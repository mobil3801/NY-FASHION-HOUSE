import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import {
  Calculator,
  CreditCard,
  FileText,
  Settings,
  Users,
  BarChart3,
  ArrowLeft,
  DollarSign } from
'lucide-react';
import { toast } from 'sonner';

// Import salary management components
import SalaryStructureForm from '@/components/SalaryStructureForm';
import SalaryCalculator from '@/components/SalaryCalculator';
import SalarySlipGenerator from '@/components/SalarySlipGenerator';
import AdvanceManagement from '@/components/AdvanceManagement';

// Import services and types
import { salaryService } from '@/services/salaryService';
import { SalaryStructure, SalaryStats } from '@/types/salary';

const SalaryManagementPage: React.FC = () => {
  const [currentView, setCurrentView] = useState<'main' | 'create-structure' | 'bulk-process'>('main');
  const [salaryStructures, setSalaryStructures] = useState<SalaryStructure[]>([]);
  const [salaryStats, setSalaryStats] = useState<SalaryStats | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [structuresData, statsData] = await Promise.all([
      salaryService.getAllSalaryStructures(),
      salaryService.getSalaryStats()]
      );
      setSalaryStructures(structuresData);
      setSalaryStats(statsData);
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load salary data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSalaryStructure = async (data: Omit<SalaryStructure, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      await salaryService.createSalaryStructure(data);
      toast.success('Salary structure created successfully');
      setCurrentView('main');
      loadData();
    } catch (error) {
      console.error('Failed to create salary structure:', error);
      toast.error('Failed to create salary structure');
      throw error;
    }
  };

  const handleBulkProcessSalaries = async () => {
    // This would open a bulk processing dialog
    setCurrentView('bulk-process');
  };

  const formatCurrency = (amount: number) => {
    return `$${amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
  };

  const handleBackToMain = () => {
    setCurrentView('main');
  };

  if (loading && !salaryStats) {
    return (
      <div className="container mx-auto px-6 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) =>
            <Card key={i}>
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="h-8 w-8 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-6 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>);

  }

  return (
    <div className="container mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        {currentView !== 'main' &&
        <Button
          variant="outline"
          onClick={handleBackToMain}
          className="flex items-center gap-2 mb-4">

            <ArrowLeft className="h-4 w-4" />
            Back to Salary Management
          </Button>
        }
        
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-100 rounded-lg">
            <DollarSign className="h-8 w-8 text-green-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Salary Management</h1>
            <p className="text-gray-600">Manage employee salaries, advances, and payroll processing</p>
          </div>
        </div>
      </div>

      {currentView === 'main' &&
      <>
          {/* Stats Cards */}
          {salaryStats &&
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <DollarSign className="h-8 w-8 text-blue-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Payroll</p>
                      <p className="text-2xl font-bold">{formatCurrency(salaryStats.totalPayroll)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Users className="h-8 w-8 text-green-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Employees</p>
                      <p className="text-2xl font-bold">{salaryStats.totalEmployees}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <BarChart3 className="h-8 w-8 text-orange-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Average Salary</p>
                      <p className="text-2xl font-bold">{formatCurrency(salaryStats.averageSalary)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <CreditCard className="h-8 w-8 text-purple-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Advances</p>
                      <p className="text-2xl font-bold">{formatCurrency(salaryStats.totalAdvances)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
        }

          {/* Main Tabs */}
          <Tabs defaultValue="calculator" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="calculator" className="flex items-center gap-2">
                <Calculator className="h-4 w-4" />
                Calculator
              </TabsTrigger>
              <TabsTrigger value="advances" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Advances
              </TabsTrigger>
              <TabsTrigger value="slips" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Salary Slips
              </TabsTrigger>
              <TabsTrigger value="structures" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Structures
              </TabsTrigger>
            </TabsList>

            <TabsContent value="calculator">
              <SalaryCalculator onCalculationComplete={loadData} />
            </TabsContent>

            <TabsContent value="advances">
              <AdvanceManagement />
            </TabsContent>

            <TabsContent value="slips">
              <SalarySlipGenerator />
            </TabsContent>

            <TabsContent value="structures">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold">Salary Structures</h3>
                    <Button onClick={() => setCurrentView('create-structure')}>
                      <Settings className="h-4 w-4 mr-2" />
                      Create New Structure
                    </Button>
                  </div>

                  {salaryStructures.length === 0 ?
                <div className="text-center py-8 text-gray-500">
                      <Settings className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No salary structures found</p>
                      <Button className="mt-4" onClick={() => setCurrentView('create-structure')}>
                        Create First Structure
                      </Button>
                    </div> :

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {salaryStructures.map((structure) =>
                  <Card key={structure.id} className="border">
                          <CardContent className="p-4">
                            <div className="space-y-2">
                              <h4 className="font-semibold">{structure.position}</h4>
                              <p className="text-sm text-gray-600">{structure.department}</p>
                              <div className="flex justify-between">
                                <span className="text-sm">Base Salary:</span>
                                <span className="font-medium">{formatCurrency(structure.baseSalary)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-sm">Allowances:</span>
                                <span className="text-sm">{structure.allowances.length}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-sm">Deductions:</span>
                                <span className="text-sm">{structure.deductions.length}</span>
                              </div>
                              <div className="pt-2 border-t">
                                <span className={`px-2 py-1 rounded-full text-xs ${
                          structure.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`
                          }>
                                  {structure.isActive ? 'Active' : 'Inactive'}
                                </span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                  )}
                    </div>
                }
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      }

      {currentView === 'create-structure' &&
      <SalaryStructureForm
        onSubmit={handleCreateSalaryStructure}
        onCancel={handleBackToMain}
        isLoading={loading} />

      }

      {currentView === 'bulk-process' &&
      <Card>
          <CardContent className="p-6">
            <div className="text-center py-8">
              <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold mb-2">Bulk Salary Processing</h3>
              <p className="text-gray-600 mb-4">
                Process salaries for multiple employees at once
              </p>
              <p className="text-sm text-gray-500">
                This feature will be implemented to allow bulk processing of employee salaries
                for a selected pay period with progress tracking and error handling.
              </p>
            </div>
          </CardContent>
        </Card>
      }
    </div>);

};

export default SalaryManagementPage;