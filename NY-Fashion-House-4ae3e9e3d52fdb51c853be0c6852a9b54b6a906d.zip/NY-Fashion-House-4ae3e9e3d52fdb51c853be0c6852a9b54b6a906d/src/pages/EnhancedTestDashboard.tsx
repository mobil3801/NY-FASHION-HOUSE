
import React from 'react';
import EnhancedComprehensiveTestDashboard from '@/components/testing/EnhancedComprehensiveTestDashboard';

const EnhancedTestDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <EnhancedComprehensiveTestDashboard />
    </div>);

};

export default EnhancedTestDashboard;