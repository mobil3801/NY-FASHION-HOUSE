
import React from 'react';
import { useTranslation } from 'react-i18next';
import ReportDashboard from '@/components/reports/ReportDashboard';
import ReportErrorBoundary from '@/components/reports/ReportErrorBoundary';

export default function ReportsPage() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        <ReportErrorBoundary>
          <ReportDashboard />
        </ReportErrorBoundary>
      </div>
    </div>);

}