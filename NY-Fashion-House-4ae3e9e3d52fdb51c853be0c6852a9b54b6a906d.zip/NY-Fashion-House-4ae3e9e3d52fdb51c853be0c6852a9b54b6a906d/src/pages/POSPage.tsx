import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Product } from '@/types/product';
import { Customer } from '@/types/customer';
import { CartItem, Sale, PaymentMethod, PaymentDetails } from '@/types/sales';
import { salesService } from '@/services/salesService';
import { formatUSD } from '@/utils/currencyUtils';
import ProductSearch from '@/components/pos/ProductSearch';
import ShoppingCart from '@/components/pos/ShoppingCart';
import CustomerSelector from '@/components/pos/CustomerSelector';
import PaymentMethods from '@/components/pos/PaymentMethods';
import ReceiptGenerator from '@/components/pos/ReceiptGenerator';
import LanguageToggle from '@/components/pos/LanguageToggle';
// import { toast } from 'sonner'; // Removed error notifications
import { ShoppingCart as CartIcon, User, CreditCard, Menu, X } from 'lucide-react';

const POSPage: React.FC = () => {
  const { t } = useTranslation();

  // State management
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<PaymentMethod | null>(null);
  const [paymentDetails, setPaymentDetails] = useState<PaymentDetails>({});
  const [discountPercentage, setDiscountPercentage] = useState(0);
  const [completedSale, setCompletedSale] = useState<Sale | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Calculate totals
  const subtotal = cartItems.reduce((sum, item) => sum + item.total, 0);
  const { discountAmount, taxAmount, totalAmount } = salesService.calculateSaleTotals(
    cartItems,
    discountPercentage
  );

  // Initialize with cash payment method
  useEffect(() => {
    const cashMethod = salesService.getPaymentMethods().find((method) => method.type === 'cash');
    if (cashMethod && !selectedPaymentMethod) {
      setSelectedPaymentMethod(cashMethod);
    }
  }, [selectedPaymentMethod]);

  // Setup cart with products (batch operation)
  const setupCartWithProducts = (products: Product[]) => {
    try {
      const cartItemsToAdd: CartItem[] = products.
      filter((product) => product.stockLevel > 0 && product.isActive).
      map((product) => ({
        id: `${product.id}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        productId: product.id,
        productName: product.name,
        productSku: product.sku,
        sellingPrice: product.sellingPrice,
        quantity: 1,
        discount: 0,
        total: product.sellingPrice,
        product: {
          id: product.id,
          name: product.name,
          sku: product.sku,
          sellingPrice: product.sellingPrice,
          stockLevel: product.stockLevel,
          sizes: product.sizes,
          colors: product.colors,
          images: product.images
        }
      }));

      if (cartItemsToAdd.length > 0) {
        setCartItems((prev) => [...prev, ...cartItemsToAdd]);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error setting up cart with products:', error);
      return false;
    }
  };

  // Add product to cart
  const handleProductSelect = (product: Product) => {
    if (product.stockLevel <= 0) {
      // Silently ignore out of stock products
      return;
    }

    const existingItemIndex = cartItems.findIndex(
      (item) => item.productId === product.id && !item.size && !item.color
    );

    if (existingItemIndex >= 0) {
      const existingItem = cartItems[existingItemIndex];
      if (existingItem.quantity >= product.stockLevel) {
        // Silently ignore if quantity exceeds stock
        return;
      }
      handleUpdateQuantity(existingItem.id, existingItem.quantity + 1);
    } else {
      const newItem: CartItem = {
        id: `${product.id}-${Date.now()}`,
        productId: product.id,
        productName: product.name,
        productSku: product.sku,
        sellingPrice: product.sellingPrice,
        quantity: 1,
        discount: 0,
        total: product.sellingPrice,
        product: {
          id: product.id,
          name: product.name,
          sku: product.sku,
          sellingPrice: product.sellingPrice,
          stockLevel: product.stockLevel,
          sizes: product.sizes,
          colors: product.colors,
          images: product.images || []
        }
      };
      setCartItems((prev) => [...prev, newItem]);
      // Removed success notification
    }
  };

  // Update item quantity
  const handleUpdateQuantity = (itemId: string, quantity: number) => {
    setCartItems((prev) => prev.map((item) => {
      if (item.id === itemId) {
        const newQuantity = Math.max(1, Math.min(quantity, item.product.stockLevel));
        return {
          ...item,
          quantity: newQuantity,
          total: newQuantity * item.sellingPrice - item.discount
        };
      }
      return item;
    }));
  };

  // Remove item from cart
  const handleRemoveItem = (itemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== itemId));
  };

  // Update item variant
  const handleUpdateVariant = (itemId: string, size?: string, color?: string) => {
    setCartItems((prev) => prev.map((item) => {
      if (item.id === itemId) {
        return { ...item, size, color };
      }
      return item;
    }));
  };

  // Validate checkout
  const validateCheckout = (): boolean => {
    if (cartItems.length === 0) {
      // Silently prevent checkout if cart is empty
      return false;
    }

    if (!selectedPaymentMethod) {
      // Silently prevent checkout if no payment method
      return false;
    }

    // Check stock availability
    const outOfStockItems = cartItems.filter((item) => item.quantity > item.product.stockLevel);
    if (outOfStockItems.length > 0) {
      // Silently prevent checkout if stock insufficient
      return false;
    }

    // Validate payment details
    switch (selectedPaymentMethod.type) {
      case 'cash':
        if (!paymentDetails.cashReceived || paymentDetails.cashReceived < totalAmount) {
          // Silently prevent checkout if insufficient cash
          return false;
        }
        break;
      case 'card':
        if (!paymentDetails.transactionId) {
          // Silently prevent checkout if no transaction ID
          return false;
        }
        break;
      case 'mobile-banking':
        if (!paymentDetails.mobileProvider || !paymentDetails.transactionId) {
          // Silently prevent checkout if details missing
          return false;
        }
        break;
      case 'digital-wallet':
        if (!paymentDetails.digitalWalletProvider || !paymentDetails.transactionId) {
          // Silently prevent checkout if details missing
          return false;
        }
        break;
    }

    return true;
  };

  // Complete sale
  const handleCompleteSale = async () => {
    if (!validateCheckout()) return;

    try {
      const saleData: Omit<Sale, 'id' | 'createdAt' | 'receiptNumber'> = {
        customerId: selectedCustomer?.id,
        customerName: selectedCustomer?.name,
        customerPhone: selectedCustomer?.phone,
        items: cartItems,
        subtotal,
        discountAmount,
        discountPercentage,
        taxAmount,
        taxPercentage: 8.875,
        totalAmount,
        paymentMethod: selectedPaymentMethod!,
        paymentDetails,
        status: 'completed',
        cashierId: 'CASHIER01', // In a real app, this would come from auth
        completedAt: new Date()
      };

      const newSale = await salesService.createSale(saleData);
      setCompletedSale(newSale);

      // Clear cart and form
      setCartItems([]);
      setSelectedCustomer(null);
      setPaymentDetails({});
      setDiscountPercentage(0);
      setIsCheckoutOpen(false);
      setIsReceiptOpen(true);

      // Sale completed silently - no notification
    } catch (error) {
      console.error('Sale completion error:', error);
      // Silently handle error - no user notification
    }
  };

  // Clear cart
  const handleClearCart = () => {
    setCartItems([]);
    setDiscountPercentage(0);
  };

  return (
    <div className="space-y-4 lg:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">{t('pos.title')}</h1>
          <p className="text-sm text-gray-600 mt-1">Process sales transactions, manage cart, and generate receipts</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 lg:gap-4">
          <LanguageToggle />
          <Badge variant="outline" className="text-xs sm:text-sm">
            Items: {cartItems.length}
          </Badge>
          <Badge variant="outline" className="inline-flex items-center rounded-md border px-2.5 py-0.5 font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 text-foreground text-xs sm:text-sm">
            Total: {formatUSD(totalAmount)}
          </Badge>
          {/* Mobile Cart Toggle */}
          <Button
            variant="outline"
            size="sm"
            className="lg:hidden"
            onClick={() => setIsCartOpen(true)}>

            <CartIcon className="h-4 w-4 mr-2" />
            Cart ({cartItems.length})
          </Button>
        </div>
      </div>

      {/* Main Content - Desktop Layout */}
      <div className="hidden lg:grid lg:grid-cols-3 gap-6 min-h-[calc(100vh-200px)]">
        {/* Left Panel - Product Search */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6 h-full">
            <h2 className="text-lg font-semibold mb-4">Product Search</h2>
            <ProductSearch onProductSelect={handleProductSelect} />
          </Card>
        </div>

        {/* Right Panel - Cart and Checkout */}
        <div className="space-y-6">
          {/* Customer Selection */}
          <Card className="p-4">
            <CustomerSelector
              selectedCustomer={selectedCustomer}
              onCustomerSelect={setSelectedCustomer} />
          </Card>

          {/* Shopping Cart */}
          <Card className="p-4 flex-1">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <CartIcon className="h-5 w-5" />
                {t('pos.cart.title')}
              </h2>
              {cartItems.length > 0 &&
              <Button variant="outline" size="sm" onClick={handleClearCart}>
                  {t('common.clear')}
                </Button>
              }
            </div>

            <ShoppingCart
              items={cartItems}
              onUpdateQuantity={handleUpdateQuantity}
              onRemoveItem={handleRemoveItem}
              onUpdateVariant={handleUpdateVariant}
              subtotal={subtotal}
              discount={discountAmount}
              tax={taxAmount}
              total={totalAmount}
              onDiscountChange={setDiscountPercentage} />

            {/* Checkout Button */}
            {cartItems.length > 0 &&
            <div className="mt-6 pt-4 border-t">
                <Button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full h-12 text-lg font-semibold touch-manipulation"
                size="lg">
                  <CreditCard className="h-5 w-5 mr-2" />
                  {t('pos.checkout.button')}
                </Button>
              </div>
            }
          </Card>
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="lg:hidden space-y-4">
        {/* Product Search */}
        <Card className="p-4">
          <h2 className="text-lg font-semibold mb-4">Product Search</h2>
          <ProductSearch onProductSelect={handleProductSelect} />
        </Card>

        {/* Customer Selection */}
        <Card className="p-4">
          <CustomerSelector
            selectedCustomer={selectedCustomer}
            onCustomerSelect={setSelectedCustomer} />

        </Card>

        {/* Checkout Button - Always visible on mobile when cart has items */}
        {cartItems.length > 0 &&
        <div className="fixed bottom-4 left-4 right-4 z-50">
            <Button
            onClick={() => setIsCheckoutOpen(true)}
            className="w-full h-14 text-lg font-semibold touch-manipulation shadow-lg"
            size="lg">

              <CreditCard className="h-5 w-5 mr-2" />
              Checkout - {formatUSD(totalAmount)}
            </Button>
          </div>
        }
      </div>

      {/* Mobile Cart Sheet */}
      <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
        <SheetContent side="right" className="w-full sm:w-96 p-0">
          <SheetHeader className="p-4 border-b">
            <SheetTitle className="flex items-center gap-2">
              <CartIcon className="h-5 w-5" />
              Shopping Cart ({cartItems.length})
            </SheetTitle>
          </SheetHeader>
          <div className="p-4 flex-1 overflow-y-auto">
            <ShoppingCart
              items={cartItems}
              onUpdateQuantity={handleUpdateQuantity}
              onRemoveItem={handleRemoveItem}
              onUpdateVariant={handleUpdateVariant}
              subtotal={subtotal}
              discount={discountAmount}
              tax={taxAmount}
              total={totalAmount}
              onDiscountChange={setDiscountPercentage} />

            {cartItems.length > 0 &&
            <div className="mt-6 pt-4 border-t space-y-2">
                <Button
                variant="outline"
                onClick={handleClearCart}
                className="w-full touch-manipulation">

                  Clear Cart
                </Button>
                <Button
                onClick={() => {
                  setIsCartOpen(false);
                  setIsCheckoutOpen(true);
                }}
                className="w-full h-12 text-lg font-semibold touch-manipulation"
                size="lg">

                  <CreditCard className="h-5 w-5 mr-2" />
                  Checkout
                </Button>
              </div>
            }
          </div>
        </SheetContent>
      </Sheet>

      {/* Checkout Dialog - Full screen on mobile */}
      <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
        <DialogContent className="max-w-2xl max-h-[95vh] w-[95vw] sm:w-full overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg sm:text-xl">Complete Sale - {formatUSD(totalAmount)}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 sm:space-y-6">
            {/* Order Summary */}
            <div>
              <h3 className="font-medium mb-3">Order Summary</h3>
              <div className="space-y-2 text-sm">
                {cartItems.map((item) =>
                <div key={item.id} className="flex justify-between">
                    <span className="truncate">{item.productName} x{item.quantity}</span>
                    <span className="flex-shrink-0 ml-2">{formatUSD(item.total)}</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between font-semibold text-base">
                  <span>Total</span>
                  <span>{formatUSD(totalAmount)}</span>
                </div>
              </div>
            </div>

            <Separator />

            {/* Payment Methods */}
            <PaymentMethods
              selectedMethod={selectedPaymentMethod}
              onMethodSelect={setSelectedPaymentMethod}
              paymentDetails={paymentDetails}
              onDetailsChange={setPaymentDetails}
              totalAmount={totalAmount} />


            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                variant="outline"
                onClick={() => setIsCheckoutOpen(false)}
                className="flex-1 h-12 touch-manipulation">

                {t('common.cancel')}
              </Button>
              <Button
                onClick={handleCompleteSale}
                className="flex-1 h-12 touch-manipulation"
                disabled={!validateCheckout()}>

                Complete Sale
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Receipt Dialog */}
      <Dialog open={isReceiptOpen} onOpenChange={setIsReceiptOpen}>
        <DialogContent className="max-w-md w-[95vw] sm:w-full">
          <DialogHeader>
            <DialogTitle>Sale Completed!</DialogTitle>
          </DialogHeader>

          {completedSale &&
          <div className="space-y-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <h3 className="text-lg font-semibold text-green-800">
                  {formatUSD(completedSale.totalAmount)}
                </h3>
                <p className="text-green-600">Receipt: {completedSale.receiptNumber}</p>
              </div>

              <ReceiptGenerator
              sale={completedSale}
              onPrint={() => {/* Silently handle print - no notification */}} />


              <Button
              variant="outline"
              onClick={() => setIsReceiptOpen(false)}
              className="w-full h-12 touch-manipulation">

                Close
              </Button>
            </div>
          }
        </DialogContent>
      </Dialog>

      {/* Bottom padding for mobile when checkout button is fixed */}
      {cartItems.length > 0 && <div className="lg:hidden h-20"></div>}
    </div>);

};

export default POSPage;