import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Database,
  Activity,
  Shield,
  Settings,
  Play,
  CheckCircle2,
  AlertTriangle,
  Info,
  TrendingUp,
  Clock } from
'lucide-react';
import { toast } from 'sonner';
import DataVerificationDashboard from '@/components/verification/DataVerificationDashboard';
import AutomatedVerificationRunner from '@/components/verification/AutomatedVerificationRunner';
import { constraintValidationService, type ComprehensiveConstraintReport } from '@/services/constraintValidationService';

const ComprehensiveDataVerificationPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [constraintReport, setConstraintReport] = useState<ComprehensiveConstraintReport | null>(null);
  const [isRunningConstraints, setIsRunningConstraints] = useState(false);

  const runConstraintValidation = async () => {
    setIsRunningConstraints(true);
    try {
      toast.info('Running constraint validation...');
      const report = await constraintValidationService.runComprehensiveConstraintValidation();
      setConstraintReport(report);
      toast.success('Constraint validation completed');
    } catch (error) {
      console.error('Constraint validation failed:', error);
      toast.error('Constraint validation failed: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsRunningConstraints(false);
    }
  };

  const getStatusIcon = (status: string, size: number = 20) => {
    switch (status) {
      case 'PASSED':
        return <CheckCircle2 size={size} className="text-green-600" />;
      case 'FAILED':
        return <AlertTriangle size={size} className="text-red-600" />;
      case 'WARNING':
        return <AlertTriangle size={size} className="text-yellow-600" />;
      default:
        return <Info size={size} className="text-blue-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PASSED':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'WARNING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const OverviewTab = () =>
  <div className="space-y-6">
      {/* Introduction */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield size={24} />
            Comprehensive Data Verification System
          </CardTitle>
          <CardDescription>
            A complete suite of tools to validate data integrity, relationships, constraints, 
            and cross-service flows across your entire database ecosystem.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Database size={32} className="mx-auto mb-2 text-blue-600" />
              <h3 className="font-semibold">Data Integrity</h3>
              <p className="text-sm text-gray-600 mt-1">
                Validates table structures, data types, and business rules
              </p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <Activity size={32} className="mx-auto mb-2 text-green-600" />
              <h3 className="font-semibold">Data Flow</h3>
              <p className="text-sm text-gray-600 mt-1">
                Tests cross-service integrations and data consistency
              </p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Shield size={32} className="mx-auto mb-2 text-purple-600" />
              <h3 className="font-semibold">Constraints</h3>
              <p className="text-sm text-gray-600 mt-1">
                Validates database constraints and referential integrity
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Features */}
      <Card>
        <CardHeader>
          <CardTitle>Verification Capabilities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold text-green-700">✓ Data Integrity Verification</h4>
              <ul className="text-sm space-y-1 text-gray-600 pl-4">
                <li>• CRUD operation validation for all tables</li>
                <li>• Required field validation</li>
                <li>• Business rule enforcement</li>
                <li>• Data type validation</li>
                <li>• Record count and consistency checks</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-blue-700">✓ Cross-Service Flow Testing</h4>
              <ul className="text-sm space-y-1 text-gray-600 pl-4">
                <li>• Customer-to-Sales integration</li>
                <li>• Product-to-Sales validation</li>
                <li>• Employee-to-Salary flow</li>
                <li>• Invoice-to-Accounting integration</li>
                <li>• Supplier-to-Product relationships</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-purple-700">✓ Constraint Validation</h4>
              <ul className="text-sm space-y-1 text-gray-600 pl-4">
                <li>• NOT NULL constraint validation</li>
                <li>• UNIQUE constraint verification</li>
                <li>• CHECK constraint validation</li>
                <li>• Foreign key referential integrity</li>
                <li>• Business logic constraints</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-orange-700">✓ Automated Testing</h4>
              <ul className="text-sm space-y-1 text-gray-600 pl-4">
                <li>• Scheduled verification runs</li>
                <li>• Performance metrics tracking</li>
                <li>• Historical test result storage</li>
                <li>• Automated error reporting</li>
                <li>• Comprehensive result dashboard</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Verification</CardTitle>
          <CardDescription>
            Run individual verification components or comprehensive tests
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2 h-auto py-4 px-4"
            variant="outline">

              <Database size={20} />
              <div className="text-left">
                <div className="font-medium">Data Integrity</div>
                <div className="text-xs text-gray-500">Full validation</div>
              </div>
            </Button>
            
            <Button
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2 h-auto py-4 px-4"
            variant="outline">

              <Activity size={20} />
              <div className="text-left">
                <div className="font-medium">Data Flow</div>
                <div className="text-xs text-gray-500">Cross-service tests</div>
              </div>
            </Button>
            
            <Button
            onClick={runConstraintValidation}
            disabled={isRunningConstraints}
            className="flex items-center gap-2 h-auto py-4 px-4"
            variant="outline">

              <Shield size={20} />
              <div className="text-left">
                <div className="font-medium">Constraints</div>
                <div className="text-xs text-gray-500">Database rules</div>
              </div>
            </Button>
            
            <Button
            onClick={() => setActiveTab('automation')}
            className="flex items-center gap-2 h-auto py-4 px-4"
            variant="outline">

              <Settings size={20} />
              <div className="text-left">
                <div className="font-medium">Automation</div>
                <div className="text-xs text-gray-500">Schedule tests</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>;


  const ConstraintsTab = () =>
  <div className="space-y-6">
      {/* Constraint Validation Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield size={20} />
            Database Constraint Validation
          </CardTitle>
          <CardDescription>
            Validate database constraints, referential integrity, and business rules
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Button
            onClick={runConstraintValidation}
            disabled={isRunningConstraints}
            className="flex items-center gap-2">

              {isRunningConstraints ?
            <Clock size={16} className="animate-pulse" /> :

            <Play size={16} />
            }
              Run Constraint Validation
            </Button>
            
            {constraintReport &&
          <div className="flex items-center gap-2">
                {getStatusIcon(constraintReport.overallStatus, 16)}
                <Badge className={getStatusColor(constraintReport.overallStatus)}>
                  {constraintReport.overallStatus}
                </Badge>
                <span className="text-sm text-gray-600">
                  Last run: {new Date(constraintReport.timestamp).toLocaleString()}
                </span>
              </div>
          }
          </div>
        </CardContent>
      </Card>

      {/* Constraint Results */}
      {constraintReport &&
    <>
          {/* Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp size={20} />
                Validation Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {constraintReport.summary.totalConstraints}
                  </div>
                  <div className="text-gray-600 text-sm">Total Constraints</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {constraintReport.summary.validConstraints}
                  </div>
                  <div className="text-gray-600 text-sm">Valid Constraints</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">
                    {constraintReport.summary.violatedConstraints}
                  </div>
                  <div className="text-gray-600 text-sm">Violations</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">
                    {constraintReport.summary.totalViolations}
                  </div>
                  <div className="text-gray-600 text-sm">Total Issues</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Constraint Details */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Constraint Results */}
            <Card>
              <CardHeader>
                <CardTitle>Constraint Violations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {constraintReport.constraintResults.map((constraint, index) =>
              <div
                key={index}
                className={`border rounded-lg p-3 ${constraint.isValid ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>

                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{constraint.constraintName}</span>
                        <Badge
                    className={constraint.isValid ?
                    'bg-green-100 text-green-800' :
                    constraint.severity === 'ERROR' ?
                    'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                    }>

                          {constraint.isValid ? 'VALID' : constraint.severity}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-600 mb-1">{constraint.description}</p>
                      {constraint.violationCount > 0 &&
                <p className="text-xs text-red-600">
                          {constraint.violationCount} violation(s) found
                        </p>
                }
                    </div>
              )}
                </div>
              </CardContent>
            </Card>

            {/* Foreign Key Issues */}
            <Card>
              <CardHeader>
                <CardTitle>Foreign Key Integrity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {constraintReport.foreignKeyResults.map((fk, index) =>
              <div
                key={index}
                className={`border rounded-lg p-3 ${fk.isValid ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>

                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{fk.relationshipName}</span>
                        <Badge className={fk.isValid ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                          {fk.isValid ? 'VALID' : 'INVALID'}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-600 mb-1">
                        {fk.sourceTable}.{fk.sourceField} → {fk.targetTable}.{fk.targetField}
                      </p>
                      {fk.orphanedRecords.length > 0 &&
                <p className="text-xs text-red-600">
                          {fk.orphanedRecords.length} orphaned record(s)
                        </p>
                }
                    </div>
              )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Data Type Issues */}
          {constraintReport.dataTypeResults.some((dt) => !dt.isValid) &&
      <Card>
              <CardHeader>
                <CardTitle>Data Type Violations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {constraintReport.dataTypeResults.
            filter((dt) => !dt.isValid).
            map((dataType, index) =>
            <Alert key={index} className="border-red-200">
                        <AlertTriangle size={16} className="text-red-600" />
                        <AlertDescription>
                          <strong>{dataType.tableName}.{dataType.field}</strong>: 
                          Expected {dataType.expectedType}, found invalid data in {dataType.invalidRecords.length} records
                        </AlertDescription>
                      </Alert>
            )}
                </div>
              </CardContent>
            </Card>
      }
        </>
    }

      {!constraintReport &&
    <Alert>
          <Info size={16} />
          <AlertDescription>
            No constraint validation report available. Click "Run Constraint Validation" to generate a comprehensive report.
          </AlertDescription>
        </Alert>
    }
    </div>;


  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Comprehensive Data Verification</h1>
        <p className="text-gray-600">
          Complete validation system for data integrity, relationships, constraints, and cross-service flows
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4 mb-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Info size={16} />
            <span className="hidden sm:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <Database size={16} />
            <span className="hidden sm:inline">Integrity & Flow</span>
          </TabsTrigger>
          <TabsTrigger value="constraints" className="flex items-center gap-2">
            <Shield size={16} />
            <span className="hidden sm:inline">Constraints</span>
          </TabsTrigger>
          <TabsTrigger value="automation" className="flex items-center gap-2">
            <Settings size={16} />
            <span className="hidden sm:inline">Automation</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab />
        </TabsContent>

        <TabsContent value="dashboard">
          <DataVerificationDashboard />
        </TabsContent>

        <TabsContent value="constraints">
          <ConstraintsTab />
        </TabsContent>

        <TabsContent value="automation">
          <AutomatedVerificationRunner />
        </TabsContent>
      </Tabs>
    </div>);

};

export default ComprehensiveDataVerificationPage;