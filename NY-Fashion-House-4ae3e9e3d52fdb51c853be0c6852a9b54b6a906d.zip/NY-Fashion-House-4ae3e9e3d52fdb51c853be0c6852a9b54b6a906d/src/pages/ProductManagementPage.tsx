import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Package, TrendingUp, AlertTriangle, Users } from 'lucide-react';
import { Product, ProductSearchParams } from '@/types/product';
import { Supplier } from '@/types/supplier';
import { enhancedProductService } from '@/services/enhancedProductService';
import { supplierService } from '@/services/supplierService';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import ProductCatalog from '@/components/ProductCatalog';
import ProductSearchFilter from '@/components/ProductSearchFilter';
import ProductForm from '@/components/ProductForm';
import ProductDetails from '@/components/ProductDetails';
import LowStockAlerts from '@/components/LowStockAlerts';
import SupplierManagement from '@/components/SupplierManagement';
import PriceTagGenerator from '@/components/PriceTagGenerator';
import DatabaseHealthCheck from '@/components/DatabaseHealthCheck';
import { toast } from 'sonner';

type ViewMode = 'catalog' | 'add' | 'edit';

const ProductManagementPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('catalog');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [filters, setFilters] = useState<ProductSearchParams>({});
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalValue: 0,
    lowStock: 0,
    outOfStock: 0
  });

  useEffect(() => {
    loadData();
  }, [filters]);

  const loadData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Load suppliers first
      let suppliersData: Supplier[] = [];
      try {
        suppliersData = await supplierService.getAllSuppliers();
      } catch (supplierError) {
        console.warn('Failed to load suppliers:', supplierError);
        // Continue without suppliers rather than failing completely
      }

      // Load products with enhanced error handling
      let productsData: Product[] = [];
      try {
        // Test connection first
        const connectionStatus = enhancedProductService.getConnectionStatus();
        if (!connectionStatus.isConnected || connectionStatus.needsRestoration) {
          console.log('Connection issues detected, attempting restoration...');
          await enhancedProductService.restoreConnection();
        }

        productsData = await enhancedProductService.getAllProducts(filters);
      } catch (productError) {
        const errorDetails = enhancedErrorLoggingService.logErrorWithDetails(productError as Error, {
          title: 'Product Loading Error',
          action: 'Load products on page',
          operation: 'loadData',
          severity: 'high',
          category: 'database',
          service: 'ProductManagementPage'
        });

        console.error('[Route: /products] Failed to load products:', errorDetails);
        throw new Error(enhancedErrorLoggingService.createUserFriendlyMessage(productError as Error));
      }

      setProducts(productsData);
      setSuppliers(suppliersData);

      // Calculate stats safely
      const totalProducts = productsData.length;
      const totalValue = productsData.reduce((sum, p) => {
        const price = p.sellingPrice || 0;
        const stock = p.stockLevel || 0;
        return sum + price * stock;
      }, 0);
      const lowStock = productsData.filter((p) =>
      (p.stockLevel || 0) <= (p.minStockLevel || 0) && (p.stockLevel || 0) > 0
      ).length;
      const outOfStock = productsData.filter((p) => (p.stockLevel || 0) === 0).length;

      setStats({ totalProducts, totalValue, lowStock, outOfStock });
    } catch (error) {
      const errorDetails = enhancedErrorLoggingService.logErrorWithDetails(error as Error, {
        title: 'Data Loading Error',
        action: 'Load page data',
        operation: 'loadData',
        severity: 'high',
        category: 'database',
        service: 'ProductManagementPage'
      });

      const errorMessage = error instanceof Error ? error.message : 'Failed to load data';
      console.error('[Route: /products] Error loading data:', errorDetails);
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleProductSaved = async () => {
    setViewMode('catalog');
    setSelectedProduct(null);
    await refreshData();
  };

  const refreshData = async () => {
    await loadData(); // Reload all data
  };

  const handleViewProduct = (product: Product) => {
    setSelectedProduct(product);
    setDetailsOpen(true);
  };

  const handleEditProduct = (product: Product) => {
    setSelectedProduct(product);
    setViewMode('edit');
  };

  const handleProductUpdate = async (updatedProduct: Product) => {
    setSelectedProduct(updatedProduct);
    await loadData(); // Reload to get fresh data
  };

  const getSupplierForProduct = (supplierId: string) => {
    return suppliers.find((s) => s.id === supplierId) || null;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount);
  };

  // Error state
  if (error && !loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center justify-center py-8">
            <AlertTriangle className="h-12 w-12 text-red-500 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Error Loading Products</h3>
            <p className="text-gray-500 text-center mb-4">{error}</p>
            <Button onClick={() => loadData()} variant="outline">
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>);

  }

  if (viewMode === 'add') {
    return (
      <ProductForm
        onSave={handleProductSaved}
        onCancel={() => setViewMode('catalog')}
        onSuccess={refreshData} />);


  }

  if (viewMode === 'edit' && selectedProduct) {
    return (
      <ProductForm
        product={selectedProduct}
        onSave={handleProductSaved}
        onCancel={() => setViewMode('catalog')}
        onSuccess={refreshData} />);


  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Product & Inventory Management</h1>
          <p className="text-gray-600">
            Manage your products, track inventory, and handle suppliers
          </p>
        </div>
        <div className="flex gap-2">
          <PriceTagGenerator products={products} />
          <Button onClick={() => setViewMode('add')}>
            <Plus className="w-4 h-4 mr-2" />
            Add Product
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalProducts}</div>
            <p className="text-xs text-muted-foreground">
              Active products in catalog
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inventory Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalValue)}</div>
            <p className="text-xs text-muted-foreground">
              Total value of current stock
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.lowStock}</div>
            <p className="text-xs text-muted-foreground">
              Items below minimum stock
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Out of Stock</CardTitle>
            <Package className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.outOfStock}</div>
            <p className="text-xs text-muted-foreground">
              Items with zero stock
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="products" className="space-y-6">
        <TabsList>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="inventory">Inventory Alerts</TabsTrigger>
          <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
          <TabsTrigger value="health">System Health</TabsTrigger>
        </TabsList>

        <TabsContent value="products" className="space-y-6">
          {/* Search and Filter */}
          <ProductSearchFilter
            filters={filters}
            onFiltersChange={setFilters}
            suppliers={suppliers} />


          {/* Product Catalog */}
          <ProductCatalog
            products={products}
            onViewProduct={handleViewProduct}
            onEditProduct={handleEditProduct}
            onDeleteProduct={refreshData}
            loading={loading} />


          {/* Product Details Dialog */}
          {selectedProduct &&
          <ProductDetails
            product={selectedProduct}
            supplier={getSupplierForProduct(selectedProduct.supplierId)}
            open={detailsOpen}
            onOpenChange={setDetailsOpen}
            onEdit={handleEditProduct}
            onProductUpdate={handleProductUpdate} />

          }
        </TabsContent>

        <TabsContent value="inventory" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Inventory Status Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-4 bg-green-50 rounded-lg">
                        <p className="text-2xl font-bold text-green-600">
                          {stats.totalProducts - stats.lowStock - stats.outOfStock}
                        </p>
                        <p className="text-sm text-green-700">Well Stocked</p>
                      </div>
                      <div className="p-4 bg-yellow-50 rounded-lg">
                        <p className="text-2xl font-bold text-yellow-600">{stats.lowStock}</p>
                        <p className="text-sm text-yellow-700">Low Stock</p>
                      </div>
                      <div className="p-4 bg-red-50 rounded-lg">
                        <p className="text-2xl font-bold text-red-600">{stats.outOfStock}</p>
                        <p className="text-sm text-red-700">Out of Stock</p>
                      </div>
                    </div>

                    {(stats.lowStock > 0 || stats.outOfStock > 0) &&
                    <div className="mt-6">
                        <div className="flex items-center gap-2 mb-3">
                          <AlertTriangle className="w-5 h-5 text-amber-600" />
                          <h3 className="font-semibold">Action Required</h3>
                        </div>
                        
                        {stats.outOfStock > 0 &&
                      <div className="p-3 bg-red-50 border border-red-200 rounded-lg mb-3">
                            <p className="text-red-700">
                              <strong>{stats.outOfStock}</strong> products are completely out of stock 
                              and need immediate restocking.
                            </p>
                          </div>
                      }
                        
                        {stats.lowStock > 0 &&
                      <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <p className="text-yellow-700">
                              <strong>{stats.lowStock}</strong> products are running low on stock. 
                              Consider reordering soon to avoid stockouts.
                            </p>
                          </div>
                      }
                      </div>
                    }
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <LowStockAlerts
                onViewProduct={(productId) => {
                  const product = products.find((p) => p.id === productId);
                  if (product) {
                    handleViewProduct(product);
                  }
                }} />

            </div>
          </div>
        </TabsContent>

        <TabsContent value="suppliers" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <SupplierManagement />
            </div>

            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Supplier Stats
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">{suppliers.length}</p>
                    <p className="text-sm text-blue-700">Active Suppliers</p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Top Categories</h4>
                    {/* Show top supplier categories */}
                    {Array.from(
                      new Set(suppliers.flatMap((s) => s.categories))
                    ).slice(0, 5).map((category) => {
                      const count = suppliers.filter((s) => s.categories.includes(category)).length;
                      return (
                        <div key={category} className="flex justify-between items-center">
                          <span className="text-sm">{category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}</span>
                          <Badge variant="outline">{count}</Badge>
                        </div>);

                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="health" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DatabaseHealthCheck />
            
            <Card>
              <CardHeader>
                <CardTitle>Recent Error Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  System errors are automatically logged with detailed context for debugging.
                </p>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Error Logging Features:</span>
                  </div>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Correlation ID tracking</li>
                    <li>• Stack trace capture</li>
                    <li>• Context-aware error details</li>
                    <li>• Automatic remediation suggestions</li>
                    <li>• Automatic retry for recoverable errors</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>);

};

export default ProductManagementPage;