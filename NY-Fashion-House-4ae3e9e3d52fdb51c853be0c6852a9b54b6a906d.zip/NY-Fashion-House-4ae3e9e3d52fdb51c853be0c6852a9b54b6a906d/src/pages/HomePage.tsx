
import React from 'react';
import StatsCards from '@/components/StatsCards';
import DashboardContent from '@/components/DashboardContent';

const HomePage: React.FC = () => {
  return (
    <div className="space-y-6 lg:space-y-8 transition-colors duration-300">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold mb-2" style={{ color: 'var(--theme-text)' }}>
          Dashboard Overview
        </h1>
        <p className="text-sm sm:text-base" style={{ color: 'var(--theme-muted-foreground)' }}>
          Welcome to your business management dashboard. Monitor key metrics and manage your operations efficiently.
        </p>
      </div>
      
      <StatsCards />
      
      <div className="mt-6 lg:mt-8">
        <DashboardContent />
      </div>
    </div>);

};

export default HomePage;