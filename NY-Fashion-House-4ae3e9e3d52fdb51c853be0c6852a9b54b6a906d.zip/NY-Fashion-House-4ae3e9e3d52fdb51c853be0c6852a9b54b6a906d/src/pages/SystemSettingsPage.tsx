
import React, { useState, useEffect } from 'react';
import { SystemSetting, SettingsCategory } from '@/types/settings';
import { SettingsService } from '@/services/settingsService';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import SettingsCategoryComponent from '@/components/settings/SettingsCategory';
import SettingsExportImport from '@/components/settings/SettingsExportImport';
import { Settings, Building, Shield, Bell, Plug, RefreshCw, Info } from 'lucide-react';
import { toast } from 'sonner';

const SystemSettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<SystemSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('general');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const categories: SettingsCategory[] = [
  {
    key: 'general',
    name: 'General',
    description: 'Basic application settings and preferences',
    icon: '⚙️'
  },
  {
    key: 'business',
    name: 'Business',
    description: 'Company information and business-specific settings',
    icon: '🏢'
  },
  {
    key: 'security',
    name: 'Security',
    description: 'Authentication and access control settings',
    icon: '🔒'
  },
  {
    key: 'notifications',
    name: 'Notifications',
    description: 'Email and notification preferences',
    icon: '🔔'
  },
  {
    key: 'integrations',
    name: 'Integrations',
    description: 'Third-party integrations and system maintenance',
    icon: '🔌'
  }];


  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const settingsData = await SettingsService.getAllSettings();
      setSettings(settingsData);

      // Initialize default settings if none exist
      if (settingsData.length === 0) {
        await SettingsService.initializeDefaultSettings();
        const newSettingsData = await SettingsService.getAllSettings();
        setSettings(newSettingsData);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast.error('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSettingSave = async (updatedSetting: SystemSetting) => {
    try {
      await SettingsService.updateSetting(updatedSetting);

      // Update local state
      setSettings((prevSettings) =>
      prevSettings.map((setting) =>
      setting.id === updatedSetting.id ? updatedSetting : setting
      )
      );

      toast.success('Setting saved successfully');
    } catch (error) {
      console.error('Error saving setting:', error);
      toast.error('Failed to save setting');
      throw error;
    }
  };

  const getSettingsByCategory = (categoryKey: string) => {
    return settings.filter((setting) => setting.category === categoryKey && setting.is_active);
  };

  const initializeDefaults = async () => {
    setLoading(true);
    try {
      await SettingsService.initializeDefaultSettings();
      await loadSettings();
      toast.success('Default settings initialized successfully');
    } catch (error) {
      console.error('Error initializing defaults:', error);
      toast.error('Failed to initialize default settings');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </div>);

  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center">
            <Settings className="h-8 w-8 mr-3" />
            System Settings
          </h1>
          <p className="text-muted-foreground mt-2">
            Configure system preferences, business settings, and integrations
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="flex items-center">
            <Info className="h-3 w-3 mr-1" />
            {settings.length} settings configured
          </Badge>
          <Button variant="outline" onClick={initializeDefaults}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Reset to Defaults
          </Button>
        </div>
      </div>

      {/* Settings Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          {categories.map((category) => {
            const categorySettings = getSettingsByCategory(category.key);
            return (
              <TabsTrigger
                key={category.key}
                value={category.key}
                className="flex items-center space-x-2">

                <span>{category.icon}</span>
                <span className="hidden sm:inline">{category.name}</span>
                <Badge variant="secondary" className="ml-1">
                  {categorySettings.length}
                </Badge>
              </TabsTrigger>);

          })}
        </TabsList>

        {categories.map((category) => {
          const categorySettings = getSettingsByCategory(category.key);

          return (
            <TabsContent key={category.key} value={category.key} className="space-y-6">
              {categorySettings.length > 0 ?
              <SettingsCategoryComponent
                category={category}
                settings={categorySettings}
                onSettingSave={handleSettingSave} /> :


              <Card>
                  <CardContent className="flex items-center justify-center py-12">
                    <div className="text-center space-y-3">
                      <div className="text-4xl">{category.icon}</div>
                      <h3 className="text-lg font-medium">No {category.name} Settings</h3>
                      <p className="text-muted-foreground">
                        No settings found in this category. 
                        <Button variant="link" onClick={initializeDefaults} className="px-1">
                          Initialize defaults
                        </Button>
                        to get started.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              }
            </TabsContent>);

        })}
      </Tabs>

      {/* Export/Import Section */}
      <SettingsExportImport />

      {/* Information Alert */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          Settings are automatically saved when you make changes. Some settings may require an application restart to take effect.
        </AlertDescription>
      </Alert>
    </div>);

};

export default SystemSettingsPage;