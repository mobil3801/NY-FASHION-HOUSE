// Error Tracking Test Page - Comprehensive testing interface for error tracking system
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useErrorTracking } from '@/hooks/useErrorTracking';
import { ErrorContext } from '@/types/errorTypes';
import {
  Bug,
  AlertTriangle,
  Network,
  Database,
  Shield,
  Zap,
  TestTube,
  RefreshCw,
  Eye } from
'lucide-react';
import ErrorDashboard from '@/components/ErrorDashboard';

interface ErrorTestCase {
  name: string;
  description: string;
  icon: React.ReactNode;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  execute: () => void;
}

const ErrorTrackingTestPage: React.FC = () => {
  const {
    logError,
    errorReports,
    statistics,
    isLoading,
    clearAllErrors,
    refreshData
  } = useErrorTracking({ autoRefresh: true, refreshInterval: 5000 });

  const [customError, setCustomError] = useState({
    message: '',
    severity: 'medium' as 'low' | 'medium' | 'high' | 'critical',
    category: 'client',
    component: '',
    action: ''
  });

  // Simulate network error
  const simulateNetworkError = async () => {
    try {
      await fetch('/api/nonexistent-endpoint');
    } catch (error) {
      await logError(error as Error, {
        category: 'network',
        severity: 'high',
        action: 'API Request Test',
        operation: 'Network simulation',
        requestDetails: {
          url: '/api/nonexistent-endpoint',
          method: 'GET'
        }
      });
    }
  };

  // Simulate validation error
  const simulateValidationError = async () => {
    const error = new Error('Validation failed: Required field "email" is missing');
    await logError(error, {
      category: 'validation',
      severity: 'medium',
      action: 'Form Validation',
      operation: 'User input validation',
      userInputs: { name: 'John Doe', email: '' }
    });
  };

  // Simulate authentication error
  const simulateAuthError = async () => {
    const error = new Error('Unauthorized: Session token has expired');
    await logError(error, {
      category: 'authentication',
      severity: 'high',
      action: 'Authentication Check',
      operation: 'Token validation',
      additionalData: {
        tokenExpiry: new Date().toISOString(),
        userAgent: navigator.userAgent
      }
    });
  };

  // Simulate database error
  const simulateDatabaseError = async () => {
    const error = new Error('Database connection timeout after 30 seconds');
    await logError(error, {
      category: 'server',
      severity: 'critical',
      action: 'Database Query',
      operation: 'Data retrieval',
      additionalData: {
        query: 'SELECT * FROM users WHERE id = ?',
        timeout: 30000
      }
    });
  };

  // Simulate React component error
  const simulateComponentError = async () => {
    const error = new Error('Cannot read property "map" of undefined');
    await logError(error, {
      category: 'client',
      severity: 'high',
      component: 'UserList',
      action: 'Component Rendering',
      operation: 'Data mapping',
      componentStack: 'UserList → UserCard → Avatar'
    });
  };

  // Simulate JavaScript error
  const simulateJavaScriptError = () => {
    // This will trigger the global error handler
    throw new Error('Uncaught TypeError: Cannot access property before initialization');
  };

  // Simulate promise rejection
  const simulatePromiseRejection = () => {
    // This will trigger the unhandled rejection handler
    Promise.reject(new Error('Promise rejected: Failed to process async operation'));
  };

  // Test error frequency
  const simulateFrequentError = async () => {
    for (let i = 0; i < 5; i++) {
      const error = new Error(`Frequent error occurrence #${i + 1}`);
      await logError(error, {
        category: 'client',
        severity: 'low',
        action: 'Frequency Test',
        operation: `Test iteration ${i + 1}`,
        additionalData: { iteration: i + 1 }
      });
    }
  };

  // Submit custom error
  const submitCustomError = async () => {
    if (!customError.message) return;

    const error = new Error(customError.message);
    await logError(error, {
      category: customError.category as any,
      severity: customError.severity,
      component: customError.component || undefined,
      action: customError.action || 'Custom Error Test',
      operation: 'Manual error simulation'
    });

    // Reset form
    setCustomError({
      message: '',
      severity: 'medium',
      category: 'client',
      component: '',
      action: ''
    });
  };

  const testCases: ErrorTestCase[] = [
  {
    name: 'Network Error',
    description: 'Simulate a failed API request',
    icon: <Network className="w-5 h-5" />,
    severity: 'high',
    category: 'network',
    execute: simulateNetworkError
  },
  {
    name: 'Validation Error',
    description: 'Simulate form validation failure',
    icon: <AlertTriangle className="w-5 h-5" />,
    severity: 'medium',
    category: 'validation',
    execute: simulateValidationError
  },
  {
    name: 'Authentication Error',
    description: 'Simulate expired session token',
    icon: <Shield className="w-5 h-5" />,
    severity: 'high',
    category: 'authentication',
    execute: simulateAuthError
  },
  {
    name: 'Database Error',
    description: 'Simulate database connection timeout',
    icon: <Database className="w-5 h-5" />,
    severity: 'critical',
    category: 'server',
    execute: simulateDatabaseError
  },
  {
    name: 'Component Error',
    description: 'Simulate React component rendering error',
    icon: <Bug className="w-5 h-5" />,
    severity: 'high',
    category: 'client',
    execute: simulateComponentError
  },
  {
    name: 'JavaScript Error',
    description: 'Trigger uncaught JavaScript error',
    icon: <Zap className="w-5 h-5" />,
    severity: 'critical',
    category: 'client',
    execute: simulateJavaScriptError
  },
  {
    name: 'Promise Rejection',
    description: 'Trigger unhandled promise rejection',
    icon: <RefreshCw className="w-5 h-5" />,
    severity: 'high',
    category: 'client',
    execute: simulatePromiseRejection
  },
  {
    name: 'Frequent Errors',
    description: 'Generate multiple similar errors',
    icon: <TestTube className="w-5 h-5" />,
    severity: 'low',
    category: 'client',
    execute: simulateFrequentError
  }];


  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Error Tracking System Test Suite
        </h1>
        <p className="text-gray-600">
          Comprehensive testing interface for the error tracking and reporting system.
          Test various error scenarios and monitor real-time error analytics.
        </p>
      </div>

      {/* Quick Stats */}
      {statistics &&
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Errors</p>
                  <p className="text-2xl font-bold">{statistics.totalErrors}</p>
                </div>
                <Bug className="w-8 h-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Recent</p>
                  <p className="text-2xl font-bold text-orange-600">{statistics.recentErrors}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Critical</p>
                  <p className="text-2xl font-bold text-red-600">{statistics.errorsBySeverity.critical || 0}</p>
                </div>
                <Zap className="w-8 h-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Resolved</p>
                  <p className="text-2xl font-bold text-green-600">{statistics.resolvedErrors}</p>
                </div>
                <RefreshCw className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      }

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Test Controls */}
        <div className="lg:col-span-1 space-y-6">
          {/* Predefined Test Cases */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TestTube className="w-5 h-5" />
                Error Test Cases
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {testCases.map((testCase, index) =>
              <div key={index} className="p-3 border rounded-lg hover:bg-gray-50">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {testCase.icon}
                      <h4 className="font-medium text-sm">{testCase.name}</h4>
                    </div>
                    <Badge className={getSeverityColor(testCase.severity)}>
                      {testCase.severity}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-3">{testCase.description}</p>
                  <Button
                  size="sm"
                  onClick={testCase.execute}
                  className="w-full"
                  variant={testCase.severity === 'critical' ? 'destructive' : 'outline'}>

                    Execute Test
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Custom Error Form */}
          <Card>
            <CardHeader>
              <CardTitle>Custom Error Test</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="error-message">Error Message</Label>
                <Textarea
                  id="error-message"
                  placeholder="Enter custom error message..."
                  value={customError.message}
                  onChange={(e) => setCustomError((prev) => ({ ...prev, message: e.target.value }))} />

              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="severity">Severity</Label>
                  <Select
                    value={customError.severity}
                    onValueChange={(value: any) => setCustomError((prev) => ({ ...prev, severity: value }))}>

                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={customError.category}
                    onValueChange={(value) => setCustomError((prev) => ({ ...prev, category: value }))}>

                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="client">Client</SelectItem>
                      <SelectItem value="server">Server</SelectItem>
                      <SelectItem value="network">Network</SelectItem>
                      <SelectItem value="validation">Validation</SelectItem>
                      <SelectItem value="authentication">Authentication</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="component">Component (optional)</Label>
                <Input
                  id="component"
                  placeholder="Component name"
                  value={customError.component}
                  onChange={(e) => setCustomError((prev) => ({ ...prev, component: e.target.value }))} />

              </div>

              <div>
                <Label htmlFor="action">Action (optional)</Label>
                <Input
                  id="action"
                  placeholder="Action description"
                  value={customError.action}
                  onChange={(e) => setCustomError((prev) => ({ ...prev, action: e.target.value }))} />

              </div>

              <Button
                onClick={submitCustomError}
                disabled={!customError.message}
                className="w-full">

                Log Custom Error
              </Button>
            </CardContent>
          </Card>

          {/* Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button onClick={refreshData} variant="outline" className="w-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Data
              </Button>
              
              <Button onClick={clearAllErrors} variant="destructive" className="w-full">
                Clear All Errors
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Error Dashboard */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Live Error Dashboard
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-96 overflow-hidden">
                <ErrorDashboard className="h-full" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Usage Instructions */}
      <Alert className="mt-8">
        <TestTube className="h-4 w-4" />
        <AlertDescription>
          <strong>Usage Instructions:</strong> Use the test cases on the left to simulate different types of errors. 
          The dashboard on the right will update in real-time to show error reports, statistics, and analytics. 
          Create custom errors to test specific scenarios relevant to your application.
        </AlertDescription>
      </Alert>
    </div>);

};

export default ErrorTrackingTestPage;