
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import {
  Shield,
  Activity,
  Download,
  Settings,
  Search,
  Database,
  AlertTriangle,
  RefreshCw } from
'lucide-react';
import { AuditLog, AuditLogFilters } from '@/types/audit';
import AuditLogSearchFilter from '@/components/audit/AuditLogSearchFilter';
import AuditLogTable from '@/components/audit/AuditLogTable';
import AuditLogDetail from '@/components/audit/AuditLogDetail';
import AuditLogExport from '@/components/audit/AuditLogExport';
import RealTimeAuditDashboard from '@/components/audit/RealTimeAuditDashboard';
import AuditLogRetentionSettings from '@/components/audit/AuditLogRetentionSettings';

const AUDIT_LOGS_TABLE_ID = 37723; // audit_logs table

const AuditLogsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('logs');
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalLogs, setTotalLogs] = useState(0);
  const [filters, setFilters] = useState<AuditLogFilters>({});

  const pageSize = 50;

  const fetchAuditLogs = async (page: number = 1) => {
    setLoading(true);
    try {
      const queryFilters = [];

      if (filters.user_name) {
        queryFilters.push({ name: 'user_name', op: 'StringContains', value: filters.user_name });
      }
      if (filters.action) {
        queryFilters.push({ name: 'action', op: 'Equal', value: filters.action });
      }
      if (filters.table_name) {
        queryFilters.push({ name: 'table_name', op: 'Equal', value: filters.table_name });
      }
      if (filters.start_date) {
        queryFilters.push({ name: 'timestamp', op: 'GreaterThanOrEqual', value: filters.start_date });
      }
      if (filters.end_date) {
        queryFilters.push({ name: 'timestamp', op: 'LessThanOrEqual', value: filters.end_date });
      }
      if (filters.is_security_event !== undefined) {
        queryFilters.push({ name: 'is_security_event', op: 'Equal', value: filters.is_security_event });
      }

      const { data, error } = await window.ezsite.apis.tablePage(AUDIT_LOGS_TABLE_ID, {
        PageNo: page,
        PageSize: pageSize,
        OrderByField: 'timestamp',
        IsAsc: false,
        Filters: queryFilters
      });

      if (error) {
        console.error('[Route: /admin/audit] Error fetching audit logs:', error);
        throw new Error(error);
      }

      const transformedLogs: AuditLog[] = (data?.List || []).map((log: any) => ({
        id: log.id,
        user_id: log.user_id || 0,
        user_name: log.user_name || 'Anonymous',
        user_email: log.user_email || '',
        action: log.action || '',
        table_name: log.table_name || '',
        record_id: log.record_id || '',
        old_values: log.old_values || '',
        new_values: log.new_values || '',
        ip_address: log.ip_address || '',
        user_agent: log.user_agent || '',
        timestamp: log.timestamp || new Date().toISOString(),
        session_id: log.session_id || '',
        is_security_event: log.is_security_event || false,
        severity: log.severity || 'LOW',
        event_description: log.event_description || '',
        metadata: log.metadata || ''
      }));

      setLogs(transformedLogs);
      setTotalLogs(data?.VirtualCount || 0);
      setCurrentPage(page);
    } catch (error) {
      console.error('[Route: /admin/audit] Failed to fetch audit logs:', error);
      toast.error('Failed to fetch audit logs. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuditLogs(1);
  }, []);

  const handleSearch = () => {
    fetchAuditLogs(1);
  };

  const handleClearFilters = () => {
    setFilters({});
    setTimeout(() => fetchAuditLogs(1), 100);
  };

  const handleViewDetails = (log: AuditLog) => {
    setSelectedLog(log);
    setShowDetail(true);
  };

  const handleRefresh = () => {
    fetchAuditLogs(currentPage);
  };

  const getSecurityEventsCount = () => {
    return logs.filter((log) => log.is_security_event).length;
  };

  const getCriticalEventsCount = () => {
    return logs.filter((log) => log.severity === 'CRITICAL' || log.severity === 'HIGH').length;
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Audit Logs</h1>
          <p className="text-gray-600">
            Comprehensive audit logging and security monitoring system
          </p>
        </div>
        <div className="flex items-center gap-2">
          {getSecurityEventsCount() > 0 &&
          <Badge variant="destructive" className="animate-pulse">
              {getSecurityEventsCount()} Security Events
            </Badge>
          }
          {getCriticalEventsCount() > 0 &&
          <Badge variant="outline" className="border-orange-500 text-orange-600">
              {getCriticalEventsCount()} Critical Events
            </Badge>
          }
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Audit Logs
          </TabsTrigger>
          <TabsTrigger value="export" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        {/* Real-time Dashboard */}
        <TabsContent value="dashboard" className="space-y-6">
          <RealTimeAuditDashboard />
        </TabsContent>

        {/* Audit Logs */}
        <TabsContent value="logs" className="space-y-6">
          {/* Search Filters */}
          <AuditLogSearchFilter
            filters={filters}
            onFiltersChange={setFilters}
            onSearch={handleSearch}
            onClear={handleClearFilters} />


          {/* Results Summary */}
          <Card>
            <CardContent className="py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Database className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">
                      Showing {logs.length} of {totalLogs.toLocaleString()} logs
                    </span>
                  </div>
                  {getSecurityEventsCount() > 0 &&
                  <div className="flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      <span className="text-sm text-red-600">
                        {getSecurityEventsCount()} security events in current view
                      </span>
                    </div>
                  }
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('export')}>

                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Audit Logs Table */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Audit Log Results
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AuditLogTable
                logs={logs}
                onViewDetails={handleViewDetails}
                loading={loading} />


              {/* Pagination */}
              {totalLogs > pageSize &&
              <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-gray-500">
                    Page {currentPage} of {Math.ceil(totalLogs / pageSize)}
                  </div>
                  <div className="flex gap-2">
                    <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchAuditLogs(currentPage - 1)}
                    disabled={currentPage === 1 || loading}>

                      Previous
                    </Button>
                    <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchAuditLogs(currentPage + 1)}
                    disabled={currentPage >= Math.ceil(totalLogs / pageSize) || loading}>

                      Next
                    </Button>
                  </div>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        {/* Export */}
        <TabsContent value="export" className="space-y-6">
          <AuditLogExport logs={logs} filters={filters} />
        </TabsContent>

        {/* Settings */}
        <TabsContent value="settings" className="space-y-6">
          <AuditLogRetentionSettings />
        </TabsContent>
      </Tabs>

      {/* Log Detail Dialog */}
      <AuditLogDetail
        log={selectedLog}
        open={showDetail}
        onClose={() => {
          setShowDetail(false);
          setSelectedLog(null);
        }} />

    </div>);

};

export default AuditLogsPage;