
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Users,
  Shield,
  Activity,
  Server,
  Database,
  FileText,
  TrendingUp,
  AlertTriangle,
  RefreshCw,
  Eye,
  Bug } from
'lucide-react';
import { errorLoggingService } from '@/services/errorLoggingService';
import ErrorLogsPanel from '@/components/admin/ErrorLogsPanel';
import EnhancedErrorLogsPanel from '@/components/admin/EnhancedErrorLogsPanel';
import { toast } from 'sonner';

interface SystemStats {
  totalUsers: number;
  totalRoles: number;
  systemSettings: number;
  auditLogs: number;
  backupLogs: number;
  adminSessions: number;
}

interface RecentActivity {
  id: number;
  action: string;
  user: string;
  timestamp: string;
  type: 'success' | 'warning' | 'error';
}

const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<SystemStats>({
    totalUsers: 0,
    totalRoles: 0,
    systemSettings: 0,
    auditLogs: 0,
    backupLogs: 0,
    adminSessions: 0
  });
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [showErrorLogs, setShowErrorLogs] = useState(false);
  const [errorStats, setErrorStats] = useState({ total: 0, critical: 0, high: 0 });

  const fetchSystemStats = async () => {
    try {
      setIsLoading(true);

      // Fetch users count
      const { data: usersData, error: usersError } = await window.ezsite.apis.tablePage(37706, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      if (usersError) throw new Error(usersError);

      // Fetch roles count
      const { data: rolesData, error: rolesError } = await window.ezsite.apis.tablePage(37707, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      if (rolesError) throw new Error(rolesError);

      // Fetch system settings count
      const { data: settingsData, error: settingsError } = await window.ezsite.apis.tablePage(37722, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      // Fetch audit logs count
      const { data: auditData, error: auditError } = await window.ezsite.apis.tablePage(37723, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      // Fetch backup logs count
      const { data: backupData, error: backupError } = await window.ezsite.apis.tablePage(37724, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      // Fetch admin sessions count
      const { data: sessionsData, error: sessionsError } = await window.ezsite.apis.tablePage(37725, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      setStats({
        totalUsers: usersData?.VirtualCount || 0,
        totalRoles: rolesData?.VirtualCount || 0,
        systemSettings: settingsData?.VirtualCount || 0,
        auditLogs: auditData?.VirtualCount || 0,
        backupLogs: backupData?.VirtualCount || 0,
        adminSessions: sessionsData?.VirtualCount || 0
      });

      // Generate mock recent activity for demonstration
      setRecentActivity([
      {
        id: 1,
        action: 'User login',
        user: 'admin@example.com',
        timestamp: new Date(Date.now() - 300000).toISOString(),
        type: 'success'
      },
      {
        id: 2,
        action: 'System settings updated',
        user: 'admin@example.com',
        timestamp: new Date(Date.now() - 600000).toISOString(),
        type: 'warning'
      },
      {
        id: 3,
        action: 'New user registered',
        user: 'system',
        timestamp: new Date(Date.now() - 900000).toISOString(),
        type: 'success'
      }]
      );

      // Fetch error statistics
      const recentErrors = errorLoggingService.getRecentErrors(100);
      const criticalErrors = errorLoggingService.getErrorsBySeverity('critical');
      const highErrors = errorLoggingService.getErrorsBySeverity('high');

      setErrorStats({
        total: recentErrors.length,
        critical: criticalErrors.length,
        high: highErrors.length
      });

      setLastUpdated(new Date());
    } catch (error) {
      console.error('Error fetching system stats:', error);
      errorLoggingService.logError(error as Error, {
        severity: 'medium',
        context: { page: 'AdminDashboard', operation: 'fetchSystemStats' }
      });
      toast.error('Failed to load system statistics');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSystemStats();
  }, []);

  const handleRefresh = () => {
    fetchSystemStats();
    toast.success('Dashboard refreshed');
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString();
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <div className="w-2 h-2 bg-green-500 rounded-full" />;
      case 'warning':
        return <div className="w-2 h-2 bg-yellow-500 rounded-full" />;
      case 'error':
        return <div className="w-2 h-2 bg-red-500 rounded-full" />;
      default:
        return <div className="w-2 h-2 bg-gray-500 rounded-full" />;
    }
  };

  const statCards = [
  {
    title: 'Total Users',
    value: stats.totalUsers,
    icon: Users,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    change: '+12%',
    changeType: 'positive'
  },
  {
    title: 'Active Roles',
    value: stats.totalRoles,
    icon: Shield,
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    change: 'Stable',
    changeType: 'neutral'
  },
  {
    title: 'System Settings',
    value: stats.systemSettings,
    icon: Server,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    change: '2 updated',
    changeType: 'neutral'
  },
  {
    title: 'Audit Logs',
    value: stats.auditLogs,
    icon: FileText,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    change: '+45 today',
    changeType: 'positive'
  },
  {
    title: 'Backup Logs',
    value: stats.backupLogs,
    icon: Database,
    color: 'text-cyan-600',
    bgColor: 'bg-cyan-50',
    change: 'Last: 2h ago',
    changeType: 'neutral'
  },
  {
    title: 'Admin Sessions',
    value: stats.adminSessions,
    icon: Activity,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    change: '3 active',
    changeType: 'positive'
  },
  {
    title: 'Error Logs',
    value: errorStats.total,
    icon: Bug,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    change: `${errorStats.critical} critical`,
    changeType: errorStats.critical > 0 ? 'negative' : 'neutral'
  }];


  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600">System overview and management</p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="text-green-600 border-green-200">
            System Healthy
          </Badge>
          <Button
            onClick={handleRefresh}
            disabled={isLoading}
            variant="outline"
            size="sm"
            className="flex items-center space-x-2">

            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((stat, index) =>
        <Card key={stat.title} className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {stat.title}
              </CardTitle>
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">
                {isLoading ? '...' : stat.value.toLocaleString()}
              </div>
              <div className="flex items-center space-x-1 mt-1">
                <span className={`text-xs ${
              stat.changeType === 'positive' ? 'text-green-600' :
              stat.changeType === 'negative' ? 'text-red-600' : 'text-gray-500'}`
              }>
                  {stat.change}
                </span>
                {stat.changeType === 'positive' &&
              <TrendingUp className="h-3 w-3 text-green-600" />
              }
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Recent Activity & System Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-blue-600" />
              <span>Recent Activity</span>
            </CardTitle>
            <CardDescription>
              Latest system events and user actions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity) =>
              <div key={activity.id} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50">
                  {getActivityIcon(activity.type)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {activity.action}
                    </p>
                    <p className="text-xs text-gray-500">
                      by {activity.user} • {formatTime(activity.timestamp)}
                    </p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
            <Button variant="outline" className="w-full mt-4">
              View All Activity
            </Button>
          </CardContent>
        </Card>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Server className="h-5 w-5 text-green-600" />
              <span>System Status</span>
            </CardTitle>
            <CardDescription>
              Current system health and performance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Database</span>
                <Badge className="bg-green-100 text-green-800">Healthy</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">API Services</span>
                <Badge className="bg-green-100 text-green-800">Online</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">File Storage</span>
                <Badge className="bg-green-100 text-green-800">Available</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Backup System</span>
                <Badge className="bg-yellow-100 text-yellow-800">Warning</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Security</span>
                <Badge className="bg-green-100 text-green-800">Secure</Badge>
              </div>
            </div>
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-900">
                  Maintenance Notice
                </span>
              </div>
              <p className="text-xs text-blue-700 mt-1">
                Scheduled backup at 2:00 AM EST
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Error Logs Section */}
      {showErrorLogs &&
      <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Error Monitoring</h2>
            <Button
            variant="outline"
            onClick={() => setShowErrorLogs(false)}
            size="sm">

              Hide Error Logs
            </Button>
          </div>
          <EnhancedErrorLogsPanel />
        </div>
      }

      {/* Quick Error Summary */}
      {!showErrorLogs && errorStats.total > 0 &&
      <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-orange-800">
              <Bug className="h-5 w-5" />
              <span>Enhanced Error Summary</span>
            </CardTitle>
            <CardDescription className="text-orange-700">
              DevTools-enhanced error monitoring with detailed stack traces and component context
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{errorStats.total}</div>
                <div className="text-sm text-gray-600">Total Errors</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{errorStats.critical}</div>
                <div className="text-sm text-gray-600">Critical</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{errorStats.high}</div>
                <div className="text-sm text-gray-600">High Priority</div>
              </div>
            </div>
            <Button
            onClick={() => setShowErrorLogs(true)}
            className="w-full"
            variant={errorStats.critical > 0 ? "destructive" : "default"}>

              <Bug className="w-4 h-4 mr-2" />
              View Enhanced Error Logs
            </Button>
          </CardContent>
        </Card>
      }

      {/* Footer Info */}
      <Card className="bg-gradient-to-r from-gray-50 to-gray-100">
        <CardContent className="pt-6">
          <div className="text-center text-sm text-gray-600">
            <p>Last updated: {lastUpdated.toLocaleString()}</p>
            <p className="mt-1">Admin Panel v1.0 • NY FASHION HOUSE</p>
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default AdminDashboard;