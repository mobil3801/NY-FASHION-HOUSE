
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  TestTube,
  Activity,
  BarChart3,
  Settings,
  RefreshCw,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Shield,
  ShoppingCart,
  FileText,
  Zap,
  Database,
  Users,
  Lock,
  Search } from
'lucide-react';
import TestExecutionControls from '@/components/qa/TestExecutionControls';
import TestProgressIndicator from '@/components/qa/TestProgressIndicator';
import TestResultsDisplay from '@/components/qa/TestResultsDisplay';
import AutomatedTestRunner from '@/components/testing/AutomatedTestRunner';
import CriticalFlowTestManager from '@/components/testing/CriticalFlowTestManager';
import ComprehensiveTestDashboard from '@/components/testing/ComprehensiveTestDashboard';
import DataIntegrityTestResults from '@/components/testing/DataIntegrityTestResults';
import RolePermissionTestResults from '@/components/testing/RolePermissionTestResults';
import { testRegistryService } from '@/services/testRegistryService';
import { qaTestingService } from '@/services/qaTestingService';
import { comprehensiveTestManager } from '@/services/comprehensiveTestManager';
import { toast } from 'sonner';

const QADashboard: React.FC = () => {
  const [currentExecutionId, setCurrentExecutionId] = useState<number | undefined>();
  const [isExecutionActive, setIsExecutionActive] = useState(false);
  const [statistics, setStatistics] = useState<any>(null);
  const [comprehensiveTestResults, setComprehensiveTestResults] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const stats = await testRegistryService.getTestStatistics();
      setStatistics(stats);
    } catch (error) {
      toast.error('Failed to load dashboard data', {
        description: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      setLoading(false);
    }
  };

  const runComprehensiveTests = async () => {
    try {
      toast.info('Starting comprehensive tests...', {
        description: 'This will test data integrity, role permissions, and system health.'
      });

      const results = await comprehensiveTestManager.runComprehensiveTests();
      setComprehensiveTestResults(results);

      toast.success('Comprehensive tests completed!', {
        description: `${results.overallSummary.totalTests} tests executed with ${results.overallSummary.passRate.toFixed(1)}% pass rate.`
      });
    } catch (error) {
      toast.error('Comprehensive test failed', {
        description: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  };

  const handleExecutionStart = (executionId: number) => {
    setCurrentExecutionId(executionId);
    setIsExecutionActive(true);
    loadDashboardData();
  };

  const handleExecutionStop = () => {
    setIsExecutionActive(false);
    loadDashboardData();
  };

  const StatCard = ({ title, value, icon: Icon, description, color = "default" }: any) =>
  <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <div className="flex items-center gap-2">
              <p className="text-2xl font-bold">{value}</p>
              {color !== "default" &&
            <Badge variant="outline" className={`${color}`}>
                  <Icon className="w-3 h-3" />
                </Badge>
            }
            </div>
            {description &&
          <p className="text-xs text-gray-500 mt-1">{description}</p>
          }
          </div>
          <Icon className={`w-8 h-8 ${color === "default" ? "text-gray-400" : ""}`} />
        </div>
      </CardContent>
    </Card>;


  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-96">
          <div className="flex items-center gap-2">
            <RefreshCw className="w-6 h-6 animate-spin" />
            <span>Loading QA Dashboard...</span>
          </div>
        </div>
      </div>);

  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <TestTube className="w-8 h-8 text-blue-600" />
            QA Testing Dashboard
          </h1>
          <p className="text-gray-600 mt-2">
            Comprehensive testing framework for quality assurance and system validation
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={loadDashboardData} variant="outline" className="flex items-center gap-2">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
          <Button onClick={runComprehensiveTests} className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            Run Full Suite
          </Button>
        </div>
      </div>

      {/* Enhanced Testing Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card className="border-l-4 border-l-red-500">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-red-100 rounded-full">
                <Database className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Data Integrity</h3>
                <p className="text-sm text-gray-600">CRUD operations & validation</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge variant="outline">Create</Badge>
                  <Badge variant="outline">Read</Badge>
                  <Badge variant="outline">Update</Badge>
                  <Badge variant="outline">Delete</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-purple-100 rounded-full">
                <Lock className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Role Permissions</h3>
                <p className="text-sm text-gray-600">Access control validation</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge variant="outline">Admin</Badge>
                  <Badge variant="outline">Sales</Badge>
                  <Badge variant="outline">General</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-orange-100 rounded-full">
                <Zap className="h-6 w-6 text-orange-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Critical Flow Testing</h3>
                <p className="text-sm text-gray-600">Real validation of core flows</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge variant="outline">Authentication</Badge>
                  <Badge variant="outline">POS</Badge>
                  <Badge variant="outline">Reports</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-blue-100 rounded-full">
                <Shield className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Automated Test Suites</h3>
                <p className="text-sm text-gray-600">Comprehensive scenario coverage</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge variant="outline">Unit</Badge>
                  <Badge variant="outline">Integration</Badge>
                  <Badge variant="outline">Performance</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Statistics Cards */}
      {statistics &&
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
          title="Total Test Suites"
          value={statistics.totalSuites}
          icon={TestTube}
          description="Active test suites" />

          <StatCard
          title="Recent Executions"
          value={statistics.recentExecutions}
          icon={Activity}
          description="Last 50 executions" />

          <StatCard
          title="Pass Rate"
          value={`${statistics.passRate}%`}
          icon={statistics.passRate >= 80 ? CheckCircle2 : AlertTriangle}
          color={statistics.passRate >= 80 ? "text-green-600" : "text-yellow-600"}
          description="Overall success rate" />

          <StatCard
          title="Last Execution"
          value={statistics.lastExecution ? "Recent" : "None"}
          icon={Clock}
          description={statistics.lastExecution ?
          new Date(statistics.lastExecution).toLocaleDateString() :
          "No executions yet"
          } />

        </div>
      }

      {/* Comprehensive Test Results Summary */}
      {comprehensiveTestResults &&
      <Card className="border-l-4 border-l-green-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Latest Comprehensive Test Results
            </CardTitle>
            <CardDescription>
              Summary of the most recent comprehensive test execution
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{comprehensiveTestResults.overallSummary.passed}</div>
                <div className="text-sm text-gray-600">Passed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{comprehensiveTestResults.overallSummary.failed}</div>
                <div className="text-sm text-gray-600">Failed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-600">{comprehensiveTestResults.overallSummary.errors}</div>
                <div className="text-sm text-gray-600">Errors</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{comprehensiveTestResults.overallSummary.passRate.toFixed(1)}%</div>
                <div className="text-sm text-gray-600">Pass Rate</div>
              </div>
            </div>
            {comprehensiveTestResults.overallSummary.securityViolations > 0 &&
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded">
                <div className="flex items-center gap-2 text-red-800">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="font-medium">Security Alert</span>
                </div>
                <p className="text-red-700 text-sm mt-1">
                  {comprehensiveTestResults.overallSummary.securityViolations} security violations detected
                </p>
              </div>
          }
          </CardContent>
        </Card>
      }

      {/* Test Type Distribution */}
      {statistics?.suitesByType &&
      <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Test Suite Distribution
            </CardTitle>
            <CardDescription>
              Breakdown of test suites by type
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{statistics.suitesByType.unit}</div>
                <div className="text-sm text-blue-600">Unit Tests</div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{statistics.suitesByType.integration}</div>
                <div className="text-sm text-green-600">Integration Tests</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{statistics.suitesByType.performance}</div>
                <div className="text-sm text-purple-600">Performance Tests</div>
              </div>
              <div className="text-center p-4 bg-orange-50 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">{statistics.suitesByType.accessibility}</div>
                <div className="text-sm text-orange-600">Accessibility Tests</div>
              </div>
            </div>
          </CardContent>
        </Card>
      }

      {/* Main Content Tabs */}
      <Tabs defaultValue="comprehensive" className="space-y-6">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="comprehensive" className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            Comprehensive
          </TabsTrigger>
          <TabsTrigger value="critical-flows" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Critical Flows
          </TabsTrigger>
          <TabsTrigger value="automated" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Automated Tests
          </TabsTrigger>
          <TabsTrigger value="execute" className="flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Manual Tests
          </TabsTrigger>
          <TabsTrigger value="results" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Results
          </TabsTrigger>
          <TabsTrigger value="reports" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Reports
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        {/* Comprehensive Testing Tab */}
        <TabsContent value="comprehensive" className="space-y-6">
          <ComprehensiveTestDashboard />
        </TabsContent>

        {/* Critical Flow Tests Tab */}
        <TabsContent value="critical-flows" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-orange-500" />
                Critical Application Flow Testing
              </CardTitle>
              <CardDescription>
                Comprehensive testing of authentication, POS checkout, and reports functionality with real validation
              </CardDescription>
            </CardHeader>
          </Card>
          <CriticalFlowTestManager />
        </TabsContent>

        {/* Automated Tests Tab */}
        <TabsContent value="automated" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-500" />
                Automated Test Suites
              </CardTitle>
              <CardDescription>
                Automated test execution with comprehensive scenario coverage and detailed reporting
              </CardDescription>
            </CardHeader>
          </Card>
          <AutomatedTestRunner />
        </TabsContent>

        {/* Manual Execute Tests Tab */}
        <TabsContent value="execute" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TestExecutionControls
              onExecutionStart={handleExecutionStart}
              onExecutionStop={handleExecutionStop} />

            <TestProgressIndicator
              executionId={currentExecutionId}
              isActive={isExecutionActive} />

          </div>
          
          {currentExecutionId &&
          <TestResultsDisplay executionId={currentExecutionId} />
          }
        </TabsContent>

        {/* Results Tab */}
        <TabsContent value="results" className="space-y-6">
          <TestResultsDisplay showRecentResults={true} />
          
          {/* Show detailed test results if available */}
          {comprehensiveTestResults &&
          <div className="space-y-6">
              <Tabs defaultValue="data-integrity" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="data-integrity">Data Integrity</TabsTrigger>
                  <TabsTrigger value="role-permissions">Role Permissions</TabsTrigger>
                </TabsList>
                
                <TabsContent value="data-integrity">
                  <DataIntegrityTestResults
                  results={comprehensiveTestResults.testCategories.dataIntegrity.results} />

                </TabsContent>
                
                <TabsContent value="role-permissions">
                  <RolePermissionTestResults
                  results={comprehensiveTestResults.testCategories.rolePermissions.results} />

                </TabsContent>
              </Tabs>
            </div>
          }
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Test Framework Settings</CardTitle>
              <CardDescription>
                Configure your QA testing environment
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4">
                  <h3 className="font-semibold mb-2">Test Templates</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    Create test suites from predefined templates
                  </p>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testRegistryService.createSuiteFromTemplate('Frontend Unit Tests').then(() => {
                        toast.success('Unit test suite created');
                        loadDashboardData();
                      })}
                      className="w-full">

                      Create Unit Test Suite
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testRegistryService.createSuiteFromTemplate('API Integration Tests').then(() => {
                        toast.success('Integration test suite created');
                        loadDashboardData();
                      })}
                      className="w-full">

                      Create Integration Test Suite
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testRegistryService.createSuiteFromTemplate('Performance Tests').then(() => {
                        toast.success('Performance test suite created');
                        loadDashboardData();
                      })}
                      className="w-full">

                      Create Performance Test Suite
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testRegistryService.createSuiteFromTemplate('Accessibility Tests').then(() => {
                        toast.success('Accessibility test suite created');
                        loadDashboardData();
                      })}
                      className="w-full">

                      Create Accessibility Test Suite
                    </Button>
                  </div>
                </Card>

                <Card className="p-4">
                  <h3 className="font-semibold mb-2">Framework Info</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    QA testing framework information
                  </p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Version:</span>
                      <Badge variant="outline">2.0.0</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Test Types:</span>
                      <Badge variant="outline">6</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Comprehensive Testing:</span>
                      <Badge className="bg-green-100 text-green-800">Enabled</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                  </div>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};

export default QADashboard;