// Test page for demonstrating enhanced error handling (for development/testing only)
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  AlertTriangle,
  Bug,
  Network,
  Shield,
  Server,
  FileX,
  Zap,
  Database } from
'lucide-react';

import { useGlobalErrorHandler } from '@/hooks/useGlobalErrorHandler';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import ErrorReportButton from '@/components/enhanced/ErrorReportButton';
import EnhancedErrorBoundary from '@/components/enhanced/EnhancedErrorBoundary';
import { handleFormError } from '@/utils/enhancedGlobalErrorHandler';

// Component that deliberately throws errors for testing
const BuggyComponent: React.FC<{shouldThrow: boolean;errorType: string;}> = ({
  shouldThrow,
  errorType
}) => {
  if (shouldThrow) {
    switch (errorType) {
      case 'render':
        throw new Error('Deliberate render error for testing');
      case 'type':
        throw new TypeError('Type error in component');
      case 'reference':
        throw new ReferenceError('Reference error in component');
      default:
        throw new Error('Generic component error');
    }
  }

  return (
    <div className="p-4 border border-green-200 bg-green-50 rounded">
      <p className="text-green-800">Component rendered successfully ✓</p>
    </div>);

};

const ErrorTestPage: React.FC = () => {
  const [errorLogs, setErrorLogs] = useState<string[]>([]);
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [buggyComponent, setBuggyComponent] = useState({ show: false, type: 'render' });

  const { handleError, handleAsyncError, createErrorHandler } = useGlobalErrorHandler({
    showToast: true,
    context: {
      component: 'ErrorTestPage',
      route: '/error-test'
    }
  });

  // Different types of errors to demonstrate
  const triggerNetworkError = () => {
    const error = new Error('Network connection lost');
    const correlationId = handleError(error, {
      title: 'Network Error Test',
      action: 'Test network error simulation',
      category: 'network',
      severity: 'medium'
    });
    setErrorLogs((prev) => [...prev, correlationId]);
  };

  const triggerValidationError = () => {
    const error = new Error('Required field missing: email');
    const correlationId = handleError(error, {
      title: 'Validation Error Test',
      action: 'Form validation test',
      category: 'validation',
      severity: 'low',
      userInputs: formData
    });
    setErrorLogs((prev) => [...prev, correlationId]);
  };

  const triggerAuthError = () => {
    const error = new Error('User session expired');
    const correlationId = handleError(error, {
      title: 'Authentication Error Test',
      action: 'Session validation test',
      category: 'authentication',
      severity: 'high'
    });
    setErrorLogs((prev) => [...prev, correlationId]);
  };

  const triggerServerError = () => {
    const error = new Error('Internal server error (500)');
    const correlationId = handleError(error, {
      title: 'Server Error Test',
      action: 'API call simulation',
      category: 'server',
      severity: 'high',
      requestDetails: {
        url: '/api/test',
        method: 'POST',
        body: { test: 'data' }
      }
    });
    setErrorLogs((prev) => [...prev, correlationId]);
  };

  const triggerCriticalError = () => {
    const error = new Error('Critical system failure - database corruption detected');
    const correlationId = handleError(error, {
      title: 'Critical System Error',
      action: 'Database operation',
      category: 'server',
      severity: 'critical'
    });
    setErrorLogs((prev) => [...prev, correlationId]);
  };

  const triggerAsyncError = async () => {
    const result = await handleAsyncError(
      async () => {
        throw new Error('Async operation failed');
      },
      {
        title: 'Async Error Test',
        action: 'Async operation simulation',
        severity: 'medium'
      }
    );

    if (!result) {
      const stats = enhancedErrorLoggingService.getErrorStatistics();
      const latestErrorId = Object.keys(stats).length > 0 ?
      enhancedErrorLoggingService.getErrorReports(1)[0]?.correlationId : null;

      if (latestErrorId) {
        setErrorLogs((prev) => [...prev, latestErrorId]);
      }
    }
  };

  const triggerPromiseRejection = () => {
    // This will be caught by the global unhandled rejection handler
    Promise.reject(new Error('Unhandled promise rejection test'));
  };

  const triggerFormError = () => {
    const error = new Error('Form submission failed - invalid data');
    const correlationId = handleFormError(
      error,
      formData,
      'Submit test form',
      {
        title: 'Form Submission Error',
        severity: 'medium'
      }
    );
    setErrorLogs((prev) => [...prev, correlationId]);
  };

  const triggerComponentError = (type: string) => {
    setBuggyComponent({ show: true, type });
  };

  const resetBuggyComponent = () => {
    setBuggyComponent({ show: false, type: 'render' });
  };

  const clearErrorLogs = () => {
    setErrorLogs([]);
    enhancedErrorLoggingService.clearAllErrors();
  };

  const stats = enhancedErrorLoggingService.getErrorStatistics();

  // Only show this page in development
  if (process.env.NODE_ENV !== 'development') {
    return (
      <Card className="max-w-2xl mx-auto mt-8">
        <CardHeader>
          <CardTitle>Error Testing</CardTitle>
          <CardDescription>
            This page is only available in development mode.
          </CardDescription>
        </CardHeader>
      </Card>);

  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">Enhanced Error Handling System</h1>
        <p className="text-gray-600">
          This page demonstrates the comprehensive error reporting system
        </p>
      </div>

      {/* Error Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Error Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{stats.total}</div>
              <div className="text-sm text-gray-500">Total Errors</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{stats.recent}</div>
              <div className="text-sm text-gray-500">Recent (1h)</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.resolved}</div>
              <div className="text-sm text-gray-500">Resolved</div>
            </div>
            <div className="text-center">
              <Badge variant="outline">{stats.sessionId.slice(-8)}</Badge>
              <div className="text-sm text-gray-500">Session</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Error Trigger Buttons */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bug className="w-5 h-5" />
            Error Simulation
          </CardTitle>
          <CardDescription>
            Click these buttons to simulate different types of errors
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <Button
              variant="outline"
              onClick={triggerNetworkError}
              className="flex items-center gap-2 justify-start">

              <Network className="w-4 h-4" />
              Network Error
            </Button>
            
            <Button
              variant="outline"
              onClick={triggerValidationError}
              className="flex items-center gap-2 justify-start">

              <AlertTriangle className="w-4 h-4" />
              Validation Error
            </Button>
            
            <Button
              variant="outline"
              onClick={triggerAuthError}
              className="flex items-center gap-2 justify-start">

              <Shield className="w-4 h-4" />
              Auth Error
            </Button>
            
            <Button
              variant="outline"
              onClick={triggerServerError}
              className="flex items-center gap-2 justify-start">

              <Server className="w-4 h-4" />
              Server Error
            </Button>
            
            <Button
              variant="outline"
              onClick={triggerCriticalError}
              className="flex items-center gap-2 justify-start">

              <Zap className="w-4 h-4" />
              Critical Error
            </Button>
            
            <Button
              variant="outline"
              onClick={triggerAsyncError}
              className="flex items-center gap-2 justify-start">

              <FileX className="w-4 h-4" />
              Async Error
            </Button>
          </div>
          
          <div className="mt-4 flex gap-2">
            <Button variant="outline" onClick={triggerPromiseRejection}>
              Promise Rejection
            </Button>
            <Button variant="outline" onClick={triggerFormError}>
              Form Error
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Form Testing */}
      <Card>
        <CardHeader>
          <CardTitle>Form Error Testing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
              placeholder="Enter name" />

          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
              placeholder="Enter email" />

          </div>
        </CardContent>
      </Card>

      {/* Component Error Testing */}
      <Card>
        <CardHeader>
          <CardTitle>Component Error Testing</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => triggerComponentError('render')}>

              Render Error
            </Button>
            <Button
              variant="outline"
              onClick={() => triggerComponentError('type')}>

              Type Error
            </Button>
            <Button
              variant="outline"
              onClick={() => triggerComponentError('reference')}>

              Reference Error
            </Button>
            <Button
              variant="outline"
              onClick={resetBuggyComponent}>

              Reset
            </Button>
          </div>

          <EnhancedErrorBoundary
            level="component"
            component="BuggyTestComponent"
            action="Component error testing">

            <BuggyComponent
              shouldThrow={buggyComponent.show}
              errorType={buggyComponent.type} />

          </EnhancedErrorBoundary>
        </CardContent>
      </Card>

      {/* Error Log Display */}
      {errorLogs.length > 0 &&
      <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Recent Error Reports
              <Button variant="outline" size="sm" onClick={clearErrorLogs}>
                Clear
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {errorLogs.slice(-5).map((correlationId) =>
            <div key={correlationId} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <code className="text-sm font-mono">{correlationId}</code>
                  <ErrorReportButton
                correlationId={correlationId}
                size="sm" />

                </div>
            )}
            </div>
          </CardContent>
        </Card>
      }

      {process.env.NODE_ENV === 'development' &&
      <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            This error testing page is only available in development mode. 
            All errors are simulated for testing the error handling system.
          </AlertDescription>
        </Alert>
      }
    </div>);

};

export default ErrorTestPage;