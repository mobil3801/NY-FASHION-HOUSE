import { useState, useEffect, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Users } from "lucide-react";
import { toast } from "sonner";

import CustomerStats from "@/components/CustomerStats";
import SearchFilter from "@/components/SearchFilter";
import CustomerList from "@/components/CustomerList";
import CustomerForm from "@/components/CustomerForm";
import CustomerDetails from "@/components/CustomerDetails";

import { Customer, CustomerFilters } from "@/types/customer";
import {
  getCustomers,
  createCustomer,
  updateCustomer,
  deleteCustomer } from
"@/services/customerService";

const CustomerManagementPage = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [filters, setFilters] = useState<CustomerFilters>({
    search: '',
    status: 'all',
    sortBy: 'name',
    sortOrder: 'asc'
  });

  // Load customers on mount
  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      setIsLoading(true);
      const data = await getCustomers();
      setCustomers(data);
    } catch (error) {
      toast.error('Failed to load customers');
      console.error('Failed to load customers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Filter and sort customers
  const filteredAndSortedCustomers = useMemo(() => {
    let filtered = customers;

    // Apply search filter
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      filtered = filtered.filter((customer) =>
      customer.name.toLowerCase().includes(searchTerm) ||
      customer.email.toLowerCase().includes(searchTerm) ||
      customer.phone.toLowerCase().includes(searchTerm)
      );
    }

    // Apply status filter
    if (filters.status !== 'all') {
      filtered = filtered.filter((customer) => customer.status === filters.status);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue: any = a[filters.sortBy];
      let bValue: any = b[filters.sortBy];

      // Handle different data types
      if (filters.sortBy === 'createdAt' || filters.sortBy === 'lastPurchase') {
        aValue = new Date(aValue || 0);
        bValue = new Date(bValue || 0);
      } else if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (aValue < bValue) return filters.sortOrder === 'asc' ? -1 : 1;
      if (aValue > bValue) return filters.sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    return filtered;
  }, [customers, filters]);

  const handleAddCustomer = () => {
    setSelectedCustomer(null);
    setIsFormOpen(true);
  };

  const handleEditCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsFormOpen(true);
  };

  const handleViewCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsDetailsOpen(true);
  };

  const handleDeleteCustomer = async (customerId: string) => {
    try {
      await deleteCustomer(customerId);
      setCustomers((prev) => prev.filter((c) => c.id !== customerId));
      toast.success('Customer deleted successfully');
    } catch (error) {
      toast.error('Failed to delete customer');
      console.error('Failed to delete customer:', error);
    }
  };

  const handleFormSubmit = async (customerData: Omit<Customer, 'id' | 'createdAt' | 'totalPurchases' | 'totalSpent'>) => {
    try {
      setIsSubmitting(true);

      if (selectedCustomer) {
        // Update existing customer
        const updatedCustomer = await updateCustomer(selectedCustomer.id, customerData);
        setCustomers((prev) => prev.map((c) => c.id === selectedCustomer.id ? updatedCustomer : c));
        toast.success('Customer updated successfully');
      } else {
        // Create new customer
        const newCustomer = await createCustomer(customerData);
        setCustomers((prev) => [...prev, newCustomer]);
        toast.success('Customer created successfully');
      }

      setIsFormOpen(false);
    } catch (error) {
      toast.error(selectedCustomer ? 'Failed to update customer' : 'Failed to create customer');
      console.error('Form submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExport = () => {
    // Create CSV data
    const csvData = filteredAndSortedCustomers.map((customer) => ({
      Name: customer.name,
      Email: customer.email,
      Phone: customer.phone,
      Address: customer.address,
      Status: customer.status,
      'Total Spent': customer.totalSpent,
      'Total Orders': customer.totalPurchases,
      'Created At': new Date(customer.createdAt).toLocaleDateString(),
      'Last Purchase': customer.lastPurchase ? new Date(customer.lastPurchase).toLocaleDateString() : 'Never',
      Notes: customer.notes || ''
    }));

    // Convert to CSV string
    const headers = Object.keys(csvData[0] || {});
    const csvContent = [
    headers.join(','),
    ...csvData.map((row) => headers.map((header) => `"${row[header]}"`).join(','))].
    join('\n');

    // Download file
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `customers-export-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    toast.success('Customer data exported successfully');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Customer Management</h1>
          <p className="text-muted-foreground">
            Manage your customers, track purchase history, and analyze customer data
          </p>
        </div>
        <Button onClick={handleAddCustomer} className="shrink-0">
          <Plus className="mr-2 h-4 w-4" />
          Add Customer
        </Button>
      </div>

      {/* Statistics */}
      <CustomerStats customers={customers} />

      {/* Search and Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Customer Database ({filteredAndSortedCustomers.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <SearchFilter
            filters={filters}
            onFiltersChange={setFilters}
            onExport={handleExport} />

          
          {/* Customer List */}
          <CustomerList
            customers={filteredAndSortedCustomers}
            onEdit={handleEditCustomer}
            onDelete={handleDeleteCustomer}
            onView={handleViewCustomer}
            isLoading={isLoading} />

        </CardContent>
      </Card>

      {/* Add/Edit Customer Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {selectedCustomer ? 'Edit Customer' : 'Add New Customer'}
            </DialogTitle>
          </DialogHeader>
          <CustomerForm
            customer={selectedCustomer || undefined}
            onSubmit={handleFormSubmit}
            onCancel={() => setIsFormOpen(false)}
            isLoading={isSubmitting} />

        </DialogContent>
      </Dialog>

      {/* Customer Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedCustomer?.name} - Customer Details
            </DialogTitle>
          </DialogHeader>
          {selectedCustomer && <CustomerDetails customer={selectedCustomer} />}
        </DialogContent>
      </Dialog>
    </div>);

};

export default CustomerManagementPage;