
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, Database, TrendingUp, AlertTriangle, Download, Upload } from 'lucide-react';
import { toast } from 'sonner';

import UnifiedDataTable from '@/components/data-management/UnifiedDataTable';
import DataStatistics from '@/components/data-management/DataStatistics';
import BulkOperations from '@/components/data-management/BulkOperations';
import ImportExportManager from '@/components/data-management/ImportExportManager';
import DataValidationTools from '@/components/data-management/DataValidationTools';
import AuditLogViewer from '@/components/data-management/AuditLogViewer';

import { Customer } from '@/types/customer';
import { Product } from '@/types/product';
import { Employee } from '@/types/employee';
import { Invoice } from '@/types/invoice';
import { Sale } from '@/types/sales';

interface DataManagementPageProps {}

const DataManagementPage: React.FC<DataManagementPageProps> = () => {
  const [activeTab, setActiveTab] = useState('customers');
  const [selectedItems, setSelectedItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Check if user is admin
  useEffect(() => {
    const checkAdminAccess = async () => {
      try {
        const { data: userInfo, error } = await window.ezsite.apis.getUserInfo();
        if (error) throw new Error(error);

        if (!userInfo?.Roles?.includes('Administrator')) {
          toast.error('Access denied. Administrator privileges required.');
          // Redirect to home page or show access denied
          window.location.href = '/';
          return;
        }
      } catch (error) {
        console.error('Error checking admin access:', error);
        toast.error('Authentication error');
        window.location.href = '/';
      }
    };

    checkAdminAccess();
  }, []);

  const entityConfigs = [
  {
    key: 'customers',
    title: 'Customers',
    description: 'Customer records and contact information',
    icon: '👥',
    color: 'blue'
  },
  {
    key: 'products',
    title: 'Products',
    description: 'Product catalog and inventory data',
    icon: '📦',
    color: 'green'
  },
  {
    key: 'employees',
    title: 'Employees',
    description: 'Employee records and HR information',
    icon: '👨‍💼',
    color: 'purple'
  },
  {
    key: 'suppliers',
    title: 'Suppliers',
    description: 'Supplier and vendor information',
    icon: '🏢',
    color: 'orange'
  },
  {
    key: 'invoices',
    title: 'Invoices',
    description: 'Invoice and billing records',
    icon: '📄',
    color: 'red'
  },
  {
    key: 'sales',
    title: 'Sales',
    description: 'Sales transactions and POS data',
    icon: '💰',
    color: 'yellow'
  },
  {
    key: 'accounting',
    title: 'Accounting',
    description: 'Financial records and transactions',
    icon: '📊',
    color: 'indigo'
  },
  {
    key: 'audit',
    title: 'Audit Logs',
    description: 'System audit trails and operation logs',
    icon: '📋',
    color: 'gray'
  }];


  const handleBulkAction = async (action: string, items: any[]) => {
    try {
      setIsLoading(true);

      // Log the operation
      const operationData = {
        operation_type: action,
        entity_type: activeTab,
        entity_ids: items.map((item) => item.id || item.ID).join(','),
        operation_details: JSON.stringify({ action, itemCount: items.length }),
        user_id: 0, // Will be filled by backend
        user_email: '', // Will be filled by backend
        timestamp: new Date().toISOString(),
        status: 'pending',
        error_message: ''
      };

      const { error: logError } = await window.ezsite.apis.tableCreate(
        'data_operations',
        operationData
      );

      if (logError) {
        console.warn('Failed to log operation:', logError);
      }

      toast.success(`${action} operation completed for ${items.length} items`);
      setSelectedItems([]);
    } catch (error) {
      console.error('Bulk action error:', error);
      toast.error(`Failed to perform ${action} operation`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <Database className="h-8 w-8 text-blue-600" />
              Data Management
            </h1>
            <p className="text-gray-600 mt-1">
              Unified interface for managing all system data
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="flex items-center gap-1">
              <Shield className="h-3 w-3" />
              Admin Only
            </Badge>
          </div>
        </div>

        {/* Statistics Overview */}
        <DataStatistics />

        {/* Main Content */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Entity Management</CardTitle>
                <CardDescription>
                  Select an entity type to manage its data
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <ImportExportManager
                  entityType={activeTab}
                  onImportComplete={() => toast.success('Import completed successfully')} />

              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
                {entityConfigs.map((config) =>
                <TabsTrigger
                  key={config.key}
                  value={config.key}
                  className="flex items-center gap-1 text-xs">

                    <span>{config.icon}</span>
                    <span className="hidden lg:inline">{config.title}</span>
                  </TabsTrigger>
                )}
              </TabsList>

              {entityConfigs.slice(0, -1).map((config) =>
              <TabsContent key={config.key} value={config.key} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <span className="text-2xl">{config.icon}</span>
                        {config.title} Management
                      </h3>
                      <p className="text-gray-600 text-sm">{config.description}</p>
                    </div>
                    <BulkOperations
                    entityType={config.key}
                    selectedItems={selectedItems}
                    onAction={handleBulkAction}
                    isLoading={isLoading} />

                  </div>

                  <UnifiedDataTable
                  entityType={config.key}
                  onSelectionChange={setSelectedItems}
                  selectedItems={selectedItems} />

                </TabsContent>
              )}

              {/* Audit Logs Tab */}
              <TabsContent value="audit" className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <span className="text-2xl">📋</span>
                    Audit Logs
                  </h3>
                  <p className="text-gray-600 text-sm">
                    System audit trails and operation logs
                  </p>
                </div>
                <AuditLogViewer />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Data Validation Tools */}
        <DataValidationTools />
      </div>
    </div>);

};

export default DataManagementPage;