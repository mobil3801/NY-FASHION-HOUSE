
import { useState } from 'react';
import { Account, JournalEntry, TransactionSearchFilters } from '@/types/accounting';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, BookOpen, BarChart3, Calculator, FileText } from 'lucide-react';
import { toast } from 'sonner';

import ChartOfAccounts from '@/components/accounting/ChartOfAccounts';
import AccountForm from '@/components/accounting/AccountForm';
import JournalEntryForm from '@/components/accounting/JournalEntryForm';
import TransactionList from '@/components/accounting/TransactionList';
import TransactionSearchFilter from '@/components/accounting/TransactionSearchFilter';
import FinancialReports from '@/components/accounting/FinancialReports';
import FinancialDashboard from '@/components/accounting/FinancialDashboard';

const AccountingPage = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [showAccountForm, setShowAccountForm] = useState(false);
  const [showJournalForm, setShowJournalForm] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  const [transactionFilters, setTransactionFilters] = useState<TransactionSearchFilters>({});

  const handleAccountSave = (account: Account) => {
    setShowAccountForm(false);
    setSelectedAccount(null);
    toast.success('Account saved successfully');
  };

  const handleJournalEntrySave = (entry: JournalEntry) => {
    setShowJournalForm(false);
    toast.success('Journal entry created successfully');
  };

  const handleAccountSelect = (account: Account) => {
    setSelectedAccount(account);
    setActiveTab('transactions');
    setTransactionFilters({ accountId: account.id });
  };

  const handleEditAccount = (account: Account) => {
    setSelectedAccount(account);
    setShowAccountForm(true);
  };

  const stats = [
  { label: 'Total Accounts', value: '16', icon: BookOpen, color: 'text-blue-600' },
  { label: 'This Month Transactions', value: '0', icon: FileText, color: 'text-green-600' },
  { label: 'Monthly Revenue', value: '$0', icon: BarChart3, color: 'text-purple-600' },
  { label: 'Monthly Expenses', value: '$0', icon: Calculator, color: 'text-red-600' }];


  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Accounting & Finance</h1>
          <p className="text-muted-foreground">
            Comprehensive financial management and reporting
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowAccountForm(true)} variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Account
          </Button>
          <Button onClick={() => setShowJournalForm(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Entry
          </Button>
        </div>
      </div>

      {/* Financial Dashboard */}
      <FinancialDashboard />

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="accounts">Chart of Accounts</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Transactions */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Recent Transactions</h3>
              <TransactionList
                filters={{
                  startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                  endDate: new Date().toISOString().split('T')[0]
                }} />

            </div>

            {/* Quick Actions */}
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                <div className="grid grid-cols-1 gap-3">
                  <Button onClick={() => setShowJournalForm(true)} className="justify-start">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Journal Entry
                  </Button>
                  <Button onClick={() => setShowAccountForm(true)} variant="outline" className="justify-start">
                    <Plus className="w-4 h-4 mr-2" />
                    Add New Account
                  </Button>
                  <Button onClick={() => setActiveTab('reports')} variant="outline" className="justify-start">
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Generate Reports
                  </Button>
                </div>
              </div>

              {/* Account Summary */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Account Categories</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded">
                    <span>Assets</span>
                    <Badge variant="outline">4 accounts</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded">
                    <span>Liabilities</span>
                    <Badge variant="outline">3 accounts</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded">
                    <span>Equity</span>
                    <Badge variant="outline">2 accounts</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-purple-50 rounded">
                    <span>Income</span>
                    <Badge variant="outline">2 accounts</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-orange-50 rounded">
                    <span>Expenses</span>
                    <Badge variant="outline">5 accounts</Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="accounts">
          <ChartOfAccounts
            onAccountSelect={handleAccountSelect}
            onAddAccount={() => setShowAccountForm(true)}
            onEditAccount={handleEditAccount} />

        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <TransactionSearchFilter
            onFiltersChange={setTransactionFilters}
            initialFilters={transactionFilters} />

          <TransactionList filters={transactionFilters} />
        </TabsContent>

        <TabsContent value="reports">
          <FinancialReports />
        </TabsContent>
      </Tabs>

      {/* Account Form Dialog */}
      <Dialog open={showAccountForm} onOpenChange={setShowAccountForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedAccount ? 'Edit Account' : 'Create New Account'}
            </DialogTitle>
          </DialogHeader>
          <AccountForm
            account={selectedAccount}
            onSave={handleAccountSave}
            onCancel={() => {
              setShowAccountForm(false);
              setSelectedAccount(null);
            }} />

        </DialogContent>
      </Dialog>

      {/* Journal Entry Form Dialog */}
      <Dialog open={showJournalForm} onOpenChange={setShowJournalForm}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Journal Entry</DialogTitle>
          </DialogHeader>
          <JournalEntryForm
            onSave={handleJournalEntrySave}
            onCancel={() => setShowJournalForm(false)} />

        </DialogContent>
      </Dialog>
    </div>);

};

export default AccountingPage;