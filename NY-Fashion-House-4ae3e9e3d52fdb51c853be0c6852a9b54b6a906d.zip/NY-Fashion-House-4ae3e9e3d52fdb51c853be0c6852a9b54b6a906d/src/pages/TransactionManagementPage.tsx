import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DatePickerWithRange } from '@/components/ui/date-picker';
import { FileText, BarChart3, Search, Filter, RefreshCw, Plus, Calendar, DollarSign } from 'lucide-react';
import { format } from 'date-fns';
import { DateRange } from 'react-day-picker';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorDisplay from '@/components/ErrorDisplay';
import TransactionList from '@/components/transaction/TransactionList';
import SalesSummaryCard from '@/components/transaction/SalesSummaryCard';
import InvoiceReprintDialog from '@/components/transaction/InvoiceReprintDialog';
import ReturnAdjustmentDialog from '@/components/transaction/ReturnAdjustmentDialog';
import { useTransactionData } from '@/hooks/useTransactionData';
import { toast } from '@/hooks/use-toast';

interface Transaction {
  id: number;
  product_id?: number;
  product_name?: string;
  quantity_sold?: number;
  unit_price?: number;
  total_amount: number;
  sale_date?: string;
  employee_id?: number;
  employee_name?: string;
  notes?: string;
}

const TransactionManagementPage: React.FC = () => {
  const {
    transactions,
    invoices,
    dailySummary,
    isLoading,
    error,
    refetch
  } = useTransactionData();

  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [showFilters, setShowFilters] = useState(false);

  // Dialog states
  const [printDialogOpen, setPrintDialogOpen] = useState(false);
  const [returnDialogOpen, setReturnDialogOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  // Filter transactions based on search and filters
  const filteredTransactions = React.useMemo(() => {
    let filtered = transactions;

    // Search filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter((transaction) =>
      transaction.product_name?.toLowerCase().includes(term) ||
      transaction.employee_name?.toLowerCase().includes(term) ||
      transaction.notes?.toLowerCase().includes(term) ||
      transaction.id.toString().includes(term)
      );
    }

    // Date range filter
    if (dateRange?.from) {
      filtered = filtered.filter((transaction) => {
        if (!transaction.sale_date) return false;
        const transactionDate = new Date(transaction.sale_date);
        const fromDate = dateRange.from!;
        const toDate = dateRange.to || fromDate;

        return transactionDate >= fromDate && transactionDate <= toDate;
      });
    }

    return filtered;
  }, [transactions, searchTerm, dateRange]);

  const handlePrintTransaction = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setPrintDialogOpen(true);
  };

  const handleReturnTransaction = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setReturnDialogOpen(true);
  };

  const handleReturnSuccess = () => {
    toast({
      title: "Return processed successfully",
      description: "The return has been processed and recorded."
    });
    refetch(); // Refresh the data
  };

  const handleDeleteTransaction = async (transaction: Transaction) => {
    try {
      // Determine table ID based on transaction type
      const tableId = transaction.invoice_number ? 38565 : 38156; // 38565 for invoices, 38156 for sales_transactions

      const { error } = await window.ezsite.apis.tableDelete(tableId, { ID: transaction.id });

      if (error) {
        throw new Error(error);
      }

      toast({
        title: "Success",
        description: `${transaction.invoice_number ? 'Invoice' : 'Transaction'} deleted successfully`
      });

      refetch(); // Refresh the data
    } catch (error) {
      console.error('Error deleting transaction:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      toast({
        title: "Error",
        description: `Failed to delete ${transaction.invoice_number ? 'invoice' : 'transaction'}: ${errorMessage}`,
        variant: "destructive"
      });
      throw error; // Re-throw to let the component handle it
    }
  };

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setDateRange(undefined);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <LoadingSpinner message="Loading transaction management..." />
      </div>);

  }

  if (error) {
    return (
      <div className="p-6">
        <ErrorDisplay
          message={`Failed to load transactions: ${error}`}
          onRetry={refetch} />

      </div>);

  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">Transaction Management</h1>
          <p className="text-muted-foreground mt-1">
            Comprehensive transaction tracking and management system
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2">

            <Filter className="h-4 w-4" />
            {showFilters ? 'Hide Filters' : 'Show Filters'}
          </Button>
          <Button
            variant="outline"
            onClick={refetch}
            className="flex items-center gap-2">

            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Filters */}
      {showFilters &&
      <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Search Transactions</label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                  placeholder="Search products, employees, notes..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9" />

                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Status</label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Transactions</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="returned">Returned</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Date Range</label>
                <DatePickerWithRange
                date={dateRange}
                setDate={setDateRange}
                placeholder="Select date range" />

              </div>

              <div className="space-y-2 flex items-end">
                <Button
                variant="outline"
                onClick={clearFilters}
                className="w-full">

                  Clear Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      }

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <SalesSummaryCard
          title="Today's Sales"
          value={dailySummary.today}
          icon={<DollarSign className="h-4 w-4" />}
          trend={dailySummary.todayTrend} />

        <SalesSummaryCard
          title="This Week"
          value={dailySummary.week}
          icon={<BarChart3 className="h-4 w-4" />}
          trend={dailySummary.weekTrend} />

        <SalesSummaryCard
          title="This Month"
          value={dailySummary.month}
          icon={<Calendar className="h-4 w-4" />}
          trend={dailySummary.monthTrend} />

      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="transactions" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            All Transactions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="space-y-6">
            {/* Recent Transactions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Recent Transactions
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('transactions')}>

                    View All
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <TransactionList
                  transactions={filteredTransactions.slice(0, 5)}
                  onPrint={handlePrintTransaction}
                  onReturn={handleReturnTransaction}
                  onDelete={handleDeleteTransaction}
                  isInvoiceView={false} />

              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="transactions">
          <TransactionList
            transactions={filteredTransactions}
            onPrint={handlePrintTransaction}
            onReturn={handleReturnTransaction}
            onDelete={handleDeleteTransaction}
            isInvoiceView={false} />

        </TabsContent>
      </Tabs>

      {/* Print Dialog */}
      <InvoiceReprintDialog
        open={printDialogOpen}
        onClose={() => {
          setPrintDialogOpen(false);
          setSelectedTransaction(null);
        }}
        transaction={selectedTransaction} />


      {/* Return/Adjustment Dialog */}
      <ReturnAdjustmentDialog
        open={returnDialogOpen}
        onClose={() => {
          setReturnDialogOpen(false);
          setSelectedTransaction(null);
        }}
        transaction={selectedTransaction}
        onSuccess={handleReturnSuccess} />

    </div>);

};

export default TransactionManagementPage;