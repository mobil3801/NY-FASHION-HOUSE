import React from 'react';
import AdminLayout from '@/components/admin/AdminLayout';
import InvoiceManagement from '@/components/invoice/InvoiceManagement';

const InvoiceManagementPage: React.FC = () => {
  return (
    <AdminLayout>
      <InvoiceManagement />
    </AdminLayout>);

};

export default InvoiceManagementPage;