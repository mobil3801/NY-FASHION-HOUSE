
import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { UserPlus, Users, UserCheck, UserX, Shield } from 'lucide-react';
import UserSearchFilter from '@/components/UserSearchFilter';
import UserForm from '@/components/UserForm';
import UserList from '@/components/UserList';
import { User, Role, UserFormData, UserSearchFilters } from '@/types/user';
import { toast } from 'sonner';

interface UserStats {
  total: number;
  active: number;
  inactive: number;
  admins: number;
}

const USERS_TABLE_ID = 37706; // easysite_auth_users table
const ROLES_TABLE_ID = 37707; // easysite_roles table

const UserManagementPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [userFormOpen, setUserFormOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [formLoading, setFormLoading] = useState(false);
  const [currentUser, setCurrentUser] = useState<{ID: number;Email: string;Name?: string;} | null>(null);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [pageSize] = useState(20);

  // Search and filter state
  const [filters, setFilters] = useState<UserSearchFilters>({ search: '' });

  // Delete confirmation state
  const [deleteConfirm, setDeleteConfirm] = useState<{
    open: boolean;
    userId: number | null;
  }>({ open: false, userId: null });

  // User stats
  const [userStats, setUserStats] = useState<UserStats>({
    total: 0,
    active: 0,
    inactive: 0,
    admins: 0
  });

  // Get current user info
  useEffect(() => {
    const getCurrentUser = async () => {
      try {
        const { data, error } = await window.ezsite.apis.getUserInfo();
        if (error) {
          console.error('[Route: /admin/users] Error getting current user:', error);
          return;
        }
        setCurrentUser(data);
      } catch (error) {
        console.error('[Route: /admin/users] Error getting current user:', error);
      }
    };

    getCurrentUser();
  }, []);

  // Load roles
  const loadRoles = useCallback(async () => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(ROLES_TABLE_ID, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'name',
        IsAsc: true,
        Filters: []
      });

      if (error) {
        console.error('[Route: /admin/users] Error loading roles:', error);
        toast.error('Failed to load roles');
        return;
      }

      const transformedRoles = data?.List?.map((role: any) => ({
        id: role.id,
        name: role.name || '',
        code: role.code || '',
        remark: role.remark || ''
      })) || [];

      setRoles(transformedRoles);
    } catch (error) {
      console.error('[Route: /admin/users] Error loading roles:', error);
      toast.error('Failed to load roles');
    }
  }, []);

  // Load users
  const loadUsers = useCallback(async () => {
    try {
      setLoading(true);

      const queryFilters = [];
      if (filters.search) {
        queryFilters.push(
          { name: 'name', op: 'StringContains', value: filters.search },
          { name: 'email', op: 'StringContains', value: filters.search }
        );
      }

      const { data, error } = await window.ezsite.apis.tablePage(USERS_TABLE_ID, {
        PageNo: currentPage,
        PageSize: pageSize,
        OrderByField: 'create_time',
        IsAsc: false,
        Filters: queryFilters
      });

      if (error) {
        console.error('[Route: /admin/users] Error loading users:', error);
        toast.error('Failed to load users');
        return;
      }

      const transformedUsers: User[] = data?.List?.map((user: any) => ({
        id: user.id || 0,
        name: user.name || '',
        email: user.email || '',
        phone_number: user.phone_number || '',
        is_activated: user.is_activated !== false,
        role_id: user.role_id || null,
        role_name: user.role_name || 'No Role',
        role_code: user.role_code || '',
        create_time: user.create_time || new Date().toISOString()
      })) || [];

      setUsers(transformedUsers);
      setTotalCount(data?.VirtualCount || 0);

      // Calculate user stats
      const stats = transformedUsers.reduce(
        (acc, user) => {
          acc.total = data?.VirtualCount || 0;
          if (user.is_activated) acc.active++;else
          acc.inactive++;
          if (user.role_code === 'Administrator') acc.admins++;
          return acc;
        },
        { total: 0, active: 0, inactive: 0, admins: 0 }
      );
      setUserStats(stats);

    } catch (error) {
      console.error('[Route: /admin/users] Error loading users:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  }, [currentPage, pageSize, filters]);

  // Load data on component mount and when dependencies change
  useEffect(() => {
    loadRoles();
  }, [loadRoles]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  const handleCreateUser = () => {
    setEditingUser(null);
    setUserFormOpen(true);
  };

  const handleEditUser = (user: User) => {
    setEditingUser(user);
    setUserFormOpen(true);
  };

  const handleUserSubmit = async (userData: UserFormData) => {
    try {
      setFormLoading(true);

      if (editingUser) {
        // Update existing user
        const updateData: any = {
          ID: editingUser.id
        };

        if (userData.name !== undefined) updateData.name = userData.name;
        if (userData.email !== undefined) updateData.email = userData.email;
        if (userData.phoneNumber !== undefined) updateData.phone_number = userData.phoneNumber;
        if (userData.roleId !== undefined) updateData.role_id = userData.roleId;

        const { error } = await window.ezsite.apis.tableUpdate(USERS_TABLE_ID, updateData);

        if (error) {
          throw new Error(error);
        }

        toast.success('User updated successfully');
      } else {
        // Create new user
        const { error } = await window.ezsite.apis.register({
          email: userData.email,
          password: userData.password || 'DefaultPassword123!'
        });

        if (error) {
          throw new Error(error);
        }

        toast.success('User created successfully');
      }

      setUserFormOpen(false);
      setEditingUser(null);
      await loadUsers();

    } catch (error) {
      console.error('Error saving user:', error);
      toast.error(`Failed to ${editingUser ? 'update' : 'create'} user: ${error}`);
    } finally {
      setFormLoading(false);
    }
  };

  const handleDeleteUser = async (userId: number) => {
    try {
      const { error } = await window.ezsite.apis.tableDelete(USERS_TABLE_ID, { ID: userId });

      if (error) {
        throw new Error(error);
      }

      toast.success('User deleted successfully');
      await loadUsers();

    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error('Failed to delete user');
    }
  };

  const handleToggleActivation = async (userId: number, isActivated: boolean) => {
    try {
      const { error } = await window.ezsite.apis.tableUpdate(USERS_TABLE_ID, {
        ID: userId,
        is_activated: isActivated
      });

      if (error) {
        throw new Error(error);
      }

      toast.success(`User ${isActivated ? 'activated' : 'deactivated'} successfully`);
      await loadUsers();

    } catch (error) {
      console.error('Error toggling user activation:', error);
      toast.error(`Failed to ${isActivated ? 'activate' : 'deactivate'} user`);
    }
  };

  const handleSendPasswordReset = async (email: string) => {
    try {
      const { error } = await window.ezsite.apis.sendResetPwdEmail({ email });

      if (error) {
        throw new Error(error);
      }

      toast.success('Password reset email sent successfully');

    } catch (error) {
      console.error('Error sending password reset:', error);
      toast.error('Failed to send password reset email');
    }
  };

  const handleFiltersChange = (newFilters: UserSearchFilters) => {
    setFilters(newFilters);
    setCurrentPage(1); // Reset to first page when filters change
  };

  const handleResetFilters = () => {
    setFilters({ search: '' });
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const totalPages = Math.ceil(totalCount / pageSize);

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-gray-600 mt-2">
            Manage user accounts, roles, and permissions
          </p>
        </div>
        <Button onClick={handleCreateUser} className="flex items-center gap-2">
          <UserPlus className="h-4 w-4" />
          Add New User
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userStats.total}</div>
            <p className="text-xs text-muted-foreground">All registered users</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{userStats.active}</div>
            <p className="text-xs text-muted-foreground">Currently active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Inactive Users</CardTitle>
            <UserX className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{userStats.inactive}</div>
            <p className="text-xs text-muted-foreground">Deactivated accounts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Administrators</CardTitle>
            <Shield className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{userStats.admins}</div>
            <p className="text-xs text-muted-foreground">Admin accounts</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <UserSearchFilter
        filters={filters}
        onFiltersChange={handleFiltersChange}
        roles={roles}
        onReset={handleResetFilters} />


      {/* User List */}
      <UserList
        users={users}
        loading={loading}
        onEditUser={handleEditUser}
        onDeleteUser={handleDeleteUser}
        onToggleActivation={handleToggleActivation}
        onSendPasswordReset={handleSendPasswordReset}
        deleteConfirm={deleteConfirm}
        setDeleteConfirm={setDeleteConfirm} />


      {/* Pagination */}
      {totalPages > 1 &&
      <div className="flex justify-center">
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                onClick={() => handlePageChange(Math.max(1, currentPage - 1))}
                className={currentPage === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'} />

              </PaginationItem>
              
              {[...Array(Math.min(5, totalPages))].map((_, i) => {
              const page = i + 1;
              return (
                <PaginationItem key={page}>
                    <PaginationLink
                    onClick={() => handlePageChange(page)}
                    isActive={currentPage === page}
                    className="cursor-pointer">

                      {page}
                    </PaginationLink>
                  </PaginationItem>);

            })}

              <PaginationItem>
                <PaginationNext
                onClick={() => handlePageChange(Math.min(totalPages, currentPage + 1))}
                className={currentPage === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'} />

              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      }

      {/* User Form Modal */}
      <UserForm
        open={userFormOpen}
        onOpenChange={setUserFormOpen}
        user={editingUser}
        roles={roles}
        onSubmit={handleUserSubmit}
        loading={formLoading} />

    </div>);

};

export default UserManagementPage;