
import React, { useState, useEffect } from 'react';
import { Employee, EmployeeRole } from '@/types/employee';
import { employeeService } from '@/services/employeeService';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import {
  Users,
  UserPlus,
  BarChart3,
  Shield,
  ArrowLeft } from
'lucide-react';
import { toast } from 'sonner';

// Import components
import EmployeeList from '@/components/EmployeeList';
import EmployeeForm from '@/components/EmployeeForm';
import EmployeeProfile from '@/components/EmployeeProfile';
import EmployeeStats from '@/components/EmployeeStats';
import RoleManagement from '@/components/RoleManagement';

const EmployeeManagementPage: React.FC = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [roles, setRoles] = useState<EmployeeRole[]>([]);
  const [currentView, setCurrentView] = useState<'list' | 'create' | 'edit' | 'profile'>('list');
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    initializeData();
  }, []);

  const initializeData = async () => {
    // Load employee data
    await loadData();
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [employeesData, rolesData] = await Promise.all([
      employeeService.getAllEmployees(),
      employeeService.getAllRoles()]
      );
      setEmployees(employeesData);
      setRoles(rolesData);
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load employee data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateEmployee = () => {
    setSelectedEmployee(null);
    setCurrentView('create');
  };

  const handleEditEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setCurrentView('edit');
  };

  const handleViewEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setCurrentView('profile');
  };

  const handleDeleteEmployee = async (id: string) => {
    if (!confirm('Are you sure you want to delete this employee?')) {
      return;
    }

    try {
      await employeeService.deleteEmployee(id);
      toast.success('Employee deleted successfully');
      loadData();
    } catch (error) {
      console.error('Failed to delete employee:', error);
      toast.error('Failed to delete employee');
    }
  };

  const handleSaveEmployee = async (employeeData: Omit<Employee, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      if (selectedEmployee) {
        // Update existing employee
        await employeeService.updateEmployee(selectedEmployee.id, employeeData);
        toast.success('Employee updated successfully');
      } else {
        // Create new employee
        await employeeService.createEmployee(employeeData);
        toast.success('Employee created successfully');
      }
      setCurrentView('list');
      loadData();
    } catch (error) {
      console.error('Failed to save employee:', error);
      toast.error('Failed to save employee');
      throw error;
    }
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedEmployee(null);
  };

  const getEmployeeRole = (roleId: string) => {
    return roles.find((role) => role.id === roleId) || null;
  };

  if (loading && employees.length === 0) {
    return (
      <div className="container mx-auto px-6 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) =>
            <Card key={i}>
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>);

  }

  return (
    <div className="container mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        {currentView !== 'list' &&
        <Button
          variant="outline"
          onClick={handleBackToList}
          className="flex items-center gap-2 mb-4">

            <ArrowLeft className="h-4 w-4" />
            Back to Employee List
          </Button>
        }
        
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Users className="h-8 w-8 text-blue-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Employee Management</h1>
            <p className="text-gray-600">Manage your team members and their information</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      {currentView === 'list' &&
      <Tabs defaultValue="employees" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="employees" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Employees
            </TabsTrigger>
            <TabsTrigger value="statistics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Statistics
            </TabsTrigger>
            <TabsTrigger value="roles" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Roles & Permissions
            </TabsTrigger>
          </TabsList>

          <TabsContent value="employees">
            <EmployeeList
            employees={employees}
            onEditEmployee={handleEditEmployee}
            onDeleteEmployee={handleDeleteEmployee}
            onViewEmployee={handleViewEmployee}
            onCreateEmployee={handleCreateEmployee} />

          </TabsContent>

          <TabsContent value="statistics">
            <EmployeeStats />
          </TabsContent>

          <TabsContent value="roles">
            <RoleManagement />
          </TabsContent>
        </Tabs>
      }

      {(currentView === 'create' || currentView === 'edit') &&
      <EmployeeForm
        employee={selectedEmployee || undefined}
        roles={roles}
        onSubmit={handleSaveEmployee}
        onCancel={handleBackToList}
        isLoading={loading} />

      }

      {currentView === 'profile' && selectedEmployee &&
      <EmployeeProfile
        employee={selectedEmployee}
        role={getEmployeeRole(selectedEmployee.roleId)}
        onEdit={handleEditEmployee} />

      }
    </div>);

};

export default EmployeeManagementPage;