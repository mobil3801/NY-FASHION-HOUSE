import React from 'react';
import { ApiTestingDashboard } from '@/components/testing/ApiTestingDashboard';

const ApiTestingDashboardPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <ApiTestingDashboard />
    </div>);

};

export default ApiTestingDashboardPage;