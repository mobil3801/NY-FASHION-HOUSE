
import React from 'react';
import CrossBrowserErrorTestDashboard from '@/components/testing/CrossBrowserErrorTestDashboard';

const CrossBrowserErrorTestPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <CrossBrowserErrorTestDashboard />
    </div>);

};

export default CrossBrowserErrorTestPage;