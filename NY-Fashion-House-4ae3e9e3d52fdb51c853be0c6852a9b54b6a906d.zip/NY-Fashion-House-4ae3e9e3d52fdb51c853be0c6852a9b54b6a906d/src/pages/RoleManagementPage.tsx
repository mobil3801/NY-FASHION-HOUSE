
import React from 'react';
import { Plus, Shield, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Role, Permission, RoleFormData, RoleSearchFilters, RoleStats } from '@/types/role';
import RoleSearchFilter from '@/components/roles/RoleSearchFilter';
import RoleAnalytics from '@/components/roles/RoleAnalytics';
import RoleList from '@/components/roles/RoleList';
import RoleForm from '@/components/roles/RoleForm';
import RoleAssignment from '@/components/roles/RoleAssignment';

type ViewMode = 'list' | 'create' | 'edit';

const ROLES_TABLE_ID = 37707; // easysite_roles table
const USERS_TABLE_ID = 37706; // easysite_auth_users table

export const RoleManagementPage: React.FC = () => {
  const [viewMode, setViewMode] = React.useState<ViewMode>('list');
  const [roles, setRoles] = React.useState<Role[]>([]);
  const [permissions, setPermissions] = React.useState<Permission[]>([]);
  const [roleStats, setRoleStats] = React.useState<RoleStats | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [selectedRole, setSelectedRole] = React.useState<Role | null>(null);
  const [rolePermissions, setRolePermissions] = React.useState<number[]>([]);
  const [showAssignment, setShowAssignment] = React.useState(false);
  const [filters, setFilters] = React.useState<RoleSearchFilters>({
    search: '',
    sortBy: 'name',
    sortOrder: 'asc'
  });

  // Load initial data
  React.useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
      loadRoles(),
      loadPermissions(),
      loadStats()]
      );
    } catch (error: any) {
      console.error('[Route: /admin/roles] Error loading data:', error);
      toast.error('Failed to load role management data');
    } finally {
      setLoading(false);
    }
  };

  const loadRoles = async () => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(ROLES_TABLE_ID, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'name',
        IsAsc: true,
        Filters: []
      });

      if (error) {
        console.error('[Route: /admin/roles] Error fetching roles:', error);
        throw new Error(error);
      }

      // Get user counts for each role
      const rolesWithCounts = await Promise.all(
        (data?.List || []).map(async (role: any) => {
          try {
            const userCountResponse = await window.ezsite.apis.tablePage(USERS_TABLE_ID, {
              PageNo: 1,
              PageSize: 1,
              OrderByField: 'id',
              IsAsc: true,
              Filters: [{ name: 'role_id', op: 'Equal', value: role.id }]
            });

            return {
              id: role.id,
              name: role.name || '',
              code: role.code || '',
              remark: role.remark || '',
              create_time: role.create_time || new Date().toISOString(),
              userCount: userCountResponse.error ? 0 : userCountResponse.data?.VirtualCount || 0
            };
          } catch {
            return {
              id: role.id,
              name: role.name || '',
              code: role.code || '',
              remark: role.remark || '',
              create_time: role.create_time || new Date().toISOString(),
              userCount: 0
            };
          }
        })
      );

      setRoles(rolesWithCounts);
    } catch (error: any) {
      console.error('[Route: /admin/roles] Error loading roles:', error);
      throw error;
    }
  };

  const loadPermissions = async () => {
    try {
      // Mock permissions since permissions table doesn't exist yet
      const mockPermissions: Permission[] = [
      { id: 1, name: 'View Users', code: 'VIEW_USERS', category: 'User Management' },
      { id: 2, name: 'Create Users', code: 'CREATE_USERS', category: 'User Management' },
      { id: 3, name: 'Edit Users', code: 'EDIT_USERS', category: 'User Management' },
      { id: 4, name: 'Delete Users', code: 'DELETE_USERS', category: 'User Management' },
      { id: 5, name: 'View Roles', code: 'VIEW_ROLES', category: 'Role Management' },
      { id: 6, name: 'Create Roles', code: 'CREATE_ROLES', category: 'Role Management' },
      { id: 7, name: 'Edit Roles', code: 'EDIT_ROLES', category: 'Role Management' },
      { id: 8, name: 'Delete Roles', code: 'DELETE_ROLES', category: 'Role Management' }];


      setPermissions(mockPermissions);
    } catch (error: any) {
      console.error('Error loading permissions:', error);
      throw error;
    }
  };

  const loadStats = async () => {
    try {
      const mockStats: RoleStats = {
        totalRoles: roles.length,
        totalUsers: 0,
        activeRoles: roles.length,
        roleUsageDistribution: roles.map((role) => ({
          roleName: role.name,
          userCount: role.userCount || 0,
          percentage: 0
        }))
      };

      setRoleStats(mockStats);
    } catch (error: any) {
      console.error('Error loading stats:', error);
      // Don't throw here, stats are non-critical
    }
  };

  const loadRolePermissions = async (roleId: number) => {
    try {
      // Mock role permissions
      setRolePermissions([1, 2, 3, 5, 6]);
    } catch (error: any) {
      console.error('Error loading role permissions:', error);
      setRolePermissions([]);
    }
  };

  // Filtered roles based on search and filters
  const filteredRoles = React.useMemo(() => {
    return roles.filter((role) => {
      const matchesSearch = !filters.search ||
      role.name.toLowerCase().includes(filters.search.toLowerCase()) ||
      role.code.toLowerCase().includes(filters.search.toLowerCase()) ||
      role.remark && role.remark.toLowerCase().includes(filters.search.toLowerCase());

      const matchesUserCount =
      (!filters.userCountMin || (role.userCount || 0) >= filters.userCountMin) && (
      !filters.userCountMax || (role.userCount || 0) <= filters.userCountMax);

      const matchesDate =
      (!filters.dateFrom || new Date(role.create_time) >= new Date(filters.dateFrom)) && (
      !filters.dateTo || new Date(role.create_time) <= new Date(filters.dateTo));

      return matchesSearch && matchesUserCount && matchesDate;
    }).sort((a, b) => {
      let aValue: any, bValue: any;

      switch (filters.sortBy) {
        case 'name':
          aValue = a.name;
          bValue = b.name;
          break;
        case 'code':
          aValue = a.code;
          bValue = b.code;
          break;
        case 'create_time':
          aValue = new Date(a.create_time);
          bValue = new Date(b.create_time);
          break;
        case 'userCount':
          aValue = a.userCount || 0;
          bValue = b.userCount || 0;
          break;
        default:
          aValue = a.name;
          bValue = b.name;
      }

      if (filters.sortOrder === 'desc') {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      } else {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      }
    });
  }, [roles, filters]);

  // Handlers
  const handleCreateRole = () => {
    setSelectedRole(null);
    setRolePermissions([]);
    setViewMode('create');
  };

  const handleEditRole = async (role: Role) => {
    setSelectedRole(role);
    await loadRolePermissions(role.id);
    setViewMode('edit');
  };

  const handleDeleteRole = async (role: Role) => {
    try {
      // Check if it's a protected role
      if (role.code === 'Administrator' || role.code === 'GeneralUser') {
        throw new Error('Cannot delete system default roles');
      }

      // Check if role is in use
      if (role.userCount && role.userCount > 0) {
        throw new Error(`Cannot delete role: ${role.userCount} users are assigned to this role`);
      }

      const { error } = await window.ezsite.apis.tableDelete(ROLES_TABLE_ID, { ID: role.id });

      if (error) {
        throw new Error(error);
      }

      toast.success(`Role "${role.name}" deleted successfully`);
      await loadRoles();
      await loadStats();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete role');
    }
  };

  const handleSubmitRole = async (data: RoleFormData) => {
    try {
      if (selectedRole) {
        // Update existing role
        const { error } = await window.ezsite.apis.tableUpdate(ROLES_TABLE_ID, {
          ID: selectedRole.id,
          name: data.name,
          remark: data.remark
        });

        if (error) {
          throw new Error(error);
        }

        toast.success(`Role "${data.name}" updated successfully`);
      } else {
        // Create new role
        const code = data.name.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '') + '_' + Date.now();

        const { error } = await window.ezsite.apis.tableCreate(ROLES_TABLE_ID, {
          name: data.name,
          code: code,
          remark: data.remark || '',
          create_time: new Date().toISOString()
        });

        if (error) {
          throw new Error(error);
        }

        toast.success(`Role "${data.name}" created successfully`);
      }

      setViewMode('list');
      await loadRoles();
      await loadStats();
    } catch (error: any) {
      throw error; // Let the form handle the error
    }
  };

  const handleAssignUsers = async (userIds: number[], roleId: number) => {
    try {
      for (const userId of userIds) {
        const { error } = await window.ezsite.apis.tableUpdate(USERS_TABLE_ID, {
          ID: userId,
          role_id: roleId
        });

        if (error) {
          throw new Error(error);
        }
      }

      toast.success(`Successfully assigned ${userIds.length} users to role`);
      await loadRoles();
      await loadStats();
    } catch (error: any) {
      throw error;
    }
  };

  const handleViewUsers = (role: Role) => {
    toast.info(`Viewing users for role: ${role.name} (${role.userCount || 0} users)`);
  };

  const handleAssignUsersToRole = (role: Role) => {
    setSelectedRole(role);
    setShowAssignment(true);
  };

  const resetFilters = () => {
    setFilters({
      search: '',
      sortBy: 'name',
      sortOrder: 'asc'
    });
  };

  if (loading && roles.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-8">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) =>
            <div key={i} className="h-32 bg-gray-200 rounded"></div>
            )}
          </div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>);

  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Shield className="h-8 w-8" />
              Role & Permission Management
            </h1>
            <p className="text-gray-600 mt-2">
              Manage system roles, permissions, and user assignments
            </p>
          </div>
          
          {viewMode === 'list' &&
          <div className="flex gap-2">
              <Button variant="outline" onClick={loadData}>
                <RotateCcw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button onClick={handleCreateRole}>
                <Plus className="h-4 w-4 mr-2" />
                Create Role
              </Button>
            </div>
          }
        </div>

        {viewMode === 'list' ?
        <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 lg:w-auto lg:grid-cols-2">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="roles">Roles</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <RoleAnalytics stats={roleStats} loading={loading} />
              <RoleList
              roles={roles}
              loading={loading}
              onEdit={handleEditRole}
              onDelete={handleDeleteRole}
              onViewUsers={handleViewUsers}
              onAssignUsers={handleAssignUsersToRole} />

            </TabsContent>

            <TabsContent value="roles" className="space-y-6">
              <RoleSearchFilter
              filters={filters}
              onFiltersChange={setFilters}
              onReset={resetFilters} />

              
              <RoleList
              roles={filteredRoles}
              loading={loading}
              onEdit={handleEditRole}
              onDelete={handleDeleteRole}
              onViewUsers={handleViewUsers}
              onAssignUsers={handleAssignUsersToRole} />

            </TabsContent>
          </Tabs> :

        <RoleForm
          role={selectedRole}
          permissions={permissions}
          rolePermissions={rolePermissions}
          onSubmit={handleSubmitRole}
          onCancel={() => setViewMode('list')}
          loading={loading} />

        }

        {/* Role Assignment Dialog */}
        <RoleAssignment
          isOpen={showAssignment}
          onClose={() => setShowAssignment(false)}
          roles={roles}
          selectedRole={selectedRole}
          onAssignUsers={handleAssignUsers} />

      </div>
    </div>);

};

export default RoleManagementPage;