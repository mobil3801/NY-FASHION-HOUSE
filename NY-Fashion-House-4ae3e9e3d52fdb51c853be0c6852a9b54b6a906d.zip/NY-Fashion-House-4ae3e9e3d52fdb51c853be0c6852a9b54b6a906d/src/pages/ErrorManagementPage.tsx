import React from 'react';
import Layout from '../components/Layout';
import { FinalErrorBoundary } from '../components/error-system/FinalErrorBoundary';
import { ErrorMonitoringDashboard } from '../components/error-system/ErrorMonitoringDashboard';
import { ErrorHandlingDocumentation } from '../components/error-system/ErrorHandlingDocumentation';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import {
  Monitor,
  Book,
  Settings,
  Activity,
  Shield,
  Zap,
  AlertTriangle,
  CheckCircle } from
'lucide-react';

const ErrorManagementPage: React.FC = () => {
  return (
    <Layout>
      <FinalErrorBoundary level="page" identifier="error-management-page">
        <div className="container mx-auto p-6 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <Shield className="h-8 w-8 text-blue-500" />
                Error Management System
              </h1>
              <p className="text-muted-foreground mt-2">
                Comprehensive error handling, monitoring, and management dashboard
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="flex items-center gap-1">
                <Activity className="h-3 w-3" />
                System Active
              </Badge>
              <Badge variant="default" className="flex items-center gap-1">
                <Zap className="h-3 w-3" />
                Production Ready
              </Badge>
            </div>
          </div>

          {/* System Status Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Error Boundaries</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Active</div>
                <div className="flex items-center gap-2 mt-1">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <p className="text-xs text-muted-foreground">
                    Full coverage implemented
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Monitoring</CardTitle>
                <Monitor className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Real-time</div>
                <div className="flex items-center gap-2 mt-1">
                  <Activity className="h-4 w-4 text-blue-500 animate-pulse" />
                  <p className="text-xs text-muted-foreground">
                    Live error tracking
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Performance</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Optimized</div>
                <div className="flex items-center gap-2 mt-1">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <p className="text-xs text-muted-foreground">
                    Minimal impact
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Tabs */}
          <Tabs defaultValue="monitoring" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="monitoring" className="flex items-center gap-2">
                <Monitor className="h-4 w-4" />
                Monitoring
              </TabsTrigger>
              <TabsTrigger value="documentation" className="flex items-center gap-2">
                <Book className="h-4 w-4" />
                Documentation
              </TabsTrigger>
              <TabsTrigger value="configuration" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Configuration
              </TabsTrigger>
              <TabsTrigger value="testing" className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                Testing
              </TabsTrigger>
            </TabsList>

            <TabsContent value="monitoring">
              <FinalErrorBoundary level="section" identifier="error-monitoring-dashboard">
                <ErrorMonitoringDashboard />
              </FinalErrorBoundary>
            </TabsContent>

            <TabsContent value="documentation">
              <FinalErrorBoundary level="section" identifier="error-documentation">
                <ErrorHandlingDocumentation />
              </FinalErrorBoundary>
            </TabsContent>

            <TabsContent value="configuration" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    System Configuration
                  </CardTitle>
                  <CardDescription>
                    Configure error handling system settings and preferences
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold">Error Capture Settings</h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Automatic Error Capture</span>
                          <Badge variant="default">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">DevTools Integration</span>
                          <Badge variant="default">Active</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Performance Monitoring</span>
                          <Badge variant="default">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Pattern Detection</span>
                          <Badge variant="default">Running</Badge>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-semibold">Reporting Settings</h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Real-time Alerts</span>
                          <Badge variant="default">Enabled</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Error Deduplication</span>
                          <Badge variant="default">Active</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Automated Reports</span>
                          <Badge variant="default">Scheduled</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Data Retention</span>
                          <Badge variant="outline">30 days</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="testing" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Error System Testing
                  </CardTitle>
                  <CardDescription>
                    Test and validate the error handling system functionality
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold">Test Error Boundaries</h3>
                      <p className="text-sm text-muted-foreground">
                        Verify that error boundaries are working correctly at all levels
                      </p>
                      <Button
                        variant="outline"
                        onClick={() => {
                          throw new Error('Test error boundary - Component level');
                        }}>

                        Test Component Error
                      </Button>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-semibold">Test Error Reporting</h3>
                      <p className="text-sm text-muted-foreground">
                        Test the error reporting and tracking functionality
                      </p>
                      <Button
                        variant="outline"
                        onClick={() => {
                          const error = new Error('Test error reporting system');
                          console.error('Test error:', error);
                        }}>

                        Test Error Reporting
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold">System Health Check</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="flex items-center gap-2 p-3 border rounded-lg">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <div>
                          <div className="font-medium text-sm">Error Boundaries</div>
                          <div className="text-xs text-muted-foreground">Active</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 p-3 border rounded-lg">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <div>
                          <div className="font-medium text-sm">Error Service</div>
                          <div className="text-xs text-muted-foreground">Running</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 p-3 border rounded-lg">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <div>
                          <div className="font-medium text-sm">Monitoring</div>
                          <div className="text-xs text-muted-foreground">Online</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </FinalErrorBoundary>
    </Layout>);

};

export default ErrorManagementPage;