
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BackupHistoryTable } from '@/components/backup/BackupHistoryTable';
import { ManualBackupForm } from '@/components/backup/ManualBackupForm';
import { BackupScheduler } from '@/components/backup/BackupScheduler';
import { StorageMonitoring } from '@/components/backup/StorageMonitoring';
import { BackupCleanupSettings } from '@/components/backup/BackupCleanupSettings';
import { Shield, Clock, Settings, HardDrive } from 'lucide-react';

const BackupManagementPage: React.FC = () => {
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleBackupCreated = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Backup Management</h1>
          <p className="text-gray-600 mt-2">
            Manage system backups, schedules, and recovery operations
          </p>
        </div>
      </div>

      <Tabs defaultValue="history" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="history" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            History
          </TabsTrigger>
          <TabsTrigger value="manual" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Manual Backup
          </TabsTrigger>
          <TabsTrigger value="schedule" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Schedule
          </TabsTrigger>
          <TabsTrigger value="storage" className="flex items-center gap-2">
            <HardDrive className="h-4 w-4" />
            Storage
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Backup History</CardTitle>
              <CardDescription>
                View and manage all system backups
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BackupHistoryTable refreshTrigger={refreshTrigger} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="manual">
          <Card>
            <CardHeader>
              <CardTitle>Create Manual Backup</CardTitle>
              <CardDescription>
                Create an immediate backup of the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ManualBackupForm onBackupCreated={handleBackupCreated} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Backup Schedule</CardTitle>
              <CardDescription>
                Configure automatic backup schedules
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BackupScheduler />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="storage">
          <Card>
            <CardHeader>
              <CardTitle>Storage Monitoring</CardTitle>
              <CardDescription>
                Monitor backup storage usage and capacity
              </CardDescription>
            </CardHeader>
            <CardContent>
              <StorageMonitoring />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Backup Settings</CardTitle>
              <CardDescription>
                Configure cleanup policies and retention settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BackupCleanupSettings />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};

export default BackupManagementPage;