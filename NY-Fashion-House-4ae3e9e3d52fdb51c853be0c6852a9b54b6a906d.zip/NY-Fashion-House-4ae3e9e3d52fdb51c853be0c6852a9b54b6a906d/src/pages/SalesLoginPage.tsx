
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSalesAuth } from '@/contexts/SalesAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, ShoppingCart, TrendingUp, Users } from 'lucide-react';
import ImageWithFallback from '@/components/ImageWithFallback';

const SalesLoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { login, isAuthenticated } = useSalesAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/sales-dashboard', { replace: true });
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      if (!email || !password) {
        setError('Please enter both email and password');
        return;
      }

      const result = await login(email, password);

      if (result.success) {
        navigate('/sales-dashboard', { replace: true });
      } else {
        console.error('[Route: /sales-login] Login failed:', result.error);
        setError(result.error || 'Login failed. Please try again.');
      }
    } catch (err) {
      console.error('[Route: /sales-login] Login error:', err);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-3">
            <ImageWithFallback
              src="https://cdn.ezsite.ai/AutoDev/19016/95c2a8a3-4455-4cc1-91c1-442a3cf63926.jpeg"
              fallbackSrc="/logo-placeholder.svg"
              alt="NY FASHION HOUSE Logo"
              className="h-10 w-10 rounded-lg object-cover" />

            <div>
              <h1 className="text-xl font-bold text-gray-900">NY FASHION HOUSE - Sales Portal</h1>
              <p className="text-sm text-gray-600">Dedicated Sales Management System</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 items-center min-h-[calc(100vh-120px)]">
          
          {/* Left Side - Features */}
          <div className="hidden lg:block space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Welcome to Your
                <span className="text-blue-600 block">Sales Dashboard</span>
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Manage your sales transactions efficiently with our dedicated sales portal.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <ShoppingCart className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Sales Entry</h3>
                  <p className="text-gray-600">Record and manage sales transactions with ease</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-green-100 p-3 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Track Performance</h3>
                  <p className="text-gray-600">Monitor your sales metrics and performance</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-purple-100 p-3 rounded-lg">
                  <Users className="h-6 w-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Customer Management</h3>
                  <p className="text-gray-600">Access customer information during sales</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="flex justify-center">
            <Card className="w-full max-w-md shadow-xl border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="text-center space-y-2">
                <CardTitle className="text-2xl font-bold text-gray-900">Sales Login</CardTitle>
                <CardDescription className="text-gray-600">
                  Sign in to access your sales dashboard
                </CardDescription>
              </CardHeader>
              <CardContent>
                {error &&
                <Alert className="mb-6 border-red-200 bg-red-50">
                    <AlertDescription className="text-red-700">
                      {error}
                    </AlertDescription>
                  </Alert>
                }

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      disabled={isSubmitting}
                      placeholder="Enter your email"
                      className="bg-white/80" />

                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      disabled={isSubmitting}
                      placeholder="Enter your password"
                      className="bg-white/80" />

                  </div>

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 font-medium">

                    {isSubmitting ?
                    <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Signing In...
                      </> :

                    'Sign In to Sales Portal'
                    }
                  </Button>
                </form>

                <div className="mt-6 pt-6 border-t border-gray-200">
                  <p className="text-center text-sm text-gray-600">
                    Only authorized sales personnel can access this portal.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>);

};

export default SalesLoginPage;