
import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import CheckoutTestRunner from '@/components/testing/CheckoutTestRunner';

const TestDashboard: React.FC = () => {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Test Dashboard</h1>
        <p className="text-gray-600 mt-2">
          Run comprehensive tests to validate system functionality and identify issues
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">System Status</p>
              <p className="text-2xl font-bold text-green-600">Operational</p>
            </div>
            <Badge variant="default" className="bg-green-100 text-green-800">
              Healthy
            </Badge>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Database</p>
              <p className="text-2xl font-bold text-blue-600">Connected</p>
            </div>
            <Badge variant="default" className="bg-blue-100 text-blue-800">
              Active
            </Badge>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">POS System</p>
              <p className="text-2xl font-bold text-purple-600">Ready</p>
            </div>
            <Badge variant="default" className="bg-purple-100 text-purple-800">
              Testing
            </Badge>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Test Mode</p>
              <p className="text-2xl font-bold text-orange-600">Active</p>
            </div>
            <Badge variant="default" className="bg-orange-100 text-orange-800">
              Debug
            </Badge>
          </div>
        </Card>
      </div>

      <CheckoutTestRunner />
    </div>);

};

export default TestDashboard;