
import React from 'react';
import Layout from '@/components/Layout';
import PerformanceTestDashboard from '@/components/performance/PerformanceTestDashboard';

const PerformanceTestingPage: React.FC = () => {
  return (
    <Layout>
      <PerformanceTestDashboard />
    </Layout>);

};

export default PerformanceTestingPage;