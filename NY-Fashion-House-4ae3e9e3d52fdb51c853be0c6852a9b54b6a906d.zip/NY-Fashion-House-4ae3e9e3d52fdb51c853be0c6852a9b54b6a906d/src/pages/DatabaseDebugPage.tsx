import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { Database, Play, CheckCircle, XCircle, AlertTriangle, RefreshCw, Trash2 } from 'lucide-react';
import DatabaseCrudTest from '@/components/DatabaseCrudTest';
import { DatabaseService } from '@/services/databaseService';

interface TestResult {
  table: string;
  operation: string;
  status: 'success' | 'error' | 'warning';
  message: string;
  timestamp: Date;
  details?: any;
}

const DatabaseDebugPage: React.FC = () => {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);

  // Capture console output
  React.useEffect(() => {
    const originalConsoleLog = console.log;
    const originalConsoleError = console.error;
    const originalConsoleWarn = console.warn;

    console.log = (...args) => {
      setConsoleOutput((prev) => [...prev, `[LOG] ${args.join(' ')}`]);
      originalConsoleLog(...args);
    };

    console.error = (...args) => {
      setConsoleOutput((prev) => [...prev, `[ERROR] ${args.join(' ')}`]);
      originalConsoleError(...args);
    };

    console.warn = (...args) => {
      setConsoleOutput((prev) => [...prev, `[WARN] ${args.join(' ')}`]);
      originalConsoleWarn(...args);
    };

    return () => {
      console.log = originalConsoleLog;
      console.error = originalConsoleError;
      console.warn = originalConsoleWarn;
    };
  }, []);

  const addTestResult = (result: Omit<TestResult, 'timestamp'>) => {
    setTestResults((prev) => [{
      ...result,
      timestamp: new Date()
    }, ...prev]);
  };

  const clearResults = () => {
    setTestResults([]);
    setConsoleOutput([]);
  };

  const testAllTables = async () => {
    setIsLoading(true);
    setTestResults([]);
    setConsoleOutput([]);

    console.log('='.repeat(80));
    console.log('STARTING COMPREHENSIVE DATABASE CRUD TEST');
    console.log('='.repeat(80));

    const testTables = [
    {
      name: 'products',
      data: {
        sku: `TEST-${Date.now()}`,
        name: 'Test Product',
        description: 'Test product for CRUD verification',
        category: 'Test Category',
        cost_price: 10.50,
        selling_price: 20.99,
        stock_level: 100,
        min_stock_level: 10,
        supplier_id: 'TEST_SUPPLIER',
        barcode: `BAR${Date.now()}`,
        is_active: true
      }
    },
    {
      name: 'employees',
      data: {
        first_name: 'Test',
        last_name: 'Employee',
        email: `test.employee.${Date.now()}@company.com`,
        phone: '555-0123',
        position: 'Test Developer',
        department: 'IT',
        salary: 75000,
        employment_status: 'active',
        hire_date: new Date().toISOString(),
        address_street: '123 Test St',
        address_city: 'Test City',
        address_state: 'TS',
        address_zip_code: '12345',
        address_country: 'Test Country'
      }
    },
    {
      name: 'sales_transactions',
      data: {
        product_id: 1,
        product_name: 'Test Product Sale',
        quantity_sold: 3,
        unit_price: 25.99,
        total_amount: 77.97,
        sale_date: new Date().toISOString(),
        employee_id: 1,
        employee_name: 'Test Cashier',
        notes: 'Test transaction for CRUD verification'
      }
    }];


    for (const table of testTables) {
      console.log(`\n${'='.repeat(60)}`);
      console.log(`TESTING TABLE: ${table.name.toUpperCase()}`);
      console.log(`${'='.repeat(60)}`);

      try {
        const success = await DatabaseService.testTableCrud(table.name, table.data);

        addTestResult({
          table: table.name,
          operation: 'FULL_CRUD',
          status: success ? 'success' : 'error',
          message: success ? 'All CRUD operations successful' : 'CRUD test failed',
          details: table.data
        });

      } catch (error) {
        console.error(`Failed to test ${table.name}:`, error);
        addTestResult({
          table: table.name,
          operation: 'FULL_CRUD',
          status: 'error',
          message: `Test failed: ${error}`,
          details: { error }
        });
      }

      // Add delay between table tests
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }

    // Test notifications UPDATE specifically
    console.log(`\n${'='.repeat(60)}`);
    console.log('TESTING NOTIFICATIONS UPDATE');
    console.log(`${'='.repeat(60)}`);

    await testNotificationsUpdate();

    console.log('\n' + '='.repeat(80));
    console.log('DATABASE CRUD TEST COMPLETED');
    console.log('='.repeat(80));

    setIsLoading(false);
    toast.success('Database CRUD tests completed!');
  };

  const testNotificationsUpdate = async () => {
    try {
      const tableId = 38282; // notifications table ID

      // First create a test notification
      console.log('Creating test notification...');
      const createResult = await DatabaseService.create(tableId, 'notifications', {
        user_id: 1,
        title: 'CRUD Test Notification',
        message: 'This notification was created for CRUD testing purposes',
        type: 'create',
        related_table: 'test',
        related_id: 999,
        actor_id: 1,
        actor_name: 'CRUD Test System',
        is_read: false
      });

      if (!createResult.success) {
        addTestResult({
          table: 'notifications',
          operation: 'CREATE',
          status: 'error',
          message: `Failed to create test notification: ${createResult.error}`
        });
        return;
      }

      // Read to get the created notification
      console.log('Reading notifications...');
      const readResult = await DatabaseService.read(tableId, 'notifications', 1, 5);

      if (!readResult.success || !readResult.data?.List?.length) {
        addTestResult({
          table: 'notifications',
          operation: 'READ',
          status: 'error',
          message: `Failed to read notifications: ${readResult.error}`
        });
        return;
      }

      const notification = readResult.data.List[0];
      console.log('Found notification with ID:', notification.id);

      // Test UPDATE
      console.log('Testing notification UPDATE...');
      const updateResult = await DatabaseService.update(tableId, 'notifications', notification.id, {
        is_read: true,
        title: 'CRUD Test Notification - UPDATED',
        message: 'This notification has been successfully updated by CRUD test'
      });

      addTestResult({
        table: 'notifications',
        operation: 'UPDATE',
        status: updateResult.success ? 'success' : 'error',
        message: updateResult.success ?
        'Notification UPDATE successful' :
        `Notification UPDATE failed: ${updateResult.error}`,
        details: { notificationId: notification.id }
      });

      // Clean up - delete the test notification
      if (updateResult.success) {
        console.log('Cleaning up test notification...');
        await DatabaseService.delete(tableId, 'notifications', notification.id);
      }

    } catch (error) {
      console.error('Notifications test error:', error);
      addTestResult({
        table: 'notifications',
        operation: 'UPDATE',
        status: 'error',
        message: `Notifications test exception: ${error}`
      });
    }
  };

  const testIndividualTable = async (tableName: string) => {
    setIsLoading(true);

    const testData = {
      products: {
        sku: `INDIVIDUAL-${Date.now()}`,
        name: 'Individual Test Product',
        description: 'Individual test',
        category: 'Test',
        cost_price: 5,
        selling_price: 10,
        stock_level: 50,
        min_stock_level: 5,
        is_active: true
      },
      employees: {
        first_name: 'Individual',
        last_name: 'Test',
        email: `individual.test.${Date.now()}@test.com`,
        phone: '555-9999',
        position: 'Tester',
        department: 'QA',
        salary: 50000,
        employment_status: 'active'
      },
      sales_transactions: {
        product_id: 1,
        product_name: 'Individual Test Sale',
        quantity_sold: 1,
        unit_price: 10,
        total_amount: 10,
        sale_date: new Date().toISOString(),
        employee_id: 1,
        employee_name: 'Individual Tester',
        notes: 'Individual test transaction'
      }
    };

    const data = testData[tableName as keyof typeof testData];
    if (data) {
      const success = await DatabaseService.testTableCrud(tableName, data);
      addTestResult({
        table: tableName,
        operation: 'INDIVIDUAL_TEST',
        status: success ? 'success' : 'error',
        message: success ? 'Individual test successful' : 'Individual test failed',
        details: data
      });
    }

    setIsLoading(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default:
        return <Database className="h-4 w-4 text-gray-400" />;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Database className="h-8 w-8" />
            Database Debug & CRUD Test Center
          </h1>
          <p className="text-gray-600 mt-1">
            Comprehensive testing and debugging for database CRUD operations
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={clearResults} variant="outline" size="sm">
            <Trash2 className="h-4 w-4 mr-2" />
            Clear All
          </Button>
        </div>
      </div>

      <Tabs defaultValue="comprehensive" className="w-full">
        <TabsList>
          <TabsTrigger value="comprehensive">Comprehensive Tests</TabsTrigger>
          <TabsTrigger value="individual">Individual Table Tests</TabsTrigger>
          <TabsTrigger value="results">Test Results</TabsTrigger>
          <TabsTrigger value="console">Console Output</TabsTrigger>
        </TabsList>

        <TabsContent value="comprehensive" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Run Complete CRUD Test Suite</CardTitle>
              <CardDescription>
                Tests CREATE, READ, UPDATE, DELETE operations on all critical tables: products, employees, sales_transactions, and notifications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={testAllTables}
                disabled={isLoading}
                className="flex items-center gap-2"
                size="lg">

                {isLoading ?
                <RefreshCw className="h-4 w-4 animate-spin" /> :

                <Play className="h-4 w-4" />
                }
                Run Complete Test Suite
              </Button>
            </CardContent>
          </Card>

          <DatabaseCrudTest />
        </TabsContent>

        <TabsContent value="individual" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {['products', 'employees', 'sales_transactions', 'notifications'].map((table) =>
            <Card key={table}>
                <CardHeader>
                  <CardTitle className="text-lg capitalize">{table}</CardTitle>
                  <CardDescription>
                    Test CRUD operations for {table} table only
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                  onClick={() => testIndividualTable(table)}
                  disabled={isLoading}
                  className="w-full"
                  variant="outline">

                    {isLoading ?
                  <RefreshCw className="h-4 w-4 animate-spin mr-2" /> :

                  <Database className="h-4 w-4 mr-2" />
                  }
                    Test {table}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="results">
          <Card>
            <CardHeader>
              <CardTitle>Test Results</CardTitle>
              <CardDescription>
                Detailed results from CRUD operations testing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                {testResults.length === 0 ?
                <div className="text-center py-8 text-gray-500">
                    <Database className="h-12 w-12 mx-auto mb-2 opacity-50" />
                    <p>No test results yet. Run some tests to see results here.</p>
                  </div> :

                <div className="space-y-2">
                    {testResults.map((result, index) =>
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(result.status)}
                          <div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                {result.table}
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {result.operation}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">{result.message}</p>
                          </div>
                        </div>
                        <span className="text-xs text-gray-400">
                          {result.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                  )}
                  </div>
                }
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="console">
          <Card>
            <CardHeader>
              <CardTitle>Console Output</CardTitle>
              <CardDescription>
                Real-time console logs from database operations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="bg-black text-green-400 p-4 rounded font-mono text-xs">
                  {consoleOutput.length === 0 ?
                  <div className="text-gray-500">No console output yet...</div> :

                  consoleOutput.map((line, index) =>
                  <div key={index} className="mb-1">
                        {line}
                      </div>
                  )
                  }
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};

export default DatabaseDebugPage;