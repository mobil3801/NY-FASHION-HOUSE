import { TestCase, TestResult } from './automatedTestGeneratorService';
import { ServiceEndpoint } from './apiEndpointDiscoveryService';

export interface ValidationRule {
  field: string;
  type: 'required' | 'type' | 'format' | 'range' | 'custom';
  value?: any;
  message: string;
  validator?: (value: any) => boolean;
}

export interface SchemaValidation {
  serviceName: string;
  operationType: string;
  requestSchema?: ValidationRule[];
  responseSchema?: ValidationRule[];
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface ApiValidationReport {
  endpoint: string;
  requestValidation: ValidationResult;
  responseValidation: ValidationResult;
  overallStatus: 'PASS' | 'FAIL' | 'WARNING';
}

export class RequestResponseValidationService {
  private schemaRegistry: Map<string, SchemaValidation> = new Map();

  constructor() {
    this.initializeStandardSchemas();
  }

  /**
   * Initialize standard validation schemas for common operations
   */
  private initializeStandardSchemas(): void {
    // Customer service schemas
    this.registerSchema({
      serviceName: 'customerService',
      operationType: 'CREATE',
      requestSchema: [
      { field: 'name', type: 'required', message: 'Customer name is required' },
      { field: 'email', type: 'format', value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Valid email format required' },
      { field: 'phone', type: 'format', value: /^\+?[\d\s\-()]+$/, message: 'Valid phone format required' }],

      responseSchema: [
      { field: 'id', type: 'required', message: 'Customer ID should be returned' },
      { field: 'name', type: 'required', message: 'Customer name should be returned' },
      { field: 'email', type: 'required', message: 'Customer email should be returned' }]

    });

    // Product service schemas
    this.registerSchema({
      serviceName: 'productService',
      operationType: 'CREATE',
      requestSchema: [
      { field: 'name', type: 'required', message: 'Product name is required' },
      { field: 'costPrice', type: 'type', value: 'number', message: 'Cost price must be a number' },
      { field: 'sellingPrice', type: 'type', value: 'number', message: 'Selling price must be a number' },
      { field: 'stockLevel', type: 'range', value: [0, Infinity], message: 'Stock level must be non-negative' }],

      responseSchema: [
      { field: 'id', type: 'required', message: 'Product ID should be returned' },
      { field: 'sku', type: 'required', message: 'Product SKU should be generated' }]

    });

    // Supplier service schemas
    this.registerSchema({
      serviceName: 'supplierService',
      operationType: 'CREATE',
      requestSchema: [
      { field: 'name', type: 'required', message: 'Supplier name is required' },
      { field: 'email', type: 'format', value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Valid email format required' }],

      responseSchema: [
      { field: 'id', type: 'required', message: 'Supplier ID should be returned' }]

    });

    // Employee service schemas
    this.registerSchema({
      serviceName: 'employeeService',
      operationType: 'CREATE',
      requestSchema: [
      { field: 'firstName', type: 'required', message: 'First name is required' },
      { field: 'lastName', type: 'required', message: 'Last name is required' },
      { field: 'email', type: 'format', value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Valid email format required' },
      { field: 'salary', type: 'range', value: [0, Infinity], message: 'Salary must be non-negative' }],

      responseSchema: [
      { field: 'id', type: 'required', message: 'Employee ID should be returned' }]

    });

    // READ operation schemas (common for all services)
    ['customerService', 'productService', 'supplierService', 'employeeService', 'invoiceService'].forEach((serviceName) => {
      this.registerSchema({
        serviceName,
        operationType: 'READ',
        responseSchema: [
        { field: 'id', type: 'required', message: 'ID field should be present in response' }]

      });
    });
  }

  /**
   * Register a validation schema
   */
  registerSchema(schema: SchemaValidation): void {
    const key = `${schema.serviceName}_${schema.operationType}`;
    this.schemaRegistry.set(key, schema);
  }

  /**
   * Validate request data
   */
  validateRequest(serviceName: string, operationType: string, data: any): ValidationResult {
    const schema = this.getSchema(serviceName, operationType);
    if (!schema || !schema.requestSchema) {
      return { isValid: true, errors: [], warnings: ['No request validation schema found'] };
    }

    return this.validateData(data, schema.requestSchema);
  }

  /**
   * Validate response data
   */
  validateResponse(serviceName: string, operationType: string, data: any): ValidationResult {
    const schema = this.getSchema(serviceName, operationType);
    if (!schema || !schema.responseSchema) {
      return { isValid: true, errors: [], warnings: ['No response validation schema found'] };
    }

    // Handle array responses (like getAll operations)
    if (Array.isArray(data)) {
      if (data.length === 0) {
        return { isValid: true, errors: [], warnings: ['Empty array response'] };
      }
      // Validate first item in array as sample
      return this.validateData(data[0], schema.responseSchema);
    }

    // Handle null responses (valid for getById operations)
    if (data === null) {
      return { isValid: true, errors: [], warnings: ['Null response (may be valid for not found cases)'] };
    }

    return this.validateData(data, schema.responseSchema);
  }

  /**
   * Validate API endpoint comprehensively
   */
  async validateApiEndpoint(
  endpoint: ServiceEndpoint,
  testCase: TestCase,
  requestData: any,
  responseData: any)
  : Promise<ApiValidationReport> {
    const endpointId = `${endpoint.serviceName}.${endpoint.methodName}`;

    const requestValidation = this.validateRequest(
      endpoint.serviceName,
      endpoint.operationType,
      requestData
    );

    const responseValidation = this.validateResponse(
      endpoint.serviceName,
      endpoint.operationType,
      responseData
    );

    // Additional endpoint-specific validations
    const additionalValidations = this.performAdditionalValidations(
      endpoint,
      requestData,
      responseData
    );

    // Merge additional validations
    requestValidation.errors.push(...additionalValidations.requestErrors);
    requestValidation.warnings.push(...additionalValidations.requestWarnings);
    responseValidation.errors.push(...additionalValidations.responseErrors);
    responseValidation.warnings.push(...additionalValidations.responseWarnings);

    const overallStatus = this.determineOverallStatus(requestValidation, responseValidation);

    return {
      endpoint: endpointId,
      requestValidation,
      responseValidation,
      overallStatus
    };
  }

  /**
   * Perform additional endpoint-specific validations
   */
  private performAdditionalValidations(
  endpoint: ServiceEndpoint,
  requestData: any,
  responseData: any)
  : {
    requestErrors: string[];
    requestWarnings: string[];
    responseErrors: string[];
    responseWarnings: string[];
  } {
    const result = {
      requestErrors: [],
      requestWarnings: [],
      responseErrors: [],
      responseWarnings: []
    };

    // Check for SQL injection patterns in string fields
    if (requestData && typeof requestData === 'object') {
      this.checkForSqlInjection(requestData, result.requestWarnings);
    }

    // Check response performance patterns
    if (Array.isArray(responseData) && responseData.length > 1000) {
      result.responseWarnings.push('Large response dataset (>1000 items) - consider pagination');
    }

    // Check for sensitive data in responses
    if (responseData && typeof responseData === 'object') {
      this.checkForSensitiveData(responseData, result.responseWarnings);
    }

    // Validate CRUD operation consistency
    this.validateCrudConsistency(endpoint, requestData, responseData, result);

    return result;
  }

  /**
   * Check for potential SQL injection patterns
   */
  private checkForSqlInjection(data: any, warnings: string[]): void {
    const sqlPatterns = [
    /(\bSELECT\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bDROP\b|\bCREATE\b)/i,
    /(--|\|)/,
    /(\bunion\b|\band\b|\bor\b).*(\d+=\d+|\w+=\w+)/i];


    const checkValue = (value: any, path: string) => {
      if (typeof value === 'string') {
        sqlPatterns.forEach((pattern) => {
          if (pattern.test(value)) {
            warnings.push(`Potential SQL injection pattern detected in ${path}: ${value.substring(0, 50)}`);
          }
        });
      } else if (typeof value === 'object' && value !== null) {
        Object.entries(value).forEach(([key, val]) => {
          checkValue(val, `${path}.${key}`);
        });
      }
    };

    if (Array.isArray(data)) {
      data.forEach((item, index) => checkValue(item, `[${index}]`));
    } else {
      Object.entries(data).forEach(([key, value]) => checkValue(value, key));
    }
  }

  /**
   * Check for sensitive data in responses
   */
  private checkForSensitiveData(data: any, warnings: string[]): void {
    const sensitiveFields = ['password', 'token', 'secret', 'key', 'ssn', 'creditcard'];

    const checkObject = (obj: any, path: string = '') => {
      if (typeof obj === 'object' && obj !== null) {
        Object.keys(obj).forEach((key) => {
          const lowerKey = key.toLowerCase();
          if (sensitiveFields.some((field) => lowerKey.includes(field))) {
            warnings.push(`Potentially sensitive field in response: ${path}${key}`);
          }
          if (typeof obj[key] === 'object') {
            checkObject(obj[key], `${path}${key}.`);
          }
        });
      }
    };

    if (Array.isArray(data)) {
      data.forEach((item, index) => checkObject(item, `[${index}].`));
    } else {
      checkObject(data);
    }
  }

  /**
   * Validate CRUD operation consistency
   */
  private validateCrudConsistency(
  endpoint: ServiceEndpoint,
  requestData: any,
  responseData: any,
  result: any)
  : void {
    switch (endpoint.operationType) {
      case 'CREATE':
        if (requestData && responseData && requestData.name && responseData.name) {
          if (requestData.name !== responseData.name) {
            result.responseWarnings.push('Created entity name differs from requested name');
          }
        }
        if (responseData && !responseData.id && !responseData.ID) {
          result.responseErrors.push('CREATE operation should return entity with ID');
        }
        break;

      case 'UPDATE':
        if (requestData && responseData && requestData.updates) {
          Object.keys(requestData.updates).forEach((key) => {
            if (responseData[key] !== undefined && responseData[key] !== requestData.updates[key]) {
              result.responseWarnings.push(`Updated field ${key} value differs from requested value`);
            }
          });
        }
        break;

      case 'READ':
        if (endpoint.methodName.toLowerCase().includes('getall') && !Array.isArray(responseData)) {
          result.responseErrors.push('getAll operation should return an array');
        }
        if (endpoint.methodName.toLowerCase().includes('getbyid') && Array.isArray(responseData)) {
          result.responseErrors.push('getById operation should not return an array');
        }
        break;
    }
  }

  /**
   * Generic data validation against schema rules
   */
  private validateData(data: any, rules: ValidationRule[]): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    if (!data) {
      rules.forEach((rule) => {
        if (rule.type === 'required') {
          errors.push(rule.message);
        }
      });
      return { isValid: errors.length === 0, errors, warnings };
    }

    rules.forEach((rule) => {
      const value = this.getNestedValue(data, rule.field);

      switch (rule.type) {
        case 'required':
          if (value === undefined || value === null || value === '') {
            errors.push(rule.message);
          }
          break;

        case 'type':
          if (value !== undefined && value !== null) {
            if (typeof value !== rule.value) {
              errors.push(rule.message);
            }
          }
          break;

        case 'format':
          if (value !== undefined && value !== null && typeof value === 'string') {
            if (rule.value instanceof RegExp && !rule.value.test(value)) {
              errors.push(rule.message);
            }
          }
          break;

        case 'range':
          if (value !== undefined && value !== null && typeof value === 'number') {
            const [min, max] = rule.value as [number, number];
            if (value < min || value > max) {
              errors.push(rule.message);
            }
          }
          break;

        case 'custom':
          if (rule.validator && value !== undefined && value !== null) {
            if (!rule.validator(value)) {
              errors.push(rule.message);
            }
          }
          break;
      }
    });

    return { isValid: errors.length === 0, errors, warnings };
  }

  /**
   * Get nested value from object using dot notation
   */
  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, key) => current?.[key], obj);
  }

  /**
   * Get validation schema for service and operation
   */
  private getSchema(serviceName: string, operationType: string): SchemaValidation | null {
    const key = `${serviceName}_${operationType}`;
    return this.schemaRegistry.get(key) || null;
  }

  /**
   * Determine overall validation status
   */
  private determineOverallStatus(
  requestValidation: ValidationResult,
  responseValidation: ValidationResult)
  : 'PASS' | 'FAIL' | 'WARNING' {
    if (!requestValidation.isValid || !responseValidation.isValid) {
      return 'FAIL';
    }
    if (requestValidation.warnings.length > 0 || responseValidation.warnings.length > 0) {
      return 'WARNING';
    }
    return 'PASS';
  }

  /**
   * Get all registered schemas
   */
  getAllSchemas(): SchemaValidation[] {
    return Array.from(this.schemaRegistry.values());
  }

  /**
   * Generate validation report for multiple endpoints
   */
  async validateMultipleEndpoints(
  validationData: Array<{
    endpoint: ServiceEndpoint;
    testCase: TestCase;
    requestData: any;
    responseData: any;
  }>)
  : Promise<ApiValidationReport[]> {
    const reports: ApiValidationReport[] = [];

    for (const data of validationData) {
      try {
        const report = await this.validateApiEndpoint(
          data.endpoint,
          data.testCase,
          data.requestData,
          data.responseData
        );
        reports.push(report);
      } catch (error) {
        console.error(`Validation failed for ${data.endpoint.serviceName}.${data.endpoint.methodName}:`, error);
      }
    }

    return reports;
  }
}

export const requestResponseValidationService = new RequestResponseValidationService();