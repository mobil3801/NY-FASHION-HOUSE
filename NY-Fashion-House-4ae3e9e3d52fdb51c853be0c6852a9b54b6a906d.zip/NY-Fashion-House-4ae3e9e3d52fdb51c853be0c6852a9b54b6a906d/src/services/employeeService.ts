import { Employee, EmployeeRole, Attendance, PerformanceNote, EmployeeStats, Permission } from '@/types/employee';

const EMPLOYEES_TABLE_ID = 37818; // Table ID from the created table

// Helper function to convert database record to Employee interface
const mapDbToEmployee = (record: any): Employee => ({
  id: record.id?.toString() || '',
  firstName: record.first_name || '',
  lastName: record.last_name || '',
  email: record.email || '',
  phone: record.phone || '',
  position: record.position || '',
  department: record.department || '',
  hireDate: record.hire_date ? new Date(record.hire_date).toISOString().split('T')[0] : '',
  salary: record.salary || 0,
  employmentStatus: record.employment_status || 'active',
  roleId: record.role_id || '',
  address: {
    street: record.address_street || '',
    city: record.address_city || '',
    state: record.address_state || '',
    zipCode: record.address_zip_code || '',
    country: record.address_country || ''
  },
  emergencyContact: {
    name: record.emergency_contact_name || '',
    relationship: record.emergency_contact_relationship || '',
    phone: record.emergency_contact_phone || '',
    email: record.emergency_contact_email || ''
  },
  photoUrl: record.photo_url || undefined,
  photoIdFileId: record.photo_id_file_id || undefined,
  photoIdType: record.photo_id_type as 'Passport' | 'Driving License' | 'National ID' || undefined,
  notes: record.notes || '',
  createdAt: record.created_at || new Date().toISOString(),
  updatedAt: record.updated_at || new Date().toISOString()
});

// Helper function to convert Employee interface to database record
const mapEmployeeToDb = (employee: Omit<Employee, 'id' | 'createdAt' | 'updatedAt'> | Partial<Employee>) => ({
  first_name: employee.firstName,
  last_name: employee.lastName,
  email: employee.email,
  phone: employee.phone,
  position: employee.position,
  department: employee.department,
  hire_date: employee.hireDate,
  salary: employee.salary,
  employment_status: employee.employmentStatus,
  role_id: employee.roleId,
  address_street: employee.address?.street,
  address_city: employee.address?.city,
  address_state: employee.address?.state,
  address_zip_code: employee.address?.zipCode,
  address_country: employee.address?.country,
  emergency_contact_name: employee.emergencyContact?.name,
  emergency_contact_relationship: employee.emergencyContact?.relationship,
  emergency_contact_phone: employee.emergencyContact?.phone,
  emergency_contact_email: employee.emergencyContact?.email,
  photo_url: employee.photoUrl,
  photo_id_file_id: employee.photoIdFileId,
  photo_id_type: employee.photoIdType,
  notes: employee.notes,
  updated_at: new Date().toISOString()
});

export const employeeService = {
  // Get all employees
  getAllEmployees: async (): Promise<Employee[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(EMPLOYEES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);

      return data?.List?.map(mapDbToEmployee) || [];
    } catch (error) {
      console.error('Error fetching employees:', error);
      return [];
    }
  },

  // Get employee by ID
  getEmployeeById: async (id: string): Promise<Employee | null> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(EMPLOYEES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'id',
        IsAsc: true,
        Filters: [
        {
          name: 'id',
          op: 'Equal',
          value: parseInt(id)
        }]

      });

      if (error) throw new Error(error);

      const employee = data?.List?.[0];
      return employee ? mapDbToEmployee(employee) : null;
    } catch (error) {
      console.error('Error fetching employee:', error);
      return null;
    }
  },

  // Create new employee
  createEmployee: async (employee: Omit<Employee, 'id' | 'createdAt' | 'updatedAt'>): Promise<Employee> => {
    try {
      const dbRecord = {
        ...mapEmployeeToDb(employee),
        created_at: new Date().toISOString()
      };

      const { error } = await window.ezsite.apis.tableCreate(EMPLOYEES_TABLE_ID, dbRecord);

      if (error) throw new Error(error);

      // Fetch the created employee to return with ID
      const employees = await employeeService.getAllEmployees();
      const createdEmployee = employees.find((emp) => emp.email === employee.email);

      if (!createdEmployee) {
        throw new Error('Failed to retrieve created employee');
      }

      return createdEmployee;
    } catch (error) {
      console.error('Error creating employee:', error);
      throw error;
    }
  },

  // Update employee
  updateEmployee: async (id: string, updates: Partial<Employee>): Promise<Employee> => {
    try {
      const dbRecord = {
        ID: parseInt(id),
        ...mapEmployeeToDb(updates)
      };

      const { error } = await window.ezsite.apis.tableUpdate(EMPLOYEES_TABLE_ID, dbRecord);

      if (error) throw new Error(error);

      // Fetch the updated employee
      const updatedEmployee = await employeeService.getEmployeeById(id);

      if (!updatedEmployee) {
        throw new Error('Failed to retrieve updated employee');
      }

      return updatedEmployee;
    } catch (error) {
      console.error('Error updating employee:', error);
      throw error;
    }
  },

  // Delete employee
  deleteEmployee: async (id: string): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.tableDelete(EMPLOYEES_TABLE_ID, {
        ID: parseInt(id)
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error deleting employee:', error);
      throw error;
    }
  },

  // Upload photo ID file
  uploadPhotoId: async (file: File): Promise<number> => {
    try {
      const { data, error } = await window.ezsite.apis.upload({
        filename: file.name,
        file: file
      });

      if (error) throw new Error(error);

      return data;
    } catch (error) {
      console.error('Error uploading photo ID:', error);
      throw error;
    }
  },

  // Get photo ID URL
  getPhotoIdUrl: async (fileId: number): Promise<string> => {
    try {
      const { data, error } = await window.ezsite.apis.getUploadUrl(fileId);

      if (error) throw new Error(error);

      return data;
    } catch (error) {
      console.error('Error getting photo ID URL:', error);
      throw error;
    }
  },

  // Role management - returns empty arrays for now
  getAllRoles: async (): Promise<EmployeeRole[]> => {
    return [];
  },

  getAllPermissions: async (): Promise<Permission[]> => {
    return [];
  },

  // Statistics
  getEmployeeStats: async (): Promise<EmployeeStats> => {
    try {
      const employees = await employeeService.getAllEmployees();
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();

      const newHiresThisMonth = employees.filter((emp) => {
        const hireDate = new Date(emp.hireDate);
        return hireDate.getMonth() === currentMonth && hireDate.getFullYear() === currentYear;
      }).length;

      const departmentBreakdown = employees.reduce((acc, emp) => {
        acc[emp.department] = (acc[emp.department] || 0) + 1;
        return acc;
      }, {} as {[key: string]: number;});

      const totalTenure = employees.reduce((acc, emp) => {
        const hireDate = new Date(emp.hireDate);
        const now = new Date();
        const years = (now.getTime() - hireDate.getTime()) / (1000 * 60 * 60 * 24 * 365);
        return acc + years;
      }, 0);

      return {
        totalEmployees: employees.length,
        activeEmployees: employees.filter((emp) => emp.employmentStatus === 'active').length,
        newHiresThisMonth,
        departmentBreakdown,
        averageTenure: employees.length > 0 ? totalTenure / employees.length : 0,
        attendanceRate: 0,
        performanceAverage: 0
      };
    } catch (error) {
      console.error('Error getting employee stats:', error);
      return {
        totalEmployees: 0,
        activeEmployees: 0,
        newHiresThisMonth: 0,
        departmentBreakdown: {},
        averageTenure: 0,
        attendanceRate: 0,
        performanceAverage: 0
      };
    }
  },

  // Empty implementations for attendance and performance
  getAttendanceByEmployee: async (employeeId: string): Promise<Attendance[]> => {
    return [];
  },

  createAttendance: async (attendance: Omit<Attendance, 'id' | 'createdAt' | 'updatedAt'>): Promise<Attendance> => {
    throw new Error('Attendance functionality not implemented');
  },

  getPerformanceNotesByEmployee: async (employeeId: string): Promise<PerformanceNote[]> => {
    return [];
  },

  createPerformanceNote: async (note: Omit<PerformanceNote, 'id' | 'createdAt' | 'updatedAt'>): Promise<PerformanceNote> => {
    throw new Error('Performance note functionality not implemented');
  },

  updatePerformanceNote: async (id: string, updates: Partial<PerformanceNote>): Promise<PerformanceNote> => {
    throw new Error('Performance note functionality not implemented');
  }
};