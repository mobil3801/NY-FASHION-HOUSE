import { Invoice } from '@/types/invoice';

export interface EmailOptions {
  to: string;
  subject: string;
  body: string;
  attachments?: {
    filename: string;
    content: string;
    contentType: string;
  }[];
}

export const emailService = {
  // Send invoice email
  sendInvoiceEmail: async (invoice: Invoice, recipientEmail: string, message?: string): Promise<boolean> => {
    try {
      const subject = `Invoice ${invoice.invoiceNumber} from Your Company`;
      const body = `
Dear ${invoice.customerName},

Please find attached your invoice ${invoice.invoiceNumber} for the amount of $${invoice.totalAmount.toFixed(2)}.

${message ? `Message from Your Company:\n${message}\n` : ''}

Payment is due by ${invoice.dueDate.toLocaleDateString()}.

If you have any questions about this invoice, please contact us at info@yourcompany.com or +1 234-567-8900.

Thank you for your business!

Best regards,
Your Company Team
      `.trim();

      console.log('Email would be sent:', {
        to: recipientEmail,
        subject,
        body,
        invoice: invoice.invoiceNumber
      });

      // TODO: Integrate with real email service (SendGrid, AWS SES, etc.)
      // For now, we'll simulate success
      return true;
    } catch (error) {
      console.error('Error sending invoice email:', error);
      return false;
    }
  },

  // Send payment reminder
  sendPaymentReminder: async (invoice: Invoice, recipientEmail: string): Promise<boolean> => {
    try {
      const isOverdue = invoice.dueDate < new Date();
      const subject = isOverdue ?
      `Overdue Invoice ${invoice.invoiceNumber} - Payment Required` :
      `Payment Reminder: Invoice ${invoice.invoiceNumber}`;

      const body = `
Dear ${invoice.customerName},

This is a ${isOverdue ? 'final notice' : 'friendly reminder'} that your invoice ${invoice.invoiceNumber} has ${isOverdue ? 'an overdue' : 'an upcoming'} payment due.

Invoice Details:
- Invoice Number: ${invoice.invoiceNumber}
- Amount: $${invoice.totalAmount.toFixed(2)}
- Amount Paid: $${invoice.paidAmount.toFixed(2)}
- Amount Due: $${invoice.remainingAmount.toFixed(2)}
- Due Date: ${invoice.dueDate.toLocaleDateString()}
${isOverdue ? `- Days Overdue: ${Math.floor((new Date().getTime() - invoice.dueDate.getTime()) / (1000 * 60 * 60 * 24))}` : ''}

Please arrange payment at your earliest convenience. If you have already made this payment, please disregard this notice.

If you have any questions or need to discuss payment arrangements, please contact us immediately at info@yourcompany.com or +1 234-567-8900.

Thank you for your prompt attention to this matter.

Best regards,
Your Company Team
      `.trim();

      console.log('Payment reminder would be sent:', {
        to: recipientEmail,
        subject,
        body,
        invoice: invoice.invoiceNumber,
        isOverdue
      });

      // TODO: Integrate with real email service
      return true;
    } catch (error) {
      console.error('Error sending payment reminder:', error);
      return false;
    }
  },

  // Validate email address
  validateEmail: (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  // Send generic email
  sendEmail: async (options: EmailOptions): Promise<boolean> => {
    try {
      console.log('Email would be sent:', options);

      // TODO: Integrate with real email service provider
      // Example integration patterns:

      // For SendGrid:
      // const sgMail = require('@sendgrid/mail');
      // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
      // await sgMail.send(msg);

      // For AWS SES:
      // const AWS = require('aws-sdk');
      // const ses = new AWS.SES();
      // await ses.sendEmail(params).promise();

      // For Nodemailer:
      // const nodemailer = require('nodemailer');
      // const transporter = nodemailer.createTransporter(config);
      // await transporter.sendMail(mailOptions);

      return true;
    } catch (error) {
      console.error('Error sending email:', error);
      return false;
    }
  },

  // Send bulk emails
  sendBulkEmails: async (emails: EmailOptions[]): Promise<{sent: number;failed: number;}> => {
    let sent = 0;
    let failed = 0;

    for (const email of emails) {
      try {
        const success = await emailService.sendEmail(email);
        if (success) {
          sent++;
        } else {
          failed++;
        }
      } catch (error) {
        console.error('Error sending bulk email:', error);
        failed++;
      }
    }

    return { sent, failed };
  },

  // Get email templates
  getInvoiceEmailTemplate: (invoice: Invoice, customMessage?: string): EmailOptions => {
    return {
      to: '', // Will be set by caller
      subject: `Invoice ${invoice.invoiceNumber} from Your Company`,
      body: `
Dear ${invoice.customerName},

Please find attached your invoice ${invoice.invoiceNumber} for the amount of $${invoice.totalAmount.toFixed(2)}.

${customMessage ? `${customMessage}\n` : ''}

Payment is due by ${invoice.dueDate.toLocaleDateString()}.

Thank you for your business!

Best regards,
Your Company Team
      `.trim()
    };
  },

  getPaymentReminderTemplate: (invoice: Invoice): EmailOptions => {
    const isOverdue = invoice.dueDate < new Date();

    return {
      to: '', // Will be set by caller
      subject: isOverdue ?
      `Overdue Invoice ${invoice.invoiceNumber} - Payment Required` :
      `Payment Reminder: Invoice ${invoice.invoiceNumber}`,
      body: `
Dear ${invoice.customerName},

This is a ${isOverdue ? 'final notice' : 'friendly reminder'} regarding invoice ${invoice.invoiceNumber}.

Amount Due: $${invoice.remainingAmount.toFixed(2)}
Due Date: ${invoice.dueDate.toLocaleDateString()}

Please arrange payment at your earliest convenience.

Best regards,
Your Company Team
      `.trim()
    };
  }
};