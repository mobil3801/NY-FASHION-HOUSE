// Updated userService with proper API calls and error handling
import { User } from '@/types/user';

const USERS_TABLE_ID = 37706; // easysite_auth_users table
const ROLES_TABLE_ID = 37707; // easysite_roles table

export const userService = {
  // Get users with pagination and filters
  getUsers: async (
  pageNo: number = 1,
  pageSize: number = 50,
  filters: any = {})
  : Promise<{users: User[];totalCount: number;}> => {
    try {
      const queryFilters = [];
      if (filters.search) {
        queryFilters.push(
          { name: 'name', op: 'StringContains', value: filters.search },
          { name: 'email', op: 'StringContains', value: filters.search }
        );
      }

      if (filters.roleId) {
        queryFilters.push({ name: 'role_id', op: 'Equal', value: filters.roleId });
      }

      const { data, error } = await window.ezsite.apis.tablePage(USERS_TABLE_ID, {
        PageNo: pageNo,
        PageSize: pageSize,
        OrderByField: 'create_time',
        IsAsc: false,
        Filters: queryFilters
      });

      if (error) throw new Error(error);

      const users: User[] = (data?.List || []).map((record: any) => ({
        id: record.id || 0,
        name: record.name || '',
        email: record.email || '',
        phone_number: record.phone_number || '',
        is_activated: record.is_activated !== false,
        role_id: record.role_id || null,
        role_name: record.role_name || 'No Role',
        role_code: record.role_code || '',
        create_time: record.create_time || new Date().toISOString()
      }));

      return {
        users,
        totalCount: data?.VirtualCount || 0
      };
    } catch (error) {
      console.error('Error fetching users:', error);
      throw error;
    }
  },

  // Get roles for user assignment
  getRoles: async (): Promise<any[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(ROLES_TABLE_ID, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'name',
        IsAsc: true,
        Filters: []
      });

      if (error) throw new Error(error);

      return (data?.List || []).map((role: any) => ({
        id: role.id,
        name: role.name || '',
        code: role.code || '',
        remark: role.remark || ''
      }));
    } catch (error) {
      console.error('Error fetching roles:', error);
      throw error;
    }
  },

  // Create new user
  createUser: async (userData: any): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.register({
        email: userData.email,
        password: userData.password || 'DefaultPassword123!'
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  },

  // Update user
  updateUser: async (id: number, updates: any): Promise<void> => {
    try {
      const updateData: any = { ID: id };

      if (updates.name !== undefined) updateData.name = updates.name;
      if (updates.email !== undefined) updateData.email = updates.email;
      if (updates.phoneNumber !== undefined) updateData.phone_number = updates.phoneNumber;
      if (updates.roleId !== undefined) updateData.role_id = updates.roleId;
      if (updates.isActivated !== undefined) updateData.is_activated = updates.isActivated;

      const { error } = await window.ezsite.apis.tableUpdate(USERS_TABLE_ID, updateData);

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  },

  // Delete user
  deleteUser: async (id: number): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.tableDelete(USERS_TABLE_ID, { ID: id });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  },

  // Toggle user activation
  toggleUserActivation: async (id: number, isActivated: boolean): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.tableUpdate(USERS_TABLE_ID, {
        ID: id,
        is_activated: isActivated
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error toggling user activation:', error);
      throw error;
    }
  },

  // Send password reset
  sendPasswordReset: async (email: string): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.sendResetPwdEmail({ email });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error sending password reset:', error);
      throw error;
    }
  }
};