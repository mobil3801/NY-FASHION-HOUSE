import { enhancedDevToolsErrorService } from './enhancedDevToolsErrorService';
import { comprehensiveErrorTrackingService } from './comprehensiveErrorTrackingService';
import { automatedErrorAnalyzer } from './automatedErrorAnalyzer';

export interface ErrorMetadata {
  id: string;
  timestamp: Date;
  level: 'info' | 'warn' | 'error' | 'critical';
  category: 'ui' | 'api' | 'performance' | 'security' | 'network' | 'validation';
  component?: string;
  userId?: string;
  sessionId: string;
  url: string;
  userAgent: string;
  stackTrace?: string;
  componentStack?: string;
  errorBoundary?: string;
  context: Record<string, any>;
  performance?: {
    memory?: number;
    timing?: number;
    renderTime?: number;
  };
  devTools?: {
    sourceMap?: string;
    originalError?: Error;
    debugInfo?: any;
  };
}

export interface ErrorPattern {
  pattern: string;
  frequency: number;
  lastOccurrence: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
  components: string[];
  suggestedFix?: string;
}

export interface ErrorAnalysis {
  totalErrors: number;
  errorsByCategory: Record<string, number>;
  errorsByComponent: Record<string, number>;
  topPatterns: ErrorPattern[];
  criticalErrors: ErrorMetadata[];
  recommendations: string[];
}

class ComprehensiveErrorManager {
  private errors: Map<string, ErrorMetadata> = new Map();
  private patterns: Map<string, ErrorPattern> = new Map();
  private subscribers: ((error: ErrorMetadata) => void)[] = [];
  private performanceThreshold = 100; // ms
  private batchSize = 10;
  private batchTimeout = 5000;
  private errorQueue: ErrorMetadata[] = [];
  private batchTimer?: NodeJS.Timeout;

  constructor() {
    this.initializeErrorCapture();
    this.startPeriodicAnalysis();
  }

  private initializeErrorCapture(): void {
    // Global error handlers
    window.addEventListener('error', this.handleGlobalError.bind(this));
    window.addEventListener('unhandledrejection', this.handleUnhandledRejection.bind(this));

    // React error boundary integration
    (window as any).__REACT_ERROR_OVERLAY_GLOBAL_HOOK__ = (error: Error, errorInfo: any) => {
      this.captureError(error, {
        category: 'ui',
        level: 'error',
        component: errorInfo?.componentStack?.split('\n')[0]?.trim(),
        componentStack: errorInfo?.componentStack,
        context: { errorInfo }
      });
    };

    // Console error capture
    const originalConsoleError = console.error;
    console.error = (...args: any[]) => {
      originalConsoleError.apply(console, args);
      this.captureConsoleError(args);
    };
  }

  private handleGlobalError(event: ErrorEvent): void {
    this.captureError(event.error || new Error(event.message), {
      category: 'ui',
      level: 'error',
      context: {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        source: 'global'
      }
    });
  }

  private handleUnhandledRejection(event: PromiseRejectionEvent): void {
    const error = event.reason instanceof Error ? event.reason : new Error(String(event.reason));
    this.captureError(error, {
      category: 'network',
      level: 'error',
      context: {
        source: 'unhandledRejection',
        reason: event.reason
      }
    });
  }

  private captureConsoleError(args: any[]): void {
    const message = args.map((arg) => typeof arg === 'object' ? JSON.stringify(arg) : String(arg)).join(' ');
    this.captureError(new Error(message), {
      category: 'ui',
      level: 'warn',
      context: {
        source: 'console',
        arguments: args
      }
    });
  }

  public captureError(error: Error, options: Partial<ErrorMetadata> = {}): string {
    const startTime = performance.now();

    try {
      const errorId = this.generateErrorId();
      const sessionId = this.getSessionId();

      const metadata: ErrorMetadata = {
        id: errorId,
        timestamp: new Date(),
        level: options.level || 'error',
        category: options.category || 'ui',
        component: options.component,
        userId: this.getUserId(),
        sessionId,
        url: window.location.href,
        userAgent: navigator.userAgent,
        stackTrace: error.stack,
        componentStack: options.componentStack,
        errorBoundary: options.errorBoundary,
        context: {
          message: error.message,
          name: error.name,
          ...options.context
        },
        performance: {
          memory: this.getMemoryUsage(),
          timing: performance.now() - startTime,
          renderTime: options.performance?.renderTime
        },
        devTools: {
          originalError: error,
          debugInfo: enhancedDevToolsErrorService.collectDebugInfo(error),
          ...options.devTools
        }
      };

      // Store error
      this.errors.set(errorId, metadata);

      // Update patterns
      this.updateErrorPatterns(metadata);

      // Add to batch queue
      this.addToBatch(metadata);

      // Notify subscribers
      this.notifySubscribers(metadata);

      // Development-specific logging
      if (process.env.NODE_ENV === 'development') {
        this.logDevelopmentError(metadata);
      }

      return errorId;
    } catch (captureError) {
      console.error('Error in error capture:', captureError);
      return 'capture-failed';
    }
  }

  private updateErrorPatterns(metadata: ErrorMetadata): void {
    const pattern = this.extractErrorPattern(metadata);
    const existing = this.patterns.get(pattern);

    if (existing) {
      existing.frequency++;
      existing.lastOccurrence = metadata.timestamp;
      if (metadata.component && !existing.components.includes(metadata.component)) {
        existing.components.push(metadata.component);
      }
    } else {
      this.patterns.set(pattern, {
        pattern,
        frequency: 1,
        lastOccurrence: metadata.timestamp,
        severity: this.calculateSeverity(metadata),
        components: metadata.component ? [metadata.component] : [],
        suggestedFix: this.generateSuggestedFix(metadata)
      });
    }
  }

  private extractErrorPattern(metadata: ErrorMetadata): string {
    const message = metadata.context.message || '';
    const component = metadata.component || 'unknown';

    // Normalize error message to create pattern
    const normalized = message.
    replace(/\d+/g, '[NUMBER]').
    replace(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/g, '[UUID]').
    replace(/https?:\/\/[^\s]+/g, '[URL]');

    return `${component}:${normalized}`;
  }

  private calculateSeverity(metadata: ErrorMetadata): 'low' | 'medium' | 'high' | 'critical' {
    if (metadata.level === 'critical') return 'critical';
    if (metadata.category === 'security') return 'critical';
    if (metadata.level === 'error' && metadata.category === 'api') return 'high';
    if (metadata.level === 'error') return 'medium';
    return 'low';
  }

  private generateSuggestedFix(metadata: ErrorMetadata): string {
    const message = metadata.context.message?.toLowerCase() || '';
    const component = metadata.component || '';

    if (message.includes('network') || message.includes('fetch')) {
      return 'Check network connectivity and API endpoints';
    }
    if (message.includes('permission') || message.includes('unauthorized')) {
      return 'Verify user permissions and authentication';
    }
    if (message.includes('render') || component.includes('Component')) {
      return 'Check component props and state management';
    }
    if (message.includes('undefined') || message.includes('null')) {
      return 'Add null checks and default values';
    }
    return 'Review error context and implement appropriate handling';
  }

  private addToBatch(metadata: ErrorMetadata): void {
    this.errorQueue.push(metadata);

    if (this.errorQueue.length >= this.batchSize) {
      this.processBatch();
    } else if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.processBatch();
      }, this.batchTimeout);
    }
  }

  private processBatch(): void {
    if (this.errorQueue.length === 0) return;

    const batch = [...this.errorQueue];
    this.errorQueue = [];

    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = undefined;
    }

    // Process batch asynchronously
    this.processBatchAsync(batch);
  }

  private async processBatchAsync(batch: ErrorMetadata[]): Promise<void> {
    try {
      // Send to external logging service in production
      if (process.env.NODE_ENV === 'production') {
        await this.sendToLoggingService(batch);
      }

      // Update comprehensive tracking
      await comprehensiveErrorTrackingService.processBatch(batch);

      // Analyze for patterns
      this.analyzeErrorBatch(batch);
    } catch (error) {
      console.error('Error processing batch:', error);
    }
  }

  private async sendToLoggingService(batch: ErrorMetadata[]): Promise<void> {
















    // Implementation for external logging service
    // This would typically send to services like LogRocket, Sentry, etc.
  }private analyzeErrorBatch(batch: ErrorMetadata[]): void {batch.forEach((error) => {automatedErrorAnalyzer.analyzeError(error);});}private startPeriodicAnalysis(): void {setInterval(() => {this.performPeriodicAnalysis();}, 60000); // Every minute
  }private performPeriodicAnalysis(): void {const analysis = this.generateAnalysis(); // Check for critical patterns
    const criticalPatterns = Array.from(this.patterns.values()).
    filter((p) => p.severity === 'critical' || p.frequency > 10);

    if (criticalPatterns.length > 0) {
      this.handleCriticalPatterns(criticalPatterns);
    }
  }

  private handleCriticalPatterns(patterns: ErrorPattern[]): void {
    console.warn('Critical error patterns detected:', patterns);

    // Notify monitoring systems
    patterns.forEach((pattern) => {
      this.notifySubscribers({
        id: `pattern-${Date.now()}`,
        timestamp: new Date(),
        level: 'critical',
        category: 'ui',
        sessionId: this.getSessionId(),
        url: window.location.href,
        userAgent: navigator.userAgent,
        context: {
          pattern: pattern.pattern,
          frequency: pattern.frequency,
          suggestedFix: pattern.suggestedFix
        }
      } as ErrorMetadata);
    });
  }

  public generateAnalysis(): ErrorAnalysis {
    const errors = Array.from(this.errors.values());
    const patterns = Array.from(this.patterns.values());

    const errorsByCategory = errors.reduce((acc, error) => {
      acc[error.category] = (acc[error.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const errorsByComponent = errors.reduce((acc, error) => {
      if (error.component) {
        acc[error.component] = (acc[error.component] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);

    const criticalErrors = errors.filter((e) => e.level === 'critical');
    const topPatterns = patterns.
    sort((a, b) => b.frequency - a.frequency).
    slice(0, 10);

    return {
      totalErrors: errors.length,
      errorsByCategory,
      errorsByComponent,
      topPatterns,
      criticalErrors,
      recommendations: this.generateRecommendations(errors, patterns)
    };
  }

  private generateRecommendations(errors: ErrorMetadata[], patterns: ErrorPattern[]): string[] {
    const recommendations: string[] = [];

    // High-frequency pattern recommendations
    patterns.
    filter((p) => p.frequency > 5).
    forEach((pattern) => {
      if (pattern.suggestedFix) {
        recommendations.push(`${pattern.pattern}: ${pattern.suggestedFix}`);
      }
    });

    // Category-based recommendations
    const categoryErrors = errors.reduce((acc, error) => {
      acc[error.category] = (acc[error.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    if (categoryErrors.network > 5) {
      recommendations.push('Consider implementing retry logic and better network error handling');
    }

    if (categoryErrors.performance > 3) {
      recommendations.push('Review component rendering performance and consider optimization');
    }

    return recommendations.slice(0, 10);
  }

  public subscribe(callback: (error: ErrorMetadata) => void): () => void {
    this.subscribers.push(callback);
    return () => {
      const index = this.subscribers.indexOf(callback);
      if (index > -1) {
        this.subscribers.splice(index, 1);
      }
    };
  }

  private notifySubscribers(error: ErrorMetadata): void {
    this.subscribers.forEach((callback) => {
      try {
        callback(error);
      } catch (error) {
        console.error('Error in error subscriber:', error);
      }
    });
  }

  private logDevelopmentError(metadata: ErrorMetadata): void {
    const devStyle = 'background: #ff6b6b; color: white; padding: 2px 4px; border-radius: 2px; font-weight: bold;';

    console.group(`%c[ERROR] ${metadata.category.toUpperCase()}`, devStyle);
    console.log('Message:', metadata.context.message);
    console.log('Component:', metadata.component);
    console.log('Timestamp:', metadata.timestamp.toISOString());
    console.log('Context:', metadata.context);

    if (metadata.stackTrace) {
      console.log('Stack Trace:', metadata.stackTrace);
    }

    if (metadata.devTools?.debugInfo) {
      console.log('Debug Info:', metadata.devTools.debugInfo);
    }

    console.groupEnd();
  }

  // Utility methods
  private generateErrorId(): string {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private getSessionId(): string {
    let sessionId = sessionStorage.getItem('error_session_id');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('error_session_id', sessionId);
    }
    return sessionId;
  }

  private getUserId(): string | undefined {
    try {
      const userInfo = localStorage.getItem('user_info');
      if (userInfo) {
        return JSON.parse(userInfo).ID;
      }
    } catch (error) {








      // Silent fail
    }return undefined;}private getMemoryUsage(): number {try {return (performance as any).memory?.usedJSHeapSize || 0;} catch (error) {return 0;
    }
  }

  // Public API methods
  public getErrors(filter?: Partial<ErrorMetadata>): ErrorMetadata[] {
    const errors = Array.from(this.errors.values());

    if (!filter) return errors;

    return errors.filter((error) => {
      return Object.entries(filter).every(([key, value]) => {
        return (error as any)[key] === value;
      });
    });
  }

  public getErrorPatterns(): ErrorPattern[] {
    return Array.from(this.patterns.values());
  }

  public clearErrors(): void {
    this.errors.clear();
    this.patterns.clear();
  }

  public exportErrors(): string {
    return JSON.stringify({
      errors: Array.from(this.errors.values()),
      patterns: Array.from(this.patterns.values()),
      analysis: this.generateAnalysis()
    }, null, 2);
  }
}

export const comprehensiveErrorManager = new ComprehensiveErrorManager();
export default comprehensiveErrorManager;