
import { SaleTransaction, SalesSummary, EmployeeSalesReport } from '../types/sales';
import { Employee } from '../types/employee';
import { Product } from '../types/product';
import { formatCurrency } from '../utils/currencyUtils';
import {
  format,
  startOfDay,
  endOfDay,
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
  subDays,
  subWeeks,
  subMonths,
  eachDayOfInterval,
  eachWeekOfInterval,
  eachMonthOfInterval,
  isValid } from
'date-fns';

export interface SalesAnalyticsData {
  totalSales: number;
  totalQuantity: number;
  totalTransactions: number;
  averageOrderValue: number;
  topProducts: Array<{
    productName: string;
    quantity: number;
    revenue: number;
  }>;
  categoryBreakdown: Array<{
    category: string;
    revenue: number;
    quantity: number;
    percentage: number;
  }>;
  employeePerformance: Array<{
    employeeId: number;
    employeeName: string;
    sales: number;
    quantity: number;
    transactions: number;
  }>;
}

export interface TrendData {
  period: string;
  sales: number;
  quantity: number;
  transactions: number;
}

export interface ComparisonData {
  current: SalesAnalyticsData;
  previous: SalesAnalyticsData;
  growth: {
    salesGrowth: number;
    quantityGrowth: number;
    transactionGrowth: number;
    avgOrderValueGrowth: number;
  };
}

export interface DailySalesData {
  date: string;
  employeeId: number;
  employeeName: string;
  shift: string;
  totalAmount: number;
  totalQuantity: number;
  productsCount: number;
  transactions: number;
}

const SALES_TRANSACTIONS_TABLE_ID = 38156;
const EMPLOYEES_TABLE_ID = 37818;
const PRODUCTS_TABLE_ID = 38157;

class ReportService {
  // Validate date parameters
  private validateDates(startDate: Date, endDate: Date): boolean {
    if (!startDate || !endDate || !isValid(startDate) || !isValid(endDate)) {
      console.error('[ReportService] Invalid dates provided:', { startDate, endDate });
      return false;
    }

    if (startDate > endDate) {
      console.error('[ReportService] Start date is after end date:', { startDate, endDate });
      return false;
    }

    // Check if date range is reasonable (not more than 2 years)
    const twoYears = 2 * 365 * 24 * 60 * 60 * 1000;
    if (endDate.getTime() - startDate.getTime() > twoYears) {
      console.warn('[ReportService] Date range is very large, this might cause performance issues');
    }

    return true;
  }

  // Safe API call wrapper with enhanced error handling
  private async safeApiCall<T>(
  operation: () => Promise<{data: any;error: any;}>,
  errorMessage: string,
  fallbackValue: T,
  retries: number = 1)
  : Promise<T> {
    let lastError: any = null;

    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const { data, error } = await operation();

        if (error) {
          lastError = new Error(error.toString());
          console.error(`[ReportService] API Error in ${errorMessage} (attempt ${attempt + 1}):`, error);

          if (attempt < retries) {
            // Wait before retry (exponential backoff)
            await new Promise((resolve) => setTimeout(resolve, Math.pow(2, attempt) * 1000));
            continue;
          }

          throw lastError;
        }

        if (!data) {
          console.warn(`[ReportService] No data returned from ${errorMessage}`);
          return fallbackValue;
        }

        return data.List || data || fallbackValue;
      } catch (error) {
        lastError = error;
        console.error(`[ReportService] Exception in ${errorMessage} (attempt ${attempt + 1}):`, error);

        if (attempt < retries) {
          // Wait before retry
          await new Promise((resolve) => setTimeout(resolve, Math.pow(2, attempt) * 1000));
          continue;
        }
      }
    }

    // If all retries failed, log the error and return fallback
    console.error(`[ReportService] All ${retries + 1} attempts failed for ${errorMessage}:`, lastError);
    return fallbackValue;
  }

  // Get sales data for a date range with validation and error handling
  async getSalesData(startDate: Date, endDate: Date): Promise<SaleTransaction[]> {
    if (!this.validateDates(startDate, endDate)) {
      throw new Error('Invalid date range provided');
    }

    try {
      console.log('[ReportService] Fetching sales data for range:', {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString()
      });

      const data = await this.safeApiCall(
        () => window.ezsite.apis.tablePage(SALES_TRANSACTIONS_TABLE_ID, {
          PageNo: 1,
          PageSize: 10000,
          OrderByField: "sale_date",
          IsAsc: false,
          Filters: [
          {
            name: "sale_date",
            op: "GreaterThanOrEqual",
            value: startDate.toISOString()
          },
          {
            name: "sale_date",
            op: "LessThanOrEqual",
            value: endDate.toISOString()
          }]

        }),
        'getSalesData',
        [],
        2 // Retry up to 2 times
      );

      console.log(`[ReportService] Retrieved ${data.length} sales records`);
      return data;
    } catch (error) {
      console.error('[ReportService] Error fetching sales data:', error);
      throw new Error('Failed to fetch sales data from database');
    }
  }

  // Get comprehensive sales analytics for a period with comprehensive error handling
  async getSalesAnalytics(startDate: Date, endDate: Date): Promise<SalesAnalyticsData> {
    if (!this.validateDates(startDate, endDate)) {
      throw new Error('Invalid date range provided for analytics');
    }

    try {
      console.log('[ReportService] Generating sales analytics for range:', {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString()
      });

      const salesData = await this.getSalesData(startDate, endDate);

      // Calculate totals with null safety
      const totalSales = salesData.reduce((sum, sale) => {
        const amount = parseFloat(sale.total_amount?.toString() || '0') || 0;
        return sum + amount;
      }, 0);

      const totalQuantity = salesData.reduce((sum, sale) => {
        const quantity = parseFloat(sale.quantity_sold?.toString() || '0') || 0;
        return sum + quantity;
      }, 0);

      const totalTransactions = salesData.length;
      const averageOrderValue = totalTransactions > 0 ? totalSales / totalTransactions : 0;

      // Top products analysis with null safety
      const productMap = new Map();
      salesData.forEach((sale) => {
        try {
          const key = sale.product_name?.toString() || 'Unknown Product';
          const quantity = parseFloat(sale.quantity_sold?.toString() || '0') || 0;
          const revenue = parseFloat(sale.total_amount?.toString() || '0') || 0;

          if (!productMap.has(key)) {
            productMap.set(key, { quantity: 0, revenue: 0 });
          }
          const product = productMap.get(key);
          product.quantity += quantity;
          product.revenue += revenue;
        } catch (error) {
          console.warn('[ReportService] Error processing product data for sale:', sale, error);
        }
      });

      const topProducts = Array.from(productMap.entries()).
      map(([productName, data]) => ({
        productName: productName || 'Unknown Product',
        quantity: data.quantity || 0,
        revenue: data.revenue || 0
      })).
      sort((a, b) => b.revenue - a.revenue).
      slice(0, 10);

      // Get category breakdown with error handling
      let categoryBreakdown = [];
      try {
        categoryBreakdown = await this.getCategoryBreakdown(salesData);
      } catch (error) {
        console.warn('[ReportService] Error getting category breakdown:', error);
        categoryBreakdown = [];
      }

      // Employee performance with null safety
      const employeeMap = new Map();
      salesData.forEach((sale) => {
        try {
          const employeeId = parseInt(sale.employee_id?.toString() || '0') || 0;
          const employeeName = sale.employee_name?.toString() || 'Unknown Employee';
          const saleAmount = parseFloat(sale.total_amount?.toString() || '0') || 0;
          const saleQuantity = parseFloat(sale.quantity_sold?.toString() || '0') || 0;

          if (!employeeMap.has(employeeId)) {
            employeeMap.set(employeeId, {
              employeeId,
              employeeName,
              sales: 0,
              quantity: 0,
              transactions: 0
            });
          }
          const emp = employeeMap.get(employeeId);
          emp.sales += saleAmount;
          emp.quantity += saleQuantity;
          emp.transactions += 1;
        } catch (error) {
          console.warn('[ReportService] Error processing employee data for sale:', sale, error);
        }
      });

      const employeePerformance = Array.from(employeeMap.values()).
      sort((a, b) => b.sales - a.sales);

      const result = {
        totalSales,
        totalQuantity,
        totalTransactions,
        averageOrderValue,
        topProducts,
        categoryBreakdown,
        employeePerformance
      };

      console.log('[ReportService] Sales analytics generated successfully:', {
        totalSales,
        totalQuantity,
        totalTransactions,
        topProductsCount: topProducts.length,
        categoryCount: categoryBreakdown.length,
        employeeCount: employeePerformance.length
      });

      return result;
    } catch (error) {
      console.error('[ReportService] Error generating sales analytics:', error);

      // Return safe fallback data instead of throwing
      return {
        totalSales: 0,
        totalQuantity: 0,
        totalTransactions: 0,
        averageOrderValue: 0,
        topProducts: [],
        categoryBreakdown: [],
        employeePerformance: []
      };
    }
  }

  // Get category breakdown from products with comprehensive error handling
  async getCategoryBreakdown(salesData: SaleTransaction[]): Promise<Array<{
    category: string;
    revenue: number;
    quantity: number;
    percentage: number;
  }>> {
    try {
      console.log('[ReportService] Generating category breakdown for', salesData.length, 'sales');

      // Get all products to map categories
      const products = await this.safeApiCall(
        () => window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
          PageNo: 1,
          PageSize: 10000,
          OrderByField: "id",
          IsAsc: true,
          Filters: []
        }),
        'getCategoryBreakdown - products',
        []
      );

      // Create product-category mapping with null safety
      const productCategoryMap = new Map();
      products.forEach((product: any) => {
        try {
          const id = parseInt(product.id?.toString() || '0');
          const category = product.category?.toString() || 'Uncategorized';
          if (id > 0) {
            productCategoryMap.set(id, category);
          }
        } catch (error) {
          console.warn('[ReportService] Error processing product category mapping:', product, error);
        }
      });

      // Aggregate by category with null safety
      const categoryMap = new Map();
      let totalRevenue = 0;

      salesData.forEach((sale) => {
        try {
          const productId = parseInt(sale.product_id?.toString() || '0');
          const category = productCategoryMap.get(productId) || 'Uncategorized';
          const revenue = parseFloat(sale.total_amount?.toString() || '0') || 0;
          const quantity = parseFloat(sale.quantity_sold?.toString() || '0') || 0;

          if (!categoryMap.has(category)) {
            categoryMap.set(category, { revenue: 0, quantity: 0 });
          }
          const cat = categoryMap.get(category);
          cat.revenue += revenue;
          cat.quantity += quantity;
          totalRevenue += revenue;
        } catch (error) {
          console.warn('[ReportService] Error processing category data for sale:', sale, error);
        }
      });

      const result = Array.from(categoryMap.entries()).map(([category, data]) => ({
        category: category || 'Unknown',
        revenue: data.revenue || 0,
        quantity: data.quantity || 0,
        percentage: totalRevenue > 0 ? data.revenue / totalRevenue * 100 : 0
      })).sort((a, b) => b.revenue - a.revenue);

      console.log('[ReportService] Category breakdown generated:', result.length, 'categories');
      return result;
    } catch (error) {
      console.error('[ReportService] Error generating category breakdown:', error);
      return [];
    }
  }

  // Get daily sales trend with error handling
  async getDailySalesTrend(startDate: Date, endDate: Date): Promise<TrendData[]> {
    if (!this.validateDates(startDate, endDate)) {
      console.warn('[ReportService] Invalid dates for trend data, returning empty array');
      return [];
    }

    try {
      console.log('[ReportService] Generating daily sales trend');

      const salesData = await this.getSalesData(startDate, endDate);

      let days = [];
      try {
        days = eachDayOfInterval({ start: startDate, end: endDate });
      } catch (error) {
        console.error('[ReportService] Error generating day intervals:', error);
        return [];
      }

      const result = days.map((day) => {
        try {
          const dayStart = startOfDay(day);
          const dayEnd = endOfDay(day);

          const daySales = salesData.filter((sale) => {
            try {
              if (!sale.sale_date) return false;
              const saleDate = new Date(sale.sale_date);
              return isValid(saleDate) && saleDate >= dayStart && saleDate <= dayEnd;
            } catch (error) {
              console.warn('[ReportService] Error parsing sale date:', sale.sale_date, error);
              return false;
            }
          });

          return {
            period: format(day, 'MMM dd'),
            sales: daySales.reduce((sum, sale) => {
              const amount = parseFloat(sale.total_amount?.toString() || '0') || 0;
              return sum + amount;
            }, 0),
            quantity: daySales.reduce((sum, sale) => {
              const quantity = parseFloat(sale.quantity_sold?.toString() || '0') || 0;
              return sum + quantity;
            }, 0),
            transactions: daySales.length
          };
        } catch (error) {
          console.warn('[ReportService] Error processing day trend for:', day, error);
          return {
            period: format(day, 'MMM dd'),
            sales: 0,
            quantity: 0,
            transactions: 0
          };
        }
      });

      console.log('[ReportService] Daily trend generated for', result.length, 'days');
      return result;
    } catch (error) {
      console.error('[ReportService] Error generating daily sales trend:', error);
      return [];
    }
  }

  // Get weekly sales trend with error handling
  async getWeeklySalesTrend(startDate: Date, endDate: Date): Promise<TrendData[]> {
    if (!this.validateDates(startDate, endDate)) {
      return [];
    }

    try {
      const salesData = await this.getSalesData(startDate, endDate);
      const weeks = eachWeekOfInterval({ start: startDate, end: endDate });

      const result = weeks.map((week) => {
        const weekStart = startOfWeek(week);
        const weekEnd = endOfWeek(week);

        const weekSales = salesData.filter((sale) => {
          try {
            if (!sale.sale_date) return false;
            const saleDate = new Date(sale.sale_date);
            return isValid(saleDate) && saleDate >= weekStart && saleDate <= weekEnd;
          } catch {
            return false;
          }
        });

        return {
          period: `Week of ${format(weekStart, 'MMM dd')}`,
          sales: weekSales.reduce((sum, sale) => sum + (parseFloat(sale.total_amount?.toString() || '0') || 0), 0),
          quantity: weekSales.reduce((sum, sale) => sum + (parseFloat(sale.quantity_sold?.toString() || '0') || 0), 0),
          transactions: weekSales.length
        };
      });

      return result;
    } catch (error) {
      console.error('[ReportService] Error generating weekly sales trend:', error);
      return [];
    }
  }

  // Get monthly sales trend with error handling
  async getMonthlySalesTrend(startDate: Date, endDate: Date): Promise<TrendData[]> {
    if (!this.validateDates(startDate, endDate)) {
      return [];
    }

    try {
      const salesData = await this.getSalesData(startDate, endDate);
      const months = eachMonthOfInterval({ start: startDate, end: endDate });

      const result = months.map((month) => {
        const monthStart = startOfMonth(month);
        const monthEnd = endOfMonth(month);

        const monthSales = salesData.filter((sale) => {
          try {
            if (!sale.sale_date) return false;
            const saleDate = new Date(sale.sale_date);
            return isValid(saleDate) && saleDate >= monthStart && saleDate <= monthEnd;
          } catch {
            return false;
          }
        });

        return {
          period: format(month, 'MMM yyyy'),
          sales: monthSales.reduce((sum, sale) => sum + (parseFloat(sale.total_amount?.toString() || '0') || 0), 0),
          quantity: monthSales.reduce((sum, sale) => sum + (parseFloat(sale.quantity_sold?.toString() || '0') || 0), 0),
          transactions: monthSales.length
        };
      });

      return result;
    } catch (error) {
      console.error('[ReportService] Error generating monthly sales trend:', error);
      return [];
    }
  }

  // Get daily sales by employee with error handling
  async getDailySalesByEmployee(date: Date): Promise<DailySalesData[]> {
    if (!date || !isValid(date)) {
      console.error('[ReportService] Invalid date provided for daily employee sales');
      return [];
    }

    try {
      const startDate = startOfDay(date);
      const endDate = endOfDay(date);
      const salesData = await this.getSalesData(startDate, endDate);

      console.log('[ReportService] Processing daily employee sales for', salesData.length, 'records');

      // Group by employee and shift with error handling
      const employeeMap = new Map();

      salesData.forEach((sale) => {
        try {
          if (!sale.sale_date) return;

          const saleTime = new Date(sale.sale_date);
          if (!isValid(saleTime)) return;

          const hour = saleTime.getHours();
          const shift = hour < 12 ? 'Morning' : hour < 17 ? 'Afternoon' : 'Evening';
          const employeeId = parseInt(sale.employee_id?.toString() || '0') || 0;
          const employeeName = sale.employee_name?.toString() || 'Unknown Employee';

          const key = `${employeeId}-${shift}`;
          if (!employeeMap.has(key)) {
            employeeMap.set(key, {
              date: format(date, 'yyyy-MM-dd'),
              employeeId,
              employeeName,
              shift,
              totalAmount: 0,
              totalQuantity: 0,
              productsCount: new Set(),
              transactions: 0
            });
          }

          const emp = employeeMap.get(key);
          const amount = parseFloat(sale.total_amount?.toString() || '0') || 0;
          const quantity = parseFloat(sale.quantity_sold?.toString() || '0') || 0;
          const productId = parseInt(sale.product_id?.toString() || '0');

          emp.totalAmount += amount;
          emp.totalQuantity += quantity;
          if (productId > 0) {
            emp.productsCount.add(productId);
          }
          emp.transactions += 1;
        } catch (error) {
          console.warn('[ReportService] Error processing daily employee sale:', sale, error);
        }
      });

      const result = Array.from(employeeMap.values()).map((emp) => ({
        ...emp,
        productsCount: emp.productsCount.size
      })).sort((a, b) => b.totalAmount - a.totalAmount);

      console.log('[ReportService] Daily employee sales processed:', result.length, 'entries');
      return result;
    } catch (error) {
      console.error('[ReportService] Error getting daily sales by employee:', error);
      return [];
    }
  }

  // Get period-over-period comparison with error handling
  async getPeriodComparison(
  currentStart: Date,
  currentEnd: Date,
  comparisonType: 'day' | 'week' | 'month')
  : Promise<ComparisonData> {
    if (!this.validateDates(currentStart, currentEnd)) {
      throw new Error('Invalid dates for period comparison');
    }

    try {
      console.log('[ReportService] Generating period comparison:', comparisonType);

      const current = await this.getSalesAnalytics(currentStart, currentEnd);

      let previousStart: Date, previousEnd: Date;

      switch (comparisonType) {
        case 'day':
          previousStart = startOfDay(subDays(currentStart, 1));
          previousEnd = endOfDay(subDays(currentEnd, 1));
          break;
        case 'week':
          previousStart = startOfWeek(subWeeks(currentStart, 1));
          previousEnd = endOfWeek(subWeeks(currentEnd, 1));
          break;
        case 'month':
          previousStart = startOfMonth(subMonths(currentStart, 1));
          previousEnd = endOfMonth(subMonths(currentEnd, 1));
          break;
        default:
          previousStart = startOfDay(subDays(currentStart, 1));
          previousEnd = endOfDay(subDays(currentEnd, 1));
      }

      const previous = await this.getSalesAnalytics(previousStart, previousEnd);

      const calculateGrowth = (current: number, previous: number): number => {
        if (previous === 0) return current > 0 ? 100 : 0;
        return (current - previous) / previous * 100;
      };

      const growth = {
        salesGrowth: calculateGrowth(current.totalSales, previous.totalSales),
        quantityGrowth: calculateGrowth(current.totalQuantity, previous.totalQuantity),
        transactionGrowth: calculateGrowth(current.totalTransactions, previous.totalTransactions),
        avgOrderValueGrowth: calculateGrowth(current.averageOrderValue, previous.averageOrderValue)
      };

      console.log('[ReportService] Period comparison generated successfully');
      return { current, previous, growth };
    } catch (error) {
      console.error('[ReportService] Error generating period comparison:', error);
      throw new Error('Failed to generate period comparison');
    }
  }

  // Export sales report data with error handling
  async exportSalesReport(
  startDate: Date,
  endDate: Date,
  format: 'pdf' | 'excel')
  : Promise<void> {
    if (!this.validateDates(startDate, endDate)) {
      throw new Error('Invalid dates for export');
    }

    try {
      console.log(`[ReportService] Exporting sales report as ${format}`);

      const analytics = await this.getSalesAnalytics(startDate, endDate);
      const trendData = await this.getDailySalesTrend(startDate, endDate);

      if (format === 'excel') {
        await this.exportToExcel(analytics, trendData, startDate, endDate);
      } else {
        await this.exportToPDF(analytics, trendData, startDate, endDate);
      }

      console.log(`[ReportService] Export completed successfully: ${format}`);
    } catch (error) {
      console.error('[ReportService] Error exporting sales report:', error);
      throw new Error(`Failed to export ${format} report`);
    }
  }

  private async exportToExcel(
  analytics: SalesAnalyticsData,
  trendData: TrendData[],
  startDate: Date,
  endDate: Date)
  : Promise<void> {
    try {
      const { exportSalesReportToExcel } = await import('../utils/exportUtils');
      const dailyEmployees = await this.getDailySalesByEmployee(startDate);

      const reportData = {
        summary: {
          title: 'Sales Analytics Report',
          period: `${format(startDate, 'PP')} - ${format(endDate, 'PP')}`,
          totalSales: analytics.totalSales,
          totalQuantity: analytics.totalQuantity,
          totalTransactions: analytics.totalTransactions,
          averageOrderValue: analytics.averageOrderValue
        },
        trends: trendData,
        categories: analytics.categoryBreakdown,
        employees: analytics.employeePerformance,
        dailyEmployees
      };

      exportSalesReportToExcel(reportData);
    } catch (error) {
      console.error('[ReportService] Error in Excel export:', error);
      throw new Error('Failed to export Excel report');
    }
  }

  private async exportToPDF(
  analytics: SalesAnalyticsData,
  trendData: TrendData[],
  startDate: Date,
  endDate: Date)
  : Promise<void> {
    try {
      const { exportSalesReportToPDF } = await import('../utils/exportUtils');
      const dailyEmployees = await this.getDailySalesByEmployee(startDate);

      const reportData = {
        summary: {
          title: 'Sales Analytics Report',
          period: `${format(startDate, 'PP')} - ${format(endDate, 'PP')}`,
          totalSales: analytics.totalSales,
          totalQuantity: analytics.totalQuantity,
          totalTransactions: analytics.totalTransactions,
          averageOrderValue: analytics.averageOrderValue
        },
        trends: trendData,
        categories: analytics.categoryBreakdown,
        employees: analytics.employeePerformance,
        dailyEmployees
      };

      exportSalesReportToPDF(reportData);
    } catch (error) {
      console.error('[ReportService] Error in PDF export:', error);
      throw new Error('Failed to export PDF report');
    }
  }
}

export const reportService = new ReportService();