
import { format, startOfDay, endOfDay, startOfMonth, endOfMonth, startOfWeek, endOfWeek } from 'date-fns';

const SALES_TRANSACTIONS_TABLE_ID = 38156;
const EXPENSES_TABLE_ID = 38512;
const PRODUCTS_TABLE_ID = 38157;

export interface FinancialMetrics {
  revenue: number;
  expenses: number;
  profit: number;
  profitMargin: number;
  grossProfit: number;
  netProfit: number;
  costOfGoodsSold: number;
}

export interface FinancialAnalytics {
  daily: FinancialMetrics;
  weekly: FinancialMetrics;
  monthly: FinancialMetrics;
  yearToDate: FinancialMetrics;
}

export interface ExpenseData {
  id: number;
  expense_date: string;
  category: string;
  description: string;
  amount: number;
  payment_method: string;
  employee_name: string;
  is_approved: boolean;
}

export interface FinancialTrendData {
  period: string;
  revenue: number;
  expenses: number;
  profit: number;
  profitMargin: number;
}

export interface CategoryExpenseData {
  category: string;
  amount: number;
  percentage: number;
  transactions: number;
}

class FinancialService {
  // Get comprehensive financial analytics
  async getFinancialAnalytics(): Promise<FinancialAnalytics> {
    const now = new Date();

    // Get daily metrics (today)
    const dailyStart = startOfDay(now);
    const dailyEnd = endOfDay(now);
    const daily = await this.getFinancialMetrics(dailyStart, dailyEnd);

    // Get weekly metrics (this week)
    const weeklyStart = startOfWeek(now);
    const weeklyEnd = endOfWeek(now);
    const weekly = await this.getFinancialMetrics(weeklyStart, weeklyEnd);

    // Get monthly metrics (this month)
    const monthlyStart = startOfMonth(now);
    const monthlyEnd = endOfMonth(now);
    const monthly = await this.getFinancialMetrics(monthlyStart, monthlyEnd);

    // Get year-to-date metrics
    const ytdStart = new Date(now.getFullYear(), 0, 1);
    const ytdEnd = now;
    const yearToDate = await this.getFinancialMetrics(ytdStart, ytdEnd);

    return {
      daily,
      weekly,
      monthly,
      yearToDate
    };
  }

  // Get financial metrics for a specific period
  async getFinancialMetrics(startDate: Date, endDate: Date): Promise<FinancialMetrics> {
    try {
      const [salesData, expenseData, productsData] = await Promise.all([
      this.getSalesData(startDate, endDate),
      this.getExpenseData(startDate, endDate),
      this.getProductsData()]
      );

      // Calculate revenue
      const revenue = salesData.reduce((sum, sale) => sum + (sale.total_amount || 0), 0);

      // Calculate total expenses
      const expenses = expenseData.
      filter((expense) => expense.is_approved).
      reduce((sum, expense) => sum + (expense.amount || 0), 0);

      // Calculate cost of goods sold (COGS)
      const costOfGoodsSold = this.calculateCOGS(salesData, productsData);

      // Calculate profits
      const grossProfit = revenue - costOfGoodsSold;
      const netProfit = grossProfit - expenses;
      const profit = netProfit;

      // Calculate profit margin
      const profitMargin = revenue > 0 ? profit / revenue * 100 : 0;

      return {
        revenue,
        expenses,
        profit,
        profitMargin,
        grossProfit,
        netProfit,
        costOfGoodsSold
      };
    } catch (error) {
      console.error('Error calculating financial metrics:', error);
      return {
        revenue: 0,
        expenses: 0,
        profit: 0,
        profitMargin: 0,
        grossProfit: 0,
        netProfit: 0,
        costOfGoodsSold: 0
      };
    }
  }

  // Get sales data for a period
  private async getSalesData(startDate: Date, endDate: Date): Promise<any[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALES_TRANSACTIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 10000,
        OrderByField: 'sale_date',
        IsAsc: false,
        Filters: [
        { name: 'sale_date', op: 'GreaterThanOrEqual', value: startDate.toISOString() },
        { name: 'sale_date', op: 'LessThanOrEqual', value: endDate.toISOString() }]

      });

      if (error) throw new Error(error);
      return data?.List || [];
    } catch (error) {
      console.error('Error fetching sales data:', error);
      return [];
    }
  }

  // Get expense data for a period
  private async getExpenseData(startDate: Date, endDate: Date): Promise<ExpenseData[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(EXPENSES_TABLE_ID, {
        PageNo: 1,
        PageSize: 10000,
        OrderByField: 'expense_date',
        IsAsc: false,
        Filters: [
        { name: 'expense_date', op: 'GreaterThanOrEqual', value: startDate.toISOString() },
        { name: 'expense_date', op: 'LessThanOrEqual', value: endDate.toISOString() }]

      });

      if (error) throw new Error(error);
      return data?.List || [];
    } catch (error) {
      console.error('Error fetching expense data:', error);
      return [];
    }
  }

  // Get products data for COGS calculation
  private async getProductsData(): Promise<any[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 10000,
        Filters: []
      });

      if (error) throw new Error(error);
      return data?.List || [];
    } catch (error) {
      console.error('Error fetching products data:', error);
      return [];
    }
  }

  // Calculate Cost of Goods Sold
  private calculateCOGS(salesData: any[], productsData: any[]): number {
    const productCostMap = new Map();
    productsData.forEach((product) => {
      productCostMap.set(product.id, product.cost_price || 0);
    });

    return salesData.reduce((total, sale) => {
      const costPrice = productCostMap.get(sale.product_id) || 0;
      const quantity = sale.quantity_sold || 0;
      return total + costPrice * quantity;
    }, 0);
  }

  // Get financial trend data
  async getFinancialTrend(period: 'daily' | 'weekly' | 'monthly', days: number = 30): Promise<FinancialTrendData[]> {
    const now = new Date();
    const trends: FinancialTrendData[] = [];

    for (let i = days - 1; i >= 0; i--) {
      let startDate: Date, endDate: Date, label: string;

      switch (period) {
        case 'daily':
          startDate = startOfDay(new Date(now.getTime() - i * 24 * 60 * 60 * 1000));
          endDate = endOfDay(startDate);
          label = format(startDate, 'MMM dd');
          break;
        case 'weekly':
          startDate = startOfWeek(new Date(now.getTime() - i * 7 * 24 * 60 * 60 * 1000));
          endDate = endOfWeek(startDate);
          label = `Week of ${format(startDate, 'MMM dd')}`;
          break;
        case 'monthly':
          startDate = startOfMonth(new Date(now.getFullYear(), now.getMonth() - i, 1));
          endDate = endOfMonth(startDate);
          label = format(startDate, 'MMM yyyy');
          break;
      }

      const metrics = await this.getFinancialMetrics(startDate, endDate);

      trends.push({
        period: label,
        revenue: metrics.revenue,
        expenses: metrics.expenses,
        profit: metrics.profit,
        profitMargin: metrics.profitMargin
      });
    }

    return trends;
  }

  // Get expense breakdown by category
  async getExpenseCategoryBreakdown(startDate: Date, endDate: Date): Promise<CategoryExpenseData[]> {
    try {
      const expenseData = await this.getExpenseData(startDate, endDate);
      const approvedExpenses = expenseData.filter((expense) => expense.is_approved);

      const categoryMap = new Map();
      let totalExpenses = 0;

      approvedExpenses.forEach((expense) => {
        const category = expense.category || 'Uncategorized';
        if (!categoryMap.has(category)) {
          categoryMap.set(category, { amount: 0, transactions: 0 });
        }
        const cat = categoryMap.get(category);
        cat.amount += expense.amount || 0;
        cat.transactions += 1;
        totalExpenses += expense.amount || 0;
      });

      return Array.from(categoryMap.entries()).
      map(([category, data]) => ({
        category,
        amount: data.amount,
        percentage: totalExpenses > 0 ? data.amount / totalExpenses * 100 : 0,
        transactions: data.transactions
      })).
      sort((a, b) => b.amount - a.amount);
    } catch (error) {
      console.error('Error getting expense category breakdown:', error);
      return [];
    }
  }

  // Add new expense
  async addExpense(expenseData: Omit<ExpenseData, 'id'>): Promise<void> {
    try {
      const { error } = await window.ezsite.apis.tableCreate(EXPENSES_TABLE_ID, {
        expense_date: new Date(expenseData.expense_date),
        category: expenseData.category,
        description: expenseData.description,
        amount: expenseData.amount,
        payment_method: expenseData.payment_method,
        employee_name: expenseData.employee_name,
        is_approved: expenseData.is_approved
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error adding expense:', error);
      throw error;
    }
  }

  // Update expense approval status
  async updateExpenseApproval(expenseId: number, isApproved: boolean): Promise<void> {
    try {
      const { error } = await window.ezsite.apis.tableUpdate(EXPENSES_TABLE_ID, {
        ID: expenseId,
        is_approved: isApproved
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error updating expense approval:', error);
      throw error;
    }
  }

  // Get top expense categories
  async getTopExpenseCategories(startDate: Date, endDate: Date, limit: number = 5): Promise<CategoryExpenseData[]> {
    const categories = await this.getExpenseCategoryBreakdown(startDate, endDate);
    return categories.slice(0, limit);
  }

  // Calculate financial KPIs
  async getFinancialKPIs(startDate: Date, endDate: Date): Promise<{
    revenueGrowth: number;
    profitMargin: number;
    expenseRatio: number;
    averageTransactionValue: number;
    costEfficiency: number;
  }> {
    try {
      const currentMetrics = await this.getFinancialMetrics(startDate, endDate);

      // Calculate previous period for comparison
      const periodLength = endDate.getTime() - startDate.getTime();
      const previousStart = new Date(startDate.getTime() - periodLength);
      const previousEnd = new Date(endDate.getTime() - periodLength);
      const previousMetrics = await this.getFinancialMetrics(previousStart, previousEnd);

      // Calculate revenue growth
      const revenueGrowth = previousMetrics.revenue > 0 ?
      (currentMetrics.revenue - previousMetrics.revenue) / previousMetrics.revenue * 100 :
      0;

      // Calculate expense ratio (expenses as % of revenue)
      const expenseRatio = currentMetrics.revenue > 0 ?
      currentMetrics.expenses / currentMetrics.revenue * 100 :
      0;

      // Get transaction data for average transaction value
      const salesData = await this.getSalesData(startDate, endDate);
      const averageTransactionValue = salesData.length > 0 ?
      currentMetrics.revenue / salesData.length :
      0;

      // Cost efficiency (revenue per dollar of expense)
      const costEfficiency = currentMetrics.expenses > 0 ?
      currentMetrics.revenue / currentMetrics.expenses :
      0;

      return {
        revenueGrowth,
        profitMargin: currentMetrics.profitMargin,
        expenseRatio,
        averageTransactionValue,
        costEfficiency
      };
    } catch (error) {
      console.error('Error calculating financial KPIs:', error);
      return {
        revenueGrowth: 0,
        profitMargin: 0,
        expenseRatio: 0,
        averageTransactionValue: 0,
        costEfficiency: 0
      };
    }
  }
}

export const financialService = new FinancialService();