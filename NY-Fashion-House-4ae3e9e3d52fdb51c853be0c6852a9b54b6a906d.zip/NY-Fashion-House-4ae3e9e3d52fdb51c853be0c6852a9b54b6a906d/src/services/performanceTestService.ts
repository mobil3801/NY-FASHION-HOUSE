
export interface PerformanceTestCase {
  id: number;
  test_name: string;
  test_type: 'page_load' | 'api_response' | 'memory_leak' | 'cross_browser' | 'responsiveness';
  target_url: string;
  expected_threshold_ms: number;
  browser_targets: string;
  is_active: boolean;
  created_at: string;
}

export interface PerformanceTestResult {
  id?: number;
  test_case_id: number;
  execution_id: string;
  browser: string;
  device_type: 'Desktop' | 'Mobile' | 'Tablet';
  screen_resolution: string;
  load_time_ms: number;
  api_response_time_ms: number;
  memory_usage_mb: number;
  cpu_usage_percent: number;
  test_status: 'Pass' | 'Fail' | 'Error';
  performance_score: number;
  bottlenecks_detected: string;
  memory_leaks_detected: boolean;
  executed_at: string;
}

export interface BrowserInfo {
  name: string;
  version: string;
  userAgent: string;
}

export interface DeviceInfo {
  type: 'Desktop' | 'Mobile' | 'Tablet';
  screenWidth: number;
  screenHeight: number;
  orientation: 'portrait' | 'landscape';
}

export class PerformanceTestService {
  private static readonly PERFORMANCE_TEST_CASES_TABLE_ID = 38556;
  private static readonly PERFORMANCE_TEST_RESULTS_TABLE_ID = 38557;

  static async createTestCase(testCase: Omit<PerformanceTestCase, 'id'>): Promise<void> {
    const { error } = await window.ezsite.apis.tableCreate(
      this.PERFORMANCE_TEST_CASES_TABLE_ID,
      {
        ...testCase,
        created_at: new Date().toISOString()
      }
    );
    if (error) throw new Error(error);
  }

  static async getTestCases(): Promise<PerformanceTestCase[]> {
    const { data, error } = await window.ezsite.apis.tablePage(
      this.PERFORMANCE_TEST_CASES_TABLE_ID,
      {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'id',
        IsAsc: true,
        Filters: [
        {
          name: 'is_active',
          op: 'Equal',
          value: true
        }]

      }
    );
    if (error) throw new Error(error);
    return data.List;
  }

  static async saveTestResult(result: Omit<PerformanceTestResult, 'id'>): Promise<void> {
    const { error } = await window.ezsite.apis.tableCreate(
      this.PERFORMANCE_TEST_RESULTS_TABLE_ID,
      {
        ...result,
        executed_at: new Date().toISOString()
      }
    );
    if (error) throw new Error(error);
  }

  static async getTestResults(executionId?: string): Promise<PerformanceTestResult[]> {
    const filters = [];
    if (executionId) {
      filters.push({
        name: 'execution_id',
        op: 'Equal',
        value: executionId
      });
    }

    const { data, error } = await window.ezsite.apis.tablePage(
      this.PERFORMANCE_TEST_RESULTS_TABLE_ID,
      {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'executed_at',
        IsAsc: false,
        Filters: filters
      }
    );
    if (error) throw new Error(error);
    return data.List;
  }

  static getBrowserInfo(): BrowserInfo {
    const ua = navigator.userAgent;
    let name = 'Unknown';
    let version = 'Unknown';

    if (ua.includes('Chrome') && !ua.includes('Edg')) {
      name = 'Chrome';
      const match = ua.match(/Chrome\/([0-9]+)/);
      version = match ? match[1] : 'Unknown';
    } else if (ua.includes('Firefox')) {
      name = 'Firefox';
      const match = ua.match(/Firefox\/([0-9]+)/);
      version = match ? match[1] : 'Unknown';
    } else if (ua.includes('Safari') && !ua.includes('Chrome')) {
      name = 'Safari';
      const match = ua.match(/Version\/([0-9]+)/);
      version = match ? match[1] : 'Unknown';
    } else if (ua.includes('Edg')) {
      name = 'Edge';
      const match = ua.match(/Edg\/([0-9]+)/);
      version = match ? match[1] : 'Unknown';
    }

    return { name, version, userAgent: ua };
  }

  static getDeviceInfo(): DeviceInfo {
    const width = window.innerWidth;
    const height = window.innerHeight;

    let type: 'Desktop' | 'Mobile' | 'Tablet' = 'Desktop';
    if (width <= 768) {
      type = 'Mobile';
    } else if (width <= 1024) {
      type = 'Tablet';
    }

    return {
      type,
      screenWidth: width,
      screenHeight: height,
      orientation: width > height ? 'landscape' : 'portrait'
    };
  }

  static async measurePageLoadTime(url: string): Promise<number> {
    const startTime = performance.now();

    try {
      await new Promise<void>((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve();
        img.onerror = () => reject(new Error('Failed to load page'));
        img.src = `${url}?t=${Date.now()}`;
      });

      return Math.round(performance.now() - startTime);
    } catch {
      // Fallback to navigation timing if available
      if (performance.navigation && performance.timing) {
        const { loadEventEnd, navigationStart } = performance.timing;
        return loadEventEnd - navigationStart;
      }
      return 0;
    }
  }

  static async measureApiResponseTime(endpoint: string, method: 'GET' | 'POST' = 'GET'): Promise<number> {
    const startTime = performance.now();

    try {
      await fetch(endpoint, { method });
      return Math.round(performance.now() - startTime);
    } catch {
      return 0;
    }
  }

  static getMemoryUsage(): number {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      return Math.round(memory.usedJSHeapSize / 1024 / 1024);
    }
    return 0;
  }

  static async detectMemoryLeaks(): Promise<boolean> {
    if (!('memory' in performance)) return false;

    const memory = (performance as any).memory;
    const initialMemory = memory.usedJSHeapSize;

    // Simulate some operations and check for significant memory growth
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const finalMemory = memory.usedJSHeapSize;
    const memoryGrowth = (finalMemory - initialMemory) / 1024 / 1024; // MB

    return memoryGrowth > 50; // Consider significant growth as potential leak
  }

  static calculatePerformanceScore(loadTime: number, threshold: number, memoryUsage: number): number {
    let score = 100;

    // Penalize slow load times
    if (loadTime > threshold) {
      const penalty = Math.min(50, (loadTime - threshold) / 100);
      score -= penalty;
    }

    // Penalize high memory usage
    if (memoryUsage > 100) {
      const penalty = Math.min(30, (memoryUsage - 100) / 10);
      score -= penalty;
    }

    return Math.max(0, Math.round(score));
  }

  static detectPerformanceBottlenecks(): string[] {
    const bottlenecks: string[] = [];

    // Check navigation timing
    if (performance.timing) {
      const timing = performance.timing;
      const dnsTime = timing.domainLookupEnd - timing.domainLookupStart;
      const connectionTime = timing.connectEnd - timing.connectStart;
      const responseTime = timing.responseEnd - timing.responseStart;

      if (dnsTime > 100) bottlenecks.push('Slow DNS lookup');
      if (connectionTime > 100) bottlenecks.push('Slow connection establishment');
      if (responseTime > 1000) bottlenecks.push('Slow server response');
    }

    // Check resource loading
    if (performance.getEntriesByType) {
      const resources = performance.getEntriesByType('resource') as any[];
      const slowResources = resources.filter((resource) => resource.duration > 2000);
      if (slowResources.length > 0) {
        bottlenecks.push(`${slowResources.length} slow resource(s) detected`);
      }
    }

    return bottlenecks;
  }
}