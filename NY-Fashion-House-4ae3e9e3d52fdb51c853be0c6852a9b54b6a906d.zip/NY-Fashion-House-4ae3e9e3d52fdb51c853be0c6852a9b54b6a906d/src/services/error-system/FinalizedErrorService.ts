import { DevToolsIntegration } from '../../utils/devToolsIntegration';
import { ErrorPatternDetector } from '../../utils/errorPatternDetector';
import { PerformanceOptimizer } from '../../utils/performanceOptimizer';

interface ErrorMetadata {
  errorInfo?: any;
  level?: 'page' | 'component' | 'section' | 'system';
  identifier?: string;
  timestamp?: string;
  userAgent?: string;
  url?: string;
  componentStack?: string;
  userId?: string;
  sessionId?: string;
  buildVersion?: string;
  feature?: string;
  severity?: 'low' | 'medium' | 'high' | 'critical';
  tags?: string[];
  context?: Record<string, any>;
}

interface ErrorReport {
  id: string;
  error: Error;
  metadata: ErrorMetadata;
  fingerprint: string;
  count: number;
  firstSeen: Date;
  lastSeen: Date;
  resolved: boolean;
  reportedByUsers: number;
}

interface IssueReport {
  errorId: string;
  userFeedback?: string;
  reproductionSteps?: string;
  expectedBehavior?: string;
  actualBehavior?: string;
  userEmail?: string;
  priority?: 'low' | 'medium' | 'high' | 'critical';
}

export class FinalizedErrorService {
  private static instance: FinalizedErrorService;
  private errorReports: Map<string, ErrorReport> = new Map();
  private isInitialized = false;
  private devTools: DevToolsIntegration;
  private patternDetector: ErrorPatternDetector;
  private performanceOptimizer: PerformanceOptimizer;
  private sessionId: string;

  private constructor() {
    this.sessionId = this.generateSessionId();
    this.devTools = new DevToolsIntegration();
    this.patternDetector = new ErrorPatternDetector();
    this.performanceOptimizer = new PerformanceOptimizer();
    this.initialize();
  }

  static getInstance(): FinalizedErrorService {
    if (!FinalizedErrorService.instance) {
      FinalizedErrorService.instance = new FinalizedErrorService();
    }
    return FinalizedErrorService.instance;
  }

  private async initialize() {
    if (this.isInitialized) return;

    try {
      // Initialize DevTools integration
      await this.devTools.initialize();

      // Set up global error handlers
      this.setupGlobalErrorHandlers();

      // Start performance monitoring
      this.performanceOptimizer.startMonitoring();

      // Schedule periodic pattern analysis
      this.schedulePatternAnalysis();

      this.isInitialized = true;
      console.log('[Error System] Initialized successfully');
    } catch (error) {
      console.error('[Error System] Failed to initialize:', error);
    }
  }

  private setupGlobalErrorHandlers() {
    // Handle unhandled errors
    window.addEventListener('error', (event) => {
      this.captureError(new Error(event.message), {
        level: 'system',
        identifier: 'global-error',
        context: {
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        }
      });
    });

    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.captureError(
        event.reason instanceof Error ? event.reason : new Error(String(event.reason)),
        {
          level: 'system',
          identifier: 'unhandled-promise-rejection'
        }
      );
    });

    // Handle React errors (if not caught by error boundaries)
    const originalConsoleError = console.error;
    console.error = (...args) => {
      if (args[0] && typeof args[0] === 'string' && args[0].includes('React')) {
        this.captureError(new Error(args.join(' ')), {
          level: 'component',
          identifier: 'react-error',
          context: { args }
        });
      }
      originalConsoleError.apply(console, args);
    };
  }

  public captureError(error: Error, metadata: ErrorMetadata = {}): string {
    return this.performanceOptimizer.withPerformanceTracking('captureError', () => {
      const errorId = this.generateErrorId();
      const fingerprint = this.generateFingerprint(error, metadata);

      // Enhanced metadata collection
      const enrichedMetadata: ErrorMetadata = {
        ...metadata,
        timestamp: metadata.timestamp || new Date().toISOString(),
        userAgent: metadata.userAgent || navigator.userAgent,
        url: metadata.url || window.location.href,
        sessionId: this.sessionId,
        buildVersion: process.env.REACT_APP_VERSION || 'development',
        severity: this.calculateSeverity(error, metadata),
        tags: this.generateTags(error, metadata),
        context: {
          ...metadata.context,
          viewport: {
            width: window.innerWidth,
            height: window.innerHeight
          },
          screen: {
            width: screen.width,
            height: screen.height
          },
          memory: (performance as any).memory ? {
            used: (performance as any).memory.usedJSHeapSize,
            total: (performance as any).memory.totalJSHeapSize,
            limit: (performance as any).memory.jsHeapSizeLimit
          } : undefined
        }
      };

      // Check if this error already exists
      const existingReport = Array.from(this.errorReports.values()).
      find((report) => report.fingerprint === fingerprint);

      if (existingReport) {
        existingReport.count++;
        existingReport.lastSeen = new Date();
        this.updateErrorReport(existingReport);
      } else {
        // Create new error report
        const newReport: ErrorReport = {
          id: errorId,
          error,
          metadata: enrichedMetadata,
          fingerprint,
          count: 1,
          firstSeen: new Date(),
          lastSeen: new Date(),
          resolved: false,
          reportedByUsers: 0
        };

        this.errorReports.set(errorId, newReport);
        this.logErrorReport(newReport);
      }

      // Capture with DevTools in development
      if (process.env.NODE_ENV === 'development') {
        this.devTools.captureError(error, enrichedMetadata);
      }

      // Add to pattern detection
      this.patternDetector.addError(error, enrichedMetadata);

      // Store in localStorage for persistence (with size limit)
      this.persistError(errorId, { error: error.message, metadata: enrichedMetadata });

      return errorId;
    });
  }

  private calculateSeverity(error: Error, metadata: ErrorMetadata): 'low' | 'medium' | 'high' | 'critical' {
    // High severity for page-level errors
    if (metadata.level === 'page') return 'critical';
    if (metadata.level === 'system') return 'high';

    // Check for critical keywords in error message
    const criticalKeywords = ['security', 'auth', 'payment', 'data loss'];
    const highKeywords = ['network', 'api', 'database', 'server'];
    const mediumKeywords = ['validation', 'form', 'ui'];

    const message = error.message.toLowerCase();

    if (criticalKeywords.some((keyword) => message.includes(keyword))) return 'critical';
    if (highKeywords.some((keyword) => message.includes(keyword))) return 'high';
    if (mediumKeywords.some((keyword) => message.includes(keyword))) return 'medium';

    return 'low';
  }

  private generateTags(error: Error, metadata: ErrorMetadata): string[] {
    const tags: string[] = [];

    if (metadata.level) tags.push(`level:${metadata.level}`);
    if (metadata.identifier) tags.push(`component:${metadata.identifier}`);
    if (metadata.feature) tags.push(`feature:${metadata.feature}`);

    // Add browser tag
    const ua = metadata.userAgent || navigator.userAgent;
    if (ua.includes('Chrome')) tags.push('browser:chrome');else
    if (ua.includes('Firefox')) tags.push('browser:firefox');else
    if (ua.includes('Safari')) tags.push('browser:safari');else
    if (ua.includes('Edge')) tags.push('browser:edge');

    // Add device type
    if (/Mobi|Android/i.test(ua)) tags.push('device:mobile');else
    tags.push('device:desktop');

    return tags;
  }

  public reportIssue(errorId: string, issueReport: IssueReport): boolean {
    const errorReport = this.errorReports.get(errorId);
    if (!errorReport) return false;

    errorReport.reportedByUsers++;

    // Log the issue report
    console.log('[Error System] Issue reported:', {
      errorId,
      issueReport,
      errorDetails: {
        message: errorReport.error.message,
        count: errorReport.count,
        firstSeen: errorReport.firstSeen
      }
    });

    // In production, send to error tracking service
    this.sendToErrorTrackingService(errorId, issueReport);

    return true;
  }

  public getErrorReports(): ErrorReport[] {
    return Array.from(this.errorReports.values()).
    sort((a, b) => b.lastSeen.getTime() - a.lastSeen.getTime());
  }

  public getErrorStats() {
    const reports = this.getErrorReports();
    const totalErrors = reports.reduce((sum, report) => sum + report.count, 0);
    const uniqueErrors = reports.length;
    const resolvedErrors = reports.filter((r) => r.resolved).length;

    return {
      totalErrors,
      uniqueErrors,
      resolvedErrors,
      errorRate: totalErrors > 0 ? totalErrors / uniqueErrors : 0,
      severityDistribution: this.getSeverityDistribution(reports),
      topErrors: reports.slice(0, 10)
    };
  }

  private getSeverityDistribution(reports: ErrorReport[]) {
    const distribution = { low: 0, medium: 0, high: 0, critical: 0 };
    reports.forEach((report) => {
      const severity = report.metadata.severity || 'low';
      distribution[severity]++;
    });
    return distribution;
  }

  public analyzePatterns(): any {
    return this.patternDetector.analyzePatterns();
  }

  public generateHealthReport() {
    const stats = this.getErrorStats();
    const patterns = this.analyzePatterns();
    const performance = this.performanceOptimizer.getMetrics();

    return {
      timestamp: new Date().toISOString(),
      sessionId: this.sessionId,
      stats,
      patterns,
      performance,
      recommendations: this.generateRecommendations(stats, patterns)
    };
  }

  private generateRecommendations(stats: any, patterns: any): string[] {
    const recommendations: string[] = [];

    if (stats.totalErrors > 100) {
      recommendations.push('High error count detected. Consider reviewing error patterns.');
    }

    if (stats.severityDistribution.critical > 0) {
      recommendations.push('Critical errors detected. Immediate attention required.');
    }

    if (patterns.commonComponents?.length > 0) {
      recommendations.push(`Frequent errors in: ${patterns.commonComponents.join(', ')}`);
    }

    return recommendations;
  }

  private schedulePatternAnalysis() {
    setInterval(() => {
      try {
        const patterns = this.analyzePatterns();
        if (patterns.anomalies?.length > 0) {
          console.warn('[Error System] Pattern anomalies detected:', patterns.anomalies);
        }
      } catch (error) {
        console.error('[Error System] Pattern analysis failed:', error);
      }
    }, 5 * 60 * 1000); // Every 5 minutes
  }

  private generateErrorId(): string {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateFingerprint(error: Error, metadata: ErrorMetadata): string {
    const components = [
    error.name,
    error.message,
    metadata.identifier || '',
    metadata.level || ''];

    return btoa(components.join('|')).substr(0, 16);
  }

  private logErrorReport(report: ErrorReport) {
    console.error('[Error System] New error captured:', {
      id: report.id,
      message: report.error.message,
      level: report.metadata.level,
      identifier: report.metadata.identifier,
      severity: report.metadata.severity,
      timestamp: report.metadata.timestamp
    });
  }

  private updateErrorReport(report: ErrorReport) {
    // Update in storage/service
    console.log('[Error System] Error occurred again:', {
      id: report.id,
      count: report.count,
      message: report.error.message
    });
  }

  private persistError(errorId: string, data: any) {
    try {
      const stored = JSON.parse(localStorage.getItem('errorSystem_errors') || '{}');
      stored[errorId] = data;

      // Limit storage to last 100 errors
      const keys = Object.keys(stored);
      if (keys.length > 100) {
        const sortedKeys = keys.sort().slice(-100);
        const trimmed = {};
        sortedKeys.forEach((key) => {
          (trimmed as any)[key] = stored[key];
        });
        localStorage.setItem('errorSystem_errors', JSON.stringify(trimmed));
      } else {
        localStorage.setItem('errorSystem_errors', JSON.stringify(stored));
      }
    } catch (error) {
      console.warn('[Error System] Failed to persist error:', error);
    }
  }

  private async sendToErrorTrackingService(errorId: string, issueReport: IssueReport) {
    // In a real implementation, send to external error tracking service
    // For now, just log it
    console.log('[Error System] Would send to error tracking service:', {
      errorId,
      issueReport
    });
  }
}