import { TestCase, TestResult } from './automatedTestGeneratorService';
import { ServiceEndpoint, apiEndpointDiscoveryService } from './apiEndpointDiscoveryService';

export interface TestExecutionConfig {
  maxRetries: number;
  timeoutMultiplier: number;
  parallelExecution: boolean;
  maxConcurrency: number;
  stopOnFirstFailure: boolean;
  detailedLogging: boolean;
}

export interface TestExecutionSummary {
  totalTests: number;
  passed: number;
  failed: number;
  errors: number;
  timeouts: number;
  skipped: number;
  totalExecutionTime: number;
  successRate: number;
  averageExecutionTime: number;
}

export interface TestExecutionReport {
  executionId: string;
  startTime: Date;
  endTime: Date;
  summary: TestExecutionSummary;
  results: TestResult[];
  config: TestExecutionConfig;
  errors: string[];
}

export class TestExecutionEngineService {
  private defaultConfig: TestExecutionConfig = {
    maxRetries: 2,
    timeoutMultiplier: 1.5,
    parallelExecution: false,
    maxConcurrency: 5,
    stopOnFirstFailure: false,
    detailedLogging: true
  };

  private executionReports: Map<string, TestExecutionReport> = new Map();

  /**
   * Execute a single test case
   */
  async executeTestCase(testCase: TestCase, config: Partial<TestExecutionConfig> = {}): Promise<TestResult> {
    const finalConfig = { ...this.defaultConfig, ...config };
    const startTime = performance.now();
    let retryCount = 0;

    while (retryCount <= finalConfig.maxRetries) {
      try {
        if (finalConfig.detailedLogging) {
          console.log(`Executing test: ${testCase.id} (attempt ${retryCount + 1})`);
        }

        const result = await this.runSingleTest(testCase, finalConfig);
        const endTime = performance.now();
        const executionTime = endTime - startTime;

        return {
          testCaseId: testCase.id,
          status: result.status,
          executionTime,
          result: result.data,
          error: result.error,
          actualError: result.actualError,
          timestamp: new Date(),
          retryCount
        };
      } catch (error) {
        retryCount++;
        if (retryCount > finalConfig.maxRetries) {
          const endTime = performance.now();
          const executionTime = endTime - startTime;

          return {
            testCaseId: testCase.id,
            status: 'ERROR',
            executionTime,
            error: error instanceof Error ? error.message : 'Unknown error',
            actualError: error as Error,
            timestamp: new Date(),
            retryCount: retryCount - 1
          };
        }

        // Wait before retry
        await this.delay(500 * retryCount);
      }
    }

    // This should never be reached, but just in case
    return {
      testCaseId: testCase.id,
      status: 'ERROR',
      executionTime: 0,
      error: 'Max retries exceeded',
      timestamp: new Date(),
      retryCount: finalConfig.maxRetries
    };
  }

  /**
   * Execute multiple test cases
   */
  async executeTestCases(
  testCases: TestCase[],
  config: Partial<TestExecutionConfig> = {})
  : Promise<TestExecutionReport> {
    const finalConfig = { ...this.defaultConfig, ...config };
    const executionId = `exec_${Date.now()}`;
    const startTime = new Date();
    const errors: string[] = [];
    const results: TestResult[] = [];

    try {
      if (finalConfig.parallelExecution) {
        // Execute tests in parallel with concurrency limit
        const chunks = this.chunkArray(testCases, finalConfig.maxConcurrency);

        for (const chunk of chunks) {
          const promises = chunk.map((testCase) => this.executeTestCase(testCase, finalConfig));
          const chunkResults = await Promise.all(promises);
          results.push(...chunkResults);

          // Stop on first failure if configured
          if (finalConfig.stopOnFirstFailure && chunkResults.some((r) => r.status === 'FAIL' || r.status === 'ERROR')) {
            break;
          }
        }
      } else {
        // Execute tests sequentially
        for (const testCase of testCases) {
          const result = await this.executeTestCase(testCase, finalConfig);
          results.push(result);

          // Stop on first failure if configured
          if (finalConfig.stopOnFirstFailure && (result.status === 'FAIL' || result.status === 'ERROR')) {
            break;
          }
        }
      }
    } catch (error) {
      errors.push(error instanceof Error ? error.message : 'Unknown execution error');
    }

    const endTime = new Date();
    const summary = this.generateSummary(results, startTime, endTime);

    const report: TestExecutionReport = {
      executionId,
      startTime,
      endTime,
      summary,
      results,
      config: finalConfig,
      errors
    };

    this.executionReports.set(executionId, report);
    return report;
  }

  /**
   * Run a single test with timeout handling
   */
  private async runSingleTest(testCase: TestCase, config: TestExecutionConfig): Promise<{
    status: TestResult['status'];
    data?: any;
    error?: string;
    actualError?: Error;
  }> {
    const timeout = testCase.timeout * config.timeoutMultiplier;

    return new Promise(async (resolve) => {
      const timeoutId = setTimeout(() => {
        resolve({
          status: 'TIMEOUT',
          error: `Test timed out after ${timeout}ms`
        });
      }, timeout);

      try {
        const endpoint = await this.getEndpointForTest(testCase);
        if (!endpoint) {
          clearTimeout(timeoutId);
          resolve({
            status: 'ERROR',
            error: 'Endpoint not found'
          });
          return;
        }

        const result = await this.invokeEndpoint(endpoint, testCase);
        clearTimeout(timeoutId);

        // Analyze the result
        const analysis = this.analyzeResult(testCase, result);
        resolve(analysis);
      } catch (error) {
        clearTimeout(timeoutId);
        resolve({
          status: 'ERROR',
          error: error instanceof Error ? error.message : 'Unknown error',
          actualError: error as Error
        });
      }
    });
  }

  /**
   * Get the endpoint for a test case
   */
  private async getEndpointForTest(testCase: TestCase): Promise<ServiceEndpoint | null> {
    try {
      const allRegistries = await apiEndpointDiscoveryService.discoverAllEndpoints();

      for (const registry of allRegistries) {
        for (const endpoint of registry.endpoints) {
          const endpointId = `${endpoint.serviceName}.${endpoint.methodName}`;
          if (endpointId === testCase.endpointId) {
            return endpoint;
          }
        }
      }
    } catch (error) {
      console.error('Error getting endpoint for test:', error);
    }

    return null;
  }

  /**
   * Invoke an endpoint with test data
   */
  private async invokeEndpoint(endpoint: ServiceEndpoint, testCase: TestCase): Promise<any> {
    const method = endpoint.method;
    const testData = testCase.testData;

    // Handle different method signatures based on operation type
    switch (endpoint.operationType) {
      case 'CREATE':
        if (testData === null || testData === undefined) {
          return await method(testData);
        }
        return await method(testData);

      case 'READ':
        if (endpoint.methodName.toLowerCase().includes('getall') ||
        endpoint.methodName.toLowerCase().includes('list')) {
          return await method(testData); // May include filters
        } else if (endpoint.methodName.toLowerCase().includes('getbyid') ||
        endpoint.methodName.toLowerCase().includes('findbyid')) {
          return await method(testData); // ID parameter
        }
        return await method(testData);

      case 'UPDATE':
        if (testData && typeof testData === 'object' && testData.id && testData.updates) {
          return await method(testData.id, testData.updates);
        }
        return await method(testData);

      case 'DELETE':
        return await method(testData); // ID parameter

      case 'UTILITY':
        // Handle utility methods with various parameter patterns
        if (Array.isArray(testData)) {
          return await method(...testData);
        } else if (testData && typeof testData === 'object') {
          // Try to spread object properties
          const values = Object.values(testData);
          return await method(...values);
        }
        return await method(testData);

      default:
        return await method(testData);
    }
  }

  /**
   * Analyze test result to determine pass/fail
   */
  private analyzeResult(testCase: TestCase, result: any): {
    status: TestResult['status'];
    data?: any;
    error?: string;
    actualError?: Error;
  } {
    try {
      switch (testCase.testType) {
        case 'POSITIVE':
          return this.analyzePositiveTest(testCase, result);
        case 'NEGATIVE':
          return this.analyzeNegativeTest(testCase, result);
        case 'EDGE_CASE':
          return this.analyzeEdgeCaseTest(testCase, result);
        case 'PERFORMANCE':
          return this.analyzePerformanceTest(testCase, result);
        default:
          return {
            status: 'PASS',
            data: result
          };
      }
    } catch (error) {
      return {
        status: 'ERROR',
        error: error instanceof Error ? error.message : 'Analysis error',
        actualError: error as Error
      };
    }
  }

  private analyzePositiveTest(testCase: TestCase, result: any): {
    status: TestResult['status'];
    data?: any;
    error?: string;
  } {
    // For positive tests, we expect no errors and reasonable results
    if (result === undefined) {
      return {
        status: 'FAIL',
        error: 'Expected result but got undefined'
      };
    }

    // Check expected result type
    if (testCase.expectedResult) {
      if (testCase.expectedResult === 'Array' && !Array.isArray(result)) {
        return {
          status: 'FAIL',
          error: `Expected array but got ${typeof result}`
        };
      }
    }

    return {
      status: 'PASS',
      data: result
    };
  }

  private analyzeNegativeTest(testCase: TestCase, result: any): {
    status: TestResult['status'];
    data?: any;
    error?: string;
  } {
    // For negative tests, we expect errors or specific failure conditions
    if (result instanceof Error || result && result.error) {
      return {
        status: 'PASS',
        data: result,
        error: 'Expected error occurred'
      };
    }

    // Some negative tests might return null or empty results
    if (result === null || result === undefined ||
    Array.isArray(result) && result.length === 0) {
      return {
        status: 'PASS',
        data: result
      };
    }

    return {
      status: 'FAIL',
      error: 'Expected failure but test succeeded',
      data: result
    };
  }

  private analyzeEdgeCaseTest(testCase: TestCase, result: any): {
    status: TestResult['status'];
    data?: any;
    error?: string;
  } {
    // Edge cases should handle gracefully without throwing unhandled errors
    return {
      status: 'PASS',
      data: result
    };
  }

  private analyzePerformanceTest(testCase: TestCase, result: any): {
    status: TestResult['status'];
    data?: any;
    error?: string;
  } {
    // For performance tests, we mainly check that they complete within timeout
    return {
      status: 'PASS',
      data: result
    };
  }

  /**
   * Generate execution summary
   */
  private generateSummary(
  results: TestResult[],
  startTime: Date,
  endTime: Date)
  : TestExecutionSummary {
    const totalTests = results.length;
    const passed = results.filter((r) => r.status === 'PASS').length;
    const failed = results.filter((r) => r.status === 'FAIL').length;
    const errors = results.filter((r) => r.status === 'ERROR').length;
    const timeouts = results.filter((r) => r.status === 'TIMEOUT').length;
    const skipped = totalTests - (passed + failed + errors + timeouts);
    const totalExecutionTime = endTime.getTime() - startTime.getTime();
    const successRate = totalTests > 0 ? passed / totalTests * 100 : 0;
    const averageExecutionTime = totalTests > 0 ?
    results.reduce((sum, r) => sum + r.executionTime, 0) / totalTests :
    0;

    return {
      totalTests,
      passed,
      failed,
      errors,
      timeouts,
      skipped,
      totalExecutionTime,
      successRate,
      averageExecutionTime
    };
  }

  /**
   * Get execution report by ID
   */
  getExecutionReport(executionId: string): TestExecutionReport | null {
    return this.executionReports.get(executionId) || null;
  }

  /**
   * Get all execution reports
   */
  getAllExecutionReports(): TestExecutionReport[] {
    return Array.from(this.executionReports.values());
  }

  /**
   * Clear execution history
   */
  clearExecutionHistory(): void {
    this.executionReports.clear();
  }

  // Utility methods
  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  private chunkArray<T>(array: T[], size: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }
}

export const testExecutionEngineService = new TestExecutionEngineService();