interface AuditEvent {
  action: string;
  table_name?: string;
  record_id?: number;
  old_values?: any;
  new_values?: any;
  details?: string;
  is_security_event?: boolean;
  severity?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | 'INFO';
}

class AuditInterceptorService {
  private isEnabled = true;

  async logEvent(event: AuditEvent) {
    if (!this.isEnabled) return;

    try {
      // Get current user info if available
      const { data: userInfo } = await window.ezsite.apis.getUserInfo();

      const auditData = {
        user_id: userInfo?.ID || 0,
        user_email: userInfo?.Email || 'Anonymous',
        action: event.action,
        table_name: event.table_name || '',
        record_id: event.record_id || 0,
        old_values: event.old_values ? JSON.stringify(event.old_values) : '',
        new_values: event.new_values ? JSON.stringify(event.new_values) : '',
        ip_address: await this.getClientIP(),
        user_agent: navigator.userAgent,
        timestamp: new Date().toISOString(),
        is_security_event: event.is_security_event || false,
        severity: event.severity || 'INFO',
        details: event.details || ''
      };

      const { error } = await window.ezsite.apis.tableCreate(37723, auditData);
      if (error) {
        console.error('Failed to log audit event:', error);
      }
    } catch (error) {
      console.error('Error in audit logging:', error);
    }
  }

  private async getClientIP(): Promise<string> {
    try {
      // In production, you might want to get the real client IP from the server
      return 'Client IP'; // Placeholder - would need server-side implementation
    } catch {
      return 'Unknown';
    }
  }

  // Intercept table operations
  async interceptTableCreate(tableId: number, data: any, tableName?: string) {
    await this.logEvent({
      action: 'CREATE',
      table_name: tableName || `table_${tableId}`,
      new_values: data,
      details: `Created new record in ${tableName || `table ${tableId}`}`
    });
  }

  async interceptTableUpdate(tableId: number, data: any, oldData?: any, tableName?: string) {
    await this.logEvent({
      action: 'UPDATE',
      table_name: tableName || `table_${tableId}`,
      record_id: data.ID || data.id,
      old_values: oldData,
      new_values: data,
      details: `Updated record ${data.ID || data.id} in ${tableName || `table ${tableId}`}`
    });
  }

  async interceptTableDelete(tableId: number, recordId: number, oldData?: any, tableName?: string) {
    await this.logEvent({
      action: 'DELETE',
      table_name: tableName || `table_${tableId}`,
      record_id: recordId,
      old_values: oldData,
      details: `Deleted record ${recordId} from ${tableName || `table ${tableId}`}`
    });
  }

  // Log authentication events
  async logLogin(userEmail: string, success: boolean) {
    await this.logEvent({
      action: success ? 'LOGIN' : 'LOGIN_FAILED',
      details: `User ${success ? 'successfully logged in' : 'failed to log in'}`,
      is_security_event: !success,
      severity: success ? 'INFO' : 'MEDIUM'
    });
  }

  async logLogout(userEmail: string) {
    await this.logEvent({
      action: 'LOGOUT',
      details: `User logged out`
    });
  }

  // Log security events
  async logSecurityEvent(event: string, details: string, severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'MEDIUM') {
    await this.logEvent({
      action: 'SECURITY_EVENT',
      details: `${event}: ${details}`,
      is_security_event: true,
      severity
    });
  }

  // Log permission changes
  async logPermissionChange(targetUserId: number, targetUserEmail: string, changes: any) {
    await this.logEvent({
      action: 'PERMISSION_CHANGE',
      new_values: changes,
      details: `Changed permissions for user ${targetUserEmail}`,
      is_security_event: true,
      severity: 'HIGH'
    });
  }

  enable() {
    this.isEnabled = true;
  }

  disable() {
    this.isEnabled = false;
  }
}

export const auditInterceptor = new AuditInterceptorService();
export default auditInterceptor;