import { TestResult, TestExecutionConfig, TestExecutionSummary, TestExecutionReport } from './testExecutionEngineService';
import { ErrorHandlingReport } from './errorHandlingVerificationService';
import { ApiValidationReport } from './requestResponseValidationService';
import { ServiceRegistry } from './apiEndpointDiscoveryService';

export interface DetailedTestReport {
  reportId: string;
  generatedAt: Date;
  testScope: 'ENDPOINT' | 'SERVICE' | 'FULL_SUITE';
  scopeDetails: string;

  // Execution Summary
  executionSummary: TestExecutionSummary;

  // Test Results
  testResults: TestResult[];

  // Error Handling Analysis
  errorHandlingReports: ErrorHandlingReport[];

  // Validation Analysis
  validationReports: ApiValidationReport[];

  // Performance Metrics
  performanceMetrics: {
    averageResponseTime: number;
    slowestEndpoint: {name: string;time: number;};
    fastestEndpoint: {name: string;time: number;};
    timeoutOccurrences: number;
  };

  // Coverage Analysis
  coverageAnalysis: {
    totalEndpoints: number;
    testedEndpoints: number;
    coveragePercentage: number;
    untestedEndpoints: string[];
  };

  // Issue Summary
  issueSummary: {
    criticalIssues: string[];
    warnings: string[];
    recommendations: string[];
  };

  // Configuration
  testConfiguration: TestExecutionConfig;
}

export interface TestTrendData {
  date: Date;
  successRate: number;
  totalTests: number;
  averageExecutionTime: number;
  issueCount: number;
}

export interface EndpointHealthScore {
  endpointId: string;
  serviceName: string;
  methodName: string;
  operationType: string;
  overallScore: number; // 0-100
  functionalityScore: number;
  errorHandlingScore: number;
  validationScore: number;
  performanceScore: number;
  lastTestedAt: Date;
}

export class ApiTestReportingService {
  private reportHistory: DetailedTestReport[] = [];
  private trendData: TestTrendData[] = [];
  private endpointHealthScores: Map<string, EndpointHealthScore> = new Map();

  /**
   * Generate comprehensive test report
   */
  async generateDetailedReport(
  executionReport: TestExecutionReport,
  errorReports: ErrorHandlingReport[],
  validationReports: ApiValidationReport[],
  serviceRegistries: ServiceRegistry[])
  : Promise<DetailedTestReport> {
    const reportId = `report_${Date.now()}`;
    const generatedAt = new Date();

    // Calculate performance metrics
    const performanceMetrics = this.calculatePerformanceMetrics(executionReport.results);

    // Calculate coverage analysis
    const coverageAnalysis = this.calculateCoverageAnalysis(
      executionReport.results,
      serviceRegistries
    );

    // Generate issue summary
    const issueSummary = this.generateIssueSummary(
      executionReport,
      errorReports,
      validationReports
    );

    // Update health scores
    this.updateEndpointHealthScores(
      executionReport.results,
      errorReports,
      validationReports
    );

    const detailedReport: DetailedTestReport = {
      reportId,
      generatedAt,
      testScope: 'FULL_SUITE',
      scopeDetails: `Comprehensive API testing across ${serviceRegistries.length} services`,
      executionSummary: executionReport.summary,
      testResults: executionReport.results,
      errorHandlingReports: errorReports,
      validationReports,
      performanceMetrics,
      coverageAnalysis,
      issueSummary,
      testConfiguration: executionReport.config
    };

    // Store in history
    this.reportHistory.push(detailedReport);
    this.updateTrendData(detailedReport);

    return detailedReport;
  }

  /**
   * Calculate performance metrics from test results
   */
  private calculatePerformanceMetrics(results: TestResult[]): DetailedTestReport['performanceMetrics'] {
    if (results.length === 0) {
      return {
        averageResponseTime: 0,
        slowestEndpoint: { name: 'N/A', time: 0 },
        fastestEndpoint: { name: 'N/A', time: 0 },
        timeoutOccurrences: 0
      };
    }

    const validResults = results.filter((r) => r.executionTime > 0);
    const averageResponseTime = validResults.reduce((sum, r) => sum + r.executionTime, 0) / validResults.length;

    const sortedByTime = validResults.sort((a, b) => b.executionTime - a.executionTime);
    const slowestEndpoint = {
      name: sortedByTime[0]?.testCaseId || 'N/A',
      time: sortedByTime[0]?.executionTime || 0
    };
    const fastestEndpoint = {
      name: sortedByTime[sortedByTime.length - 1]?.testCaseId || 'N/A',
      time: sortedByTime[sortedByTime.length - 1]?.executionTime || 0
    };

    const timeoutOccurrences = results.filter((r) => r.status === 'TIMEOUT').length;

    return {
      averageResponseTime,
      slowestEndpoint,
      fastestEndpoint,
      timeoutOccurrences
    };
  }

  /**
   * Calculate test coverage analysis
   */
  private calculateCoverageAnalysis(
  results: TestResult[],
  serviceRegistries: ServiceRegistry[])
  : DetailedTestReport['coverageAnalysis'] {
    const totalEndpoints = serviceRegistries.reduce((sum, registry) => sum + registry.endpoints.length, 0);

    // Extract unique endpoints that were tested
    const testedEndpointIds = new Set<string>();
    results.forEach((result) => {
      // Extract endpoint ID from test case ID (assumes format: serviceName_methodName_*)
      const parts = result.testCaseId.split('_');
      if (parts.length >= 2) {
        const endpointId = `${parts[0]}_${parts[1]}`;
        testedEndpointIds.add(endpointId);
      }
    });

    const testedEndpoints = testedEndpointIds.size;
    const coveragePercentage = totalEndpoints > 0 ? testedEndpoints / totalEndpoints * 100 : 0;

    // Find untested endpoints
    const allEndpoints = new Set<string>();
    serviceRegistries.forEach((registry) => {
      registry.endpoints.forEach((endpoint) => {
        allEndpoints.add(`${registry.serviceName}_${endpoint.methodName}`);
      });
    });

    const untestedEndpoints = Array.from(allEndpoints).filter((endpointId) =>
    !testedEndpointIds.has(endpointId)
    );

    return {
      totalEndpoints,
      testedEndpoints,
      coveragePercentage,
      untestedEndpoints
    };
  }

  /**
   * Generate issue summary from all test results
   */
  private generateIssueSummary(
  executionReport: TestExecutionReport,
  errorReports: ErrorHandlingReport[],
  validationReports: ApiValidationReport[])
  : DetailedTestReport['issueSummary'] {
    const criticalIssues: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    // Analyze execution failures
    const failedTests = executionReport.results.filter((r) => r.status === 'FAIL' || r.status === 'ERROR');
    if (failedTests.length > 0) {
      criticalIssues.push(`${failedTests.length} test cases failed execution`);
    }

    const timeoutTests = executionReport.results.filter((r) => r.status === 'TIMEOUT');
    if (timeoutTests.length > 0) {
      warnings.push(`${timeoutTests.length} test cases timed out`);
    }

    // Analyze error handling issues
    errorReports.forEach((report) => {
      if (report.overallScore < 50) {
        criticalIssues.push(`Poor error handling in ${report.endpointId} (${report.overallScore.toFixed(1)}% score)`);
      } else if (report.overallScore < 80) {
        warnings.push(`Moderate error handling issues in ${report.endpointId}`);
      }

      // Add specific recommendations
      recommendations.push(...report.recommendations);
    });

    // Analyze validation issues
    const failedValidations = validationReports.filter((r) => r.overallStatus === 'FAIL');
    if (failedValidations.length > 0) {
      criticalIssues.push(`${failedValidations.length} endpoints failed validation checks`);
    }

    const warningValidations = validationReports.filter((r) => r.overallStatus === 'WARNING');
    if (warningValidations.length > 0) {
      warnings.push(`${warningValidations.length} endpoints have validation warnings`);
    }

    // Add validation-specific warnings
    validationReports.forEach((report) => {
      warnings.push(...report.requestValidation.warnings);
      warnings.push(...report.responseValidation.warnings);
    });

    // General recommendations
    recommendations.push('Implement comprehensive input validation');
    recommendations.push('Add proper error logging and monitoring');
    recommendations.push('Consider implementing rate limiting');
    recommendations.push('Add API documentation and examples');

    return {
      criticalIssues: [...new Set(criticalIssues)], // Remove duplicates
      warnings: [...new Set(warnings)],
      recommendations: [...new Set(recommendations)].slice(0, 10) // Top 10 recommendations
    };
  }

  /**
   * Update endpoint health scores
   */
  private updateEndpointHealthScores(
  testResults: TestResult[],
  errorReports: ErrorHandlingReport[],
  validationReports: ApiValidationReport[])
  : void {
    const endpointScores = new Map<string, Partial<EndpointHealthScore>>();

    // Process test results for functionality scores
    testResults.forEach((result) => {
      const endpointId = this.extractEndpointId(result.testCaseId);
      if (!endpointScores.has(endpointId)) {
        endpointScores.set(endpointId, { endpointId });
      }

      const score = endpointScores.get(endpointId)!;
      const isSuccess = result.status === 'PASS';
      score.functionalityScore = (score.functionalityScore || 0) + (isSuccess ? 100 : 0);
    });

    // Process error handling scores
    errorReports.forEach((report) => {
      const endpointId = report.endpointId;
      if (!endpointScores.has(endpointId)) {
        endpointScores.set(endpointId, { endpointId });
      }

      const score = endpointScores.get(endpointId)!;
      score.errorHandlingScore = report.overallScore;
      score.serviceName = report.serviceName;
      score.methodName = report.methodName;
    });

    // Process validation scores
    validationReports.forEach((report) => {
      const endpointId = report.endpoint;
      if (!endpointScores.has(endpointId)) {
        endpointScores.set(endpointId, { endpointId });
      }

      const score = endpointScores.get(endpointId)!;
      score.validationScore = report.overallStatus === 'PASS' ? 100 :
      report.overallStatus === 'WARNING' ? 75 : 0;
    });

    // Calculate overall scores and update health map
    endpointScores.forEach((partial, endpointId) => {
      const functionalityScore = partial.functionalityScore || 0;
      const errorHandlingScore = partial.errorHandlingScore || 50;
      const validationScore = partial.validationScore || 50;
      const performanceScore = 80; // Default performance score

      const overallScore =
      functionalityScore * 0.4 +
      errorHandlingScore * 0.3 +
      validationScore * 0.2 +
      performanceScore * 0.1;


      const healthScore: EndpointHealthScore = {
        endpointId,
        serviceName: partial.serviceName || 'Unknown',
        methodName: partial.methodName || 'Unknown',
        operationType: 'UNKNOWN',
        overallScore,
        functionalityScore,
        errorHandlingScore,
        validationScore,
        performanceScore,
        lastTestedAt: new Date()
      };

      this.endpointHealthScores.set(endpointId, healthScore);
    });
  }

  /**
   * Extract endpoint ID from test case ID
   */
  private extractEndpointId(testCaseId: string): string {
    const parts = testCaseId.split('_');
    return parts.length >= 2 ? `${parts[0]}.${parts[1]}` : testCaseId;
  }

  /**
   * Update trend data for historical analysis
   */
  private updateTrendData(report: DetailedTestReport): void {
    const trendPoint: TestTrendData = {
      date: report.generatedAt,
      successRate: report.executionSummary.successRate,
      totalTests: report.executionSummary.totalTests,
      averageExecutionTime: report.executionSummary.averageExecutionTime,
      issueCount: report.issueSummary.criticalIssues.length + report.issueSummary.warnings.length
    };

    this.trendData.push(trendPoint);

    // Keep only last 30 data points
    if (this.trendData.length > 30) {
      this.trendData = this.trendData.slice(-30);
    }
  }

  /**
   * Generate HTML report
   */
  generateHtmlReport(report: DetailedTestReport): string {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>API Testing Report - ${report.reportId}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }
          .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .header { text-align: center; border-bottom: 3px solid #007bff; padding-bottom: 20px; margin-bottom: 30px; }
          .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
          .summary-card { background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #007bff; }
          .metric-value { font-size: 2em; font-weight: bold; color: #007bff; }
          .section { margin-bottom: 40px; }
          .section-title { font-size: 1.5em; font-weight: bold; color: #333; border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 20px; }
          .status-pass { color: #28a745; font-weight: bold; }
          .status-fail { color: #dc3545; font-weight: bold; }
          .status-warning { color: #ffc107; font-weight: bold; }
          .issue-list { background: #fff3cd; padding: 15px; border-radius: 5px; border: 1px solid #ffeaa7; }
          .recommendation-list { background: #d1ecf1; padding: 15px; border-radius: 5px; border: 1px solid #bee5eb; }
          table { width: 100%; border-collapse: collapse; margin-top: 15px; }
          th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
          th { background-color: #f8f9fa; font-weight: bold; }
          .progress-bar { width: 100%; height: 20px; background-color: #e9ecef; border-radius: 10px; overflow: hidden; }
          .progress-fill { height: 100%; background-color: #28a745; transition: width 0.3s; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>API Testing Report</h1>
            <p><strong>Report ID:</strong> ${report.reportId}</p>
            <p><strong>Generated:</strong> ${report.generatedAt.toLocaleString()}</p>
            <p><strong>Scope:</strong> ${report.scopeDetails}</p>
          </div>

          <div class="summary-grid">
            <div class="summary-card">
              <h3>Test Execution</h3>
              <div class="metric-value">${report.executionSummary.successRate.toFixed(1)}%</div>
              <p>Success Rate</p>
            </div>
            <div class="summary-card">
              <h3>Total Tests</h3>
              <div class="metric-value">${report.executionSummary.totalTests}</div>
              <p>Executed</p>
            </div>
            <div class="summary-card">
              <h3>Coverage</h3>
              <div class="metric-value">${report.coverageAnalysis.coveragePercentage.toFixed(1)}%</div>
              <p>Endpoint Coverage</p>
            </div>
            <div class="summary-card">
              <h3>Performance</h3>
              <div class="metric-value">${report.performanceMetrics.averageResponseTime.toFixed(0)}ms</div>
              <p>Avg Response Time</p>
            </div>
          </div>

          <div class="section">
            <h2 class="section-title">Test Results Summary</h2>
            <div class="progress-bar">
              <div class="progress-fill" style="width: ${report.executionSummary.successRate}%"></div>
            </div>
            <p style="margin-top: 10px;">
              <span class="status-pass">✓ ${report.executionSummary.passed} Passed</span> | 
              <span class="status-fail">✗ ${report.executionSummary.failed} Failed</span> | 
              <span class="status-warning">⚠ ${report.executionSummary.errors + report.executionSummary.timeouts} Errors/Timeouts</span>
            </p>
          </div>

          <div class="section">
            <h2 class="section-title">Critical Issues</h2>
            <div class="issue-list">
              ${report.issueSummary.criticalIssues.length > 0 ?
    report.issueSummary.criticalIssues.map((issue) => `<p>🚨 ${issue}</p>`).join('') :
    '<p>✅ No critical issues found!</p>'}
            </div>
          </div>

          <div class="section">
            <h2 class="section-title">Recommendations</h2>
            <div class="recommendation-list">
              ${
    report.issueSummary.recommendations.slice(0, 5).map((rec) => `<p>💡 ${rec}</p>`).join('')}
            </div>
          </div>

          <div class="section">
            <h2 class="section-title">Performance Metrics</h2>
            <table>
              <tr>
                <th>Metric</th>
                <th>Value</th>
              </tr>
              <tr>
                <td>Average Response Time</td>
                <td>${report.performanceMetrics.averageResponseTime.toFixed(2)}ms</td>
              </tr>
              <tr>
                <td>Slowest Endpoint</td>
                <td>${report.performanceMetrics.slowestEndpoint.name} (${report.performanceMetrics.slowestEndpoint.time.toFixed(2)}ms)</td>
              </tr>
              <tr>
                <td>Fastest Endpoint</td>
                <td>${report.performanceMetrics.fastestEndpoint.name} (${report.performanceMetrics.fastestEndpoint.time.toFixed(2)}ms)</td>
              </tr>
              <tr>
                <td>Timeout Occurrences</td>
                <td>${report.performanceMetrics.timeoutOccurrences}</td>
              </tr>
            </table>
          </div>

          <div class="section">
            <h2 class="section-title">Coverage Analysis</h2>
            <p><strong>Total Endpoints:</strong> ${report.coverageAnalysis.totalEndpoints}</p>
            <p><strong>Tested Endpoints:</strong> ${report.coverageAnalysis.testedEndpoints}</p>
            <p><strong>Coverage:</strong> ${report.coverageAnalysis.coveragePercentage.toFixed(1)}%</p>
            ${report.coverageAnalysis.untestedEndpoints.length > 0 ?
    `<p><strong>Untested Endpoints:</strong> ${report.coverageAnalysis.untestedEndpoints.slice(0, 10).join(', ')}${report.coverageAnalysis.untestedEndpoints.length > 10 ? '...' : ''}</p>` :
    ''}
          </div>

          <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee;">
            <p style="color: #666;">Generated by API Testing Framework at ${
    new Date().toLocaleString()}</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  /**
   * Export report as JSON
   */
  exportReportAsJson(report: DetailedTestReport): string {
    return JSON.stringify(report, null, 2);
  }

  /**
   * Get endpoint health scores
   */
  getEndpointHealthScores(): EndpointHealthScore[] {
    return Array.from(this.endpointHealthScores.values()).sort((a, b) => b.overallScore - a.overallScore);
  }

  /**
   * Get trend data for charts
   */
  getTrendData(): TestTrendData[] {
    return [...this.trendData];
  }

  /**
   * Get report history
   */
  getReportHistory(limit?: number): DetailedTestReport[] {
    const reports = [...this.reportHistory].sort((a, b) => b.generatedAt.getTime() - a.generatedAt.getTime());
    return limit ? reports.slice(0, limit) : reports;
  }

  /**
   * Clear report history
   */
  clearReportHistory(): void {
    this.reportHistory = [];
    this.trendData = [];
    this.endpointHealthScores.clear();
  }
}

export const apiTestReportingService = new ApiTestReportingService();