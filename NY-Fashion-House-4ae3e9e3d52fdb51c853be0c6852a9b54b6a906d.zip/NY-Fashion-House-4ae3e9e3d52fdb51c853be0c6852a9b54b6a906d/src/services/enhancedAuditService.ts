import { AuditLog, AuditLogFilters, SecurityEvent, AuditStats, AuditLogRetentionSettings } from '@/types/audit';

class EnhancedAuditService {
  private tableId = '37723'; // audit_logs table ID

  // Log an audit event
  async logEvent(
  action: string,
  tableName?: string,
  recordId?: string,
  oldValues?: Record<string, any>,
  newValues?: Record<string, any>,
  isSecurityEvent: boolean = false,
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW',
  eventDescription?: string)
  : Promise<void> {
    try {
      // Get user info
      const { data: userInfo } = await window.ezsite.apis.getUserInfo();

      // Get client info
      const ipAddress = await this.getClientIP();
      const userAgent = navigator.userAgent;
      const sessionId = this.generateSessionId();

      const auditData = {
        user_id: userInfo?.ID || 0,
        user_name: userInfo?.Name || 'Anonymous',
        user_email: userInfo?.Email || '',
        action,
        table_name: tableName || '',
        record_id: recordId || '',
        old_values: oldValues ? JSON.stringify(oldValues) : '',
        new_values: newValues ? JSON.stringify(newValues) : '',
        ip_address: ipAddress,
        user_agent: userAgent,
        timestamp: new Date().toISOString(),
        session_id: sessionId,
        is_security_event: isSecurityEvent,
        severity,
        event_description: eventDescription || `${action} performed on ${tableName || 'system'}`,
        metadata: JSON.stringify({
          timestamp_formatted: new Date().toLocaleString('en-US', {
            timeZone: 'America/New_York',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
          }),
          browser: this.getBrowserInfo(),
          screen_resolution: `${window.screen.width}x${window.screen.height}`,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        })
      };

      await window.ezsite.apis.tableCreate(this.tableId, auditData);
    } catch (error) {
      console.error('Failed to log audit event:', error);
      // Don't throw error to avoid breaking the main operation
    }
  }

  // Log security events with special handling
  async logSecurityEvent(event: SecurityEvent): Promise<void> {
    await this.logEvent(
      event.type,
      'SECURITY',
      undefined,
      undefined,
      event.metadata,
      true,
      event.severity,
      event.description
    );
  }

  // Get audit logs with pagination and filtering
  async getAuditLogs(
  filters: AuditLogFilters = {},
  page: number = 1,
  pageSize: number = 50)
  : Promise<{logs: AuditLog[];total: number;}> {
    try {
      const queryFilters = this.buildFilters(filters);

      const { data, error } = await window.ezsite.apis.tablePage(this.tableId, {
        PageNo: page,
        PageSize: pageSize,
        OrderByField: 'timestamp',
        IsAsc: false,
        Filters: queryFilters
      });

      if (error) throw error;

      const logs = data.List.map(this.transformAuditLog);
      return {
        logs,
        total: data.VirtualCount
      };
    } catch (error) {
      console.error('Failed to fetch audit logs:', error);
      throw error;
    }
  }

  // Get audit statistics
  async getAuditStats(dateRange?: {start: string;end: string;}): Promise<AuditStats> {
    try {
      const filters = [];

      if (dateRange) {
        filters.push(
          { name: 'timestamp', op: 'GreaterThanOrEqual' as const, value: dateRange.start },
          { name: 'timestamp', op: 'LessThanOrEqual' as const, value: dateRange.end }
        );
      }

      const { data, error } = await window.ezsite.apis.tablePage(this.tableId, {
        PageNo: 1,
        PageSize: 10000, // Get all for stats
        OrderByField: 'timestamp',
        IsAsc: false,
        Filters: filters
      });

      if (error) throw error;

      const logs = data.List;

      return {
        total_logs: data.VirtualCount,
        security_events: logs.filter((log: any) => log.is_security_event).length,
        failed_logins: logs.filter((log: any) => log.action === 'FAILED_LOGIN').length,
        data_modifications: logs.filter((log: any) =>
        ['CREATE', 'UPDATE', 'DELETE'].includes(log.action)
        ).length,
        unique_users: new Set(logs.map((log: any) => log.user_id).filter(Boolean)).size,
        recent_activity_count: logs.filter((log: any) => {
          const logTime = new Date(log.timestamp);
          const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
          return logTime > hourAgo;
        }).length,
        critical_events: logs.filter((log: any) =>
        ['HIGH', 'CRITICAL'].includes(log.severity)
        ).length
      };
    } catch (error) {
      console.error('Failed to get audit stats:', error);
      throw error;
    }
  }

  // Clean up old logs based on retention settings
  async cleanupOldLogs(settings: AuditLogRetentionSettings): Promise<number> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - settings.retention_days);

      const { data, error } = await window.ezsite.apis.tablePage(this.tableId, {
        PageNo: 1,
        PageSize: 10000,
        OrderByField: 'timestamp',
        IsAsc: true,
        Filters: [
        { name: 'timestamp', op: 'LessThan' as const, value: cutoffDate.toISOString() }]

      });

      if (error) throw error;

      let deletedCount = 0;
      for (const log of data.List) {
        await window.ezsite.apis.tableDelete(this.tableId, { ID: log.id });
        deletedCount++;
      }

      // Log cleanup activity
      await this.logEvent(
        'AUDIT_CLEANUP',
        'audit_logs',
        undefined,
        undefined,
        { deleted_count: deletedCount, retention_days: settings.retention_days },
        false,
        'LOW',
        `Cleaned up ${deletedCount} old audit logs (retention: ${settings.retention_days} days)`
      );

      return deletedCount;
    } catch (error) {
      console.error('Failed to cleanup old logs:', error);
      throw error;
    }
  }

  // Export audit logs
  async exportLogs(
  format: 'CSV' | 'PDF',
  filters: AuditLogFilters = {},
  includeSensitiveData: boolean = false)
  : Promise<Blob> {
    try {
      const { logs } = await this.getAuditLogs(filters, 1, 10000);

      if (format === 'CSV') {
        return this.exportToCSV(logs, includeSensitiveData);
      } else {
        return this.exportToPDF(logs, includeSensitiveData);
      }
    } catch (error) {
      console.error('Failed to export logs:', error);
      throw error;
    }
  }

  // Private helper methods
  private buildFilters(filters: AuditLogFilters) {
    const queryFilters = [];

    if (filters.user_id) {
      queryFilters.push({ name: 'user_id', op: 'Equal' as const, value: filters.user_id });
    }
    if (filters.user_name) {
      queryFilters.push({ name: 'user_name', op: 'StringContains' as const, value: filters.user_name });
    }
    if (filters.user_email) {
      queryFilters.push({ name: 'user_email', op: 'StringContains' as const, value: filters.user_email });
    }
    if (filters.action) {
      queryFilters.push({ name: 'action', op: 'Equal' as const, value: filters.action });
    }
    if (filters.table_name) {
      queryFilters.push({ name: 'table_name', op: 'Equal' as const, value: filters.table_name });
    }
    if (filters.start_date) {
      queryFilters.push({ name: 'timestamp', op: 'GreaterThanOrEqual' as const, value: filters.start_date });
    }
    if (filters.end_date) {
      queryFilters.push({ name: 'timestamp', op: 'LessThanOrEqual' as const, value: filters.end_date });
    }
    if (filters.ip_address) {
      queryFilters.push({ name: 'ip_address', op: 'StringContains' as const, value: filters.ip_address });
    }
    if (filters.is_security_event !== undefined) {
      queryFilters.push({ name: 'is_security_event', op: 'Equal' as const, value: filters.is_security_event });
    }

    return queryFilters;
  }

  private transformAuditLog(log: any): AuditLog {
    return {
      id: log.id,
      user_id: log.user_id,
      user_name: log.user_name || '',
      user_email: log.user_email || '',
      action: log.action || '',
      table_name: log.table_name,
      record_id: log.record_id,
      old_values: log.old_values,
      new_values: log.new_values,
      ip_address: log.ip_address,
      user_agent: log.user_agent,
      timestamp: log.timestamp,
      session_id: log.session_id,
      is_security_event: log.is_security_event || false,
      severity: log.severity || 'LOW',
      event_description: log.event_description || '',
      metadata: log.metadata
    };
  }

  private async getClientIP(): Promise<string> {
    try {
      // This would normally be handled by the server
      return 'CLIENT_IP';
    } catch {
      return 'UNKNOWN';
    }
  }

  private generateSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private getBrowserInfo(): string {
    const ua = navigator.userAgent;
    if (ua.includes('Chrome')) return 'Chrome';
    if (ua.includes('Firefox')) return 'Firefox';
    if (ua.includes('Safari')) return 'Safari';
    if (ua.includes('Edge')) return 'Edge';
    return 'Unknown';
  }

  private exportToCSV(logs: AuditLog[], includeSensitiveData: boolean): Blob {
    const headers = [
    'ID', 'User Name', 'Email', 'Action', 'Table', 'Record ID',
    'Timestamp', 'IP Address', 'Security Event', 'Severity', 'Description'];


    if (includeSensitiveData) {
      headers.push('Old Values', 'New Values', 'User Agent', 'Session ID');
    }

    const rows = [headers.join(',')];

    logs.forEach((log) => {
      const row = [
      log.id,
      `"${log.user_name}"`,
      `"${log.user_email}"`,
      log.action,
      log.table_name || '',
      log.record_id || '',
      new Date(log.timestamp).toLocaleString('en-US', { timeZone: 'America/New_York' }),
      log.ip_address || '',
      log.is_security_event ? 'Yes' : 'No',
      log.severity,
      `"${log.event_description}"`];


      if (includeSensitiveData) {
        row.push(
          `"${log.old_values || ''}"`,
          `"${log.new_values || ''}"`,
          `"${log.user_agent || ''}"`,
          log.session_id || ''
        );
      }

      rows.push(row.join(','));
    });

    return new Blob([rows.join('\n')], { type: 'text/csv' });
  }

  private exportToPDF(logs: AuditLog[], includeSensitiveData: boolean): Blob {
    // Simple text-based PDF export for now
    let content = 'AUDIT LOGS REPORT\n';
    content += `Generated: ${new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })}\n`;
    content += `Total Records: ${logs.length}\n\n`;

    logs.forEach((log, index) => {
      content += `${index + 1}. ${log.action} by ${log.user_name}\n`;
      content += `   Time: ${new Date(log.timestamp).toLocaleString('en-US', { timeZone: 'America/New_York' })}\n`;
      content += `   Table: ${log.table_name || 'N/A'}\n`;
      content += `   Security Event: ${log.is_security_event ? 'Yes' : 'No'}\n`;
      content += `   Severity: ${log.severity}\n`;
      content += `   Description: ${log.event_description}\n`;

      if (includeSensitiveData && (log.old_values || log.new_values)) {
        if (log.old_values) content += `   Old Values: ${log.old_values}\n`;
        if (log.new_values) content += `   New Values: ${log.new_values}\n`;
      }
      content += '\n';
    });

    return new Blob([content], { type: 'application/pdf' });
  }
}

const enhancedAuditService = new EnhancedAuditService();
export default enhancedAuditService;