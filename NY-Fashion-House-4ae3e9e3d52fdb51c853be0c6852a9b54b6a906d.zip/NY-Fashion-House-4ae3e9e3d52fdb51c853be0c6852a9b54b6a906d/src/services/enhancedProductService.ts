
import { Product, ProductVariant, StockAdjustment, LowStockAlert, ProductSearchParams, ProductCategory } from '@/types/product';
import { apiWrapper } from '@/utils/apiWrapper';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import { skuGenerator } from '@/services/skuGenerator';

// Database service for product management
const PRODUCTS_TABLE_ID = 38157; // ID of the products table

interface DatabaseProduct {
  id: number;
  sku: string;
  name: string;
  description: string;
  category: string;
  cost_price: number;
  selling_price: number;
  stock_level: number;
  min_stock_level: number;
  supplier_id: string;
  barcode: string;
  sizes: string;
  colors: string;
  image_url: string;
  image_ids: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Connection health monitoring
class ConnectionMonitor {
  private isConnected = true;
  private lastSuccessfulRequest = Date.now();
  private failureCount = 0;
  private readonly MAX_FAILURES = 3;
  private readonly CONNECTION_TIMEOUT = 30000; // 30 seconds

  async testConnection(): Promise<boolean> {
    try {
      // Simple test query to check database connectivity
      const { error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: []
      });

      if (!error) {
        this.onConnectionSuccess();
        return true;
      } else {
        this.onConnectionFailure(new Error(error));
        return false;
      }
    } catch (error) {
      this.onConnectionFailure(error as Error);
      return false;
    }
  }

  private onConnectionSuccess(): void {
    this.isConnected = true;
    this.lastSuccessfulRequest = Date.now();
    this.failureCount = 0;
  }

  private onConnectionFailure(error: Error): void {
    this.failureCount++;
    if (this.failureCount >= this.MAX_FAILURES) {
      this.isConnected = false;
    }

    enhancedErrorLoggingService.logErrorWithDetails(error, {
      title: 'Database Connection Failure',
      category: 'database',
      severity: 'high',
      service: 'ConnectionMonitor',
      failureCount: this.failureCount,
      isConnected: this.isConnected
    });
  }

  getHealthStatus(): {
    isConnected: boolean;
    lastSuccessfulRequest: number;
    failureCount: number;
    needsRestoration: boolean;
  } {
    const timeSinceLastSuccess = Date.now() - this.lastSuccessfulRequest;
    return {
      isConnected: this.isConnected,
      lastSuccessfulRequest: this.lastSuccessfulRequest,
      failureCount: this.failureCount,
      needsRestoration: timeSinceLastSuccess > this.CONNECTION_TIMEOUT
    };
  }

  async attemptReconnection(): Promise<boolean> {
    enhancedErrorLoggingService.logErrorWithDetails(new Error('Attempting database reconnection'), {
      title: 'Database Reconnection Attempt',
      category: 'database',
      severity: 'medium',
      service: 'ConnectionMonitor'
    });

    return await this.testConnection();
  }
}

const connectionMonitor = new ConnectionMonitor();

// Helper functions for data conversion
const convertFromDatabase = (dbProduct: DatabaseProduct): Product => {
  try {
    const imageIds = dbProduct.image_ids ? JSON.parse(dbProduct.image_ids) : [];
    const sizes = dbProduct.sizes ? dbProduct.sizes.split(',').map((s) => s.trim()).filter(Boolean) : [];
    const colors = dbProduct.colors ? dbProduct.colors.split(',').map((c) => c.trim()).filter(Boolean) : [];

    return {
      id: dbProduct.id.toString(),
      sku: dbProduct.sku || '',
      name: dbProduct.name || '',
      description: dbProduct.description || '',
      category: (dbProduct.category || 'casual-wear') as ProductCategory,
      costPrice: dbProduct.cost_price || 0,
      sellingPrice: dbProduct.selling_price || 0,
      stockLevel: dbProduct.stock_level || 0,
      minStockLevel: dbProduct.min_stock_level || 0,
      supplierId: dbProduct.supplier_id || '',
      barcode: dbProduct.barcode || '',
      sizes,
      colors,
      images: [dbProduct.image_url].filter(Boolean), // Legacy support
      imageIds,
      createdAt: new Date(dbProduct.created_at || Date.now()),
      updatedAt: new Date(dbProduct.updated_at || Date.now()),
      isActive: dbProduct.is_active !== false
    };
  } catch (error) {
    enhancedErrorLoggingService.logErrorWithDetails(error as Error, {
      title: 'Product Data Conversion Error',
      severity: 'medium',
      category: 'validation',
      service: 'productService',
      operation: 'convertFromDatabase',
      productId: dbProduct.id,
      productData: dbProduct
    });

    // Return a default product to prevent complete failure
    return {
      id: dbProduct.id.toString(),
      sku: dbProduct.sku || 'UNKNOWN',
      name: dbProduct.name || 'Unknown Product',
      description: dbProduct.description || '',
      category: 'casual-wear' as ProductCategory,
      costPrice: dbProduct.cost_price || 0,
      sellingPrice: dbProduct.selling_price || 0,
      stockLevel: dbProduct.stock_level || 0,
      minStockLevel: dbProduct.min_stock_level || 0,
      supplierId: dbProduct.supplier_id || '',
      barcode: dbProduct.barcode || '',
      sizes: [],
      colors: [],
      images: [],
      imageIds: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      isActive: true
    };
  }
};

const convertToDatabase = (product: Partial<Product>): Partial<DatabaseProduct> => {
  return {
    sku: product.sku,
    name: product.name,
    description: product.description,
    category: product.category,
    cost_price: product.costPrice,
    selling_price: product.sellingPrice,
    stock_level: product.stockLevel,
    min_stock_level: product.minStockLevel,
    supplier_id: product.supplierId,
    barcode: product.barcode,
    sizes: product.sizes ? product.sizes.join(', ') : '',
    colors: product.colors ? product.colors.join(', ') : '',
    image_url: product.images?.[0] || '', // Legacy support
    image_ids: product.imageIds ? JSON.stringify(product.imageIds) : '[]',
    is_active: product.isActive,
    created_at: product.createdAt?.toISOString(),
    updated_at: new Date().toISOString()
  };
};

let stockAdjustments: StockAdjustment[] = [];
let lowStockAlerts: LowStockAlert[] = [];

export const enhancedProductService = {
  // Connection management
  getConnectionStatus: () => connectionMonitor.getHealthStatus(),

  testConnection: () => connectionMonitor.testConnection(),

  restoreConnection: () => connectionMonitor.attemptReconnection(),

  // Product CRUD operations with enhanced error handling
  getAllProducts: async (params?: ProductSearchParams): Promise<Product[]> => {
    const context = {
      title: 'Product Service Error',
      action: 'Fetch product list',
      operation: 'getAllProducts',
      severity: 'medium' as const,
      category: 'database' as const,
      service: 'productService'
    };

    return await enhancedErrorLoggingService.withRetry(async () => {
      const filters = [];

      // Add active filter
      filters.push({
        name: 'is_active',
        op: 'Equal',
        value: true
      });

      if (params) {
        // Search by query
        if (params.query) {
          filters.push({
            name: 'name',
            op: 'StringContains',
            value: params.query
          });
        }

        // Filter by category
        if (params.category) {
          filters.push({
            name: 'category',
            op: 'Equal',
            value: params.category
          });
        }

        // Filter by supplier
        if (params.supplier) {
          filters.push({
            name: 'supplier_id',
            op: 'Equal',
            value: params.supplier
          });
        }

        // Filter by price range
        if (params.priceRange) {
          const [min, max] = params.priceRange;
          filters.push({
            name: 'selling_price',
            op: 'GreaterThanOrEqual',
            value: min
          });
          filters.push({
            name: 'selling_price',
            op: 'LessThanOrEqual',
            value: max
          });
        }
      }

      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: params?.sortBy === 'name' ? 'name' :
        params?.sortBy === 'price' ? 'selling_price' :
        params?.sortBy === 'stock' ? 'stock_level' :
        params?.sortBy === 'category' ? 'category' : 'created_at',
        IsAsc: params?.sortOrder !== 'desc',
        Filters: filters
      });

      if (error) {
        throw new Error(`Database query failed: ${error}`);
      }

      if (!data || !data.List) {
        console.warn('No data returned from database, returning empty array');
        return [];
      }

      const products = data.List.map(convertFromDatabase);

      // Apply client-side filtering for complex cases
      let filteredProducts = products;

      if (params) {
        // Filter by size
        if (params.size) {
          filteredProducts = filteredProducts.filter((p) => p.sizes.includes(params.size!));
        }

        // Filter by color
        if (params.color) {
          filteredProducts = filteredProducts.filter((p) => p.colors.includes(params.color!));
        }

        // Filter by stock status
        if (params.inStock !== undefined) {
          filteredProducts = filteredProducts.filter((p) =>
          params.inStock ? p.stockLevel > 0 : p.stockLevel === 0
          );
        }

        if (params.lowStock !== undefined && params.lowStock) {
          filteredProducts = filteredProducts.filter((p) => p.stockLevel <= p.minStockLevel);
        }
      }

      return filteredProducts;
    }, context, 3, 1000);
  },

  getProductById: async (id: string): Promise<Product | null> => {
    const context = {
      title: 'Product Service Error',
      action: 'Fetch single product',
      operation: 'getProductById',
      severity: 'medium' as const,
      category: 'database' as const,
      service: 'productService',
      productId: id
    };

    return await enhancedErrorLoggingService.withRetry(async () => {
      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'id',
          op: 'Equal',
          value: parseInt(id)
        },
        {
          name: 'is_active',
          op: 'Equal',
          value: true
        }]

      });

      if (error) {
        throw new Error(`Database query failed: ${error}`);
      }

      if (data && data.List && data.List.length > 0) {
        return convertFromDatabase(data.List[0]);
      }

      return null;
    }, context, 2, 500);
  },

  createProduct: async (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'barcode' | 'sku'>): Promise<Product> => {
    const context = {
      title: 'Product Service Error',
      action: 'Create new product',
      operation: 'createProduct',
      severity: 'medium' as const,
      category: 'database' as const,
      service: 'productService'
    };

    return await enhancedErrorLoggingService.withRetry(async () => {
      // Generate unique 128-character SKU
      const sku = await skuGenerator.generateSKU(productData.name, productData.category);
      const barcode = `${Date.now()}${Math.random().toString().substr(2, 3)}`;
      const dbData = convertToDatabase({
        ...productData,
        sku,
        barcode,
        createdAt: new Date(),
        updatedAt: new Date()
      });

      const { error } = await window.ezsite.apis.tableCreate(PRODUCTS_TABLE_ID, dbData);

      if (error) {
        throw new Error(`Product creation failed: ${error}`);
      }

      // Fetch the created product
      const products = await enhancedProductService.getAllProducts();
      const newProduct = products.find((p) => p.barcode === barcode);

      if (!newProduct) {
        throw new Error('Failed to retrieve created product');
      }

      return newProduct;
    }, context, 2, 1000);
  },

  updateProduct: async (id: string, productData: Partial<Product>): Promise<Product> => {
    const context = {
      title: 'Product Service Error',
      action: 'Update product',
      operation: 'updateProduct',
      severity: 'medium' as const,
      category: 'database' as const,
      service: 'productService',
      productId: id
    };

    return await enhancedErrorLoggingService.withRetry(async () => {
      const dbData = convertToDatabase({
        ...productData,
        updatedAt: new Date()
      });

      const { error } = await window.ezsite.apis.tableUpdate(PRODUCTS_TABLE_ID, {
        ID: parseInt(id),
        ...dbData
      });

      if (error) {
        throw new Error(`Product update failed: ${error}`);
      }

      // Fetch the updated product
      const updatedProduct = await enhancedProductService.getProductById(id);

      if (!updatedProduct) {
        throw new Error('Failed to retrieve updated product');
      }

      return updatedProduct;
    }, context, 2, 1000);
  },

  deleteProduct: async (id: string): Promise<void> => {
    const context = {
      title: 'Product Service Error',
      action: 'Delete product',
      operation: 'deleteProduct',
      severity: 'medium' as const,
      category: 'database' as const,
      service: 'productService',
      productId: id
    };

    return await enhancedErrorLoggingService.withRetry(async () => {
      // First, verify the product exists and is active
      const product = await enhancedProductService.getProductById(id);
      if (!product) {
        throw new Error('Product not found or already deleted');
      }

      if (!product.isActive) {
        // Product is already inactive (deleted)
        return;
      }

      // Perform soft delete by setting is_active to false
      const { error } = await window.ezsite.apis.tableUpdate(PRODUCTS_TABLE_ID, {
        ID: parseInt(id),
        is_active: false,
        updated_at: new Date().toISOString()
      });

      if (error) {
        // Log specific database error details
        console.error('Database deletion error:', error);
        throw new Error(`Unable to delete product: ${error}`);
      }

      // Verify deletion was successful
      const verifyProduct = await enhancedProductService.getProductById(id);
      if (verifyProduct && verifyProduct.isActive) {
        throw new Error('Product deletion verification failed');
      }
    }, context, 2, 1000);
  },

  // Stock management with error handling
  adjustStock: async (adjustment: Omit<StockAdjustment, 'id' | 'date'>): Promise<void> => {
    const context = {
      title: 'Stock Adjustment Error',
      action: 'Adjust product stock',
      operation: 'adjustStock',
      severity: 'medium' as const,
      category: 'database' as const,
      service: 'productService',
      productId: adjustment.productId
    };

    return await enhancedErrorLoggingService.withRetry(async () => {
      const product = await enhancedProductService.getProductById(adjustment.productId);
      if (!product) {
        throw new Error('Product not found');
      }

      const newAdjustment: StockAdjustment = {
        ...adjustment,
        id: Date.now().toString(),
        date: new Date()
      };

      stockAdjustments.push(newAdjustment);

      // Update product stock
      const stockChange = adjustment.type === 'out' ? -adjustment.quantity : adjustment.quantity;
      const newStockLevel = Math.max(0, product.stockLevel + stockChange);

      await enhancedProductService.updateProduct(adjustment.productId, {
        stockLevel: newStockLevel
      });
    }, context, 2, 1000);
  },

  getStockAdjustments: async (productId?: string): Promise<StockAdjustment[]> => {
    const filtered = productId ?
    stockAdjustments.filter((adj) => adj.productId === productId) :
    stockAdjustments;

    return filtered.sort((a, b) => b.date.getTime() - a.date.getTime());
  },

  getLowStockAlerts: async (): Promise<LowStockAlert[]> => {
    try {
      const products = await enhancedProductService.getAllProducts();
      const alerts = products.
      filter((product) => product.stockLevel <= product.minStockLevel && product.isActive).
      map((product) => ({
        id: `alert-${product.id}`,
        productId: product.id,
        productName: product.name,
        currentStock: product.stockLevel,
        minStockLevel: product.minStockLevel,
        createdAt: new Date(),
        isResolved: false
      }));

      return alerts;
    } catch (error) {
      enhancedErrorLoggingService.logErrorWithDetails(error as Error, {
        title: 'Low Stock Alerts Error',
        action: 'Generate low stock alerts',
        operation: 'getLowStockAlerts',
        severity: 'low',
        category: 'server',
        service: 'productService'
      });
      return [];
    }
  },

  // Utility functions
  getCategories: (): ProductCategory[] => {
    return [
    'sarees',
    'kurtis',
    'lehengas',
    'salwar-suits',
    'tops',
    'bottoms',
    'accessories',
    'ethnic-wear',
    'casual-wear',
    'formal-wear'];

  },

  getSizes: (): string[] => {
    return ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', 'Free Size'];
  },

  getColors: (): string[] => {
    return ['Red', 'Blue', 'Green', 'Yellow', 'Pink', 'Purple', 'Orange', 'Black', 'White', 'Grey', 'Brown', 'Navy Blue', 'Maroon', 'Golden', 'Silver', 'Cream', 'Peach', 'Mint Green', 'Lavender', 'Light Blue'];
  },

  // Search product by barcode with enhanced error handling
  searchProductByBarcode: async (barcode: string): Promise<Product | null> => {
    const context = {
      title: 'Barcode Search Error',
      action: 'Search product by barcode',
      operation: 'searchProductByBarcode',
      severity: 'low' as const,
      category: 'database' as const,
      service: 'productService',
      barcode
    };

    return await enhancedErrorLoggingService.withRetry(async () => {
      if (!barcode || barcode.trim().length === 0) {
        throw new Error('Barcode cannot be empty');
      }

      // Validate barcode format (basic validation)
      if (barcode.length < 6 || !/^\d+$/.test(barcode.slice(-6))) {
        throw new Error('Invalid barcode format');
      }

      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'barcode',
          op: 'Equal',
          value: barcode
        },
        {
          name: 'is_active',
          op: 'Equal',
          value: true
        }]

      });

      if (error) {
        throw new Error(`Barcode search failed: ${error}`);
      }

      if (!data || !data.List || data.List.length === 0) {
        return null;
      }

      return convertFromDatabase(data.List[0]);
    }, context, 2, 500);
  },

  generateBarcode: (sku: string): string => {
    const timestamp = Date.now().toString();
    return `${sku}${timestamp.slice(-6)}`;
  },

  // Enhanced validation for barcode
  validateBarcode: (barcode: string): {isValid: boolean;error?: string;} => {
    if (!barcode || barcode.trim().length === 0) {
      return { isValid: false, error: 'Barcode cannot be empty' };
    }

    if (barcode.length < 6) {
      return { isValid: false, error: 'Barcode must be at least 6 characters long' };
    }

    if (barcode.length > 20) {
      return { isValid: false, error: 'Barcode cannot exceed 20 characters' };
    }

    // Allow alphanumeric characters and hyphens
    if (!/^[a-zA-Z0-9\-]+$/.test(barcode)) {
      return { isValid: false, error: 'Barcode can only contain letters, numbers, and hyphens' };
    }

    return { isValid: true };
  },

  // Health check and diagnostics
  performHealthCheck: async (): Promise<{
    isHealthy: boolean;
    connectionStatus: any;
    errorCount: number;
    lastError?: any;
    recommendations: string[];
  }> => {
    const connectionStatus = connectionMonitor.getHealthStatus();
    const recentErrors = enhancedErrorLoggingService.getRecentErrors(5);
    const recommendations: string[] = [];

    if (!connectionStatus.isConnected) {
      recommendations.push('Database connection is down - attempting to restore');
      await connectionMonitor.attemptReconnection();
    }

    if (connectionStatus.failureCount > 0) {
      recommendations.push('Multiple connection failures detected - check network connectivity');
    }

    if (recentErrors.length > 3) {
      recommendations.push('High error rate detected - consider clearing cache or contacting support');
    }

    return {
      isHealthy: connectionStatus.isConnected && recentErrors.length < 3,
      connectionStatus,
      errorCount: recentErrors.length,
      lastError: recentErrors[0],
      recommendations
    };
  }
};