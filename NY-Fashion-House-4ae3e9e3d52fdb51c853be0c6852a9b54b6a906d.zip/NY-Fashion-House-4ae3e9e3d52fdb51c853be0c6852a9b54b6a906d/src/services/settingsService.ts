
import { SystemSetting, SettingsExport } from '@/types/settings';

const SYSTEM_SETTINGS_TABLE_ID = 37722;

export class SettingsService {
  static async getAllSettings(): Promise<SystemSetting[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SYSTEM_SETTINGS_TABLE_ID, {
        "PageNo": 1,
        "PageSize": 1000,
        "OrderByField": "category",
        "IsAsc": true,
        "Filters": []
      });

      if (error) throw new Error(error);

      return data?.List || [];
    } catch (error) {
      console.error('Error fetching settings:', error);
      throw error;
    }
  }

  static async getSettingsByCategory(category: string): Promise<SystemSetting[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SYSTEM_SETTINGS_TABLE_ID, {
        "PageNo": 1,
        "PageSize": 1000,
        "OrderByField": "setting_key",
        "IsAsc": true,
        "Filters": [
        {
          "name": "category",
          "op": "Equal",
          "value": category
        },
        {
          "name": "is_active",
          "op": "Equal",
          "value": true
        }]

      });

      if (error) throw new Error(error);

      return data?.List || [];
    } catch (error) {
      console.error('Error fetching settings by category:', error);
      throw error;
    }
  }

  static async getSetting(key: string): Promise<SystemSetting | null> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SYSTEM_SETTINGS_TABLE_ID, {
        "PageNo": 1,
        "PageSize": 1,
        "OrderByField": "id",
        "IsAsc": true,
        "Filters": [
        {
          "name": "setting_key",
          "op": "Equal",
          "value": key
        },
        {
          "name": "is_active",
          "op": "Equal",
          "value": true
        }]

      });

      if (error) throw new Error(error);

      return data?.List?.[0] || null;
    } catch (error) {
      console.error('Error fetching setting:', error);
      throw error;
    }
  }

  static async updateSetting(setting: SystemSetting): Promise<void> {
    try {
      const updateData = {
        ...setting,
        updated_at: new Date().toISOString()
      };

      const { error } = await window.ezsite.apis.tableUpdate(SYSTEM_SETTINGS_TABLE_ID, updateData);

      if (error) throw new Error(error);

      // Log the change for audit purposes
      await this.logSettingChange(setting.setting_key, 'updated', setting.setting_value);
    } catch (error) {
      console.error('Error updating setting:', error);
      throw error;
    }
  }

  static async createSetting(setting: Omit<SystemSetting, 'id'>): Promise<void> {
    try {
      const createData = {
        ...setting,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const { error } = await window.ezsite.apis.tableCreate(SYSTEM_SETTINGS_TABLE_ID, createData);

      if (error) throw new Error(error);

      // Log the change for audit purposes
      await this.logSettingChange(setting.setting_key, 'created', setting.setting_value);
    } catch (error) {
      console.error('Error creating setting:', error);
      throw error;
    }
  }

  static async exportSettings(): Promise<SettingsExport> {
    try {
      const settings = await this.getAllSettings();

      return {
        version: '1.0',
        exported_at: new Date().toISOString(),
        settings: settings
      };
    } catch (error) {
      console.error('Error exporting settings:', error);
      throw error;
    }
  }

  static async importSettings(exportData: SettingsExport): Promise<void> {
    try {
      for (const setting of exportData.settings) {
        const existingSetting = await this.getSetting(setting.setting_key);

        if (existingSetting) {
          await this.updateSetting({
            ...setting,
            id: existingSetting.id
          });
        } else {
          await this.createSetting(setting);
        }
      }

      await this.logSettingChange('system', 'imported', `${exportData.settings.length} settings imported`);
    } catch (error) {
      console.error('Error importing settings:', error);
      throw error;
    }
  }

  private static async logSettingChange(settingKey: string, action: string, value: string): Promise<void> {
    try {
      // This would integrate with the audit_logs table if needed
      console.log(`Setting ${action}: ${settingKey} = ${value}`);
    } catch (error) {
      console.error('Error logging setting change:', error);
    }
  }

  static async initializeDefaultSettings(): Promise<void> {
    try {
      const defaultSettings = this.getDefaultUSASettings();

      for (const setting of defaultSettings) {
        const existing = await this.getSetting(setting.setting_key);
        if (!existing) {
          await this.createSetting(setting);
        }
      }
    } catch (error) {
      console.error('Error initializing default settings:', error);
      throw error;
    }
  }

  private static getDefaultUSASettings(): Omit<SystemSetting, 'id'>[] {
    return [
    // General Settings
    {
      setting_key: 'site_name',
      setting_value: 'Business Management System',
      description: 'The name of your business or application',
      category: 'general',
      data_type: 'string',
      is_active: true
    },
    {
      setting_key: 'site_description',
      setting_value: 'Comprehensive business management solution',
      description: 'Brief description of your business',
      category: 'general',
      data_type: 'string',
      is_active: true
    },
    {
      setting_key: 'maintenance_mode',
      setting_value: 'false',
      description: 'Enable maintenance mode to restrict access',
      category: 'general',
      data_type: 'boolean',
      is_active: true
    },

    // Business Settings
    {
      setting_key: 'currency',
      setting_value: 'USD',
      description: 'Default currency for financial transactions',
      category: 'business',
      data_type: 'select',
      is_active: true
    },
    {
      setting_key: 'date_format',
      setting_value: 'MM/dd/yyyy',
      description: 'Date format used throughout the application',
      category: 'business',
      data_type: 'select',
      is_active: true
    },
    {
      setting_key: 'timezone',
      setting_value: 'America/New_York',
      description: 'Default timezone for the application',
      category: 'business',
      data_type: 'select',
      is_active: true
    },
    {
      setting_key: 'company_name',
      setting_value: '',
      description: 'Legal name of your company',
      category: 'business',
      data_type: 'string',
      is_active: true
    },
    {
      setting_key: 'company_address',
      setting_value: '',
      description: 'Physical address of your business',
      category: 'business',
      data_type: 'string',
      is_active: true
    },
    {
      setting_key: 'company_phone',
      setting_value: '',
      description: 'Main phone number for your business',
      category: 'business',
      data_type: 'string',
      is_active: true
    },
    {
      setting_key: 'tax_id',
      setting_value: '',
      description: 'Federal Tax ID (EIN) for your business',
      category: 'business',
      data_type: 'string',
      is_active: true
    },

    // Security Settings
    {
      setting_key: 'session_timeout',
      setting_value: '30',
      description: 'Session timeout in minutes',
      category: 'security',
      data_type: 'number',
      is_active: true
    },
    {
      setting_key: 'max_login_attempts',
      setting_value: '5',
      description: 'Maximum login attempts before account lockout',
      category: 'security',
      data_type: 'number',
      is_active: true
    },
    {
      setting_key: 'password_min_length',
      setting_value: '8',
      description: 'Minimum password length requirement',
      category: 'security',
      data_type: 'number',
      is_active: true
    },
    {
      setting_key: 'require_password_complexity',
      setting_value: 'true',
      description: 'Require complex passwords (uppercase, lowercase, numbers, symbols)',
      category: 'security',
      data_type: 'boolean',
      is_active: true
    },

    // Notification Settings
    {
      setting_key: 'email_notifications_enabled',
      setting_value: 'true',
      description: 'Enable email notifications',
      category: 'notifications',
      data_type: 'boolean',
      is_active: true
    },
    {
      setting_key: 'smtp_host',
      setting_value: '',
      description: 'SMTP server hostname',
      category: 'notifications',
      data_type: 'string',
      is_active: true
    },
    {
      setting_key: 'smtp_port',
      setting_value: '587',
      description: 'SMTP server port',
      category: 'notifications',
      data_type: 'number',
      is_active: true
    },
    {
      setting_key: 'smtp_username',
      setting_value: '',
      description: 'SMTP username for authentication',
      category: 'notifications',
      data_type: 'string',
      is_active: true
    },
    {
      setting_key: 'notification_email',
      setting_value: '',
      description: 'Email address for system notifications',
      category: 'notifications',
      data_type: 'string',
      is_active: true
    },

    // Integration Settings
    {
      setting_key: 'backup_enabled',
      setting_value: 'true',
      description: 'Enable automatic database backups',
      category: 'integrations',
      data_type: 'boolean',
      is_active: true
    },
    {
      setting_key: 'backup_frequency',
      setting_value: 'daily',
      description: 'Frequency of automatic backups',
      category: 'integrations',
      data_type: 'select',
      is_active: true
    },
    {
      setting_key: 'api_rate_limit',
      setting_value: '1000',
      description: 'API rate limit per hour',
      category: 'integrations',
      data_type: 'number',
      is_active: true
    }];

  }
}