import { toast } from "sonner";

// Types for verification results
export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  details?: any;
}

export interface TableValidationResult extends ValidationResult {
  tableName: string;
  tableId: number;
  recordsChecked: number;
  crudTestResults: CrudTestResult;
  relationshipResults: RelationshipValidationResult[];
  businessRuleResults: BusinessRuleResult[];
}

export interface CrudTestResult {
  create: ValidationResult;
  read: ValidationResult;
  update: ValidationResult;
  delete: ValidationResult;
}

export interface RelationshipValidationResult {
  relationship: string;
  foreignTable: string;
  foreignKey: string;
  result: ValidationResult;
}

export interface BusinessRuleResult {
  rule: string;
  result: ValidationResult;
}

export interface DataIntegrityReport {
  timestamp: string;
  overallStatus: 'PASSED' | 'FAILED' | 'WARNING';
  summary: {
    totalTables: number;
    tablesChecked: number;
    criticalErrors: number;
    warnings: number;
    successfulOperations: number;
  };
  tableResults: TableValidationResult[];
  performanceMetrics: {
    totalExecutionTime: number;
    averageResponseTime: number;
    slowestOperation: string;
  };
}

// Table configuration for verification
interface TableConfig {
  id: number;
  name: string;
  relationships: {
    field: string;
    relatedTable: string;
    relatedField: string;
    required?: boolean;
  }[];
  businessRules: {
    name: string;
    validator: (data: any) => ValidationResult;
  }[];
  requiredFields: string[];
}

export class ComprehensiveDataVerificationService {
  private tableConfigs: TableConfig[] = [
  {
    id: 38563,
    name: 'customers',
    relationships: [],
    businessRules: [
    {
      name: 'Email format validation',
      validator: (data: any) => this.validateEmailFormat(data.email)
    },
    {
      name: 'Phone format validation',
      validator: (data: any) => this.validatePhoneFormat(data.phone)
    },
    {
      name: 'Status validation',
      validator: (data: any) => this.validateStatus(data.status, ['active', 'inactive'])
    }],

    requiredFields: ['name', 'email']
  },
  {
    id: 38157,
    name: 'products',
    relationships: [
    {
      field: 'supplier_id',
      relatedTable: 'suppliers',
      relatedField: 'id',
      required: false
    }],

    businessRules: [
    {
      name: 'Price validation',
      validator: (data: any) => this.validatePriceLogic(data.cost_price, data.selling_price)
    },
    {
      name: 'Stock level validation',
      validator: (data: any) => this.validateStockLevels(data.stock_level, data.min_stock_level)
    },
    {
      name: 'SKU uniqueness',
      validator: (data: any) => this.validateSKUUniqueness(data.sku, data.id)
    }],

    requiredFields: ['sku', 'name', 'selling_price']
  },
  {
    id: 38564,
    name: 'suppliers',
    relationships: [],
    businessRules: [
    {
      name: 'Contact email validation',
      validator: (data: any) => this.validateEmailFormat(data.email)
    },
    {
      name: 'Status validation',
      validator: (data: any) => this.validateStatus(data.status, ['active', 'inactive'])
    }],

    requiredFields: ['name', 'contact_person']
  },
  {
    id: 38156,
    name: 'sales_transactions',
    relationships: [
    {
      field: 'product_id',
      relatedTable: 'products',
      relatedField: 'id',
      required: true
    },
    {
      field: 'employee_id',
      relatedTable: 'employees',
      relatedField: 'id',
      required: true
    }],

    businessRules: [
    {
      name: 'Transaction amount calculation',
      validator: (data: any) => this.validateTransactionAmount(data.quantity_sold, data.unit_price, data.total_amount)
    },
    {
      name: 'Quantity validation',
      validator: (data: any) => this.validatePositiveNumber(data.quantity_sold, 'Quantity sold')
    }],

    requiredFields: ['product_id', 'quantity_sold', 'unit_price', 'total_amount', 'sale_date']
  },
  {
    id: 38565,
    name: 'invoices',
    relationships: [
    {
      field: 'customer_id',
      relatedTable: 'customers',
      relatedField: 'id',
      required: true
    }],

    businessRules: [
    {
      name: 'Invoice amount calculation',
      validator: (data: any) => this.validateInvoiceCalculation(data)
    },
    {
      name: 'Due date validation',
      validator: (data: any) => this.validateDueDate(data.issue_date, data.due_date)
    },
    {
      name: 'Payment validation',
      validator: (data: any) => this.validatePaymentAmounts(data.total_amount, data.paid_amount, data.remaining_amount)
    }],

    requiredFields: ['invoice_number', 'customer_id', 'issue_date', 'total_amount']
  },
  {
    id: 37818,
    name: 'employees',
    relationships: [],
    businessRules: [
    {
      name: 'Email format validation',
      validator: (data: any) => this.validateEmailFormat(data.email)
    },
    {
      name: 'Salary validation',
      validator: (data: any) => this.validatePositiveNumber(data.salary, 'Salary')
    },
    {
      name: 'Hire date validation',
      validator: (data: any) => this.validateHireDate(data.hire_date)
    }],

    requiredFields: ['first_name', 'last_name', 'email', 'position']
  },
  {
    id: 38567,
    name: 'salary_calculations',
    relationships: [
    {
      field: 'employee_id',
      relatedTable: 'employees',
      relatedField: 'id',
      required: true
    }],

    businessRules: [
    {
      name: 'Salary calculation validation',
      validator: (data: any) => this.validateSalaryCalculation(data)
    },
    {
      name: 'Pay period format validation',
      validator: (data: any) => this.validatePayPeriodFormat(data.pay_period)
    }],

    requiredFields: ['employee_id', 'pay_period', 'base_salary', 'gross_salary', 'net_salary']
  },
  {
    id: 38570,
    name: 'accounts',
    relationships: [],
    businessRules: [
    {
      name: 'Account type validation',
      validator: (data: any) => this.validateAccountType(data.account_type)
    },
    {
      name: 'Account code uniqueness',
      validator: (data: any) => this.validateAccountCodeUniqueness(data.code, data.id)
    }],

    requiredFields: ['code', 'name', 'account_type']
  }];


  async runComprehensiveVerification(): Promise<DataIntegrityReport> {
    const startTime = Date.now();
    const report: DataIntegrityReport = {
      timestamp: new Date().toISOString(),
      overallStatus: 'PASSED',
      summary: {
        totalTables: this.tableConfigs.length,
        tablesChecked: 0,
        criticalErrors: 0,
        warnings: 0,
        successfulOperations: 0
      },
      tableResults: [],
      performanceMetrics: {
        totalExecutionTime: 0,
        averageResponseTime: 0,
        slowestOperation: ''
      }
    };

    const operationTimes: {operation: string;time: number;}[] = [];

    // Run verification for each table
    for (const config of this.tableConfigs) {
      try {
        const tableStartTime = Date.now();
        const tableResult = await this.verifyTableIntegrity(config);
        const tableEndTime = Date.now();

        operationTimes.push({
          operation: `Table: ${config.name}`,
          time: tableEndTime - tableStartTime
        });

        report.tableResults.push(tableResult);
        report.summary.tablesChecked++;

        // Update summary statistics
        if (!tableResult.isValid) {
          report.summary.criticalErrors += tableResult.errors.length;
        }
        report.summary.warnings += tableResult.warnings.length;
        if (tableResult.isValid) {
          report.summary.successfulOperations++;
        }

        // Update overall status
        if (!tableResult.isValid && report.overallStatus === 'PASSED') {
          report.overallStatus = tableResult.errors.length > 0 ? 'FAILED' : 'WARNING';
        }

      } catch (error) {
        console.error(`Error verifying table ${config.name}:`, error);
        report.summary.criticalErrors++;
        report.overallStatus = 'FAILED';
      }
    }

    // Calculate performance metrics
    const endTime = Date.now();
    report.performanceMetrics.totalExecutionTime = endTime - startTime;
    report.performanceMetrics.averageResponseTime = operationTimes.length > 0 ?
    operationTimes.reduce((sum, op) => sum + op.time, 0) / operationTimes.length :
    0;

    const slowestOp = operationTimes.reduce((prev, current) =>
    current.time > prev.time ? current : prev, { operation: '', time: 0 });
    report.performanceMetrics.slowestOperation = slowestOp.operation;

    return report;
  }

  private async verifyTableIntegrity(config: TableConfig): Promise<TableValidationResult> {
    const result: TableValidationResult = {
      tableName: config.name,
      tableId: config.id,
      recordsChecked: 0,
      isValid: true,
      errors: [],
      warnings: [],
      crudTestResults: {
        create: { isValid: true, errors: [], warnings: [] },
        read: { isValid: true, errors: [], warnings: [] },
        update: { isValid: true, errors: [], warnings: [] },
        delete: { isValid: true, errors: [], warnings: [] }
      },
      relationshipResults: [],
      businessRuleResults: []
    };

    try {
      // 1. Test CRUD operations
      result.crudTestResults = await this.testCrudOperations(config);

      // 2. Verify existing data
      const dataVerificationResult = await this.verifyExistingData(config);
      result.recordsChecked = dataVerificationResult.recordsChecked;
      result.errors.push(...dataVerificationResult.errors);
      result.warnings.push(...dataVerificationResult.warnings);

      // 3. Test relationships
      for (const relationship of config.relationships) {
        const relationshipResult = await this.verifyRelationship(config, relationship);
        result.relationshipResults.push(relationshipResult);

        if (!relationshipResult.result.isValid) {
          result.errors.push(...relationshipResult.result.errors);
          result.warnings.push(...relationshipResult.result.warnings);
        }
      }

      // 4. Test business rules on sample data
      const businessRuleResults = await this.testBusinessRules(config);
      result.businessRuleResults = businessRuleResults;

      businessRuleResults.forEach((brResult) => {
        if (!brResult.result.isValid) {
          result.errors.push(...brResult.result.errors);
          result.warnings.push(...brResult.result.warnings);
        }
      });

      // Set overall validity
      result.isValid = result.errors.length === 0;

    } catch (error) {
      result.isValid = false;
      result.errors.push(`Table verification failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  private async testCrudOperations(config: TableConfig): Promise<CrudTestResult> {
    const result: CrudTestResult = {
      create: { isValid: true, errors: [], warnings: [] },
      read: { isValid: true, errors: [], warnings: [] },
      update: { isValid: true, errors: [], warnings: [] },
      delete: { isValid: true, errors: [], warnings: [] }
    };

    const testData = this.generateTestData(config);

    try {
      // Test CREATE
      const { error: createError } = await window.ezsite.apis.tableCreate(config.id, testData);
      if (createError) {
        result.create.isValid = false;
        result.create.errors.push(`Create operation failed: ${createError}`);
      }

      // Test READ
      const { data: readData, error: readError } = await window.ezsite.apis.tablePage(config.id, {
        PageNo: 1,
        PageSize: 10,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      if (readError) {
        result.read.isValid = false;
        result.read.errors.push(`Read operation failed: ${readError}`);
      } else if (!readData?.List) {
        result.read.isValid = false;
        result.read.errors.push('Read operation returned invalid data structure');
      }

      // If create was successful, test UPDATE and DELETE
      if (!createError && readData?.List?.length > 0) {
        const createdRecord = readData.List.find((record: any) =>
        config.name === 'products' ? record.sku === testData.sku :
        config.name === 'customers' ? record.email === testData.email :
        config.name === 'employees' ? record.email === testData.email :
        true
        );

        if (createdRecord) {
          // Test UPDATE
          const updateData = { ...createdRecord, name: `${createdRecord.name || createdRecord.first_name || 'Test'} - Updated` };
          const { error: updateError } = await window.ezsite.apis.tableUpdate(config.id, updateData);
          if (updateError) {
            result.update.isValid = false;
            result.update.errors.push(`Update operation failed: ${updateError}`);
          }

          // Test DELETE
          const { error: deleteError } = await window.ezsite.apis.tableDelete(config.id, { ID: createdRecord.id });
          if (deleteError) {
            result.delete.isValid = false;
            result.delete.errors.push(`Delete operation failed: ${deleteError}`);
          }
        }
      }

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      result.create.errors.push(`CRUD test exception: ${errorMessage}`);
      result.create.isValid = false;
    }

    return result;
  }

  private async verifyExistingData(config: TableConfig): Promise<{recordsChecked: number;errors: string[];warnings: string[];}> {
    const result = { recordsChecked: 0, errors: [], warnings: [] };

    try {
      const { data, error } = await window.ezsite.apis.tablePage(config.id, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      if (error) {
        result.errors.push(`Failed to fetch data for verification: ${error}`);
        return result;
      }

      if (!data?.List) {
        result.warnings.push('No data found in table');
        return result;
      }

      result.recordsChecked = data.List.length;

      // Verify each record against business rules
      for (const record of data.List) {
        // Check required fields
        for (const field of config.requiredFields) {
          if (!record[field] && record[field] !== 0) {
            result.errors.push(`Record ${record.id}: Missing required field '${field}'`);
          }
        }

        // Run business rule validations
        for (const rule of config.businessRules) {
          try {
            const validation = rule.validator(record);
            if (!validation.isValid) {
              result.errors.push(`Record ${record.id}: ${rule.name} failed - ${validation.errors.join(', ')}`);
            }
            result.warnings.push(...validation.warnings.map((w) => `Record ${record.id}: ${rule.name} - ${w}`));
          } catch (error) {
            result.errors.push(`Record ${record.id}: Business rule '${rule.name}' validation error`);
          }
        }
      }

    } catch (error) {
      result.errors.push(`Data verification exception: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  private async verifyRelationship(config: TableConfig, relationship: any): Promise<RelationshipValidationResult> {
    const result: RelationshipValidationResult = {
      relationship: `${config.name}.${relationship.field} -> ${relationship.relatedTable}.${relationship.relatedField}`,
      foreignTable: relationship.relatedTable,
      foreignKey: relationship.field,
      result: { isValid: true, errors: [], warnings: [] }
    };

    try {
      // Get records from the main table
      const { data: mainData, error: mainError } = await window.ezsite.apis.tablePage(config.id, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      if (mainError) {
        result.result.isValid = false;
        result.result.errors.push(`Failed to fetch main table data: ${mainError}`);
        return result;
      }

      // Get the related table ID
      const relatedTableId = this.tableConfigs.find((t) => t.name === relationship.relatedTable)?.id;
      if (!relatedTableId) {
        result.result.warnings.push(`Related table '${relationship.relatedTable}' not found in configuration`);
        return result;
      }

      // Get records from the related table
      const { data: relatedData, error: relatedError } = await window.ezsite.apis.tablePage(relatedTableId, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: "id",
        IsAsc: false,
        Filters: []
      });

      if (relatedError) {
        result.result.isValid = false;
        result.result.errors.push(`Failed to fetch related table data: ${relatedError}`);
        return result;
      }

      // Check referential integrity
      if (mainData?.List && relatedData?.List) {
        const relatedIds = new Set(relatedData.List.map((record: any) => record.id?.toString()));

        for (const record of mainData.List) {
          const foreignKeyValue = record[relationship.field];
          if (foreignKeyValue && !relatedIds.has(foreignKeyValue.toString())) {
            if (relationship.required) {
              result.result.isValid = false;
              result.result.errors.push(`Record ${record.id}: Foreign key '${foreignKeyValue}' not found in ${relationship.relatedTable}`);
            } else {
              result.result.warnings.push(`Record ${record.id}: Optional foreign key '${foreignKeyValue}' not found in ${relationship.relatedTable}`);
            }
          }
        }
      }

    } catch (error) {
      result.result.isValid = false;
      result.result.errors.push(`Relationship verification exception: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    return result;
  }

  private async testBusinessRules(config: TableConfig): Promise<BusinessRuleResult[]> {
    return config.businessRules.map((rule) => ({
      rule: rule.name,
      result: { isValid: true, errors: [], warnings: ['Business rule tested during data verification'] }
    }));
  }

  // Business rule validators
  private validateEmailFormat(email: string): ValidationResult {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return {
      isValid: !email || emailRegex.test(email),
      errors: email && !emailRegex.test(email) ? ['Invalid email format'] : [],
      warnings: []
    };
  }

  private validatePhoneFormat(phone: string): ValidationResult {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return {
      isValid: !phone || phoneRegex.test(phone.replace(/[\s\-\(\)]/g, '')),
      errors: phone && !phoneRegex.test(phone.replace(/[\s\-\(\)]/g, '')) ? ['Invalid phone format'] : [],
      warnings: []
    };
  }

  private validateStatus(status: string, validStatuses: string[]): ValidationResult {
    return {
      isValid: !status || validStatuses.includes(status),
      errors: status && !validStatuses.includes(status) ? [`Invalid status. Must be one of: ${validStatuses.join(', ')}`] : [],
      warnings: []
    };
  }

  private validatePriceLogic(costPrice: number, sellingPrice: number): ValidationResult {
    const result: ValidationResult = { isValid: true, errors: [], warnings: [] };

    if (costPrice && sellingPrice) {
      if (sellingPrice <= costPrice) {
        result.warnings.push('Selling price is not higher than cost price - potential loss');
      }
      if (sellingPrice < costPrice * 0.5) {
        result.errors.push('Selling price is significantly below cost price');
        result.isValid = false;
      }
    }

    return result;
  }

  private validateStockLevels(stockLevel: number, minStockLevel: number): ValidationResult {
    const result: ValidationResult = { isValid: true, errors: [], warnings: [] };

    if (stockLevel < 0) {
      result.errors.push('Stock level cannot be negative');
      result.isValid = false;
    }

    if (minStockLevel && stockLevel <= minStockLevel) {
      result.warnings.push('Stock level is at or below minimum threshold');
    }

    return result;
  }

  private async validateSKUUniqueness(sku: string, currentId?: number): Promise<ValidationResult> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(38157, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: [{ name: "sku", op: "Equal", value: sku }]
      });

      if (error) {
        return { isValid: false, errors: [`SKU uniqueness check failed: ${error}`], warnings: [] };
      }

      const existingRecords = data?.List?.filter((record: any) => record.id !== currentId) || [];

      return {
        isValid: existingRecords.length === 0,
        errors: existingRecords.length > 0 ? ['SKU already exists'] : [],
        warnings: []
      };
    } catch (error) {
      return { isValid: false, errors: ['SKU uniqueness validation failed'], warnings: [] };
    }
  }

  private validateTransactionAmount(quantity: number, unitPrice: number, totalAmount: number): ValidationResult {
    const expectedTotal = quantity * unitPrice;
    const tolerance = 0.01;

    return {
      isValid: Math.abs(totalAmount - expectedTotal) <= tolerance,
      errors: Math.abs(totalAmount - expectedTotal) > tolerance ? ['Transaction total amount calculation is incorrect'] : [],
      warnings: []
    };
  }

  private validatePositiveNumber(value: number, fieldName: string): ValidationResult {
    return {
      isValid: value >= 0,
      errors: value < 0 ? [`${fieldName} must be a positive number`] : [],
      warnings: []
    };
  }

  private validateInvoiceCalculation(data: any): ValidationResult {
    const { subtotal, discount_amount, tax_amount, total_amount } = data;
    const calculatedTotal = subtotal - discount_amount + tax_amount;
    const tolerance = 0.01;

    return {
      isValid: Math.abs(total_amount - calculatedTotal) <= tolerance,
      errors: Math.abs(total_amount - calculatedTotal) > tolerance ? ['Invoice total calculation is incorrect'] : [],
      warnings: []
    };
  }

  private validateDueDate(issueDate: string, dueDate: string): ValidationResult {
    if (!issueDate || !dueDate) return { isValid: true, errors: [], warnings: [] };

    const issue = new Date(issueDate);
    const due = new Date(dueDate);

    return {
      isValid: due >= issue,
      errors: due < issue ? ['Due date cannot be before issue date'] : [],
      warnings: []
    };
  }

  private validatePaymentAmounts(totalAmount: number, paidAmount: number, remainingAmount: number): ValidationResult {
    const calculatedRemaining = totalAmount - paidAmount;
    const tolerance = 0.01;

    return {
      isValid: Math.abs(remainingAmount - calculatedRemaining) <= tolerance,
      errors: Math.abs(remainingAmount - calculatedRemaining) > tolerance ? ['Payment amount calculation is incorrect'] : [],
      warnings: []
    };
  }

  private validateHireDate(hireDate: string): ValidationResult {
    if (!hireDate) return { isValid: true, errors: [], warnings: [] };

    const hire = new Date(hireDate);
    const now = new Date();
    const maxFutureDate = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());

    return {
      isValid: hire <= maxFutureDate,
      errors: hire > maxFutureDate ? ['Hire date cannot be more than 1 year in the future'] : [],
      warnings: hire > now ? ['Hire date is in the future'] : []
    };
  }

  private validateSalaryCalculation(data: any): ValidationResult {
    const { base_salary, gross_salary, net_salary } = data;
    const result: ValidationResult = { isValid: true, errors: [], warnings: [] };

    if (gross_salary < base_salary) {
      result.errors.push('Gross salary cannot be less than base salary');
      result.isValid = false;
    }

    if (net_salary > gross_salary) {
      result.errors.push('Net salary cannot be greater than gross salary');
      result.isValid = false;
    }

    return result;
  }

  private validatePayPeriodFormat(payPeriod: string): ValidationResult {
    const periodRegex = /^\d{4}-\d{2}$/;
    return {
      isValid: periodRegex.test(payPeriod),
      errors: !periodRegex.test(payPeriod) ? ['Pay period must be in YYYY-MM format'] : [],
      warnings: []
    };
  }

  private validateAccountType(accountType: string): ValidationResult {
    const validTypes = ['ASSET', 'LIABILITY', 'EQUITY', 'INCOME', 'EXPENSE'];
    return {
      isValid: validTypes.includes(accountType),
      errors: !validTypes.includes(accountType) ? [`Invalid account type. Must be one of: ${validTypes.join(', ')}`] : [],
      warnings: []
    };
  }

  private async validateAccountCodeUniqueness(code: string, currentId?: number): Promise<ValidationResult> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(38570, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: "id",
        IsAsc: false,
        Filters: [{ name: "code", op: "Equal", value: code }]
      });

      if (error) {
        return { isValid: false, errors: [`Account code uniqueness check failed: ${error}`], warnings: [] };
      }

      const existingRecords = data?.List?.filter((record: any) => record.id !== currentId) || [];

      return {
        isValid: existingRecords.length === 0,
        errors: existingRecords.length > 0 ? ['Account code already exists'] : [],
        warnings: []
      };
    } catch (error) {
      return { isValid: false, errors: ['Account code uniqueness validation failed'], warnings: [] };
    }
  }

  private generateTestData(config: TableConfig): any {
    const timestamp = new Date().toISOString();
    const uniqueId = Date.now();

    switch (config.name) {
      case 'customers':
        return {
          name: `Test Customer ${uniqueId}`,
          email: `test.customer.${uniqueId}@example.com`,
          phone: '+1234567890',
          address: 'Test Address',
          status: 'active',
          created_at: timestamp
        };

      case 'products':
        return {
          sku: `TEST-SKU-${uniqueId}`,
          name: `Test Product ${uniqueId}`,
          description: 'Test product description',
          category: 'Test Category',
          cost_price: 10.00,
          selling_price: 15.00,
          stock_level: 100,
          min_stock_level: 10,
          is_active: true,
          created_at: timestamp
        };

      case 'suppliers':
        return {
          name: `Test Supplier ${uniqueId}`,
          contact_person: `Test Contact ${uniqueId}`,
          email: `test.supplier.${uniqueId}@example.com`,
          phone: '+1234567890',
          address: 'Test Supplier Address',
          status: 'active',
          created_at: timestamp
        };

      case 'employees':
        return {
          first_name: `Test`,
          last_name: `Employee ${uniqueId}`,
          email: `test.employee.${uniqueId}@company.com`,
          phone: '+1234567890',
          position: 'Test Position',
          department: 'Test Department',
          hire_date: timestamp,
          salary: 50000,
          employment_status: 'active',
          created_at: timestamp
        };

      default:
        return { name: `Test Record ${uniqueId}`, created_at: timestamp };
    }
  }
}

export const dataVerificationService = new ComprehensiveDataVerificationService();