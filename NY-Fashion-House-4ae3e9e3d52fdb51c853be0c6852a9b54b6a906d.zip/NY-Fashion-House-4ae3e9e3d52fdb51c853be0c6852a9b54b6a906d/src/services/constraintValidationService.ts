import { toast } from "sonner";

export interface ConstraintValidationResult {
  constraintName: string;
  tableName: string;
  isValid: boolean;
  violationCount: number;
  violations: any[];
  description: string;
  severity: 'ERROR' | 'WARNING' | 'INFO';
}

export interface DataTypeValidationResult {
  field: string;
  tableName: string;
  expectedType: string;
  actualType: string;
  isValid: boolean;
  invalidRecords: any[];
  description: string;
}

export interface ForeignKeyValidationResult {
  relationshipName: string;
  sourceTable: string;
  sourceField: string;
  targetTable: string;
  targetField: string;
  orphanedRecords: any[];
  isValid: boolean;
  description: string;
}

export interface ComprehensiveConstraintReport {
  timestamp: string;
  overallStatus: 'PASSED' | 'FAILED' | 'WARNING';
  summary: {
    totalConstraints: number;
    validConstraints: number;
    violatedConstraints: number;
    totalViolations: number;
  };
  constraintResults: ConstraintValidationResult[];
  dataTypeResults: DataTypeValidationResult[];
  foreignKeyResults: ForeignKeyValidationResult[];
  businessRuleViolations: {
    rule: string;
    tableName: string;
    violationCount: number;
    description: string;
  }[];
}

export class ConstraintValidationService {

  async runComprehensiveConstraintValidation(): Promise<ComprehensiveConstraintReport> {
    const startTime = Date.now();
    const report: ComprehensiveConstraintReport = {
      timestamp: new Date().toISOString(),
      overallStatus: 'PASSED',
      summary: {
        totalConstraints: 0,
        validConstraints: 0,
        violatedConstraints: 0,
        totalViolations: 0
      },
      constraintResults: [],
      dataTypeResults: [],
      foreignKeyResults: [],
      businessRuleViolations: []
    };

    try {
      // 1. Validate NOT NULL constraints
      const notNullResults = await this.validateNotNullConstraints();
      report.constraintResults.push(...notNullResults);

      // 2. Validate UNIQUE constraints
      const uniqueResults = await this.validateUniqueConstraints();
      report.constraintResults.push(...uniqueResults);

      // 3. Validate CHECK constraints (business rules)
      const checkResults = await this.validateCheckConstraints();
      report.constraintResults.push(...checkResults);

      // 4. Validate data types
      const dataTypeResults = await this.validateDataTypes();
      report.dataTypeResults = dataTypeResults;

      // 5. Validate foreign key constraints
      const foreignKeyResults = await this.validateForeignKeyConstraints();
      report.foreignKeyResults = foreignKeyResults;

      // 6. Validate business logic constraints
      const businessRuleViolations = await this.validateBusinessRuleConstraints();
      report.businessRuleViolations = businessRuleViolations;

      // Calculate summary
      report.summary.totalConstraints =
      report.constraintResults.length +
      report.dataTypeResults.length +
      report.foreignKeyResults.length;

      report.summary.validConstraints =
      report.constraintResults.filter((r) => r.isValid).length +
      report.dataTypeResults.filter((r) => r.isValid).length +
      report.foreignKeyResults.filter((r) => r.isValid).length;

      report.summary.violatedConstraints =
      report.summary.totalConstraints - report.summary.validConstraints;

      report.summary.totalViolations =
      report.constraintResults.reduce((sum, r) => sum + r.violationCount, 0) +
      report.dataTypeResults.reduce((sum, r) => sum + r.invalidRecords.length, 0) +
      report.foreignKeyResults.reduce((sum, r) => sum + r.orphanedRecords.length, 0);

      // Determine overall status
      if (report.summary.violatedConstraints > 0) {
        const hasErrors = report.constraintResults.some((r) => r.severity === 'ERROR' && !r.isValid) ||
        report.dataTypeResults.some((r) => !r.isValid) ||
        report.foreignKeyResults.some((r) => !r.isValid);
        report.overallStatus = hasErrors ? 'FAILED' : 'WARNING';
      }

    } catch (error) {
      console.error('Constraint validation failed:', error);
      report.overallStatus = 'FAILED';
    }

    return report;
  }

  private async validateNotNullConstraints(): Promise<ConstraintValidationResult[]> {
    const results: ConstraintValidationResult[] = [];

    const requiredFieldsByTable = {
      customers: ['name', 'email'],
      products: ['sku', 'name', 'selling_price'],
      suppliers: ['name', 'contact_person'],
      employees: ['first_name', 'last_name', 'email', 'position'],
      sales_transactions: ['product_id', 'quantity_sold', 'unit_price', 'total_amount', 'sale_date'],
      invoices: ['invoice_number', 'customer_id', 'issue_date', 'total_amount'],
      accounts: ['code', 'name', 'account_type'],
      salary_calculations: ['employee_id', 'pay_period', 'base_salary', 'gross_salary', 'net_salary']
    };

    const tableIds = {
      customers: 38563,
      products: 38157,
      suppliers: 38564,
      employees: 37818,
      sales_transactions: 38156,
      invoices: 38565,
      accounts: 38570,
      salary_calculations: 38567
    };

    for (const [tableName, requiredFields] of Object.entries(requiredFieldsByTable)) {
      const tableId = tableIds[tableName as keyof typeof tableIds];

      for (const field of requiredFields) {
        try {
          const { data, error } = await window.ezsite.apis.tablePage(tableId, {
            PageNo: 1,
            PageSize: 1000,
            OrderByField: "id",
            IsAsc: false,
            Filters: []
          });

          if (error) {
            results.push({
              constraintName: `${tableName}.${field} NOT NULL`,
              tableName,
              isValid: false,
              violationCount: 1,
              violations: [{ error: `Unable to check constraint: ${error}` }],
              description: `Required field ${field} validation failed`,
              severity: 'ERROR'
            });
            continue;
          }

          const violations = (data?.List || []).filter((record: any) =>
          record[field] === null || record[field] === undefined || record[field] === ''
          );

          results.push({
            constraintName: `${tableName}.${field} NOT NULL`,
            tableName,
            isValid: violations.length === 0,
            violationCount: violations.length,
            violations: violations.slice(0, 10), // Limit to first 10 violations for performance
            description: `Field '${field}' must not be null or empty`,
            severity: 'ERROR'
          });

        } catch (error) {
          results.push({
            constraintName: `${tableName}.${field} NOT NULL`,
            tableName,
            isValid: false,
            violationCount: 1,
            violations: [{ error: 'Validation check failed' }],
            description: `Required field ${field} validation encountered an error`,
            severity: 'ERROR'
          });
        }
      }
    }

    return results;
  }

  private async validateUniqueConstraints(): Promise<ConstraintValidationResult[]> {
    const results: ConstraintValidationResult[] = [];

    const uniqueConstraints = [
    { table: 'customers', tableId: 38563, field: 'email', name: 'customers_email_unique' },
    { table: 'products', tableId: 38157, field: 'sku', name: 'products_sku_unique' },
    { table: 'suppliers', tableId: 38564, field: 'email', name: 'suppliers_email_unique' },
    { table: 'employees', tableId: 37818, field: 'email', name: 'employees_email_unique' },
    { table: 'invoices', tableId: 38565, field: 'invoice_number', name: 'invoices_number_unique' },
    { table: 'accounts', tableId: 38570, field: 'code', name: 'accounts_code_unique' }];


    for (const constraint of uniqueConstraints) {
      try {
        const { data, error } = await window.ezsite.apis.tablePage(constraint.tableId, {
          PageNo: 1,
          PageSize: 1000,
          OrderByField: "id",
          IsAsc: false,
          Filters: []
        });

        if (error) {
          results.push({
            constraintName: constraint.name,
            tableName: constraint.table,
            isValid: false,
            violationCount: 1,
            violations: [{ error: `Unable to check constraint: ${error}` }],
            description: `Unique constraint validation failed for ${constraint.field}`,
            severity: 'ERROR'
          });
          continue;
        }

        const records = data?.List || [];
        const fieldValues = records.map((record: any) => record[constraint.field]);
        const duplicates = fieldValues.filter((value: any, index: number) =>
        value && fieldValues.indexOf(value) !== index
        );

        const uniqueDuplicates = [...new Set(duplicates)];
        const duplicateRecords = records.filter((record: any) =>
        uniqueDuplicates.includes(record[constraint.field])
        );

        results.push({
          constraintName: constraint.name,
          tableName: constraint.table,
          isValid: duplicates.length === 0,
          violationCount: duplicates.length,
          violations: duplicateRecords.slice(0, 20),
          description: `Field '${constraint.field}' values must be unique`,
          severity: 'ERROR'
        });

      } catch (error) {
        results.push({
          constraintName: constraint.name,
          tableName: constraint.table,
          isValid: false,
          violationCount: 1,
          violations: [{ error: 'Validation check failed' }],
          description: `Unique constraint validation encountered an error for ${constraint.field}`,
          severity: 'ERROR'
        });
      }
    }

    return results;
  }

  private async validateCheckConstraints(): Promise<ConstraintValidationResult[]> {
    const results: ConstraintValidationResult[] = [];

    // Define check constraints (business rules that should be enforced at DB level)
    const checkConstraints = [
    {
      name: 'products_positive_prices',
      table: 'products',
      tableId: 38157,
      description: 'Product prices must be positive',
      validator: (record: any) => record.cost_price >= 0 && record.selling_price >= 0
    },
    {
      name: 'products_selling_price_gte_cost',
      table: 'products',
      tableId: 38157,
      description: 'Selling price should be greater than or equal to cost price',
      validator: (record: any) => !record.selling_price || !record.cost_price || record.selling_price >= record.cost_price,
      severity: 'WARNING' as const
    },
    {
      name: 'products_stock_non_negative',
      table: 'products',
      tableId: 38157,
      description: 'Stock level must be non-negative',
      validator: (record: any) => record.stock_level >= 0
    },
    {
      name: 'sales_positive_amounts',
      table: 'sales_transactions',
      tableId: 38156,
      description: 'Sales amounts must be positive',
      validator: (record: any) => record.quantity_sold > 0 && record.unit_price > 0 && record.total_amount > 0
    },
    {
      name: 'sales_amount_calculation',
      table: 'sales_transactions',
      tableId: 38156,
      description: 'Total amount must equal quantity × unit price',
      validator: (record: any) => Math.abs(record.quantity_sold * record.unit_price - record.total_amount) <= 0.01
    },
    {
      name: 'invoices_positive_amounts',
      table: 'invoices',
      tableId: 38565,
      description: 'Invoice amounts must be non-negative',
      validator: (record: any) => record.subtotal >= 0 && record.total_amount >= 0 &&
      record.paid_amount >= 0 && record.remaining_amount >= 0
    },
    {
      name: 'invoices_payment_logic',
      table: 'invoices',
      tableId: 38565,
      description: 'Remaining amount must equal total amount minus paid amount',
      validator: (record: any) => Math.abs(record.remaining_amount - (record.total_amount - record.paid_amount)) <= 0.01
    },
    {
      name: 'employees_positive_salary',
      table: 'employees',
      tableId: 37818,
      description: 'Employee salary must be positive',
      validator: (record: any) => !record.salary || record.salary > 0
    },
    {
      name: 'salary_calculations_logic',
      table: 'salary_calculations',
      tableId: 38567,
      description: 'Net salary must not exceed gross salary',
      validator: (record: any) => record.net_salary <= record.gross_salary
    }];


    for (const constraint of checkConstraints) {
      try {
        const { data, error } = await window.ezsite.apis.tablePage(constraint.tableId, {
          PageNo: 1,
          PageSize: 500,
          OrderByField: "id",
          IsAsc: false,
          Filters: []
        });

        if (error) {
          results.push({
            constraintName: constraint.name,
            tableName: constraint.table,
            isValid: false,
            violationCount: 1,
            violations: [{ error: `Unable to check constraint: ${error}` }],
            description: constraint.description,
            severity: 'ERROR'
          });
          continue;
        }

        const records = data?.List || [];
        const violations = records.filter((record: any) => {
          try {
            return !constraint.validator(record);
          } catch (error) {
            return true; // Treat validation errors as violations
          }
        });

        results.push({
          constraintName: constraint.name,
          tableName: constraint.table,
          isValid: violations.length === 0,
          violationCount: violations.length,
          violations: violations.slice(0, 10),
          description: constraint.description,
          severity: (constraint as any).severity || 'ERROR'
        });

      } catch (error) {
        results.push({
          constraintName: constraint.name,
          tableName: constraint.table,
          isValid: false,
          violationCount: 1,
          violations: [{ error: 'Validation check failed' }],
          description: constraint.description,
          severity: 'ERROR'
        });
      }
    }

    return results;
  }

  private async validateDataTypes(): Promise<DataTypeValidationResult[]> {
    const results: DataTypeValidationResult[] = [];

    // Define expected data types for key fields
    const dataTypeConstraints = [
    { table: 'products', tableId: 38157, field: 'cost_price', expectedType: 'number' },
    { table: 'products', tableId: 38157, field: 'selling_price', expectedType: 'number' },
    { table: 'products', tableId: 38157, field: 'stock_level', expectedType: 'integer' },
    { table: 'sales_transactions', tableId: 38156, field: 'quantity_sold', expectedType: 'number' },
    { table: 'sales_transactions', tableId: 38156, field: 'unit_price', expectedType: 'number' },
    { table: 'sales_transactions', tableId: 38156, field: 'total_amount', expectedType: 'number' },
    { table: 'invoices', tableId: 38565, field: 'subtotal', expectedType: 'number' },
    { table: 'invoices', tableId: 38565, field: 'total_amount', expectedType: 'number' },
    { table: 'employees', tableId: 37818, field: 'salary', expectedType: 'number' },
    { table: 'customers', tableId: 38563, field: 'email', expectedType: 'email' },
    { table: 'suppliers', tableId: 38564, field: 'email', expectedType: 'email' },
    { table: 'employees', tableId: 37818, field: 'email', expectedType: 'email' }];


    for (const constraint of dataTypeConstraints) {
      try {
        const { data, error } = await window.ezsite.apis.tablePage(constraint.tableId, {
          PageNo: 1,
          PageSize: 500,
          OrderByField: "id",
          IsAsc: false,
          Filters: []
        });

        if (error) {
          results.push({
            field: constraint.field,
            tableName: constraint.table,
            expectedType: constraint.expectedType,
            actualType: 'unknown',
            isValid: false,
            invalidRecords: [{ error: `Unable to check data type: ${error}` }],
            description: `Data type validation failed for ${constraint.field}`
          });
          continue;
        }

        const records = data?.List || [];
        const invalidRecords = records.filter((record: any) => {
          const value = record[constraint.field];
          if (value === null || value === undefined) return false; // Skip null/undefined values

          return !this.validateDataType(value, constraint.expectedType);
        });

        results.push({
          field: constraint.field,
          tableName: constraint.table,
          expectedType: constraint.expectedType,
          actualType: 'mixed',
          isValid: invalidRecords.length === 0,
          invalidRecords: invalidRecords.slice(0, 10),
          description: `Field '${constraint.field}' must be of type ${constraint.expectedType}`
        });

      } catch (error) {
        results.push({
          field: constraint.field,
          tableName: constraint.table,
          expectedType: constraint.expectedType,
          actualType: 'unknown',
          isValid: false,
          invalidRecords: [{ error: 'Data type validation failed' }],
          description: `Data type validation encountered an error for ${constraint.field}`
        });
      }
    }

    return results;
  }

  private validateDataType(value: any, expectedType: string): boolean {
    switch (expectedType) {
      case 'number':
        return typeof value === 'number' && !isNaN(value);
      case 'integer':
        return typeof value === 'number' && Number.isInteger(value) && !isNaN(value);
      case 'string':
        return typeof value === 'string';
      case 'boolean':
        return typeof value === 'boolean';
      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return typeof value === 'string' && emailRegex.test(value);
      default:
        return true; // Unknown type, assume valid
    }
  }

  private async validateForeignKeyConstraints(): Promise<ForeignKeyValidationResult[]> {
    const results: ForeignKeyValidationResult[] = [];

    const foreignKeyConstraints = [
    {
      name: 'products_supplier_fk',
      sourceTable: 'products',
      sourceTableId: 38157,
      sourceField: 'supplier_id',
      targetTable: 'suppliers',
      targetTableId: 38564,
      targetField: 'id',
      required: false
    },
    {
      name: 'sales_product_fk',
      sourceTable: 'sales_transactions',
      sourceTableId: 38156,
      sourceField: 'product_id',
      targetTable: 'products',
      targetTableId: 38157,
      targetField: 'id',
      required: true
    },
    {
      name: 'sales_employee_fk',
      sourceTable: 'sales_transactions',
      sourceTableId: 38156,
      sourceField: 'employee_id',
      targetTable: 'employees',
      targetTableId: 37818,
      targetField: 'id',
      required: true
    },
    {
      name: 'invoices_customer_fk',
      sourceTable: 'invoices',
      sourceTableId: 38565,
      sourceField: 'customer_id',
      targetTable: 'customers',
      targetTableId: 38563,
      targetField: 'id',
      required: true
    },
    {
      name: 'salary_employee_fk',
      sourceTable: 'salary_calculations',
      sourceTableId: 38567,
      sourceField: 'employee_id',
      targetTable: 'employees',
      targetTableId: 37818,
      targetField: 'id',
      required: true
    }];


    for (const fk of foreignKeyConstraints) {
      try {
        // Get source table data
        const { data: sourceData, error: sourceError } = await window.ezsite.apis.tablePage(fk.sourceTableId, {
          PageNo: 1,
          PageSize: 500,
          OrderByField: "id",
          IsAsc: false,
          Filters: []
        });

        if (sourceError) {
          results.push({
            relationshipName: fk.name,
            sourceTable: fk.sourceTable,
            sourceField: fk.sourceField,
            targetTable: fk.targetTable,
            targetField: fk.targetField,
            orphanedRecords: [{ error: `Unable to check foreign key: ${sourceError}` }],
            isValid: false,
            description: `Foreign key constraint validation failed`
          });
          continue;
        }

        // Get target table data
        const { data: targetData, error: targetError } = await window.ezsite.apis.tablePage(fk.targetTableId, {
          PageNo: 1,
          PageSize: 1000,
          OrderByField: "id",
          IsAsc: false,
          Filters: []
        });

        if (targetError) {
          results.push({
            relationshipName: fk.name,
            sourceTable: fk.sourceTable,
            sourceField: fk.sourceField,
            targetTable: fk.targetTable,
            targetField: fk.targetField,
            orphanedRecords: [{ error: `Unable to check target table: ${targetError}` }],
            isValid: false,
            description: `Foreign key constraint validation failed`
          });
          continue;
        }

        const sourceRecords = sourceData?.List || [];
        const targetRecords = targetData?.List || [];
        const targetIds = new Set(targetRecords.map((record: any) => record[fk.targetField]?.toString()));

        const orphanedRecords = sourceRecords.filter((record: any) => {
          const foreignKeyValue = record[fk.sourceField];
          if (!foreignKeyValue && !fk.required) return false; // Optional FK can be null
          return foreignKeyValue && !targetIds.has(foreignKeyValue.toString());
        });

        results.push({
          relationshipName: fk.name,
          sourceTable: fk.sourceTable,
          sourceField: fk.sourceField,
          targetTable: fk.targetTable,
          targetField: fk.targetField,
          orphanedRecords: orphanedRecords.slice(0, 10),
          isValid: orphanedRecords.length === 0,
          description: `Foreign key ${fk.sourceTable}.${fk.sourceField} must reference existing ${fk.targetTable}.${fk.targetField}`
        });

      } catch (error) {
        results.push({
          relationshipName: fk.name,
          sourceTable: fk.sourceTable,
          sourceField: fk.sourceField,
          targetTable: fk.targetTable,
          targetField: fk.targetField,
          orphanedRecords: [{ error: 'Foreign key validation failed' }],
          isValid: false,
          description: `Foreign key constraint validation encountered an error`
        });
      }
    }

    return results;
  }

  private async validateBusinessRuleConstraints(): Promise<{rule: string;tableName: string;violationCount: number;description: string;}[]> {
    const results: {rule: string;tableName: string;violationCount: number;description: string;}[] = [];

    // This method validates high-level business rules that span multiple constraints
    try {
      // Rule: Customer with transactions should have complete contact info
      const customerBusinessRule = await this.validateCustomerBusinessRules();
      if (customerBusinessRule.violationCount > 0) {
        results.push(customerBusinessRule);
      }

      // Rule: Products with sales should maintain minimum stock levels
      const stockBusinessRule = await this.validateStockBusinessRules();
      if (stockBusinessRule.violationCount > 0) {
        results.push(stockBusinessRule);
      }

      // Rule: Invoice totals should match line item sums
      const invoiceBusinessRule = await this.validateInvoiceBusinessRules();
      if (invoiceBusinessRule.violationCount > 0) {
        results.push(invoiceBusinessRule);
      }

    } catch (error) {
      console.error('Business rule validation failed:', error);
    }

    return results;
  }

  private async validateCustomerBusinessRules() {
    // Implementation would check customer data completeness for active customers
    return {
      rule: 'customer_data_completeness',
      tableName: 'customers',
      violationCount: 0,
      description: 'Active customers should have complete contact information'
    };
  }

  private async validateStockBusinessRules() {
    // Implementation would check stock levels vs sales activity
    return {
      rule: 'stock_management',
      tableName: 'products',
      violationCount: 0,
      description: 'Products with recent sales should maintain adequate stock levels'
    };
  }

  private async validateInvoiceBusinessRules() {
    // Implementation would validate invoice calculation logic
    return {
      rule: 'invoice_calculations',
      tableName: 'invoices',
      violationCount: 0,
      description: 'Invoice totals should be mathematically correct'
    };
  }
}

export const constraintValidationService = new ConstraintValidationService();