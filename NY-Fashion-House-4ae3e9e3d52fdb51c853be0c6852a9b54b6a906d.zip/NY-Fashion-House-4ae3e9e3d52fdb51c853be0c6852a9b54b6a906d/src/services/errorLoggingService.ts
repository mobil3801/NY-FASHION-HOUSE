
// Error logging service for comprehensive error tracking and reporting
export interface ErrorLog {
  id: string;
  error: Error;
  context: ErrorContext;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
  resolved: boolean;
}

export interface ErrorContext {
  service?: string;
  operation?: string;
  userId?: string;
  sessionId?: string;
  component?: string;
  url?: string;
  userAgent?: string;
  additionalData?: any;
  severity?: 'low' | 'medium' | 'high' | 'critical';
  context?: any;
}

class ErrorLoggingService {
  private errorLogs: ErrorLog[] = [];
  private maxLogs = 1000; // Keep last 1000 errors in memory

  // Log an error with context
  logError(error: Error, context: ErrorContext = {}): void {
    try {
      const errorLog: ErrorLog = {
        id: `error-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        error,
        context: {
          ...context,
          url: window?.location?.href,
          userAgent: navigator?.userAgent,
          timestamp: new Date()
        },
        timestamp: new Date(),
        severity: context.severity || 'medium',
        resolved: false
      };

      this.errorLogs.push(errorLog);

      // Keep only the most recent logs
      if (this.errorLogs.length > this.maxLogs) {
        this.errorLogs = this.errorLogs.slice(-this.maxLogs);
      }

      // Log to console based on severity
      switch (context.severity) {
        case 'critical':
        case 'high':
          console.error('[ERROR]', error.message, context);
          break;
        case 'medium':
          console.warn('[WARNING]', error.message, context);
          break;
        case 'low':
        default:
          console.log('[INFO]', error.message, context);
          break;
      }

    } catch (loggingError) {
      // Fallback if logging itself fails
      console.error('Failed to log error:', loggingError);
      console.error('Original error:', error);
    }
  }

  // Get all error logs
  getErrorLogs(): ErrorLog[] {
    return [...this.errorLogs];
  }

  // Get error logs by severity
  getErrorLogsBySeverity(severity: ErrorLog['severity']): ErrorLog[] {
    return this.errorLogs.filter((log) => log.severity === severity);
  }

  // Get recent error logs
  getRecentErrorLogs(minutes: number = 60): ErrorLog[] {
    const cutoff = new Date(Date.now() - minutes * 60 * 1000);
    return this.errorLogs.filter((log) => log.timestamp > cutoff);
  }

  // Mark error as resolved
  resolveError(errorId: string): void {
    const errorLog = this.errorLogs.find((log) => log.id === errorId);
    if (errorLog) {
      errorLog.resolved = true;
    }
  }

  // Clear resolved errors
  clearResolvedErrors(): void {
    this.errorLogs = this.errorLogs.filter((log) => !log.resolved);
  }

  // Create user-friendly error message
  createUserFriendlyMessage(error: Error): string {
    const message = error.message.toLowerCase();

    if (message.includes('network') || message.includes('fetch')) {
      return 'Network connection error. Please check your internet connection and try again.';
    }

    if (message.includes('unauthorized') || message.includes('401')) {
      return 'Your session has expired. Please log in again.';
    }

    if (message.includes('forbidden') || message.includes('403')) {
      return 'You do not have permission to perform this action.';
    }

    if (message.includes('not found') || message.includes('404')) {
      return 'The requested resource was not found.';
    }

    if (message.includes('timeout')) {
      return 'The operation timed out. Please try again.';
    }

    if (message.includes('validation') || message.includes('invalid')) {
      return 'Invalid data provided. Please check your input and try again.';
    }

    // Default fallback message
    return 'An unexpected error occurred. Please try again or contact support if the problem persists.';
  }

  // Get error statistics
  getErrorStatistics(): {
    total: number;
    bySeverity: Record<ErrorLog['severity'], number>;
    resolved: number;
    recent: number;
  } {
    const recentLogs = this.getRecentErrorLogs(60);

    return {
      total: this.errorLogs.length,
      bySeverity: {
        low: this.getErrorLogsBySeverity('low').length,
        medium: this.getErrorLogsBySeverity('medium').length,
        high: this.getErrorLogsBySeverity('high').length,
        critical: this.getErrorLogsBySeverity('critical').length
      },
      resolved: this.errorLogs.filter((log) => log.resolved).length,
      recent: recentLogs.length
    };
  }

  // Clear all error logs
  clearAllErrors(): void {
    this.errorLogs = [];
  }
}

export const errorLoggingService = new ErrorLoggingService();