import { ServiceEndpoint } from './apiEndpointDiscoveryService';
import { TestCase, TestResult } from './automatedTestGeneratorService';

export interface ErrorScenario {
  id: string;
  name: string;
  description: string;
  category: 'NETWORK' | 'VALIDATION' | 'AUTHORIZATION' | 'NOT_FOUND' | 'TIMEOUT' | 'SERVER_ERROR' | 'BUSINESS_LOGIC';
  testData: any;
  expectedErrorType: string;
  expectedErrorMessage?: RegExp | string;
  shouldThrow: boolean;
}

export interface ErrorHandlingTestResult {
  scenarioId: string;
  endpoint: string;
  status: 'PASS' | 'FAIL' | 'ERROR';
  actualError?: Error;
  expectedError?: string;
  errorCategory: string;
  handlesGracefully: boolean;
  providesUserFriendlyMessage: boolean;
  logsProperly: boolean;
  executionTime: number;
}

export interface ErrorHandlingReport {
  endpointId: string;
  serviceName: string;
  methodName: string;
  totalScenarios: number;
  passedScenarios: number;
  failedScenarios: number;
  errorScenarios: number;
  overallScore: number;
  results: ErrorHandlingTestResult[];
  recommendations: string[];
}

export class ErrorHandlingVerificationService {
  private errorScenarios: Map<string, ErrorScenario[]> = new Map();

  constructor() {
    this.initializeCommonErrorScenarios();
  }

  /**
   * Initialize common error scenarios for different operation types
   */
  private initializeCommonErrorScenarios(): void {
    // CREATE operation error scenarios
    this.errorScenarios.set('CREATE', [
    {
      id: 'create_null_data',
      name: 'Null Data Input',
      description: 'Test creating entity with null data',
      category: 'VALIDATION',
      testData: null,
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /null|required|invalid/i,
      shouldThrow: true
    },
    {
      id: 'create_empty_object',
      name: 'Empty Object Input',
      description: 'Test creating entity with empty object',
      category: 'VALIDATION',
      testData: {},
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /required|empty|missing/i,
      shouldThrow: true
    },
    {
      id: 'create_invalid_data_types',
      name: 'Invalid Data Types',
      description: 'Test creating entity with wrong data types',
      category: 'VALIDATION',
      testData: {
        name: 123, // Should be string
        email: true, // Should be string
        price: 'invalid' // Should be number
      },
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /type|format|invalid/i,
      shouldThrow: true
    },
    {
      id: 'create_duplicate_entry',
      name: 'Duplicate Entry',
      description: 'Test creating duplicate entity',
      category: 'BUSINESS_LOGIC',
      testData: {
        email: 'existing@example.com',
        name: 'Existing User'
      },
      expectedErrorType: 'DuplicateError',
      expectedErrorMessage: /duplicate|exists|already/i,
      shouldThrow: true
    }]
    );

    // READ operation error scenarios
    this.errorScenarios.set('READ', [
    {
      id: 'read_invalid_id',
      name: 'Invalid ID Format',
      description: 'Test reading with invalid ID format',
      category: 'VALIDATION',
      testData: 'invalid-id-format-###',
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /invalid.*id|format/i,
      shouldThrow: false // Should return null gracefully
    },
    {
      id: 'read_non_existent_id',
      name: 'Non-existent ID',
      description: 'Test reading with non-existent ID',
      category: 'NOT_FOUND',
      testData: '999999999',
      expectedErrorType: 'NotFoundError',
      expectedErrorMessage: /not found|does not exist/i,
      shouldThrow: false // Should return null
    },
    {
      id: 'read_empty_id',
      name: 'Empty ID',
      description: 'Test reading with empty ID',
      category: 'VALIDATION',
      testData: '',
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /empty|required.*id/i,
      shouldThrow: true
    },
    {
      id: 'read_null_id',
      name: 'Null ID',
      description: 'Test reading with null ID',
      category: 'VALIDATION',
      testData: null,
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /null|required.*id/i,
      shouldThrow: true
    }]
    );

    // UPDATE operation error scenarios
    this.errorScenarios.set('UPDATE', [
    {
      id: 'update_non_existent_id',
      name: 'Non-existent ID Update',
      description: 'Test updating non-existent entity',
      category: 'NOT_FOUND',
      testData: { id: '999999999', updates: { name: 'New Name' } },
      expectedErrorType: 'NotFoundError',
      expectedErrorMessage: /not found|does not exist/i,
      shouldThrow: true
    },
    {
      id: 'update_empty_updates',
      name: 'Empty Updates',
      description: 'Test updating with empty updates object',
      category: 'VALIDATION',
      testData: { id: '1', updates: {} },
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /empty.*update|no.*changes/i,
      shouldThrow: false // Some services allow empty updates
    },
    {
      id: 'update_invalid_field_types',
      name: 'Invalid Field Types',
      description: 'Test updating with invalid field types',
      category: 'VALIDATION',
      testData: {
        id: '1',
        updates: {
          price: 'not-a-number',
          active: 'not-a-boolean'
        }
      },
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /type|format|invalid/i,
      shouldThrow: true
    },
    {
      id: 'update_readonly_fields',
      name: 'Update Readonly Fields',
      description: 'Test updating readonly fields like ID or timestamps',
      category: 'BUSINESS_LOGIC',
      testData: {
        id: '1',
        updates: {
          id: '2',
          createdAt: new Date()
        }
      },
      expectedErrorType: 'BusinessLogicError',
      expectedErrorMessage: /readonly|cannot.*update|immutable/i,
      shouldThrow: false // May be ignored or cause error
    }]
    );

    // DELETE operation error scenarios
    this.errorScenarios.set('DELETE', [
    {
      id: 'delete_non_existent_id',
      name: 'Non-existent ID Delete',
      description: 'Test deleting non-existent entity',
      category: 'NOT_FOUND',
      testData: '999999999',
      expectedErrorType: 'NotFoundError',
      expectedErrorMessage: /not found|does not exist/i,
      shouldThrow: true
    },
    {
      id: 'delete_invalid_id',
      name: 'Invalid ID Delete',
      description: 'Test deleting with invalid ID format',
      category: 'VALIDATION',
      testData: 'invalid-id-###',
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /invalid.*id|format/i,
      shouldThrow: true
    },
    {
      id: 'delete_protected_entity',
      name: 'Delete Protected Entity',
      description: 'Test deleting entity with dependencies',
      category: 'BUSINESS_LOGIC',
      testData: '1', // Assuming ID 1 has dependencies
      expectedErrorType: 'BusinessLogicError',
      expectedErrorMessage: /dependency|referenced|cannot.*delete/i,
      shouldThrow: true
    }]
    );

    // UTILITY operation error scenarios
    this.errorScenarios.set('UTILITY', [
    {
      id: 'utility_invalid_parameters',
      name: 'Invalid Parameters',
      description: 'Test utility method with invalid parameters',
      category: 'VALIDATION',
      testData: { invalid: 'parameter' },
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /parameter|invalid|format/i,
      shouldThrow: true
    },
    {
      id: 'utility_missing_parameters',
      name: 'Missing Required Parameters',
      description: 'Test utility method with missing parameters',
      category: 'VALIDATION',
      testData: undefined,
      expectedErrorType: 'ValidationError',
      expectedErrorMessage: /required|missing|parameter/i,
      shouldThrow: true
    }]
    );
  }

  /**
   * Test error handling for a specific endpoint
   */
  async testEndpointErrorHandling(endpoint: ServiceEndpoint): Promise<ErrorHandlingReport> {
    const scenarios = this.getScenarios(endpoint.operationType);
    const results: ErrorHandlingTestResult[] = [];
    const recommendations: string[] = [];

    for (const scenario of scenarios) {
      try {
        const result = await this.executeErrorScenario(endpoint, scenario);
        results.push(result);
      } catch (error) {
        results.push({
          scenarioId: scenario.id,
          endpoint: `${endpoint.serviceName}.${endpoint.methodName}`,
          status: 'ERROR',
          actualError: error as Error,
          expectedError: scenario.expectedErrorType,
          errorCategory: scenario.category,
          handlesGracefully: false,
          providesUserFriendlyMessage: false,
          logsProperly: false,
          executionTime: 0
        });
      }
    }

    // Generate recommendations
    recommendations.push(...this.generateRecommendations(results, endpoint));

    const passedScenarios = results.filter((r) => r.status === 'PASS').length;
    const failedScenarios = results.filter((r) => r.status === 'FAIL').length;
    const errorScenarios = results.filter((r) => r.status === 'ERROR').length;
    const overallScore = results.length > 0 ? passedScenarios / results.length * 100 : 0;

    return {
      endpointId: `${endpoint.serviceName}.${endpoint.methodName}`,
      serviceName: endpoint.serviceName,
      methodName: endpoint.methodName,
      totalScenarios: results.length,
      passedScenarios,
      failedScenarios,
      errorScenarios,
      overallScore,
      results,
      recommendations
    };
  }

  /**
   * Execute a single error scenario
   */
  private async executeErrorScenario(
  endpoint: ServiceEndpoint,
  scenario: ErrorScenario)
  : Promise<ErrorHandlingTestResult> {
    const startTime = performance.now();
    let actualError: Error | undefined;
    let handlesGracefully = false;
    let providesUserFriendlyMessage = false;
    let logsProperly = true; // Assume true unless we can detect otherwise

    try {
      // Execute the endpoint method with error scenario data
      const result = await this.invokeEndpointWithErrorData(endpoint, scenario.testData);

      // If we expected an error but didn't get one
      if (scenario.shouldThrow) {
        return {
          scenarioId: scenario.id,
          endpoint: `${endpoint.serviceName}.${endpoint.methodName}`,
          status: 'FAIL',
          expectedError: scenario.expectedErrorType,
          errorCategory: scenario.category,
          handlesGracefully: false,
          providesUserFriendlyMessage: false,
          logsProperly: false,
          executionTime: performance.now() - startTime
        };
      }

      // For scenarios that shouldn't throw, check if result is handled gracefully
      handlesGracefully = result === null || result === undefined ||
      Array.isArray(result) && result.length === 0;

      return {
        scenarioId: scenario.id,
        endpoint: `${endpoint.serviceName}.${endpoint.methodName}`,
        status: 'PASS',
        expectedError: scenario.expectedErrorType,
        errorCategory: scenario.category,
        handlesGracefully,
        providesUserFriendlyMessage: true,
        logsProperly,
        executionTime: performance.now() - startTime
      };

    } catch (error) {
      actualError = error as Error;

      // Check if error matches expected criteria
      const errorMatches = this.validateExpectedError(error as Error, scenario);
      handlesGracefully = true; // It threw as expected
      providesUserFriendlyMessage = this.checkUserFriendlyMessage(error as Error);

      return {
        scenarioId: scenario.id,
        endpoint: `${endpoint.serviceName}.${endpoint.methodName}`,
        status: errorMatches ? 'PASS' : 'FAIL',
        actualError,
        expectedError: scenario.expectedErrorType,
        errorCategory: scenario.category,
        handlesGracefully,
        providesUserFriendlyMessage,
        logsProperly,
        executionTime: performance.now() - startTime
      };
    }
  }

  /**
   * Invoke endpoint method with error data
   */
  private async invokeEndpointWithErrorData(endpoint: ServiceEndpoint, testData: any): Promise<any> {
    const method = endpoint.method;

    // Handle different method signatures
    switch (endpoint.operationType) {
      case 'CREATE':
        return await method(testData);

      case 'READ':
        if (endpoint.methodName.toLowerCase().includes('getall')) {
          return await method(testData);
        }
        return await method(testData);

      case 'UPDATE':
        if (testData && typeof testData === 'object' && testData.id && testData.updates) {
          return await method(testData.id, testData.updates);
        }
        return await method(testData);

      case 'DELETE':
        return await method(testData);

      case 'UTILITY':
        if (Array.isArray(testData)) {
          return await method(...testData);
        }
        return await method(testData);

      default:
        return await method(testData);
    }
  }

  /**
   * Validate if error matches expected criteria
   */
  private validateExpectedError(actualError: Error, scenario: ErrorScenario): boolean {
    const errorMessage = actualError.message || '';
    const errorName = actualError.name || actualError.constructor.name || '';

    // Check error type/name
    if (scenario.expectedErrorType &&
    !errorName.toLowerCase().includes(scenario.expectedErrorType.toLowerCase())) {
      return false;
    }

    // Check error message pattern
    if (scenario.expectedErrorMessage) {
      if (scenario.expectedErrorMessage instanceof RegExp) {
        return scenario.expectedErrorMessage.test(errorMessage);
      } else {
        return errorMessage.toLowerCase().includes(scenario.expectedErrorMessage.toLowerCase());
      }
    }

    return true;
  }

  /**
   * Check if error provides user-friendly message
   */
  private checkUserFriendlyMessage(error: Error): boolean {
    const message = error.message || '';

    // Check for technical jargon that shouldn't be shown to users
    const technicalTerms = [
    'null pointer', 'undefined', 'stack trace', 'database', 'sql',
    'connection', 'timeout', 'server', 'internal', 'debug', 'trace'];


    const hasUserFriendlyIndicators = [
    message.length > 10, // Not too short
    !technicalTerms.some((term) => message.toLowerCase().includes(term)),
    /^[A-Z]/.test(message), // Starts with capital letter
    message.includes(' ') // Contains spaces (not just error codes)
    ].filter(Boolean).length >= 3;

    return hasUserFriendlyIndicators;
  }

  /**
   * Get error scenarios for operation type
   */
  private getScenarios(operationType: string): ErrorScenario[] {
    return this.errorScenarios.get(operationType) || [];
  }

  /**
   * Generate recommendations based on test results
   */
  private generateRecommendations(
  results: ErrorHandlingTestResult[],
  endpoint: ServiceEndpoint)
  : string[] {
    const recommendations: string[] = [];
    const failedResults = results.filter((r) => r.status === 'FAIL');
    const ungracefulHandling = results.filter((r) => !r.handlesGracefully);
    const poorMessages = results.filter((r) => !r.providesUserFriendlyMessage);

    if (failedResults.length > 0) {
      recommendations.push(
        `${failedResults.length} error scenarios failed. Review error handling logic.`
      );
    }

    if (ungracefulHandling.length > 0) {
      recommendations.push(
        'Improve graceful error handling for invalid inputs.'
      );
    }

    if (poorMessages.length > 0) {
      recommendations.push(
        'Enhance error messages to be more user-friendly and descriptive.'
      );
    }

    // Operation-specific recommendations
    if (endpoint.operationType === 'CREATE') {
      recommendations.push('Ensure proper validation of required fields and data types.');
    } else if (endpoint.operationType === 'UPDATE') {
      recommendations.push('Add checks for non-existent entities and readonly fields.');
    } else if (endpoint.operationType === 'DELETE') {
      recommendations.push('Implement checks for entity dependencies before deletion.');
    }

    if (recommendations.length === 0) {
      recommendations.push('Error handling appears to be well implemented.');
    }

    return recommendations;
  }

  /**
   * Test error handling for multiple endpoints
   */
  async testMultipleEndpointsErrorHandling(endpoints: ServiceEndpoint[]): Promise<ErrorHandlingReport[]> {
    const reports: ErrorHandlingReport[] = [];

    for (const endpoint of endpoints) {
      try {
        const report = await this.testEndpointErrorHandling(endpoint);
        reports.push(report);
      } catch (error) {
        console.error(`Error testing ${endpoint.serviceName}.${endpoint.methodName}:`, error);
      }
    }

    return reports;
  }

  /**
   * Generate comprehensive error handling summary
   */
  generateErrorHandlingSummary(reports: ErrorHandlingReport[]): {
    totalEndpoints: number;
    averageScore: number;
    bestPerformingEndpoints: string[];
    worstPerformingEndpoints: string[];
    commonIssues: string[];
    overallRecommendations: string[];
  } {
    const totalEndpoints = reports.length;
    const averageScore = reports.reduce((sum, r) => sum + r.overallScore, 0) / totalEndpoints;

    const sortedByScore = reports.sort((a, b) => b.overallScore - a.overallScore);
    const bestPerformingEndpoints = sortedByScore.slice(0, 3).map((r) => r.endpointId);
    const worstPerformingEndpoints = sortedByScore.slice(-3).map((r) => r.endpointId);

    // Analyze common issues
    const allRecommendations = reports.flatMap((r) => r.recommendations);
    const recommendationCounts = allRecommendations.reduce((acc, rec) => {
      acc[rec] = (acc[rec] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const commonIssues = Object.entries(recommendationCounts).
    filter(([, count]) => count > 1).
    sort(([, a], [, b]) => b - a).
    slice(0, 5).
    map(([issue]) => issue);

    const overallRecommendations = [
    `Average error handling score: ${averageScore.toFixed(1)}%`,
    'Focus on improving user-friendly error messages',
    'Implement consistent validation across all endpoints',
    'Add proper logging for debugging purposes',
    'Consider implementing circuit breaker patterns for external dependencies'];


    return {
      totalEndpoints,
      averageScore,
      bestPerformingEndpoints,
      worstPerformingEndpoints,
      commonIssues,
      overallRecommendations
    };
  }

  /**
   * Add custom error scenario
   */
  addCustomErrorScenario(operationType: string, scenario: ErrorScenario): void {
    const scenarios = this.errorScenarios.get(operationType) || [];
    scenarios.push(scenario);
    this.errorScenarios.set(operationType, scenarios);
  }
}

export const errorHandlingVerificationService = new ErrorHandlingVerificationService();