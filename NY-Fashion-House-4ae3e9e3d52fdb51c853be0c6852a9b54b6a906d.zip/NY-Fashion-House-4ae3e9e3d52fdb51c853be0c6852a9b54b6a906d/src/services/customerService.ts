import { Customer, Purchase } from '@/types/customer';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';

// Database service for customer management
const CUSTOMERS_TABLE_ID = 38563; // Updated with real table ID
const SALES_TRANSACTIONS_TABLE_ID = 38156;

// Service functions
export const getCustomers = async (): Promise<Customer[]> => {
  try {
    const { data, error } = await window.ezsite.apis.tablePage(CUSTOMERS_TABLE_ID, {
      PageNo: 1,
      PageSize: 1000,
      OrderByField: 'created_at',
      IsAsc: false,
      Filters: []
    });

    if (error) {
      const apiError = new Error(`Failed to fetch customers: ${error}`);
      enhancedErrorLoggingService.logError(apiError, {
        title: 'Customer Fetch Failed',
        action: 'Fetch customer list',
        operation: 'getCustomers',
        severity: 'medium',
        category: 'server',
        service: 'customerService',
        requestDetails: {
          url: '/api/customers',
          method: 'GET',
          params: { tableId: CUSTOMERS_TABLE_ID }
        }
      });
      throw apiError;
    }

    return data?.List?.map((record: any) => ({
      id: record.id?.toString() || '',
      name: record.name || '',
      email: record.email || '',
      phone: record.phone || '',
      address: record.address || '',
      notes: record.notes || '',
      createdAt: record.created_at || new Date().toISOString(),
      lastPurchase: record.last_purchase || '',
      totalPurchases: record.total_purchases || 0,
      totalSpent: record.total_spent || 0,
      status: record.status || 'active'
    })) || [];
  } catch (error) {
    // Enhanced error logging for better debugging
    enhancedErrorLoggingService.logError(error as Error, {
      title: 'Customer Service Error',
      action: 'Fetch customer list',
      operation: 'getCustomers',
      severity: 'medium',
      category: 'server',
      service: 'customerService'
    });
    throw error;
  }
};

export const getCustomerPurchases = async (customerId: string): Promise<Purchase[]> => {
  try {
    // Query sales_transactions table for customer purchases
    const { data, error } = await window.ezsite.apis.tablePage(SALES_TRANSACTIONS_TABLE_ID, {
      PageNo: 1,
      PageSize: 1000,
      OrderByField: 'sale_date',
      IsAsc: false,
      Filters: [
      {
        name: 'customer_id',
        op: 'Equal',
        value: customerId
      }]

    });

    if (error) throw new Error(error);

    return data?.List?.map((record: any) => ({
      id: record.id?.toString() || '',
      productId: record.product_id?.toString() || '',
      productName: record.product_name || '',
      quantity: record.quantity_sold || 0,
      price: record.unit_price || 0,
      total: record.total_amount || 0,
      date: record.sale_date || new Date().toISOString(),
      paymentMethod: 'cash', // Default since not stored in sales transactions
      status: 'completed' // Default status
    })) || [];
  } catch (error) {
    console.error('Error fetching customer purchases:', error);
    return [];
  }
};

export const createCustomer = async (customer: Omit<Customer, 'id' | 'createdAt' | 'totalPurchases' | 'totalSpent'>): Promise<Customer> => {
  try {
    // Validate required fields
    if (!customer.name || !customer.email) {
      const validationError = new Error('Name and email are required fields');
      enhancedErrorLoggingService.logError(validationError, {
        title: 'Customer Validation Failed',
        action: 'Create new customer',
        operation: 'createCustomer',
        severity: 'low',
        category: 'validation',
        service: 'customerService',
        userInputs: customer,
        formData: {
          name: customer.name,
          email: customer.email,
          hasName: !!customer.name,
          hasEmail: !!customer.email
        }
      });
      throw validationError;
    }

    const { error } = await window.ezsite.apis.tableCreate(CUSTOMERS_TABLE_ID, {
      name: customer.name,
      email: customer.email,
      phone: customer.phone,
      address: customer.address,
      notes: customer.notes,
      status: customer.status,
      created_at: new Date().toISOString(),
      total_purchases: 0,
      total_spent: 0
    });

    if (error) {
      const createError = new Error(`Failed to create customer: ${error}`);
      enhancedErrorLoggingService.logError(createError, {
        title: 'Customer Creation Failed',
        action: 'Create new customer',
        operation: 'createCustomer',
        severity: 'medium',
        category: 'server',
        service: 'customerService',
        userInputs: { name: customer.name, email: customer.email },
        apiError: error
      });
      throw createError;
    }

    // Fetch the created customer with retry logic
    try {
      const customers = await getCustomers();
      const newCustomer = customers.find((c) => c.email === customer.email);
      if (!newCustomer) {
        throw new Error('Customer was created but could not be retrieved');
      }
      return newCustomer;
    } catch (fetchError) {
      enhancedErrorLoggingService.logError(fetchError as Error, {
        title: 'Customer Fetch After Creation Failed',
        action: 'Fetch newly created customer',
        operation: 'createCustomer-fetch',
        severity: 'medium',
        category: 'server',
        service: 'customerService',
        userInputs: { email: customer.email }
      });
      throw new Error('Customer created successfully but could not be retrieved. Please refresh to see the new customer.');
    }
  } catch (error) {
    if (error instanceof Error && error.message.includes('required fields')) {
      throw error; // Re-throw validation errors as-is
    }

    enhancedErrorLoggingService.logError(error as Error, {
      title: 'Customer Creation Error',
      action: 'Create new customer',
      operation: 'createCustomer',
      severity: 'medium',
      category: 'server',
      service: 'customerService',
      userInputs: { name: customer.name, email: customer.email }
    });
    throw error;
  }
};

export const updateCustomer = async (id: string, updates: Partial<Customer>): Promise<Customer> => {
  try {
    const updateData: any = {
      id: parseInt(id)
    };

    // Map the updates to database field names
    if (updates.name !== undefined) updateData.name = updates.name;
    if (updates.email !== undefined) updateData.email = updates.email;
    if (updates.phone !== undefined) updateData.phone = updates.phone;
    if (updates.address !== undefined) updateData.address = updates.address;
    if (updates.notes !== undefined) updateData.notes = updates.notes;
    if (updates.status !== undefined) updateData.status = updates.status;
    if (updates.totalPurchases !== undefined) updateData.total_purchases = updates.totalPurchases;
    if (updates.totalSpent !== undefined) updateData.total_spent = updates.totalSpent;
    if (updates.lastPurchase !== undefined) updateData.last_purchase = updates.lastPurchase;

    const { error } = await window.ezsite.apis.tableUpdate(CUSTOMERS_TABLE_ID, updateData);

    if (error) throw new Error(error);

    // Fetch the updated customer
    const customers = await getCustomers();
    const updatedCustomer = customers.find((c) => c.id === id);
    if (!updatedCustomer) throw new Error('Customer not found');

    return updatedCustomer;
  } catch (error) {
    console.error('Error updating customer:', error);
    throw error;
  }
};

export const deleteCustomer = async (id: string): Promise<void> => {
  try {
    const { error } = await window.ezsite.apis.tableDelete(CUSTOMERS_TABLE_ID, {
      id: parseInt(id)
    });

    if (error) throw new Error(error);
  } catch (error) {
    console.error('Error deleting customer:', error);
    throw error;
  }
};

// Utility function to format USA phone numbers
export const formatUSAPhoneNumber = (phone: string): string => {
  const cleaned = phone.replace(/\D/g, '');

  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  } else if (cleaned.length === 11 && cleaned.startsWith('1')) {
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  }

  return phone; // Return original if format doesn't match
};

// Utility function to validate USA zip codes
export const validateUSAZipCode = (zipCode: string): boolean => {
  const zipRegex = /^\d{5}(-\d{4})?$/;
  return zipRegex.test(zipCode);
};