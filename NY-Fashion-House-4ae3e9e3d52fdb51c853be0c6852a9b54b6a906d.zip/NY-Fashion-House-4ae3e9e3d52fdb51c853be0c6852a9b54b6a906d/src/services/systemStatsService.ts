/**
 * System Statistics Service
 * Provides system-wide statistics and health metrics
 */

interface SystemStats {
  totalProducts: number;
  totalCustomers: number;
  totalOrders: number;
  totalRevenue: number;
  lowStockCount: number;
  pendingOrders: number;
  activeUsers: number;
  systemHealth: 'healthy' | 'warning' | 'critical';
}

interface DatabaseHealth {
  isConnected: boolean;
  responseTime: number;
  errorRate: number;
}

class SystemStatsService {
  private readonly PRODUCTS_TABLE_ID = 38157;
  private readonly CUSTOMERS_TABLE_ID = 38563;
  private readonly SALES_TRANSACTIONS_TABLE_ID = 38156;

  /**
   * Get comprehensive system statistics
   */
  async getSystemStats(): Promise<SystemStats> {
    try {
      const [
      productsCount,
      customersCount,
      ordersStats,
      lowStockCount,
      healthStatus] =
      await Promise.allSettled([
      this.getProductsCount(),
      this.getCustomersCount(),
      this.getOrdersStats(),
      this.getLowStockCount(),
      this.getSystemHealth()]
      );

      return {
        totalProducts: this.extractValue(productsCount, 0),
        totalCustomers: this.extractValue(customersCount, 0),
        totalOrders: this.extractValue(ordersStats, { count: 0, revenue: 0 }).count,
        totalRevenue: this.extractValue(ordersStats, { count: 0, revenue: 0 }).revenue,
        lowStockCount: this.extractValue(lowStockCount, 0),
        pendingOrders: 0, // TODO: Implement pending orders logic
        activeUsers: 1, // TODO: Implement active users tracking
        systemHealth: this.extractValue(healthStatus, 'warning' as const)
      };
    } catch (error) {
      console.error('Error fetching system stats:', error);
      // Return default stats if there's an error
      return {
        totalProducts: 0,
        totalCustomers: 0,
        totalOrders: 0,
        totalRevenue: 0,
        lowStockCount: 0,
        pendingOrders: 0,
        activeUsers: 0,
        systemHealth: 'warning' as const
      };
    }
  }

  /**
   * Get total products count
   */
  private async getProductsCount(): Promise<number> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(this.PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [{
          name: 'is_active',
          op: 'Equal',
          value: true
        }]
      });

      if (error) {
        console.warn('Error fetching products count:', error);
        return 0;
      }

      return data?.VirtualCount || 0;
    } catch (error) {
      console.warn('Failed to fetch products count:', error);
      return 0;
    }
  }

  /**
   * Get total customers count
   */
  private async getCustomersCount(): Promise<number> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(this.CUSTOMERS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: []
      });

      if (error) {
        console.warn('Error fetching customers count:', error);
        return 0;
      }

      return data?.VirtualCount || 0;
    } catch (error) {
      console.warn('Failed to fetch customers count:', error);
      return 0;
    }
  }

  /**
   * Get orders statistics
   */
  private async getOrdersStats(): Promise<{count: number;revenue: number;}> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(this.SALES_TRANSACTIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 100, // Get recent transactions to calculate revenue
        Filters: [],
        OrderByField: 'id',
        IsAsc: false
      });

      if (error) {
        console.warn('Error fetching orders stats:', error);
        return { count: 0, revenue: 0 };
      }

      const orders = data?.List || [];
      const count = data?.VirtualCount || 0;
      const revenue = orders.reduce((sum: number, order: any) => {
        return sum + (parseFloat(order.total_amount) || 0);
      }, 0);

      return { count, revenue };
    } catch (error) {
      console.warn('Failed to fetch orders stats:', error);
      return { count: 0, revenue: 0 };
    }
  }

  /**
   * Get low stock products count
   */
  private async getLowStockCount(): Promise<number> {
    try {
      // This would require a more complex query to compare stock_level with min_stock_level
      // For now, we'll return 0 as a placeholder
      return 0;
    } catch (error) {
      console.warn('Failed to fetch low stock count:', error);
      return 0;
    }
  }

  /**
   * Check system health
   */
  private async getSystemHealth(): Promise<'healthy' | 'warning' | 'critical'> {
    try {
      const startTime = Date.now();

      // Test database connectivity with a simple query
      const { error } = await window.ezsite.apis.tablePage(this.PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: []
      });

      const responseTime = Date.now() - startTime;

      if (error) {
        return 'critical';
      }

      if (responseTime > 5000) {// 5 seconds
        return 'warning';
      }

      return 'healthy';
    } catch (error) {
      console.warn('System health check failed:', error);
      return 'critical';
    }
  }

  /**
   * Get database health metrics
   */
  async getDatabaseHealth(): Promise<DatabaseHealth> {
    const startTime = Date.now();

    try {
      const { error } = await window.ezsite.apis.tablePage(this.PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: []
      });

      const responseTime = Date.now() - startTime;

      return {
        isConnected: !error,
        responseTime,
        errorRate: error ? 100 : 0
      };
    } catch (error) {
      return {
        isConnected: false,
        responseTime: Date.now() - startTime,
        errorRate: 100
      };
    }
  }

  /**
   * Utility method to safely extract values from Promise.allSettled results
   */
  private extractValue<T>(result: PromiseSettledResult<T>, defaultValue: T): T {
    return result.status === 'fulfilled' ? result.value : defaultValue;
  }

  /**
   * Get real-time metrics (placeholder for future implementation)
   */
  async getRealtimeMetrics(): Promise<{
    activeConnections: number;
    requestsPerMinute: number;
    memoryUsage: number;
    cpuUsage: number;
  }> {
    // Placeholder implementation
    return {
      activeConnections: Math.floor(Math.random() * 10) + 1,
      requestsPerMinute: Math.floor(Math.random() * 100) + 50,
      memoryUsage: Math.floor(Math.random() * 30) + 40, // 40-70%
      cpuUsage: Math.floor(Math.random() * 20) + 10 // 10-30%
    };
  }
}

export const systemStatsService = new SystemStatsService();
export default systemStatsService;