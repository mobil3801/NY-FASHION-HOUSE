import {
  SalaryStructure,
  SalaryCalculation,
  Advance,
  PaymentRecord,
  SalarySlip,
  BulkSalaryProcess,
  SalaryReport,
  BengaliDate,
  PayPeriod,
  SalaryStats,
  OvertimeCalculation,
  CalculatedAllowance,
  CalculatedDeduction } from
'@/types/salary';
import { Employee, Attendance } from '@/types/employee';
import { employeeService } from './employeeService';
import { accountingIntegrationService } from './accountingIntegrationService';

// Database table IDs
const SALARY_STRUCTURES_TABLE_ID = 38566;
const SALARY_CALCULATIONS_TABLE_ID = 38567;
const SALARY_ADVANCES_TABLE_ID = 38568;
const SALARY_PAYMENTS_TABLE_ID = 38569;

// Bengali months
const bengaliMonths = [
'বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়', 'শ্রাবণ', 'ভাদ্র', 'আশ্বিন',
'কার্তিক', 'অগ্রহায়ণ', 'পৌষ', 'মাঘ', 'ফাল্গুন', 'চৈত্র'];


export const salaryService = {
  // Bengali calendar functions
  convertToBengaliDate: (englishDate: Date): BengaliDate => {
    // Simplified Bengali calendar conversion
    // In a real application, use a proper Bengali calendar library
    const year = englishDate.getFullYear();
    const month = englishDate.getMonth();
    const day = englishDate.getDate();

    const bengaliYear = year + 593; // Approximate conversion
    const bengaliMonth = month + 1;
    const bengaliMonthName = bengaliMonths[month % 12];

    return {
      bengaliDay: day,
      bengaliMonth,
      bengaliYear,
      bengaliMonthName,
      englishDate
    };
  },

  getCurrentBengaliMonth: (): {month: string;year: string;} => {
    const currentDate = new Date();
    const bengaliDate = salaryService.convertToBengaliDate(currentDate);
    return {
      month: bengaliDate.bengaliMonthName,
      year: bengaliDate.bengaliYear.toString()
    };
  },

  // Salary Structure Management
  getAllSalaryStructures: async (): Promise<SalaryStructure[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_STRUCTURES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        position: record.position || '',
        department: record.department || '',
        baseSalary: record.base_salary || 0,
        allowances: record.allowances ? JSON.parse(record.allowances) : [],
        deductions: record.deductions ? JSON.parse(record.deductions) : [],
        overtimeRate: record.overtime_rate || 0,
        isActive: record.is_active !== false,
        createdAt: record.created_at || new Date().toISOString(),
        updatedAt: record.updated_at || new Date().toISOString()
      })) || [];
    } catch (error) {
      console.error('Error fetching salary structures:', error);
      return [];
    }
  },

  createSalaryStructure: async (structure: Omit<SalaryStructure, 'id' | 'createdAt' | 'updatedAt'>): Promise<SalaryStructure> => {
    try {
      const now = new Date().toISOString();

      const { error } = await window.ezsite.apis.tableCreate(SALARY_STRUCTURES_TABLE_ID, {
        position: structure.position,
        department: structure.department,
        base_salary: structure.baseSalary,
        allowances: JSON.stringify(structure.allowances),
        deductions: JSON.stringify(structure.deductions),
        overtime_rate: structure.overtimeRate,
        is_active: structure.isActive,
        created_at: now,
        updated_at: now
      });

      if (error) throw new Error(error);

      // Fetch the created structure
      const structures = await salaryService.getAllSalaryStructures();
      const newStructure = structures.find((s) =>
      s.position === structure.position && s.department === structure.department
      );

      if (!newStructure) throw new Error('Failed to create salary structure');
      return newStructure;
    } catch (error) {
      console.error('Error creating salary structure:', error);
      throw error;
    }
  },

  getSalaryStructureByPosition: async (position: string, department: string): Promise<SalaryStructure | null> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_STRUCTURES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        { name: 'position', op: 'Equal', value: position },
        { name: 'department', op: 'Equal', value: department },
        { name: 'is_active', op: 'Equal', value: true }]

      });

      if (error) throw new Error(error);

      const record = data?.List?.[0];
      if (!record) return null;

      return {
        id: record.id?.toString() || '',
        position: record.position || '',
        department: record.department || '',
        baseSalary: record.base_salary || 0,
        allowances: record.allowances ? JSON.parse(record.allowances) : [],
        deductions: record.deductions ? JSON.parse(record.deductions) : [],
        overtimeRate: record.overtime_rate || 0,
        isActive: record.is_active !== false,
        createdAt: record.created_at || new Date().toISOString(),
        updatedAt: record.updated_at || new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching salary structure:', error);
      return null;
    }
  },

  // Salary Calculation
  calculateSalary: async (employeeId: string, payPeriod: string): Promise<SalaryCalculation> => {
    const employee = await employeeService.getEmployeeById(employeeId);
    if (!employee) {
      throw new Error('Employee not found');
    }

    const salaryStructure = await salaryService.getSalaryStructureByPosition(employee.position, employee.department);
    if (!salaryStructure) {
      throw new Error('Salary structure not found for this position');
    }

    // Calculate attendance and overtime
    const startDate = `${payPeriod}-01`;
    const endDate = new Date(parseInt(payPeriod.split('-')[0]), parseInt(payPeriod.split('-')[1]), 0).toISOString().split('T')[0];

    const attendance = await employeeService.getAttendanceByEmployee(employeeId, startDate, endDate);
    const overtimeCalculation = salaryService.calculateOvertime(attendance, salaryStructure.overtimeRate);

    // Calculate allowances
    const allowances: CalculatedAllowance[] = salaryStructure.allowances.
    filter((a) => a.isActive).
    map((allowance) => ({
      id: allowance.id,
      name: allowance.name,
      type: allowance.type,
      baseAmount: allowance.amount,
      calculatedAmount: allowance.type === 'percentage' ?
      salaryStructure.baseSalary * allowance.amount / 100 :
      allowance.amount
    }));

    const totalAllowances = allowances.reduce((sum, a) => sum + a.calculatedAmount, 0);
    const grossSalary = salaryStructure.baseSalary + totalAllowances + overtimeCalculation.overtimeAmount;

    // Calculate deductions
    const deductions: CalculatedDeduction[] = salaryStructure.deductions.
    filter((d) => d.isActive).
    map((deduction) => {
      let calculatedAmount = 0;
      let taxDetails = undefined;

      if (deduction.type === 'fixed') {
        calculatedAmount = deduction.amount;
      } else if (deduction.type === 'percentage') {
        calculatedAmount = salaryStructure.baseSalary * deduction.amount / 100;
      } else if (deduction.type === 'tax' && deduction.taxBracket) {
        if (grossSalary >= deduction.taxBracket.minIncome && grossSalary <= deduction.taxBracket.maxIncome) {
          calculatedAmount = grossSalary * deduction.taxBracket.rate / 100;
          taxDetails = {
            taxableIncome: grossSalary,
            taxRate: deduction.taxBracket.rate
          };
        }
      }

      return {
        id: deduction.id,
        name: deduction.name,
        type: deduction.type,
        baseAmount: deduction.amount,
        calculatedAmount,
        taxDetails
      };
    });

    // Check for advance deductions
    const advances = await salaryService.getAdvancesByEmployee(employeeId);
    const pendingAdvances = advances.filter((a) => !a.isFullyPaid && a.approvalStatus === 'approved');

    for (const advance of pendingAdvances) {
      const scheduleItem = advance.deductionSchedule.find((s) => s.payPeriod === payPeriod && !s.isDeducted);
      if (scheduleItem) {
        deductions.push({
          id: `advance-${advance.id}`,
          name: `Advance Deduction - ${advance.reason}`,
          type: 'fixed',
          baseAmount: scheduleItem.amount,
          calculatedAmount: scheduleItem.amount
        });
      }
    }

    const totalDeductions = deductions.reduce((sum, d) => sum + d.calculatedAmount, 0);
    const netSalary = grossSalary - totalDeductions;

    const bengaliDate = salaryService.getCurrentBengaliMonth();

    const calculation: SalaryCalculation = {
      id: Date.now().toString(),
      employeeId,
      payPeriod,
      bengaliMonth: bengaliDate.month,
      bengaliYear: bengaliDate.year,
      baseSalary: salaryStructure.baseSalary,
      allowances,
      overtime: overtimeCalculation,
      deductions,
      grossSalary,
      netSalary,
      status: 'calculated',
      calculatedAt: new Date().toISOString(),
      calculatedBy: 'system' // In a real app, this would be the current user
    };

    return calculation;
  },

  calculateOvertime: (attendance: Attendance[], overtimeRate: number): OvertimeCalculation => {
    const regularHoursPerDay = 8;
    const regularHoursPerMonth = 22 * regularHoursPerDay; // Assuming 22 working days

    const totalWorkedHours = attendance.reduce((sum, a) => sum + a.totalHours, 0);
    const overtimeHours = Math.max(0, totalWorkedHours - regularHoursPerMonth);
    const overtimeAmount = overtimeHours * overtimeRate;

    return {
      regularHours: Math.min(totalWorkedHours, regularHoursPerMonth),
      overtimeHours,
      overtimeRate,
      overtimeAmount
    };
  },

  // Salary Calculation CRUD
  saveSalaryCalculation: async (calculation: SalaryCalculation): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.tableCreate(SALARY_CALCULATIONS_TABLE_ID, {
        employee_id: calculation.employeeId,
        pay_period: calculation.payPeriod,
        bengali_month: calculation.bengaliMonth,
        bengali_year: calculation.bengaliYear,
        base_salary: calculation.baseSalary,
        allowances_data: JSON.stringify(calculation.allowances),
        overtime_data: JSON.stringify(calculation.overtime),
        deductions_data: JSON.stringify(calculation.deductions),
        gross_salary: calculation.grossSalary,
        net_salary: calculation.netSalary,
        status: calculation.status,
        calculated_at: calculation.calculatedAt,
        calculated_by: calculation.calculatedBy
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error saving salary calculation:', error);
      throw error;
    }
  },

  getAllSalaryCalculations: async (): Promise<SalaryCalculation[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_CALCULATIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'calculated_at',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        employeeId: record.employee_id || '',
        payPeriod: record.pay_period || '',
        bengaliMonth: record.bengali_month || '',
        bengaliYear: record.bengali_year || '',
        baseSalary: record.base_salary || 0,
        allowances: record.allowances_data ? JSON.parse(record.allowances_data) : [],
        overtime: record.overtime_data ? JSON.parse(record.overtime_data) : { regularHours: 0, overtimeHours: 0, overtimeRate: 0, overtimeAmount: 0 },
        deductions: record.deductions_data ? JSON.parse(record.deductions_data) : [],
        grossSalary: record.gross_salary || 0,
        netSalary: record.net_salary || 0,
        status: record.status || 'calculated',
        calculatedAt: record.calculated_at || new Date().toISOString(),
        calculatedBy: record.calculated_by || 'system'
      })) || [];
    } catch (error) {
      console.error('Error fetching salary calculations:', error);
      return [];
    }
  },

  getSalaryCalculationsByPeriod: async (payPeriod: string): Promise<SalaryCalculation[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_CALCULATIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'calculated_at',
        IsAsc: false,
        Filters: [
        { name: 'pay_period', op: 'Equal', value: payPeriod }]

      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        employeeId: record.employee_id || '',
        payPeriod: record.pay_period || '',
        bengaliMonth: record.bengali_month || '',
        bengaliYear: record.bengali_year || '',
        baseSalary: record.base_salary || 0,
        allowances: record.allowances_data ? JSON.parse(record.allowances_data) : [],
        overtime: record.overtime_data ? JSON.parse(record.overtime_data) : { regularHours: 0, overtimeHours: 0, overtimeRate: 0, overtimeAmount: 0 },
        deductions: record.deductions_data ? JSON.parse(record.deductions_data) : [],
        grossSalary: record.gross_salary || 0,
        netSalary: record.net_salary || 0,
        status: record.status || 'calculated',
        calculatedAt: record.calculated_at || new Date().toISOString(),
        calculatedBy: record.calculated_by || 'system'
      })) || [];
    } catch (error) {
      console.error('Error fetching salary calculations by period:', error);
      return [];
    }
  },

  getSalaryCalculationsByEmployee: async (employeeId: string): Promise<SalaryCalculation[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_CALCULATIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'calculated_at',
        IsAsc: false,
        Filters: [
        { name: 'employee_id', op: 'Equal', value: employeeId }]

      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        employeeId: record.employee_id || '',
        payPeriod: record.pay_period || '',
        bengaliMonth: record.bengali_month || '',
        bengaliYear: record.bengali_year || '',
        baseSalary: record.base_salary || 0,
        allowances: record.allowances_data ? JSON.parse(record.allowances_data) : [],
        overtime: record.overtime_data ? JSON.parse(record.overtime_data) : { regularHours: 0, overtimeHours: 0, overtimeRate: 0, overtimeAmount: 0 },
        deductions: record.deductions_data ? JSON.parse(record.deductions_data) : [],
        grossSalary: record.gross_salary || 0,
        netSalary: record.net_salary || 0,
        status: record.status || 'calculated',
        calculatedAt: record.calculated_at || new Date().toISOString(),
        calculatedBy: record.calculated_by || 'system'
      })) || [];
    } catch (error) {
      console.error('Error fetching salary calculations by employee:', error);
      return [];
    }
  },

  // Advance Management
  getAllAdvances: async (): Promise<Advance[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_ADVANCES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        employeeId: record.employee_id || '',
        amount: record.amount || 0,
        reason: record.reason || '',
        approvalStatus: record.approval_status || 'pending',
        approvedBy: record.approved_by,
        approvedAt: record.approved_at,
        deductionSchedule: record.deduction_schedule ? JSON.parse(record.deduction_schedule) : [],
        remainingBalance: record.remaining_balance || 0,
        isFullyPaid: record.is_fully_paid || false,
        createdAt: record.created_at || new Date().toISOString(),
        updatedAt: record.updated_at || new Date().toISOString()
      })) || [];
    } catch (error) {
      console.error('Error fetching advances:', error);
      return [];
    }
  },

  getAdvancesByEmployee: async (employeeId: string): Promise<Advance[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_ADVANCES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: [
        { name: 'employee_id', op: 'Equal', value: employeeId }]

      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        employeeId: record.employee_id || '',
        amount: record.amount || 0,
        reason: record.reason || '',
        approvalStatus: record.approval_status || 'pending',
        approvedBy: record.approved_by,
        approvedAt: record.approved_at,
        deductionSchedule: record.deduction_schedule ? JSON.parse(record.deduction_schedule) : [],
        remainingBalance: record.remaining_balance || 0,
        isFullyPaid: record.is_fully_paid || false,
        createdAt: record.created_at || new Date().toISOString(),
        updatedAt: record.updated_at || new Date().toISOString()
      })) || [];
    } catch (error) {
      console.error('Error fetching advances by employee:', error);
      return [];
    }
  },

  createAdvance: async (advance: Omit<Advance, 'id' | 'createdAt' | 'updatedAt'>): Promise<Advance> => {
    try {
      const now = new Date().toISOString();

      const { error } = await window.ezsite.apis.tableCreate(SALARY_ADVANCES_TABLE_ID, {
        employee_id: advance.employeeId,
        amount: advance.amount,
        reason: advance.reason,
        approval_status: advance.approvalStatus,
        approved_by: advance.approvedBy,
        approved_at: advance.approvedAt,
        deduction_schedule: JSON.stringify(advance.deductionSchedule),
        remaining_balance: advance.remainingBalance,
        is_fully_paid: advance.isFullyPaid,
        created_at: now,
        updated_at: now
      });

      if (error) throw new Error(error);

      // Fetch the created advance
      const advances = await salaryService.getAdvancesByEmployee(advance.employeeId);
      const newAdvance = advances[0]; // Should be the most recently created

      if (!newAdvance) throw new Error('Failed to create advance');
      return newAdvance;
    } catch (error) {
      console.error('Error creating advance:', error);
      throw error;
    }
  },

  approveAdvance: async (advanceId: string, approvedBy: string): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.tableUpdate(SALARY_ADVANCES_TABLE_ID, {
        ID: parseInt(advanceId),
        approval_status: 'approved',
        approved_by: approvedBy,
        approved_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error approving advance:', error);
      throw error;
    }
  },

  // Payment Records
  createPaymentRecord: async (record: Omit<PaymentRecord, 'id' | 'createdAt'>): Promise<PaymentRecord> => {
    try {
      const { error } = await window.ezsite.apis.tableCreate(SALARY_PAYMENTS_TABLE_ID, {
        employee_id: record.employeeId,
        salary_calculation_id: record.salaryCalculationId,
        pay_period: record.payPeriod,
        gross_amount: record.grossAmount,
        net_amount: record.netAmount,
        payment_date: record.paymentDate,
        payment_method: record.paymentMethod,
        status: record.status,
        reference_number: record.referenceNumber,
        notes: record.notes,
        created_at: new Date().toISOString()
      });

      if (error) throw new Error(error);

      const newRecord: PaymentRecord = {
        ...record,
        id: Date.now().toString(), // This would be the actual DB ID in production
        createdAt: new Date().toISOString()
      };

      return newRecord;
    } catch (error) {
      console.error('Error creating payment record:', error);
      throw error;
    }
  },

  getPaymentRecordsByEmployee: async (employeeId: string): Promise<PaymentRecord[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALARY_PAYMENTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'payment_date',
        IsAsc: false,
        Filters: [
        { name: 'employee_id', op: 'Equal', value: employeeId }]

      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        employeeId: record.employee_id || '',
        salaryCalculationId: record.salary_calculation_id || '',
        payPeriod: record.pay_period || '',
        grossAmount: record.gross_amount || 0,
        netAmount: record.net_amount || 0,
        paymentDate: record.payment_date || '',
        paymentMethod: record.payment_method || 'bank_transfer',
        status: record.status || 'pending',
        referenceNumber: record.reference_number || '',
        notes: record.notes || '',
        createdAt: record.created_at || new Date().toISOString()
      })) || [];
    } catch (error) {
      console.error('Error fetching payment records by employee:', error);
      return [];
    }
  },

  // Bulk Processing - simplified for database implementation
  processBulkSalaries: async (employeeIds: string[], payPeriod: string, processedBy: string): Promise<BulkSalaryProcess> => {
    const bengaliDate = salaryService.getCurrentBengaliMonth();

    const bulkProcess: BulkSalaryProcess = {
      id: Date.now().toString(),
      payPeriod,
      bengaliMonth: bengaliDate.month,
      bengaliYear: bengaliDate.year,
      employeeIds,
      totalEmployees: employeeIds.length,
      processedEmployees: 0,
      failedEmployees: [],
      status: 'processing',
      startedAt: new Date().toISOString(),
      startedBy: processedBy
    };

    // Process each employee
    for (const employeeId of employeeIds) {
      try {
        const calculation = await salaryService.calculateSalary(employeeId, payPeriod);
        await salaryService.saveSalaryCalculation(calculation);
        bulkProcess.processedEmployees++;
      } catch (error) {
        const employee = await employeeService.getEmployeeById(employeeId);
        bulkProcess.failedEmployees.push({
          employeeId,
          employeeName: employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown',
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    bulkProcess.status = bulkProcess.failedEmployees.length === 0 ? 'completed' : 'failed';
    bulkProcess.completedAt = new Date().toISOString();

    return bulkProcess;
  },

  // Generate Salary Slip
  generateSalarySlip: async (employeeId: string, payPeriod: string, generatedBy: string): Promise<SalarySlip> => {
    const employee = await employeeService.getEmployeeById(employeeId);
    if (!employee) {
      throw new Error('Employee not found');
    }

    const calculations = await salaryService.getSalaryCalculationsByEmployee(employeeId);
    const calculation = calculations.find((c) => c.payPeriod === payPeriod);
    if (!calculation) {
      throw new Error('Salary calculation not found for this period');
    }

    const paymentRecords = await salaryService.getPaymentRecordsByEmployee(employeeId);
    const paymentRecord = paymentRecords.find((r) => r.salaryCalculationId === calculation.id);

    const salarySlip: SalarySlip = {
      id: Date.now().toString(),
      employeeId,
      employee: {
        firstName: employee.firstName,
        lastName: employee.lastName,
        employeeCode: employee.id,
        position: employee.position,
        department: employee.department
      },
      salaryCalculation: calculation,
      paymentRecord,
      generatedAt: new Date().toISOString(),
      generatedBy
    };

    return salarySlip;
  },

  // Pay Periods - Generate dynamically for the last 12 months
  getAllPayPeriods: async (): Promise<PayPeriod[]> => {
    const currentDate = new Date();
    const payPeriods: PayPeriod[] = [];

    for (let i = 0; i < 12; i++) {
      const periodDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
      const bengaliDate = salaryService.convertToBengaliDate(periodDate);
      payPeriods.push({
        id: (i + 1).toString(),
        startDate: new Date(periodDate.getFullYear(), periodDate.getMonth(), 1).toISOString().split('T')[0],
        endDate: new Date(periodDate.getFullYear(), periodDate.getMonth() + 1, 0).toISOString().split('T')[0],
        payPeriod: `${periodDate.getFullYear()}-${String(periodDate.getMonth() + 1).padStart(2, '0')}`,
        bengaliMonth: bengaliDate.bengaliMonthName,
        bengaliYear: bengaliDate.bengaliYear.toString(),
        isActive: i === 0,
        paymentDueDate: new Date(periodDate.getFullYear(), periodDate.getMonth() + 1, 5).toISOString().split('T')[0]
      });
    }

    return payPeriods;
  },

  // Statistics
  getSalaryStats: async (): Promise<SalaryStats> => {
    try {
      const calculations = await salaryService.getAllSalaryCalculations();
      const employees = await employeeService.getAllEmployees();

      if (calculations.length === 0) {
        return {
          totalPayroll: 0,
          totalEmployees: 0,
          averageSalary: 0,
          totalOvertime: 0,
          totalAdvances: 0,
          departmentBreakdown: {},
          monthlyTrend: []
        };
      }

      const currentMonth = new Date().toISOString().slice(0, 7);
      const currentMonthCalculations = calculations.filter((c) => c.payPeriod === currentMonth);

      const totalPayroll = currentMonthCalculations.reduce((sum, c) => sum + c.netSalary, 0);
      const totalOvertime = currentMonthCalculations.reduce((sum, c) => sum + c.overtime.overtimeAmount, 0);

      const departmentBreakdown = employees.reduce((acc, emp) => {
        const empCalculations = currentMonthCalculations.filter((c) => c.employeeId === emp.id);
        const totalSalary = empCalculations.reduce((sum, c) => sum + c.netSalary, 0);
        acc[emp.department] = (acc[emp.department] || 0) + totalSalary;
        return acc;
      }, {} as {[key: string]: number;});

      // Calculate monthly trend for the last 6 months
      const monthlyTrend = [];
      for (let i = 0; i < 6; i++) {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        const period = date.toISOString().slice(0, 7);

        const periodCalculations = calculations.filter((c) => c.payPeriod === period);
        const periodPayroll = periodCalculations.reduce((sum, c) => sum + c.netSalary, 0);
        const periodAverage = periodCalculations.length > 0 ? periodPayroll / periodCalculations.length : 0;

        monthlyTrend.unshift({
          month: period,
          totalPayroll: periodPayroll,
          totalEmployees: periodCalculations.length,
          averageSalary: periodAverage
        });
      }

      const advances = await salaryService.getAllAdvances();
      const totalAdvances = advances.
      filter((a) => a.approvalStatus === 'approved' && !a.isFullyPaid).
      reduce((sum, a) => sum + a.remainingBalance, 0);

      return {
        totalPayroll,
        totalEmployees: currentMonthCalculations.length,
        averageSalary: currentMonthCalculations.length > 0 ? totalPayroll / currentMonthCalculations.length : 0,
        totalOvertime,
        totalAdvances,
        departmentBreakdown,
        monthlyTrend
      };
    } catch (error) {
      console.error('Error getting salary stats:', error);
      return {
        totalPayroll: 0,
        totalEmployees: 0,
        averageSalary: 0,
        totalOvertime: 0,
        totalAdvances: 0,
        departmentBreakdown: {},
        monthlyTrend: []
      };
    }
  }
};