import { Supplier, SupplierOrder } from '@/types/supplier';

// Database service for supplier management
const SUPPLIERS_TABLE_ID = 38564; // Updated with real table ID

export const supplierService = {
  // Supplier CRUD operations
  getAllSuppliers: async (): Promise<Supplier[]> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SUPPLIERS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        name: record.name || '',
        contactPerson: record.contact_person || '',
        email: record.email || '',
        phone: record.phone || '',
        address: record.address || '',
        paymentTerms: record.payment_terms || '',
        status: record.status || 'active',
        createdAt: new Date(record.created_at || Date.now()),
        updatedAt: new Date(record.updated_at || Date.now())
      })) || [];
    } catch (error) {
      console.error('Error fetching suppliers:', error);
      return [];
    }
  },

  getSupplierById: async (id: string): Promise<Supplier | null> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SUPPLIERS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'id',
          op: 'Equal',
          value: parseInt(id)
        }]

      });

      if (error) throw new Error(error);

      const record = data?.List?.[0];
      if (!record) return null;

      return {
        id: record.id?.toString() || '',
        name: record.name || '',
        contactPerson: record.contact_person || '',
        email: record.email || '',
        phone: record.phone || '',
        address: record.address || '',
        paymentTerms: record.payment_terms || '',
        status: record.status || 'active',
        createdAt: new Date(record.created_at || Date.now()),
        updatedAt: new Date(record.updated_at || Date.now())
      };
    } catch (error) {
      console.error('Error fetching supplier:', error);
      return null;
    }
  },

  createSupplier: async (supplierData: Omit<Supplier, 'id' | 'createdAt' | 'updatedAt'>): Promise<Supplier> => {
    try {
      const now = new Date().toISOString();

      const { error } = await window.ezsite.apis.tableCreate(SUPPLIERS_TABLE_ID, {
        name: supplierData.name,
        contact_person: supplierData.contactPerson,
        email: supplierData.email,
        phone: supplierData.phone,
        address: supplierData.address,
        payment_terms: supplierData.paymentTerms,
        status: supplierData.status,
        created_at: now,
        updated_at: now
      });

      if (error) throw new Error(error);

      // Fetch the created supplier
      const suppliers = await supplierService.getAllSuppliers();
      const newSupplier = suppliers.find((s) => s.email === supplierData.email);
      if (!newSupplier) throw new Error('Failed to create supplier');

      return newSupplier;
    } catch (error) {
      console.error('Error creating supplier:', error);
      throw error;
    }
  },

  updateSupplier: async (id: string, supplierData: Partial<Supplier>): Promise<Supplier> => {
    try {
      const updateData: any = {
        id: parseInt(id),
        updated_at: new Date().toISOString()
      };

      // Map the updates to database field names
      if (supplierData.name !== undefined) updateData.name = supplierData.name;
      if (supplierData.contactPerson !== undefined) updateData.contact_person = supplierData.contactPerson;
      if (supplierData.email !== undefined) updateData.email = supplierData.email;
      if (supplierData.phone !== undefined) updateData.phone = supplierData.phone;
      if (supplierData.address !== undefined) updateData.address = supplierData.address;
      if (supplierData.paymentTerms !== undefined) updateData.payment_terms = supplierData.paymentTerms;
      if (supplierData.status !== undefined) updateData.status = supplierData.status;

      const { error } = await window.ezsite.apis.tableUpdate(SUPPLIERS_TABLE_ID, updateData);

      if (error) throw new Error(error);

      // Fetch the updated supplier
      const updatedSupplier = await supplierService.getSupplierById(id);
      if (!updatedSupplier) throw new Error('Supplier not found');

      return updatedSupplier;
    } catch (error) {
      console.error('Error updating supplier:', error);
      throw error;
    }
  },

  deleteSupplier: async (id: string): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.tableDelete(SUPPLIERS_TABLE_ID, {
        id: parseInt(id)
      });

      if (error) throw new Error(error);
    } catch (error) {
      console.error('Error deleting supplier:', error);
      throw error;
    }
  },

  // Supplier orders - currently not implemented with real database
  // Would need additional tables for order management
  getSupplierOrders: async (supplierId?: string): Promise<SupplierOrder[]> => {
    // TODO: Implement with real database table
    console.warn('Supplier orders not implemented with real database yet');
    return [];
  },

  createSupplierOrder: async (orderData: Omit<SupplierOrder, 'id' | 'orderNumber'>): Promise<SupplierOrder> => {
    // TODO: Implement with real database table
    throw new Error('Supplier order creation not implemented with real database yet');
  }
};