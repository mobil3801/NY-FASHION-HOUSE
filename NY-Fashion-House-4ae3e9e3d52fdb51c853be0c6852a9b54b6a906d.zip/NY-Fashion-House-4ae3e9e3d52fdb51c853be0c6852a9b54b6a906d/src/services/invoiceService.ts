import { Invoice, InvoiceItem, InvoicePayment, InvoiceTemplate, InvoiceFilters, InvoiceStats } from '@/types/invoice';
import { PaymentRecord } from '@/types/payment';
import { Sale } from '@/types/sales';

// Database service for invoice management
const INVOICES_TABLE_ID = 38565; // Updated with real table ID
let invoiceCounter = 1;

// Default template for the company
const defaultTemplate: InvoiceTemplate = {
  id: '1',
  name: 'Default Template',
  isDefault: true,
  companyName: 'Your Company Name',
  companyAddress: '123 Business Street, City, Country',
  companyPhone: '+1 234-567-8900',
  companyEmail: 'info@company.com',
  companyWebsite: 'www.company.com',
  taxId: 'TAX ID: 123456789',
  primaryColor: '#1f2937',
  secondaryColor: '#6b7280',
  fontFamily: 'Inter',
  includeItemDescription: true,
  includeItemSku: true,
  includeDiscounts: true,
  includeTax: true,
  defaultTerms: 'Payment is due within 30 days of invoice date. Late payments may be subject to 1.5% monthly service charge.',
  defaultFooter: 'Thank you for your business!',
  defaultDueDays: 30
};

export const invoiceService = {
  // Create invoice from sale
  createInvoiceFromSale: async (sale: Sale, customTemplate?: Partial<InvoiceTemplate>): Promise<Invoice> => {
    const template = { ...defaultTemplate, ...customTemplate };
    const invoiceNumber = `INV-${new Date().getFullYear()}-${String(invoiceCounter++).padStart(4, '0')}`;

    const items: InvoiceItem[] = sale.items.map((item) => ({
      id: item.id,
      productId: item.productId,
      productName: item.productName,
      productSku: item.productSku,
      description: `${item.productName}${item.size ? ` - Size: ${item.size}` : ''}${item.color ? ` - Color: ${item.color}` : ''}`,
      quantity: item.quantity,
      unitPrice: item.sellingPrice,
      discount: item.discount,
      total: item.total,
      size: item.size,
      color: item.color
    }));

    const invoiceData = {
      invoice_number: invoiceNumber,
      customer_id: sale.customerId || 'walk-in-customer',
      customer_name: sale.customerName || 'Walk-in Customer',
      customer_phone: sale.customerPhone,
      issue_date: new Date().toISOString(),
      due_date: new Date(Date.now() + template.defaultDueDays * 24 * 60 * 60 * 1000).toISOString(),
      subtotal: sale.subtotal,
      discount_amount: sale.discountAmount,
      tax_amount: sale.taxAmount,
      total_amount: sale.totalAmount,
      status: 'sent',
      paid_amount: sale.status === 'completed' ? sale.totalAmount : 0,
      remaining_amount: sale.status === 'completed' ? 0 : sale.totalAmount,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    try {
      const { error } = await window.ezsite.apis.tableCreate(INVOICES_TABLE_ID, invoiceData);
      if (error) throw new Error(error);

      // Return the created invoice object
      const invoice: Invoice = {
        id: Date.now().toString(), // This would be replaced with actual DB ID
        invoiceNumber,
        saleId: sale.id,
        customerId: sale.customerId || 'walk-in-customer',
        customerName: sale.customerName || 'Walk-in Customer',
        customerPhone: sale.customerPhone,
        issueDate: new Date(),
        dueDate: new Date(Date.now() + template.defaultDueDays * 24 * 60 * 60 * 1000),
        items,
        subtotal: sale.subtotal,
        discountAmount: sale.discountAmount,
        discountPercentage: sale.discountPercentage,
        taxAmount: sale.taxAmount,
        taxPercentage: sale.taxPercentage,
        totalAmount: sale.totalAmount,
        status: 'sent',
        paidAmount: sale.status === 'completed' ? sale.totalAmount : 0,
        remainingAmount: sale.status === 'completed' ? 0 : sale.totalAmount,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: sale.cashierId,
        terms: template.defaultTerms,
        footerText: template.defaultFooter
      };

      return invoice;
    } catch (error) {
      console.error('Error creating invoice:', error);
      throw error;
    }
  },

  // Get all invoices with filtering
  getAllInvoices: async (filters?: InvoiceFilters): Promise<Invoice[]> => {
    try {
      // Check if API is available
      if (!window.ezsite?.apis?.tablePage) {
        console.warn('Database API not available for invoices');
        return [];
      }

      const queryFilters = [];

      if (filters?.status) {
        queryFilters.push({
          name: 'status',
          op: 'Equal',
          value: filters.status
        });
      }

      if (filters?.startDate) {
        queryFilters.push({
          name: 'issue_date',
          op: 'GreaterThanOrEqual',
          value: filters.startDate.toISOString()
        });
      }

      if (filters?.endDate) {
        queryFilters.push({
          name: 'issue_date',
          op: 'LessThanOrEqual',
          value: filters.endDate.toISOString()
        });
      }

      const { data, error } = await window.ezsite.apis.tablePage(INVOICES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: queryFilters
      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        invoiceNumber: record.invoice_number || '',
        saleId: '', // Not stored in current schema
        customerId: record.customer_id || '',
        customerName: record.customer_name || '',
        customerPhone: record.customer_phone,
        issueDate: new Date(record.issue_date || Date.now()),
        dueDate: new Date(record.due_date || Date.now()),
        items: [], // Would need separate table for invoice items
        subtotal: record.subtotal || 0,
        discountAmount: record.discount_amount || 0,
        discountPercentage: 0, // Would need to calculate
        taxAmount: record.tax_amount || 0,
        taxPercentage: 0, // Would need to calculate
        totalAmount: record.total_amount || 0,
        status: record.status || 'draft',
        paidAmount: record.paid_amount || 0,
        remainingAmount: record.remaining_amount || 0,
        createdAt: new Date(record.created_at || Date.now()),
        updatedAt: new Date(record.updated_at || Date.now()),
        createdBy: '', // Not stored in current schema
        terms: defaultTemplate.defaultTerms,
        footerText: defaultTemplate.defaultFooter
      })) || [];
    } catch (error) {
      console.error('Error fetching invoices:', error);
      return [];
    }
  },

  // Get invoice by ID
  getInvoiceById: async (id: string): Promise<Invoice | null> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(INVOICES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'id',
          op: 'Equal',
          value: parseInt(id)
        }]

      });

      if (error) throw new Error(error);

      const record = data?.List?.[0];
      if (!record) return null;

      return {
        id: record.id?.toString() || '',
        invoiceNumber: record.invoice_number || '',
        saleId: '',
        customerId: record.customer_id || '',
        customerName: record.customer_name || '',
        customerPhone: record.customer_phone,
        issueDate: new Date(record.issue_date || Date.now()),
        dueDate: new Date(record.due_date || Date.now()),
        items: [], // Would need separate table for invoice items
        subtotal: record.subtotal || 0,
        discountAmount: record.discount_amount || 0,
        discountPercentage: 0,
        taxAmount: record.tax_amount || 0,
        taxPercentage: 0,
        totalAmount: record.total_amount || 0,
        status: record.status || 'draft',
        paidAmount: record.paid_amount || 0,
        remainingAmount: record.remaining_amount || 0,
        createdAt: new Date(record.created_at || Date.now()),
        updatedAt: new Date(record.updated_at || Date.now()),
        createdBy: '',
        terms: defaultTemplate.defaultTerms,
        footerText: defaultTemplate.defaultFooter
      };
    } catch (error) {
      console.error('Error fetching invoice:', error);
      return null;
    }
  },

  // Update invoice
  updateInvoice: async (id: string, updates: Partial<Invoice>): Promise<Invoice> => {
    try {
      const updateData: any = {
        ID: parseInt(id),
        updated_at: new Date().toISOString()
      };

      // Map updates to database field names
      if (updates.status !== undefined) updateData.status = updates.status;
      if (updates.paidAmount !== undefined) updateData.paid_amount = updates.paidAmount;
      if (updates.remainingAmount !== undefined) updateData.remaining_amount = updates.remainingAmount;
      if (updates.dueDate !== undefined) updateData.due_date = updates.dueDate.toISOString();

      const { error } = await window.ezsite.apis.tableUpdate(INVOICES_TABLE_ID, updateData);
      if (error) throw new Error(error);

      // Fetch the updated invoice
      const updatedInvoice = await invoiceService.getInvoiceById(id);
      if (!updatedInvoice) throw new Error('Invoice not found');

      return updatedInvoice;
    } catch (error) {
      console.error('Error updating invoice:', error);
      throw error;
    }
  },

  // Record payment (would need separate payments table)
  recordPayment: async (payment: Omit<InvoicePayment, 'id' | 'recordedAt'>): Promise<InvoicePayment> => {
    // TODO: Implement with real payments table
    throw new Error('Payment recording not implemented with real database yet');
  },

  // Get payments for an invoice (would need separate payments table)
  getInvoicePayments: async (invoiceId: string): Promise<InvoicePayment[]> => {
    // TODO: Implement with real payments table
    return [];
  },

  // Get invoice statistics
  getInvoiceStats: async (): Promise<InvoiceStats> => {
    try {
      // Check if API is available
      if (!window.ezsite?.apis?.tablePage) {
        console.warn('Database API not available for invoice stats');
        return {
          totalInvoices: 0,
          totalAmount: 0,
          paidAmount: 0,
          pendingAmount: 0,
          overdueAmount: 0,
          draftCount: 0,
          paidCount: 0,
          overdueCount: 0,
          pendingCount: 0
        };
      }

      const { data, error } = await window.ezsite.apis.tablePage(INVOICES_TABLE_ID, {
        PageNo: 1,
        PageSize: 10000,
        Filters: []
      });

      if (error) {
        console.warn('Invoice stats fetch failed:', error);
        throw new Error(error);
      }

      const invoices = data?.List || [];

      const totalInvoices = invoices.length;
      const totalAmount = invoices.reduce((sum: number, inv: any) => sum + (inv.total_amount || 0), 0);
      const paidAmount = invoices.reduce((sum: number, inv: any) => sum + (inv.paid_amount || 0), 0);
      const pendingAmount = invoices.reduce((sum: number, inv: any) => {
        const remaining = inv.remaining_amount || 0;
        return sum + (remaining > 0 ? remaining : 0);
      }, 0);

      // Calculate overdue amount
      const now = new Date();
      const overdueAmount = invoices.reduce((sum: number, inv: any) => {
        const dueDate = new Date(inv.due_date || Date.now());
        const remaining = inv.remaining_amount || 0;
        return sum + (dueDate < now && remaining > 0 ? remaining : 0);
      }, 0);

      const statusCounts = invoices.reduce((counts: any, inv: any) => {
        const status = inv.status || 'draft';
        counts[status] = (counts[status] || 0) + 1;
        return counts;
      }, {});

      return {
        totalInvoices,
        totalAmount,
        paidAmount,
        pendingAmount,
        overdueAmount,
        draftCount: statusCounts.draft || 0,
        paidCount: statusCounts.paid || 0,
        overdueCount: statusCounts.overdue || 0,
        pendingCount: statusCounts.pending || 0
      };
    } catch (error) {
      console.error('Error getting invoice stats:', error);
      return {
        totalInvoices: 0,
        totalAmount: 0,
        paidAmount: 0,
        pendingAmount: 0,
        overdueAmount: 0,
        draftCount: 0,
        paidCount: 0,
        overdueCount: 0,
        pendingCount: 0
      };
    }
  },

  // Delete invoice
  deleteInvoice: async (id: string): Promise<boolean> => {
    try {
      const { error } = await window.ezsite.apis.tableDelete(INVOICES_TABLE_ID, {
        ID: parseInt(id)
      });

      if (error) throw new Error(error);
      return true;
    } catch (error) {
      console.error('Error deleting invoice:', error);
      return false;
    }
  },

  // Get default template
  getDefaultTemplate: (): InvoiceTemplate => defaultTemplate,

  // Calculate invoice totals
  calculateInvoiceTotals: (items: InvoiceItem[], discountPercentage: number = 0, taxPercentage: number = 15) => {
    const subtotal = items.reduce((sum, item) => sum + (item.unitPrice * item.quantity - item.discount), 0);
    const discountAmount = subtotal * discountPercentage / 100;
    const taxableAmount = subtotal - discountAmount;
    const taxAmount = taxableAmount * taxPercentage / 100;
    const totalAmount = taxableAmount + taxAmount;

    return {
      subtotal,
      discountAmount,
      taxAmount,
      totalAmount
    };
  }
};