// Comprehensive Error Tracking Service - Centralized error management system
import { enhancedErrorLoggingService, ErrorDetails } from '@/services/enhancedErrorLoggingService';
import { enhancedDevToolsErrorService, EnhancedErrorReport } from '@/services/enhancedDevToolsErrorService';
import { errorLoggingService } from '@/services/errorLoggingService';
import { ErrorContext } from '@/types/errorTypes';
import { toast } from 'sonner';

export interface ErrorTrackingConfig {
  enableDevTools: boolean;
  enableToastNotifications: boolean;
  enableConsoleLogging: boolean;
  enableLocalStorage: boolean;
  maxStoredErrors: number;
  autoRetryEnabled: boolean;
  maxRetryAttempts: number;
}

export interface ComprehensiveErrorReport {
  id: string;
  timestamp: string;

  // Error information
  error: Error;
  message: string;
  stack?: string;

  // Context
  context: ErrorContext;

  // Classification
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;

  // Analysis
  rootCause: string;
  recommendations: string[];
  isRecoverable: boolean;

  // Enhanced details (if DevTools is enabled)
  enhancedReport?: EnhancedErrorReport;

  // User experience
  userFriendlyMessage: string;
  displayTitle: string;

  // Status
  resolved: boolean;
  retryCount: number;

  // DevTools integration
  devToolsDetails?: any;
  componentTrace?: string[];
  errorLocation?: string;
}

export interface ErrorStatistics {
  totalErrors: number;
  recentErrors: number;
  errorsBySeverity: Record<string, number>;
  errorsByCategory: Record<string, number>;
  resolvedErrors: number;
  averageResolutionTime: number;
  topErrors: Array<{
    message: string;
    count: number;
    lastOccurred: string;
  }>;
}

class ComprehensiveErrorTrackingService {
  private config: ErrorTrackingConfig = {
    enableDevTools: process.env.NODE_ENV === 'development',
    enableToastNotifications: true,
    enableConsoleLogging: true,
    enableLocalStorage: true,
    maxStoredErrors: 200,
    autoRetryEnabled: true,
    maxRetryAttempts: 3
  };

  private errorReports: ComprehensiveErrorReport[] = [];
  private sessionId: string;
  private errorFrequency: Map<string, number> = new Map();

  constructor() {
    this.sessionId = this.generateSessionId();
    this.initializeErrorTracking();
    this.loadPersistedErrors();
  }

  private generateSessionId(): string {
    return `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private initializeErrorTracking(): void {
    // Setup comprehensive global error handling
    window.addEventListener('error', this.handleGlobalError.bind(this));
    window.addEventListener('unhandledrejection', this.handleUnhandledRejection.bind(this));

    // Monitor for React errors
    this.setupReactErrorMonitoring();

    // Setup periodic cleanup
    setInterval(this.performMaintenance.bind(this), 300000); // Every 5 minutes

    console.log('[COMPREHENSIVE ERROR TRACKING] Initialized');
  }

  private setupReactErrorMonitoring(): void {
    // Override console.error to catch React warnings that might indicate issues
    const originalError = console.error;
    console.error = (...args) => {
      const message = args.join(' ');

      // Check for React-specific warnings
      if (message.includes('Warning:') && message.includes('React')) {
        this.logError(new Error(message), {
          category: 'client',
          severity: 'medium',
          action: 'React Warning',
          additionalData: {
            reactWarning: true,
            consoleArgs: args
          }
        });
      }

      originalError.apply(console, args);
    };
  }

  private async handleGlobalError(event: ErrorEvent): Promise<void> {
    if (event.target !== window || !event.error) return;

    await this.logError(event.error, {
      category: 'client',
      severity: 'high',
      action: 'Uncaught JavaScript Error',
      additionalData: {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno
      }
    });
  }

  private async handleUnhandledRejection(event: PromiseRejectionEvent): Promise<void> {
    const error = event.reason instanceof Error ?
    event.reason :
    new Error(String(event.reason));

    await this.logError(error, {
      category: 'client',
      severity: 'high',
      action: 'Unhandled Promise Rejection',
      additionalData: {
        promiseRejection: true,
        reason: event.reason
      }
    });

    event.preventDefault();
  }

  public async logError(
  error: Error | string,
  context: ErrorContext = {})
  : Promise<string> {
    const errorObj = typeof error === 'string' ? new Error(error) : error;
    const reportId = this.generateErrorId();

    // Track error frequency
    const errorKey = `${errorObj.name}:${errorObj.message}`;
    this.errorFrequency.set(errorKey, (this.errorFrequency.get(errorKey) || 0) + 1);

    // Create comprehensive error report
    const report: ComprehensiveErrorReport = {
      id: reportId,
      timestamp: new Date().toISOString(),

      error: errorObj,
      message: errorObj.message,
      stack: errorObj.stack,

      context: {
        sessionId: this.sessionId,
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString(),
        ...context
      },

      severity: this.determineSeverity(errorObj, context),
      category: context.category || this.determineCategory(errorObj),

      rootCause: this.analyzeRootCause(errorObj, context),
      recommendations: this.generateRecommendations(errorObj, context),
      isRecoverable: this.determineRecoverability(errorObj, context),

      userFriendlyMessage: this.generateUserFriendlyMessage(errorObj, context),
      displayTitle: this.generateDisplayTitle(errorObj, context),

      resolved: false,
      retryCount: 0
    };

    // Use enhanced DevTools error service if enabled
    if (this.config.enableDevTools) {
      try {
        const enhancedReport = await enhancedDevToolsErrorService.logEnhancedError(errorObj, context);
        report.enhancedReport = enhancedReport;
        report.devToolsDetails = enhancedReport.devToolsDetails;
        report.componentTrace = enhancedReport.componentContext;
        report.errorLocation = enhancedReport.errorLocation;
      } catch (devToolsError) {
        console.warn('[ERROR TRACKING] DevTools integration failed:', devToolsError);
      }
    }

    // Store the error report
    this.errorReports.unshift(report);
    this.limitStoredErrors();

    // Log to different services
    enhancedErrorLoggingService.logError(errorObj, context);
    errorLoggingService.logError(errorObj, context);

    // Console logging
    if (this.config.enableConsoleLogging) {
      this.logToConsole(report);
    }

    // Toast notification for user
    if (this.config.enableToastNotifications) {
      this.showUserNotification(report);
    }

    // Persist to localStorage
    if (this.config.enableLocalStorage) {
      this.persistErrors();
    }

    return reportId;
  }

  private generateErrorId(): string {
    return `cet-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private determineSeverity(error: Error, context: ErrorContext): 'low' | 'medium' | 'high' | 'critical' {
    if (context.severity) return context.severity;

    const message = error.message.toLowerCase();

    // Critical errors
    if (
    message.includes('uncaught') ||
    message.includes('script error') ||
    context.category === 'authentication')
    {
      return 'critical';
    }

    // High severity
    if (
    message.includes('network') ||
    message.includes('failed to fetch') ||
    message.includes('database') ||
    context.category === 'server')
    {
      return 'high';
    }

    // Medium severity
    if (
    message.includes('validation') ||
    message.includes('invalid') ||
    context.category === 'validation')
    {
      return 'medium';
    }

    return 'low';
  }

  private determineCategory(error: Error): string {
    const message = error.message.toLowerCase();

    if (message.includes('network') || message.includes('fetch')) return 'network';
    if (message.includes('validation') || message.includes('invalid')) return 'validation';
    if (message.includes('unauthorized') || message.includes('forbidden')) return 'authentication';
    if (message.includes('database') || message.includes('sql')) return 'server';

    return 'client';
  }

  private analyzeRootCause(error: Error, context: ErrorContext): string {
    const message = error.message.toLowerCase();

    if (message.includes('failed to fetch')) {
      return 'Network connectivity or server unavailability';
    }

    if (message.includes('database')) {
      return 'Database operation or data integrity issue';
    }

    if (message.includes('validation')) {
      return 'Data validation or input format issue';
    }

    if (message.includes('unauthorized')) {
      return 'Authentication or session expiry issue';
    }

    if (context.component) {
      return `Application logic error in ${context.component}`;
    }

    return 'Unexpected application error';
  }

  private generateRecommendations(error: Error, context: ErrorContext): string[] {
    const message = error.message.toLowerCase();
    const recommendations: string[] = [];

    if (message.includes('network') || message.includes('fetch')) {
      recommendations.push('Check internet connection');
      recommendations.push('Verify server availability');
      recommendations.push('Try refreshing the page');
    }

    if (message.includes('validation') || message.includes('invalid')) {
      recommendations.push('Review input data format');
      recommendations.push('Check required fields');
      recommendations.push('Verify data constraints');
    }

    if (message.includes('unauthorized') || message.includes('forbidden')) {
      recommendations.push('Log in again');
      recommendations.push('Check user permissions');
      recommendations.push('Clear browser cache');
    }

    if (recommendations.length === 0) {
      recommendations.push('Refresh the page');
      recommendations.push('Try again in a few moments');
      recommendations.push('Contact support if issue persists');
    }

    return recommendations;
  }

  private determineRecoverability(error: Error, context: ErrorContext): boolean {
    const message = error.message.toLowerCase();

    // Non-recoverable errors
    if (
    message.includes('permission') ||
    message.includes('forbidden') ||
    message.includes('not found'))
    {
      return false;
    }

    return true;
  }

  private generateUserFriendlyMessage(error: Error, context: ErrorContext): string {
    const message = error.message.toLowerCase();

    if (message.includes('network') || message.includes('fetch')) {
      return 'Unable to connect to the server. Please check your connection and try again.';
    }

    if (message.includes('validation') || message.includes('invalid')) {
      return 'Please check your input and try again.';
    }

    if (message.includes('unauthorized')) {
      return 'Your session has expired. Please log in again.';
    }

    if (message.includes('database')) {
      return 'We are experiencing technical difficulties. Please try again shortly.';
    }

    return 'An unexpected error occurred. We have been notified and are investigating.';
  }

  private generateDisplayTitle(error: Error, context: ErrorContext): string {
    if (context.title) return context.title;

    const severity = this.determineSeverity(error, context);

    switch (severity) {
      case 'critical':return 'Critical System Error';
      case 'high':return 'Application Error';
      case 'medium':return 'Processing Error';
      default:return 'Minor Issue';
    }
  }

  private logToConsole(report: ComprehensiveErrorReport): void {
    const style = this.getConsoleStyle(report.severity);

    console.group(`🔥 [${report.id}] ${report.displayTitle}`);
    console.log(`%c${report.message}`, style);
    console.log('Severity:', report.severity);
    console.log('Category:', report.category);
    console.log('Root Cause:', report.rootCause);
    console.log('Context:', report.context);

    if (report.componentTrace?.length) {
      console.log('Component Trace:', report.componentTrace.join(' → '));
    }

    if (report.recommendations.length) {
      console.log('Recommendations:', report.recommendations);
    }

    if (report.stack) {
      console.log('Stack Trace:', report.stack);
    }

    console.groupEnd();
  }

  private getConsoleStyle(severity: string): string {
    switch (severity) {
      case 'critical':return 'color: #ff0000; font-weight: bold; font-size: 14px;';
      case 'high':return 'color: #ff6600; font-weight: bold;';
      case 'medium':return 'color: #ffaa00;';
      default:return 'color: #666666;';
    }
  }

  private showUserNotification(report: ComprehensiveErrorReport): void {
    const shouldShowToast =
    report.severity !== 'low' &&
    !report.message.includes('warning');

    if (shouldShowToast) {
      toast.error(report.displayTitle, {
        description: report.userFriendlyMessage,
        duration: report.severity === 'critical' ? 10000 : 5000,
        action: report.isRecoverable ? {
          label: 'Retry',
          onClick: () => this.retryOperation(report.id)
        } : undefined
      });
    }
  }

  private limitStoredErrors(): void {
    if (this.errorReports.length > this.config.maxStoredErrors) {
      this.errorReports = this.errorReports.slice(0, this.config.maxStoredErrors);
    }
  }

  private persistErrors(): void {
    try {
      const reportsToStore = this.errorReports.slice(0, 50); // Store only recent 50 errors
      localStorage.setItem('comprehensive_error_reports', JSON.stringify(reportsToStore));
    } catch (e) {
      console.warn('[ERROR TRACKING] Failed to persist errors:', e);
    }
  }

  private loadPersistedErrors(): void {
    try {
      const stored = localStorage.getItem('comprehensive_error_reports');
      if (stored) {
        const persistedReports: ComprehensiveErrorReport[] = JSON.parse(stored);
        this.errorReports = persistedReports.concat(this.errorReports);
      }
    } catch (e) {
      console.warn('[ERROR TRACKING] Failed to load persisted errors:', e);
    }
  }

  private performMaintenance(): void {
    // Clean up old resolved errors
    const cutoffTime = Date.now() - 24 * 60 * 60 * 1000; // 24 hours ago
    this.errorReports = this.errorReports.filter((report) =>
    !report.resolved || new Date(report.timestamp).getTime() > cutoffTime
    );

    // Update frequency tracking
    const activeErrors = new Set(this.errorReports.map((r) => `${r.error.name}:${r.message}`));
    for (const [key] of this.errorFrequency) {
      if (!activeErrors.has(key)) {
        this.errorFrequency.delete(key);
      }
    }

    // Persist after cleanup
    if (this.config.enableLocalStorage) {
      this.persistErrors();
    }
  }

  // Public API methods
  public getErrorReports(): ComprehensiveErrorReport[] {
    return [...this.errorReports];
  }

  public getErrorReport(id: string): ComprehensiveErrorReport | null {
    return this.errorReports.find((report) => report.id === id) || null;
  }

  public resolveError(id: string): boolean {
    const report = this.getErrorReport(id);
    if (report) {
      report.resolved = true;
      this.persistErrors();
      return true;
    }
    return false;
  }

  public async retryOperation(errorId: string): Promise<boolean> {
    const report = this.getErrorReport(errorId);
    if (!report || !report.isRecoverable) {
      return false;
    }

    report.retryCount++;

    // You can implement specific retry logic here based on the error context
    // For now, just mark as resolved if retry count is reasonable
    if (report.retryCount >= this.config.maxRetryAttempts) {
      toast.error('Maximum retry attempts reached', {
        description: 'Please contact support for assistance.'
      });
      return false;
    }

    toast.success('Retrying operation...');
    return true;
  }

  public getStatistics(): ErrorStatistics {
    const now = Date.now();
    const oneHourAgo = now - 60 * 60 * 1000;

    const recentErrors = this.errorReports.filter(
      (report) => new Date(report.timestamp).getTime() > oneHourAgo
    );

    const errorsByCategory: Record<string, number> = {};
    const errorsBySeverity: Record<string, number> = {};

    this.errorReports.forEach((report) => {
      errorsByCategory[report.category] = (errorsByCategory[report.category] || 0) + 1;
      errorsBySeverity[report.severity] = (errorsBySeverity[report.severity] || 0) + 1;
    });

    // Calculate top errors
    const errorCounts = new Map<string, {count: number;lastOccurred: string;}>();
    this.errorReports.forEach((report) => {
      const key = report.message;
      const existing = errorCounts.get(key);
      if (existing) {
        existing.count++;
        if (new Date(report.timestamp) > new Date(existing.lastOccurred)) {
          existing.lastOccurred = report.timestamp;
        }
      } else {
        errorCounts.set(key, { count: 1, lastOccurred: report.timestamp });
      }
    });

    const topErrors = Array.from(errorCounts.entries()).
    map(([message, data]) => ({ message, ...data })).
    sort((a, b) => b.count - a.count).
    slice(0, 5);

    return {
      totalErrors: this.errorReports.length,
      recentErrors: recentErrors.length,
      errorsByCategory,
      errorsBySeverity,
      resolvedErrors: this.errorReports.filter((r) => r.resolved).length,
      averageResolutionTime: 0, // TODO: Implement resolution time tracking
      topErrors
    };
  }

  public clearAllErrors(): void {
    this.errorReports = [];
    this.errorFrequency.clear();
    localStorage.removeItem('comprehensive_error_reports');
    enhancedErrorLoggingService.clearErrorQueue();
    enhancedDevToolsErrorService.clearErrorReports();
  }

  public exportErrorReports(): string {
    return JSON.stringify({
      sessionId: this.sessionId,
      timestamp: new Date().toISOString(),
      reports: this.errorReports,
      statistics: this.getStatistics(),
      config: this.config
    }, null, 2);
  }

  public updateConfig(newConfig: Partial<ErrorTrackingConfig>): void {
    this.config = { ...this.config, ...newConfig };
    console.log('[ERROR TRACKING] Configuration updated:', this.config);
  }

  // Integration methods for existing error boundaries
  public createErrorBoundaryHandler(component: string, level: string) {
    return async (error: Error, errorInfo: React.ErrorInfo) => {
      await this.logError(error, {
        category: 'client',
        severity: level === 'root' ? 'critical' : 'high',
        component,
        action: 'React Component Error',
        componentStack: errorInfo.componentStack,
        additionalData: {
          errorBoundaryLevel: level,
          reactErrorInfo: errorInfo
        }
      });
    };
  }

  // API error handler integration
  public createApiErrorHandler(endpoint: string, method: string = 'GET') {
    return async (error: any, requestData?: any) => {
      await this.logError(error, {
        category: 'network',
        severity: error.status >= 500 ? 'high' : 'medium',
        action: `${method} ${endpoint}`,
        operation: 'API Request',
        requestDetails: {
          url: endpoint,
          method,
          body: requestData
        },
        additionalData: {
          statusCode: error.status,
          statusText: error.statusText,
          responseData: error.data
        }
      });
    };
  }
}

// Create singleton instance
export const comprehensiveErrorTrackingService = new ComprehensiveErrorTrackingService();

// Export convenience functions
export const logError = comprehensiveErrorTrackingService.logError.bind(comprehensiveErrorTrackingService);
export const getErrorStatistics = comprehensiveErrorTrackingService.getStatistics.bind(comprehensiveErrorTrackingService);
export const createErrorBoundaryHandler = comprehensiveErrorTrackingService.createErrorBoundaryHandler.bind(comprehensiveErrorTrackingService);
export const createApiErrorHandler = comprehensiveErrorTrackingService.createApiErrorHandler.bind(comprehensiveErrorTrackingService);