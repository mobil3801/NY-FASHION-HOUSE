
// Service for seeding test data for POS system validation
import { productService } from './productService';

interface SeedDataResult {
  success: boolean;
  message: string;
  data?: any;
}

class TestDataSeeder {
  private hasSeeded = false;

  // Create sample products for testing
  async seedTestProducts(): Promise<SeedDataResult> {
    if (this.hasSeeded) {
      return { success: true, message: 'Test data already seeded' };
    }

    try {
      console.log('[TestDataSeeder] Creating sample products for testing...');

      const testProducts = [
      {
        sku: 'TEST001',
        name: 'Test Saree - Silk Blue',
        description: 'Beautiful blue silk saree for testing purposes',
        category: 'sarees' as const,
        costPrice: 800,
        sellingPrice: 1200,
        stockLevel: 25,
        minStockLevel: 5,
        supplierId: 'SUP001',
        sizes: ['Free Size'],
        colors: ['Blue', 'Navy Blue'],
        imageIds: [],
        images: [],
        isActive: true
      },
      {
        sku: 'TEST002',
        name: 'Test Kurti - Cotton Red',
        description: 'Comfortable cotton kurti for testing',
        category: 'kurtis' as const,
        costPrice: 300,
        sellingPrice: 450,
        stockLevel: 50,
        minStockLevel: 10,
        supplierId: 'SUP001',
        sizes: ['S', 'M', 'L', 'XL'],
        colors: ['Red', 'Maroon'],
        imageIds: [],
        images: [],
        isActive: true
      },
      {
        sku: 'TEST003',
        name: 'Test Lehenga - Designer Golden',
        description: 'Elegant golden designer lehenga',
        category: 'lehengas' as const,
        costPrice: 2000,
        sellingPrice: 3500,
        stockLevel: 8,
        minStockLevel: 2,
        supplierId: 'SUP002',
        sizes: ['S', 'M', 'L'],
        colors: ['Golden', 'Cream'],
        imageIds: [],
        images: [],
        isActive: true
      },
      {
        sku: 'TEST004',
        name: 'Test Salwar Suit - Punjabi Style',
        description: 'Traditional Punjabi style salwar suit',
        category: 'salwar-suits' as const,
        costPrice: 600,
        sellingPrice: 900,
        stockLevel: 15,
        minStockLevel: 3,
        supplierId: 'SUP001',
        sizes: ['M', 'L', 'XL'],
        colors: ['Pink', 'Green', 'Yellow'],
        imageIds: [],
        images: [],
        isActive: true
      },
      {
        sku: 'TEST005',
        name: 'Test Top - Casual White',
        description: 'Casual white top for daily wear',
        category: 'tops' as const,
        costPrice: 200,
        sellingPrice: 350,
        stockLevel: 2, // Low stock for testing
        minStockLevel: 5,
        supplierId: 'SUP001',
        sizes: ['XS', 'S', 'M', 'L'],
        colors: ['White', 'Light Blue'],
        imageIds: [],
        images: [],
        isActive: true
      }];


      const createdProducts = [];
      for (const productData of testProducts) {
        try {
          // Check if product already exists
          const existingProducts = await productService.getAllProducts({ query: productData.sku });
          if (existingProducts.length === 0) {
            const product = await productService.createProduct(productData);
            createdProducts.push(product);
            console.log(`[TestDataSeeder] Created test product: ${product.name} (ID: ${product.id})`);
          } else {
            console.log(`[TestDataSeeder] Product ${productData.sku} already exists`);
          }
        } catch (error) {
          console.warn(`[TestDataSeeder] Failed to create product ${productData.sku}:`, error);
          // Continue with other products
        }
      }

      this.hasSeeded = true;
      return {
        success: true,
        message: `Successfully seeded ${createdProducts.length} test products`,
        data: createdProducts
      };

    } catch (error) {
      console.error('[TestDataSeeder] Error seeding test data:', error);
      return {
        success: false,
        message: `Failed to seed test data: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }

  // Get test products for validation
  async getTestProducts(): Promise<SeedDataResult> {
    try {
      const testProducts = await productService.getAllProducts({ query: 'TEST' });
      return {
        success: true,
        message: `Found ${testProducts.length} test products`,
        data: testProducts
      };
    } catch (error) {
      return {
        success: false,
        message: `Failed to retrieve test products: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }

  // Clean up test data
  async cleanupTestData(): Promise<SeedDataResult> {
    try {
      console.log('[TestDataSeeder] Cleaning up test data...');

      const testProducts = await productService.getAllProducts({ query: 'TEST' });

      for (const product of testProducts) {
        try {
          await productService.deleteProduct(product.id);
          console.log(`[TestDataSeeder] Deleted test product: ${product.name}`);
        } catch (error) {
          console.warn(`[TestDataSeeder] Failed to delete product ${product.id}:`, error);
        }
      }

      this.hasSeeded = false;
      return {
        success: true,
        message: `Cleaned up ${testProducts.length} test products`
      };

    } catch (error) {
      return {
        success: false,
        message: `Failed to cleanup test data: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }

  // Reset seeding flag
  resetSeedingFlag(): void {
    this.hasSeeded = false;
  }
}

export const testDataSeeder = new TestDataSeeder();