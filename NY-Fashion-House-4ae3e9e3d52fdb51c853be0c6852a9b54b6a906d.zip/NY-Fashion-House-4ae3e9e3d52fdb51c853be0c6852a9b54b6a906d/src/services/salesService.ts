import { Sale, SaleItem, PaymentMethod, TaxConfig, POSSettings } from '@/types/sales';
import { Product } from '@/types/product';
import { Customer } from '@/types/customer';

const SALES_TRANSACTIONS_TABLE_ID = 38156;
const PRODUCTS_TABLE_ID = 38157;

let receiptCounter = 1;

const defaultTaxConfig: TaxConfig = {
  id: '1',
  name: 'New York Sales Tax',
  percentage: 8.875,
  isDefault: true
};

const defaultPOSSettings: POSSettings = {
  taxPercentage: 8.875,
  defaultPaymentMethod: 'cash',
  requireCustomer: false,
  autoGenerateReceipt: true,
  printReceipt: false,
  currency: 'USD',
  language: 'en'
};

export const paymentMethods: PaymentMethod[] = [
{ type: 'cash', label: 'Cash' },
{ type: 'card', label: 'Credit/Debit Card' },
{ type: 'mobile-banking', label: 'Mobile Banking' },
{ type: 'digital-wallet', label: 'Digital Wallet' }];


export const salesService = {
  // Create a new sale and sync to database
  createSale: async (saleData: Omit<Sale, 'id' | 'createdAt' | 'receiptNumber'>): Promise<Sale> => {
    const receiptNumber = `RCP${String(receiptCounter++).padStart(6, '0')}`;

    const newSale: Sale = {
      ...saleData,
      id: Date.now().toString(),
      receiptNumber,
      createdAt: new Date()
    };

    // Save each sale item to the database
    for (const item of newSale.items) {
      try {
        const { error } = await window.ezsite.apis.tableCreate(SALES_TRANSACTIONS_TABLE_ID, {
          product_id: parseInt(item.productId),
          product_name: item.productName,
          quantity_sold: item.quantity,
          unit_price: item.sellingPrice,
          total_amount: item.sellingPrice * item.quantity - item.discount,
          sale_date: new Date(),
          employee_id: parseInt(newSale.cashierId) || 0,
          employee_name: newSale.cashierName || 'Unknown',
          notes: `Receipt: ${receiptNumber}`
        });

        if (error) {
          console.error('Failed to save sale transaction:', error);
        }

        // Update product stock level
        const { data: products, error: productError } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
          PageNo: 1,
          PageSize: 1,
          Filters: [{ name: 'id', op: 'Equal', value: parseInt(item.productId) }]
        });

        if (!productError && products?.List?.length > 0) {
          const product = products.List[0];
          const newStockLevel = Math.max(0, product.stock_level - item.quantity);

          await window.ezsite.apis.tableUpdate(PRODUCTS_TABLE_ID, {
            id: product.id,
            stock_level: newStockLevel
          });
        }
      } catch (error) {
        console.error('Error processing sale item:', error);
      }
    }

    return newSale;
  },

  // Get all sales from database
  getAllSales: async (filters?: {
    startDate?: Date;
    endDate?: Date;
    customerId?: string;
    cashierId?: string;
    status?: Sale['status'];
  }): Promise<any[]> => {
    try {
      const queryFilters = [];

      if (filters?.startDate) {
        queryFilters.push({ name: 'sale_date', op: 'GreaterThanOrEqual', value: filters.startDate.toISOString() });
      }

      if (filters?.endDate) {
        queryFilters.push({ name: 'sale_date', op: 'LessThanOrEqual', value: filters.endDate.toISOString() });
      }

      if (filters?.cashierId) {
        queryFilters.push({ name: 'employee_id', op: 'Equal', value: parseInt(filters.cashierId) });
      }

      const { data, error } = await window.ezsite.apis.tablePage(SALES_TRANSACTIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'sale_date',
        IsAsc: false,
        Filters: queryFilters
      });

      if (error) {
        console.error('Failed to fetch sales:', error);
        return [];
      }

      return data?.List || [];
    } catch (error) {
      console.error('Error fetching sales:', error);
      return [];
    }
  },

  // Get sale by ID
  getSaleById: async (id: string): Promise<any | null> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALES_TRANSACTIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [{ name: 'id', op: 'Equal', value: parseInt(id) }]
      });

      if (error || !data?.List?.length) {
        return null;
      }

      return data.List[0];
    } catch (error) {
      console.error('Error fetching sale by ID:', error);
      return null;
    }
  },

  // Calculate sale totals
  calculateSaleTotals: (
  items: SaleItem[],
  discountPercentage: number = 0,
  taxPercentage: number = defaultTaxConfig.percentage) =>
  {
    const subtotal = items.reduce((sum, item) => sum + (item.sellingPrice * item.quantity - item.discount), 0);
    const discountAmount = subtotal * discountPercentage / 100;
    const taxableAmount = subtotal - discountAmount;
    const taxAmount = taxableAmount * taxPercentage / 100;
    const totalAmount = taxableAmount + taxAmount;

    return {
      subtotal,
      discountAmount,
      taxAmount,
      totalAmount
    };
  },

  // Get sales statistics with real-time data
  getSalesStats: async (period: 'today' | 'week' | 'month' | 'year' = 'today') => {
    const now = new Date();
    let startDate: Date;

    switch (period) {
      case 'today':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
    }

    try {
      const { data, error } = await window.ezsite.apis.tablePage(SALES_TRANSACTIONS_TABLE_ID, {
        PageNo: 1,
        PageSize: 10000,
        Filters: [
        { name: 'sale_date', op: 'GreaterThanOrEqual', value: startDate.toISOString() }]

      });

      if (error || !data?.List) {
        return {
          totalSales: 0,
          totalRevenue: 0,
          averageSaleValue: 0,
          totalItemsSold: 0,
          period
        };
      }

      const sales = data.List;
      const totalSales = sales.length;
      const totalRevenue = sales.reduce((sum: number, sale: any) => sum + (sale.total_amount || 0), 0);
      const totalItemsSold = sales.reduce((sum: number, sale: any) => sum + (sale.quantity_sold || 0), 0);
      const averageSaleValue = totalSales > 0 ? totalRevenue / totalSales : 0;

      return {
        totalSales,
        totalRevenue,
        averageSaleValue,
        totalItemsSold,
        period
      };
    } catch (error) {
      console.error('Error fetching sales stats:', error);
      return {
        totalSales: 0,
        totalRevenue: 0,
        averageSaleValue: 0,
        totalItemsSold: 0,
        period
      };
    }
  },

  // Get payment methods
  getPaymentMethods: () => paymentMethods,

  // Get tax configuration
  getTaxConfig: () => defaultTaxConfig,

  // Get POS settings
  getPOSSettings: () => defaultPOSSettings,

  // Update POS settings
  updatePOSSettings: async (settings: Partial<POSSettings>): Promise<POSSettings> => {
    Object.assign(defaultPOSSettings, settings);
    return new Promise((resolve) => setTimeout(() => resolve(defaultPOSSettings), 100));
  }
};