import { Product, ProductVariant, StockAdjustment, LowStockAlert, ProductSearchParams, ProductCategory } from '@/types/product';
import { apiWrapper } from '@/utils/apiWrapper';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import { enhancedProductService } from '@/services/enhancedProductService';
import { skuGenerator } from '@/services/skuGenerator';

// Database service for product management
const PRODUCTS_TABLE_ID = 38157; // ID of the products table

interface DatabaseProduct {
  id: number;
  sku: string;
  name: string;
  description: string;
  category: string;
  cost_price: number;
  selling_price: number;
  stock_level: number;
  min_stock_level: number;
  supplier_id: string;
  barcode: string;
  sizes: string;
  colors: string;
  image_url: string;
  image_ids: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Helper functions for data conversion
const convertFromDatabase = (dbProduct: DatabaseProduct): Product => {
  try {
    const imageIds = dbProduct.image_ids ? JSON.parse(dbProduct.image_ids) : [];
    const sizes = dbProduct.sizes ? dbProduct.sizes.split(',').map((s) => s.trim()).filter(Boolean) : [];
    const colors = dbProduct.colors ? dbProduct.colors.split(',').map((c) => c.trim()).filter(Boolean) : [];

    return {
      id: dbProduct.id.toString(),
      sku: dbProduct.sku || '',
      name: dbProduct.name || '',
      description: dbProduct.description || '',
      category: (dbProduct.category || 'casual-wear') as ProductCategory,
      costPrice: dbProduct.cost_price || 0,
      sellingPrice: dbProduct.selling_price || 0,
      stockLevel: dbProduct.stock_level || 0,
      minStockLevel: dbProduct.min_stock_level || 0,
      supplierId: dbProduct.supplier_id || '',
      barcode: dbProduct.barcode || '',
      sizes,
      colors,
      images: [dbProduct.image_url].filter(Boolean), // Legacy support
      imageIds,
      createdAt: new Date(dbProduct.created_at || Date.now()),
      updatedAt: new Date(dbProduct.updated_at || Date.now()),
      isActive: dbProduct.is_active !== false
    };
  } catch (error) {
    enhancedErrorLoggingService.logError(error as Error, {
      severity: 'medium',
      service: 'productService',
      operation: 'convertFromDatabase',
      productId: dbProduct.id,
      productData: dbProduct
    });

    // Return a default product to prevent complete failure
    return {
      id: dbProduct.id.toString(),
      sku: dbProduct.sku || 'UNKNOWN',
      name: dbProduct.name || 'Unknown Product',
      description: dbProduct.description || '',
      category: 'casual-wear' as ProductCategory,
      costPrice: dbProduct.cost_price || 0,
      sellingPrice: dbProduct.selling_price || 0,
      stockLevel: dbProduct.stock_level || 0,
      minStockLevel: dbProduct.min_stock_level || 0,
      supplierId: dbProduct.supplier_id || '',
      barcode: dbProduct.barcode || '',
      sizes: [],
      colors: [],
      images: [],
      imageIds: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      isActive: true
    };
  }
};

const convertToDatabase = (product: Partial<Product>): Partial<DatabaseProduct> => {
  return {
    sku: product.sku,
    name: product.name,
    description: product.description,
    category: product.category,
    cost_price: product.costPrice,
    selling_price: product.sellingPrice,
    stock_level: product.stockLevel,
    min_stock_level: product.minStockLevel,
    supplier_id: product.supplierId,
    barcode: product.barcode,
    sizes: product.sizes ? product.sizes.join(', ') : '',
    colors: product.colors ? product.colors.join(', ') : '',
    image_url: product.images?.[0] || '', // Legacy support
    image_ids: product.imageIds ? JSON.stringify(product.imageIds) : '[]',
    is_active: product.isActive,
    created_at: product.createdAt?.toISOString(),
    updated_at: new Date().toISOString()
  };
};

let stockAdjustments: StockAdjustment[] = [];
let lowStockAlerts: LowStockAlert[] = [];

// Main product service implementation
export const productService = {
  // Product CRUD operations
  getAllProducts: async (params?: ProductSearchParams): Promise<Product[]> => {
    try {
      const filters = [];

      // Add active filter
      filters.push({
        name: 'is_active',
        op: 'Equal',
        value: true
      });

      if (params) {
        // Search by query
        if (params.query) {
          filters.push({
            name: 'name',
            op: 'StringContains',
            value: params.query
          });
        }

        // Filter by category
        if (params.category) {
          filters.push({
            name: 'category',
            op: 'Equal',
            value: params.category
          });
        }

        // Filter by supplier
        if (params.supplier) {
          filters.push({
            name: 'supplier_id',
            op: 'Equal',
            value: params.supplier
          });
        }

        // Filter by price range
        if (params.priceRange) {
          const [min, max] = params.priceRange;
          filters.push({
            name: 'selling_price',
            op: 'GreaterThanOrEqual',
            value: min
          });
          filters.push({
            name: 'selling_price',
            op: 'LessThanOrEqual',
            value: max
          });
        }
      }

      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: params?.sortBy === 'name' ? 'name' :
        params?.sortBy === 'price' ? 'selling_price' :
        params?.sortBy === 'stock' ? 'stock_level' :
        params?.sortBy === 'category' ? 'category' : 'created_at',
        IsAsc: params?.sortOrder !== 'desc',
        Filters: filters
      });

      if (error) {
        const dbError = new Error(`Database error: ${error}`);
        enhancedErrorLoggingService.logError(dbError, {
          severity: 'medium',
          service: 'productService',
          operation: 'getAllProducts',
          searchParams: params,
          tableId: PRODUCTS_TABLE_ID
        });
        throw dbError;
      }

      if (!data || !data.List) {
        console.warn('No data returned from database, returning empty array');
        return [];
      }

      const products = data.List.map(convertFromDatabase);

      // Apply client-side filtering for complex cases
      let filteredProducts = products;

      if (params) {
        // Filter by size
        if (params.size) {
          filteredProducts = filteredProducts.filter((p) => p.sizes.includes(params.size!));
        }

        // Filter by color
        if (params.color) {
          filteredProducts = filteredProducts.filter((p) => p.colors.includes(params.color!));
        }

        // Filter by stock status
        if (params.inStock !== undefined) {
          filteredProducts = filteredProducts.filter((p) =>
          params.inStock ? p.stockLevel > 0 : p.stockLevel === 0
          );
        }

        if (params.lowStock !== undefined && params.lowStock) {
          filteredProducts = filteredProducts.filter((p) => p.stockLevel <= p.minStockLevel);
        }
      }

      return filteredProducts;
    } catch (error) {
      enhancedErrorLoggingService.logError(error as Error, {
        severity: 'medium',
        service: 'productService',
        operation: 'getAllProducts',
        searchParams: params
      });

      // If it's a network error or database connection error, provide a meaningful message
      if (error instanceof Error) {
        if (error.message.includes('Failed to fetch') || error.message.includes('Network')) {
          throw new Error('Unable to connect to database. Please check your internet connection.');
        }
        throw new Error(enhancedErrorLoggingService.createUserFriendlyMessage(error));
      }

      throw new Error('Unknown error occurred while fetching products');
    }
  },

  getProductById: async (id: string): Promise<Product | null> => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'id',
          op: 'Equal',
          value: parseInt(id)
        },
        {
          name: 'is_active',
          op: 'Equal',
          value: true
        }]

      });

      if (error) {
        throw new Error(error);
      }

      if (data && data.List && data.List.length > 0) {
        return convertFromDatabase(data.List[0]);
      }

      return null;
    } catch (error) {
      console.error('Error fetching product:', error);
      throw error;
    }
  },

  createProduct: async (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'barcode' | 'sku'>): Promise<Product> => {
    try {
      // Generate unique SKU (9-11 digits)
      const sku = await skuGenerator.generateSKU(productData.name, productData.category);
      const barcode = `${Date.now()}${Math.random().toString().substr(2, 3)}`;

      const dbData = convertToDatabase({
        ...productData,
        sku,
        barcode,
        createdAt: new Date(),
        updatedAt: new Date()
      });

      const { error } = await window.ezsite.apis.tableCreate(PRODUCTS_TABLE_ID, dbData);

      if (error) {
        throw new Error(error);
      }

      // Fetch the created product
      const products = await productService.getAllProducts();
      const newProduct = products.find((p) => p.barcode === barcode);

      if (!newProduct) {
        throw new Error('Failed to retrieve created product');
      }

      return newProduct;
    } catch (error) {
      console.error('Error creating product:', error);
      throw error;
    }
  },

  updateProduct: async (id: string, productData: Partial<Product>): Promise<Product> => {
    try {
      const dbData = convertToDatabase({
        ...productData,
        updatedAt: new Date()
      });

      const { error } = await window.ezsite.apis.tableUpdate(PRODUCTS_TABLE_ID, {
        id: parseInt(id),
        ...dbData
      });

      if (error) {
        throw new Error(error);
      }

      // Fetch the updated product
      const updatedProduct = await productService.getProductById(id);

      if (!updatedProduct) {
        throw new Error('Failed to retrieve updated product');
      }

      return updatedProduct;
    } catch (error) {
      console.error('Error updating product:', error);
      throw error;
    }
  },

  deleteProduct: async (id: string): Promise<void> => {
    try {
      const { error } = await window.ezsite.apis.tableUpdate(PRODUCTS_TABLE_ID, {
        id: parseInt(id),
        is_active: false
      });

      if (error) {
        throw new Error(`Product deletion failed: ${error}`);
      }
    } catch (error) {
      enhancedErrorLoggingService.logError(error as Error, {
        severity: 'medium',
        service: 'productService',
        operation: 'deleteProduct',
        productId: id
      });
      throw error;
    }
  },

  // Stock management
  adjustStock: async (adjustment: Omit<StockAdjustment, 'id' | 'date'>): Promise<void> => {
    try {
      const product = await productService.getProductById(adjustment.productId);
      if (!product) {
        throw new Error('Product not found');
      }

      const newAdjustment: StockAdjustment = {
        ...adjustment,
        id: Date.now().toString(),
        date: new Date()
      };

      stockAdjustments.push(newAdjustment);

      // Update product stock
      const stockChange = adjustment.type === 'out' ? -adjustment.quantity : adjustment.quantity;
      const newStockLevel = Math.max(0, product.stockLevel + stockChange);

      await productService.updateProduct(adjustment.productId, {
        stockLevel: newStockLevel
      });
    } catch (error) {
      console.error('Error adjusting stock:', error);
      throw error;
    }
  },

  getStockAdjustments: async (productId?: string): Promise<StockAdjustment[]> => {
    const filtered = productId ?
    stockAdjustments.filter((adj) => adj.productId === productId) :
    stockAdjustments;

    return filtered.sort((a, b) => b.date.getTime() - a.date.getTime());
  },

  getLowStockAlerts: async (): Promise<LowStockAlert[]> => {
    try {
      const products = await productService.getAllProducts();
      const alerts = products.
      filter((product) => product.stockLevel <= product.minStockLevel && product.isActive).
      map((product) => ({
        id: `alert-${product.id}`,
        productId: product.id,
        productName: product.name,
        currentStock: product.stockLevel,
        minStockLevel: product.minStockLevel,
        createdAt: new Date(),
        isResolved: false
      }));

      return alerts;
    } catch (error) {
      console.error('Error generating low stock alerts:', error);
      return [];
    }
  },

  // Utility functions with updated categories based on user requirements
  getCategories: (): ProductCategory[] => {
    return [
    'Jamdani Saree',
    'Katan',
    'Silk',
    'Muslin',
    'Tangail',
    'Cotton',
    'Half-Silk',
    'Linen',
    'Organza',
    'Georgette',
    'Chiffon',
    'Salwar Kameez/Three-Piece',
    'Kurti/Tunic',
    'Lehenga/Bridal',
    'Abaya',
    'Hijab/Scarf/Khimar',
    'Orna/Dupatta',
    'Blouse',
    'Petticoat',
    'Palazzo/Pant',
    'Skirt',
    'Shawl/Stole',
    'Winterwear',
    'Nightwear',
    'Maternity',
    'Kids (Girls)',
    'Accessories',
    'Tailoring'] as
    ProductCategory[];
  },

  getSizes: (): string[] => {
    return ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL', 'Free Size'];
  },

  getColors: (): string[] => {
    return ['Red', 'Blue', 'Green', 'Yellow', 'Pink', 'Purple', 'Orange', 'Black', 'White', 'Grey', 'Brown', 'Navy Blue', 'Maroon', 'Golden', 'Silver', 'Cream', 'Peach', 'Mint Green', 'Lavender', 'Light Blue'];
  },

  // Search product by barcode with better error handling
  searchProductByBarcode: async (barcode: string): Promise<Product | null> => {
    try {
      if (!barcode || barcode.trim().length === 0) {
        throw new Error('Barcode cannot be empty');
      }

      // Validate barcode format (basic validation)
      if (barcode.length < 6 || !/^\d+$/.test(barcode.slice(-6))) {
        throw new Error('Invalid barcode format');
      }

      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'barcode',
          op: 'Equal',
          value: barcode
        },
        {
          name: 'is_active',
          op: 'Equal',
          value: true
        }]

      });

      if (error) {
        const dbError = new Error(`Database error: ${error}`);
        enhancedErrorLoggingService.logError(dbError, {
          severity: 'medium',
          service: 'productService',
          operation: 'searchProductByBarcode',
          barcode,
          tableId: PRODUCTS_TABLE_ID
        });
        throw dbError;
      }

      if (!data || !data.List || data.List.length === 0) {
        return null;
      }

      return convertFromDatabase(data.List[0]);
    } catch (error) {
      enhancedErrorLoggingService.logError(error as Error, {
        severity: 'low',
        service: 'productService',
        operation: 'searchProductByBarcode',
        barcode
      });

      if (error instanceof Error) {
        throw error;
      }
      throw new Error('Failed to search product by barcode');
    }
  },

  generateBarcode: (sku: string): string => {
    const timestamp = Date.now().toString();
    return `${sku}${timestamp.slice(-6)}`;
  },

  // Enhanced validation for barcode
  validateBarcode: (barcode: string): {isValid: boolean;error?: string;} => {
    if (!barcode || barcode.trim().length === 0) {
      return { isValid: false, error: 'Barcode cannot be empty' };
    }

    if (barcode.length < 6) {
      return { isValid: false, error: 'Barcode must be at least 6 characters long' };
    }

    if (barcode.length > 20) {
      return { isValid: false, error: 'Barcode cannot exceed 20 characters' };
    }

    // Allow alphanumeric characters and hyphens
    if (!/^[a-zA-Z0-9\-]+$/.test(barcode)) {
      return { isValid: false, error: 'Barcode can only contain letters, numbers, and hyphens' };
    }

    return { isValid: true };
  }
};

// Use enhanced product service for better error handling and connection management
export default productService;

// Legacy service for backward compatibility
export const legacyProductService = productService;