/**
 * SKU Generator Service
 * Generates unique 9-11 digit numeric SKUs for products
 */

interface SKUComponent {
  timestamp: string;
  category: string;
  counter: string;
  checksum: string;
}

const SKU_COUNTERS_TABLE_ID = 38281;

class SKUGeneratorService {
  private readonly MIN_LENGTH = 9;
  private readonly MAX_LENGTH = 11;
  private readonly TIMESTAMP_LENGTH = 6; // YYMMDD (last 6 digits of date)
  private readonly CATEGORY_LENGTH = 2; // 2-digit category code
  private readonly COUNTER_LENGTH = 2; // 2-digit counter
  private readonly CHECKSUM_LENGTH = 1; // 1-digit checksum

  /**
   * Generate a unique 9-11 digit SKU for a product
   */
  async generateSKU(productName: string, category: string): Promise<string> {
    try {
      // Get timestamp component (6 digits: YYMMDD)
      const timestamp = this.generateTimestamp();

      // Get category component (2 digits)
      const categoryComponent = this.generateCategoryComponent(category);

      // Get counter component (2 digits)
      const counterComponent = await this.generateCounterComponent(category);

      // Combine components without checksum first
      const preChecksum = timestamp + categoryComponent + counterComponent;

      // Generate checksum (1 digit)
      const checksum = this.generateChecksum(preChecksum);

      // Final SKU (total: 6+2+2+1 = 11 digits)
      let sku = preChecksum + checksum;

      // Ensure SKU is within 9-11 digit range
      if (sku.length < this.MIN_LENGTH) {
        // Pad with additional counter digits if needed
        const padding = this.generatePadding(this.MIN_LENGTH - sku.length);
        sku = preChecksum + padding + checksum;
      } else if (sku.length > this.MAX_LENGTH) {
        // Truncate if too long (shouldn't happen with our design)
        sku = sku.substring(0, this.MAX_LENGTH);
      }

      // Verify uniqueness
      const isUnique = await this.verifySKUUniqueness(sku);
      if (!isUnique) {
        // Regenerate with different counter
        return this.generateSKU(productName, category);
      }

      return sku;
    } catch (error) {
      console.error('Error generating SKU:', error);
      throw new Error('Failed to generate unique SKU');
    }
  }

  /**
   * Generate timestamp component (6 digits: YYMMDD)
   */
  private generateTimestamp(): string {
    const now = new Date();
    const year = now.getFullYear().toString().slice(-2); // Last 2 digits of year
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');

    return year + month + day;
  }

  /**
   * Generate category component (2 digits) - Updated with new categories
   */
  private generateCategoryComponent(category: string): string {
    // Map category to 2-digit numeric codes
    const categoryMap: {[key: string]: string;} = {
      'Jamdani Saree': '01',
      'Katan': '02',
      'Silk': '03',
      'Muslin': '04',
      'Tangail': '05',
      'Cotton': '06',
      'Half-Silk': '07',
      'Linen': '08',
      'Organza': '09',
      'Georgette': '10',
      'Chiffon': '11',
      'Salwar Kameez/Three-Piece': '12',
      'Kurti/Tunic': '13',
      'Lehenga/Bridal': '14',
      'Abaya': '15',
      'Hijab/Scarf/Khimar': '16',
      'Orna/Dupatta': '17',
      'Blouse': '18',
      'Petticoat': '19',
      'Palazzo/Pant': '20',
      'Skirt': '21',
      'Shawl/Stole': '22',
      'Winterwear': '23',
      'Nightwear': '24',
      'Maternity': '25',
      'Kids (Girls)': '26',
      'Accessories': '27',
      'Tailoring': '28'
    };

    return categoryMap[category] || '99'; // Default to 99 for unknown categories
  }

  /**
   * Generate counter component (2 digits)
   */
  private async generateCounterComponent(category: string): Promise<string> {
    try {
      // Get current counter for the category
      const { data, error } = await window.ezsite.apis.tablePage(SKU_COUNTERS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'category',
          op: 'Equal',
          value: category
        }]

      });

      let counter = 1;

      if (error) {
        console.warn('Error fetching counter, using default:', error);
      } else if (data && data.List && data.List.length > 0) {
        const currentRecord = data.List[0];
        counter = (currentRecord.current_counter || 0) + 1;

        // Reset counter if it exceeds 99 (to keep it 2 digits)
        if (counter > 99) {
          counter = 1;
        }

        // Update counter
        await window.ezsite.apis.tableUpdate(SKU_COUNTERS_TABLE_ID, {
          id: currentRecord.id,
          current_counter: counter,
          last_updated: new Date().toISOString()
        });
      } else {
        // Create new counter record
        await window.ezsite.apis.tableCreate(SKU_COUNTERS_TABLE_ID, {
          category: category,
          current_counter: counter,
          last_updated: new Date().toISOString()
        });
      }

      return counter.toString().padStart(2, '0');
    } catch (error) {
      console.warn('Error managing counter, using timestamp-based fallback:', error);
      // Fallback to timestamp-based counter (last 2 digits of timestamp)
      return Date.now().toString().slice(-2);
    }
  }

  /**
   * Generate padding digits
   */
  private generatePadding(length: number): string {
    if (length <= 0) return '';
    return Math.floor(Math.random() * Math.pow(10, length)).toString().padStart(length, '0');
  }

  /**
   * Generate checksum (1 digit)
   */
  private generateChecksum(input: string): string {
    let sum = 0;
    for (let i = 0; i < input.length; i++) {
      sum += parseInt(input.charAt(i));
    }
    return (sum % 10).toString();
  }

  /**
   * Verify SKU uniqueness in database
   */
  private async verifySKUUniqueness(sku: string): Promise<boolean> {
    try {
      const PRODUCTS_TABLE_ID = 38157;
      const { data, error } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        {
          name: 'sku',
          op: 'Equal',
          value: sku
        }]

      });

      if (error) {
        console.warn('Error checking SKU uniqueness:', error);
        return true; // Assume unique if we can't verify
      }

      return !data || !data.List || data.List.length === 0;
    } catch (error) {
      console.warn('Error verifying SKU uniqueness:', error);
      return true; // Assume unique if we can't verify
    }
  }

  /**
   * Validate SKU format
   */
  validateSKU(sku: string): {isValid: boolean;error?: string;} {
    if (!sku) {
      return { isValid: false, error: 'SKU cannot be empty' };
    }

    if (sku.length < this.MIN_LENGTH || sku.length > this.MAX_LENGTH) {
      return { isValid: false, error: `SKU must be between ${this.MIN_LENGTH} and ${this.MAX_LENGTH} digits long` };
    }

    if (!/^\d+$/.test(sku)) {
      return { isValid: false, error: 'SKU must contain only digits' };
    }

    return { isValid: true };
  }

  /**
   * Parse SKU components for debugging/display
   */
  parseSKU(sku: string): SKUComponent | null {
    if (!sku || sku.length < this.MIN_LENGTH || sku.length > this.MAX_LENGTH) {
      return null;
    }

    try {
      const timestamp = sku.substring(0, this.TIMESTAMP_LENGTH);
      const category = sku.substring(this.TIMESTAMP_LENGTH, this.TIMESTAMP_LENGTH + this.CATEGORY_LENGTH);
      const counter = sku.substring(this.TIMESTAMP_LENGTH + this.CATEGORY_LENGTH, this.TIMESTAMP_LENGTH + this.CATEGORY_LENGTH + this.COUNTER_LENGTH);
      const checksum = sku.substring(sku.length - 1);

      return {
        timestamp,
        category,
        counter,
        checksum
      };
    } catch (error) {
      console.error('Error parsing SKU:', error);
      return null;
    }
  }

  /**
   * Generate a simple numeric SKU without database dependencies (fallback)
   */
  public generateSimpleSKU(): string {
    const now = new Date();
    const timestamp = now.getFullYear().toString().slice(-2) +
    (now.getMonth() + 1).toString().padStart(2, '0') +
    now.getDate().toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 999).toString().padStart(3, '0');
    const sku = timestamp + random;
    return sku.substring(0, Math.min(sku.length, this.MAX_LENGTH));
  }
}

export const skuGenerator = new SKUGeneratorService();
export default skuGenerator;