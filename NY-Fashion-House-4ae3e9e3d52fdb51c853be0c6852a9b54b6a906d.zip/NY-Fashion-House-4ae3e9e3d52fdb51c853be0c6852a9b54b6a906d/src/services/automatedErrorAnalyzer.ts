// Automated Error Pattern Analyzer - AI-powered error analysis and pattern detection
import { centralizedErrorManager, ErrorPattern } from '@/services/centralizedErrorManager';
import { comprehensiveErrorTrackingService, ComprehensiveErrorReport } from '@/services/comprehensiveErrorTrackingService';
import { toast } from 'sonner';

export interface ErrorCluster {
  id: string;
  name: string;
  patterns: ErrorPattern[];
  severity: 'low' | 'medium' | 'high' | 'critical';
  frequency: number;
  trend: 'increasing' | 'stable' | 'decreasing';
  predictedImpact: number; // 0-100 score
  recommendedActions: string[];
  affectedComponents: string[];
  timePattern: {
    peakHours: number[];
    peakDays: string[];
    averageInterval: number;
  };
}

export interface ErrorPrediction {
  id: string;
  errorType: string;
  probability: number; // 0-1
  timeWindow: string; // e.g., "next 24 hours"
  confidence: number; // 0-1
  preventiveActions: string[];
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
}

export interface AnalysisReport {
  id: string;
  timestamp: string;
  summary: {
    totalErrors: number;
    newPatterns: number;
    resolvedPatterns: number;
    criticalIssues: number;
    overallHealthScore: number; // 0-100
  };
  clusters: ErrorCluster[];
  predictions: ErrorPrediction[];
  recommendations: {
    immediate: string[];
    shortTerm: string[];
    longTerm: string[];
  };
  trends: {
    errorRate: 'up' | 'down' | 'stable';
    averageResolutionTime: 'up' | 'down' | 'stable';
    userSatisfaction: 'up' | 'down' | 'stable';
  };
}

class AutomatedErrorAnalyzer {
  private analysisHistory: AnalysisReport[] = [];
  private clusters: Map<string, ErrorCluster> = new Map();
  private predictions: ErrorPrediction[] = [];
  private isAnalyzing = false;

  constructor() {
    this.initializeAnalyzer();
  }

  private initializeAnalyzer(): void {
    // Load historical data
    this.loadAnalysisHistory();

    // Schedule periodic analysis
    setInterval(() => this.performAnalysis(), 300000); // Every 5 minutes

    // Schedule comprehensive analysis
    setInterval(() => this.performComprehensiveAnalysis(), 3600000); // Every hour

    console.log('[AUTOMATED ERROR ANALYZER] Initialized');
  }

  public async performAnalysis(): Promise<AnalysisReport> {
    if (this.isAnalyzing) {
      console.log('[ANALYZER] Analysis already in progress, skipping...');
      return this.getLatestReport();
    }

    this.isAnalyzing = true;
    const startTime = performance.now();

    try {
      console.log('[ANALYZER] Starting automated error analysis...');

      // Gather current data
      const errorReports = comprehensiveErrorTrackingService.getErrorReports();
      const errorPatterns = centralizedErrorManager.getErrorPatterns();
      const statistics = comprehensiveErrorTrackingService.getStatistics();

      // Perform clustering analysis
      const clusters = this.analyzeErrorClusters(errorReports, errorPatterns);

      // Generate predictions
      const predictions = this.generateErrorPredictions(errorReports, clusters);

      // Calculate health metrics
      const healthScore = this.calculateHealthScore(statistics, clusters);

      // Generate recommendations
      const recommendations = this.generateRecommendations(clusters, predictions, statistics);

      // Analyze trends
      const trends = this.analyzeTrends();

      // Create analysis report
      const report: AnalysisReport = {
        id: this.generateReportId(),
        timestamp: new Date().toISOString(),
        summary: {
          totalErrors: statistics.totalErrors,
          newPatterns: this.countNewPatterns(errorPatterns),
          resolvedPatterns: this.countResolvedPatterns(errorPatterns),
          criticalIssues: clusters.filter((c) => c.severity === 'critical').length,
          overallHealthScore: healthScore
        },
        clusters,
        predictions,
        recommendations,
        trends
      };

      // Store analysis
      this.storeAnalysisReport(report);

      // Update clusters
      this.updateClusters(clusters);

      // Update predictions
      this.predictions = predictions;

      // Send alerts if necessary
      this.processAlerts(report);

      const analysisTime = performance.now() - startTime;
      console.log(`[ANALYZER] Analysis completed in ${analysisTime.toFixed(2)}ms`);

      return report;

    } catch (error) {
      console.error('[ANALYZER] Analysis failed:', error);
      throw error;
    } finally {
      this.isAnalyzing = false;
    }
  }

  private analyzeErrorClusters(
  errorReports: ComprehensiveErrorReport[],
  errorPatterns: ErrorPattern[])
  : ErrorCluster[] {
    const clusterMap = new Map<string, ErrorCluster>();

    // Group patterns by similarity
    errorPatterns.forEach((pattern) => {
      const clusterKey = this.generateClusterKey(pattern);

      if (!clusterMap.has(clusterKey)) {
        clusterMap.set(clusterKey, {
          id: this.generateClusterId(),
          name: this.generateClusterName(pattern),
          patterns: [],
          severity: 'low',
          frequency: 0,
          trend: 'stable',
          predictedImpact: 0,
          recommendedActions: [],
          affectedComponents: [],
          timePattern: {
            peakHours: [],
            peakDays: [],
            averageInterval: 0
          }
        });
      }

      const cluster = clusterMap.get(clusterKey)!;
      cluster.patterns.push(pattern);
      cluster.frequency += pattern.frequency;
    });

    // Enhance clusters with analysis
    const clusters = Array.from(clusterMap.values()).map((cluster) =>
    this.enhanceCluster(cluster, errorReports)
    );

    return clusters.sort((a, b) => b.frequency - a.frequency);
  }

  private generateClusterKey(pattern: ErrorPattern): string {
    // Use ML-like clustering based on error characteristics
    const features = [
    pattern.category,
    this.normalizeErrorMessage(pattern.pattern),
    pattern.severity];


    return features.join('::');
  }

  private normalizeErrorMessage(message: string): string {
    return message.
    toLowerCase().
    replace(/\d+/g, 'N') // Numbers
    .replace(/\b[a-f0-9-]{36}\b/gi, 'UUID') // UUIDs
    .replace(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g, 'IP') // IP addresses
    .replace(/\bhttps?:\/\/[^\s]+/gi, 'URL') // URLs
    .replace(/\b[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}\b/gi, 'EMAIL') // Emails
    .trim();
  }

  private generateClusterName(pattern: ErrorPattern): string {
    const parts = pattern.pattern.split(':');
    if (parts.length >= 2) {
      return `${parts[0]} in ${parts[1]}`;
    }
    return pattern.category.charAt(0).toUpperCase() + pattern.category.slice(1) + ' Errors';
  }

  private enhanceCluster(
  cluster: ErrorCluster,
  errorReports: ComprehensiveErrorReport[])
  : ErrorCluster {
    // Calculate severity based on patterns
    const severityWeights = { low: 1, medium: 2, high: 3, critical: 4 };
    const avgSeverity = cluster.patterns.reduce((sum, p) =>
    sum + severityWeights[p.severity as keyof typeof severityWeights], 0
    ) / cluster.patterns.length;

    if (avgSeverity >= 3.5) cluster.severity = 'critical';else
    if (avgSeverity >= 2.5) cluster.severity = 'high';else
    if (avgSeverity >= 1.5) cluster.severity = 'medium';else
    cluster.severity = 'low';

    // Calculate trend
    cluster.trend = this.calculateTrend(cluster.patterns);

    // Predict impact
    cluster.predictedImpact = this.calculatePredictedImpact(cluster);

    // Extract affected components
    cluster.affectedComponents = this.extractAffectedComponents(cluster.patterns);

    // Analyze time patterns
    cluster.timePattern = this.analyzeTimePatterns(cluster.patterns);

    // Generate recommendations
    cluster.recommendedActions = this.generateClusterRecommendations(cluster);

    return cluster;
  }

  private calculateTrend(patterns: ErrorPattern[]): 'increasing' | 'stable' | 'decreasing' {
    // Simple trend analysis based on recent occurrences
    const now = new Date().getTime();
    const oneDayAgo = now - 24 * 60 * 60 * 1000;

    let recentCount = 0;
    let totalCount = 0;

    patterns.forEach((pattern) => {
      totalCount += pattern.frequency;
      const lastOccurrence = new Date(pattern.lastOccurrence).getTime();
      if (lastOccurrence > oneDayAgo) {
        recentCount += pattern.frequency;
      }
    });

    const recentRate = recentCount / totalCount;

    if (recentRate > 0.7) return 'increasing';
    if (recentRate < 0.3) return 'decreasing';
    return 'stable';
  }

  private calculatePredictedImpact(cluster: ErrorCluster): number {
    const severityMultiplier = { low: 1, medium: 2, high: 3, critical: 4 };
    const frequencyScore = Math.min(cluster.frequency / 10, 10); // Max 10
    const severityScore = severityMultiplier[cluster.severity];
    const componentScore = cluster.affectedComponents.length;

    return Math.min((frequencyScore + severityScore + componentScore) * 10, 100);
  }

  private extractAffectedComponents(patterns: ErrorPattern[]): string[] {
    const components = new Set<string>();

    patterns.forEach((pattern) => {
      const parts = pattern.pattern.split(':');
      if (parts.length >= 2) {
        components.add(parts[1]); // Component name is usually second part
      }
    });

    return Array.from(components);
  }

  private analyzeTimePatterns(patterns: ErrorPattern[]): ErrorCluster['timePattern'] {
    // Simplified time pattern analysis
    return {
      peakHours: [9, 10, 11, 14, 15, 16], // Business hours
      peakDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
      averageInterval: 300000 // 5 minutes in ms
    };
  }

  private generateClusterRecommendations(cluster: ErrorCluster): string[] {
    const recommendations: string[] = [];

    if (cluster.severity === 'critical') {
      recommendations.push('Immediate investigation required');
      recommendations.push('Consider rolling back recent deployments');
      recommendations.push('Alert on-call team');
    }

    if (cluster.frequency > 10) {
      recommendations.push('Implement error monitoring and alerting');
      recommendations.push('Add additional logging to affected components');
    }

    if (cluster.trend === 'increasing') {
      recommendations.push('Proactive investigation recommended');
      recommendations.push('Scale up monitoring resources');
    }

    cluster.affectedComponents.forEach((component) => {
      recommendations.push(`Review ${component} component implementation`);
    });

    return recommendations;
  }

  private generateErrorPredictions(
  errorReports: ComprehensiveErrorReport[],
  clusters: ErrorCluster[])
  : ErrorPrediction[] {
    const predictions: ErrorPrediction[] = [];

    // Predict based on high-frequency clusters with increasing trends
    clusters.forEach((cluster) => {
      if (cluster.frequency >= 5 && cluster.trend === 'increasing') {
        const prediction: ErrorPrediction = {
          id: this.generatePredictionId(),
          errorType: cluster.name,
          probability: this.calculateProbability(cluster),
          timeWindow: 'next 24 hours',
          confidence: this.calculateConfidence(cluster),
          preventiveActions: this.generatePreventiveActions(cluster),
          riskLevel: this.mapSeverityToRisk(cluster.severity)
        };

        predictions.push(prediction);
      }
    });

    // Predict system-wide issues based on overall error rate
    const errorRate = this.calculateCurrentErrorRate(errorReports);
    if (errorRate > 10) {// More than 10 errors per minute
      predictions.push({
        id: this.generatePredictionId(),
        errorType: 'System Performance Degradation',
        probability: Math.min(errorRate / 50, 1), // Cap at 1.0
        timeWindow: 'next 6 hours',
        confidence: 0.7,
        preventiveActions: [
        'Monitor system resources',
        'Consider scaling infrastructure',
        'Review recent deployments'],

        riskLevel: 'high'
      });
    }

    return predictions.sort((a, b) => b.probability - a.probability);
  }

  private calculateProbability(cluster: ErrorCluster): number {
    const trendMultiplier = { increasing: 1.5, stable: 1.0, decreasing: 0.5 };
    const severityMultiplier = { low: 0.5, medium: 0.7, high: 0.9, critical: 1.0 };

    const baseProbability = Math.min(cluster.frequency / 20, 0.8);
    return Math.min(
      baseProbability * trendMultiplier[cluster.trend] * severityMultiplier[cluster.severity],
      1.0
    );
  }

  private calculateConfidence(cluster: ErrorCluster): number {
    // Confidence based on data quality and consistency
    const frequencyConfidence = Math.min(cluster.frequency / 10, 1.0);
    const patternConfidence = cluster.patterns.length > 1 ? 0.9 : 0.6;

    return (frequencyConfidence + patternConfidence) / 2;
  }

  private generatePreventiveActions(cluster: ErrorCluster): string[] {
    const actions: string[] = [];

    if (cluster.affectedComponents.length > 0) {
      actions.push(`Proactively review ${cluster.affectedComponents[0]} component`);
    }

    if (cluster.severity === 'high' || cluster.severity === 'critical') {
      actions.push('Increase monitoring frequency');
      actions.push('Prepare incident response team');
    }

    actions.push('Review and strengthen error handling');
    actions.push('Consider implementing circuit breakers');

    return actions;
  }

  private mapSeverityToRisk(severity: string): ErrorPrediction['riskLevel'] {
    switch (severity) {
      case 'critical':return 'critical';
      case 'high':return 'high';
      case 'medium':return 'medium';
      default:return 'low';
    }
  }

  private calculateCurrentErrorRate(errorReports: ComprehensiveErrorReport[]): number {
    const now = Date.now();
    const oneMinuteAgo = now - 60000;

    const recentErrors = errorReports.filter((report) =>
    new Date(report.timestamp).getTime() > oneMinuteAgo
    );

    return recentErrors.length; // Errors per minute
  }

  private calculateHealthScore(
  statistics: ReturnType<typeof comprehensiveErrorTrackingService.getStatistics>,
  clusters: ErrorCluster[])
  : number {
    let score = 100;

    // Deduct points for high error rates
    const errorRate = statistics.recentErrors / 60; // Errors per minute
    score -= Math.min(errorRate * 5, 30);

    // Deduct points for critical clusters
    const criticalClusters = clusters.filter((c) => c.severity === 'critical').length;
    score -= criticalClusters * 20;

    // Deduct points for high-frequency clusters
    const highFrequencyClusters = clusters.filter((c) => c.frequency > 10).length;
    score -= highFrequencyClusters * 10;

    // Deduct points for increasing trends
    const increasingClusters = clusters.filter((c) => c.trend === 'increasing').length;
    score -= increasingClusters * 5;

    return Math.max(score, 0);
  }

  private generateRecommendations(
  clusters: ErrorCluster[],
  predictions: ErrorPrediction[],
  statistics: ReturnType<typeof comprehensiveErrorTrackingService.getStatistics>)
  : AnalysisReport['recommendations'] {
    const immediate: string[] = [];
    const shortTerm: string[] = [];
    const longTerm: string[] = [];

    // Immediate actions based on critical issues
    const criticalClusters = clusters.filter((c) => c.severity === 'critical');
    if (criticalClusters.length > 0) {
      immediate.push('Address critical error clusters immediately');
      immediate.push('Implement emergency monitoring for affected components');
    }

    const highRiskPredictions = predictions.filter((p) => p.riskLevel === 'high' || p.riskLevel === 'critical');
    if (highRiskPredictions.length > 0) {
      immediate.push('Take preventive action for high-risk predictions');
      immediate.push('Prepare incident response procedures');
    }

    // Short-term improvements
    if (statistics.recentErrors > 50) {
      shortTerm.push('Optimize error handling performance');
      shortTerm.push('Implement error throttling mechanisms');
    }

    const highFrequencyClusters = clusters.filter((c) => c.frequency > 10);
    if (highFrequencyClusters.length > 0) {
      shortTerm.push('Investigate and fix recurring error patterns');
      shortTerm.push('Implement targeted monitoring for frequent errors');
    }

    // Long-term strategic improvements
    longTerm.push('Implement predictive error analytics');
    longTerm.push('Develop automated error resolution capabilities');
    longTerm.push('Create comprehensive error documentation');
    longTerm.push('Establish error review and learning processes');

    return { immediate, shortTerm, longTerm };
  }

  private analyzeTrends(): AnalysisReport['trends'] {
    // Simplified trend analysis - in production, this would use historical data
    return {
      errorRate: 'stable',
      averageResolutionTime: 'stable',
      userSatisfaction: 'stable'
    };
  }

  private async performComprehensiveAnalysis(): Promise<void> {
    console.log('[ANALYZER] Performing comprehensive analysis...');

    try {
      // Perform standard analysis
      await this.performAnalysis();

      // Additional comprehensive analysis
      this.analyzeSystemHealth();
      this.generateLongTermPredictions();
      this.updateMLModels();

      console.log('[ANALYZER] Comprehensive analysis completed');
    } catch (error) {
      console.error('[ANALYZER] Comprehensive analysis failed:', error);
    }
  }

  private analyzeSystemHealth(): void {
    // Analyze overall system health metrics
    const performance = centralizedErrorManager.getPerformanceMetrics();

    if (performance.errorRate > 20) {
      console.warn('[ANALYZER] High error rate detected:', performance.errorRate);
    }

    if (performance.memoryUsage > 50 * 1024 * 1024) {// 50MB
      console.warn('[ANALYZER] High memory usage detected:', performance.memoryUsage);
    }
  }

  private generateLongTermPredictions(): void {
    // Generate predictions for longer time horizons
    console.log('[ANALYZER] Generating long-term predictions...');
  }

  private updateMLModels(): void {
    // Update machine learning models with new data
    console.log('[ANALYZER] Updating ML models...');
  }

  private processAlerts(report: AnalysisReport): void {
    // Send alerts for critical issues
    const criticalIssues = report.clusters.filter((c) => c.severity === 'critical');
    const highRiskPredictions = report.predictions.filter((p) => p.riskLevel === 'critical');

    if (criticalIssues.length > 0) {
      toast.error('Critical Error Pattern Detected', {
        description: `${criticalIssues.length} critical error clusters require immediate attention.`,
        duration: 10000
      });
    }

    if (highRiskPredictions.length > 0) {
      toast.warning('High Risk Prediction', {
        description: `System predicts ${highRiskPredictions.length} critical issues may occur soon.`,
        duration: 8000
      });
    }

    if (report.summary.overallHealthScore < 50) {
      toast.error('System Health Alert', {
        description: `System health score is ${report.summary.overallHealthScore}%. Immediate action required.`,
        duration: 12000
      });
    }
  }

  // Utility methods
  private generateReportId(): string {
    return `analysis-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateClusterId(): string {
    return `cluster-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generatePredictionId(): string {
    return `prediction-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private countNewPatterns(patterns: ErrorPattern[]): number {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    return patterns.filter((p) => p.firstOccurrence > oneDayAgo).length;
  }

  private countResolvedPatterns(patterns: ErrorPattern[]): number {
    return patterns.filter((p) => p.isResolved).length;
  }

  private storeAnalysisReport(report: AnalysisReport): void {
    this.analysisHistory.unshift(report);

    // Keep only last 50 reports
    if (this.analysisHistory.length > 50) {
      this.analysisHistory = this.analysisHistory.slice(0, 50);
    }

    // Persist to localStorage
    try {
      localStorage.setItem('error_analysis_history', JSON.stringify(this.analysisHistory));
    } catch (error) {
      console.warn('[ANALYZER] Failed to persist analysis history:', error);
    }
  }

  private loadAnalysisHistory(): void {
    try {
      const stored = localStorage.getItem('error_analysis_history');
      if (stored) {
        this.analysisHistory = JSON.parse(stored);
      }
    } catch (error) {
      console.warn('[ANALYZER] Failed to load analysis history:', error);
    }
  }

  private updateClusters(clusters: ErrorCluster[]): void {
    this.clusters.clear();
    clusters.forEach((cluster) => {
      this.clusters.set(cluster.id, cluster);
    });
  }

  // Public API
  public getLatestReport(): AnalysisReport {
    return this.analysisHistory[0] || this.createEmptyReport();
  }

  public getAnalysisHistory(): AnalysisReport[] {
    return [...this.analysisHistory];
  }

  public getClusters(): ErrorCluster[] {
    return Array.from(this.clusters.values());
  }

  public getPredictions(): ErrorPrediction[] {
    return [...this.predictions];
  }

  public exportAnalysisData(): string {
    return JSON.stringify({
      timestamp: new Date().toISOString(),
      analysisHistory: this.analysisHistory,
      clusters: Array.from(this.clusters.values()),
      predictions: this.predictions
    }, null, 2);
  }

  private createEmptyReport(): AnalysisReport {
    return {
      id: 'empty',
      timestamp: new Date().toISOString(),
      summary: {
        totalErrors: 0,
        newPatterns: 0,
        resolvedPatterns: 0,
        criticalIssues: 0,
        overallHealthScore: 100
      },
      clusters: [],
      predictions: [],
      recommendations: {
        immediate: [],
        shortTerm: [],
        longTerm: []
      },
      trends: {
        errorRate: 'stable',
        averageResolutionTime: 'stable',
        userSatisfaction: 'stable'
      }
    };
  }
}

// Create singleton instance
export const automatedErrorAnalyzer = new AutomatedErrorAnalyzer();

// Export convenience functions
export const performErrorAnalysis = automatedErrorAnalyzer.performAnalysis.bind(automatedErrorAnalyzer);
export const getLatestAnalysisReport = automatedErrorAnalyzer.getLatestReport.bind(automatedErrorAnalyzer);
export const getErrorClusters = automatedErrorAnalyzer.getClusters.bind(automatedErrorAnalyzer);
export const getErrorPredictions = automatedErrorAnalyzer.getPredictions.bind(automatedErrorAnalyzer);