import { ErrorMetadata } from './comprehensiveErrorManager';

interface PerformanceConfig {
  maxCaptureTime: number;
  maxStackTraceDepth: number;
  maxContextSize: number;
  enableStackTraceSourceMap: boolean;
  enablePerformanceMetrics: boolean;
  batchSize: number;
  batchTimeout: number;
}

interface CaptureResult {
  success: boolean;
  errorId?: string;
  performanceImpact: number;
  warnings?: string[];
}

class OptimizedErrorCaptureService {
  private config: PerformanceConfig = {
    maxCaptureTime: 50, // 50ms max for error capture
    maxStackTraceDepth: 20,
    maxContextSize: 1024 * 10, // 10KB max context size
    enableStackTraceSourceMap: process.env.NODE_ENV === 'development',
    enablePerformanceMetrics: true,
    batchSize: 10,
    batchTimeout: 2000
  };

  private captureQueue: Array<{
    error: Error;
    metadata: Partial<ErrorMetadata>;
    timestamp: number;
    callback?: (result: CaptureResult) => void;
  }> = [];

  private batchTimer?: NodeJS.Timeout;
  private isProcessing = false;

  constructor(config?: Partial<PerformanceConfig>) {
    if (config) {
      this.config = { ...this.config, ...config };
    }

    this.startBatchProcessor();
  }

  public async captureError(
  error: Error,
  metadata: Partial<ErrorMetadata> = {},
  callback?: (result: CaptureResult) => void)
  : Promise<CaptureResult> {
    const startTime = performance.now();

    try {
      // Quick validation
      if (!error || typeof error !== 'object') {
        return {
          success: false,
          performanceImpact: performance.now() - startTime,
          warnings: ['Invalid error object provided']
        };
      }

      // Optimize error capture
      const optimizedCapture = this.optimizeErrorCapture(error, metadata);

      // Add to queue for batch processing
      this.addToQueue({
        error,
        metadata: optimizedCapture.metadata,
        timestamp: Date.now(),
        callback
      });

      return {
        success: true,
        errorId: optimizedCapture.errorId,
        performanceImpact: performance.now() - startTime,
        warnings: optimizedCapture.warnings
      };
    } catch (captureError) {
      console.warn('Error in optimized error capture:', captureError);

      return {
        success: false,
        performanceImpact: performance.now() - startTime,
        warnings: ['Error capture failed due to internal error']
      };
    }
  }

  private optimizeErrorCapture(error: Error, metadata: Partial<ErrorMetadata>) {
    const warnings: string[] = [];
    let optimizedMetadata = { ...metadata };

    // Optimize stack trace
    if (error.stack) {
      const stackLines = error.stack.split('\n');
      if (stackLines.length > this.config.maxStackTraceDepth) {
        optimizedMetadata.stackTrace = stackLines.
        slice(0, this.config.maxStackTraceDepth).
        join('\n') + '\n... (truncated)';
        warnings.push(`Stack trace truncated to ${this.config.maxStackTraceDepth} lines`);
      } else {
        optimizedMetadata.stackTrace = error.stack;
      }
    }

    // Optimize context size
    if (metadata.context) {
      const contextStr = JSON.stringify(metadata.context);
      if (contextStr.length > this.config.maxContextSize) {
        try {
          // Try to truncate large context objects
          const truncatedContext = this.truncateContext(metadata.context);
          optimizedMetadata.context = truncatedContext;
          warnings.push('Context truncated due to size limit');
        } catch (truncateError) {
          optimizedMetadata.context = {
            error: 'Context too large to serialize',
            originalSize: contextStr.length
          };
          warnings.push('Context replaced due to serialization error');
        }
      }
    }

    // Add performance metrics if enabled
    if (this.config.enablePerformanceMetrics) {
      optimizedMetadata.performance = {
        ...optimizedMetadata.performance,
        memory: this.getMemoryUsage(),
        timing: performance.now()
      };
    }

    // Generate optimized error ID
    const errorId = this.generateOptimizedErrorId();

    return {
      errorId,
      metadata: optimizedMetadata,
      warnings
    };
  }

  private truncateContext(context: any, maxDepth = 3, currentDepth = 0): any {
    if (currentDepth >= maxDepth) {
      return '[Truncated: Max depth reached]';
    }

    if (context === null || typeof context !== 'object') {
      return context;
    }

    if (Array.isArray(context)) {
      const truncatedArray = context.slice(0, 10); // Max 10 array items
      return truncatedArray.map((item) =>
      this.truncateContext(item, maxDepth, currentDepth + 1)
      );
    }

    const truncatedObj: any = {};
    let count = 0;
    const maxProps = 20; // Max 20 properties per object

    for (const [key, value] of Object.entries(context)) {
      if (count >= maxProps) {
        truncatedObj['...'] = `${Object.keys(context).length - maxProps} more properties`;
        break;
      }

      // Skip functions and complex objects
      if (typeof value === 'function') {
        truncatedObj[key] = '[Function]';
      } else if (value instanceof Error) {
        truncatedObj[key] = {
          name: value.name,
          message: value.message
        };
      } else if (value instanceof Date) {
        truncatedObj[key] = value.toISOString();
      } else {
        truncatedObj[key] = this.truncateContext(value, maxDepth, currentDepth + 1);
      }

      count++;
    }

    return truncatedObj;
  }

  private addToQueue(item: {
    error: Error;
    metadata: Partial<ErrorMetadata>;
    timestamp: number;
    callback?: (result: CaptureResult) => void;
  }): void {
    this.captureQueue.push(item);

    // Process immediately if queue is full
    if (this.captureQueue.length >= this.config.batchSize) {
      this.processBatch();
    } else if (!this.batchTimer) {
      // Set timer for batch processing
      this.batchTimer = setTimeout(() => {
        this.processBatch();
      }, this.config.batchTimeout);
    }
  }

  private startBatchProcessor(): void {
    // Use requestIdleCallback for non-critical processing if available
    const processWhenIdle = () => {
      if (this.captureQueue.length > 0 && !this.isProcessing) {
        this.processBatch();
      }

      // Schedule next check
      if ('requestIdleCallback' in window) {
        requestIdleCallback(processWhenIdle, { timeout: 5000 });
      } else {
        setTimeout(processWhenIdle, 1000);
      }
    };

    processWhenIdle();
  }

  private async processBatch(): Promise<void> {
    if (this.isProcessing || this.captureQueue.length === 0) {
      return;
    }

    this.isProcessing = true;

    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = undefined;
    }

    const batch = this.captureQueue.splice(0, this.config.batchSize);

    try {
      // Process batch asynchronously
      await this.processBatchAsync(batch);
    } catch (error) {
      console.warn('Error processing error batch:', error);
    } finally {
      this.isProcessing = false;
    }
  }

  private async processBatchAsync(batch: Array<{
    error: Error;
    metadata: Partial<ErrorMetadata>;
    timestamp: number;
    callback?: (result: CaptureResult) => void;
  }>): Promise<void> {
    const processPromises = batch.map(async (item) => {
      try {
        const startTime = performance.now();

        // Process individual error (would integrate with comprehensiveErrorManager here)
        const errorId = await this.processIndividualError(item.error, item.metadata);

        const result: CaptureResult = {
          success: true,
          errorId,
          performanceImpact: performance.now() - startTime
        };

        // Call callback if provided
        if (item.callback) {
          item.callback(result);
        }

        return result;
      } catch (error) {
        const result: CaptureResult = {
          success: false,
          performanceImpact: 0,
          warnings: ['Failed to process error in batch']
        };

        if (item.callback) {
          item.callback(result);
        }

        return result;
      }
    });

    // Process all errors concurrently
    await Promise.allSettled(processPromises);
  }

  private async processIndividualError(
  error: Error,
  metadata: Partial<ErrorMetadata>)
  : Promise<string> {
    // This would integrate with the comprehensive error manager
    // For now, return a mock error ID
    return `opt_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  }

  private generateOptimizedErrorId(): string {
    // Optimized ID generation using timestamp and random
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 6);
    return `${timestamp}_${random}`;
  }

  private getMemoryUsage(): number {
    try {
      if ('memory' in performance) {
        return (performance as any).memory.usedJSHeapSize;
      }
    } catch (error) {








      // Silent fail
    }return 0;} // Public configuration methods
  public updateConfig(newConfig: Partial<PerformanceConfig>): void {this.config = { ...this.config, ...newConfig };}public getConfig(): PerformanceConfig {
    return { ...this.config };
  }

  public getQueueStats() {
    return {
      queueSize: this.captureQueue.length,
      isProcessing: this.isProcessing,
      batchSize: this.config.batchSize
    };
  }

  public flush(): Promise<void> {
    return new Promise((resolve) => {
      if (this.captureQueue.length === 0) {
        resolve();
        return;
      }

      const originalCallback = () => resolve();
      this.processBatch().then(originalCallback).catch(originalCallback);
    });
  }
}

export const optimizedErrorCaptureService = new OptimizedErrorCaptureService();
export default optimizedErrorCaptureService;
export type { PerformanceConfig, CaptureResult };