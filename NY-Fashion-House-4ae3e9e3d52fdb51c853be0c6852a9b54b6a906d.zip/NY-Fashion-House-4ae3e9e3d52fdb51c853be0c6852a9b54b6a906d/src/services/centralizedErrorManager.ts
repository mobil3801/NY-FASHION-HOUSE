// Centralized Error Manager - Production-ready unified error handling system
import { comprehensiveErrorTrackingService, ComprehensiveErrorReport } from '@/services/comprehensiveErrorTrackingService';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import { ErrorContext } from '@/types/errorTypes';
import { toast } from 'sonner';

export interface ErrorManagerConfig {
  // Performance optimizations
  enableBatching: boolean;
  batchSize: number;
  batchDelay: number;
  enableThrottling: boolean;
  throttleWindow: number;
  maxErrorsPerWindow: number;

  // Reporting settings
  enableDevMode: boolean;
  enableProductionReporting: boolean;
  enableUserNotifications: boolean;
  enableAutomaticRetry: boolean;

  // Storage and persistence
  enableLocalStorage: boolean;
  maxStoredErrors: number;
  autoCleanupInterval: number;

  // Analytics and monitoring
  enablePatternDetection: boolean;
  patternAnalysisInterval: number;
  enablePerformanceMonitoring: boolean;
}

export interface ErrorPattern {
  id: string;
  pattern: string;
  frequency: number;
  firstOccurrence: string;
  lastOccurrence: string;
  category: string;
  severity: string;
  affectedUsers: number;
  recommendedAction: string;
  isResolved: boolean;
}

export interface PerformanceMetrics {
  errorProcessingTime: number;
  memoryUsage: number;
  batchProcessingTime: number;
  totalErrorsProcessed: number;
  averageErrorSize: number;
  errorRate: number;
}

class CentralizedErrorManager {
  private config: ErrorManagerConfig;
  private errorQueue: Array<{error: Error | string;context: ErrorContext;timestamp: number;}> = [];
  private batchTimer: NodeJS.Timeout | null = null;
  private throttleTracker: Map<string, {count: number;windowStart: number;}> = new Map();
  private patterns: Map<string, ErrorPattern> = new Map();
  private performanceMetrics: PerformanceMetrics;
  private isInitialized = false;

  constructor(config?: Partial<ErrorManagerConfig>) {
    this.config = {
      // Performance optimizations
      enableBatching: true,
      batchSize: 10,
      batchDelay: 2000,
      enableThrottling: true,
      throttleWindow: 60000, // 1 minute
      maxErrorsPerWindow: 100,

      // Reporting settings
      enableDevMode: process.env.NODE_ENV === 'development',
      enableProductionReporting: process.env.NODE_ENV === 'production',
      enableUserNotifications: true,
      enableAutomaticRetry: true,

      // Storage and persistence
      enableLocalStorage: true,
      maxStoredErrors: 500,
      autoCleanupInterval: 300000, // 5 minutes

      // Analytics and monitoring
      enablePatternDetection: true,
      patternAnalysisInterval: 600000, // 10 minutes
      enablePerformanceMonitoring: true,

      ...config
    };

    this.performanceMetrics = {
      errorProcessingTime: 0,
      memoryUsage: 0,
      batchProcessingTime: 0,
      totalErrorsProcessed: 0,
      averageErrorSize: 0,
      errorRate: 0
    };

    this.initialize();
  }

  private initialize(): void {
    if (this.isInitialized) return;

    // Start periodic tasks
    if (this.config.autoCleanupInterval > 0) {
      setInterval(() => this.performMaintenance(), this.config.autoCleanupInterval);
    }

    if (this.config.enablePatternDetection && this.config.patternAnalysisInterval > 0) {
      setInterval(() => this.analyzeErrorPatterns(), this.config.patternAnalysisInterval);
    }

    // Performance monitoring
    if (this.config.enablePerformanceMonitoring) {
      setInterval(() => this.updatePerformanceMetrics(), 30000); // Every 30 seconds
    }

    // Load existing patterns and data
    this.loadStoredData();

    this.isInitialized = true;
    console.log('[CENTRALIZED ERROR MANAGER] Initialized with config:', this.config);
  }

  // Main error logging method with performance optimizations
  public async logError(
  error: Error | string,
  context: ErrorContext = {})
  : Promise<string> {
    const startTime = performance.now();

    try {
      const errorObj = typeof error === 'string' ? new Error(error) : error;
      const errorKey = this.generateErrorKey(errorObj, context);

      // Throttling check
      if (this.config.enableThrottling && this.shouldThrottleError(errorKey)) {
        console.warn('[ERROR MANAGER] Error throttled:', errorKey);
        return 'throttled';
      }

      // Add to batch queue if batching is enabled
      if (this.config.enableBatching) {
        this.addToErrorQueue(errorObj, context);
        return 'queued';
      }

      // Process immediately if batching is disabled
      return await this.processError(errorObj, context);
    } catch (processingError) {
      console.error('[ERROR MANAGER] Failed to log error:', processingError);
      // Fallback to direct logging
      return await comprehensiveErrorTrackingService.logError(error, context);
    } finally {
      const processingTime = performance.now() - startTime;
      this.performanceMetrics.errorProcessingTime =
      (this.performanceMetrics.errorProcessingTime + processingTime) / 2;
    }
  }

  private generateErrorKey(error: Error, context: ErrorContext): string {
    return `${error.name}:${error.message}:${context.component || 'unknown'}`;
  }

  private shouldThrottleError(errorKey: string): boolean {
    const now = Date.now();
    const tracker = this.throttleTracker.get(errorKey);

    if (!tracker) {
      this.throttleTracker.set(errorKey, { count: 1, windowStart: now });
      return false;
    }

    // Reset window if expired
    if (now - tracker.windowStart > this.config.throttleWindow) {
      tracker.count = 1;
      tracker.windowStart = now;
      return false;
    }

    // Check if within limits
    if (tracker.count >= this.config.maxErrorsPerWindow) {
      return true;
    }

    tracker.count++;
    return false;
  }

  private addToErrorQueue(error: Error, context: ErrorContext): void {
    this.errorQueue.push({
      error,
      context,
      timestamp: Date.now()
    });

    // Process batch if queue is full
    if (this.errorQueue.length >= this.config.batchSize) {
      this.processBatch();
      return;
    }

    // Set timer for batch processing if not already set
    if (!this.batchTimer) {
      this.batchTimer = setTimeout(() => {
        this.processBatch();
      }, this.config.batchDelay);
    }
  }

  private async processBatch(): Promise<void> {
    if (this.errorQueue.length === 0) return;

    const batchStartTime = performance.now();
    const batch = [...this.errorQueue];
    this.errorQueue = [];

    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = null;
    }

    try {
      // Process errors in parallel for better performance
      const processingPromises = batch.map(({ error, context }) =>
      this.processError(error, context).catch((err) => {
        console.warn('[ERROR MANAGER] Failed to process batched error:', err);
        return null;
      })
      );

      await Promise.all(processingPromises);

      console.log(`[ERROR MANAGER] Processed batch of ${batch.length} errors`);
    } catch (batchError) {
      console.error('[ERROR MANAGER] Batch processing failed:', batchError);

      // Re-queue failed errors for retry
      this.errorQueue.unshift(...batch);
    } finally {
      const batchProcessingTime = performance.now() - batchStartTime;
      this.performanceMetrics.batchProcessingTime =
      (this.performanceMetrics.batchProcessingTime + batchProcessingTime) / 2;
    }
  }

  private async processError(error: Error, context: ErrorContext): Promise<string> {
    try {
      // Enhanced context with performance data
      const enhancedContext: ErrorContext = {
        ...context,
        timestamp: new Date().toISOString(),
        sessionId: this.getSessionId(),
        performanceMetrics: this.config.enablePerformanceMonitoring ? {
          memoryUsage: this.getMemoryUsage(),
          errorRate: this.performanceMetrics.errorRate
        } : undefined
      };

      // Log to comprehensive tracking service
      const reportId = await comprehensiveErrorTrackingService.logError(error, enhancedContext);

      // Update metrics
      this.performanceMetrics.totalErrorsProcessed++;

      // Pattern detection
      if (this.config.enablePatternDetection) {
        this.updateErrorPattern(error, enhancedContext);
      }

      return reportId;
    } catch (processingError) {
      console.error('[ERROR MANAGER] Error processing failed:', processingError);
      throw processingError;
    }
  }

  private updateErrorPattern(error: Error, context: ErrorContext): void {
    const patternKey = this.generatePatternKey(error, context);
    const existing = this.patterns.get(patternKey);
    const now = new Date().toISOString();

    if (existing) {
      existing.frequency++;
      existing.lastOccurrence = now;
      existing.affectedUsers++; // Simplified - in real implementation, track unique users
    } else {
      const newPattern: ErrorPattern = {
        id: this.generatePatternId(),
        pattern: patternKey,
        frequency: 1,
        firstOccurrence: now,
        lastOccurrence: now,
        category: context.category || 'unknown',
        severity: context.severity || 'medium',
        affectedUsers: 1,
        recommendedAction: this.generateRecommendedAction(error, context),
        isResolved: false
      };

      this.patterns.set(patternKey, newPattern);
    }
  }

  private generatePatternKey(error: Error, context: ErrorContext): string {
    // Create a pattern key that groups similar errors
    const errorType = error.constructor.name;
    const component = context.component || 'unknown';
    const action = context.action || 'unknown';

    // Normalize error message to group similar messages
    const normalizedMessage = error.message.
    replace(/\d+/g, 'N') // Replace numbers with N
    .replace(/\b[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\b/gi, 'UUID') // Replace UUIDs
    .replace(/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g, 'IP') // Replace IP addresses
    .toLowerCase();

    return `${errorType}:${component}:${action}:${normalizedMessage}`;
  }

  private generatePatternId(): string {
    return `pattern-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateRecommendedAction(error: Error, context: ErrorContext): string {
    const message = error.message.toLowerCase();

    if (message.includes('network') || message.includes('fetch')) {
      return 'Check network connectivity and server availability';
    }

    if (message.includes('validation') || message.includes('invalid')) {
      return 'Review data validation rules and input formats';
    }

    if (message.includes('permission') || message.includes('unauthorized')) {
      return 'Verify user permissions and authentication status';
    }

    if (context.component) {
      return `Review ${context.component} component implementation`;
    }

    return 'Investigate error cause and implement appropriate fix';
  }

  private async analyzeErrorPatterns(): Promise<void> {
    console.log('[ERROR MANAGER] Analyzing error patterns...');

    const highFrequencyPatterns = Array.from(this.patterns.values()).
    filter((pattern) => pattern.frequency >= 5 && !pattern.isResolved).
    sort((a, b) => b.frequency - a.frequency);

    if (highFrequencyPatterns.length > 0) {
      console.warn('[ERROR MANAGER] High-frequency error patterns detected:',
      highFrequencyPatterns.slice(0, 3));

      // In a real implementation, you might:
      // 1. Send alerts to monitoring systems
      // 2. Create automated tickets
      // 3. Trigger emergency responses
      // 4. Notify development teams

      if (this.config.enableUserNotifications) {
        toast.warning('System Monitoring Alert', {
          description: `${highFrequencyPatterns.length} recurring error patterns detected. System administrators have been notified.`,
          duration: 8000
        });
      }
    }

    // Performance optimization: clean up old patterns
    this.cleanupOldPatterns();

    // Update performance metrics
    this.updatePerformanceMetrics();
  }

  private cleanupOldPatterns(): void {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

    for (const [key, pattern] of this.patterns.entries()) {
      if (pattern.lastOccurrence < oneWeekAgo && pattern.isResolved) {
        this.patterns.delete(key);
      }
    }
  }

  private performMaintenance(): void {
    console.log('[ERROR MANAGER] Performing maintenance...');

    // Clean up throttle tracker
    const now = Date.now();
    for (const [key, tracker] of this.throttleTracker.entries()) {
      if (now - tracker.windowStart > this.config.throttleWindow * 2) {
        this.throttleTracker.delete(key);
      }
    }

    // Update error rate
    const recentErrors = comprehensiveErrorTrackingService.getStatistics().recentErrors;
    this.performanceMetrics.errorRate = recentErrors / (this.config.throttleWindow / 1000 / 60); // errors per minute

    // Persist data
    if (this.config.enableLocalStorage) {
      this.persistData();
    }
  }

  private updatePerformanceMetrics(): void {
    if (!this.config.enablePerformanceMonitoring) return;

    this.performanceMetrics.memoryUsage = this.getMemoryUsage();

    const reports = comprehensiveErrorTrackingService.getErrorReports();
    if (reports.length > 0) {
      const totalSize = reports.reduce((sum, report) =>
      sum + JSON.stringify(report).length, 0);
      this.performanceMetrics.averageErrorSize = totalSize / reports.length;
    }
  }

  private getMemoryUsage(): number {
    if ('memory' in performance) {
      return (performance as any).memory.usedJSHeapSize;
    }
    return 0;
  }

  private getSessionId(): string {
    let sessionId = sessionStorage.getItem('error_manager_session_id');
    if (!sessionId) {
      sessionId = `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('error_manager_session_id', sessionId);
    }
    return sessionId;
  }

  private persistData(): void {
    try {
      const dataToStore = {
        patterns: Array.from(this.patterns.entries()),
        performanceMetrics: this.performanceMetrics,
        config: this.config,
        timestamp: Date.now()
      };

      localStorage.setItem('centralized_error_manager_data', JSON.stringify(dataToStore));
    } catch (error) {
      console.warn('[ERROR MANAGER] Failed to persist data:', error);
    }
  }

  private loadStoredData(): void {
    try {
      const stored = localStorage.getItem('centralized_error_manager_data');
      if (stored) {
        const data = JSON.parse(stored);

        // Restore patterns (only recent ones)
        const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000;
        if (data.timestamp > oneDayAgo) {
          this.patterns = new Map(data.patterns);
          if (data.performanceMetrics) {
            this.performanceMetrics = { ...this.performanceMetrics, ...data.performanceMetrics };
          }
        }
      }
    } catch (error) {
      console.warn('[ERROR MANAGER] Failed to load stored data:', error);
    }
  }

  // Public API methods
  public getErrorPatterns(): ErrorPattern[] {
    return Array.from(this.patterns.values()).sort((a, b) => b.frequency - a.frequency);
  }

  public getHighFrequencyPatterns(threshold: number = 5): ErrorPattern[] {
    return this.getErrorPatterns().filter((pattern) => pattern.frequency >= threshold);
  }

  public resolvePattern(patternId: string): boolean {
    for (const pattern of this.patterns.values()) {
      if (pattern.id === patternId) {
        pattern.isResolved = true;
        this.persistData();
        return true;
      }
    }
    return false;
  }

  public getPerformanceMetrics(): PerformanceMetrics {
    return { ...this.performanceMetrics };
  }

  public updateConfiguration(newConfig: Partial<ErrorManagerConfig>): void {
    this.config = { ...this.config, ...newConfig };
    console.log('[ERROR MANAGER] Configuration updated:', newConfig);
  }

  public exportDiagnosticData(): string {
    return JSON.stringify({
      timestamp: new Date().toISOString(),
      sessionId: this.getSessionId(),
      config: this.config,
      performanceMetrics: this.performanceMetrics,
      patterns: this.getErrorPatterns(),
      errorReports: comprehensiveErrorTrackingService.getErrorReports().slice(0, 50),
      statistics: comprehensiveErrorTrackingService.getStatistics()
    }, null, 2);
  }

  public async clearAllData(): Promise<void> {
    this.errorQueue = [];
    this.patterns.clear();
    this.throttleTracker.clear();

    if (this.batchTimer) {
      clearTimeout(this.batchTimer);
      this.batchTimer = null;
    }

    localStorage.removeItem('centralized_error_manager_data');
    comprehensiveErrorTrackingService.clearAllErrors();

    console.log('[ERROR MANAGER] All data cleared');
  }

  // Integration methods for existing components
  public createErrorBoundaryHandler(component: string) {
    return async (error: Error, errorInfo: React.ErrorInfo) => {
      await this.logError(error, {
        category: 'client',
        severity: 'critical',
        component,
        action: 'React Error Boundary Triggered',
        componentStack: errorInfo.componentStack,
        additionalData: { errorInfo }
      });
    };
  }

  public createApiErrorHandler(endpoint: string, method: string = 'GET') {
    return async (error: any, requestData?: any) => {
      await this.logError(error, {
        category: 'network',
        severity: error.status >= 500 ? 'high' : 'medium',
        action: `${method} ${endpoint}`,
        operation: 'API Request',
        requestDetails: {
          url: endpoint,
          method,
          body: requestData
        },
        additionalData: {
          statusCode: error.status,
          statusText: error.statusText
        }
      });
    };
  }
}

// Create singleton instance with optimized default configuration
export const centralizedErrorManager = new CentralizedErrorManager({
  enableBatching: true,
  batchSize: 15,
  batchDelay: 1500,
  enableThrottling: true,
  maxErrorsPerWindow: 50,
  enablePatternDetection: true,
  enablePerformanceMonitoring: true
});

// Export convenience functions
export const logError = centralizedErrorManager.logError.bind(centralizedErrorManager);
export const getErrorPatterns = centralizedErrorManager.getErrorPatterns.bind(centralizedErrorManager);
export const getPerformanceMetrics = centralizedErrorManager.getPerformanceMetrics.bind(centralizedErrorManager);
export const createErrorBoundaryHandler = centralizedErrorManager.createErrorBoundaryHandler.bind(centralizedErrorManager);
export const createApiErrorHandler = centralizedErrorManager.createApiErrorHandler.bind(centralizedErrorManager);