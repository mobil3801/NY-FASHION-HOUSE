import {
  Account,
  AccountType,
  JournalEntry,
  TransactionEntry,
  TransactionSource,
  FinancialReport,
  ReportType,
  ReportPeriod,
  ProfitLossData,
  BalanceSheetData,
  CashFlowData,
  AccountBalance,
  TransactionSearchFilters } from
'@/types/accounting';

// Database table IDs
const ACCOUNTS_TABLE_ID = 38570;
const JOURNAL_ENTRIES_TABLE_ID = 38571;
const JOURNAL_ENTRY_LINES_TABLE_ID = 38572;

class AccountingService {
  constructor() {
    this.initializeDefaultAccounts();
  }

  private async initializeDefaultAccounts() {
    try {
      // Check if accounts already exist
      const existingAccounts = await this.getAccounts();
      if (existingAccounts.length > 0) {
        return; // Accounts already initialized
      }

      const defaultAccounts = [
      // Assets
      { code: '1000', name: 'Cash', type: AccountType.ASSET, isActive: true, balance: 0 },
      { code: '1100', name: 'Accounts Receivable', type: AccountType.ASSET, isActive: true, balance: 0 },
      { code: '1200', name: 'Inventory', type: AccountType.ASSET, isActive: true, balance: 0 },
      { code: '1300', name: 'Equipment', type: AccountType.ASSET, isActive: true, balance: 0 },

      // Liabilities
      { code: '2000', name: 'Accounts Payable', type: AccountType.LIABILITY, isActive: true, balance: 0 },
      { code: '2100', name: 'Salaries Payable', type: AccountType.LIABILITY, isActive: true, balance: 0 },
      { code: '2200', name: 'Taxes Payable', type: AccountType.LIABILITY, isActive: true, balance: 0 },

      // Equity
      { code: '3000', name: 'Owner Equity', type: AccountType.EQUITY, isActive: true, balance: 0 },
      { code: '3100', name: 'Retained Earnings', type: AccountType.EQUITY, isActive: true, balance: 0 },

      // Income
      { code: '4000', name: 'Sales Revenue', type: AccountType.INCOME, isActive: true, balance: 0 },
      { code: '4100', name: 'Service Revenue', type: AccountType.INCOME, isActive: true, balance: 0 },

      // Expenses
      { code: '5000', name: 'Cost of Goods Sold', type: AccountType.EXPENSE, isActive: true, balance: 0 },
      { code: '5100', name: 'Salary Expense', type: AccountType.EXPENSE, isActive: true, balance: 0 },
      { code: '5200', name: 'Rent Expense', type: AccountType.EXPENSE, isActive: true, balance: 0 },
      { code: '5300', name: 'Utilities Expense', type: AccountType.EXPENSE, isActive: true, balance: 0 },
      { code: '5400', name: 'Office Supplies', type: AccountType.EXPENSE, isActive: true, balance: 0 }];


      const now = new Date().toISOString();
      for (const account of defaultAccounts) {
        await window.ezsite.apis.tableCreate(ACCOUNTS_TABLE_ID, {
          code: account.code,
          name: account.name,
          account_type: account.type,
          balance: account.balance,
          is_active: account.isActive,
          created_at: now,
          updated_at: now
        });
      }
    } catch (error) {
      console.error('Error initializing default accounts:', error);
    }
  }

  // Account Management
  async getAccounts(): Promise<Account[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(ACCOUNTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'code',
        IsAsc: true,
        Filters: []
      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        code: record.code || '',
        name: record.name || '',
        type: record.account_type || AccountType.ASSET,
        balance: record.balance || 0,
        isActive: record.is_active !== false,
        createdAt: record.created_at || new Date().toISOString(),
        updatedAt: record.updated_at || new Date().toISOString()
      })) || [];
    } catch (error) {
      console.error('Error fetching accounts:', error);
      return [];
    }
  }

  async getAccountsByType(type: AccountType): Promise<Account[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(ACCOUNTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'code',
        IsAsc: true,
        Filters: [
        { name: 'account_type', op: 'Equal', value: type },
        { name: 'is_active', op: 'Equal', value: true }]

      });

      if (error) throw new Error(error);

      return data?.List?.map((record: any) => ({
        id: record.id?.toString() || '',
        code: record.code || '',
        name: record.name || '',
        type: record.account_type || AccountType.ASSET,
        balance: record.balance || 0,
        isActive: record.is_active !== false,
        createdAt: record.created_at || new Date().toISOString(),
        updatedAt: record.updated_at || new Date().toISOString()
      })) || [];
    } catch (error) {
      console.error('Error fetching accounts by type:', error);
      return [];
    }
  }

  async getAccountById(id: string): Promise<Account | null> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(ACCOUNTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        Filters: [
        { name: 'id', op: 'Equal', value: parseInt(id) }]

      });

      if (error) throw new Error(error);

      const record = data?.List?.[0];
      if (!record) return null;

      return {
        id: record.id?.toString() || '',
        code: record.code || '',
        name: record.name || '',
        type: record.account_type || AccountType.ASSET,
        balance: record.balance || 0,
        isActive: record.is_active !== false,
        createdAt: record.created_at || new Date().toISOString(),
        updatedAt: record.updated_at || new Date().toISOString()
      };
    } catch (error) {
      console.error('Error fetching account by ID:', error);
      return null;
    }
  }

  async createAccount(accountData: Omit<Account, 'id' | 'createdAt' | 'updatedAt'>): Promise<Account> {
    try {
      const now = new Date().toISOString();

      const { error } = await window.ezsite.apis.tableCreate(ACCOUNTS_TABLE_ID, {
        code: accountData.code,
        name: accountData.name,
        account_type: accountData.type,
        balance: accountData.balance,
        is_active: accountData.isActive,
        created_at: now,
        updated_at: now
      });

      if (error) throw new Error(error);

      // Fetch the created account
      const accounts = await this.getAccounts();
      const newAccount = accounts.find((acc) => acc.code === accountData.code);
      if (!newAccount) throw new Error('Failed to create account');

      return newAccount;
    } catch (error) {
      console.error('Error creating account:', error);
      throw error;
    }
  }

  async updateAccount(id: string, updates: Partial<Account>): Promise<Account> {
    try {
      const updateData: any = {
        ID: parseInt(id),
        updated_at: new Date().toISOString()
      };

      if (updates.code !== undefined) updateData.code = updates.code;
      if (updates.name !== undefined) updateData.name = updates.name;
      if (updates.type !== undefined) updateData.account_type = updates.type;
      if (updates.balance !== undefined) updateData.balance = updates.balance;
      if (updates.isActive !== undefined) updateData.is_active = updates.isActive;

      const { error } = await window.ezsite.apis.tableUpdate(ACCOUNTS_TABLE_ID, updateData);
      if (error) throw new Error(error);

      // Fetch the updated account
      const updatedAccount = await this.getAccountById(id);
      if (!updatedAccount) throw new Error('Account not found');

      return updatedAccount;
    } catch (error) {
      console.error('Error updating account:', error);
      throw error;
    }
  }

  // Journal Entry Management
  async createJournalEntry(entryData: Omit<JournalEntry, 'id' | 'createdAt' | 'updatedAt'>): Promise<JournalEntry> {
    try {
      // Validate double-entry bookkeeping
      const totalDebits = entryData.entries.reduce((sum, entry) => sum + entry.debitAmount, 0);
      const totalCredits = entryData.entries.reduce((sum, entry) => sum + entry.creditAmount, 0);

      if (Math.abs(totalDebits - totalCredits) > 0.01) {
        throw new Error('Journal entry must be balanced (debits must equal credits)');
      }

      const now = new Date().toISOString();

      // Create the journal entry
      const { error: journalError } = await window.ezsite.apis.tableCreate(JOURNAL_ENTRIES_TABLE_ID, {
        journal_date: entryData.date,
        reference: entryData.reference,
        description: entryData.description,
        total_amount: entryData.totalAmount,
        source: entryData.source,
        source_id: entryData.sourceId,
        created_by: entryData.createdBy,
        created_at: now,
        updated_at: now
      });

      if (journalError) throw new Error(journalError);

      // Get the created journal entry ID
      const { data: journalData, error: fetchError } = await window.ezsite.apis.tablePage(JOURNAL_ENTRIES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: [
        { name: 'reference', op: 'Equal', value: entryData.reference }]

      });

      if (fetchError || !journalData?.List?.[0]) {
        throw new Error('Failed to retrieve created journal entry');
      }

      const journalEntryId = journalData.List[0].id;

      // Create journal entry lines
      for (const entry of entryData.entries) {
        const { error: lineError } = await window.ezsite.apis.tableCreate(JOURNAL_ENTRY_LINES_TABLE_ID, {
          journal_entry_id: journalEntryId,
          account_id: parseInt(entry.accountId),
          debit_amount: entry.debitAmount,
          credit_amount: entry.creditAmount,
          description: entry.description
        });

        if (lineError) {
          console.error('Error creating journal entry line:', lineError);
        }
      }

      // Update account balances
      await this.updateAccountBalances(entryData.entries);

      // Return the created journal entry
      const journalEntry: JournalEntry = {
        id: journalEntryId.toString(),
        date: entryData.date,
        reference: entryData.reference,
        description: entryData.description,
        totalAmount: entryData.totalAmount,
        entries: entryData.entries.map((entry, index) => ({
          ...entry,
          id: `${journalEntryId}-${index}`,
          journalEntryId: journalEntryId.toString()
        })),
        source: entryData.source,
        sourceId: entryData.sourceId,
        createdBy: entryData.createdBy,
        createdAt: now,
        updatedAt: now
      };

      return journalEntry;
    } catch (error) {
      console.error('Error creating journal entry:', error);
      throw error;
    }
  }

  private async updateAccountBalances(entries: TransactionEntry[]): Promise<void> {
    for (const entry of entries) {
      try {
        const account = await this.getAccountById(entry.accountId);
        if (!account) continue;

        let balanceChange = 0;

        // Normal balance rules:
        // Assets and Expenses: Debit increases, Credit decreases
        // Liabilities, Equity, and Income: Credit increases, Debit decreases
        if (account.type === AccountType.ASSET || account.type === AccountType.EXPENSE) {
          balanceChange = entry.debitAmount - entry.creditAmount;
        } else {
          balanceChange = entry.creditAmount - entry.debitAmount;
        }

        await this.updateAccount(account.id, {
          balance: account.balance + balanceChange
        });
      } catch (error) {
        console.error('Error updating account balance:', error);
      }
    }
  }

  async getJournalEntries(filters?: TransactionSearchFilters): Promise<JournalEntry[]> {
    try {
      const queryFilters = [];

      if (filters) {
        if (filters.startDate) {
          queryFilters.push({ name: 'journal_date', op: 'GreaterThanOrEqual', value: filters.startDate });
        }
        if (filters.endDate) {
          queryFilters.push({ name: 'journal_date', op: 'LessThanOrEqual', value: filters.endDate });
        }
        if (filters.source) {
          queryFilters.push({ name: 'source', op: 'Equal', value: filters.source });
        }
        if (filters.reference) {
          queryFilters.push({ name: 'reference', op: 'StringContains', value: filters.reference });
        }
        if (filters.description) {
          queryFilters.push({ name: 'description', op: 'StringContains', value: filters.description });
        }
        if (filters.minAmount !== undefined) {
          queryFilters.push({ name: 'total_amount', op: 'GreaterThanOrEqual', value: filters.minAmount });
        }
        if (filters.maxAmount !== undefined) {
          queryFilters.push({ name: 'total_amount', op: 'LessThanOrEqual', value: filters.maxAmount });
        }
      }

      const { data, error } = await window.ezsite.apis.tablePage(JOURNAL_ENTRIES_TABLE_ID, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'journal_date',
        IsAsc: false,
        Filters: queryFilters
      });

      if (error) throw new Error(error);

      const journalEntries: JournalEntry[] = [];

      for (const record of data?.List || []) {
        // Get journal entry lines for this entry
        const { data: linesData, error: linesError } = await window.ezsite.apis.tablePage(JOURNAL_ENTRY_LINES_TABLE_ID, {
          PageNo: 1,
          PageSize: 100,
          Filters: [
          { name: 'journal_entry_id', op: 'Equal', value: record.id }]

        });

        let entries: TransactionEntry[] = [];
        if (!linesError && linesData?.List) {
          entries = await Promise.all(linesData.List.map(async (line: any) => {
            const account = await this.getAccountById(line.account_id?.toString());
            return {
              id: line.id?.toString() || '',
              journalEntryId: record.id?.toString() || '',
              accountId: line.account_id?.toString() || '',
              debitAmount: line.debit_amount || 0,
              creditAmount: line.credit_amount || 0,
              description: line.description || '',
              account
            };
          }));
        }

        journalEntries.push({
          id: record.id?.toString() || '',
          date: record.journal_date || '',
          reference: record.reference || '',
          description: record.description || '',
          totalAmount: record.total_amount || 0,
          entries,
          source: record.source || TransactionSource.MANUAL,
          sourceId: record.source_id,
          createdBy: record.created_by || '',
          createdAt: record.created_at || new Date().toISOString(),
          updatedAt: record.updated_at || new Date().toISOString()
        });
      }

      return journalEntries;
    } catch (error) {
      console.error('Error fetching journal entries:', error);
      return [];
    }
  }

  // Automated Entry Creation
  async createSalesEntry(saleData: {
    amount: number;
    date: string;
    reference: string;
    paymentMethod: 'cash' | 'credit';
    customerId?: string;
  }): Promise<JournalEntry> {
    const accounts = await this.getAccounts();
    const cashAccount = accounts.find((acc) => acc.code === '1000');
    const receivableAccount = accounts.find((acc) => acc.code === '1100');
    const revenueAccount = accounts.find((acc) => acc.code === '4000');

    if (!cashAccount || !receivableAccount || !revenueAccount) {
      throw new Error('Required accounts not found');
    }

    const entries: Omit<TransactionEntry, 'id' | 'journalEntryId'>[] = [
    {
      accountId: saleData.paymentMethod === 'cash' ? cashAccount.id : receivableAccount.id,
      debitAmount: saleData.amount,
      creditAmount: 0,
      description: `Sale - ${saleData.paymentMethod} payment`
    },
    {
      accountId: revenueAccount.id,
      debitAmount: 0,
      creditAmount: saleData.amount,
      description: 'Sales revenue'
    }];


    return this.createJournalEntry({
      date: saleData.date,
      reference: saleData.reference,
      description: `Sales transaction - ${saleData.reference}`,
      totalAmount: saleData.amount,
      entries,
      source: TransactionSource.SALES,
      sourceId: saleData.customerId,
      createdBy: 'system'
    });
  }

  async createSalaryEntry(salaryData: {
    amount: number;
    date: string;
    employeeId: string;
    employeeName: string;
  }): Promise<JournalEntry> {
    const accounts = await this.getAccounts();
    const cashAccount = accounts.find((acc) => acc.code === '1000');
    const salaryExpenseAccount = accounts.find((acc) => acc.code === '5100');

    if (!cashAccount || !salaryExpenseAccount) {
      throw new Error('Required accounts not found');
    }

    const entries: Omit<TransactionEntry, 'id' | 'journalEntryId'>[] = [
    {
      accountId: salaryExpenseAccount.id,
      debitAmount: salaryData.amount,
      creditAmount: 0,
      description: `Salary expense - ${salaryData.employeeName}`
    },
    {
      accountId: cashAccount.id,
      debitAmount: 0,
      creditAmount: salaryData.amount,
      description: `Salary payment - ${salaryData.employeeName}`
    }];


    return this.createJournalEntry({
      date: salaryData.date,
      reference: `SAL-${salaryData.employeeId}-${new Date(salaryData.date).getTime()}`,
      description: `Salary payment - ${salaryData.employeeName}`,
      totalAmount: salaryData.amount,
      entries,
      source: TransactionSource.SALARY,
      sourceId: salaryData.employeeId,
      createdBy: 'system'
    });
  }

  // Financial Reports
  async generateProfitLoss(period: ReportPeriod): Promise<ProfitLossData> {
    try {
      const { startDate, endDate } = this.getPeriodDates(period);
      const entries = await this.getJournalEntries({ startDate, endDate });

      const revenue: AccountBalance[] = [];
      const expenses: AccountBalance[] = [];

      // Get income and expense accounts
      const incomeAccounts = await this.getAccountsByType(AccountType.INCOME);
      const expenseAccounts = await this.getAccountsByType(AccountType.EXPENSE);

      // Calculate revenue balances
      for (const account of incomeAccounts) {
        const accountEntries = entries.flatMap((entry) =>
        entry.entries.filter((e) => e.accountId === account.id)
        );
        const balance = accountEntries.reduce((sum, entry) =>
        sum + (entry.creditAmount - entry.debitAmount), 0
        );

        if (balance !== 0) {
          revenue.push({
            accountId: account.id,
            accountName: account.name,
            accountCode: account.code,
            balance
          });
        }
      }

      // Calculate expense balances
      for (const account of expenseAccounts) {
        const accountEntries = entries.flatMap((entry) =>
        entry.entries.filter((e) => e.accountId === account.id)
        );
        const balance = accountEntries.reduce((sum, entry) =>
        sum + (entry.debitAmount - entry.creditAmount), 0
        );

        if (balance !== 0) {
          expenses.push({
            accountId: account.id,
            accountName: account.name,
            accountCode: account.code,
            balance
          });
        }
      }

      const totalRevenue = revenue.reduce((sum, item) => sum + item.balance, 0);
      const totalExpenses = expenses.reduce((sum, item) => sum + item.balance, 0);

      return {
        revenue,
        expenses,
        grossProfit: totalRevenue,
        netProfit: totalRevenue - totalExpenses
      };
    } catch (error) {
      console.error('Error generating profit & loss:', error);
      return {
        revenue: [],
        expenses: [],
        grossProfit: 0,
        netProfit: 0
      };
    }
  }

  async generateBalanceSheet(period: ReportPeriod): Promise<BalanceSheetData> {
    try {
      const assets: AccountBalance[] = [];
      const liabilities: AccountBalance[] = [];
      const equity: AccountBalance[] = [];

      // Get accounts by type
      const assetAccounts = await this.getAccountsByType(AccountType.ASSET);
      const liabilityAccounts = await this.getAccountsByType(AccountType.LIABILITY);
      const equityAccounts = await this.getAccountsByType(AccountType.EQUITY);

      // Calculate asset balances
      for (const account of assetAccounts) {
        if (account.balance !== 0) {
          assets.push({
            accountId: account.id,
            accountName: account.name,
            accountCode: account.code,
            balance: account.balance
          });
        }
      }

      // Calculate liability balances
      for (const account of liabilityAccounts) {
        if (account.balance !== 0) {
          liabilities.push({
            accountId: account.id,
            accountName: account.name,
            accountCode: account.code,
            balance: account.balance
          });
        }
      }

      // Calculate equity balances
      for (const account of equityAccounts) {
        if (account.balance !== 0) {
          equity.push({
            accountId: account.id,
            accountName: account.name,
            accountCode: account.code,
            balance: account.balance
          });
        }
      }

      const totalAssets = assets.reduce((sum, item) => sum + item.balance, 0);
      const totalLiabilities = liabilities.reduce((sum, item) => sum + item.balance, 0);
      const totalEquity = equity.reduce((sum, item) => sum + item.balance, 0);

      return {
        assets,
        liabilities,
        equity,
        totalAssets,
        totalLiabilities,
        totalEquity
      };
    } catch (error) {
      console.error('Error generating balance sheet:', error);
      return {
        assets: [],
        liabilities: [],
        equity: [],
        totalAssets: 0,
        totalLiabilities: 0,
        totalEquity: 0
      };
    }
  }

  private getPeriodDates(period: ReportPeriod): {startDate: string;endDate: string;} {
    const year = period.year;
    let startDate: Date;
    let endDate: Date;

    switch (period.type) {
      case 'monthly':
        const month = period.month || 1;
        startDate = new Date(year, month - 1, 1);
        endDate = new Date(year, month, 0);
        break;
      case 'quarterly':
        const quarter = period.quarter || 1;
        const quarterStartMonth = (quarter - 1) * 3;
        startDate = new Date(year, quarterStartMonth, 1);
        endDate = new Date(year, quarterStartMonth + 3, 0);
        break;
      case 'yearly':
        startDate = new Date(year, 0, 1);
        endDate = new Date(year, 11, 31);
        break;
      default:
        startDate = new Date(year, 0, 1);
        endDate = new Date(year, 11, 31);
    }

    return {
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    };
  }
}

export const accountingService = new AccountingService();