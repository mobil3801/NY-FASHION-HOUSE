import { Role, Permission, RolePermission, RoleStats, PermissionMatrix } from '@/types/role';

export const roleService = {
  // Role CRUD operations
  async getRoles(pageNo: number = 1, pageSize: number = 50): Promise<{data: Role[];total: number;}> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37707, {
        PageNo: pageNo,
        PageSize: pageSize,
        OrderByField: 'create_time',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);

      // Get user counts for each role
      const rolesWithCounts = await Promise.all(
        data.List.map(async (role: any) => {
          const userCountResponse = await window.ezsite.apis.tablePage(37706, {
            PageNo: 1,
            PageSize: 1,
            OrderByField: 'id',
            IsAsc: true,
            Filters: [{ name: 'role_id', op: 'Equal', value: role.id }]
          });

          return {
            ...role,
            userCount: userCountResponse.error ? 0 : userCountResponse.data.VirtualCount
          };
        })
      );

      return {
        data: rolesWithCounts,
        total: data.VirtualCount
      };
    } catch (error) {
      console.error('Error fetching roles:', error);
      throw error;
    }
  },

  async createRole(roleData: {name: string;remark: string;}): Promise<void> {
    try {
      // Generate unique code
      const code = roleData.name.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '') + '_' + Date.now();

      const { error } = await window.ezsite.apis.tableCreate(37707, {
        name: roleData.name,
        code: code,
        remark: roleData.remark || '',
        create_time: new Date().toISOString()
      });

      if (error) throw new Error(error);

      // Log audit trail
      await this.logAudit('CREATE_ROLE', `Created role: ${roleData.name}`);
    } catch (error) {
      console.error('Error creating role:', error);
      throw error;
    }
  },

  async updateRole(id: number, roleData: {name: string;remark: string;}): Promise<void> {
    try {
      const { error } = await window.ezsite.apis.tableUpdate(37707, {
        ID: id,
        name: roleData.name,
        remark: roleData.remark || ''
      });

      if (error) throw new Error(error);

      // Log audit trail
      await this.logAudit('UPDATE_ROLE', `Updated role ID: ${id}, Name: ${roleData.name}`);
    } catch (error) {
      console.error('Error updating role:', error);
      throw error;
    }
  },

  async deleteRole(id: number, roleName: string): Promise<void> {
    try {
      // Check if it's a protected role
      const roleResponse = await window.ezsite.apis.tablePage(37707, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'id',
        IsAsc: true,
        Filters: [{ name: 'ID', op: 'Equal', value: id }]
      });

      if (roleResponse.error) throw new Error(roleResponse.error);

      const role = roleResponse.data.List[0];
      if (role && (role.code === 'Administrator' || role.code === 'GeneralUser')) {
        throw new Error('Cannot delete system default roles');
      }

      // Check if role is in use
      const userCountResponse = await window.ezsite.apis.tablePage(37706, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'id',
        IsAsc: true,
        Filters: [{ name: 'role_id', op: 'Equal', value: id }]
      });

      if (!userCountResponse.error && userCountResponse.data.VirtualCount > 0) {
        throw new Error(`Cannot delete role: ${userCountResponse.data.VirtualCount} users are assigned to this role`);
      }

      // Delete role permissions first
      await this.clearRolePermissions(id);

      // Delete role
      const { error } = await window.ezsite.apis.tableDelete(37707, { ID: id });
      if (error) throw new Error(error);

      // Log audit trail
      await this.logAudit('DELETE_ROLE', `Deleted role: ${roleName} (ID: ${id})`);
    } catch (error) {
      console.error('Error deleting role:', error);
      throw error;
    }
  },

  // Permission operations
  async getPermissions(): Promise<Permission[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37728, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'sort_order',
        IsAsc: true,
        Filters: [{ name: 'is_active', op: 'Equal', value: true }]
      });

      if (error) throw new Error(error);
      return data.List;
    } catch (error) {
      console.error('Error fetching permissions:', error);
      throw error;
    }
  },

  async getRolePermissions(roleId: number): Promise<number[]> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37729, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'permission_id',
        IsAsc: true,
        Filters: [{ name: 'role_id', op: 'Equal', value: roleId }]
      });

      if (error) throw new Error(error);
      return data.List.map((rp: any) => rp.permission_id);
    } catch (error) {
      console.error('Error fetching role permissions:', error);
      return [];
    }
  },

  async updateRolePermissions(roleId: number, permissionIds: number[]): Promise<void> {
    try {
      // First, clear existing permissions
      await this.clearRolePermissions(roleId);

      // Add new permissions
      const currentUser = await window.ezsite.apis.getUserInfo();
      const grantedBy = currentUser.data?.Name || 'System';

      for (const permissionId of permissionIds) {
        await window.ezsite.apis.tableCreate(37729, {
          role_id: roleId,
          permission_id: permissionId,
          granted_at: new Date().toISOString(),
          granted_by: grantedBy
        });
      }

      // Log audit trail
      await this.logAudit('UPDATE_ROLE_PERMISSIONS', `Updated permissions for role ID: ${roleId}, Permissions: ${permissionIds.join(', ')}`);
    } catch (error) {
      console.error('Error updating role permissions:', error);
      throw error;
    }
  },

  async clearRolePermissions(roleId: number): Promise<void> {
    try {
      // Get existing permissions
      const { data, error } = await window.ezsite.apis.tablePage(37729, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'id',
        IsAsc: true,
        Filters: [{ name: 'role_id', op: 'Equal', value: roleId }]
      });

      if (error) return; // No existing permissions

      // Delete each permission
      for (const rp of data.List) {
        await window.ezsite.apis.tableDelete(37729, { ID: rp.id });
      }
    } catch (error) {
      console.error('Error clearing role permissions:', error);
      throw error;
    }
  },

  // Analytics and stats
  async getRoleStats(): Promise<RoleStats> {
    try {
      const [rolesResponse, usersResponse] = await Promise.all([
      window.ezsite.apis.tablePage(37707, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'id',
        IsAsc: true,
        Filters: []
      }),
      window.ezsite.apis.tablePage(37706, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'id',
        IsAsc: true,
        Filters: []
      })]
      );

      if (rolesResponse.error || usersResponse.error) {
        throw new Error(rolesResponse.error || usersResponse.error);
      }

      const roles = rolesResponse.data.List;
      const totalUsers = usersResponse.data.VirtualCount;

      // Get user count per role
      const roleUsageDistribution = await Promise.all(
        roles.map(async (role: any) => {
          const userCountResponse = await window.ezsite.apis.tablePage(37706, {
            PageNo: 1,
            PageSize: 1,
            OrderByField: 'id',
            IsAsc: true,
            Filters: [{ name: 'role_id', op: 'Equal', value: role.id }]
          });

          const userCount = userCountResponse.error ? 0 : userCountResponse.data.VirtualCount;

          return {
            roleName: role.name,
            userCount,
            percentage: totalUsers > 0 ? Math.round(userCount / totalUsers * 100) : 0
          };
        })
      );

      return {
        totalRoles: roles.length,
        totalUsers,
        activeRoles: roles.length, // All roles are considered active
        roleUsageDistribution
      };
    } catch (error) {
      console.error('Error getting role stats:', error);
      throw error;
    }
  },

  // User role assignment
  async assignUserRole(userId: number, roleId: number): Promise<void> {
    try {
      const { error } = await window.ezsite.apis.tableUpdate(37706, {
        ID: userId,
        role_id: roleId
      });

      if (error) throw new Error(error);

      // Log audit trail
      await this.logAudit('ASSIGN_USER_ROLE', `Assigned role ID: ${roleId} to user ID: ${userId}`);
    } catch (error) {
      console.error('Error assigning user role:', error);
      throw error;
    }
  },

  async getUsers(pageNo: number = 1, pageSize: number = 50): Promise<{data: any[];total: number;}> {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37706, {
        PageNo: pageNo,
        PageSize: pageSize,
        OrderByField: 'create_time',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);
      return { data: data.List, total: data.VirtualCount };
    } catch (error) {
      console.error('Error fetching users:', error);
      throw error;
    }
  },

  // Helper methods
  async logAudit(action: string, details: string): Promise<void> {
    try {
      const currentUser = await window.ezsite.apis.getUserInfo();
      const userId = currentUser.data?.ID || 'System';
      const userName = currentUser.data?.Name || 'System';

      await window.ezsite.apis.tableCreate(37723, {
        user_id: userId,
        user_name: userName,
        action: action,
        details: details,
        timestamp: new Date().toISOString(),
        ip_address: 'N/A'
      });
    } catch (error) {
      console.error('Error logging audit:', error);
    }
  }
};