import { ErrorMetadata, ErrorPattern } from './comprehensiveErrorManager';

interface PatternDetectionConfig {
  minFrequency: number;
  timeWindowHours: number;
  similarityThreshold: number;
  enableMachineLearning: boolean;
}

interface DetectedPattern {
  id: string;
  pattern: ErrorPattern;
  confidence: number;
  suggestedActions: string[];
  relatedErrors: ErrorMetadata[];
  trend: 'increasing' | 'decreasing' | 'stable';
}

interface PredictiveAnalysis {
  likelyNextErrors: Array<{
    errorType: string;
    probability: number;
    timeEstimate: string;
  }>;
  riskFactors: Array<{
    factor: string;
    impact: 'high' | 'medium' | 'low';
    description: string;
  }>;
  recommendations: Array<{
    priority: 'critical' | 'high' | 'medium' | 'low';
    action: string;
    expectedImpact: string;
  }>;
}

class AutomatedErrorPatternDetection {
  private config: PatternDetectionConfig = {
    minFrequency: 3,
    timeWindowHours: 24,
    similarityThreshold: 0.8,
    enableMachineLearning: true
  };

  private patterns: Map<string, DetectedPattern> = new Map();
  private analysisHistory: Array<{
    timestamp: Date;
    totalErrors: number;
    patterns: DetectedPattern[];
  }> = [];

  constructor(config?: Partial<PatternDetectionConfig>) {
    if (config) {
      this.config = { ...this.config, ...config };
    }
  }

  public analyzeErrors(errors: ErrorMetadata[]): DetectedPattern[] {
    const timeWindow = this.getTimeWindow();
    const recentErrors = errors.filter((error) => error.timestamp >= timeWindow);

    // Group errors by similarity
    const errorGroups = this.groupSimilarErrors(recentErrors);

    // Detect patterns in each group
    const detectedPatterns: DetectedPattern[] = [];

    for (const group of errorGroups) {
      if (group.length >= this.config.minFrequency) {
        const pattern = this.createPattern(group);
        if (pattern) {
          detectedPatterns.push(pattern);
        }
      }
    }

    // Update pattern history
    this.updatePatternHistory(detectedPatterns);

    // Store analysis
    this.analysisHistory.push({
      timestamp: new Date(),
      totalErrors: errors.length,
      patterns: detectedPatterns
    });

    // Keep only recent analysis history
    if (this.analysisHistory.length > 100) {
      this.analysisHistory = this.analysisHistory.slice(-100);
    }

    return detectedPatterns;
  }

  private getTimeWindow(): Date {
    const now = new Date();
    return new Date(now.getTime() - this.config.timeWindowHours * 60 * 60 * 1000);
  }

  private groupSimilarErrors(errors: ErrorMetadata[]): ErrorMetadata[][] {
    const groups: ErrorMetadata[][] = [];
    const processed = new Set<string>();

    for (const error of errors) {
      if (processed.has(error.id)) continue;

      const similarErrors = errors.filter((otherError) => {
        if (processed.has(otherError.id) || error.id === otherError.id) return false;
        return this.calculateSimilarity(error, otherError) >= this.config.similarityThreshold;
      });

      if (similarErrors.length > 0) {
        const group = [error, ...similarErrors];
        groups.push(group);

        // Mark all errors in this group as processed
        group.forEach((e) => processed.add(e.id));
      }
    }

    return groups;
  }

  private calculateSimilarity(error1: ErrorMetadata, error2: ErrorMetadata): number {
    let similarity = 0;
    let factors = 0;

    // Component similarity
    if (error1.component && error2.component) {
      similarity += error1.component === error2.component ? 1 : 0;
      factors++;
    }

    // Category similarity
    if (error1.category === error2.category) {
      similarity += 1;
    }
    factors++;

    // Level similarity
    if (error1.level === error2.level) {
      similarity += 0.5;
    }
    factors++;

    // Message similarity (using Levenshtein distance)
    const message1 = error1.context.message || '';
    const message2 = error2.context.message || '';
    const messageSimilarity = this.calculateMessageSimilarity(message1, message2);
    similarity += messageSimilarity;
    factors++;

    // Stack trace similarity (if available)
    if (error1.stackTrace && error2.stackTrace) {
      const stackSimilarity = this.calculateStackTraceSimilarity(error1.stackTrace, error2.stackTrace);
      similarity += stackSimilarity;
      factors++;
    }

    return factors > 0 ? similarity / factors : 0;
  }

  private calculateMessageSimilarity(message1: string, message2: string): number {
    // Normalize messages
    const normalize = (msg: string) => msg.
    toLowerCase().
    replace(/\d+/g, 'NUM').
    replace(/[^\w\s]/g, '').
    trim();

    const norm1 = normalize(message1);
    const norm2 = normalize(message2);

    if (norm1 === norm2) return 1;

    // Calculate word-level similarity
    const words1 = norm1.split(/\s+/);
    const words2 = norm2.split(/\s+/);

    const commonWords = words1.filter((word) => words2.includes(word));
    const totalWords = new Set([...words1, ...words2]).size;

    return totalWords > 0 ? commonWords.length / totalWords : 0;
  }

  private calculateStackTraceSimilarity(stack1: string, stack2: string): number {
    const lines1 = stack1.split('\n').slice(0, 5); // Compare top 5 stack frames
    const lines2 = stack2.split('\n').slice(0, 5);

    let commonLines = 0;
    const minLines = Math.min(lines1.length, lines2.length);

    for (let i = 0; i < minLines; i++) {
      // Extract function names and compare
      const func1 = this.extractFunctionName(lines1[i]);
      const func2 = this.extractFunctionName(lines2[i]);

      if (func1 && func2 && func1 === func2) {
        commonLines++;
      }
    }

    return minLines > 0 ? commonLines / minLines : 0;
  }

  private extractFunctionName(stackLine: string): string | null {
    const match = stackLine.match(/at\s+([^\s]+)/);
    return match ? match[1] : null;
  }

  private createPattern(errors: ErrorMetadata[]): DetectedPattern | null {
    if (errors.length === 0) return null;

    const firstError = errors[0];
    const id = `pattern_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;

    // Calculate trend
    const trend = this.calculateTrend(errors);

    // Generate suggested actions
    const suggestedActions = this.generateSuggestedActions(errors);

    // Calculate confidence based on frequency and consistency
    const confidence = Math.min(0.95, 0.5 + errors.length * 0.1 + this.calculateConsistency(errors) * 0.4);

    const pattern: ErrorPattern = {
      pattern: this.generatePatternSignature(errors),
      frequency: errors.length,
      lastOccurrence: errors.reduce((latest, error) =>
      error.timestamp > latest ? error.timestamp : latest, errors[0].timestamp),
      severity: this.calculatePatternSeverity(errors),
      components: [...new Set(errors.map((e) => e.component).filter(Boolean))],
      suggestedFix: suggestedActions[0] || 'Review error context and implement appropriate handling'
    };

    return {
      id,
      pattern,
      confidence,
      suggestedActions,
      relatedErrors: errors,
      trend
    };
  }

  private generatePatternSignature(errors: ErrorMetadata[]): string {
    const firstError = errors[0];
    const commonMessage = this.findCommonMessage(errors);
    const component = firstError.component || 'Unknown';

    return `${component}: ${commonMessage}`;
  }

  private findCommonMessage(errors: ErrorMetadata[]): string {
    const messages = errors.map((e) => e.context.message || '').filter(Boolean);
    if (messages.length === 0) return 'Unknown error';

    // Find the most common message pattern
    const messageCounts = messages.reduce((acc, msg) => {
      const normalized = msg.replace(/\d+/g, '[NUMBER]').replace(/['"]/g, '');
      acc[normalized] = (acc[normalized] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const mostCommon = Object.entries(messageCounts).
    sort(([, a], [, b]) => b - a)[0];

    return mostCommon ? mostCommon[0] : messages[0];
  }

  private calculateTrend(errors: ErrorMetadata[]): 'increasing' | 'decreasing' | 'stable' {
    if (errors.length < 3) return 'stable';

    const sortedErrors = errors.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    const midpoint = Math.floor(sortedErrors.length / 2);

    const firstHalf = sortedErrors.slice(0, midpoint).length;
    const secondHalf = sortedErrors.slice(midpoint).length;

    if (secondHalf > firstHalf * 1.2) return 'increasing';
    if (secondHalf < firstHalf * 0.8) return 'decreasing';
    return 'stable';
  }

  private calculateConsistency(errors: ErrorMetadata[]): number {
    if (errors.length < 2) return 1;

    const components = errors.map((e) => e.component).filter(Boolean);
    const categories = errors.map((e) => e.category);
    const levels = errors.map((e) => e.level);

    const componentConsistency = new Set(components).size === 1 ? 1 : 0.5;
    const categoryConsistency = new Set(categories).size === 1 ? 1 : 0.7;
    const levelConsistency = new Set(levels).size === 1 ? 1 : 0.8;

    return (componentConsistency + categoryConsistency + levelConsistency) / 3;
  }

  private calculatePatternSeverity(errors: ErrorMetadata[]): 'low' | 'medium' | 'high' | 'critical' {
    const hasCritical = errors.some((e) => e.level === 'critical');
    const hasErrors = errors.some((e) => e.level === 'error');
    const frequency = errors.length;

    if (hasCritical) return 'critical';
    if (hasErrors && frequency > 10) return 'critical';
    if (hasErrors && frequency > 5) return 'high';
    if (frequency > 3) return 'medium';
    return 'low';
  }

  private generateSuggestedActions(errors: ErrorMetadata[]): string[] {
    const actions = new Set<string>();
    const components = new Set(errors.map((e) => e.component).filter(Boolean));
    const categories = new Set(errors.map((e) => e.category));

    // Component-specific actions
    if (components.size === 1) {
      const component = Array.from(components)[0];
      actions.add(`Review ${component} component implementation for error handling`);
      actions.add(`Add error boundary around ${component} component`);
    }

    // Category-specific actions
    categories.forEach((category) => {
      switch (category) {
        case 'network':
          actions.add('Implement retry logic with exponential backoff');
          actions.add('Add network connectivity checks');
          break;
        case 'api':
          actions.add('Review API endpoint error handling');
          actions.add('Implement proper API response validation');
          break;
        case 'ui':
          actions.add('Add input validation and error boundaries');
          actions.add('Review component lifecycle and state management');
          break;
        case 'performance':
          actions.add('Optimize component rendering performance');
          actions.add('Implement lazy loading and code splitting');
          break;
      }
    });

    // Frequency-based actions
    const frequency = errors.length;
    if (frequency > 10) {
      actions.add('This is a high-frequency error pattern requiring immediate attention');
      actions.add('Consider implementing monitoring alerts for this pattern');
    }

    return Array.from(actions).slice(0, 5); // Return top 5 actions
  }

  private updatePatternHistory(patterns: DetectedPattern[]): void {
    patterns.forEach((pattern) => {
      this.patterns.set(pattern.id, pattern);
    });

    // Clean up old patterns (keep last 50)
    if (this.patterns.size > 50) {
      const entries = Array.from(this.patterns.entries());
      const toKeep = entries.slice(-50);
      this.patterns.clear();
      toKeep.forEach(([id, pattern]) => this.patterns.set(id, pattern));
    }
  }

  public getPredictiveAnalysis(): PredictiveAnalysis {
    const recentAnalyses = this.analysisHistory.slice(-10);

    return {
      likelyNextErrors: this.predictNextErrors(recentAnalyses),
      riskFactors: this.identifyRiskFactors(recentAnalyses),
      recommendations: this.generateRecommendations(recentAnalyses)
    };
  }

  private predictNextErrors(analyses: typeof this.analysisHistory): PredictiveAnalysis['likelyNextErrors'] {
    const errorTypes = new Map<string, number>();

    analyses.forEach((analysis) => {
      analysis.patterns.forEach((pattern) => {
        const type = pattern.pattern.pattern.split(':')[0];
        errorTypes.set(type, (errorTypes.get(type) || 0) + 1);
      });
    });

    return Array.from(errorTypes.entries()).
    sort(([, a], [, b]) => b - a).
    slice(0, 3).
    map(([errorType, frequency]) => ({
      errorType,
      probability: Math.min(0.9, frequency / analyses.length),
      timeEstimate: frequency > 5 ? 'Within 1 hour' : 'Within 24 hours'
    }));
  }

  private identifyRiskFactors(analyses: typeof this.analysisHistory): PredictiveAnalysis['riskFactors'] {
    const factors: PredictiveAnalysis['riskFactors'] = [];

    // Trend analysis
    if (analyses.length >= 2) {
      const recent = analyses.slice(-2);
      const errorIncrease = recent[1].totalErrors - recent[0].totalErrors;

      if (errorIncrease > 10) {
        factors.push({
          factor: 'Rapid Error Increase',
          impact: 'high',
          description: `Error count increased by ${errorIncrease} in recent analysis`
        });
      }
    }

    // Pattern frequency
    const highFrequencyPatterns = analyses.
    flatMap((a) => a.patterns).
    filter((p) => p.pattern.frequency > 5);

    if (highFrequencyPatterns.length > 0) {
      factors.push({
        factor: 'High-Frequency Error Patterns',
        impact: 'high',
        description: `${highFrequencyPatterns.length} patterns with high frequency detected`
      });
    }

    return factors;
  }

  private generateRecommendations(analyses: typeof this.analysisHistory): PredictiveAnalysis['recommendations'] {
    const recommendations: PredictiveAnalysis['recommendations'] = [];

    // Critical patterns
    const criticalPatterns = analyses.
    flatMap((a) => a.patterns).
    filter((p) => p.pattern.severity === 'critical');

    if (criticalPatterns.length > 0) {
      recommendations.push({
        priority: 'critical',
        action: 'Address critical error patterns immediately',
        expectedImpact: 'Prevent system instability and improve user experience'
      });
    }

    // Increasing trends
    const increasingPatterns = analyses.
    flatMap((a) => a.patterns).
    filter((p) => p.trend === 'increasing');

    if (increasingPatterns.length > 0) {
      recommendations.push({
        priority: 'high',
        action: 'Investigate and fix increasing error trends',
        expectedImpact: 'Prevent errors from becoming critical issues'
      });
    }

    // General improvements
    recommendations.push({
      priority: 'medium',
      action: 'Implement comprehensive error monitoring and alerting',
      expectedImpact: 'Faster detection and resolution of issues'
    });

    return recommendations.slice(0, 5);
  }

  public getPatternHistory(): DetectedPattern[] {
    return Array.from(this.patterns.values());
  }

  public clearHistory(): void {
    this.patterns.clear();
    this.analysisHistory = [];
  }
}

export const automatedErrorPatternDetection = new AutomatedErrorPatternDetection();
export default automatedErrorPatternDetection;
export type { DetectedPattern, PredictiveAnalysis, PatternDetectionConfig };