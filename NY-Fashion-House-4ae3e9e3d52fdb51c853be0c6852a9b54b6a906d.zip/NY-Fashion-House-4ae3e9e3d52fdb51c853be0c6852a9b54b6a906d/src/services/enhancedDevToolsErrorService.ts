// Enhanced error service with DevTools integration
import { ErrorContext } from '@/types/errorTypes';
import { devToolsErrorCollector, DevToolsErrorDetails } from '@/utils/devToolsErrorCollector';
import { enhancedStackTraceParser, StackTraceAnalysis } from '@/utils/enhancedStackTraceParser';

export interface EnhancedErrorReport {
  id: string;
  timestamp: string;
  message: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;

  // DevTools enhanced information
  devToolsDetails: DevToolsErrorDetails;
  stackAnalysis: StackTraceAnalysis;
  errorLocation: string;
  componentContext: string[];

  // Original context
  context: ErrorContext;

  // Analysis and recommendations
  rootCause: string;
  recommendations: string[];
  isRecoverable: boolean;

  // Display formatting
  formattedStack: string;
  userFriendlyMessage: string;
}

class EnhancedDevToolsErrorService {
  private errorReports: EnhancedErrorReport[] = [];
  private readonly MAX_REPORTS = 100;
  private sessionId: string;

  constructor() {
    this.sessionId = this.generateSessionId();
    this.setupGlobalErrorHandling();
  }

  private generateSessionId(): string {
    return `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private setupGlobalErrorHandling(): void {
    // Enhanced global error handler
    window.addEventListener('error', async (event) => {
      if (event.error) {
        await this.logEnhancedError(event.error, {
          category: 'client',
          severity: 'high',
          action: 'Uncaught JavaScript Error',
          additionalData: {
            filename: event.filename,
            lineno: event.lineno,
            colno: event.colno
          }
        });
      }
    });

    // Enhanced promise rejection handler
    window.addEventListener('unhandledrejection', async (event) => {
      const error = event.reason instanceof Error ?
      event.reason :
      new Error(String(event.reason));

      await this.logEnhancedError(error, {
        category: 'client',
        severity: 'high',
        action: 'Unhandled Promise Rejection',
        additionalData: {
          promiseRejection: true,
          reason: event.reason
        }
      });
    });
  }

  public async logEnhancedError(
  error: Error,
  context: ErrorContext = {})
  : Promise<EnhancedErrorReport> {
    // Collect enhanced error details using DevTools
    const devToolsDetails = await devToolsErrorCollector.collectEnhancedErrorDetails(error);

    // Analyze the stack trace
    const stackAnalysis = enhancedStackTraceParser.analyzeStackTrace(devToolsDetails.parsedStack);

    // Generate error location and component context
    const errorLocation = enhancedStackTraceParser.getErrorLocation(stackAnalysis);
    const componentContext = enhancedStackTraceParser.getComponentContext(stackAnalysis);

    // Create enhanced error report
    const report: EnhancedErrorReport = {
      id: this.generateErrorId(),
      timestamp: new Date().toISOString(),
      message: error.message,
      severity: this.determineSeverity(error, context, stackAnalysis),
      category: context.category || this.determineCategory(stackAnalysis),

      devToolsDetails,
      stackAnalysis,
      errorLocation,
      componentContext,

      context: {
        ...context,
        sessionId: this.sessionId,
        url: window.location.href,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString()
      },

      rootCause: this.analyzeRootCause(error, stackAnalysis, context),
      recommendations: this.generateRecommendations(error, stackAnalysis, context),
      isRecoverable: this.determineRecoverability(error, stackAnalysis, context),

      formattedStack: this.formatStackForDisplay(devToolsDetails, stackAnalysis),
      userFriendlyMessage: this.generateUserFriendlyMessage(error, stackAnalysis)
    };

    // Store the report
    this.errorReports.unshift(report);
    if (this.errorReports.length > this.MAX_REPORTS) {
      this.errorReports = this.errorReports.slice(0, this.MAX_REPORTS);
    }

    // Log to console with enhanced formatting
    this.logToConsoleWithFormatting(report);

    // Store in localStorage for persistence
    this.persistErrorReport(report);

    return report;
  }

  private generateErrorId(): string {
    return `err-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private determineSeverity(
  error: Error,
  context: ErrorContext,
  stackAnalysis: StackTraceAnalysis)
  : 'low' | 'medium' | 'high' | 'critical' {
    // Use provided severity first
    if (context.severity) return context.severity;

    const errorMessage = error.message.toLowerCase();

    // Critical errors
    if (
    errorMessage.includes('uncaught') ||
    errorMessage.includes('script error') ||
    stackAnalysis.userCodeFrames.length === 0)
    {
      return 'critical';
    }

    // High severity errors
    if (
    errorMessage.includes('network') ||
    errorMessage.includes('failed to fetch') ||
    stackAnalysis.reactComponentChain.length > 0)
    {
      return 'high';
    }

    // Medium severity errors
    if (
    errorMessage.includes('validation') ||
    errorMessage.includes('invalid') ||
    stackAnalysis.userCodeFrames.length > 0)
    {
      return 'medium';
    }

    return 'low';
  }

  private determineCategory(stackAnalysis: StackTraceAnalysis): string {
    if (stackAnalysis.reactComponentChain.length > 0) {
      return 'client';
    }

    if (stackAnalysis.libraryFrames.length > stackAnalysis.userCodeFrames.length) {
      return 'library';
    }

    return 'application';
  }

  private analyzeRootCause(
  error: Error,
  stackAnalysis: StackTraceAnalysis,
  context: ErrorContext)
  : string {
    const errorMessage = error.message.toLowerCase();

    // Network issues
    if (errorMessage.includes('failed to fetch') || errorMessage.includes('network')) {
      return 'Network connectivity or server availability issue';
    }

    // React component issues
    if (stackAnalysis.reactComponentChain.length > 0) {
      const componentName = stackAnalysis.reactComponentChain[0]?.componentName;
      return `React component error in ${componentName || 'unknown component'}`;
    }

    // User code issues
    if (stackAnalysis.errorOrigin?.isUserCode) {
      return `Application logic error in ${stackAnalysis.errorOrigin.relativeFilePath}`;
    }

    // Library issues
    if (stackAnalysis.errorOrigin?.isLibraryCode) {
      return 'Third-party library error or compatibility issue';
    }

    return 'Unexpected error occurred during execution';
  }

  private generateRecommendations(
  error: Error,
  stackAnalysis: StackTraceAnalysis,
  context: ErrorContext)
  : string[] {
    const recommendations: string[] = [];
    const errorMessage = error.message.toLowerCase();

    // Network-related recommendations
    if (errorMessage.includes('failed to fetch') || errorMessage.includes('network')) {
      recommendations.push('Check network connectivity');
      recommendations.push('Verify API endpoint availability');
      recommendations.push('Implement retry logic for network requests');
    }

    // React component recommendations
    if (stackAnalysis.reactComponentChain.length > 0) {
      recommendations.push('Check component props and state management');
      recommendations.push('Verify component lifecycle methods');
      recommendations.push('Add error boundaries around problematic components');
    }

    // User code recommendations
    if (stackAnalysis.errorOrigin?.isUserCode) {
      recommendations.push(`Review code at ${stackAnalysis.errorOrigin.relativeFilePath}:${stackAnalysis.errorOrigin.originalFrame.lineNumber}`);
      recommendations.push('Add null checks and validation');
      recommendations.push('Implement proper error handling');
    }

    // General recommendations
    if (recommendations.length === 0) {
      recommendations.push('Review error details and stack trace');
      recommendations.push('Check browser console for additional information');
      recommendations.push('Consider updating dependencies if library-related');
    }

    return recommendations;
  }

  private determineRecoverability(
  error: Error,
  stackAnalysis: StackTraceAnalysis,
  context: ErrorContext)
  : boolean {
    const errorMessage = error.message.toLowerCase();

    // Non-recoverable errors
    if (
    errorMessage.includes('script error') ||
    errorMessage.includes('uncaught') ||
    stackAnalysis.libraryFrames.some((f) => f.fileName.includes('react')))
    {
      return false;
    }

    // Recoverable errors
    return true;
  }

  private formatStackForDisplay(
  devToolsDetails: DevToolsErrorDetails,
  stackAnalysis: StackTraceAnalysis)
  : string {
    let formatted = devToolsErrorCollector.formatErrorForDisplay(devToolsDetails);
    formatted += '\n' + enhancedStackTraceParser.formatAnalysisForDisplay(stackAnalysis);
    return formatted;
  }

  private generateUserFriendlyMessage(error: Error, stackAnalysis: StackTraceAnalysis): string {
    const errorMessage = error.message.toLowerCase();

    if (errorMessage.includes('failed to fetch') || errorMessage.includes('network')) {
      return 'Unable to connect to the server. Please check your internet connection and try again.';
    }

    if (stackAnalysis.reactComponentChain.length > 0) {
      const componentName = stackAnalysis.reactComponentChain[0]?.componentName;
      return `A problem occurred in the ${componentName || 'interface'} component. Please refresh the page and try again.`;
    }

    if (stackAnalysis.errorOrigin?.isUserCode) {
      return 'An application error occurred. Our development team has been notified and will investigate the issue.';
    }

    return 'An unexpected error occurred. Please try refreshing the page or contact support if the problem persists.';
  }

  private logToConsoleWithFormatting(report: EnhancedErrorReport): void {
    console.group(`🔥 [${report.id}] Enhanced Error Report`);
    console.error('Message:', report.message);
    console.error('Location:', report.errorLocation);
    console.error('Severity:', report.severity);

    if (report.componentContext.length > 0) {
      console.error('React Components:', report.componentContext.join(' → '));
    }

    console.error('Root Cause:', report.rootCause);
    console.error('Recommendations:', report.recommendations);
    console.error('Formatted Stack:', report.formattedStack);
    console.groupEnd();
  }

  private persistErrorReport(report: EnhancedErrorReport): void {
    try {
      const persistedReports = this.getPersistedReports();
      persistedReports.unshift(report);

      // Keep only last 20 reports in storage
      const limitedReports = persistedReports.slice(0, 20);

      localStorage.setItem('enhanced_error_reports', JSON.stringify(limitedReports));
    } catch (e) {
      console.warn('Failed to persist error report:', e);
    }
  }

  public getPersistedReports(): EnhancedErrorReport[] {
    try {
      const stored = localStorage.getItem('enhanced_error_reports');
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  }

  public getErrorReports(): EnhancedErrorReport[] {
    return [...this.errorReports];
  }

  public getErrorReport(id: string): EnhancedErrorReport | null {
    return this.errorReports.find((report) => report.id === id) || null;
  }

  public clearErrorReports(): void {
    this.errorReports = [];
    localStorage.removeItem('enhanced_error_reports');
  }

  public getErrorStatistics() {
    const reports = this.errorReports;

    return {
      total: reports.length,
      bySeverity: {
        critical: reports.filter((r) => r.severity === 'critical').length,
        high: reports.filter((r) => r.severity === 'high').length,
        medium: reports.filter((r) => r.severity === 'medium').length,
        low: reports.filter((r) => r.severity === 'low').length
      },
      byCategory: reports.reduce((acc, report) => {
        acc[report.category] = (acc[report.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      recentErrors: reports.filter((r) =>
      Date.now() - new Date(r.timestamp).getTime() < 60 * 60 * 1000
      ).length
    };
  }

  public exportErrorReports(): string {
    const allReports = [...this.errorReports, ...this.getPersistedReports()];
    return JSON.stringify(allReports, null, 2);
  }
}

export const enhancedDevToolsErrorService = new EnhancedDevToolsErrorService();