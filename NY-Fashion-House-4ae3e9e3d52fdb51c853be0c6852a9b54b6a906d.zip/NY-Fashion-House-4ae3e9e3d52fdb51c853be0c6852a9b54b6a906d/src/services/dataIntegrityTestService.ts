
export interface DataIntegrityTestResult {
  testId: string;
  testName: string;
  operation: 'create' | 'read' | 'update' | 'delete';
  tableId: number;
  tableName: string;
  status: 'passed' | 'failed' | 'error';
  details: {
    testData?: any;
    expectedResult?: any;
    actualResult?: any;
    errorMessage?: string;
    executionTime: number;
    validations: ValidationResult[];
  };
  timestamp: Date;
}

export interface ValidationResult {
  validation: string;
  passed: boolean;
  message: string;
  expected?: any;
  actual?: any;
}

export interface ReferentialIntegrityTest {
  parentTable: number;
  childTable: number;
  foreignKeyField: string;
  testResult: 'passed' | 'failed' | 'error';
  orphanedRecords: number;
  errorMessage?: string;
}

export interface DataCorruptionTest {
  testType: 'null_constraints' | 'data_types' | 'range_validation' | 'format_validation' | 'duplicate_detection';
  tableId: number;
  fieldName: string;
  corruptedRecords: number;
  totalRecords: number;
  corruptionPercentage: number;
  examples: any[];
}

class DataIntegrityTestService {
  private readonly TABLE_IDS = {
    PRODUCTS: 38157,
    SALES_TRANSACTIONS: 38156,
    EMPLOYEES: 37818,
    CUSTOMERS: null, // Will need to get the actual ID
    NOTIFICATIONS: 38282,
    TEST_SUITES: 38515,
    TEST_CASES: 38516,
    TEST_EXECUTIONS: 38517,
    TEST_RESULTS: 38518,
    AUTH_USERS: 37706,
    ROLES: 37707
  };

  // Run comprehensive data integrity tests
  async runComprehensiveDataIntegrityTests(): Promise<{
    crudTests: DataIntegrityTestResult[];
    referentialIntegrityTests: ReferentialIntegrityTest[];
    dataCorruptionTests: DataCorruptionTest[];
    summary: {
      totalTests: number;
      passed: number;
      failed: number;
      errors: number;
      executionTime: number;
    };
  }> {
    const startTime = Date.now();

    console.log('[DataIntegrityTestService] Starting comprehensive data integrity tests...');

    const [crudTests, referentialIntegrityTests, dataCorruptionTests] = await Promise.all([
    this.runAllCRUDTests(),
    this.runReferentialIntegrityTests(),
    this.runDataCorruptionTests()]
    );

    const allTests = [...crudTests, ...referentialIntegrityTests.map((t) => ({
      testId: `ref-integrity-${Date.now()}`,
      testName: `Referential Integrity Test - ${t.parentTable}->${t.childTable}`,
      operation: 'read' as const,
      tableId: t.parentTable,
      tableName: `Table_${t.parentTable}`,
      status: t.testResult,
      details: {
        errorMessage: t.errorMessage,
        executionTime: 0,
        validations: []
      },
      timestamp: new Date()
    }))];

    const summary = {
      totalTests: allTests.length,
      passed: allTests.filter((t) => t.status === 'passed').length,
      failed: allTests.filter((t) => t.status === 'failed').length,
      errors: allTests.filter((t) => t.status === 'error').length,
      executionTime: Date.now() - startTime
    };

    console.log('[DataIntegrityTestService] Data integrity tests completed:', summary);

    return {
      crudTests,
      referentialIntegrityTests,
      dataCorruptionTests,
      summary
    };
  }

  // Run CRUD tests for all tables
  async runAllCRUDTests(): Promise<DataIntegrityTestResult[]> {
    const results: DataIntegrityTestResult[] = [];

    // Test core business tables
    const tablesToTest = [
    { id: this.TABLE_IDS.PRODUCTS, name: 'products' },
    { id: this.TABLE_IDS.SALES_TRANSACTIONS, name: 'sales_transactions' },
    { id: this.TABLE_IDS.EMPLOYEES, name: 'employees' },
    { id: this.TABLE_IDS.NOTIFICATIONS, name: 'notifications' }];


    for (const table of tablesToTest) {
      if (table.id) {
        // Test Read operations
        const readTest = await this.testReadOperation(table.id, table.name);
        results.push(readTest);

        // Test Create operations
        const createTest = await this.testCreateOperation(table.id, table.name);
        results.push(createTest);

        // Test Update operations (only if create succeeded)
        if (createTest.status === 'passed' && createTest.details.actualResult) {
          const updateTest = await this.testUpdateOperation(table.id, table.name, createTest.details.actualResult);
          results.push(updateTest);

          // Test Delete operations (clean up created record)
          const deleteTest = await this.testDeleteOperation(table.id, table.name, createTest.details.actualResult);
          results.push(deleteTest);
        }
      }
    }

    return results;
  }

  // Test Read operation
  async testReadOperation(tableId: number, tableName: string): Promise<DataIntegrityTestResult> {
    const testId = `read-${tableName}-${Date.now()}`;
    const startTime = Date.now();
    const validations: ValidationResult[] = [];

    try {
      console.log(`[DataIntegrityTestService] Testing READ operation for ${tableName}`);

      const response = await window.ezsite.apis.tablePage(tableId, {
        PageNo: 1,
        PageSize: 10,
        OrderByField: 'id',
        IsAsc: false,
        Filters: []
      });

      const executionTime = Date.now() - startTime;

      // Validation: API response structure
      validations.push({
        validation: 'api_response_structure',
        passed: response.hasOwnProperty('data') && response.hasOwnProperty('error'),
        message: response.hasOwnProperty('data') ? 'API response structure is correct' : 'Invalid API response structure',
        expected: 'Response with data and error properties',
        actual: Object.keys(response).join(', ')
      });

      // Validation: No API error
      validations.push({
        validation: 'no_api_error',
        passed: !response.error,
        message: response.error ? `API error: ${response.error}` : 'No API error',
        expected: 'No error',
        actual: response.error || 'No error'
      });

      // Validation: Data structure
      if (response.data && response.data.List) {
        validations.push({
          validation: 'data_list_present',
          passed: Array.isArray(response.data.List),
          message: Array.isArray(response.data.List) ? 'Data list is an array' : 'Data list is not an array',
          expected: 'Array',
          actual: typeof response.data.List
        });

        // Validation: Record structure (if records exist)
        if (response.data.List.length > 0) {
          const firstRecord = response.data.List[0];
          validations.push({
            validation: 'record_has_id',
            passed: firstRecord.hasOwnProperty('id'),
            message: firstRecord.hasOwnProperty('id') ? 'Records have ID field' : 'Records missing ID field',
            expected: 'ID field present',
            actual: firstRecord.hasOwnProperty('id') ? 'ID present' : 'ID missing'
          });

          // Validation: Data consistency
          const hasConsistentStructure = this.validateRecordStructure(response.data.List);
          validations.push({
            validation: 'consistent_record_structure',
            passed: hasConsistentStructure,
            message: hasConsistentStructure ? 'All records have consistent structure' : 'Records have inconsistent structure',
            expected: 'Consistent structure across all records',
            actual: hasConsistentStructure ? 'Consistent' : 'Inconsistent'
          });
        }
      }

      const testPassed = validations.every((v) => v.passed);

      return {
        testId,
        testName: `READ operation - ${tableName}`,
        operation: 'read',
        tableId,
        tableName,
        status: testPassed ? 'passed' : 'failed',
        details: {
          actualResult: response.data,
          executionTime,
          validations
        },
        timestamp: new Date()
      };

    } catch (error) {
      const executionTime = Date.now() - startTime;

      return {
        testId,
        testName: `READ operation - ${tableName}`,
        operation: 'read',
        tableId,
        tableName,
        status: 'error',
        details: {
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          executionTime,
          validations
        },
        timestamp: new Date()
      };
    }
  }

  // Test Create operation
  async testCreateOperation(tableId: number, tableName: string): Promise<DataIntegrityTestResult> {
    const testId = `create-${tableName}-${Date.now()}`;
    const startTime = Date.now();
    const validations: ValidationResult[] = [];

    try {
      console.log(`[DataIntegrityTestService] Testing CREATE operation for ${tableName}`);

      const testData = this.generateTestData(tableName);

      const response = await window.ezsite.apis.tableCreate(tableId, testData);
      const executionTime = Date.now() - startTime;

      // Validation: No API error
      validations.push({
        validation: 'no_create_error',
        passed: !response.error,
        message: response.error ? `Create error: ${response.error}` : 'Record created successfully',
        expected: 'No error',
        actual: response.error || 'No error'
      });

      // Validation: Record ID returned
      if (!response.error && response.data) {
        validations.push({
          validation: 'record_id_returned',
          passed: typeof response.data === 'number' && response.data > 0,
          message: typeof response.data === 'number' ? 'Valid record ID returned' : 'Invalid or missing record ID',
          expected: 'Positive integer ID',
          actual: response.data
        });

        // Validate by reading back the created record
        if (typeof response.data === 'number') {
          const readBackResponse = await window.ezsite.apis.tablePage(tableId, {
            PageNo: 1,
            PageSize: 1,
            Filters: [{ name: 'id', op: 'Equal', value: response.data }]
          });

          validations.push({
            validation: 'created_record_readable',
            passed: !readBackResponse.error && readBackResponse.data?.List?.length === 1,
            message: !readBackResponse.error && readBackResponse.data?.List?.length === 1 ?
            'Created record can be read back' : 'Created record cannot be read back',
            expected: 'Record found',
            actual: readBackResponse.data?.List?.length || 0
          });

          // Validate data integrity
          if (readBackResponse.data?.List?.length === 1) {
            const createdRecord = readBackResponse.data.List[0];
            const dataMatches = this.validateDataIntegrity(testData, createdRecord);
            validations.push({
              validation: 'data_integrity_maintained',
              passed: dataMatches,
              message: dataMatches ? 'Created data matches input data' : 'Data integrity compromised',
              expected: 'Data matches input',
              actual: dataMatches ? 'Matches' : 'Does not match'
            });
          }
        }
      }

      const testPassed = validations.every((v) => v.passed);

      return {
        testId,
        testName: `CREATE operation - ${tableName}`,
        operation: 'create',
        tableId,
        tableName,
        status: testPassed ? 'passed' : 'failed',
        details: {
          testData,
          actualResult: response.data,
          executionTime,
          validations
        },
        timestamp: new Date()
      };

    } catch (error) {
      const executionTime = Date.now() - startTime;

      return {
        testId,
        testName: `CREATE operation - ${tableName}`,
        operation: 'create',
        tableId,
        tableName,
        status: 'error',
        details: {
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          executionTime,
          validations
        },
        timestamp: new Date()
      };
    }
  }

  // Test Update operation
  async testUpdateOperation(tableId: number, tableName: string, recordId: number): Promise<DataIntegrityTestResult> {
    const testId = `update-${tableName}-${Date.now()}`;
    const startTime = Date.now();
    const validations: ValidationResult[] = [];

    try {
      console.log(`[DataIntegrityTestService] Testing UPDATE operation for ${tableName}`);

      const updateData = this.generateUpdateTestData(tableName, recordId);

      const response = await window.ezsite.apis.tableUpdate(tableId, updateData);
      const executionTime = Date.now() - startTime;

      // Validation: No API error
      validations.push({
        validation: 'no_update_error',
        passed: !response.error,
        message: response.error ? `Update error: ${response.error}` : 'Record updated successfully',
        expected: 'No error',
        actual: response.error || 'No error'
      });

      // Validate by reading back the updated record
      if (!response.error) {
        const readBackResponse = await window.ezsite.apis.tablePage(tableId, {
          PageNo: 1,
          PageSize: 1,
          Filters: [{ name: 'id', op: 'Equal', value: recordId }]
        });

        validations.push({
          validation: 'updated_record_readable',
          passed: !readBackResponse.error && readBackResponse.data?.List?.length === 1,
          message: !readBackResponse.error && readBackResponse.data?.List?.length === 1 ?
          'Updated record can be read back' : 'Updated record cannot be read back',
          expected: 'Record found',
          actual: readBackResponse.data?.List?.length || 0
        });

        // Validate update integrity
        if (readBackResponse.data?.List?.length === 1) {
          const updatedRecord = readBackResponse.data.List[0];
          const updateApplied = this.validateUpdateIntegrity(updateData, updatedRecord);
          validations.push({
            validation: 'update_applied_correctly',
            passed: updateApplied,
            message: updateApplied ? 'Update was applied correctly' : 'Update was not applied correctly',
            expected: 'Update applied',
            actual: updateApplied ? 'Applied' : 'Not applied'
          });
        }
      }

      const testPassed = validations.every((v) => v.passed);

      return {
        testId,
        testName: `UPDATE operation - ${tableName}`,
        operation: 'update',
        tableId,
        tableName,
        status: testPassed ? 'passed' : 'failed',
        details: {
          testData: updateData,
          actualResult: response.data,
          executionTime,
          validations
        },
        timestamp: new Date()
      };

    } catch (error) {
      const executionTime = Date.now() - startTime;

      return {
        testId,
        testName: `UPDATE operation - ${tableName}`,
        operation: 'update',
        tableId,
        tableName,
        status: 'error',
        details: {
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          executionTime,
          validations
        },
        timestamp: new Date()
      };
    }
  }

  // Test Delete operation
  async testDeleteOperation(tableId: number, tableName: string, recordId: number): Promise<DataIntegrityTestResult> {
    const testId = `delete-${tableName}-${Date.now()}`;
    const startTime = Date.now();
    const validations: ValidationResult[] = [];

    try {
      console.log(`[DataIntegrityTestService] Testing DELETE operation for ${tableName}`);

      const response = await window.ezsite.apis.tableDelete(tableId, { ID: recordId });
      const executionTime = Date.now() - startTime;

      // Validation: No API error
      validations.push({
        validation: 'no_delete_error',
        passed: !response.error,
        message: response.error ? `Delete error: ${response.error}` : 'Record deleted successfully',
        expected: 'No error',
        actual: response.error || 'No error'
      });

      // Validate record is actually deleted
      if (!response.error) {
        const readBackResponse = await window.ezsite.apis.tablePage(tableId, {
          PageNo: 1,
          PageSize: 1,
          Filters: [{ name: 'id', op: 'Equal', value: recordId }]
        });

        validations.push({
          validation: 'record_actually_deleted',
          passed: !readBackResponse.error && readBackResponse.data?.List?.length === 0,
          message: !readBackResponse.error && readBackResponse.data?.List?.length === 0 ?
          'Record was successfully deleted' : 'Record still exists after delete',
          expected: 'Record not found',
          actual: readBackResponse.data?.List?.length || 0
        });
      }

      const testPassed = validations.every((v) => v.passed);

      return {
        testId,
        testName: `DELETE operation - ${tableName}`,
        operation: 'delete',
        tableId,
        tableName,
        status: testPassed ? 'passed' : 'failed',
        details: {
          testData: { ID: recordId },
          actualResult: response.data,
          executionTime,
          validations
        },
        timestamp: new Date()
      };

    } catch (error) {
      const executionTime = Date.now() - startTime;

      return {
        testId,
        testName: `DELETE operation - ${tableName}`,
        operation: 'delete',
        tableId,
        tableName,
        status: 'error',
        details: {
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          executionTime,
          validations
        },
        timestamp: new Date()
      };
    }
  }

  // Run referential integrity tests
  async runReferentialIntegrityTests(): Promise<ReferentialIntegrityTest[]> {
    const tests: ReferentialIntegrityTest[] = [];

    // Test relationships between tables
    const relationships = [
    { parent: this.TABLE_IDS.PRODUCTS, child: this.TABLE_IDS.SALES_TRANSACTIONS, fkField: 'product_id' },
    { parent: this.TABLE_IDS.EMPLOYEES, child: this.TABLE_IDS.SALES_TRANSACTIONS, fkField: 'employee_id' },
    { parent: this.TABLE_IDS.TEST_SUITES, child: this.TABLE_IDS.TEST_CASES, fkField: 'suite_id' },
    { parent: this.TABLE_IDS.TEST_EXECUTIONS, child: this.TABLE_IDS.TEST_RESULTS, fkField: 'execution_id' },
    { parent: this.TABLE_IDS.TEST_CASES, child: this.TABLE_IDS.TEST_RESULTS, fkField: 'test_case_id' }];


    for (const rel of relationships) {
      if (rel.parent && rel.child) {
        try {
          console.log(`[DataIntegrityTestService] Testing referential integrity: ${rel.parent} -> ${rel.child}`);

          // Get sample of child records
          const childResponse = await window.ezsite.apis.tablePage(rel.child, {
            PageNo: 1,
            PageSize: 100,
            OrderByField: 'id',
            IsAsc: false,
            Filters: []
          });

          if (childResponse.error || !childResponse.data?.List) {
            tests.push({
              parentTable: rel.parent,
              childTable: rel.child,
              foreignKeyField: rel.fkField,
              testResult: 'error',
              orphanedRecords: 0,
              errorMessage: childResponse.error || 'No child data available'
            });
            continue;
          }

          const childRecords = childResponse.data.List;
          const foreignKeyValues = [...new Set(childRecords.
          map((record) => record[rel.fkField]).
          filter((val) => val != null)
          )];

          let orphanedCount = 0;

          // Check if parent records exist for each foreign key
          for (const fkValue of foreignKeyValues.slice(0, 20)) {// Test first 20 unique values
            const parentResponse = await window.ezsite.apis.tablePage(rel.parent, {
              PageNo: 1,
              PageSize: 1,
              Filters: [{ name: 'id', op: 'Equal', value: fkValue }]
            });

            if (parentResponse.error || !parentResponse.data?.List?.length) {
              orphanedCount++;
            }
          }

          tests.push({
            parentTable: rel.parent,
            childTable: rel.child,
            foreignKeyField: rel.fkField,
            testResult: orphanedCount === 0 ? 'passed' : 'failed',
            orphanedRecords: orphanedCount,
            errorMessage: orphanedCount > 0 ? `Found ${orphanedCount} orphaned records` : undefined
          });

        } catch (error) {
          tests.push({
            parentTable: rel.parent,
            childTable: rel.child,
            foreignKeyField: rel.fkField,
            testResult: 'error',
            orphanedRecords: 0,
            errorMessage: error instanceof Error ? error.message : 'Unknown error'
          });
        }
      }
    }

    return tests;
  }

  // Run data corruption detection tests
  async runDataCorruptionTests(): Promise<DataCorruptionTest[]> {
    const tests: DataCorruptionTest[] = [];

    // Test critical tables for data corruption
    const tablesToTest = [
    { id: this.TABLE_IDS.PRODUCTS, name: 'products', fields: ['name', 'price', 'stock_level'] },
    { id: this.TABLE_IDS.SALES_TRANSACTIONS, name: 'sales_transactions', fields: ['total_amount', 'quantity_sold', 'unit_price'] },
    { id: this.TABLE_IDS.EMPLOYEES, name: 'employees', fields: ['name', 'email', 'phone'] }];


    for (const table of tablesToTest) {
      if (table.id) {
        try {
          const response = await window.ezsite.apis.tablePage(table.id, {
            PageNo: 1,
            PageSize: 500,
            OrderByField: 'id',
            IsAsc: false,
            Filters: []
          });

          if (response.error || !response.data?.List) continue;

          const records = response.data.List;
          const totalRecords = records.length;

          for (const field of table.fields) {
            // Test for null constraint violations
            const nullTest = this.testNullConstraints(records, field, totalRecords);
            if (nullTest) tests.push(nullTest);

            // Test for data type violations
            const typeTest = this.testDataTypes(records, field, totalRecords, table.name);
            if (typeTest) tests.push(typeTest);

            // Test for range validation
            const rangeTest = this.testRangeValidation(records, field, totalRecords, table.name);
            if (rangeTest) tests.push(rangeTest);

            // Test for format validation
            const formatTest = this.testFormatValidation(records, field, totalRecords, table.name);
            if (formatTest) tests.push(formatTest);
          }

          // Test for duplicate detection
          const duplicateTest = this.testDuplicateDetection(records, totalRecords, table.id);
          if (duplicateTest) tests.push(duplicateTest);

        } catch (error) {
          console.error(`[DataIntegrityTestService] Error testing ${table.name}:`, error);
        }
      }
    }

    return tests;
  }

  // Generate test data for different table types
  private generateTestData(tableName: string): any {
    const timestamp = new Date().toISOString();
    const random = Math.random().toString(36).substring(7);

    switch (tableName) {
      case 'products':
        return {
          name: `Test Product ${random}`,
          description: `Test product description ${random}`,
          price: Math.round(Math.random() * 1000 * 100) / 100,
          cost_price: Math.round(Math.random() * 500 * 100) / 100,
          selling_price: Math.round(Math.random() * 1000 * 100) / 100,
          stock_level: Math.floor(Math.random() * 100),
          minimum_stock: Math.floor(Math.random() * 10),
          category: 'test-category',
          sku: `TEST-${random.toUpperCase()}`,
          is_active: true,
          created_at: timestamp
        };

      case 'sales_transactions':
        return {
          product_id: 1,
          employee_id: 1,
          customer_id: 1,
          quantity_sold: Math.floor(Math.random() * 10) + 1,
          unit_price: Math.round(Math.random() * 100 * 100) / 100,
          total_amount: Math.round(Math.random() * 1000 * 100) / 100,
          discount_amount: 0,
          payment_method: 'cash',
          sale_date: timestamp,
          created_at: timestamp
        };

      case 'employees':
        return {
          name: `Test Employee ${random}`,
          email: `test.employee.${random}@test.com`,
          phone: `+1234567${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
          position: 'Test Position',
          hire_date: timestamp,
          is_active: true,
          created_at: timestamp
        };

      case 'notifications':
        return {
          title: `Test Notification ${random}`,
          message: `Test notification message ${random}`,
          type: 'info',
          is_read: false,
          created_at: timestamp
        };

      default:
        return {
          name: `Test ${tableName} ${random}`,
          description: `Test description for ${tableName}`,
          created_at: timestamp
        };
    }
  }

  // Generate update test data
  private generateUpdateTestData(tableName: string, recordId: number): any {
    const timestamp = new Date().toISOString();
    const random = Math.random().toString(36).substring(7);

    const baseUpdate = { id: recordId };

    switch (tableName) {
      case 'products':
        return {
          ...baseUpdate,
          name: `Updated Test Product ${random}`,
          price: Math.round(Math.random() * 1000 * 100) / 100,
          stock_level: Math.floor(Math.random() * 100),
          updated_at: timestamp
        };

      case 'employees':
        return {
          ...baseUpdate,
          name: `Updated Test Employee ${random}`,
          email: `updated.test.employee.${random}@test.com`,
          updated_at: timestamp
        };

      case 'notifications':
        return {
          ...baseUpdate,
          title: `Updated Test Notification ${random}`,
          is_read: true,
          updated_at: timestamp
        };

      default:
        return {
          ...baseUpdate,
          name: `Updated Test ${tableName} ${random}`,
          updated_at: timestamp
        };
    }
  }

  // Validate record structure consistency
  private validateRecordStructure(records: any[]): boolean {
    if (records.length === 0) return true;

    const firstRecordKeys = Object.keys(records[0]).sort();

    return records.every((record) => {
      const recordKeys = Object.keys(record).sort();
      return JSON.stringify(firstRecordKeys) === JSON.stringify(recordKeys);
    });
  }

  // Validate data integrity between input and stored data
  private validateDataIntegrity(inputData: any, storedData: any): boolean {
    // Compare key fields (excluding auto-generated fields like id, created_at, etc.)
    const fieldsToCompare = Object.keys(inputData).filter((key) =>
    !['id', 'created_at', 'updated_at'].includes(key)
    );

    return fieldsToCompare.every((field) => {
      const inputValue = inputData[field];
      const storedValue = storedData[field];

      // Handle type conversions and null values
      if (inputValue === null && storedValue === null) return true;
      if (typeof inputValue === 'number' && typeof storedValue === 'string') {
        return parseFloat(storedValue) === inputValue;
      }
      if (typeof inputValue === 'boolean' && typeof storedValue === 'string') {
        return (inputValue ? 'true' : 'false') === storedValue.toLowerCase();
      }

      return inputValue === storedValue;
    });
  }

  // Validate update integrity
  private validateUpdateIntegrity(updateData: any, updatedRecord: any): boolean {
    const fieldsToCheck = Object.keys(updateData).filter((key) => key !== 'id');

    return fieldsToCheck.every((field) => {
      const expectedValue = updateData[field];
      const actualValue = updatedRecord[field];

      // Handle type conversions
      if (typeof expectedValue === 'number' && typeof actualValue === 'string') {
        return parseFloat(actualValue) === expectedValue;
      }
      if (typeof expectedValue === 'boolean' && typeof actualValue === 'string') {
        return (expectedValue ? 'true' : 'false') === actualValue.toLowerCase();
      }

      return expectedValue === actualValue;
    });
  }

  // Test null constraint violations
  private testNullConstraints(records: any[], field: string, totalRecords: number): DataCorruptionTest | null {
    const nullRecords = records.filter((record) =>
    record[field] === null || record[field] === undefined || record[field] === ''
    );

    if (nullRecords.length === 0) return null;

    return {
      testType: 'null_constraints',
      tableId: 0,
      fieldName: field,
      corruptedRecords: nullRecords.length,
      totalRecords,
      corruptionPercentage: nullRecords.length / totalRecords * 100,
      examples: nullRecords.slice(0, 5)
    };
  }

  // Test data type violations
  private testDataTypes(records: any[], field: string, totalRecords: number, tableName: string): DataCorruptionTest | null {
    const expectedTypes = this.getExpectedFieldTypes(tableName, field);
    if (!expectedTypes) return null;

    const invalidRecords = records.filter((record) => {
      const value = record[field];
      if (value === null || value === undefined) return false;

      return !expectedTypes.some((type) => {
        switch (type) {
          case 'number':
            return !isNaN(parseFloat(value)) && isFinite(value);
          case 'string':
            return typeof value === 'string';
          case 'boolean':
            return typeof value === 'boolean' || value === 'true' || value === 'false';
          case 'date':
            return !isNaN(Date.parse(value));
          default:
            return false;
        }
      });
    });

    if (invalidRecords.length === 0) return null;

    return {
      testType: 'data_types',
      tableId: 0,
      fieldName: field,
      corruptedRecords: invalidRecords.length,
      totalRecords,
      corruptionPercentage: invalidRecords.length / totalRecords * 100,
      examples: invalidRecords.slice(0, 5).map((r) => ({ [field]: r[field], type: typeof r[field] }))
    };
  }

  // Test range validation
  private testRangeValidation(records: any[], field: string, totalRecords: number, tableName: string): DataCorruptionTest | null {
    const ranges = this.getFieldRanges(tableName, field);
    if (!ranges) return null;

    const invalidRecords = records.filter((record) => {
      const value = parseFloat(record[field]);
      if (isNaN(value)) return false;

      return value < ranges.min || value > ranges.max;
    });

    if (invalidRecords.length === 0) return null;

    return {
      testType: 'range_validation',
      tableId: 0,
      fieldName: field,
      corruptedRecords: invalidRecords.length,
      totalRecords,
      corruptionPercentage: invalidRecords.length / totalRecords * 100,
      examples: invalidRecords.slice(0, 5).map((r) => ({ [field]: r[field], range: ranges }))
    };
  }

  // Test format validation
  private testFormatValidation(records: any[], field: string, totalRecords: number, tableName: string): DataCorruptionTest | null {
    const patterns = this.getFieldPatterns(tableName, field);
    if (!patterns) return null;

    const invalidRecords = records.filter((record) => {
      const value = record[field];
      if (typeof value !== 'string' || value === '') return false;

      return !patterns.some((pattern) => pattern.test(value));
    });

    if (invalidRecords.length === 0) return null;

    return {
      testType: 'format_validation',
      tableId: 0,
      fieldName: field,
      corruptedRecords: invalidRecords.length,
      totalRecords,
      corruptionPercentage: invalidRecords.length / totalRecords * 100,
      examples: invalidRecords.slice(0, 5).map((r) => ({ [field]: r[field] }))
    };
  }

  // Test duplicate detection
  private testDuplicateDetection(records: any[], totalRecords: number, tableId: number): DataCorruptionTest | null {
    const duplicates = new Map<string, number>();

    records.forEach((record) => {
      // Create a signature excluding id and timestamp fields
      const signature = Object.keys(record).
      filter((key) => !['id', 'created_at', 'updated_at'].includes(key)).
      sort().
      map((key) => `${key}:${record[key]}`).
      join('|');

      duplicates.set(signature, (duplicates.get(signature) || 0) + 1);
    });

    const duplicateEntries = Array.from(duplicates.entries()).filter(([, count]) => count > 1);

    if (duplicateEntries.length === 0) return null;

    const duplicatedRecords = duplicateEntries.reduce((sum, [, count]) => sum + count, 0);

    return {
      testType: 'duplicate_detection',
      tableId,
      fieldName: 'record_signature',
      corruptedRecords: duplicatedRecords,
      totalRecords,
      corruptionPercentage: duplicatedRecords / totalRecords * 100,
      examples: duplicateEntries.slice(0, 5).map(([signature, count]) => ({ signature, count }))
    };
  }

  // Get expected field types for validation
  private getExpectedFieldTypes(tableName: string, field: string): string[] | null {
    const typeMap: Record<string, Record<string, string[]>> = {
      products: {
        name: ['string'],
        price: ['number'],
        cost_price: ['number'],
        selling_price: ['number'],
        stock_level: ['number'],
        minimum_stock: ['number'],
        is_active: ['boolean']
      },
      sales_transactions: {
        quantity_sold: ['number'],
        unit_price: ['number'],
        total_amount: ['number'],
        discount_amount: ['number'],
        sale_date: ['date']
      },
      employees: {
        name: ['string'],
        email: ['string'],
        phone: ['string'],
        hire_date: ['date'],
        is_active: ['boolean']
      }
    };

    return typeMap[tableName]?.[field] || null;
  }

  // Get field ranges for validation
  private getFieldRanges(tableName: string, field: string): {min: number;max: number;} | null {
    const rangeMap: Record<string, Record<string, {min: number;max: number;}>> = {
      products: {
        price: { min: 0, max: 1000000 },
        cost_price: { min: 0, max: 1000000 },
        selling_price: { min: 0, max: 1000000 },
        stock_level: { min: 0, max: 100000 },
        minimum_stock: { min: 0, max: 10000 }
      },
      sales_transactions: {
        quantity_sold: { min: 0, max: 10000 },
        unit_price: { min: 0, max: 1000000 },
        total_amount: { min: 0, max: 10000000 },
        discount_amount: { min: 0, max: 1000000 }
      }
    };

    return rangeMap[tableName]?.[field] || null;
  }

  // Get field patterns for validation
  private getFieldPatterns(tableName: string, field: string): RegExp[] | null {
    const patternMap: Record<string, Record<string, RegExp[]>> = {
      employees: {
        email: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/],
        phone: [/^\+?[\d\s\-\(\)]+$/, /^\d{10,15}$/]
      },
      products: {
        sku: [/^[A-Z0-9\-_]+$/]
      }
    };

    return patternMap[tableName]?.[field] || null;
  }
}

export const dataIntegrityTestService = new DataIntegrityTestService();