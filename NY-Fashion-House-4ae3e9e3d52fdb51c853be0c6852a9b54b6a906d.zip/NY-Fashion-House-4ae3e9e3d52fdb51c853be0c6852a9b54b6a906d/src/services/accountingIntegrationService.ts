
import { accountingService } from './accountingService';
import { Sale } from '@/types/sales';
import { Employee, SalaryPayment } from '@/types/salary';

class AccountingIntegrationService {
  // Integrate with sales transactions
  async recordSalesTransaction(sale: {id: string;totalAmount: number;date: string;paymentMethod: string;customerId?: string;}): Promise<void> {
    try {
      await accountingService.createSalesEntry({
        amount: sale.totalAmount,
        date: sale.date,
        reference: `SALE-${sale.id}`,
        paymentMethod: sale.paymentMethod === 'cash' ? 'cash' : 'credit',
        customerId: sale.customerId
      });
    } catch (error) {
      console.error('Failed to create accounting entry for sale:', error);
    }
  }

  // Integrate with salary payments
  async recordSalaryPayment(employee: Employee, payment: SalaryPayment): Promise<void> {
    try {
      await accountingService.createSalaryEntry({
        amount: payment.netSalary,
        date: payment.paymentDate,
        employeeId: employee.id,
        employeeName: employee.name
      });
    } catch (error) {
      console.error('Failed to create accounting entry for salary:', error);
    }
  }

  // Record inventory purchases (when products are added to stock)
  async recordInventoryPurchase(amount: number, description: string, reference?: string): Promise<void> {
    try {
      const cashAccount = await accountingService.getAccounts().then((accounts) =>
      accounts.find((acc) => acc.code === '1000')
      );
      const inventoryAccount = await accountingService.getAccounts().then((accounts) =>
      accounts.find((acc) => acc.code === '1200')
      );

      if (!cashAccount || !inventoryAccount) {
        throw new Error('Required accounts not found');
      }

      await accountingService.createJournalEntry({
        date: new Date().toISOString().split('T')[0],
        reference: reference || `INV-${Date.now()}`,
        description: description,
        totalAmount: amount,
        entries: [
        {
          accountId: inventoryAccount.id,
          debitAmount: amount,
          creditAmount: 0,
          description: 'Inventory purchase'
        },
        {
          accountId: cashAccount.id,
          debitAmount: 0,
          creditAmount: amount,
          description: 'Cash payment for inventory'
        }],

        source: 'purchase' as any,
        createdBy: 'system'
      });
    } catch (error) {
      console.error('Failed to create accounting entry for inventory purchase:', error);
    }
  }

  // Record general expenses
  async recordExpense(amount: number, description: string, expenseType: string = 'general'): Promise<void> {
    try {
      const cashAccount = await accountingService.getAccounts().then((accounts) =>
      accounts.find((acc) => acc.code === '1000')
      );

      // Map expense types to appropriate accounts
      const expenseAccountCode = this.getExpenseAccountCode(expenseType);
      const expenseAccount = await accountingService.getAccounts().then((accounts) =>
      accounts.find((acc) => acc.code === expenseAccountCode)
      );

      if (!cashAccount || !expenseAccount) {
        throw new Error('Required accounts not found');
      }

      await accountingService.createJournalEntry({
        date: new Date().toISOString().split('T')[0],
        reference: `EXP-${Date.now()}`,
        description: description,
        totalAmount: amount,
        entries: [
        {
          accountId: expenseAccount.id,
          debitAmount: amount,
          creditAmount: 0,
          description: description
        },
        {
          accountId: cashAccount.id,
          debitAmount: 0,
          creditAmount: amount,
          description: 'Cash payment for expense'
        }],

        source: 'expense' as any,
        createdBy: 'system'
      });
    } catch (error) {
      console.error('Failed to create accounting entry for expense:', error);
    }
  }

  private getExpenseAccountCode(expenseType: string): string {
    const expenseMapping: Record<string, string> = {
      'rent': '5200',
      'utilities': '5300',
      'office_supplies': '5400',
      'salary': '5100',
      'general': '5400' // Default to office supplies
    };

    return expenseMapping[expenseType] || '5400';
  }

  // Record customer payments (when they pay their outstanding balance)
  async recordCustomerPayment(customerId: string, amount: number, paymentMethod: 'cash' | 'bank'): Promise<void> {
    try {
      const cashAccount = await accountingService.getAccounts().then((accounts) =>
      accounts.find((acc) => acc.code === '1000')
      );
      const receivableAccount = await accountingService.getAccounts().then((accounts) =>
      accounts.find((acc) => acc.code === '1100')
      );

      if (!cashAccount || !receivableAccount) {
        throw new Error('Required accounts not found');
      }

      await accountingService.createJournalEntry({
        date: new Date().toISOString().split('T')[0],
        reference: `PAY-${customerId}-${Date.now()}`,
        description: `Customer payment received`,
        totalAmount: amount,
        entries: [
        {
          accountId: cashAccount.id,
          debitAmount: amount,
          creditAmount: 0,
          description: `Payment received - ${paymentMethod}`
        },
        {
          accountId: receivableAccount.id,
          debitAmount: 0,
          creditAmount: amount,
          description: 'Accounts receivable collection'
        }],

        source: 'payment' as any,
        sourceId: customerId,
        createdBy: 'system'
      });
    } catch (error) {
      console.error('Failed to create accounting entry for customer payment:', error);
    }
  }

  // Get financial summary for dashboard
  async getFinancialSummary(): Promise<{
    totalRevenue: number;
    totalExpenses: number;
    netIncome: number;
    totalAssets: number;
    cashBalance: number;
  }> {
    try {
      const accounts = await accountingService.getAccounts();

      const incomeAccounts = accounts.filter((acc) => acc.type === 'income');
      const expenseAccounts = accounts.filter((acc) => acc.type === 'expense');
      const assetAccounts = accounts.filter((acc) => acc.type === 'asset');
      const cashAccount = accounts.find((acc) => acc.code === '1000');

      const totalRevenue = incomeAccounts.reduce((sum, acc) => sum + acc.balance, 0);
      const totalExpenses = expenseAccounts.reduce((sum, acc) => sum + acc.balance, 0);
      const totalAssets = assetAccounts.reduce((sum, acc) => sum + acc.balance, 0);
      const cashBalance = cashAccount?.balance || 0;

      return {
        totalRevenue,
        totalExpenses,
        netIncome: totalRevenue - totalExpenses,
        totalAssets,
        cashBalance
      };
    } catch (error) {
      console.error('Failed to get financial summary:', error);
      return {
        totalRevenue: 0,
        totalExpenses: 0,
        netIncome: 0,
        totalAssets: 0,
        cashBalance: 0
      };
    }
  }
}

export const accountingIntegrationService = new AccountingIntegrationService();