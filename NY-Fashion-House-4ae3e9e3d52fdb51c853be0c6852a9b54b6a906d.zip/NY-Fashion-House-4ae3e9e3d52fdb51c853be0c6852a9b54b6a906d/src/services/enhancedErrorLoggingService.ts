
import { toast } from 'sonner';

export interface ErrorContext {
  title?: string;
  action?: string;
  operation?: string;
  severity?: 'low' | 'medium' | 'high' | 'critical';
  category?: 'client' | 'server' | 'network' | 'validation' | 'database';
  service?: string;
  userId?: string;
  sessionId?: string;
  url?: string;
  userAgent?: string;
  timestamp?: string;
  requestId?: string;
  tableId?: number;
  [key: string]: any;
}

export interface ErrorDetails {
  message: string;
  name: string;
  stack?: string;
  context: ErrorContext;
  correlationId: string;
  rootCause: string;
  remediation: string[];
  isRecoverable: boolean;
  retryCount?: number;
}

class EnhancedErrorLoggingService {
  private errorQueue: ErrorDetails[] = [];
  private sessionId: string;
  private readonly MAX_QUEUE_SIZE = 100;

  constructor() {
    this.sessionId = this.generateCorrelationId('session');

    // Log unhandled errors
    window.addEventListener('error', (event) => {
      this.logError(event.error, {
        category: 'client',
        severity: 'high',
        action: 'Unhandled JavaScript Error',
        url: window.location.href
      });
    });

    // Log unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.logError(new Error(event.reason), {
        category: 'client',
        severity: 'high',
        action: 'Unhandled Promise Rejection',
        url: window.location.href
      });
    });
  }

  generateCorrelationId(prefix = 'err'): string {
    const timestamp = Date.now().toString(36);
    const random1 = Math.random().toString(36).substr(2, 8);
    const random2 = Math.random().toString(36).substr(2, 8);
    return `${prefix}-${timestamp}-${random1}`;
  }

  private determineRootCause(error: Error, context: ErrorContext): string {
    const errorMessage = error.message.toLowerCase();

    // Database connection issues
    if (errorMessage.includes('failed to fetch') ||
    errorMessage.includes('network') ||
    errorMessage.includes('connection') ||
    errorMessage.includes('timeout')) {
      return 'Network or database connection issue';
    }

    // Database errors
    if (errorMessage.includes('database') ||
    errorMessage.includes('table') ||
    errorMessage.includes('sql') ||
    errorMessage.includes('constraint')) {
      return 'Database operation failed';
    }

    // Authentication errors
    if (errorMessage.includes('unauthorized') ||
    errorMessage.includes('authentication') ||
    errorMessage.includes('forbidden')) {
      return 'Authentication or authorization issue';
    }

    // Validation errors
    if (errorMessage.includes('validation') ||
    errorMessage.includes('invalid') ||
    errorMessage.includes('required')) {
      return 'Data validation failed';
    }

    // API errors
    if (errorMessage.includes('api') ||
    errorMessage.includes('service') ||
    errorMessage.includes('endpoint')) {
      return 'API service error';
    }

    return 'An unexpected error occurred';
  }

  private generateRemediation(error: Error, context: ErrorContext): string[] {
    const errorMessage = error.message.toLowerCase();
    const remediations: string[] = [];

    // Network/Connection issues
    if (errorMessage.includes('failed to fetch') ||
    errorMessage.includes('network') ||
    errorMessage.includes('connection')) {
      remediations.push('Check your internet connection');
      remediations.push('Refresh the page and try again');
      remediations.push('Try using a different browser or device');
    }

    // Database issues
    if (errorMessage.includes('database') ||
    errorMessage.includes('table') ||
    context.category === 'database') {
      remediations.push('The database may be temporarily unavailable');
      remediations.push('Wait a few moments and try again');
      remediations.push('Contact support if the issue persists');
    }

    // Authentication issues
    if (errorMessage.includes('unauthorized') ||
    errorMessage.includes('authentication')) {
      remediations.push('Please log in again');
      remediations.push('Clear browser cache and cookies');
      remediations.push('Check if your session has expired');
    }

    // Validation issues
    if (errorMessage.includes('validation') ||
    errorMessage.includes('invalid')) {
      remediations.push('Check that all required fields are filled correctly');
      remediations.push('Verify data format and constraints');
      remediations.push('Review form input requirements');
    }

    // Default remediations
    if (remediations.length === 0) {
      remediations.push('Try refreshing the page');
      remediations.push('Clear browser cache and cookies');
      remediations.push('Try using a different browser');
      remediations.push('Contact support with error details');
    }

    return remediations;
  }

  private isRecoverableError(error: Error, context: ErrorContext): boolean {
    const errorMessage = error.message.toLowerCase();

    // Non-recoverable errors
    if (errorMessage.includes('permission') ||
    errorMessage.includes('forbidden') ||
    errorMessage.includes('not found') ||
    errorMessage.includes('unauthorized')) {
      return false;
    }

    // Recoverable errors (temporary issues)
    if (errorMessage.includes('network') ||
    errorMessage.includes('timeout') ||
    errorMessage.includes('connection') ||
    errorMessage.includes('service unavailable')) {
      return true;
    }

    // Default to recoverable
    return true;
  }

  logError(error: Error | string, context: ErrorContext = {}): string {
    const errorObj = typeof error === 'string' ? new Error(error) : error;
    const correlationId = this.generateCorrelationId();

    const enrichedContext: ErrorContext = {
      timestamp: new Date().toISOString(),
      sessionId: this.sessionId,
      url: window.location.href,
      userAgent: navigator.userAgent,
      ...context
    };

    const errorDetails: ErrorDetails = {
      message: errorObj.message,
      name: errorObj.name,
      stack: errorObj.stack,
      context: enrichedContext,
      correlationId,
      rootCause: this.determineRootCause(errorObj, enrichedContext),
      remediation: this.generateRemediation(errorObj, enrichedContext),
      isRecoverable: this.isRecoverableError(errorObj, enrichedContext)
    };

    // Add to queue
    this.errorQueue.push(errorDetails);
    if (this.errorQueue.length > this.MAX_QUEUE_SIZE) {
      this.errorQueue.shift();
    }

    // Console logging with detailed info
    console.group(`🔥 [${errorDetails.correlationId}] ${enrichedContext.service || 'System'} Error`);
    console.error('Error:', errorObj.message);
    console.error('Root Cause:', errorDetails.rootCause);
    console.error('Context:', enrichedContext);
    console.error('Stack Trace:', errorObj.stack);
    console.error('Remediation Steps:', errorDetails.remediation);
    console.error('Recoverable:', errorDetails.isRecoverable);
    console.groupEnd();

    // Send error to external logging service (if configured)
    this.sendToExternalLogger(errorDetails);

    return errorDetails.correlationId;
  }

  private async sendToExternalLogger(errorDetails: ErrorDetails): Promise<void> {
    try {
      // This would send to an external logging service like Sentry, LogRocket, etc.
      // For now, just store in localStorage for debugging
      const existingLogs = JSON.parse(localStorage.getItem('errorLogs') || '[]');
      existingLogs.push(errorDetails);

      // Keep only last 50 errors
      if (existingLogs.length > 50) {
        existingLogs.splice(0, existingLogs.length - 50);
      }

      localStorage.setItem('errorLogs', JSON.stringify(existingLogs));
    } catch (logError) {
      console.error('Failed to log error externally:', logError);
    }
  }

  createUserFriendlyMessage(error: Error | string, context?: ErrorContext): string {
    const errorObj = typeof error === 'string' ? new Error(error) : error;
    const errorMessage = errorObj.message.toLowerCase();

    if (errorMessage.includes('failed to fetch') || errorMessage.includes('network')) {
      return 'Unable to connect to the server. Please check your internet connection.';
    }

    if (errorMessage.includes('database') || errorMessage.includes('table')) {
      return 'Database is temporarily unavailable. Please try again in a few moments.';
    }

    if (errorMessage.includes('unauthorized') || errorMessage.includes('forbidden')) {
      return 'You don\'t have permission to perform this action. Please log in again.';
    }

    if (errorMessage.includes('validation') || errorMessage.includes('invalid')) {
      return 'Please check your input data and try again.';
    }

    return errorObj.message || 'An unexpected error occurred. Please try again.';
  }

  getRecentErrors(limit = 10): ErrorDetails[] {
    return this.errorQueue.slice(-limit).reverse();
  }

  clearErrorQueue(): void {
    this.errorQueue = [];
  }

  exportErrorLog(): string {
    return JSON.stringify(this.errorQueue, null, 2);
  }

  // Get detailed error report by correlation ID
  getErrorReport(correlationId: string): ErrorDetails | null {
    return this.errorQueue.find((error) => error.correlationId === correlationId) || null;
  }

  // Get error statistics
  getErrorStatistics(): {
    totalErrors: number;
    errorsByCategory: Record<string, number>;
    errorsBySeverity: Record<string, number>;
    recentErrorTrend: number[];
  } {
    const stats = {
      totalErrors: this.errorQueue.length,
      errorsByCategory: {} as Record<string, number>,
      errorsBySeverity: {} as Record<string, number>,
      recentErrorTrend: [] as number[]
    };

    // Count by category
    this.errorQueue.forEach((error) => {
      const category = error.context.category || 'unknown';
      const severity = error.context.severity || 'unknown';

      stats.errorsByCategory[category] = (stats.errorsByCategory[category] || 0) + 1;
      stats.errorsBySeverity[severity] = (stats.errorsBySeverity[severity] || 0) + 1;
    });

    // Generate recent error trend (last 7 days)
    const now = Date.now();
    const oneDayMs = 24 * 60 * 60 * 1000;

    for (let i = 6; i >= 0; i--) {
      const dayStart = now - i * oneDayMs;
      const dayEnd = dayStart + oneDayMs;

      const errorsInDay = this.errorQueue.filter((error) => {
        const errorTime = new Date(error.context.timestamp || 0).getTime();
        return errorTime >= dayStart && errorTime < dayEnd;
      }).length;

      stats.recentErrorTrend.push(errorsInDay);
    }

    return stats;
  }

  // Get full error details (for internal use)
  logErrorWithDetails(error: Error | string, context: ErrorContext = {}): ErrorDetails {
    const errorObj = typeof error === 'string' ? new Error(error) : error;
    const correlationId = this.generateCorrelationId();

    const enrichedContext: ErrorContext = {
      timestamp: new Date().toISOString(),
      sessionId: this.sessionId,
      url: window.location.href,
      userAgent: navigator.userAgent,
      ...context
    };

    const errorDetails: ErrorDetails = {
      message: errorObj.message,
      name: errorObj.name,
      stack: errorObj.stack,
      context: enrichedContext,
      correlationId,
      rootCause: this.determineRootCause(errorObj, enrichedContext),
      remediation: this.generateRemediation(errorObj, enrichedContext),
      isRecoverable: this.isRecoverableError(errorObj, enrichedContext)
    };

    // Add to queue
    this.errorQueue.push(errorDetails);
    if (this.errorQueue.length > this.MAX_QUEUE_SIZE) {
      this.errorQueue.shift();
    }

    // Console logging with detailed info
    console.group(`🔥 [${errorDetails.correlationId}] ${enrichedContext.service || 'System'} Error`);
    console.error('Error:', errorObj.message);
    console.error('Root Cause:', errorDetails.rootCause);
    console.error('Context:', enrichedContext);
    console.error('Stack Trace:', errorObj.stack);
    console.error('Remediation Steps:', errorDetails.remediation);
    console.error('Recoverable:', errorDetails.isRecoverable);
    console.groupEnd();

    // Send error to external logging service (if configured)
    this.sendToExternalLogger(errorDetails);

    return errorDetails;
  }

  // Retry mechanism for recoverable errors
  async withRetry<T>(
  operation: () => Promise<T>,
  context: ErrorContext,
  maxRetries = 3,
  delayMs = 1000)
  : Promise<T> {
    let lastError: Error;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        const errorDetails = this.logErrorWithDetails(lastError, {
          ...context,
          retryCount: attempt
        });

        if (!errorDetails.isRecoverable || attempt === maxRetries) {
          // Create a user-friendly error message for the final failure
          const userMessage = this.createUserFriendlyMessage(lastError, context);
          throw new Error(`${userMessage} Reminder: Please retry it or send email to support for help.`);
        }

        // Wait before retry with exponential backoff
        await new Promise((resolve) => setTimeout(resolve, delayMs * attempt));
      }
    }

    throw lastError!;
  }
}

export const enhancedErrorLoggingService = new EnhancedErrorLoggingService();