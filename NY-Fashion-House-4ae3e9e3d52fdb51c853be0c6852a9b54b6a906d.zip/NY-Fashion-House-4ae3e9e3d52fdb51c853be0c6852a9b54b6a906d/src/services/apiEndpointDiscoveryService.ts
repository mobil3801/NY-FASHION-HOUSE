import { customerService } from './customerService';
import { productService } from './productService';
import { supplierService } from './supplierService';
import { salesService } from './salesService';
import { invoiceService } from './invoiceService';
import { employeeService } from './employeeService';
import { salaryService } from './salaryService';
import { accountingService } from './accountingService';
import { reportService } from './reportService';
import { auditService } from './auditService';
import { userService } from './userService';
import { roleService } from './roleService';
import { settingsService } from './settingsService';
import { financialService } from './financialService';
import { systemStatsService } from './systemStatsService';

export interface ServiceEndpoint {
  serviceName: string;
  methodName: string;
  method: Function;
  operationType: 'CREATE' | 'READ' | 'UPDATE' | 'DELETE' | 'UTILITY';
  description: string;
  expectedParams?: any[];
  returnType: string;
  tableId?: number;
  requiresAuth?: boolean;
}

export interface ServiceRegistry {
  serviceName: string;
  service: any;
  tableId?: number;
  endpoints: ServiceEndpoint[];
}

export class ApiEndpointDiscoveryService {
  private services: Record<string, any> = {
    customerService: { service: customerService, tableId: 38563 },
    productService: { service: productService, tableId: 38157 },
    supplierService: { service: supplierService, tableId: 38564 },
    salesService: { service: salesService, tableId: 38156 },
    invoiceService: { service: invoiceService, tableId: 38565 },
    employeeService: { service: employeeService, tableId: 37818 },
    salaryService: { service: salaryService, tableId: 38567 },
    accountingService: { service: accountingService, tableId: 38570 },
    reportService: { service: reportService },
    auditService: { service: auditService, tableId: 37723 },
    userService: { service: userService },
    roleService: { service: roleService },
    settingsService: { service: settingsService, tableId: 37722 },
    financialService: { service: financialService },
    systemStatsService: { service: systemStatsService }
  };

  private operationPatterns = {
    CREATE: ['create', 'add', 'insert', 'new'],
    READ: ['get', 'fetch', 'find', 'list', 'all', 'search', 'by'],
    UPDATE: ['update', 'edit', 'modify', 'patch'],
    DELETE: ['delete', 'remove', 'destroy'],
    UTILITY: ['calculate', 'validate', 'format', 'generate', 'export']
  };

  /**
   * Discover all service endpoints automatically
   */
  async discoverAllEndpoints(): Promise<ServiceRegistry[]> {
    const registries: ServiceRegistry[] = [];

    for (const [serviceName, serviceConfig] of Object.entries(this.services)) {
      try {
        const registry = await this.discoverServiceEndpoints(serviceName, serviceConfig);
        registries.push(registry);
      } catch (error) {
        console.error(`Failed to discover endpoints for ${serviceName}:`, error);
      }
    }

    return registries;
  }

  /**
   * Discover endpoints for a specific service
   */
  private async discoverServiceEndpoints(serviceName: string, serviceConfig: any): Promise<ServiceRegistry> {
    const { service, tableId } = serviceConfig;
    const endpoints: ServiceEndpoint[] = [];

    // Get all methods from the service
    const serviceMethods = this.getServiceMethods(service);

    for (const [methodName, method] of serviceMethods) {
      try {
        const endpoint: ServiceEndpoint = {
          serviceName,
          methodName,
          method,
          operationType: this.determineOperationType(methodName),
          description: this.generateDescription(serviceName, methodName),
          expectedParams: this.analyzeMethodParameters(method),
          returnType: this.determineReturnType(methodName),
          tableId,
          requiresAuth: this.requiresAuth(methodName)
        };

        endpoints.push(endpoint);
      } catch (error) {
        console.warn(`Failed to analyze method ${methodName} in ${serviceName}:`, error);
      }
    }

    return {
      serviceName,
      service,
      tableId,
      endpoints
    };
  }

  /**
   * Get all callable methods from a service
   */
  private getServiceMethods(service: any): Map<string, Function> {
    const methods = new Map<string, Function>();

    if (typeof service === 'object' && service !== null) {
      // For object-based services
      for (const [key, value] of Object.entries(service)) {
        if (typeof value === 'function' && !key.startsWith('_')) {
          methods.set(key, value);
        }
      }
    } else if (typeof service === 'function') {
      // For function-based services
      const prototype = service.prototype || service;
      const propertyNames = Object.getOwnPropertyNames(prototype);

      for (const name of propertyNames) {
        if (name !== 'constructor' && typeof prototype[name] === 'function') {
          methods.set(name, prototype[name]);
        }
      }
    }

    return methods;
  }

  /**
   * Determine operation type based on method name
   */
  private determineOperationType(methodName: string): ServiceEndpoint['operationType'] {
    const lowerMethodName = methodName.toLowerCase();

    for (const [type, patterns] of Object.entries(this.operationPatterns)) {
      if (patterns.some((pattern) => lowerMethodName.includes(pattern))) {
        return type as ServiceEndpoint['operationType'];
      }
    }

    return 'UTILITY';
  }

  /**
   * Generate human-readable description
   */
  private generateDescription(serviceName: string, methodName: string): string {
    const serviceDisplayName = serviceName.replace('Service', '').replace(/([A-Z])/g, ' $1').trim();
    const methodDisplayName = methodName.replace(/([A-Z])/g, ' $1').toLowerCase().trim();

    return `${serviceDisplayName} - ${methodDisplayName}`;
  }

  /**
   * Analyze method parameters (simplified)
   */
  private analyzeMethodParameters(method: Function): any[] {
    try {
      const methodStr = method.toString();
      const paramMatch = methodStr.match(/\(([^)]*)\)/);

      if (paramMatch && paramMatch[1]) {
        const params = paramMatch[1].split(',').map((p) => p.trim().split(':')[0].trim());
        return params.filter((p) => p && p !== '');
      }
    } catch (error) {
      console.warn('Failed to analyze method parameters:', error);
    }

    return [];
  }

  /**
   * Determine expected return type
   */
  private determineReturnType(methodName: string): string {
    const lowerMethodName = methodName.toLowerCase();

    if (lowerMethodName.includes('getall') || lowerMethodName.includes('list')) {
      return 'Array';
    } else if (lowerMethodName.includes('get') || lowerMethodName.includes('find')) {
      return 'Object | null';
    } else if (lowerMethodName.includes('create') || lowerMethodName.includes('update')) {
      return 'Object';
    } else if (lowerMethodName.includes('delete') || lowerMethodName.includes('remove')) {
      return 'void | boolean';
    } else if (lowerMethodName.includes('calculate') || lowerMethodName.includes('count')) {
      return 'number';
    }

    return 'any';
  }

  /**
   * Check if method requires authentication
   */
  private requiresAuth(methodName: string): boolean {
    const authFreePatterns = ['get', 'list', 'search', 'validate', 'calculate'];
    const lowerMethodName = methodName.toLowerCase();

    return !authFreePatterns.some((pattern) => lowerMethodName.includes(pattern));
  }

  /**
   * Get endpoints by operation type
   */
  async getEndpointsByType(operationType: ServiceEndpoint['operationType']): Promise<ServiceEndpoint[]> {
    const allRegistries = await this.discoverAllEndpoints();
    const endpoints: ServiceEndpoint[] = [];

    for (const registry of allRegistries) {
      endpoints.push(...registry.endpoints.filter((e) => e.operationType === operationType));
    }

    return endpoints;
  }

  /**
   * Get endpoints by service
   */
  async getEndpointsByService(serviceName: string): Promise<ServiceEndpoint[]> {
    const serviceConfig = this.services[serviceName];
    if (!serviceConfig) {
      throw new Error(`Service ${serviceName} not found`);
    }

    const registry = await this.discoverServiceEndpoints(serviceName, serviceConfig);
    return registry.endpoints;
  }

  /**
   * Search endpoints by keyword
   */
  async searchEndpoints(keyword: string): Promise<ServiceEndpoint[]> {
    const allRegistries = await this.discoverAllEndpoints();
    const endpoints: ServiceEndpoint[] = [];
    const lowerKeyword = keyword.toLowerCase();

    for (const registry of allRegistries) {
      const matchingEndpoints = registry.endpoints.filter((endpoint) =>
      endpoint.serviceName.toLowerCase().includes(lowerKeyword) ||
      endpoint.methodName.toLowerCase().includes(lowerKeyword) ||
      endpoint.description.toLowerCase().includes(lowerKeyword)
      );
      endpoints.push(...matchingEndpoints);
    }

    return endpoints;
  }

  /**
   * Get service statistics
   */
  async getServiceStatistics(): Promise<{
    totalServices: number;
    totalEndpoints: number;
    endpointsByType: Record<string, number>;
    endpointsByService: Record<string, number>;
  }> {
    const allRegistries = await this.discoverAllEndpoints();
    const totalServices = allRegistries.length;
    let totalEndpoints = 0;
    const endpointsByType: Record<string, number> = {};
    const endpointsByService: Record<string, number> = {};

    for (const registry of allRegistries) {
      totalEndpoints += registry.endpoints.length;
      endpointsByService[registry.serviceName] = registry.endpoints.length;

      for (const endpoint of registry.endpoints) {
        endpointsByType[endpoint.operationType] = (endpointsByType[endpoint.operationType] || 0) + 1;
      }
    }

    return {
      totalServices,
      totalEndpoints,
      endpointsByType,
      endpointsByService
    };
  }
}

export const apiEndpointDiscoveryService = new ApiEndpointDiscoveryService();