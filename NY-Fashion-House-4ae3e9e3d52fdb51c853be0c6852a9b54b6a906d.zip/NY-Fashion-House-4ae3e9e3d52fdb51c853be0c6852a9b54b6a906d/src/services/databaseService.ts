import { toast } from 'sonner';

interface DatabaseOperation {
  operation: 'CREATE' | 'READ' | 'UPDATE' | 'DELETE';
  table: string;
  data?: any;
  filters?: any;
}

interface DatabaseResponse<T = any> {
  data: T;
  error: string | null;
  success: boolean;
}

export class DatabaseService {
  private static logOperation(operation: DatabaseOperation, result: any, error?: any) {
    const timestamp = new Date().toISOString();
    console.group(`[DB ${operation.operation}] ${operation.table} - ${timestamp}`);
    console.log('Operation:', operation);
    if (error) {
      console.error('Error:', error);
    } else {
      console.log('Success:', result);
    }
    console.groupEnd();
  }

  static async create(tableId: number, tableName: string, data: any): Promise<DatabaseResponse> {
    const operation: DatabaseOperation = {
      operation: 'CREATE',
      table: tableName,
      data
    };

    try {
      console.log(`[DatabaseService] Creating record in ${tableName}:`, data);

      const response = await window.ezsite.apis.tableCreate(tableId, data);

      if (response.error) {
        this.logOperation(operation, null, response.error);
        return {
          data: null,
          error: response.error,
          success: false
        };
      }

      this.logOperation(operation, 'Success');
      toast.success(`Record created in ${tableName}`);

      return {
        data: response,
        error: null,
        success: true
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logOperation(operation, null, errorMessage);
      toast.error(`Failed to create record in ${tableName}: ${errorMessage}`);

      return {
        data: null,
        error: errorMessage,
        success: false
      };
    }
  }

  static async read(tableId: number, tableName: string, pageNo = 1, pageSize = 10, filters: any[] = []): Promise<DatabaseResponse> {
    const operation: DatabaseOperation = {
      operation: 'READ',
      table: tableName,
      filters
    };

    try {
      console.log(`[DatabaseService] Reading records from ${tableName}:`, { pageNo, pageSize, filters });

      const response = await window.ezsite.apis.tablePage(tableId, {
        PageNo: pageNo,
        PageSize: pageSize,
        OrderByField: 'id',
        IsAsc: false,
        Filters: filters
      });

      if (response.error) {
        this.logOperation(operation, null, response.error);
        return {
          data: null,
          error: response.error,
          success: false
        };
      }

      this.logOperation(operation, `Found ${response.data?.List?.length || 0} records`);

      return {
        data: response.data,
        error: null,
        success: true
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logOperation(operation, null, errorMessage);

      return {
        data: null,
        error: errorMessage,
        success: false
      };
    }
  }

  static async update(tableId: number, tableName: string, recordId: number, data: any): Promise<DatabaseResponse> {
    const operation: DatabaseOperation = {
      operation: 'UPDATE',
      table: tableName,
      data: { id: recordId, ...data }
    };

    try {
      console.log(`[DatabaseService] Updating record ${recordId} in ${tableName}:`, data);

      const response = await window.ezsite.apis.tableUpdate(tableId, {
        id: recordId,
        ...data
      });

      if (response.error) {
        this.logOperation(operation, null, response.error);
        return {
          data: null,
          error: response.error,
          success: false
        };
      }

      this.logOperation(operation, 'Success');
      toast.success(`Record updated in ${tableName}`);

      return {
        data: response,
        error: null,
        success: true
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logOperation(operation, null, errorMessage);
      toast.error(`Failed to update record in ${tableName}: ${errorMessage}`);

      return {
        data: null,
        error: errorMessage,
        success: false
      };
    }
  }

  static async delete(tableId: number, tableName: string, recordId: number): Promise<DatabaseResponse> {
    const operation: DatabaseOperation = {
      operation: 'DELETE',
      table: tableName,
      data: { id: recordId }
    };

    try {
      console.log(`[DatabaseService] Deleting record ${recordId} from ${tableName}`);

      const response = await window.ezsite.apis.tableDelete(tableId, { id: recordId });

      if (response.error) {
        this.logOperation(operation, null, response.error);
        return {
          data: null,
          error: response.error,
          success: false
        };
      }

      this.logOperation(operation, 'Success');
      toast.success(`Record deleted from ${tableName}`);

      return {
        data: response,
        error: null,
        success: true
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      this.logOperation(operation, null, errorMessage);
      toast.error(`Failed to delete record from ${tableName}: ${errorMessage}`);

      return {
        data: null,
        error: errorMessage,
        success: false
      };
    }
  }

  // Helper method to get table ID by name
  static getTableId(tableName: string): number | null {
    const tableMap: Record<string, number> = {
      'products': 38157,
      'sales_transactions': 38156,
      'employees': 37818,
      'notifications': 38282,
      'customers': 38563,
      'suppliers': 38564,
      'expenses': 38512
    };

    return tableMap[tableName] || null;
  }

  // Test all CRUD operations for a table
  static async testTableCrud(tableName: string, testData: any): Promise<boolean> {
    const tableId = this.getTableId(tableName);
    if (!tableId) {
      console.error(`Unknown table: ${tableName}`);
      return false;
    }

    try {
      // CREATE
      console.log(`\n=== Testing CREATE for ${tableName} ===`);
      const createResult = await this.create(tableId, tableName, testData);
      if (!createResult.success) {
        console.error(`CREATE failed for ${tableName}:`, createResult.error);
        return false;
      }

      // READ to get the created record
      console.log(`\n=== Testing READ for ${tableName} ===`);
      const readResult = await this.read(tableId, tableName, 1, 5);
      if (!readResult.success || !readResult.data?.List?.length) {
        console.error(`READ failed for ${tableName}:`, readResult.error);
        return false;
      }

      const createdRecord = readResult.data.List[0];
      console.log(`Found ${readResult.data.List.length} records, using ID: ${createdRecord.id}`);

      // UPDATE
      console.log(`\n=== Testing UPDATE for ${tableName} ===`);
      const updateData = tableName === 'products' ?
      { name: 'Updated Test Product' } :
      tableName === 'employees' ?
      { first_name: 'Updated Test' } :
      tableName === 'notifications' ?
      { is_read: true } :
      { notes: 'Updated by CRUD test' };

      const updateResult = await this.update(tableId, tableName, createdRecord.id, updateData);
      if (!updateResult.success) {
        console.error(`UPDATE failed for ${tableName}:`, updateResult.error);
        return false;
      }

      // DELETE
      console.log(`\n=== Testing DELETE for ${tableName} ===`);
      const deleteResult = await this.delete(tableId, tableName, createdRecord.id);
      if (!deleteResult.success) {
        console.error(`DELETE failed for ${tableName}:`, deleteResult.error);
        return false;
      }

      console.log(`✅ All CRUD operations successful for ${tableName}`);
      return true;

    } catch (error) {
      console.error(`❌ CRUD test failed for ${tableName}:`, error);
      return false;
    }
  }
}