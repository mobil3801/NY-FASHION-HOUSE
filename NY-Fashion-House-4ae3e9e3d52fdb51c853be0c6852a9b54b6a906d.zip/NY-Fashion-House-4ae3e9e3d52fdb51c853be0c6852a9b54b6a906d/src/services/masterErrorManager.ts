import { ErrorInfo } from 'react';
import { PerformanceOptimizer } from '../utils/performanceOptimizer';
import { DevToolsIntegration } from '../utils/devToolsIntegration';
import { ErrorPatternDetector } from '../utils/errorPatternDetector';

export interface ComprehensiveErrorData {
  error: Error;
  errorInfo?: ErrorInfo;
  level: 'app' | 'page' | 'section' | 'component';
  context: string;
  errorId: string;
  timestamp: number;
  userAgent: string;
  url: string;
  retryCount: number;
  componentStack?: string;
  errorBoundary: string;
  userId?: string;
  sessionId?: string;
  buildVersion?: string;
  environmentInfo?: Record<string, any>;
}

export class MasterErrorManager {
  private performanceOptimizer: PerformanceOptimizer;
  private devToolsIntegration: DevToolsIntegration;
  private patternDetector: ErrorPatternDetector;
  private errorQueue: ComprehensiveErrorData[] = [];
  private isProcessing = false;

  constructor() {
    this.performanceOptimizer = new PerformanceOptimizer();
    this.devToolsIntegration = new DevToolsIntegration();
    this.patternDetector = new ErrorPatternDetector();

    this.initializeErrorCapture();
    this.setupPeriodicProcessing();
  }

  private initializeErrorCapture() {
    // Global error handlers
    window.addEventListener('error', (event) => {
      this.captureGlobalError(event.error, {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        message: event.message
      });
    });

    window.addEventListener('unhandledrejection', (event) => {
      this.capturePromiseRejection(event.reason);
    });

    // Console error interception for development
    if (process.env.NODE_ENV === 'development') {
      this.devToolsIntegration.interceptConsoleErrors();
    }
  }

  private setupPeriodicProcessing() {
    // Process error queue every 30 seconds
    setInterval(() => {
      if (this.errorQueue.length > 0 && !this.isProcessing) {
        this.processErrorQueue();
      }
    }, 30000);
  }

  public logError(errorData: ComprehensiveErrorData) {
    // Performance optimization - debounce similar errors
    if (this.performanceOptimizer.shouldSkipError(errorData)) {
      return;
    }

    // Enrich error data
    const enrichedData = this.enrichErrorData(errorData);

    // Add to queue for batch processing
    this.errorQueue.push(enrichedData);

    // Immediate processing for critical errors
    if (errorData.level === 'app' || this.isCriticalError(errorData.error)) {
      this.processErrorImmediately(enrichedData);
    }

    // Development tools integration
    if (process.env.NODE_ENV === 'development') {
      this.devToolsIntegration.logToDevTools(enrichedData);
    }

    // Pattern detection
    this.patternDetector.analyzeError(enrichedData);
  }

  private enrichErrorData(errorData: ComprehensiveErrorData): ComprehensiveErrorData {
    return {
      ...errorData,
      sessionId: this.getSessionId(),
      userId: this.getCurrentUserId(),
      buildVersion: this.getBuildVersion(),
      environmentInfo: this.getEnvironmentInfo(),
      // Additional context from browser APIs
      memoryUsage: this.getMemoryUsage(),
      connectionType: this.getConnectionType(),
      viewportSize: this.getViewportSize()
    };
  }

  private captureGlobalError(error: Error, details: any) {
    this.logError({
      error,
      level: 'app',
      context: 'global',
      errorId: `global_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      retryCount: 0,
      errorBoundary: 'global',
      ...details
    });
  }

  private capturePromiseRejection(reason: any) {
    const error = reason instanceof Error ? reason : new Error(String(reason));
    this.logError({
      error,
      level: 'app',
      context: 'promise_rejection',
      errorId: `promise_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      retryCount: 0,
      errorBoundary: 'promise_handler'
    });
  }

  private async processErrorQueue() {
    if (this.isProcessing || this.errorQueue.length === 0) return;

    this.isProcessing = true;
    const errors = this.errorQueue.splice(0, 50); // Process in batches

    try {
      // Send to logging service
      await this.sendToLoggingService(errors);

      // Update pattern detection
      this.patternDetector.updatePatterns(errors);

    } catch (error) {
      console.error('Failed to process error queue:', error);
      // Re-add errors to queue for retry
      this.errorQueue.unshift(...errors);
    } finally {
      this.isProcessing = false;
    }
  }

  private async processErrorImmediately(errorData: ComprehensiveErrorData) {
    try {
      await this.sendToLoggingService([errorData]);
    } catch (error) {
      console.error('Failed to log critical error:', error);
    }
  }

  private async sendToLoggingService(errors: ComprehensiveErrorData[]) {
    // Send to external logging service or internal API
    const payload = {
      errors,
      timestamp: Date.now(),
      batchId: `batch_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    // For now, store in localStorage for development
    if (process.env.NODE_ENV === 'development') {
      const existingErrors = JSON.parse(localStorage.getItem('error_logs') || '[]');
      existingErrors.push(...errors);
      localStorage.setItem('error_logs', JSON.stringify(existingErrors.slice(-1000))); // Keep last 1000 errors
    }

    // TODO: Replace with actual logging service endpoint
    // await fetch('/api/errors/log', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(payload)
    // });
  }

  private isCriticalError(error: Error): boolean {
    const criticalPatterns = [
    /Cannot read prop/,
    /Network Error/,
    /ChunkLoadError/,
    /Loading chunk \d+ failed/,
    /TypeError.*undefined/];


    return criticalPatterns.some((pattern) => pattern.test(error.message));
  }

  public openIssueReporter(errorReport: any) {
    // Open modal or new tab for issue reporting
    const issueUrl = `${window.location.origin}/error-report?errorId=${errorReport.errorId}`;
    window.open(issueUrl, '_blank');
  }

  public openErrorDetails(errorId: string) {
    // Navigate to error details page
    window.location.href = `${window.location.origin}/error-details/${errorId}`;
  }

  // Utility methods
  private getSessionId(): string {
    return sessionStorage.getItem('sessionId') || `session_${Date.now()}`;
  }

  private getCurrentUserId(): string | undefined {
    // Get from your auth system
    const userInfo = localStorage.getItem('user');
    return userInfo ? JSON.parse(userInfo).id : undefined;
  }

  private getBuildVersion(): string {
    return process.env.REACT_APP_VERSION || 'unknown';
  }

  private getEnvironmentInfo(): Record<string, any> {
    return {
      screen: {
        width: window.screen.width,
        height: window.screen.height,
        pixelRatio: window.devicePixelRatio
      },
      browser: {
        language: navigator.language,
        platform: navigator.platform,
        cookieEnabled: navigator.cookieEnabled
      },
      performance: {
        memoryUsed: this.getMemoryUsage(),
        connectionType: this.getConnectionType()
      }
    };
  }

  private getMemoryUsage(): number | undefined {
    return (performance as any).memory?.usedJSHeapSize;
  }

  private getConnectionType(): string | undefined {
    return (navigator as any).connection?.effectiveType;
  }

  private getViewportSize(): {width: number;height: number;} {
    return {
      width: window.innerWidth,
      height: window.innerHeight
    };
  }

  // Public API for manual error reporting
  public reportError(error: Error, context?: string) {
    this.logError({
      error,
      level: 'component',
      context: context || 'manual',
      errorId: `manual_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      retryCount: 0,
      errorBoundary: 'manual'
    });
  }

  // Get error statistics for monitoring dashboard
  public getErrorStatistics() {
    return this.patternDetector.getStatistics();
  }

  // Get error patterns for analysis
  public getErrorPatterns() {
    return this.patternDetector.getPatterns();
  }
}