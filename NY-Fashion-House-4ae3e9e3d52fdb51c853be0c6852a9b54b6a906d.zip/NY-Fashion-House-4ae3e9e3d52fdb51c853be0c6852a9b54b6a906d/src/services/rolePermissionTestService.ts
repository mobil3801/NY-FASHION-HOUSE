
export interface RolePermissionTestResult {
  testId: string;
  testName: string;
  roleCode: string;
  roleName: string;
  operation: string;
  resource: string;
  expectedAccess: 'allow' | 'deny';
  actualAccess: 'allow' | 'deny' | 'error';
  status: 'passed' | 'failed' | 'error';
  details: {
    errorMessage?: string;
    responseTime: number;
    httpStatus?: number;
    unauthorizedAttempt?: boolean;
  };
  timestamp: Date;
}

export interface PermissionBoundaryTest {
  testId: string;
  testName: string;
  roleCode: string;
  attemptedAction: string;
  expectedBehavior: string;
  actualBehavior: string;
  securityViolation: boolean;
  status: 'passed' | 'failed' | 'error';
  details: {
    errorMessage?: string;
    responseTime: number;
    dataLeakage?: boolean;
    bypassAttempted?: boolean;
  };
  timestamp: Date;
}

export interface RoleTestUser {
  id?: number;
  email: string;
  password: string;
  roleCode: string;
  roleName: string;
  temporaryUser: boolean;
}

class RolePermissionTestService {
  private readonly AVAILABLE_ROLES = [
  { code: 'GeneralUser', name: 'General User', id: 1087 },
  { code: 'Administrator', name: 'Administrator', id: 1088 },
  { code: 'r-WzDn7C', name: 'Sales', id: 1119 }];


  private readonly TABLE_IDS = {
    PRODUCTS: 38157,
    SALES_TRANSACTIONS: 38156,
    EMPLOYEES: 37818,
    NOTIFICATIONS: 38282,
    AUTH_USERS: 37706,
    ROLES: 37707,
    AUDIT_LOGS: 37723,
    SYSTEM_SETTINGS: 37722
  };

  private testUsers: Map<string, RoleTestUser> = new Map();
  private currentAuthState: {userInfo: any;token: string;} | null = null;

  // Run comprehensive role-based permission tests
  async runComprehensiveRolePermissionTests(): Promise<{
    rolePermissionTests: RolePermissionTestResult[];
    boundaryTests: PermissionBoundaryTest[];
    unauthorizedAccessTests: RolePermissionTestResult[];
    functionalityRestrictionTests: RolePermissionTestResult[];
    summary: {
      totalTests: number;
      passed: number;
      failed: number;
      errors: number;
      securityViolations: number;
      executionTime: number;
    };
  }> {
    const startTime = Date.now();

    console.log('[RolePermissionTestService] Starting comprehensive role permission tests...');

    // Store current auth state to restore later
    await this.storeCurrentAuthState();

    try {
      // Create test users for each role
      await this.createTestUsers();

      const [
      rolePermissionTests,
      boundaryTests,
      unauthorizedAccessTests,
      functionalityRestrictionTests] =
      await Promise.all([
      this.runRolePermissionTests(),
      this.runPermissionBoundaryTests(),
      this.runUnauthorizedAccessTests(),
      this.runFunctionalityRestrictionTests()]
      );

      const allTests = [
      ...rolePermissionTests,
      ...unauthorizedAccessTests,
      ...functionalityRestrictionTests];


      const summary = {
        totalTests: allTests.length + boundaryTests.length,
        passed: allTests.filter((t) => t.status === 'passed').length + boundaryTests.filter((t) => t.status === 'passed').length,
        failed: allTests.filter((t) => t.status === 'failed').length + boundaryTests.filter((t) => t.status === 'failed').length,
        errors: allTests.filter((t) => t.status === 'error').length + boundaryTests.filter((t) => t.status === 'error').length,
        securityViolations: boundaryTests.filter((t) => t.securityViolation).length,
        executionTime: Date.now() - startTime
      };

      console.log('[RolePermissionTestService] Role permission tests completed:', summary);

      return {
        rolePermissionTests,
        boundaryTests,
        unauthorizedAccessTests,
        functionalityRestrictionTests,
        summary
      };

    } finally {
      // Cleanup test users and restore auth state
      await this.cleanupTestUsers();
      await this.restoreAuthState();
    }
  }

  // Create test users for each role
  private async createTestUsers(): Promise<void> {
    console.log('[RolePermissionTestService] Creating test users...');

    for (const role of this.AVAILABLE_ROLES) {
      const testUser: RoleTestUser = {
        email: `test.${role.code.toLowerCase()}.${Date.now()}@testdomain.com`,
        password: 'TestPassword123!',
        roleCode: role.code,
        roleName: role.name,
        temporaryUser: true
      };

      try {
        // Register the test user
        const registerResponse = await window.ezsite.apis.register({
          email: testUser.email,
          password: testUser.password
        });

        if (!registerResponse.error) {
          // Get user info to get the ID
          const loginResponse = await window.ezsite.apis.login({
            email: testUser.email,
            password: testUser.password
          });

          if (!loginResponse.error) {
            const { data: userInfo } = await window.ezsite.apis.getUserInfo();
            if (userInfo && userInfo.ID) {
              testUser.id = userInfo.ID;

              // Update user role
              await window.ezsite.apis.tableUpdate(this.TABLE_IDS.AUTH_USERS, {
                id: userInfo.ID,
                role_id: role.id,
                role_name: role.name,
                role_code: role.code
              });
            }
          }

          this.testUsers.set(role.code, testUser);
          console.log(`[RolePermissionTestService] Created test user for role ${role.name}`);
        }
      } catch (error) {
        console.error(`[RolePermissionTestService] Failed to create test user for role ${role.name}:`, error);
      }
    }

    // Logout after creating users
    await window.ezsite.apis.logout();
  }

  // Run role permission tests
  private async runRolePermissionTests(): Promise<RolePermissionTestResult[]> {
    const tests: RolePermissionTestResult[] = [];

    // Define permission matrix for each role
    const permissionMatrix = this.getPermissionMatrix();

    for (const role of this.AVAILABLE_ROLES) {
      const testUser = this.testUsers.get(role.code);
      if (!testUser) continue;

      console.log(`[RolePermissionTestService] Testing permissions for ${role.name}...`);

      // Login as the test user
      await this.loginAsTestUser(testUser);

      const rolePermissions = permissionMatrix[role.code] || {};

      for (const [resource, operations] of Object.entries(rolePermissions)) {
        for (const [operation, expectedAccess] of Object.entries(operations)) {
          const test = await this.testRolePermission(
            role.code,
            role.name,
            resource,
            operation,
            expectedAccess as 'allow' | 'deny'
          );
          tests.push(test);
        }
      }

      // Logout after testing this role
      await window.ezsite.apis.logout();
    }

    return tests;
  }

  // Test individual role permission
  private async testRolePermission(
  roleCode: string,
  roleName: string,
  resource: string,
  operation: string,
  expectedAccess: 'allow' | 'deny')
  : Promise<RolePermissionTestResult> {
    const testId = `role-perm-${roleCode}-${resource}-${operation}-${Date.now()}`;
    const startTime = Date.now();

    try {
      console.log(`[RolePermissionTestService] Testing ${roleCode} - ${resource} - ${operation}`);

      let actualAccess: 'allow' | 'deny' | 'error' = 'error';
      let httpStatus: number | undefined;
      let errorMessage: string | undefined;

      // Perform the actual operation based on resource and operation type
      const result = await this.performOperation(resource, operation);

      if (result.success) {
        actualAccess = 'allow';
        httpStatus = 200;
      } else if (result.forbidden) {
        actualAccess = 'deny';
        httpStatus = 403;
      } else {
        actualAccess = 'error';
        errorMessage = result.error;
        httpStatus = 500;
      }

      const responseTime = Date.now() - startTime;
      const testPassed = actualAccess === expectedAccess;

      return {
        testId,
        testName: `${roleName} - ${resource} ${operation}`,
        roleCode,
        roleName,
        operation,
        resource,
        expectedAccess,
        actualAccess,
        status: testPassed ? 'passed' : 'failed',
        details: {
          errorMessage,
          responseTime,
          httpStatus,
          unauthorizedAttempt: expectedAccess === 'deny' && actualAccess === 'allow'
        },
        timestamp: new Date()
      };

    } catch (error) {
      const responseTime = Date.now() - startTime;

      return {
        testId,
        testName: `${roleName} - ${resource} ${operation}`,
        roleCode,
        roleName,
        operation,
        resource,
        expectedAccess,
        actualAccess: 'error',
        status: 'error',
        details: {
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          responseTime
        },
        timestamp: new Date()
      };
    }
  }

  // Run permission boundary tests
  private async runPermissionBoundaryTests(): Promise<PermissionBoundaryTest[]> {
    const tests: PermissionBoundaryTest[] = [];

    // Test various boundary scenarios
    const boundaryScenarios = [
    {
      name: 'Sales Role - Admin Area Access',
      roleCode: 'r-WzDn7C',
      action: 'access_admin_dashboard',
      expectedBehavior: 'Access denied with appropriate error message',
      testFn: () => this.testAdminAreaAccess()
    },
    {
      name: 'General User - Sales Data Access',
      roleCode: 'GeneralUser',
      action: 'access_sales_data',
      expectedBehavior: 'Access denied to sensitive sales information',
      testFn: () => this.testSalesDataAccess()
    },
    {
      name: 'Sales Role - User Management Access',
      roleCode: 'r-WzDn7C',
      action: 'access_user_management',
      expectedBehavior: 'Access denied to user management functions',
      testFn: () => this.testUserManagementAccess()
    },
    {
      name: 'General User - System Settings Access',
      roleCode: 'GeneralUser',
      action: 'access_system_settings',
      expectedBehavior: 'Access denied to system configuration',
      testFn: () => this.testSystemSettingsAccess()
    },
    {
      name: 'Role Elevation Attempt',
      roleCode: 'GeneralUser',
      action: 'attempt_role_elevation',
      expectedBehavior: 'Role elevation blocked with security alert',
      testFn: () => this.testRoleElevationAttempt()
    }];


    for (const scenario of boundaryScenarios) {
      const testUser = this.testUsers.get(scenario.roleCode);
      if (!testUser) continue;

      console.log(`[RolePermissionTestService] Testing boundary: ${scenario.name}`);

      // Login as the test user
      await this.loginAsTestUser(testUser);

      const test = await this.runBoundaryTest(scenario);
      tests.push(test);

      // Logout after test
      await window.ezsite.apis.logout();
    }

    return tests;
  }

  // Run boundary test
  private async runBoundaryTest(scenario: any): Promise<PermissionBoundaryTest> {
    const testId = `boundary-${scenario.roleCode}-${Date.now()}`;
    const startTime = Date.now();

    try {
      const result = await scenario.testFn();
      const responseTime = Date.now() - startTime;

      const securityViolation = result.accessGranted && result.shouldBeDenied;
      const testPassed = result.behaviorMatches && !securityViolation;

      return {
        testId,
        testName: scenario.name,
        roleCode: scenario.roleCode,
        attemptedAction: scenario.action,
        expectedBehavior: scenario.expectedBehavior,
        actualBehavior: result.actualBehavior,
        securityViolation,
        status: testPassed ? 'passed' : 'failed',
        details: {
          errorMessage: result.errorMessage,
          responseTime,
          dataLeakage: result.dataLeakage || false,
          bypassAttempted: result.bypassAttempted || false
        },
        timestamp: new Date()
      };

    } catch (error) {
      const responseTime = Date.now() - startTime;

      return {
        testId,
        testName: scenario.name,
        roleCode: scenario.roleCode,
        attemptedAction: scenario.action,
        expectedBehavior: scenario.expectedBehavior,
        actualBehavior: 'Test execution failed',
        securityViolation: false,
        status: 'error',
        details: {
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          responseTime
        },
        timestamp: new Date()
      };
    }
  }

  // Run unauthorized access tests
  private async runUnauthorizedAccessTests(): Promise<RolePermissionTestResult[]> {
    const tests: RolePermissionTestResult[] = [];

    // Test unauthorized access attempts
    const unauthorizedScenarios = [
    { roleCode: 'GeneralUser', resource: 'admin_functions', operation: 'user_management' },
    { roleCode: 'GeneralUser', resource: 'admin_functions', operation: 'system_settings' },
    { roleCode: 'r-WzDn7C', resource: 'admin_functions', operation: 'role_management' },
    { roleCode: 'r-WzDn7C', resource: 'admin_functions', operation: 'audit_logs' }];


    for (const scenario of unauthorizedScenarios) {
      const testUser = this.testUsers.get(scenario.roleCode);
      if (!testUser) continue;

      await this.loginAsTestUser(testUser);

      const test = await this.testRolePermission(
        scenario.roleCode,
        this.AVAILABLE_ROLES.find((r) => r.code === scenario.roleCode)?.name || scenario.roleCode,
        scenario.resource,
        scenario.operation,
        'deny'
      );

      tests.push(test);

      await window.ezsite.apis.logout();
    }

    return tests;
  }

  // Run functionality restriction tests
  private async runFunctionalityRestrictionTests(): Promise<RolePermissionTestResult[]> {
    const tests: RolePermissionTestResult[] = [];

    // Test that each role can only access their authorized functionality
    const functionalityTests = [
    { roleCode: 'Administrator', resource: 'all_functions', operation: 'full_access', expected: 'allow' },
    { roleCode: 'r-WzDn7C', resource: 'sales_functions', operation: 'pos_access', expected: 'allow' },
    { roleCode: 'r-WzDn7C', resource: 'sales_functions', operation: 'sales_reports', expected: 'allow' },
    { roleCode: 'GeneralUser', resource: 'basic_functions', operation: 'view_products', expected: 'allow' },
    { roleCode: 'GeneralUser', resource: 'restricted_functions', operation: 'modify_products', expected: 'deny' }];


    for (const testCase of functionalityTests) {
      const testUser = this.testUsers.get(testCase.roleCode);
      if (!testUser) continue;

      await this.loginAsTestUser(testUser);

      const test = await this.testRolePermission(
        testCase.roleCode,
        this.AVAILABLE_ROLES.find((r) => r.code === testCase.roleCode)?.name || testCase.roleCode,
        testCase.resource,
        testCase.operation,
        testCase.expected as 'allow' | 'deny'
      );

      tests.push(test);

      await window.ezsite.apis.logout();
    }

    return tests;
  }

  // Perform actual operation based on resource and operation
  private async performOperation(resource: string, operation: string): Promise<{
    success: boolean;
    forbidden: boolean;
    error?: string;
    data?: any;
  }> {
    try {
      switch (resource) {
        case 'products':
          return await this.testProductOperations(operation);
        case 'sales_transactions':
          return await this.testSalesOperations(operation);
        case 'employees':
          return await this.testEmployeeOperations(operation);
        case 'admin_functions':
          return await this.testAdminOperations(operation);
        case 'sales_functions':
          return await this.testSalesFunctions(operation);
        case 'basic_functions':
          return await this.testBasicFunctions(operation);
        case 'restricted_functions':
          return await this.testRestrictedFunctions(operation);
        case 'all_functions':
          return await this.testAllFunctions(operation);
        default:
          return { success: false, forbidden: false, error: 'Unknown resource' };
      }
    } catch (error) {
      return {
        success: false,
        forbidden: false,
        error: error instanceof Error ? error.message : 'Operation failed'
      };
    }
  }

  // Test product operations
  private async testProductOperations(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    switch (operation) {
      case 'read':
        const readResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.PRODUCTS, {
          PageNo: 1,
          PageSize: 5,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });
        return { success: !readResponse.error, forbidden: false, error: readResponse.error, data: readResponse.data };

      case 'create':
        const createResponse = await window.ezsite.apis.tableCreate(this.TABLE_IDS.PRODUCTS, {
          name: 'Permission Test Product',
          price: 100,
          stock_level: 10,
          is_active: true
        });
        return { success: !createResponse.error, forbidden: false, error: createResponse.error, data: createResponse.data };

      case 'update':
        // First try to get a product to update
        const getResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.PRODUCTS, {
          PageNo: 1,
          PageSize: 1,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });

        if (getResponse.error || !getResponse.data?.List?.length) {
          return { success: false, forbidden: false, error: 'No products available for update test' };
        }

        const productId = getResponse.data.List[0].id;
        const updateResponse = await window.ezsite.apis.tableUpdate(this.TABLE_IDS.PRODUCTS, {
          id: productId,
          name: 'Updated Permission Test Product'
        });
        return { success: !updateResponse.error, forbidden: false, error: updateResponse.error, data: updateResponse.data };

      case 'delete':
        // Create a test product first, then delete it
        const createForDeleteResponse = await window.ezsite.apis.tableCreate(this.TABLE_IDS.PRODUCTS, {
          name: 'Delete Test Product',
          price: 1,
          stock_level: 1,
          is_active: false
        });

        if (createForDeleteResponse.error || !createForDeleteResponse.data) {
          return { success: false, forbidden: false, error: 'Could not create product for delete test' };
        }

        const deleteResponse = await window.ezsite.apis.tableDelete(this.TABLE_IDS.PRODUCTS, {
          ID: createForDeleteResponse.data
        });
        return { success: !deleteResponse.error, forbidden: false, error: deleteResponse.error, data: deleteResponse.data };

      default:
        return { success: false, forbidden: false, error: 'Unknown operation' };
    }
  }

  // Test sales operations
  private async testSalesOperations(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    switch (operation) {
      case 'read':
        const readResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.SALES_TRANSACTIONS, {
          PageNo: 1,
          PageSize: 5,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });
        return { success: !readResponse.error, forbidden: false, error: readResponse.error, data: readResponse.data };

      case 'create':
        const createResponse = await window.ezsite.apis.tableCreate(this.TABLE_IDS.SALES_TRANSACTIONS, {
          product_id: 1,
          employee_id: 1,
          quantity_sold: 1,
          unit_price: 100,
          total_amount: 100,
          payment_method: 'cash',
          sale_date: new Date().toISOString()
        });
        return { success: !createResponse.error, forbidden: false, error: createResponse.error, data: createResponse.data };

      default:
        return { success: false, forbidden: false, error: 'Unknown operation' };
    }
  }

  // Test employee operations
  private async testEmployeeOperations(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    switch (operation) {
      case 'read':
        const readResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.EMPLOYEES, {
          PageNo: 1,
          PageSize: 5,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });
        return { success: !readResponse.error, forbidden: false, error: readResponse.error, data: readResponse.data };

      case 'create':
        const createResponse = await window.ezsite.apis.tableCreate(this.TABLE_IDS.EMPLOYEES, {
          name: 'Permission Test Employee',
          email: `test.employee.${Date.now()}@test.com`,
          position: 'Test Position',
          is_active: true
        });
        return { success: !createResponse.error, forbidden: false, error: createResponse.error, data: createResponse.data };

      default:
        return { success: false, forbidden: false, error: 'Unknown operation' };
    }
  }

  // Test admin operations
  private async testAdminOperations(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    switch (operation) {
      case 'user_management':
        const usersResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.AUTH_USERS, {
          PageNo: 1,
          PageSize: 5,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });
        return { success: !usersResponse.error, forbidden: false, error: usersResponse.error, data: usersResponse.data };

      case 'role_management':
        const rolesResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.ROLES, {
          PageNo: 1,
          PageSize: 5,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });
        return { success: !rolesResponse.error, forbidden: false, error: rolesResponse.error, data: rolesResponse.data };

      case 'audit_logs':
        const auditResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.AUDIT_LOGS, {
          PageNo: 1,
          PageSize: 5,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });
        return { success: !auditResponse.error, forbidden: false, error: auditResponse.error, data: auditResponse.data };

      case 'system_settings':
        const settingsResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.SYSTEM_SETTINGS, {
          PageNo: 1,
          PageSize: 5,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });
        return { success: !settingsResponse.error, forbidden: false, error: settingsResponse.error, data: settingsResponse.data };

      default:
        return { success: false, forbidden: false, error: 'Unknown admin operation' };
    }
  }

  // Test sales-specific functions
  private async testSalesFunctions(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    switch (operation) {
      case 'pos_access':
        // Simulate POS access by trying to read products and create sales
        const productsResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.PRODUCTS, {
          PageNo: 1,
          PageSize: 10,
          Filters: [{ name: 'is_active', op: 'Equal', value: true }]
        });
        return { success: !productsResponse.error, forbidden: false, error: productsResponse.error };

      case 'sales_reports':
        // Test access to sales data for reporting
        const salesResponse = await window.ezsite.apis.tablePage(this.TABLE_IDS.SALES_TRANSACTIONS, {
          PageNo: 1,
          PageSize: 10,
          OrderByField: 'sale_date',
          IsAsc: false,
          Filters: []
        });
        return { success: !salesResponse.error, forbidden: false, error: salesResponse.error };

      default:
        return { success: false, forbidden: false, error: 'Unknown sales function' };
    }
  }

  // Test basic functions
  private async testBasicFunctions(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    switch (operation) {
      case 'view_products':
        const response = await window.ezsite.apis.tablePage(this.TABLE_IDS.PRODUCTS, {
          PageNo: 1,
          PageSize: 5,
          Filters: [{ name: 'is_active', op: 'Equal', value: true }]
        });
        return { success: !response.error, forbidden: false, error: response.error };

      default:
        return { success: false, forbidden: false, error: 'Unknown basic function' };
    }
  }

  // Test restricted functions
  private async testRestrictedFunctions(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    switch (operation) {
      case 'modify_products':
        // General users should not be able to modify products
        const createResponse = await window.ezsite.apis.tableCreate(this.TABLE_IDS.PRODUCTS, {
          name: 'Unauthorized Product Creation',
          price: 100
        });

        // If this succeeds when it should fail, it's a security issue
        if (!createResponse.error) {
          return { success: false, forbidden: false, error: 'Security violation: Unauthorized operation succeeded' };
        }

        return { success: false, forbidden: true, error: 'Access appropriately denied' };

      default:
        return { success: false, forbidden: false, error: 'Unknown restricted function' };
    }
  }

  // Test all functions (admin should have access)
  private async testAllFunctions(operation: string): Promise<{success: boolean;forbidden: boolean;error?: string;data?: any;}> {
    if (operation === 'full_access') {
      // Test multiple operations to verify full access
      const tests = await Promise.all([
      this.testProductOperations('read'),
      this.testAdminOperations('user_management'),
      this.testSalesOperations('read')]
      );

      const allSuccessful = tests.every((test) => test.success);
      return {
        success: allSuccessful,
        forbidden: false,
        error: allSuccessful ? undefined : 'Some operations failed'
      };
    }

    return { success: false, forbidden: false, error: 'Unknown all-access operation' };
  }

  // Boundary test methods
  private async testAdminAreaAccess(): Promise<any> {
    const result = await this.testAdminOperations('user_management');
    return {
      accessGranted: result.success,
      shouldBeDenied: true,
      behaviorMatches: !result.success,
      actualBehavior: result.success ? 'Access granted (VIOLATION)' : 'Access denied (Correct)',
      errorMessage: result.error
    };
  }

  private async testSalesDataAccess(): Promise<any> {
    const result = await this.testSalesOperations('read');
    return {
      accessGranted: result.success,
      shouldBeDenied: true,
      behaviorMatches: !result.success,
      actualBehavior: result.success ? 'Access granted (VIOLATION)' : 'Access denied (Correct)',
      errorMessage: result.error,
      dataLeakage: result.success // If access is granted, there's potential data leakage
    };
  }

  private async testUserManagementAccess(): Promise<any> {
    const result = await this.testAdminOperations('user_management');
    return {
      accessGranted: result.success,
      shouldBeDenied: true,
      behaviorMatches: !result.success,
      actualBehavior: result.success ? 'Access granted (VIOLATION)' : 'Access denied (Correct)',
      errorMessage: result.error
    };
  }

  private async testSystemSettingsAccess(): Promise<any> {
    const result = await this.testAdminOperations('system_settings');
    return {
      accessGranted: result.success,
      shouldBeDenied: true,
      behaviorMatches: !result.success,
      actualBehavior: result.success ? 'Access granted (VIOLATION)' : 'Access denied (Correct)',
      errorMessage: result.error
    };
  }

  private async testRoleElevationAttempt(): Promise<any> {
    try {
      // Attempt to update own user record to admin role
      const { data: currentUser } = await window.ezsite.apis.getUserInfo();

      if (currentUser && currentUser.ID) {
        const elevationResponse = await window.ezsite.apis.tableUpdate(this.TABLE_IDS.AUTH_USERS, {
          id: currentUser.ID,
          role_id: 1088, // Administrator role
          role_code: 'Administrator'
        });

        return {
          accessGranted: !elevationResponse.error,
          shouldBeDenied: true,
          behaviorMatches: !!elevationResponse.error,
          actualBehavior: elevationResponse.error ? 'Role elevation blocked (Correct)' : 'Role elevation succeeded (VIOLATION)',
          errorMessage: elevationResponse.error,
          bypassAttempted: true
        };
      } else {
        return {
          accessGranted: false,
          shouldBeDenied: true,
          behaviorMatches: true,
          actualBehavior: 'Could not retrieve user info for elevation test',
          errorMessage: 'No current user info available'
        };
      }
    } catch (error) {
      return {
        accessGranted: false,
        shouldBeDenied: true,
        behaviorMatches: true,
        actualBehavior: 'Role elevation attempt blocked by exception',
        errorMessage: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  // Get permission matrix for each role
  private getPermissionMatrix(): Record<string, Record<string, Record<string, 'allow' | 'deny'>>> {
    return {
      'Administrator': {
        'products': { 'read': 'allow', 'create': 'allow', 'update': 'allow', 'delete': 'allow' },
        'sales_transactions': { 'read': 'allow', 'create': 'allow', 'update': 'allow', 'delete': 'allow' },
        'employees': { 'read': 'allow', 'create': 'allow', 'update': 'allow', 'delete': 'allow' },
        'admin_functions': { 'user_management': 'allow', 'role_management': 'allow', 'audit_logs': 'allow', 'system_settings': 'allow' },
        'all_functions': { 'full_access': 'allow' }
      },
      'r-WzDn7C': { // Sales role
        'products': { 'read': 'allow', 'create': 'deny', 'update': 'allow', 'delete': 'deny' },
        'sales_transactions': { 'read': 'allow', 'create': 'allow', 'update': 'allow', 'delete': 'deny' },
        'employees': { 'read': 'allow', 'create': 'deny', 'update': 'deny', 'delete': 'deny' },
        'admin_functions': { 'user_management': 'deny', 'role_management': 'deny', 'audit_logs': 'deny', 'system_settings': 'deny' },
        'sales_functions': { 'pos_access': 'allow', 'sales_reports': 'allow' }
      },
      'GeneralUser': {
        'products': { 'read': 'allow', 'create': 'deny', 'update': 'deny', 'delete': 'deny' },
        'sales_transactions': { 'read': 'deny', 'create': 'deny', 'update': 'deny', 'delete': 'deny' },
        'employees': { 'read': 'deny', 'create': 'deny', 'update': 'deny', 'delete': 'deny' },
        'admin_functions': { 'user_management': 'deny', 'role_management': 'deny', 'audit_logs': 'deny', 'system_settings': 'deny' },
        'basic_functions': { 'view_products': 'allow' },
        'restricted_functions': { 'modify_products': 'deny' }
      }
    };
  }

  // Login as test user
  private async loginAsTestUser(testUser: RoleTestUser): Promise<void> {
    const response = await window.ezsite.apis.login({
      email: testUser.email,
      password: testUser.password
    });

    if (response.error) {
      throw new Error(`Failed to login as test user: ${response.error}`);
    }
  }

  // Store current auth state
  private async storeCurrentAuthState(): Promise<void> {
    try {
      const { data: userInfo } = await window.ezsite.apis.getUserInfo();
      this.currentAuthState = {
        userInfo,
        token: 'current_session' // We can't actually get the token, but we mark that there was a session
      };
    } catch (error) {
      this.currentAuthState = null;
    }
  }

  // Restore auth state
  private async restoreAuthState(): Promise<void> {
    // For now, just logout to ensure clean state
    // In a real implementation, you might want to restore the original session
    await window.ezsite.apis.logout();
  }

  // Cleanup test users
  private async cleanupTestUsers(): Promise<void> {
    console.log('[RolePermissionTestService] Cleaning up test users...');

    for (const [roleCode, testUser] of this.testUsers) {
      if (testUser.temporaryUser && testUser.id) {
        try {
          // We can't delete users directly, but we could mark them as inactive
          // or you might have a specific cleanup API
          console.log(`[RolePermissionTestService] Would cleanup test user for role ${roleCode}`);
        } catch (error) {
          console.error(`[RolePermissionTestService] Failed to cleanup test user for role ${roleCode}:`, error);
        }
      }
    }

    this.testUsers.clear();
  }
}

export const rolePermissionTestService = new RolePermissionTestService();