import { useState, useCallback, useRef, useEffect } from 'react';
import { errorLoggingService } from '@/services/errorLoggingService';
import { toast } from '@/hooks/use-toast';

interface AsyncOperationState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

interface UseAsyncOperationOptions {
  showToast?: boolean;
  showSuccessToast?: boolean;
  successMessage?: string;
  onSuccess?: (data: any) => void;
  onError?: (error: Error) => void;
  retryCount?: number;
  retryDelay?: number;
}

export function useAsyncOperation<T = any>(
options: UseAsyncOperationOptions = {})
{
  const [state, setState] = useState<AsyncOperationState<T>>({
    data: null,
    loading: false,
    error: null
  });

  const {
    showToast = true,
    showSuccessToast = false,
    successMessage = 'Operation completed successfully',
    onSuccess,
    onError,
    retryCount = 0,
    retryDelay = 1000
  } = options;

  const mountedRef = useRef(true);
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current);
      }
    };
  }, []);

  const execute = useCallback(async (
  operation: () => Promise<T>,
  attempt: number = 0)
  : Promise<T | null> => {
    if (!mountedRef.current) return null;

    setState((prev) => ({ ...prev, loading: true, error: null }));

    try {
      const result = await operation();

      if (!mountedRef.current) return null;

      setState({
        data: result,
        loading: false,
        error: null
      });

      if (showSuccessToast) {
        toast({
          title: "Success",
          description: successMessage
        });
      }

      if (onSuccess) {
        onSuccess(result);
      }

      return result;
    } catch (error) {
      if (!mountedRef.current) return null;

      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      const userFriendlyMessage = errorLoggingService.createUserFriendlyMessage(error as Error);

      // Log the error
      errorLoggingService.logError(error as Error, {
        severity: 'medium',
        context: {
          operation: operation.name || 'async-operation',
          attempt: attempt + 1,
          maxRetries: retryCount
        }
      });

      // Retry logic
      if (attempt < retryCount) {
        retryTimeoutRef.current = setTimeout(() => {
          execute(operation, attempt + 1);
        }, retryDelay * Math.pow(2, attempt)); // Exponential backoff

        return null;
      }

      setState({
        data: null,
        loading: false,
        error: userFriendlyMessage
      });

      if (showToast) {
        toast({
          title: "Error",
          description: userFriendlyMessage,
          variant: "destructive"
        });
      }

      if (onError) {
        onError(error as Error);
      }

      return null;
    }
  }, [showToast, showSuccessToast, successMessage, onSuccess, onError, retryCount, retryDelay]);

  const reset = useCallback(() => {
    setState({
      data: null,
      loading: false,
      error: null
    });
  }, []);

  const setData = useCallback((data: T) => {
    setState((prev) => ({ ...prev, data }));
  }, []);

  return {
    ...state,
    execute,
    reset,
    setData,
    isIdle: !state.loading && !state.error && !state.data
  };
}

export default useAsyncOperation;