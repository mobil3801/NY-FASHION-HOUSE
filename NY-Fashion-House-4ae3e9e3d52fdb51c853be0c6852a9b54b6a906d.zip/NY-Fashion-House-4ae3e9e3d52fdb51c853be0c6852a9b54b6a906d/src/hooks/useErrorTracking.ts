// Enhanced error tracking hook
import { useState, useEffect, useCallback } from 'react';
import {
  comprehensiveErrorTrackingService,
  ComprehensiveErrorReport,
  ErrorStatistics } from
'@/services/comprehensiveErrorTrackingService';
import { ErrorContext } from '@/types/errorTypes';
import { toast } from 'sonner';

export interface UseErrorTrackingOptions {
  autoRefresh?: boolean;
  refreshInterval?: number;
  enableNotifications?: boolean;
}

export interface UseErrorTrackingReturn {
  // Error reporting
  logError: (error: Error | string, context?: ErrorContext) => Promise<string>;

  // Data access
  errorReports: ComprehensiveErrorReport[];
  statistics: ErrorStatistics | null;
  isLoading: boolean;

  // Management actions
  resolveError: (errorId: string) => boolean;
  retryOperation: (errorId: string) => Promise<boolean>;
  clearAllErrors: () => void;
  refreshData: () => void;

  // Filtering
  getErrorsByFilter: (filter: 'all' | 'unresolved' | 'critical' | 'recent') => ComprehensiveErrorReport[];

  // Export
  exportReports: () => void;
}

export const useErrorTracking = (options: UseErrorTrackingOptions = {}): UseErrorTrackingReturn => {
  const {
    autoRefresh = false,
    refreshInterval = 30000,
    enableNotifications = true
  } = options;

  const [errorReports, setErrorReports] = useState<ComprehensiveErrorReport[]>([]);
  const [statistics, setStatistics] = useState<ErrorStatistics | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Refresh data from the service
  const refreshData = useCallback(() => {
    setIsLoading(true);
    try {
      const reports = comprehensiveErrorTrackingService.getErrorReports();
      const stats = comprehensiveErrorTrackingService.getStatistics();

      setErrorReports(reports);
      setStatistics(stats);
    } catch (error) {
      console.error('[useErrorTracking] Failed to refresh data:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Log error with optional notification
  const logError = useCallback(async (error: Error | string, context?: ErrorContext): Promise<string> => {
    const errorId = await comprehensiveErrorTrackingService.logError(error, context);

    // Refresh data after logging
    refreshData();

    // Show notification if enabled
    if (enableNotifications) {
      const errorObj = typeof error === 'string' ? new Error(error) : error;
      const severity = context?.severity || 'medium';

      if (severity !== 'low') {
        toast.error('Error Logged', {
          description: `${errorObj.message} (ID: ${errorId})`,
          duration: severity === 'critical' ? 10000 : 5000
        });
      }
    }

    return errorId;
  }, [refreshData, enableNotifications]);

  // Resolve an error
  const resolveError = useCallback((errorId: string): boolean => {
    const success = comprehensiveErrorTrackingService.resolveError(errorId);
    if (success) {
      refreshData();
      if (enableNotifications) {
        toast.success('Error Resolved', {
          description: `Error ${errorId} has been marked as resolved.`
        });
      }
    }
    return success;
  }, [refreshData, enableNotifications]);

  // Retry an operation
  const retryOperation = useCallback(async (errorId: string): Promise<boolean> => {
    const success = await comprehensiveErrorTrackingService.retryOperation(errorId);
    refreshData();
    return success;
  }, [refreshData]);

  // Clear all errors
  const clearAllErrors = useCallback(() => {
    comprehensiveErrorTrackingService.clearAllErrors();
    refreshData();
    if (enableNotifications) {
      toast.success('All Errors Cleared', {
        description: 'All error reports have been cleared from the system.'
      });
    }
  }, [refreshData, enableNotifications]);

  // Get filtered errors
  const getErrorsByFilter = useCallback((filter: 'all' | 'unresolved' | 'critical' | 'recent'): ComprehensiveErrorReport[] => {
    switch (filter) {
      case 'unresolved':
        return errorReports.filter((error) => !error.resolved);
      case 'critical':
        return errorReports.filter((error) => error.severity === 'critical');
      case 'recent':
        const oneHourAgo = Date.now() - 60 * 60 * 1000;
        return errorReports.filter((error) =>
        new Date(error.timestamp).getTime() > oneHourAgo
        );
      default:
        return errorReports;
    }
  }, [errorReports]);

  // Export error reports
  const exportReports = useCallback(() => {
    try {
      const data = comprehensiveErrorTrackingService.exportErrorReports();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = `error-reports-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      if (enableNotifications) {
        toast.success('Export Complete', {
          description: 'Error reports have been downloaded successfully.'
        });
      }
    } catch (error) {
      console.error('[useErrorTracking] Export failed:', error);
      if (enableNotifications) {
        toast.error('Export Failed', {
          description: 'Failed to export error reports. Please try again.'
        });
      }
    }
  }, [enableNotifications]);

  // Initial data load
  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Auto refresh setup
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(refreshData, refreshInterval);
    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, refreshData]);

  return {
    logError,
    errorReports,
    statistics,
    isLoading,
    resolveError,
    retryOperation,
    clearAllErrors,
    refreshData,
    getErrorsByFilter,
    exportReports
  };
};

// Specialized hook for API error handling
export const useApiErrorTracking = () => {
  const { logError } = useErrorTracking();

  const handleApiError = useCallback(async (
  error: any,
  endpoint: string,
  method: string = 'GET',
  requestData?: any)
  : Promise<string> => {
    return await logError(error, {
      category: 'network',
      severity: error.status >= 500 ? 'high' : 'medium',
      action: `${method} ${endpoint}`,
      operation: 'API Request',
      requestDetails: {
        url: endpoint,
        method,
        body: requestData
      },
      additionalData: {
        statusCode: error.status,
        statusText: error.statusText,
        responseData: error.data
      }
    });
  }, [logError]);

  return { handleApiError, logError };
};

// Specialized hook for form error handling
export const useFormErrorTracking = () => {
  const { logError } = useErrorTracking();

  const handleFormError = useCallback(async (
  error: Error,
  formData: any,
  formAction: string)
  : Promise<string> => {
    return await logError(error, {
      category: 'validation',
      severity: 'medium',
      action: formAction,
      operation: 'Form Submission',
      userInputs: formData,
      formData,
      additionalData: {
        formAction,
        fieldCount: Object.keys(formData || {}).length
      }
    });
  }, [logError]);

  return { handleFormError, logError };
};

export default useErrorTracking;