import { useState, useCallback } from 'react';
import { validateField, validateForm, FieldValidation, ValidationResult } from '@/utils/formatValidation';

interface UseFormValidationOptions {
  initialValues: Record<string, any>;
  validationRules: Record<string, FieldValidation>;
  onSubmit?: (values: Record<string, any>) => Promise<void> | void;
}

interface UseFormValidationReturn {
  values: Record<string, any>;
  errors: Record<string, string>;
  touched: Record<string, boolean>;
  isValid: boolean;
  isSubmitting: boolean;
  setValue: (field: string, value: any) => void;
  setFieldTouched: (field: string, isTouched?: boolean) => void;
  validateField: (field: string) => ValidationResult;
  validateAll: () => boolean;
  handleSubmit: (e: React.FormEvent) => Promise<void>;
  reset: (newValues?: Record<string, any>) => void;
  setErrors: (errors: Record<string, string>) => void;
}

export const useFormValidation = ({
  initialValues,
  validationRules,
  onSubmit
}: UseFormValidationOptions): UseFormValidationReturn => {
  const [values, setValues] = useState<Record<string, any>>(initialValues);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const setValue = useCallback((field: string, value: any) => {
    setValues((prev) => ({ ...prev, [field]: value }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  }, [errors]);

  const setFieldTouched = useCallback((field: string, isTouched: boolean = true) => {
    setTouched((prev) => ({ ...prev, [field]: isTouched }));
  }, []);

  const validateFieldFn = useCallback((field: string): ValidationResult => {
    const rules = validationRules[field];
    if (!rules) return { isValid: true };

    return validateField(values[field], rules);
  }, [values, validationRules]);

  const validateAll = useCallback((): boolean => {
    const newErrors = validateForm(values, validationRules);
    setErrors(newErrors);

    // Mark all fields as touched
    const touchedFields: Record<string, boolean> = {};
    Object.keys(validationRules).forEach((field) => {
      touchedFields[field] = true;
    });
    setTouched(touchedFields);

    return Object.keys(newErrors).length === 0;
  }, [values, validationRules]);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateAll() || !onSubmit) return;

    setIsSubmitting(true);
    try {
      await onSubmit(values);
    } catch (error) {
      console.error('Form submission error:', error);
      throw error;
    } finally {
      setIsSubmitting(false);
    }
  }, [values, validateAll, onSubmit]);

  const reset = useCallback((newValues?: Record<string, any>) => {
    setValues(newValues || initialValues);
    setErrors({});
    setTouched({});
    setIsSubmitting(false);
  }, [initialValues]);

  const isValid = Object.keys(errors).length === 0 &&
  Object.keys(validationRules).every((field) => {
    const result = validateFieldFn(field);
    return result.isValid;
  });

  return {
    values,
    errors,
    touched,
    isValid,
    isSubmitting,
    setValue,
    setFieldTouched,
    validateField: validateFieldFn,
    validateAll,
    handleSubmit,
    reset,
    setErrors
  };
};

export default useFormValidation;