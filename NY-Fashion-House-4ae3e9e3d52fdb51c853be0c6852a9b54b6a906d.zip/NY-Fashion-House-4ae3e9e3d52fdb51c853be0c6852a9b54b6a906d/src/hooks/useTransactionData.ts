import { useState, useEffect, useCallback } from 'react';
import { toast } from '@/hooks/use-toast';
import { startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subYears } from 'date-fns';

interface Transaction {
  id: number;
  product_id: number;
  product_name: string;
  quantity_sold: number;
  unit_price: number;
  total_amount: number;
  sale_date: string;
  employee_id: number;
  employee_name: string;
  notes: string;
}

interface Invoice {
  id: number;
  invoice_number: string;
  customer_id: string;
  customer_name: string;
  customer_phone: string;
  issue_date: string;
  due_date: string;
  subtotal: number;
  discount_amount: number;
  tax_amount: number;
  total_amount: number;
  status: string;
  paid_amount: number;
  remaining_amount: number;
  created_at: string;
  updated_at: string;
}

interface DailySummary {
  today: number;
  todayTrend: number;
  week: number;
  weekTrend: number;
  month: number;
  monthTrend: number;
}

export const useTransactionData = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [dailySummary, setDailySummary] = useState<DailySummary>({
    today: 0,
    todayTrend: 0,
    week: 0,
    weekTrend: 0,
    month: 0,
    monthTrend: 0
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTransactions = useCallback(async () => {
    try {
      // Check if the API is available
      if (!window.ezsite?.apis?.tablePage) {
        throw new Error('Database API not available');
      }

      const { data, error } = await window.ezsite.apis.tablePage(38156, { // sales_transactions
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'sale_date',
        IsAsc: false
      });

      if (error) {
        console.error('Database error:', error);
        throw new Error(`Database operation failed: ${error}`);
      }

      const transactionList = data?.List || [];
      console.log('Fetched transactions:', transactionList.length);
      setTransactions(transactionList);
      return transactionList;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      console.error('Failed to fetch transactions:', errorMessage);
      throw new Error(`Failed to fetch transactions: ${errorMessage}`);
    }
  }, []);

  const fetchInvoices = useCallback(async () => {
    try {
      // Check if the API is available
      if (!window.ezsite?.apis?.tablePage) {
        console.warn('Database API not available, skipping invoice fetch');
        return [];
      }

      const { data, error } = await window.ezsite.apis.tablePage(38565, { // invoices
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: false
      });

      if (error) {
        console.warn('Invoice fetch failed:', error);
        return [];
      }

      const invoiceList = data?.List || [];
      console.log('Fetched invoices:', invoiceList.length);
      setInvoices(invoiceList);
      return invoiceList;
    } catch (err) {
      console.warn('Failed to fetch invoices:', err);
      return [];
    }
  }, []);

  const calculateDailySummary = useCallback((transactionList: Transaction[]) => {
    const now = new Date();
    const todayStart = startOfDay(now);
    const todayEnd = endOfDay(now);
    const weekStart = startOfWeek(now);
    const weekEnd = endOfWeek(now);
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    // Calculate current period totals
    const todayTotal = transactionList.
    filter((t) => {
      const date = new Date(t.sale_date);
      return date >= todayStart && date <= todayEnd;
    }).
    reduce((sum, t) => sum + (t.total_amount || 0), 0);

    const weekTotal = transactionList.
    filter((t) => {
      const date = new Date(t.sale_date);
      return date >= weekStart && date <= weekEnd;
    }).
    reduce((sum, t) => sum + (t.total_amount || 0), 0);

    const monthTotal = transactionList.
    filter((t) => {
      const date = new Date(t.sale_date);
      return date >= monthStart && date <= monthEnd;
    }).
    reduce((sum, t) => sum + (t.total_amount || 0), 0);

    // Calculate previous period totals for trends (simplified)
    const yesterdayStart = startOfDay(new Date(now.getTime() - 24 * 60 * 60 * 1000));
    const yesterdayEnd = endOfDay(new Date(now.getTime() - 24 * 60 * 60 * 1000));

    const yesterdayTotal = transactionList.
    filter((t) => {
      const date = new Date(t.sale_date);
      return date >= yesterdayStart && date <= yesterdayEnd;
    }).
    reduce((sum, t) => sum + (t.total_amount || 0), 0);

    // Calculate trends (simplified calculation)
    const todayTrend = yesterdayTotal > 0 ?
    (todayTotal - yesterdayTotal) / yesterdayTotal * 100 :
    0;

    setDailySummary({
      today: todayTotal,
      todayTrend: Math.round(todayTrend * 100) / 100,
      week: weekTotal,
      weekTrend: 5.2, // Mock trend - could be calculated
      month: monthTotal,
      monthTrend: 12.8 // Mock trend - could be calculated
    });
  }, []);

  const cleanupOldInvoices = useCallback(async () => {
    try {
      if (!window.ezsite?.apis?.tablePage) {
        console.warn('Database API not available, skipping cleanup');
        return;
      }

      const oneYearAgo = subYears(new Date(), 1);

      // Fetch old invoices to delete
      const { data, error } = await window.ezsite.apis.tablePage(38565, { // invoices
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'created_at',
        IsAsc: true, // Oldest first
        Filters: [
        {
          name: 'created_at',
          op: 'LessThan',
          value: oneYearAgo.toISOString()
        }]

      });

      if (error) {
        console.warn('Failed to fetch old invoices for cleanup:', error);
        return;
      }

      const oldInvoices = data?.List || [];

      // Delete old invoices one by one
      for (const invoice of oldInvoices) {
        try {
          if (window.ezsite?.apis?.tableDelete) {
            const { error: deleteError } = await window.ezsite.apis.tableDelete(38565, { ID: invoice.id });
            if (deleteError) {
              console.error(`Failed to delete invoice ${invoice.id}:`, deleteError);
            }
          }
        } catch (err) {
          console.error(`Error deleting invoice ${invoice.id}:`, err);
        }
      }

      // Also cleanup old transactions
      const { data: oldTransactionsData, error: transactionError } = await window.ezsite.apis.tablePage(38156, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'sale_date',
        IsAsc: true, // Oldest first
        Filters: [
        {
          name: 'sale_date',
          op: 'LessThan',
          value: oneYearAgo.toISOString()
        }]

      });

      if (!transactionError && oldTransactionsData?.List) {
        for (const transaction of oldTransactionsData.List) {
          try {
            if (window.ezsite?.apis?.tableDelete) {
              const { error: deleteError } = await window.ezsite.apis.tableDelete(38156, { ID: transaction.id });
              if (deleteError) {
                console.error(`Failed to delete transaction ${transaction.id}:`, deleteError);
              }
            }
          } catch (err) {
            console.error(`Error deleting transaction ${transaction.id}:`, err);
          }
        }
      }

      if (oldInvoices.length > 0 || (oldTransactionsData?.List?.length || 0) > 0) {
        console.log(`Cleanup completed: ${oldInvoices.length} invoices and ${oldTransactionsData?.List?.length || 0} transactions deleted`);
      }
    } catch (err) {
      console.error('Auto cleanup failed:', err);
      // Don't show error to user for background cleanup
    }
  }, []);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('Starting to fetch transaction data...');
      const [transactionList] = await Promise.all([
      fetchTransactions(),
      fetchInvoices() // This may fail silently if invoices table doesn't exist
      ]);

      calculateDailySummary(transactionList);
      console.log('Transaction data loaded successfully');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch data';
      console.error('Error in fetchData:', errorMessage);
      setError(errorMessage);
      toast({
        title: "Error loading data",
        description: "Failed to load transaction and invoice data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [fetchTransactions, fetchInvoices, calculateDailySummary]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const refetch = useCallback(() => {
    fetchData();
  }, [fetchData]);

  return {
    transactions,
    invoices,
    dailySummary,
    isLoading,
    error,
    refetch,
    cleanupOldInvoices
  };
};