import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Supplier } from '@/types/supplier';
import { supplierService } from '@/services/supplierService';
import { useAsyncOperation } from '@/hooks/use-async-operation';
import { useCallback } from 'react';

export interface UseSupplierListOptions {
  enabled?: boolean;
  refetchInterval?: number;
  staleTime?: number;
  retryCount?: number;
  onError?: (error: Error) => void;
  onSuccess?: (data: Supplier[]) => void;
}

export interface UseSupplierListReturn {
  suppliers: Supplier[];
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  isRefetching: boolean;
  isFetching: boolean;
  refetch: () => void;
  refresh: () => Promise<void>;
  isEmpty: boolean;
  hasActiveSuppliers: boolean;
  totalCount: number;
  getSupplierById: (id: string) => Supplier | undefined;
  getSupplierByName: (name: string) => Supplier | undefined;
  activeSuppliers: Supplier[];
  inactiveSuppliers: Supplier[];
}

export const useSupplierList = (options: UseSupplierListOptions = {}): UseSupplierListReturn => {
  const {
    enabled = true,
    refetchInterval,
    staleTime = 30 * 1000, // 30 seconds
    retryCount = 3,
    onError,
    onSuccess
  } = options;

  const queryClient = useQueryClient();

  // Use React Query for data fetching with comprehensive error handling
  const {
    data: suppliers = [],
    isLoading,
    isError,
    error,
    isRefetching,
    isFetching,
    refetch
  } = useQuery({
    queryKey: ['suppliers', 'list'],
    queryFn: async () => {
      try {
        const data = await supplierService.getAllSuppliers();
        if (onSuccess) {
          onSuccess(data);
        }
        return data;
      } catch (err) {
        const error = err instanceof Error ? err : new Error('Failed to fetch suppliers');
        if (onError) {
          onError(error);
        }
        throw error;
      }
    },
    enabled,
    staleTime,
    refetchInterval,
    refetchOnWindowFocus: true,
    retry: (failureCount, error) => {
      // Don't retry on certain error types
      if (error instanceof Error && error.message.includes('Network')) {
        return failureCount < retryCount;
      }
      return failureCount < Math.max(1, retryCount - 1);
    },
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000), // Exponential backoff with max 30s
    meta: {
      errorMessage: 'Failed to load suppliers. Please check your connection and try again.'
    }
  });

  // Enhanced refresh operation with async handling
  const { execute: executeRefresh } = useAsyncOperation({
    showToast: false, // Let the consumer handle toast messages
    retryCount: 2,
    retryDelay: 1000
  });

  const refresh = useCallback(async (): Promise<void> => {
    await executeRefresh(async () => {
      await queryClient.invalidateQueries({ queryKey: ['suppliers'] });
      const result = await refetch();
      return result.data || [];
    });
  }, [executeRefresh, queryClient, refetch]);

  // Helper functions and computed values
  const getSupplierById = useCallback((id: string) => {
    return suppliers.find((supplier) => supplier.id === id);
  }, [suppliers]);

  const getSupplierByName = useCallback((name: string) => {
    return suppliers.find((supplier) =>
    supplier.name.toLowerCase().includes(name.toLowerCase())
    );
  }, [suppliers]);

  const activeSuppliers = suppliers.filter((supplier) => supplier.status === 'active');
  const inactiveSuppliers = suppliers.filter((supplier) => supplier.status !== 'active');

  return {
    suppliers,
    isLoading,
    isError,
    error: error as Error | null,
    isRefetching,
    isFetching,
    refetch: () => void refetch(),
    refresh,
    isEmpty: suppliers.length === 0,
    hasActiveSuppliers: activeSuppliers.length > 0,
    totalCount: suppliers.length,
    getSupplierById,
    getSupplierByName,
    activeSuppliers,
    inactiveSuppliers
  };
};

export default useSupplierList;