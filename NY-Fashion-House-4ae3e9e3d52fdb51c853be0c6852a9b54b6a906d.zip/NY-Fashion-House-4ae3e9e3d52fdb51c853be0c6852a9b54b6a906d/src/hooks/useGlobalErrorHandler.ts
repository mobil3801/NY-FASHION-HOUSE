// Hook for global error handling integration
import { useCallback } from 'react';
import { ErrorContext } from '@/types/errorTypes';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import { enhancedDevToolsErrorService } from '@/services/enhancedDevToolsErrorService';
import { toast } from 'sonner';

interface GlobalErrorHandlerOptions {
  showToast?: boolean;
  toastDuration?: number;
  context?: Partial<ErrorContext>;
}

export const useGlobalErrorHandler = (options: GlobalErrorHandlerOptions = {}) => {
  const { showToast = true, toastDuration = 5000, context = {} } = options;

  const handleError = useCallback((
  error: Error,
  additionalContext: Partial<ErrorContext> = {})
  : string => {
    // Combine context
    const fullContext: ErrorContext = {
      ...context,
      ...additionalContext,
      route: window.location.pathname,
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString()
    };

    // Log error and get correlation ID
    const correlationId = enhancedErrorLoggingService.logError(error, fullContext);

    // Show user-friendly toast notification
    if (showToast) {
      const report = enhancedErrorLoggingService.getErrorReport(correlationId);
      const message = report?.title || 'An unexpected error occurred';

      toast.error(message, {
        description: `Error ID: ${correlationId}`,
        duration: toastDuration,
        action: {
          label: 'Details',
          onClick: () => {
            // Could trigger a global error report modal here
            console.log('Show error details for:', correlationId);
          }
        }
      });
    }

    return correlationId;
  }, [context, showToast, toastDuration]);

  const handleAsyncError = useCallback(async <T,>(
  asyncOperation: () => Promise<T>,
  errorContext: Partial<ErrorContext> = {})
  : Promise<T | null> => {
    try {
      return await asyncOperation();
    } catch (error) {
      handleError(error as Error, {
        ...errorContext,
        action: errorContext.action || 'Async operation',
        severity: errorContext.severity || 'medium'
      });
      return null;
    }
  }, [handleError]);

  const createErrorHandler = useCallback((
  action: string,
  additionalContext: Partial<ErrorContext> = {}) =>
  {
    return (error: Error) => {
      return handleError(error, {
        ...additionalContext,
        action,
        operation: action
      });
    };
  }, [handleError]);

  return {
    handleError,
    handleAsyncError,
    createErrorHandler,
    getErrorReport: (correlationId: string) =>
    enhancedErrorLoggingService.getErrorReport(correlationId),
    getErrorStatistics: () =>
    enhancedErrorLoggingService.getErrorStatistics()
  };
};

export default useGlobalErrorHandler;