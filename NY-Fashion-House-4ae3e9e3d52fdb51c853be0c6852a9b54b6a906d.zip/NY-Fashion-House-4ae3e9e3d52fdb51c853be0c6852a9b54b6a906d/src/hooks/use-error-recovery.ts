import { useState, useCallback, useRef } from 'react';
import { errorLoggingService } from '@/services/errorLoggingService';

interface ErrorRecoveryOptions {
  maxRetries?: number;
  retryDelay?: number;
  onMaxRetriesReached?: (error: Error) => void;
  shouldRetry?: (error: Error, retryCount: number) => boolean;
}

export function useErrorRecovery(options: ErrorRecoveryOptions = {}) {
  const [retryCount, setRetryCount] = useState(0);
  const [isRetrying, setIsRetrying] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const {
    maxRetries = 3,
    retryDelay = 1000,
    onMaxRetriesReached,
    shouldRetry = () => true
  } = options;

  const retry = useCallback(async <T,>(
  operation: () => Promise<T>,
  onError?: (error: Error) => void)
  : Promise<T | null> => {
    if (retryCount >= maxRetries) {
      const error = new Error(`Maximum retry attempts (${maxRetries}) reached`);
      if (onMaxRetriesReached) {
        onMaxRetriesReached(error);
      }
      return null;
    }

    setIsRetrying(true);

    try {
      const result = await operation();
      setRetryCount(0);
      setIsRetrying(false);
      return result;
    } catch (error) {
      const err = error as Error;

      errorLoggingService.logError(err, {
        severity: 'medium',
        context: {
          retryAttempt: retryCount + 1,
          maxRetries,
          operation: operation.name || 'retry-operation'
        }
      });

      if (!shouldRetry(err, retryCount)) {
        setIsRetrying(false);
        if (onError) {
          onError(err);
        }
        return null;
      }

      const newRetryCount = retryCount + 1;
      setRetryCount(newRetryCount);

      if (newRetryCount >= maxRetries) {
        setIsRetrying(false);
        if (onMaxRetriesReached) {
          onMaxRetriesReached(err);
        }
        return null;
      }

      // Exponential backoff
      const delay = retryDelay * Math.pow(2, newRetryCount - 1);

      return new Promise((resolve) => {
        timeoutRef.current = setTimeout(async () => {
          const result = await retry(operation, onError);
          resolve(result);
        }, delay);
      });
    }
  }, [retryCount, maxRetries, retryDelay, shouldRetry, onMaxRetriesReached]);

  const reset = useCallback(() => {
    setRetryCount(0);
    setIsRetrying(false);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
  }, []);

  return {
    retry,
    retryCount,
    isRetrying,
    reset,
    canRetry: retryCount < maxRetries
  };
}

export default useErrorRecovery;