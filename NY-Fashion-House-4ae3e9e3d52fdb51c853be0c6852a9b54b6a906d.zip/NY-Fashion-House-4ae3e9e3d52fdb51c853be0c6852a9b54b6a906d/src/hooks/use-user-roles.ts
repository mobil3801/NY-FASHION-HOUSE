import { useState, useEffect } from 'react';

interface UserInfo {
  ID: number;
  Name: string;
  Email: string;
  CreateTime: string;
  Roles: string;
}

interface UseUserRolesReturn {
  userRoles: string[];
  isAdmin: boolean;
  isSales: boolean;
  isGeneralUser: boolean;
  canDeleteInvoices: boolean;
  canManageInvoices: boolean;
  canViewInvoices: boolean;
  loading: boolean;
  error: string | null;
}

export const useUserRoles = (): UseUserRolesReturn => {
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        setLoading(true);
        setError(null);

        if (!window.ezsite?.apis?.getUserInfo) {
          throw new Error('Authentication service not available');
        }

        const { data, error: apiError } = await window.ezsite.apis.getUserInfo();

        if (apiError) {
          throw new Error(apiError);
        }

        if (!data) {
          throw new Error('No user information available');
        }

        setUserInfo(data);
      } catch (err) {
        console.error('Error fetching user roles:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch user information');
      } finally {
        setLoading(false);
      }
    };

    fetchUserInfo();
  }, []);

  const userRoles = userInfo?.Roles ? userInfo.Roles.split(',') : [];

  const isAdmin = userRoles.includes('Administrator');
  const isSales = userRoles.includes('r-WzDn7C'); // Sales role code
  const isGeneralUser = userRoles.includes('GeneralUser');

  // Permission calculations
  const canDeleteInvoices = isAdmin;
  const canManageInvoices = isAdmin || isSales;
  const canViewInvoices = isAdmin || isSales; // General users have limited access

  return {
    userRoles,
    isAdmin,
    isSales,
    isGeneralUser,
    canDeleteInvoices,
    canManageInvoices,
    canViewInvoices,
    loading,
    error
  };
};