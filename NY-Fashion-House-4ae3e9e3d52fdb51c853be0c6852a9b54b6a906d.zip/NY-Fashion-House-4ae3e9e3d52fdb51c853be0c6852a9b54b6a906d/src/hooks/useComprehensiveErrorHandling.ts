import { useCallback, useEffect, useMemo, useState } from 'react';
import { useError } from '../components/comprehensive/ComprehensiveErrorProvider';
import { ErrorMetadata } from '../services/comprehensiveErrorManager';
import { optimizedErrorCaptureService } from '../services/optimizedErrorCaptureService';
import { toast } from '../components/ui/use-toast';

interface ErrorHandlingOptions {
  component?: string;
  enableToasts?: boolean;
  enableConsoleLogging?: boolean;
  retryOptions?: {
    maxRetries: number;
    retryDelay: number;
    backoffFactor: number;
  };
  fallbackValue?: any;
}

interface ErrorHandlingReturn {
  captureError: (error: Error, context?: Record<string, any>) => string;
  captureAsyncError: <T>(
  asyncFn: () => Promise<T>,
  context?: Record<string, any>)
  => Promise<T | null>;
  withErrorHandling: <T extends any[], R>(
  fn: (...args: T) => R,
  context?: Record<string, any>)
  => (...args: T) => R | null;
  withAsyncErrorHandling: <T extends any[], R>(
  fn: (...args: T) => Promise<R>,
  context?: Record<string, any>)
  => (...args: T) => Promise<R | null>;
  retry: <T>(
  fn: () => Promise<T>,
  options?: {maxRetries?: number;delay?: number;})
  => Promise<T>;
  errors: ErrorMetadata[];
  clearComponentErrors: () => void;
  getErrorStats: () => {
    total: number;
    byLevel: Record<string, number>;
    recent: ErrorMetadata[];
  };
}

export const useComprehensiveErrorHandling = (
options: ErrorHandlingOptions = {})
: ErrorHandlingReturn => {
  const {
    component,
    enableToasts = true,
    enableConsoleLogging = process.env.NODE_ENV === 'development',
    retryOptions = { maxRetries: 3, retryDelay: 1000, backoffFactor: 2 },
    fallbackValue = null
  } = options;

  const { captureError: contextCaptureError, errors, getErrorsByComponent } = useError();
  const [componentErrors, setComponentErrors] = useState<ErrorMetadata[]>([]);

  // Update component errors when errors change
  useEffect(() => {
    if (component) {
      const filtered = getErrorsByComponent(component);
      setComponentErrors(filtered);
    }
  }, [errors, component, getErrorsByComponent]);

  const captureError = useCallback((error: Error, context: Record<string, any> = {}): string => {
    const errorId = contextCaptureError(error, {
      component,
      context: {
        ...context,
        timestamp: Date.now(),
        userAgent: navigator.userAgent,
        url: window.location.href
      }
    });

    // Console logging in development
    if (enableConsoleLogging) {
      console.group(`[Error] ${component || 'Component'}`);
      console.error(error);
      console.log('Context:', context);
      console.log('Error ID:', errorId);
      console.groupEnd();
    }

    // Toast notification
    if (enableToasts) {
      toast({
        title: 'Error Occurred',
        description: error.message,
        variant: 'destructive'
      });
    }

    return errorId;
  }, [contextCaptureError, component, enableConsoleLogging, enableToasts]);

  const captureAsyncError = useCallback(async <T,>(
  asyncFn: () => Promise<T>,
  context: Record<string, any> = {})
  : Promise<T | null> => {
    try {
      return await asyncFn();
    } catch (error) {
      captureError(error as Error, {
        ...context,
        type: 'async',
        operation: 'captureAsyncError'
      });
      return fallbackValue;
    }
  }, [captureError, fallbackValue]);

  const withErrorHandling = useCallback(<T extends any[], R>(
  fn: (...args: T) => R,
  context: Record<string, any> = {}) =>
  {
    return (...args: T): R | null => {
      try {
        return fn(...args);
      } catch (error) {
        captureError(error as Error, {
          ...context,
          type: 'sync',
          operation: 'withErrorHandling',
          arguments: args
        });
        return fallbackValue;
      }
    };
  }, [captureError, fallbackValue]);

  const withAsyncErrorHandling = useCallback(<T extends any[], R>(
  fn: (...args: T) => Promise<R>,
  context: Record<string, any> = {}) =>
  {
    return async (...args: T): Promise<R | null> => {
      try {
        return await fn(...args);
      } catch (error) {
        captureError(error as Error, {
          ...context,
          type: 'async',
          operation: 'withAsyncErrorHandling',
          arguments: args
        });
        return fallbackValue;
      }
    };
  }, [captureError, fallbackValue]);

  const retry = useCallback(async <T,>(
  fn: () => Promise<T>,
  options: {maxRetries?: number;delay?: number;} = {})
  : Promise<T> => {
    const { maxRetries = retryOptions.maxRetries, delay = retryOptions.retryDelay } = options;
    let lastError: Error;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await fn();
      } catch (error) {
        lastError = error as Error;

        if (attempt === maxRetries) {
          captureError(lastError, {
            type: 'retry_exhausted',
            maxRetries,
            finalAttempt: attempt
          });
          throw lastError;
        }

        // Calculate backoff delay
        const backoffDelay = delay * Math.pow(retryOptions.backoffFactor, attempt);
        await new Promise((resolve) => setTimeout(resolve, backoffDelay));

        // Log retry attempt
        if (enableConsoleLogging) {
          console.log(`Retry attempt ${attempt + 1}/${maxRetries} for:`, lastError.message);
        }
      }
    }

    throw lastError!;
  }, [captureError, retryOptions, enableConsoleLogging]);

  const clearComponentErrors = useCallback(() => {
    if (component) {
      // This would ideally clear errors specific to this component
      // For now, we'll clear local component errors
      setComponentErrors([]);
    }
  }, [component]);

  const getErrorStats = useCallback(() => {
    const relevantErrors = component ? componentErrors : errors;

    const byLevel = relevantErrors.reduce((acc, error) => {
      acc[error.level] = (acc[error.level] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const recent = relevantErrors.
    sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()).
    slice(0, 5);

    return {
      total: relevantErrors.length,
      byLevel,
      recent
    };
  }, [component, componentErrors, errors]);

  return {
    captureError,
    captureAsyncError,
    withErrorHandling,
    withAsyncErrorHandling,
    retry,
    errors: component ? componentErrors : errors,
    clearComponentErrors,
    getErrorStats
  };
};

export default useComprehensiveErrorHandling;