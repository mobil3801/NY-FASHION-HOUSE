// Enhanced main.tsx with comprehensive error handling setup
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Import and setup enhanced global error handlers immediately
import { setupEnhancedGlobalErrorHandlers } from '@/utils/enhancedGlobalErrorHandler';

// Setup global error handlers before anything else
setupEnhancedGlobalErrorHandlers();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);