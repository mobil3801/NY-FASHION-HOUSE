// Enhanced App.tsx with comprehensive production-ready error handling
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { requestSizeManager } from '@/utils/requestSizeManager';
import { GlobalErrorProvider } from '@/components/enhanced/GlobalErrorProvider';
import { FinalErrorBoundary } from './components/error-system/FinalErrorBoundary';
import { Toaster as SonnerToaster } from 'sonner';
import EnhancedErrorBoundary from '@/components/enhanced/EnhancedErrorBoundary';

// Master Error Handling System - Production Ready
import { MasterErrorBoundary } from '@/components/master/MasterErrorBoundary';
import { MasterErrorManager } from '@/services/masterErrorManager';

// Production-ready comprehensive error handling system
import UniversalErrorBoundary from '@/components/universal/UniversalErrorBoundary';
import { SalesAuthProvider } from '@/contexts/SalesAuthContext';
import { ErrorTrackingProvider } from '@/components/ErrorTrackingProvider';

// Comprehensive Error Handling - Enhanced
import { ComprehensiveErrorProvider } from '@/components/comprehensive/ComprehensiveErrorProvider';
import { ComprehensiveErrorBoundary } from '@/components/comprehensive/ComprehensiveErrorBoundary';

// Initialize master error management system
import { centralizedErrorManager } from '@/services/centralizedErrorManager';
import { automatedErrorAnalyzer } from '@/services/automatedErrorAnalyzer';

// Initialize Master Error Management System
const masterErrorManager = new MasterErrorManager();

// Initialize Finalized Error Management System
import { finalizedErrorManagementSystem } from '@/services/finalizedErrorManagementSystem';
console.log('[APP] Finalized Error Management System initialized');
console.log('[APP] Stream error handling active');
console.log('[APP] Performance optimization and pattern detection enabled');
console.log('[APP] Master Error Management System initialized');
console.log('[APP] Advanced pattern detection and performance optimization active');

// Layout and pages
import Layout from '@/components/Layout';
import HomePage from '@/pages/HomePage';
import CustomerManagementPage from '@/pages/CustomerManagementPage';
import ProductManagementPage from '@/pages/ProductManagementPage';
import POSPage from '@/pages/POSPage';
import EmployeeManagementPage from '@/pages/EmployeeManagementPage';
import SalaryManagementPage from '@/pages/SalaryManagementPage';
import AccountingPage from '@/pages/AccountingPage';
import ReportsPage from '@/pages/ReportsPage';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AuditLogsPage from '@/pages/admin/AuditLogsPage';
import UserManagementPage from '@/pages/UserManagementPage';
import RoleManagementPage from '@/pages/RoleManagementPage';
import SystemSettingsPage from '@/pages/SystemSettingsPage';
import DataManagementPage from '@/pages/DataManagementPage';
import BackupManagementPage from '@/pages/BackupManagementPage';
import SalesLoginPage from '@/pages/SalesLoginPage';
import SalesDashboard from '@/pages/SalesDashboard';
import QADashboard from '@/pages/QADashboard';
import PerformanceTestingPage from '@/pages/PerformanceTestingPage';
import TransactionManagementPage from '@/pages/TransactionManagementPage';
import InvoiceManagementPage from '@/pages/InvoiceManagementPage';
import ComprehensiveDataVerificationPage from '@/pages/ComprehensiveDataVerificationPage';
import SupplierManagement from '@/components/SupplierManagement';
import ErrorDashboard from '@/components/ErrorDashboard';
import ErrorTrackingTestPage from '@/pages/ErrorTrackingTestPage';
import EnhancedTestDashboard from '@/pages/EnhancedTestDashboard';
import CrossBrowserErrorTestPage from '@/pages/CrossBrowserErrorTestPage';
import ErrorManagementPage from '@/pages/ErrorManagementPage';
import TestDashboard from '@/pages/TestDashboard';
import ComprehensiveErrorManagementPage from '@/pages/ComprehensiveErrorManagementPage';
import FinalizedErrorManagementPage from '@/pages/FinalizedErrorManagementPage';

// Training and monitoring components
import ErrorHandlingTrainingDashboard from '@/components/training/ErrorHandlingTrainingDashboard';
import ComprehensiveErrorMonitoringDashboard from '@/components/monitoring/ComprehensiveErrorMonitoringDashboard';

// Enhanced global error handlers and comprehensive error tracking
import { setupEnhancedGlobalErrorHandlers } from '@/utils/enhancedGlobalErrorHandler';
import { comprehensiveErrorTrackingService } from '@/services/comprehensiveErrorTrackingService';

// Setup global error handlers
setupEnhancedGlobalErrorHandlers();

// Initialize comprehensive error tracking with centralized management
console.log('[APP] Production-ready comprehensive error handling system initialized');
console.log('[APP] Centralized error manager active');
console.log('[APP] Automated error analyzer active');

// Create query client with enhanced error handling and centralized management
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: (failureCount, error) => {
        // Log query errors to centralized system
        centralizedErrorManager.logError(error as Error, {
          category: 'network',
          severity: 'medium',
          action: 'React Query Request',
          operation: 'Data Fetching',
          additionalData: { failureCount, retryAttempt: true }
        });

        // Don't retry on certain errors
        if (error && typeof error === 'object' && 'status' in error) {
          const status = (error as any).status;
          if (status === 401 || status === 403 || status === 404) {
            return false;
          }
        }
        return failureCount < 3;
      },
      staleTime: 5 * 60 * 1000 // 5 minutes
    },
    mutations: {
      retry: 1,
      onError: (error) => {
        // Log mutation errors to centralized system
        centralizedErrorManager.logError(error as Error, {
          category: 'client',
          severity: 'high',
          action: 'React Query Mutation',
          operation: 'Data Modification'
        });
      }
    }
  }
});

function App() {
  return (
    <MasterErrorBoundary
      level="app"
      context="main-application"
      enableAutoRecovery={true}
      maxRetries={3}>

      <UniversalErrorBoundary
        level="root"
        componentName="Application"
        enableRetry={true}
        enableReporting={true}
        showErrorDetails={process.env.NODE_ENV === 'development'}>

      <ErrorTrackingProvider level="root" component="App">
        <QueryClientProvider client={queryClient}>
          <ThemeProvider defaultTheme="light" storageKey="ui-theme">
            <ComprehensiveErrorProvider
                enableAnalytics={true}
                enableToasts={true}
                toastCriticalErrors={true}>

              <GlobalErrorProvider>
                <FinalErrorBoundary level="page" identifier="app-root">
                  <SalesAuthProvider>
                  <Router>
                  <Routes>
                <Route path="/" element={
                          <UniversalErrorBoundary level="route" componentName="Layout" enableRetry={true}>
                    <Layout />
                  </UniversalErrorBoundary>
                          }>
                  <Route index element={
                            <UniversalErrorBoundary level="route" componentName="HomePage" enableRetry={true}>
                      <HomePage />
                    </UniversalErrorBoundary>
                            } />
                  <Route path="customers" element={
                            <UniversalErrorBoundary level="route" componentName="CustomerManagementPage" enableRetry={true}>
                      <CustomerManagementPage />
                    </UniversalErrorBoundary>
                            } />
                  <Route path="products" element={
                            <UniversalErrorBoundary level="route" componentName="ProductManagementPage" enableRetry={true}>
                      <ProductManagementPage />
                    </UniversalErrorBoundary>
                            } />
                  <Route path="pos" element={
                            <UniversalErrorBoundary level="route" componentName="POSPage" enableRetry={true}>
                      <POSPage />
                    </UniversalErrorBoundary>
                            } />
                  <Route path="employees" element={
                            <EnhancedErrorBoundary level="page" component="EmployeeManagementPage">
                      <EmployeeManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="salary" element={
                            <EnhancedErrorBoundary level="page" component="SalaryManagementPage">
                      <SalaryManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="accounting" element={
                            <EnhancedErrorBoundary level="page" component="AccountingPage">
                      <AccountingPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="reports" element={
                            <EnhancedErrorBoundary level="page" component="ReportsPage">
                      <ReportsPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="admin" element={
                            <EnhancedErrorBoundary level="page" component="AdminDashboard">
                      <AdminDashboard />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="admin/audit" element={
                            <EnhancedErrorBoundary level="page" component="AuditLogsPage">
                      <AuditLogsPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="users" element={
                            <EnhancedErrorBoundary level="page" component="UserManagementPage">
                      <UserManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="roles" element={
                            <EnhancedErrorBoundary level="page" component="RoleManagementPage">
                      <RoleManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="settings" element={
                            <EnhancedErrorBoundary level="page" component="SystemSettingsPage">
                      <SystemSettingsPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="data" element={
                            <EnhancedErrorBoundary level="page" component="DataManagementPage">
                      <DataManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="backup" element={
                            <EnhancedErrorBoundary level="page" component="BackupManagementPage">
                      <BackupManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="transactions" element={
                            <EnhancedErrorBoundary level="page" component="TransactionManagementPage">
                      <TransactionManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="transaction-management" element={
                            <EnhancedErrorBoundary level="page" component="TransactionManagementPage">
                      <TransactionManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="suppliers" element={
                            <EnhancedErrorBoundary level="page" component="SupplierManagement">
                      <SupplierManagement />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="invoices" element={
                            <EnhancedErrorBoundary level="page" component="InvoiceManagementPage">
                      <InvoiceManagementPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="qa" element={
                            <EnhancedErrorBoundary level="page" component="QADashboard">
                      <QADashboard />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="performance" element={
                            <EnhancedErrorBoundary level="page" component="PerformanceTestingPage">
                      <PerformanceTestingPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="data-verification" element={
                            <EnhancedErrorBoundary level="page" component="ComprehensiveDataVerificationPage">
                      <ComprehensiveDataVerificationPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="error-dashboard" element={
                            <EnhancedErrorBoundary level="page" component="ErrorDashboard">
                      <ErrorDashboard />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="error-testing" element={
                            <EnhancedErrorBoundary level="page" component="ErrorTrackingTestPage">
                      <ErrorTrackingTestPage />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="test-dashboard" element={
                            <EnhancedErrorBoundary level="page" component="TestDashboard">
                      <TestDashboard />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="enhanced-testing" element={
                            <EnhancedErrorBoundary level="page" component="EnhancedTestDashboard">
                      <EnhancedTestDashboard />
                    </EnhancedErrorBoundary>
                            } />
                  <Route path="cross-browser-error-tests" element={
                            <UniversalErrorBoundary level="route" componentName="CrossBrowserErrorTestPage" enableRetry={true}>
                      <CrossBrowserErrorTestPage />
                    </UniversalErrorBoundary>
                            } />
                  
                  {/* Error Management */}
                  <Route path="error-management" element={
                            <ComprehensiveErrorBoundary fallbackType="full">
                      <ErrorManagementPage />
                    </ComprehensiveErrorBoundary>
                            } />
                  <Route path="comprehensive-error-management" element={
                            <MasterErrorBoundary level="page" context="comprehensive-error-management">
                      <ComprehensiveErrorManagementPage />
                    </MasterErrorBoundary>
                            } />
                  <Route path="finalized-error-management" element={
                            <MasterErrorBoundary level="page" context="finalized-error-management">
                      <FinalizedErrorManagementPage />
                    </MasterErrorBoundary>
                            } />
                  <Route path="error-training" element={
                            <UniversalErrorBoundary level="route" componentName="ErrorHandlingTrainingDashboard" enableRetry={true}>
                      <ErrorHandlingTrainingDashboard />
                    </UniversalErrorBoundary>
                            } />
                  <Route path="error-monitoring" element={
                            <UniversalErrorBoundary level="route" componentName="ComprehensiveErrorMonitoringDashboard" enableRetry={true}>
                      <ComprehensiveErrorMonitoringDashboard />
                    </UniversalErrorBoundary>
                            } />
                </Route>
                
                {/* Standalone routes */}
                <Route path="/sales-login" element={
                          <EnhancedErrorBoundary level="page" component="SalesLoginPage">
                    <SalesLoginPage />
                  </EnhancedErrorBoundary>
                          } />
                <Route path="/sales-dashboard" element={
                          <EnhancedErrorBoundary level="page" component="SalesDashboard">
                    <SalesDashboard />
                  </EnhancedErrorBoundary>
                          } />
              </Routes>
            </Router>
              </SalesAuthProvider>
              
              {/* Toast notifications */}
              <Toaster />
              <SonnerToaster position="top-right" richColors />
                </FinalErrorBoundary>
              </GlobalErrorProvider>
            </ComprehensiveErrorProvider>
          </ThemeProvider>
        </QueryClientProvider>
      </ErrorTrackingProvider>
    </UniversalErrorBoundary>
    </MasterErrorBoundary>);

}


export default App;