
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      // Navigation
      'nav.dashboard': 'Dashboard',
      'nav.customers': 'Customers',
      'nav.products': 'Products',
      'nav.pos': 'Point of Sale',
      'nav.employees': 'Employees',
      'nav.salary': 'Payroll',
      'nav.accounting': 'Accounting',
      'nav.reports': 'Reports',

      // POS Interface
      'pos.title': 'Point of Sale',
      'pos.search.placeholder': 'Search products by name, SKU, or scan barcode...',
      'pos.cart.title': 'Shopping Cart',
      'pos.cart.empty': 'Cart is empty',
      'pos.cart.subtotal': 'Subtotal',
      'pos.cart.discount': 'Discount',
      'pos.cart.tax': 'Sales Tax',
      'pos.cart.total': 'Total',
      'pos.customer.select': 'Select Customer',
      'pos.customer.none': 'Walk-in Customer',
      'pos.customer.quick_add': 'Quick Add Customer',
      'pos.payment.method': 'Payment Method',
      'pos.payment.cash': 'Cash',
      'pos.payment.card': 'Credit/Debit Card',
      'pos.payment.mobile': 'Mobile Payment',
      'pos.payment.wallet': 'Digital Wallet',
      'pos.checkout.button': 'Complete Sale',
      'pos.receipt.print': 'Print Receipt',

      // Product
      'product.stock': 'Stock',
      'product.price': 'Price',
      'product.add_to_cart': 'Add to Cart',
      'product.out_of_stock': 'Out of Stock',

      // Cart
      'cart.item.remove': 'Remove',
      'cart.item.quantity': 'Qty',

      // Payment
      'payment.cash_received': 'Cash Received',
      'payment.change': 'Change',
      'payment.card_number': 'Card Number',
      'payment.mobile_number': 'Mobile Number',
      'payment.transaction_id': 'Transaction ID',

      // Messages
      'message.sale_completed': 'Sale completed successfully!',
      'message.receipt_generated': 'Receipt generated',
      'message.insufficient_stock': 'Insufficient stock for this item',
      'message.customer_added': 'Customer added successfully',
      'message.invalid_payment': 'Invalid payment details',

      // Common
      'common.add': 'Add',
      'common.remove': 'Remove',
      'common.update': 'Update',
      'common.cancel': 'Cancel',
      'common.save': 'Save',
      'common.search': 'Search',
      'common.clear': 'Clear',
      'common.name': 'Name',
      'common.phone': 'Phone',
      'common.email': 'Email',
      'common.address': 'Address',
      'common.date': 'Date',
      'common.time': 'Time',
      'common.amount': 'Amount',
      'common.status': 'Status',
      'common.actions': 'Actions',

      // Reports
      'Reports Dashboard': 'Reports Dashboard',
      'Comprehensive business analytics and reporting': 'Comprehensive business analytics and reporting',
      'Today\'s Sales': 'Today\'s Sales',
      'Active Customers': 'Active Customers',
      'Low Stock Items': 'Low Stock Items',
      'Scheduled Reports': 'Scheduled Reports',
      'Failed to load reports': 'Failed to load reports',
      'Reports updated': 'Reports updated',
      'Please wait for all reports to load': 'Please wait for all reports to load',
      'Sales Report': 'Sales Report',
      'Date': 'Date',
      'Sales': 'Sales',
      'Orders': 'Orders',
      'Total Sales': 'Total Sales',
      'Total Orders': 'Total Orders',
      'Customer Analytics': 'Customer Analytics',
      'Customer': 'Customer',
      'Total Spent': 'Total Spent',
      'Financial Summary': 'Financial Summary',
      'Month': 'Month',
      'Revenue': 'Revenue',
      'Expenses': 'Expenses',
      'Profit': 'Profit',
      'Total Revenue': 'Total Revenue',
      'Net Profit': 'Net Profit',
      'Reports exported successfully': 'Reports exported successfully',
      'Refresh': 'Refresh',
      'Export All': 'Export All',
      'Inventory': 'Inventory',
      'Customers': 'Customers',
      'Employees': 'Employees',
      'Financial': 'Financial',
      'Scheduler': 'Scheduler',
      'Loading sales report...': 'Loading sales report...',
      'Loading inventory report...': 'Loading inventory report...',
      'Loading customer analytics...': 'Loading customer analytics...',
      'Loading financial summary...': 'Loading financial summary...',

      // USA Tax System
      'tax.sales_tax': 'Sales Tax',
      'tax.federal_tax': 'Federal Tax',
      'tax.state_tax': 'State Tax',
      'tax.income_tax': 'Income Tax',
      'tax.payroll_tax': 'Payroll Tax',

      // USA Accounting Standards
      'accounting.gaap': 'GAAP Compliant',
      'accounting.assets': 'Assets',
      'accounting.liabilities': 'Liabilities',
      'accounting.equity': 'Equity',
      'accounting.accounts_receivable': 'Accounts Receivable',
      'accounting.accounts_payable': 'Accounts Payable',
      'accounting.cash_flow': 'Cash Flow',
      'accounting.income_statement': 'Income Statement',
      'accounting.balance_sheet': 'Balance Sheet',

      // Business Information - USA based
      'business.name': 'Fashion Boutique USA',
      'business.address': '1234 Fashion Avenue, New York, NY 10001',
      'business.phone': '(555) 123-4567',
      'business.email': 'info@fashionboutiqueusa.com',
      'business.tax_id': 'EIN: 12-3456789',
      'business.website': 'www.fashionboutiqueusa.com',

      // Date/Time formats - USA standards
      'format.date': 'MM/dd/yyyy',
      'format.time': 'h:mm a',
      'format.datetime': 'MM/dd/yyyy h:mm a',

      // Currency - USA standards
      'currency.symbol': '$',
      'currency.name': 'USD',
      'currency.code': 'USD',
      'currency.format': 'currency',

      // Product Categories - Bangladeshi women's clothing
      'category.sari': 'Sari',
      'category.tant_sari': 'Tant Sari',
      'category.jamdani_sari': 'Jamdani Sari',
      'category.tangail_sari': 'Tangail Sari',
      'category.salwar_kameez': 'Salwar Kameez',
      'category.lehenga': 'Lehenga',
      'category.kurti': 'Kurti',
      'category.gamcha': 'Gamcha',
      'category.dupatta': 'Dupatta',
      'category.pathin': 'Pathin',
      'category.agrun': 'Agrun',
      'category.grameen_check': 'Grameen Check garments'
    }
  }
};

i18n.
use(initReactI18next).
init({
  resources,
  lng: 'en', // English (USA) as default and only language
  fallbackLng: 'en',
  interpolation: {
    escapeValue: false
  },
  // USA locale settings
  defaultNS: 'translation',
  ns: ['translation'],
  react: {
    useSuspense: false
  }
});

export default i18n;