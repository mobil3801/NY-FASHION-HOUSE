// Enhanced global error handlers with comprehensive reporting
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import { enhancedDevToolsErrorService } from '@/services/enhancedDevToolsErrorService';
import { ErrorContext } from '@/types/errorTypes';

export const setupEnhancedGlobalErrorHandlers = () => {
  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const context: ErrorContext = {
      title: 'Unhandled Promise Rejection',
      description: 'A promise was rejected but no handler was provided',
      action: 'Promise execution',
      operation: 'Async operation',
      severity: 'high',
      category: 'client',
      route: window.location.pathname,
      userAgent: navigator.userAgent,
      additionalData: {
        promiseRejection: true,
        reason: event.reason
      }
    };

    // Create error from rejection reason
    const error = event.reason instanceof Error ?
    event.reason :
    new Error(`Promise rejected: ${String(event.reason)}`);

    // Use DevTools enhanced error logging for promise rejections
    enhancedDevToolsErrorService.logEnhancedError(error, context).catch(() => {
      // Fallback to original error logging
      enhancedErrorLoggingService.logError(error, context);
    });

    // Prevent default browser error reporting
    event.preventDefault();
  });

  // Handle uncaught JavaScript errors
  window.addEventListener('error', (event) => {
    // Skip resource loading errors (handled separately)
    if (event.target !== window) {
      return;
    }

    const context: ErrorContext = {
      title: 'Uncaught JavaScript Error',
      description: 'An error occurred in the application code',
      action: 'Script execution',
      operation: 'JavaScript execution',
      severity: 'high',
      category: 'client',
      route: window.location.pathname,
      userAgent: navigator.userAgent,
      additionalData: {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        uncaughtError: true
      }
    };

    const error = event.error || new Error(event.message);
    enhancedDevToolsErrorService.logEnhancedError(error, context).catch(() => {
      // Fallback to original error logging
      enhancedErrorLoggingService.logError(error, context);
    });
  });

  // Handle resource loading errors
  window.addEventListener('error', (event) => {
    if (event.target !== window && event.target) {
      const target = event.target as HTMLElement;

      const context: ErrorContext = {
        title: 'Resource Loading Error',
        description: `Failed to load ${target.tagName.toLowerCase()} resource`,
        action: 'Resource loading',
        operation: 'Asset loading',
        severity: 'medium',
        category: 'network',
        route: window.location.pathname,
        userAgent: navigator.userAgent,
        additionalData: {
          tagName: target.tagName,
          src: (target as any).src || (target as any).href,
          resourceType: target.tagName.toLowerCase(),
          resourceLoadError: true
        }
      };

      const error = new Error(`Failed to load ${target.tagName}: ${(target as any).src || (target as any).href}`);
      enhancedDevToolsErrorService.logEnhancedError(error, context).catch(() => {
        // Fallback to original error logging
        enhancedErrorLoggingService.logError(error, context);
      });
    }
  }, true);

  // Handle beforeunload to capture any final errors
  window.addEventListener('beforeunload', () => {
    // Export error statistics for debugging
    const stats = enhancedErrorLoggingService.getErrorStatistics();
    if (stats.total > 0) {
      console.log('[ERROR STATISTICS]', stats);
    }
  });

  // Setup periodic health check
  setInterval(() => {
    const stats = enhancedErrorLoggingService.getErrorStatistics();

    // Alert if too many errors in recent period
    if (stats.recent > 10) {
      console.warn('[ERROR HEALTH CHECK] High error rate detected:', stats);
    }
  }, 60000); // Check every minute

  console.log('[ENHANCED GLOBAL ERROR HANDLERS] Initialized');
};

// Enhanced API error handler
export const handleApiError = (
error: any,
request: {
  url?: string;
  method?: string;
  params?: any;
  headers?: any;
  body?: any;
} = {},
additionalContext: Partial<ErrorContext> = {})
: string => {
  const context: ErrorContext = {
    title: 'API Error',
    description: 'An error occurred while communicating with the server',
    action: `${request.method || 'GET'} ${request.url || 'Unknown endpoint'}`,
    operation: 'API call',
    severity: error.status >= 500 ? 'high' : 'medium',
    category: 'network',
    requestDetails: request,
    additionalData: {
      statusCode: error.status,
      statusText: error.statusText,
      responseData: error.data
    },
    ...additionalContext
  };

  const errorObject = error instanceof Error ? error : new Error(error.message || 'API request failed');

  // Use DevTools enhanced error logging for API errors
  enhancedDevToolsErrorService.logEnhancedError(errorObject, context).
  then((report) => report.id).
  catch(() => {
    // Fallback to original error logging
    return enhancedErrorLoggingService.logError(errorObject, context);
  });

  return enhancedErrorLoggingService.logError(errorObject, context);
};

// Enhanced form error handler
export const handleFormError = (
error: Error,
formData: any,
formAction: string,
additionalContext: Partial<ErrorContext> = {})
: string => {
  const context: ErrorContext = {
    title: 'Form Submission Error',
    description: 'An error occurred while processing the form',
    action: formAction,
    operation: 'Form submission',
    severity: 'medium',
    category: 'validation',
    userInputs: formData,
    formData,
    ...additionalContext
  };

  // Use DevTools enhanced error logging for form errors
  enhancedDevToolsErrorService.logEnhancedError(error, context).
  then((report) => report.id).
  catch(() => {
    // Fallback to original error logging
    return enhancedErrorLoggingService.logError(error, context);
  });

  return enhancedErrorLoggingService.logError(error, context);
};