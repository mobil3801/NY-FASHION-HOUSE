/**
 * Request Body Size Management Utility
 * Handles large requests, chunking, and size validation
 */

interface RequestSizeConfig {
  maxSize: number; // Maximum request size in bytes
  chunkSize: number; // Chunk size for large operations
  timeout: number; // Request timeout in ms
}

interface ChunkedRequestOptions {
  url: string;
  method: 'POST' | 'PUT';
  data: any[];
  headers?: Record<string, string>;
  onProgress?: (progress: number, chunk: number, total: number) => void;
}

interface UploadOptions {
  maxFileSize: number; // in MB
  allowedTypes: string[];
  compressionQuality?: number;
}

class RequestSizeManager {
  private static instance: RequestSizeManager;
  private config: RequestSizeConfig = {
    maxSize: 50 * 1024 * 1024, // 50MB default
    chunkSize: 5 * 1024 * 1024, // 5MB chunks
    timeout: 300000 // 5 minutes
  };

  private constructor() {}

  public static getInstance(): RequestSizeManager {
    if (!RequestSizeManager.instance) {
      RequestSizeManager.instance = new RequestSizeManager();
    }
    return RequestSizeManager.instance;
  }

  /**
   * Configure size limits
   */
  public configure(config: Partial<RequestSizeConfig>): void {
    this.config = { ...this.config, ...config };
  }

  /**
   * Calculate request body size in bytes
   */
  public calculateSize(data: any): number {
    if (typeof data === 'string') {
      return new Blob([data]).size;
    }
    
    if (data instanceof FormData) {
      // Estimate FormData size (rough calculation)
      let size = 0;
      for (const [key, value] of data.entries()) {
        if (value instanceof File) {
          size += value.size;
        } else {
          size += new Blob([String(value)]).size;
        }
      }
      return size;
    }

    // For JSON objects
    return new Blob([JSON.stringify(data)]).size;
  }

  /**
   * Validate if request size is within limits
   */
  public validateSize(data: any): { isValid: boolean; size: number; maxSize: number } {
    const size = this.calculateSize(data);
    return {
      isValid: size <= this.config.maxSize,
      size,
      maxSize: this.config.maxSize
    };
  }

  /**
   * Split large arrays into chunks for processing
   */
  public chunkArray<T>(array: T[], chunkSize: number = 50): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  }

  /**
   * Process large bulk operations in chunks
   */
  public async processBulkOperation<T, R>(
    data: T[],
    processorFn: (chunk: T[]) => Promise<R>,
    options: {
      chunkSize?: number;
      onProgress?: (progress: number, current: number, total: number) => void;
      delay?: number;
    } = {}
  ): Promise<R[]> {
    const { chunkSize = 50, onProgress, delay = 100 } = options;
    const chunks = this.chunkArray(data, chunkSize);
    const results: R[] = [];

    for (let i = 0; i < chunks.length; i++) {
      try {
        const result = await processorFn(chunks[i]);
        results.push(result);

        // Report progress
        if (onProgress) {
          const progress = ((i + 1) / chunks.length) * 100;
          onProgress(progress, i + 1, chunks.length);
        }

        // Small delay to prevent overwhelming the server
        if (delay > 0 && i < chunks.length - 1) {
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      } catch (error) {
        console.error(`Chunk ${i + 1} processing failed:`, error);
        throw new Error(`Bulk operation failed at chunk ${i + 1}: ${error}`);
      }
    }

    return results;
  }

  /**
   * Compress large JSON payloads before sending
   */
  public compressData(data: any): string {
    const jsonString = JSON.stringify(data);
    
    // Simple compression by removing unnecessary whitespace
    // In production, you might want to use actual compression libraries
    return jsonString.replace(/\s+/g, ' ').trim();
  }

  /**
   * Validate and resize images before upload
   */
  public async validateAndResizeImage(
    file: File,
    options: UploadOptions
  ): Promise<{ isValid: boolean; file?: File; error?: string }> {
    const { maxFileSize, allowedTypes, compressionQuality = 0.8 } = options;

    // Validate file type
    if (!allowedTypes.includes(file.type)) {
      return {
        isValid: false,
        error: `Invalid file type. Allowed types: ${allowedTypes.join(', ')}`
      };
    }

    // Check file size
    const fileSizeInMB = file.size / (1024 * 1024);
    if (fileSizeInMB > maxFileSize) {
      // Try to compress the image
      try {
        const compressedFile = await this.compressImage(file, compressionQuality);
        const compressedSizeInMB = compressedFile.size / (1024 * 1024);

        if (compressedSizeInMB > maxFileSize) {
          return {
            isValid: false,
            error: `File too large even after compression. Max: ${maxFileSize}MB, Current: ${compressedSizeInMB.toFixed(2)}MB`
          };
        }

        return { isValid: true, file: compressedFile };
      } catch (compressionError) {
        return {
          isValid: false,
          error: `File too large and compression failed. Max: ${maxFileSize}MB, Current: ${fileSizeInMB.toFixed(2)}MB`
        };
      }
    }

    return { isValid: true, file };
  }

  /**
   * Compress image file
   */
  private compressImage(file: File, quality: number): Promise<File> {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      img.onload = () => {
        // Calculate new dimensions (reduce by 20% if needed)
        const maxWidth = 1920;
        const maxHeight = 1080;
        let { width, height } = img;

        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width *= ratio;
          height *= ratio;
        }

        canvas.width = width;
        canvas.height = height;

        // Draw and compress
        ctx?.drawImage(img, 0, 0, width, height);
        
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to compress image'));
              return;
            }

            const compressedFile = new File([blob], file.name, {
              type: file.type,
              lastModified: Date.now()
            });
            resolve(compressedFile);
          },
          file.type,
          quality
        );
      };

      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = URL.createObjectURL(file);
    });
  }

  /**
   * Split large file uploads into chunks
   */
  public async uploadFileInChunks(
    file: File,
    uploadEndpoint: string,
    options: {
      chunkSize?: number;
      onProgress?: (progress: number) => void;
      headers?: Record<string, string>;
    } = {}
  ): Promise<{ success: boolean; fileId?: number; error?: string }> {
    const { chunkSize = 5 * 1024 * 1024, onProgress, headers = {} } = options; // 5MB chunks
    
    // If file is small enough, upload normally
    if (file.size <= chunkSize) {
      try {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('filename', file.name);

        const response = await fetch(uploadEndpoint, {
          method: 'POST',
          headers,
          body: formData
        });

        if (!response.ok) {
          throw new Error(`Upload failed: ${response.statusText}`);
        }

        const result = await response.json();
        return { success: true, fileId: result.data };
      } catch (error) {
        return { success: false, error: (error as Error).message };
      }
    }

    // For large files, implement chunked upload
    const totalChunks = Math.ceil(file.size / chunkSize);
    let uploadedBytes = 0;

    try {
      // Initialize chunked upload session
      const initResponse = await fetch(`${uploadEndpoint}/init`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...headers
        },
        body: JSON.stringify({
          filename: file.name,
          fileSize: file.size,
          totalChunks
        })
      });

      if (!initResponse.ok) {
        throw new Error('Failed to initialize chunked upload');
      }

      const { uploadId } = await initResponse.json();

      // Upload chunks
      for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
        const start = chunkIndex * chunkSize;
        const end = Math.min(start + chunkSize, file.size);
        const chunk = file.slice(start, end);

        const chunkFormData = new FormData();
        chunkFormData.append('chunk', chunk);
        chunkFormData.append('chunkIndex', chunkIndex.toString());
        chunkFormData.append('uploadId', uploadId);

        const chunkResponse = await fetch(`${uploadEndpoint}/chunk`, {
          method: 'POST',
          headers,
          body: chunkFormData
        });

        if (!chunkResponse.ok) {
          throw new Error(`Failed to upload chunk ${chunkIndex + 1}`);
        }

        uploadedBytes += chunk.size;
        if (onProgress) {
          onProgress((uploadedBytes / file.size) * 100);
        }
      }

      // Finalize upload
      const finalizeResponse = await fetch(`${uploadEndpoint}/finalize`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...headers
        },
        body: JSON.stringify({ uploadId })
      });

      if (!finalizeResponse.ok) {
        throw new Error('Failed to finalize chunked upload');
      }

      const result = await finalizeResponse.json();
      return { success: true, fileId: result.data };

    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  /**
   * Create a size-optimized request configuration
   */
  public createSafeRequestConfig(data: any): {
    isValid: boolean;
    config: RequestInit;
    error?: string;
  } {
    const validation = this.validateSize(data);
    
    if (!validation.isValid) {
      return {
        isValid: false,
        config: {},
        error: `Request too large: ${(validation.size / (1024 * 1024)).toFixed(2)}MB exceeds limit of ${(validation.maxSize / (1024 * 1024)).toFixed(2)}MB`
      };
    }

    const body = typeof data === 'string' ? data : this.compressData(data);

    return {
      isValid: true,
      config: {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': this.calculateSize(body).toString()
        },
        body,
        signal: AbortSignal.timeout(this.config.timeout)
      }
    };
  }
}

// Export singleton instance
export const requestSizeManager = RequestSizeManager.getInstance();
export default requestSizeManager;

// Helper functions
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const isFileSizeValid = (file: File, maxSizeInMB: number): boolean => {
  return (file.size / (1024 * 1024)) <= maxSizeInMB;
};