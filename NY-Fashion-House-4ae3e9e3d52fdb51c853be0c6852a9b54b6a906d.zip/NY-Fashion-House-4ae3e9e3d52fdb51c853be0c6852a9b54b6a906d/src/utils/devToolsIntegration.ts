interface DevToolsErrorData {
  error: Error;
  metadata: any;
  timestamp: string;
  stackTrace?: string;
  componentStack?: string;
  browserInfo: {
    userAgent: string;
    viewport: {width: number;height: number;};
    url: string;
  };
}

export class DevToolsIntegration {
  private isDevMode: boolean;
  private errorQueue: DevToolsErrorData[] = [];
  private maxQueueSize = 100;

  constructor() {
    this.isDevMode = process.env.NODE_ENV === 'development';
  }

  async initialize() {
    if (!this.isDevMode) return;

    // Enhance console output for development
    this.enhanceConsoleOutput();

    // Add DevTools panel styling
    this.addDevToolsStyles();

    console.log('%c[Error System] DevTools Integration Active',
    'color: #00ff00; font-weight: bold; font-size: 12px;');
  }

  captureError(error: Error, metadata: any = {}) {
    if (!this.isDevMode) return;

    const errorData: DevToolsErrorData = {
      error,
      metadata,
      timestamp: new Date().toISOString(),
      stackTrace: error.stack,
      componentStack: metadata.errorInfo?.componentStack,
      browserInfo: {
        userAgent: navigator.userAgent,
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight
        },
        url: window.location.href
      }
    };

    this.errorQueue.push(errorData);

    // Keep queue size manageable
    if (this.errorQueue.length > this.maxQueueSize) {
      this.errorQueue = this.errorQueue.slice(-this.maxQueueSize);
    }

    this.logToDevTools(errorData);
  }

  private logToDevTools(errorData: DevToolsErrorData) {
    const { error, metadata, timestamp, browserInfo } = errorData;

    console.group(`%c🚨 Error Captured: ${error.name}`,
    'color: #ff6b6b; font-weight: bold; font-size: 14px;');

    console.error(`%cMessage: ${error.message}`, 'color: #ff6b6b; font-weight: bold;');

    if (metadata.level) {
      console.info(`%cLevel: ${metadata.level}`, 'color: #74c0fc; font-weight: bold;');
    }

    if (metadata.identifier) {
      console.info(`%cComponent: ${metadata.identifier}`, 'color: #74c0fc; font-weight: bold;');
    }

    console.info(`%cTimestamp: ${timestamp}`, 'color: #868e96;');

    if (error.stack) {
      console.group('Stack Trace');
      console.error(error.stack);
      console.groupEnd();
    }

    if (metadata.errorInfo?.componentStack) {
      console.group('Component Stack');
      console.log(metadata.errorInfo.componentStack);
      console.groupEnd();
    }

    console.group('Browser Context');
    console.table({
      'User Agent': browserInfo.userAgent,
      'Viewport': `${browserInfo.viewport.width}x${browserInfo.viewport.height}`,
      'URL': browserInfo.url
    });
    console.groupEnd();

    if (metadata.context) {
      console.group('Additional Context');
      console.table(metadata.context);
      console.groupEnd();
    }

    console.groupEnd();
  }

  private enhanceConsoleOutput() {
    // Add timestamp to all console messages
    const originalLog = console.log;
    const originalError = console.error;
    const originalWarn = console.warn;

    const addTimestamp = (originalFn: typeof console.log) => {
      return function (...args: any[]) {
        const timestamp = new Date().toLocaleTimeString();
        originalFn(`[${timestamp}]`, ...args);
      };
    };

    // Don't override in production to avoid conflicts
    if (this.isDevMode) {
      console.log = addTimestamp(originalLog);
      console.error = addTimestamp(originalError);
      console.warn = addTimestamp(originalWarn);
    }
  }

  private addDevToolsStyles() {
    if (typeof document === 'undefined') return;

    const style = document.createElement('style');
    style.textContent = `
      /* DevTools Error Highlight Styles */
      .error-highlight {
        border: 2px solid #ff6b6b !important;
        background-color: rgba(255, 107, 107, 0.1) !important;
        box-shadow: 0 0 0 2px rgba(255, 107, 107, 0.3) !important;
      }
      
      .error-overlay {
        position: fixed;
        top: 0;
        right: 0;
        z-index: 9999;
        background: rgba(255, 107, 107, 0.95);
        color: white;
        padding: 10px;
        border-radius: 0 0 0 5px;
        font-family: monospace;
        font-size: 12px;
        max-width: 400px;
        word-wrap: break-word;
      }
    `;
    document.head.appendChild(style);
  }

  getErrorQueue(): DevToolsErrorData[] {
    return [...this.errorQueue];
  }

  clearErrorQueue() {
    this.errorQueue = [];
    console.log('%c[Error System] Error queue cleared',
    'color: #51cf66; font-weight: bold;');
  }

  exportErrorData(): string {
    const exportData = {
      timestamp: new Date().toISOString(),
      errors: this.errorQueue.map((errorData) => ({
        ...errorData,
        error: {
          name: errorData.error.name,
          message: errorData.error.message,
          stack: errorData.error.stack
        }
      }))
    };

    return JSON.stringify(exportData, null, 2);
  }

  // Highlight error-prone elements in the DOM
  highlightErrorElement(selector: string) {
    if (!this.isDevMode || typeof document === 'undefined') return;

    const elements = document.querySelectorAll(selector);
    elements.forEach((element) => {
      element.classList.add('error-highlight');

      setTimeout(() => {
        element.classList.remove('error-highlight');
      }, 5000);
    });
  }

  // Show error overlay in development
  showErrorOverlay(message: string, duration = 10000) {
    if (!this.isDevMode || typeof document === 'undefined') return;

    const overlay = document.createElement('div');
    overlay.className = 'error-overlay';
    overlay.textContent = message;

    document.body.appendChild(overlay);

    setTimeout(() => {
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    }, duration);
  }
}