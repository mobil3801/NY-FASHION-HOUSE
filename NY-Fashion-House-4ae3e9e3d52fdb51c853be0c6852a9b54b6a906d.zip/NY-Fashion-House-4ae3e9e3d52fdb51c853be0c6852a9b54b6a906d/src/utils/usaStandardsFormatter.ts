import { formatUSD as formatCurrency } from './currencyUtils';
import { formatUSADate, formatUSATime, formatUSADateTime } from './dateUtils';

export interface USAStandardsFormatter {
  formatCurrency: (amount: number) => string;
  formatDate: (date: Date) => string;
  formatTime: (date: Date) => string;
  formatDateTime: (date: Date) => string;
  formatPhoneNumber: (phoneNumber: string) => string;
  formatAddress: (address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  }) => string;
  formatNumber: (num: number) => string;
  getTimezone: () => string;
}

export const usaStandardsFormatter: USAStandardsFormatter = {
  formatCurrency,
  formatDate: formatUSADate,
  formatTime: formatUSATime,
  formatDateTime: formatUSADateTime,

  formatPhoneNumber: (phoneNumber: string) => {
    // Remove all non-digit characters
    const cleaned = phoneNumber.replace(/\D/g, '');

    // Check if the number is valid
    if (cleaned.length !== 10) return phoneNumber;

    // Format as (XXX) XXX-XXXX
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  },

  formatAddress: (address) => {
    return `${address.street}, ${address.city}, ${address.state} ${address.zipCode}`;
  },

  formatNumber: (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  },

  getTimezone: () => {
    // Simplified timezone detection
    const isDST = (date: Date) => {
      const jan = new Date(date.getFullYear(), 0, 1);
      const jul = new Date(date.getFullYear(), 6, 1);
      return date.getTimezoneOffset() < Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset());
    };

    return isDST(new Date()) ? 'EDT' : 'EST';
  }
};

// Expose as default for easy importing
export default usaStandardsFormatter;