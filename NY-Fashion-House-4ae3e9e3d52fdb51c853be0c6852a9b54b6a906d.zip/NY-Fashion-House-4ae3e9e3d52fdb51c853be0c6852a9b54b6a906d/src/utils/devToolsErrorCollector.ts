// DevTools integration for enhanced error collection
import { ErrorContext } from '@/types/errorTypes';

export interface DevToolsStackFrame {
  fileName: string;
  lineNumber: number;
  columnNumber: number;
  functionName?: string;
  source?: string;
  scriptId?: string;
}

export interface DevToolsErrorDetails {
  message: string;
  stack: string;
  parsedStack: DevToolsStackFrame[];
  componentStack?: string;
  sourceContext?: SourceContext[];
  devToolsInfo?: {
    consoleTimestamp: number;
    scriptId?: string;
    executionContextId?: number;
  };
}

export interface SourceContext {
  fileName: string;
  lineNumber: number;
  contextLines: string[];
  errorLine: string;
  errorColumn: number;
}

class DevToolsErrorCollector {
  private isDevToolsAvailable: boolean = false;
  private sourceMapCache: Map<string, any> = new Map();

  constructor() {
    this.initializeDevToolsIntegration();
  }

  private initializeDevToolsIntegration(): void {
    // Check if Chrome DevTools is available
    this.isDevToolsAvailable = this.checkDevToolsAvailability();

    if (this.isDevToolsAvailable) {
      this.setupConsoleInterception();
      this.setupSourceMapSupport();
    }

    console.log(`[DevTools Error Collector] ${this.isDevToolsAvailable ? 'Enabled' : 'Fallback mode'}`);
  }

  private checkDevToolsAvailability(): boolean {
    // Check for Chrome DevTools Console API
    return (
      typeof window !== 'undefined' &&
      'console' in window &&
      typeof (window as any).chrome === 'object' &&
      typeof console.trace === 'function');

  }

  private setupConsoleInterception(): void {
    // Enhance console.error to capture detailed information
    const originalError = console.error;
    const originalWarn = console.warn;

    console.error = (...args: any[]) => {
      try {
        this.captureConsoleError('error', args);
      } catch (e) {










        // Fallback to original behavior
      }originalError.apply(console, args);};console.warn = (...args: any[]) => {try {this.captureConsoleError('warn', args);} catch (e) {







        // Fallback to original behavior
      }originalWarn.apply(console, args);};}private setupSourceMapSupport(): void {// Setup source map parsing for better error locations
    if (typeof window !== 'undefined' && 'fetch' in window) {this.preloadSourceMaps();}}
  private async preloadSourceMaps(): Promise<void> {
    try {
      // Get all script elements and try to find source maps
      const scripts = Array.from(document.scripts);

      for (const script of scripts) {
        if (script.src && script.src.includes('.js')) {
          try {
            const response = await fetch(script.src);
            const content = await response.text();

            // Look for source map comment
            const sourceMapMatch = content.match(/\/\/# sourceMappingURL=(.+)/);
            if (sourceMapMatch) {
              const sourceMapUrl = new URL(sourceMapMatch[1], script.src);
              this.sourceMapCache.set(script.src, sourceMapUrl.href);
            }
          } catch (e) {










            // Ignore source map loading errors
          }}}} catch (e) {



      // Ignore preloading errors
    }}private captureConsoleError(level: string, args: any[]): void {// Extract error objects from console arguments
    const errors = args.filter((arg) => arg instanceof Error);if (errors.length > 0) {errors.forEach((error) => {this.enhanceErrorWithDevToolsInfo(error);});}
  }

  public parseStackTrace(stack: string): DevToolsStackFrame[] {
    if (!stack) return [];

    const stackLines = stack.split('\n').slice(1); // Remove the error message line
    const frames: DevToolsStackFrame[] = [];

    for (const line of stackLines) {
      const frame = this.parseStackLine(line);
      if (frame) {
        frames.push(frame);
      }
    }

    return frames;
  }

  private parseStackLine(line: string): DevToolsStackFrame | null {
    // Handle different browser stack trace formats

    // Chrome/Edge format: "at functionName (file:line:column)"
    const chromeMatch = line.match(/^\s*at\s+(.+?)\s+\((.+):(\d+):(\d+)\)$/);
    if (chromeMatch) {
      return {
        functionName: chromeMatch[1] === '<anonymous>' ? undefined : chromeMatch[1],
        fileName: chromeMatch[2],
        lineNumber: parseInt(chromeMatch[3], 10),
        columnNumber: parseInt(chromeMatch[4], 10)
      };
    }

    // Chrome/Edge format without function: "at file:line:column"
    const chromeSimpleMatch = line.match(/^\s*at\s+(.+):(\d+):(\d+)$/);
    if (chromeSimpleMatch) {
      return {
        fileName: chromeSimpleMatch[1],
        lineNumber: parseInt(chromeSimpleMatch[2], 10),
        columnNumber: parseInt(chromeSimpleMatch[3], 10)
      };
    }

    // Firefox format: "functionName@file:line:column"
    const firefoxMatch = line.match(/^(.*)@(.+):(\d+):(\d+)$/);
    if (firefoxMatch) {
      return {
        functionName: firefoxMatch[1] || undefined,
        fileName: firefoxMatch[2],
        lineNumber: parseInt(firefoxMatch[3], 10),
        columnNumber: parseInt(firefoxMatch[4], 10)
      };
    }

    // Safari format: "functionName@file:line:column"
    const safariMatch = line.match(/^(.+?)@(.+?):(\d+):(\d+)$/);
    if (safariMatch) {
      return {
        functionName: safariMatch[1],
        fileName: safariMatch[2],
        lineNumber: parseInt(safariMatch[3], 10),
        columnNumber: parseInt(safariMatch[4], 10)
      };
    }

    return null;
  }

  public async extractSourceContext(frame: DevToolsStackFrame): Promise<SourceContext | null> {
    if (!frame.fileName || frame.fileName.startsWith('chrome-extension://')) {
      return null;
    }

    try {
      // Try to fetch the source file
      let sourceUrl = frame.fileName;

      // Handle relative URLs
      if (!sourceUrl.startsWith('http') && !sourceUrl.startsWith('/')) {
        sourceUrl = new URL(sourceUrl, window.location.origin).href;
      }

      const response = await fetch(sourceUrl);
      if (!response.ok) return null;

      const sourceText = await response.text();
      const lines = sourceText.split('\n');

      const contextStart = Math.max(0, frame.lineNumber - 4);
      const contextEnd = Math.min(lines.length, frame.lineNumber + 3);

      const contextLines: string[] = [];
      for (let i = contextStart; i < contextEnd; i++) {
        contextLines.push(`${i + 1}: ${lines[i] || ''}`);
      }

      return {
        fileName: frame.fileName,
        lineNumber: frame.lineNumber,
        contextLines,
        errorLine: lines[frame.lineNumber - 1] || '',
        errorColumn: frame.columnNumber
      };
    } catch (e) {
      return null;
    }
  }

  public extractReactComponentStack(error: Error): string | undefined {
    // Try to extract React component stack from error
    const reactError = error as any;

    if (reactError.componentStack) {
      return reactError.componentStack;
    }

    // Look for React stack in the stack trace
    if (error.stack) {
      const reactFrames = error.stack.
      split('\n').
      filter((line) =>
      line.includes('react') ||
      line.includes('Component') ||
      line.includes('createElement') ||
      line.includes('render')
      );

      if (reactFrames.length > 0) {
        return reactFrames.join('\n');
      }
    }

    return undefined;
  }

  public async collectEnhancedErrorDetails(error: Error): Promise<DevToolsErrorDetails> {
    const parsedStack = this.parseStackTrace(error.stack || '');
    const componentStack = this.extractReactComponentStack(error);

    // Try to get source context for the first few frames
    const sourceContextPromises = parsedStack.
    slice(0, 3) // Only get context for first 3 frames to avoid performance issues
    .map((frame) => this.extractSourceContext(frame));

    const sourceContext = (await Promise.all(sourceContextPromises)).
    filter((context): context is SourceContext => context !== null);

    return {
      message: error.message,
      stack: error.stack || '',
      parsedStack,
      componentStack,
      sourceContext,
      devToolsInfo: {
        consoleTimestamp: Date.now(),
        ...(this.isDevToolsAvailable && {
          scriptId: this.getScriptIdFromError(error),
          executionContextId: this.getExecutionContextId()
        })
      }
    };
  }

  private enhanceErrorWithDevToolsInfo(error: Error): void {
    // Add DevTools-specific information to error
    if (this.isDevToolsAvailable) {
      const enhancedError = error as any;
      enhancedError.devToolsTimestamp = Date.now();
      enhancedError.userAgent = navigator.userAgent;
      enhancedError.url = window.location.href;
    }
  }

  private getScriptIdFromError(error: Error): string | undefined {
    // Try to extract script ID from DevTools if available
    if (this.isDevToolsAvailable && error.stack) {
      const stackMatch = error.stack.match(/chrome-devtools:\/\/devtools\/bundled\/(.+?)\//);
      return stackMatch ? stackMatch[1] : undefined;
    }
    return undefined;
  }

  private getExecutionContextId(): number | undefined {
    // Get execution context ID from DevTools if available
    if (this.isDevToolsAvailable) {
      try {
        // This is a simplified approach - real implementation would use DevTools Protocol
        return window.chrome?.runtime?.id ? 1 : undefined;
      } catch (e) {
        return undefined;
      }
    }
    return undefined;
  }

  public generateErrorSummary(devToolsDetails: DevToolsErrorDetails): string {
    const topFrame = devToolsDetails.parsedStack[0];
    if (!topFrame) {
      return `Error: ${devToolsDetails.message}`;
    }

    const fileName = topFrame.fileName.split('/').pop() || topFrame.fileName;
    return `${devToolsDetails.message} at ${fileName}:${topFrame.lineNumber}:${topFrame.columnNumber}`;
  }

  public formatErrorForDisplay(devToolsDetails: DevToolsErrorDetails): string {
    let formatted = `Error: ${devToolsDetails.message}\n\n`;

    if (devToolsDetails.parsedStack.length > 0) {
      formatted += 'Stack Trace:\n';
      devToolsDetails.parsedStack.forEach((frame, index) => {
        const fileName = frame.fileName.split('/').pop() || frame.fileName;
        const func = frame.functionName ? `${frame.functionName} ` : '';
        formatted += `  ${index + 1}. ${func}at ${fileName}:${frame.lineNumber}:${frame.columnNumber}\n`;
      });
      formatted += '\n';
    }

    if (devToolsDetails.componentStack) {
      formatted += 'React Component Stack:\n';
      formatted += devToolsDetails.componentStack;
      formatted += '\n\n';
    }

    if (devToolsDetails.sourceContext && devToolsDetails.sourceContext.length > 0) {
      formatted += 'Source Context:\n';
      devToolsDetails.sourceContext.forEach((context) => {
        formatted += `\nFile: ${context.fileName.split('/').pop()}\n`;
        formatted += `Error at line ${context.lineNumber}, column ${context.errorColumn}:\n`;
        context.contextLines.forEach((line) => {
          const isErrorLine = line.startsWith(`${context.lineNumber}:`);
          formatted += `${isErrorLine ? '>>> ' : '    '}${line}\n`;
        });
      });
    }

    return formatted;
  }

  public isEnhancedModeAvailable(): boolean {
    return this.isDevToolsAvailable;
  }
}

export const devToolsErrorCollector = new DevToolsErrorCollector();