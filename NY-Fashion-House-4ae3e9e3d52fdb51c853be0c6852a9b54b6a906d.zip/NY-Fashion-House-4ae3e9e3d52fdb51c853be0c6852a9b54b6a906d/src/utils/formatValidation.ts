// Enhanced validation utilities for USA standards and general form validation

export interface ValidationResult {
  isValid: boolean;
  message?: string;
}

export interface FieldValidation {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  custom?: (value: any) => ValidationResult;
}

// USA Standards Validators
export const validateUSAStandards = {
  currency: (amount: number | string): ValidationResult => {
    if (typeof amount === 'string') {
      amount = parseFloat(amount.replace(/[^0-9.-]/g, '')) || 0;
    }

    if (isNaN(amount)) {
      return { isValid: false, message: 'Invalid currency amount' };
    }

    if (amount < 0) {
      return { isValid: false, message: 'Amount cannot be negative' };
    }

    // Check for reasonable currency precision (2 decimal places)
    const decimalPlaces = amount.toString().split('.')[1]?.length || 0;
    if (decimalPlaces > 2) {
      return { isValid: false, message: 'Currency cannot have more than 2 decimal places' };
    }

    return { isValid: true };
  },

  date: (dateString: string): ValidationResult => {
    // Validate MM/DD/YYYY format
    const regex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/\d{4}$/;

    if (!regex.test(dateString)) {
      return { isValid: false, message: 'Date must be in MM/DD/YYYY format' };
    }

    // Parse and validate actual date
    const parts = dateString.split('/');
    const month = parseInt(parts[0], 10) - 1; // Month is 0-indexed
    const day = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);

    const date = new Date(year, month, day);

    if (date.getMonth() !== month || date.getDate() !== day || date.getFullYear() !== year) {
      return { isValid: false, message: 'Invalid date' };
    }

    return { isValid: true };
  },

  phoneNumber: (phoneNumber: string): ValidationResult => {
    // Remove all non-digit characters for validation
    const cleaned = phoneNumber.replace(/\D/g, '');

    if (cleaned.length === 0) {
      return { isValid: false, message: 'Phone number is required' };
    }

    if (cleaned.length !== 10) {
      return { isValid: false, message: 'Phone number must be 10 digits' };
    }

    // Check for valid area code (not starting with 0 or 1)
    if (cleaned[0] === '0' || cleaned[0] === '1') {
      return { isValid: false, message: 'Invalid area code' };
    }

    return { isValid: true };
  },

  zipCode: (zipCode: string): ValidationResult => {
    // Validate 5-digit or 5+4 digit ZIP code
    const regex = /^\d{5}(-\d{4})?$/;

    if (!regex.test(zipCode)) {
      return { isValid: false, message: 'ZIP code must be in 12345 or 12345-6789 format' };
    }

    return { isValid: true };
  },

  ssn: (ssn: string): ValidationResult => {
    // Validate Social Security Number format
    const regex = /^\d{3}-\d{2}-\d{4}$/;

    if (!regex.test(ssn)) {
      return { isValid: false, message: 'SSN must be in 123-45-6789 format' };
    }

    // Check for invalid SSN patterns
    const cleaned = ssn.replace(/\D/g, '');
    if (cleaned === '000000000' || cleaned === '123456789') {
      return { isValid: false, message: 'Invalid SSN' };
    }

    return { isValid: true };
  }
};

// General Validators
export const validators = {
  required: (value: any): ValidationResult => {
    if (value === null || value === undefined) {
      return { isValid: false, message: 'This field is required' };
    }

    if (typeof value === 'string' && value.trim().length === 0) {
      return { isValid: false, message: 'This field is required' };
    }

    return { isValid: true };
  },

  email: (email: string): ValidationResult => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!regex.test(email)) {
      return { isValid: false, message: 'Invalid email format' };
    }

    return { isValid: true };
  },

  minLength: (value: string, minLength: number): ValidationResult => {
    if (value.length < minLength) {
      return { isValid: false, message: `Must be at least ${minLength} characters long` };
    }

    return { isValid: true };
  },

  maxLength: (value: string, maxLength: number): ValidationResult => {
    if (value.length > maxLength) {
      return { isValid: false, message: `Must be no more than ${maxLength} characters long` };
    }

    return { isValid: true };
  },

  minValue: (value: number, minValue: number): ValidationResult => {
    if (value < minValue) {
      return { isValid: false, message: `Must be at least ${minValue}` };
    }

    return { isValid: true };
  },

  maxValue: (value: number, maxValue: number): ValidationResult => {
    if (value > maxValue) {
      return { isValid: false, message: `Must be no more than ${maxValue}` };
    }

    return { isValid: true };
  },

  password: (password: string): ValidationResult => {
    if (password.length < 8) {
      return { isValid: false, message: 'Password must be at least 8 characters long' };
    }

    if (!/(?=.*[a-z])/.test(password)) {
      return { isValid: false, message: 'Password must contain at least one lowercase letter' };
    }

    if (!/(?=.*[A-Z])/.test(password)) {
      return { isValid: false, message: 'Password must contain at least one uppercase letter' };
    }

    if (!/(?=.*\d)/.test(password)) {
      return { isValid: false, message: 'Password must contain at least one number' };
    }

    return { isValid: true };
  },

  url: (url: string): ValidationResult => {
    try {
      new URL(url);
      return { isValid: true };
    } catch {
      return { isValid: false, message: 'Invalid URL format' };
    }
  }
};

// Validation helper functions
export const validateField = (value: any, validation: FieldValidation): ValidationResult => {
  // Required validation
  if (validation.required) {
    const requiredResult = validators.required(value);
    if (!requiredResult.isValid) {
      return requiredResult;
    }
  }

  // Skip other validations if value is empty and not required
  if (!validation.required && (!value || value.toString().trim().length === 0)) {
    return { isValid: true };
  }

  const stringValue = value?.toString() || '';

  // Min length validation
  if (validation.minLength !== undefined) {
    const minLengthResult = validators.minLength(stringValue, validation.minLength);
    if (!minLengthResult.isValid) {
      return minLengthResult;
    }
  }

  // Max length validation
  if (validation.maxLength !== undefined) {
    const maxLengthResult = validators.maxLength(stringValue, validation.maxLength);
    if (!maxLengthResult.isValid) {
      return maxLengthResult;
    }
  }

  // Pattern validation
  if (validation.pattern) {
    if (!validation.pattern.test(stringValue)) {
      return { isValid: false, message: 'Invalid format' };
    }
  }

  // Custom validation
  if (validation.custom) {
    return validation.custom(value);
  }

  return { isValid: true };
};

export const validateForm = (formData: Record<string, any>, validationRules: Record<string, FieldValidation>): Record<string, string> => {
  const errors: Record<string, string> = {};

  for (const [fieldName, rules] of Object.entries(validationRules)) {
    const result = validateField(formData[fieldName], rules);
    if (!result.isValid && result.message) {
      errors[fieldName] = result.message;
    }
  }

  return errors;
};

// Format helpers for display
export const formatters = {
  currency: (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  },

  phoneNumber: (phoneNumber: string): string => {
    const cleaned = phoneNumber.replace(/\D/g, '');
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phoneNumber;
  },

  date: (date: Date): string => {
    return new Intl.DateTimeFormat('en-US').format(date);
  },

  ssn: (ssn: string): string => {
    const cleaned = ssn.replace(/\D/g, '');
    if (cleaned.length === 9) {
      return `${cleaned.slice(0, 3)}-${cleaned.slice(3, 5)}-${cleaned.slice(5)}`;
    }
    return ssn;
  },

  zipCode: (zipCode: string): string => {
    const cleaned = zipCode.replace(/\D/g, '');
    if (cleaned.length === 9) {
      return `${cleaned.slice(0, 5)}-${cleaned.slice(5)}`;
    }
    return zipCode;
  }
};

// Export commonly used validation patterns
export const validationPatterns = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  phone: /^\(\d{3}\) \d{3}-\d{4}$/,
  zipCode: /^\d{5}(-\d{4})?$/,
  ssn: /^\d{3}-\d{2}-\d{4}$/,
  currency: /^\$?\d+(\.\d{2})?$/,
  date: /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/\d{4}$/
};

export default {
  validateUSAStandards,
  validators,
  validateField,
  validateForm,
  formatters,
  validationPatterns
};