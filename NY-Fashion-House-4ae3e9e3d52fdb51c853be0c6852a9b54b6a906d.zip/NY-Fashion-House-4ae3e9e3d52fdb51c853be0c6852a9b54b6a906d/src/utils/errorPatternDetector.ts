interface ErrorOccurrence {
  error: Error;
  metadata: any;
  timestamp: Date;
}

interface PatternAnalysis {
  commonComponents: string[];
  timePatterns: string[];
  frequentErrors: Array<{message: string;count: number;}>;
  anomalies: string[];
  trends: {
    increasing: boolean;
    rate: number;
  };
}

export class ErrorPatternDetector {
  private errors: ErrorOccurrence[] = [];
  private maxStoredErrors = 1000;

  addError(error: Error, metadata: any) {
    this.errors.push({
      error,
      metadata,
      timestamp: new Date()
    });

    // Keep only the most recent errors
    if (this.errors.length > this.maxStoredErrors) {
      this.errors = this.errors.slice(-this.maxStoredErrors);
    }
  }

  analyzePatterns(): PatternAnalysis {
    if (this.errors.length === 0) {
      return {
        commonComponents: [],
        timePatterns: [],
        frequentErrors: [],
        anomalies: [],
        trends: { increasing: false, rate: 0 }
      };
    }

    return {
      commonComponents: this.findCommonComponents(),
      timePatterns: this.analyzeTimePatterns(),
      frequentErrors: this.findFrequentErrors(),
      anomalies: this.detectAnomalies(),
      trends: this.analyzeTrends()
    };
  }

  private findCommonComponents(): string[] {
    const componentCounts = new Map<string, number>();

    this.errors.forEach(({ metadata }) => {
      const component = metadata?.identifier || metadata?.component || 'unknown';
      componentCounts.set(component, (componentCounts.get(component) || 0) + 1);
    });

    // Return components with more than 1 error, sorted by frequency
    return Array.from(componentCounts.entries()).
    filter(([_, count]) => count > 1).
    sort(([_, a], [__, b]) => b - a).
    slice(0, 10).
    map(([component, _]) => component);
  }

  private analyzeTimePatterns(): string[] {
    const patterns: string[] = [];
    const hourCounts = new Map<number, number>();

    this.errors.forEach(({ timestamp }) => {
      const hour = timestamp.getHours();
      hourCounts.set(hour, (hourCounts.get(hour) || 0) + 1);
    });

    const avgErrorsPerHour = this.errors.length / 24;
    const peakHours = Array.from(hourCounts.entries()).
    filter(([_, count]) => count > avgErrorsPerHour * 1.5).
    sort(([_, a], [__, b]) => b - a).
    slice(0, 3).
    map(([hour, _]) => `${hour}:00-${hour + 1}:00`);

    if (peakHours.length > 0) {
      patterns.push(`Peak error times: ${peakHours.join(', ')}`);
    }

    return patterns;
  }

  private findFrequentErrors(): Array<{message: string;count: number;}> {
    const messageCounts = new Map<string, number>();

    this.errors.forEach(({ error }) => {
      const message = error.message;
      messageCounts.set(message, (messageCounts.get(message) || 0) + 1);
    });

    return Array.from(messageCounts.entries()).
    filter(([_, count]) => count > 1).
    sort(([_, a], [__, b]) => b - a).
    slice(0, 10).
    map(([message, count]) => ({ message, count }));
  }

  private detectAnomalies(): string[] {
    const anomalies: string[] = [];

    // Check for sudden spikes
    const recentErrors = this.errors.filter(
      ({ timestamp }) => Date.now() - timestamp.getTime() < 60000 // Last minute
    );

    const recentRate = recentErrors.length;
    const overallRate = this.errors.length / Math.max(1, this.getTimeSpanMinutes());

    if (recentRate > overallRate * 3) {
      anomalies.push(`Error spike detected: ${recentRate} errors in last minute (normal: ${overallRate.toFixed(1)}/min)`);
    }

    // Check for new error types
    const recentErrorTypes = new Set(recentErrors.map(({ error }) => error.message));
    const historicalErrorTypes = new Set(
      this.errors.
      filter(({ timestamp }) => Date.now() - timestamp.getTime() >= 60000).
      map(({ error }) => error.message)
    );

    const newErrorTypes = Array.from(recentErrorTypes).filter(
      (type) => !historicalErrorTypes.has(type)
    );

    if (newErrorTypes.length > 0) {
      anomalies.push(`New error types detected: ${newErrorTypes.length} new error patterns`);
    }

    return anomalies;
  }

  private analyzeTrends(): {increasing: boolean;rate: number;} {
    if (this.errors.length < 10) {
      return { increasing: false, rate: 0 };
    }

    const now = Date.now();
    const recentErrors = this.errors.filter(
      ({ timestamp }) => now - timestamp.getTime() < 300000 // Last 5 minutes
    );
    const olderErrors = this.errors.filter(
      ({ timestamp }) => {
        const age = now - timestamp.getTime();
        return age >= 300000 && age < 600000; // 5-10 minutes ago
      }
    );

    const recentRate = recentErrors.length / 5; // Per minute
    const olderRate = olderErrors.length / 5; // Per minute

    const rate = recentRate - olderRate;
    const increasing = rate > 0;

    return { increasing, rate };
  }

  private getTimeSpanMinutes(): number {
    if (this.errors.length === 0) return 1;

    const oldest = Math.min(...this.errors.map(({ timestamp }) => timestamp.getTime()));
    const newest = Math.max(...this.errors.map(({ timestamp }) => timestamp.getTime()));

    return Math.max(1, (newest - oldest) / 60000); // Minutes
  }

  clearPatterns() {
    this.errors = [];
  }

  getErrorCount(): number {
    return this.errors.length;
  }
}