// Error analysis utilities for root cause detection and remediation
import { ErrorContext, ErrorAnalysis } from '@/types/errorTypes';

export class ErrorAnalyzer {
  static analyze(error: Error, context: ErrorContext = {}): ErrorAnalysis {
    const errorMessage = error.message.toLowerCase();
    const stack = error.stack?.toLowerCase() || '';

    // Analyze by error patterns
    if (this.isNetworkError(errorMessage, stack)) {
      return this.analyzeNetworkError(error, context);
    }

    if (this.isAuthenticationError(errorMessage, stack)) {
      return this.analyzeAuthenticationError(error, context);
    }

    if (this.isValidationError(errorMessage, stack)) {
      return this.analyzeValidationError(error, context);
    }

    if (this.isPermissionError(errorMessage, stack)) {
      return this.analyzePermissionError(error, context);
    }

    if (this.isServerError(errorMessage, stack)) {
      return this.analyzeServerError(error, context);
    }

    if (this.isResourceError(errorMessage, stack)) {
      return this.analyzeResourceError(error, context);
    }

    if (this.isRenderError(errorMessage, stack, context)) {
      return this.analyzeRenderError(error, context);
    }

    // Default analysis for unknown errors
    return this.analyzeUnknownError(error, context);
  }

  private static isNetworkError(message: string, stack: string): boolean {
    const networkIndicators = ['network', 'fetch', 'connection', 'timeout', 'cors', 'offline'];
    return networkIndicators.some((indicator) => message.includes(indicator) || stack.includes(indicator));
  }

  private static isAuthenticationError(message: string, stack: string): boolean {
    const authIndicators = ['unauthorized', '401', 'authentication', 'login', 'token', 'session expired'];
    return authIndicators.some((indicator) => message.includes(indicator));
  }

  private static isValidationError(message: string, stack: string): boolean {
    const validationIndicators = ['validation', 'invalid', '400', 'bad request', 'required field'];
    return validationIndicators.some((indicator) => message.includes(indicator));
  }

  private static isPermissionError(message: string, stack: string): boolean {
    const permissionIndicators = ['forbidden', '403', 'permission', 'access denied', 'unauthorized'];
    return permissionIndicators.some((indicator) => message.includes(indicator));
  }

  private static isServerError(message: string, stack: string): boolean {
    const serverIndicators = ['500', '502', '503', '504', 'internal server error', 'service unavailable'];
    return serverIndicators.some((indicator) => message.includes(indicator));
  }

  private static isResourceError(message: string, stack: string): boolean {
    const resourceIndicators = ['not found', '404', 'resource', 'missing'];
    return resourceIndicators.some((indicator) => message.includes(indicator));
  }

  private static isRenderError(message: string, stack: string, context: ErrorContext): boolean {
    const renderIndicators = ['render', 'component', 'jsx', 'react'];
    const hasComponentStack = !!context.componentStack;
    return hasComponentStack || renderIndicators.some((indicator) => message.includes(indicator) || stack.includes(indicator));
  }

  private static analyzeNetworkError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'Internet connection lost',
      'Server is temporarily unavailable',
      'Network firewall blocking request',
      'DNS resolution failure',
      'CORS policy restrictions'],

      rootCause: 'Network connectivity or server communication failure',
      category: 'network',
      remediation: [
      'Check your internet connection',
      'Try refreshing the page',
      'Wait a moment and try again',
      'Contact support if the problem persists'],

      isRecoverable: true
    };
  }

  private static analyzeAuthenticationError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'Session has expired',
      'Invalid authentication credentials',
      'Token has been revoked',
      'User account has been disabled'],

      rootCause: 'Authentication credentials are invalid or expired',
      category: 'authentication',
      remediation: [
      'Please log in again',
      'Check your username and password',
      'Clear browser cache and cookies',
      'Contact administrator if account is locked'],

      isRecoverable: true
    };
  }

  private static analyzeValidationError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'Required fields are missing',
      'Data format is incorrect',
      'Input values exceed allowed limits',
      'Invalid data types provided'],

      rootCause: 'Input data validation failed',
      category: 'validation',
      remediation: [
      'Check all required fields are filled',
      'Verify data format is correct',
      'Review input constraints and limits',
      'Try submitting again with valid data'],

      isRecoverable: true
    };
  }

  private static analyzePermissionError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'User role lacks required permissions',
      'Resource access is restricted',
      'Account permissions have changed',
      'Feature not available for current user type'],

      rootCause: 'Insufficient permissions to perform requested action',
      category: 'authorization',
      remediation: [
      'Contact administrator for access',
      'Check if you have the required role',
      'Try logging out and back in',
      'Request permission upgrade if needed'],

      isRecoverable: false
    };
  }

  private static analyzeServerError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'Server is experiencing high load',
      'Database connection issues',
      'Internal application error',
      'Service maintenance in progress'],

      rootCause: 'Server-side error occurred while processing request',
      category: 'server',
      remediation: [
      'Wait a few minutes and try again',
      'Refresh the page',
      'Try a different action first',
      'Contact support with error details'],

      isRecoverable: true
    };
  }

  private static analyzeResourceError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'Requested resource was deleted',
      'URL path is incorrect',
      'Resource has been moved',
      'Access permissions changed'],

      rootCause: 'Requested resource could not be found',
      category: 'client',
      remediation: [
      'Check the URL is correct',
      'Go back and try a different path',
      'Refresh the page',
      'Contact support if resource should exist'],

      isRecoverable: true
    };
  }

  private static analyzeRenderError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'Component received invalid props',
      'State update during unmounting',
      'Missing required dependencies',
      'Infinite rendering loop',
      'Memory leak in component'],

      rootCause: 'React component failed to render properly',
      category: 'client',
      remediation: [
      'Refresh the page to reset component state',
      'Try navigating to a different page',
      'Clear browser cache',
      'Report this issue to development team'],

      isRecoverable: true
    };
  }

  private static analyzeUnknownError(error: Error, context: ErrorContext): ErrorAnalysis {
    return {
      possibleCauses: [
      'Unexpected application state',
      'Browser compatibility issue',
      'Corrupted local storage',
      'Third-party service failure'],

      rootCause: 'An unexpected error occurred',
      category: 'unknown',
      remediation: [
      'Try refreshing the page',
      'Clear browser cache and cookies',
      'Try using a different browser',
      'Contact support with error details'],

      isRecoverable: true
    };
  }

  static generateCorrelationId(): string {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 8);
    return `err-${timestamp}-${random}`;
  }

  static createUserFriendlyMessage(error: Error, analysis: ErrorAnalysis): string {
    switch (analysis.category) {
      case 'network':
        return 'Connection problem. Please check your internet and try again.';
      case 'authentication':
        return 'Your session has expired. Please log in again.';
      case 'validation':
        return 'Please check your input and try again.';
      case 'authorization':
        return 'You don\'t have permission to perform this action.';
      case 'server':
        return 'Server is temporarily unavailable. Please try again in a moment.';
      case 'client':
        return 'Something went wrong with the page. Try refreshing.';
      default:
        return 'An unexpected error occurred. Please try again or contact support.';
    }
  }
}