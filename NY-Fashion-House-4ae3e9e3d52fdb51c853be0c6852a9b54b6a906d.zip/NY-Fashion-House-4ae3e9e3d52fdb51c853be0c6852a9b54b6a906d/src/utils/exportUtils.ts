
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { formatUSADateTime } from './dateUtils';
import { formatUSD } from './currencyUtils';

export interface ExportData {
  title: string;
  headers: string[];
  rows: (string | number)[][];
  summary?: {[key: string]: string | number;};
}

export function exportToPDF(data: ExportData): void {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;

  // Add title
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(data.title, pageWidth / 2, 20, { align: 'center' });

  // Add generation date
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const dateText = `Generated: ${formatUSADateTime(new Date())}`;
  doc.text(dateText, pageWidth - 20, 30, { align: 'right' });

  // Add table
  autoTable(doc, {
    head: [data.headers],
    body: data.rows,
    startY: 40,
    styles: {
      fontSize: 8,
      cellPadding: 3
    },
    headStyles: {
      fillColor: [59, 130, 246],
      textColor: 255,
      fontStyle: 'bold'
    },
    alternateRowStyles: {
      fillColor: [249, 250, 251]
    }
  });

  // Add summary if provided
  if (data.summary) {
    const finalY = (doc as any).lastAutoTable.finalY + 20;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('Summary', 20, finalY);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    let yPos = finalY + 10;

    Object.entries(data.summary).forEach(([key, value]) => {
      const displayValue = typeof value === 'number' && key.toLowerCase().includes('amount') ?
      formatUSD(value) :
      value.toString();
      doc.text(`${key}: ${displayValue}`, 20, yPos);
      yPos += 8;
    });
  }

  // Save the PDF
  const filename = `${data.title.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0].replace(/-/g, '')}.pdf`;
  doc.save(filename);
}

export function exportSalesReportToPDF(reportData: SalesReportData): void {
  const doc = new jsPDF();
  let yPosition = 20;

  // Header
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('Sales Analytics Report', 20, yPosition);
  yPosition += 15;

  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(`Period: ${reportData.summary.period}`, 20, yPosition);
  doc.text(`Generated: ${formatUSADateTime(new Date())}`, 120, yPosition);
  yPosition += 20;

  // Summary Section
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('Executive Summary', 20, yPosition);
  yPosition += 10;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  const summaryData = [
  ['Total Sales', formatUSD(reportData.summary.totalSales)],
  ['Total Quantity Sold', reportData.summary.totalQuantity.toLocaleString()],
  ['Total Transactions', reportData.summary.totalTransactions.toLocaleString()],
  ['Average Order Value', formatUSD(reportData.summary.averageOrderValue)]];


  autoTable(doc, {
    body: summaryData,
    startY: yPosition,
    theme: 'grid',
    styles: { fontSize: 10 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 60 },
      1: { cellWidth: 60, halign: 'right' }
    }
  });

  yPosition = (doc as any).lastAutoTable.finalY + 20;

  // Category Breakdown
  if (reportData.categories.length > 0) {
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('Category Breakdown', 20, yPosition);
    yPosition += 10;

    const categoryHeaders = ['Category', 'Revenue', 'Quantity', 'Percentage'];
    const categoryRows = reportData.categories.map((cat) => [
    cat.category,
    formatUSD(cat.revenue),
    cat.quantity.toString(),
    `${cat.percentage.toFixed(1)}%`]
    );

    autoTable(doc, {
      head: [categoryHeaders],
      body: categoryRows,
      startY: yPosition,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [66, 139, 202] },
      columnStyles: {
        1: { halign: 'right' },
        2: { halign: 'right' },
        3: { halign: 'right' }
      }
    });

    yPosition = (doc as any).lastAutoTable.finalY + 20;
  }

  // Employee Performance
  if (reportData.employees.length > 0) {
    // Add new page if needed
    if (yPosition > 220) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('Employee Performance', 20, yPosition);
    yPosition += 10;

    const employeeHeaders = ['Employee', 'Sales', 'Quantity', 'Transactions', 'Avg/Transaction'];
    const employeeRows = reportData.employees.slice(0, 15).map((emp) => [
    emp.employeeName,
    formatUSD(emp.sales),
    emp.quantity.toString(),
    emp.transactions.toString(),
    formatUSD(emp.transactions > 0 ? emp.sales / emp.transactions : 0)]
    );

    autoTable(doc, {
      head: [employeeHeaders],
      body: employeeRows,
      startY: yPosition,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [66, 139, 202] },
      columnStyles: {
        1: { halign: 'right' },
        2: { halign: 'right' },
        3: { halign: 'right' },
        4: { halign: 'right' }
      }
    });
  }

  // Save the PDF
  const filename = `sales-report-${new Date().toISOString().split('T')[0].replace(/-/g, '')}.pdf`;
  doc.save(filename);
}

export function exportToExcel(data: ExportData[]): void {
  const workbook = XLSX.utils.book_new();

  data.forEach((sheetData, index) => {
    const worksheet = XLSX.utils.aoa_to_sheet([
    [sheetData.title],
    [],
    sheetData.headers,
    ...sheetData.rows]
    );

    // Add summary if provided
    if (sheetData.summary) {
      const summaryData = Object.entries(sheetData.summary).map(([key, value]) => [key, value]);
      XLSX.utils.sheet_add_aoa(worksheet, [[''], ['Summary'], ...summaryData], {
        origin: -1
      });
    }

    const sheetName = sheetData.title.substring(0, 31); // Excel sheet name limit
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  });

  const filename = `Reports_${new Date().toISOString().split('T')[0].replace(/-/g, '')}.xlsx`;
  XLSX.writeFile(workbook, filename);
}

export function generateChartDataURL(chartRef: any): string | null {
  if (!chartRef?.current) return null;

  const canvas = chartRef.current.canvas;
  return canvas.toDataURL('image/png');
}

export function exportDataWithUSAFormatting(data: any[], filename: string): void {
  // Helper function to export data with proper USA formatting
  const formattedData = data.map((item) => {
    const formatted: any = {};

    Object.entries(item).forEach(([key, value]) => {
      if (value instanceof Date) {
        formatted[key] = formatUSADateTime(value);
      } else if (typeof value === 'number' && key.toLowerCase().includes('amount')) {
        formatted[key] = formatUSD(value);
      } else {
        formatted[key] = value;
      }
    });

    return formatted;
  });

  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(formattedData);

  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data');
  XLSX.writeFile(workbook, `${filename}_${new Date().toISOString().split('T')[0].replace(/-/g, '')}.xlsx`);
}