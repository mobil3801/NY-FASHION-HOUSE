export class ErrorRecoveryStrategies {
  selectStrategy(error: Error, level: string): string {
    // Network related errors
    if (this.isNetworkError(error)) {
      return 'network-retry';
    }

    // Component mounting errors
    if (this.isComponentError(error)) {
      return level === 'component' ? 'component-remount' : 'auto-retry';
    }

    // Memory related errors
    if (this.isMemoryError(error)) {
      return 'memory-cleanup';
    }

    // Chunk loading errors (common in React apps)
    if (this.isChunkError(error)) {
      return 'page-reload';
    }

    // Default strategy
    return level === 'app' ? 'page-reload' : 'auto-retry';
  }

  private isNetworkError(error: Error): boolean {
    return /Network Error|fetch|XMLHttpRequest/i.test(error.message);
  }

  private isComponentError(error: Error): boolean {
    return /Cannot read prop|undefined|null/i.test(error.message);
  }

  private isMemoryError(error: Error): boolean {
    return /out of memory|Maximum call stack/i.test(error.message);
  }

  private isChunkError(error: Error): boolean {
    return /Loading chunk|ChunkLoadError/i.test(error.message);
  }
}