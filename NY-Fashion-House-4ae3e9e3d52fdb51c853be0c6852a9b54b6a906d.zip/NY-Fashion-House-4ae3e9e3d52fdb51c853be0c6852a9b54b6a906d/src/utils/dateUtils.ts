
/**
 * USA-focused date and time utilities
 * All date/time formatting follows USA standards (MM/DD/YYYY and 12-hour format)
 */

export interface USADate {
  formatted: string;
  date: Date;
  timeFormatted: string;
  dateTimeFormatted: string;
}

export const usaHolidays = [
{ date: '2024-01-01', name: 'New Year\'s Day' },
{ date: '2024-01-15', name: 'Martin Luther King Jr. Day' },
{ date: '2024-02-19', name: 'Presidents Day' },
{ date: '2024-05-27', name: 'Memorial Day' },
{ date: '2024-06-19', name: 'Juneteenth' },
{ date: '2024-07-04', name: 'Independence Day' },
{ date: '2024-09-02', name: 'Labor Day' },
{ date: '2024-10-14', name: 'Columbus Day' },
{ date: '2024-11-11', name: 'Veterans Day' },
{ date: '2024-11-28', name: 'Thanksgiving Day' },
{ date: '2024-12-25', name: 'Christmas Day' }];


export function formatUSADate(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(date);
}

export function formatUSATime(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  }).format(date);
}

export function formatUSADateTime(date: Date): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  }).format(date);
}

export function getUSADate(date: Date): USADate {
  return {
    formatted: formatUSADate(date),
    date,
    timeFormatted: formatUSATime(date),
    dateTimeFormatted: formatUSADateTime(date)
  };
}

export function isBusinessDay(date: Date): boolean {
  const day = date.getDay();
  const dateStr = formatUSADate(date).split('/').map((p) => p.padStart(2, '0')).join('-');
  const formattedDateStr = `${dateStr.split('/')[2]}-${dateStr.split('/')[0]}-${dateStr.split('/')[1]}`;

  // Check if it's weekend (Saturday = 6, Sunday = 0)
  if (day === 0 || day === 6) return false;

  // Check if it's a federal holiday
  return !usaHolidays.some((holiday) => holiday.date === formattedDateStr);
}

export function getBusinessDaysInRange(startDate: Date, endDate: Date): Date[] {
  const businessDays: Date[] = [];
  const current = new Date(startDate);

  while (current <= endDate) {
    if (isBusinessDay(current)) {
      businessDays.push(new Date(current));
    }
    current.setDate(current.getDate() + 1);
  }

  return businessDays;
}

export function parseUSADate(dateString: string): Date | null {
  // Parse MM/DD/YYYY format
  const parts = dateString.split('/');
  if (parts.length !== 3) return null;

  const month = parseInt(parts[0], 10) - 1; // Month is 0-indexed
  const day = parseInt(parts[1], 10);
  const year = parseInt(parts[2], 10);

  if (isNaN(month) || isNaN(day) || isNaN(year)) return null;

  const date = new Date(year, month, day);

  // Check if the date is valid
  if (date.getMonth() !== month || date.getDate() !== day || date.getFullYear() !== year) {
    return null;
  }

  return date;
}

export function formatDateForInput(date: Date): string {
  // Returns YYYY-MM-DD format for HTML date inputs
  return date.toISOString().split('T')[0];
}

export function formatTimeForInput(date: Date): string {
  // Returns HH:MM format for HTML time inputs
  return date.toTimeString().slice(0, 5);
}

// For backward compatibility - replace the old bangladeshi functions
export const getBangladeshiDate = getUSADate;
export const formatBangladeshiCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2
  }).format(amount);
};

// Additional USA-specific date utilities
export function getUSAFiscalYear(date: Date = new Date()): number {
  const month = date.getMonth();
  const year = date.getFullYear();

  // USA federal fiscal year starts October 1st
  return month >= 9 ? year + 1 : year;
}

export function getUSATaxYear(date: Date = new Date()): number {
  // Tax year is calendar year for individuals
  return date.getFullYear();
}

export function formatUSADateRange(startDate: Date, endDate: Date): string {
  const start = formatUSADate(startDate);
  const end = formatUSADate(endDate);

  if (start === end) {
    return start;
  }

  return `${start} - ${end}`;
}