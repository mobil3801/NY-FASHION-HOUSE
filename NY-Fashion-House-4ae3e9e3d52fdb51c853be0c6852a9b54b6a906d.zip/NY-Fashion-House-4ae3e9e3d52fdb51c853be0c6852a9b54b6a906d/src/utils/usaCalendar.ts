
/**
 * USA-focused calendar and date utilities
 * Provides USA-standard date/time formatting and business logic
 */

import { formatUSD } from './currencyUtils';
import { formatUSADate, formatUSATime, formatUSADateTime } from './dateUtils';

export interface USACalendarDate {
  date: Date;
  formatted: string;
  timeFormatted: string;
  dateTimeFormatted: string;
  fiscalYear: number;
  fiscalQuarter: number;
  businessDay: boolean;
}

// USA fiscal year typically starts October 1st for federal government
// Many businesses use January 1st, but we'll use the federal standard
export function getUSAFiscalYear(date: Date): number {
  const month = date.getMonth();
  const year = date.getFullYear();

  // Fiscal year starts in October (month 9)
  return month >= 9 ? year + 1 : year;
}

export function getUSAFiscalQuarter(date: Date): number {
  const month = date.getMonth();

  // Q1: Oct-Dec, Q2: Jan-Mar, Q3: Apr-Jun, Q4: Jul-Sep
  if (month >= 9) return 1; // Oct-Dec
  if (month >= 6) return 4; // Jul-Sep
  if (month >= 3) return 3; // Apr-Jun
  return 2; // Jan-Mar
}

export function getUSACalendarDate(date: Date): USACalendarDate {
  return {
    date,
    formatted: formatUSADate(date),
    timeFormatted: formatUSATime(date),
    dateTimeFormatted: formatUSADateTime(date),
    fiscalYear: getUSAFiscalYear(date),
    fiscalQuarter: getUSAFiscalQuarter(date),
    businessDay: isUSABusinessDay(date)
  };
}

export function isUSABusinessDay(date: Date): boolean {
  const day = date.getDay();

  // Check if it's weekend (Saturday = 6, Sunday = 0)
  if (day === 0 || day === 6) return false;

  // Check if it's a federal holiday
  const dateStr = formatUSADate(date);
  const [month, day_num, year] = dateStr.split('/').map(Number);

  // Major USA federal holidays
  const holidays = [
  { month: 1, day: 1 }, // New Year's Day
  { month: 7, day: 4 }, // Independence Day
  { month: 12, day: 25 } // Christmas Day
  // Note: Some holidays are calculated (like Thanksgiving, Labor Day)
  // For simplicity, we're including only fixed-date holidays
  ];

  return !holidays.some((holiday) =>
  holiday.month === month && holiday.day === day_num
  );
}

export function getUSABusinessDaysInRange(startDate: Date, endDate: Date): Date[] {
  const businessDays: Date[] = [];
  const current = new Date(startDate);

  while (current <= endDate) {
    if (isUSABusinessDay(current)) {
      businessDays.push(new Date(current));
    }
    current.setDate(current.getDate() + 1);
  }

  return businessDays;
}

export function formatUSACurrency(amount: number): string {
  return formatUSD(amount);
}

export function getUSAQuarterDates(year: number, quarter: number): {start: Date;end: Date;} {
  let startMonth: number;
  let endMonth: number;

  // USA fiscal quarters based on federal fiscal year
  switch (quarter) {
    case 1: // Q1: Oct-Dec
      startMonth = 9; // October (0-indexed)
      endMonth = 11; // December
      break;
    case 2: // Q2: Jan-Mar
      startMonth = 0; // January
      endMonth = 2; // March
      year = year - 1; // Adjust year for Q2-Q4
      break;
    case 3: // Q3: Apr-Jun
      startMonth = 3; // April
      endMonth = 5; // June
      year = year - 1;
      break;
    case 4: // Q4: Jul-Sep
      startMonth = 6; // July
      endMonth = 8; // September
      year = year - 1;
      break;
    default:
      throw new Error('Quarter must be between 1 and 4');
  }

  const start = new Date(year, startMonth, 1);
  const end = new Date(year, endMonth + 1, 0); // Last day of the month

  return { start, end };
}

// For backward compatibility with existing code
export const formatBangladeshiCurrency = formatUSACurrency;
export const getBangladeshiDate = getUSACalendarDate;