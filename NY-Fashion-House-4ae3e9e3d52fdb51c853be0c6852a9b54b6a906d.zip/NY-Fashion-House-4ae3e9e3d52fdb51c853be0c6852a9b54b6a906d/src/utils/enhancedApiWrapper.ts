/**
 * Enhanced API Wrapper with Request Size Management
 * Extends the existing API wrapper with better handling of large requests
 */

import { apiWrapper } from './apiWrapper';
import { requestSizeManager, formatFileSize } from './requestSizeManager';
import { toast } from 'sonner';

interface EnhancedApiOptions {
  enableChunking?: boolean;
  maxRetries?: number;
  retryDelay?: number;
  timeout?: number;
  showProgress?: boolean;
}

class EnhancedApiWrapper {
  private baseWrapper = apiWrapper;

  /**
   * Enhanced table creation with size validation and chunking
   */
  async tableCreate(
    tableId: number | string, 
    data: any,
    options: EnhancedApiOptions = {}
  ): Promise<{ error?: string }> {
    const {
      enableChunking = true,
      maxRetries = 3,
      retryDelay = 1000,
      showProgress = false
    } = options;

    // Handle table name to ID mapping if needed
    const actualTableId = typeof tableId === 'string' ? this.getTableId(tableId) : tableId;
    if (!actualTableId) {
      return { error: `Invalid table identifier: ${tableId}` };
    }

    // Validate request size
    const sizeValidation = requestSizeManager.validateSize(data);
    
    if (!sizeValidation.isValid && enableChunking && Array.isArray(data)) {
      // Handle large array data with chunking
      if (showProgress) {
        toast.info(`Processing ${data.length} records in chunks due to size limit...`);
      }

      try {
        await requestSizeManager.processBulkOperation(
          data,
          async (chunk) => {
            const { error } = await this.baseWrapper.tableCreate(actualTableId, chunk);
            if (error) throw new Error(error);
            return chunk;
          },
          {
            onProgress: showProgress ? (progress) => {
              toast.info(`Processing: ${Math.round(progress)}%`, { id: 'bulk-create' });
            } : undefined
          }
        );

        if (showProgress) {
          toast.dismiss('bulk-create');
          toast.success('All records created successfully');
        }

        return {};
      } catch (error) {
        if (showProgress) toast.dismiss('bulk-create');
        return { error: `Bulk create failed: ${(error as Error).message}` };
      }
    }

    if (!sizeValidation.isValid) {
      return { 
        error: `Request too large: ${formatFileSize(sizeValidation.size)} exceeds limit of ${formatFileSize(sizeValidation.maxSize)}. Consider reducing data size or enabling chunking.` 
      };
    }

    // Standard API call with retry logic
    return this.withRetry(
      () => this.baseWrapper.tableCreate(actualTableId, data),
      maxRetries,
      retryDelay
    );
  }

  /**
   * Enhanced table update with size validation
   */
  async tableUpdate(
    tableId: number | string,
    data: any,
    options: EnhancedApiOptions = {}
  ): Promise<{ error?: string }> {
    const { maxRetries = 3, retryDelay = 1000 } = options;
    
    const actualTableId = typeof tableId === 'string' ? this.getTableId(tableId) : tableId;
    if (!actualTableId) {
      return { error: `Invalid table identifier: ${tableId}` };
    }

    // Validate request size
    const sizeValidation = requestSizeManager.validateSize(data);
    if (!sizeValidation.isValid) {
      return { 
        error: `Request too large: ${formatFileSize(sizeValidation.size)} exceeds limit of ${formatFileSize(sizeValidation.maxSize)}` 
      };
    }

    return this.withRetry(
      () => this.baseWrapper.tableUpdate(actualTableId, data),
      maxRetries,
      retryDelay
    );
  }

  /**
   * Enhanced table query with optimized parameters
   */
  async tablePage(
    tableId: number | string,
    queryParams: any,
    options: EnhancedApiOptions = {}
  ): Promise<{ data?: any; error?: string }> {
    const { maxRetries = 3, retryDelay = 1000 } = options;
    
    const actualTableId = typeof tableId === 'string' ? this.getTableId(tableId) : tableId;
    if (!actualTableId) {
      return { error: `Invalid table identifier: ${tableId}` };
    }

    // Optimize query parameters to reduce request size
    const optimizedParams = this.optimizeQueryParams(queryParams);

    return this.withRetry(
      () => this.baseWrapper.tablePage(actualTableId, optimizedParams),
      maxRetries,
      retryDelay
    );
  }

  /**
   * Enhanced file upload with chunking support
   */
  async upload(
    fileInfo: { filename: string; file: File },
    options: EnhancedApiOptions = {}
  ): Promise<{ data?: any; error?: string }> {
    const { showProgress = true } = options;
    const { file, filename } = fileInfo;

    // Validate file size and type
    const validation = await requestSizeManager.validateAndResizeImage(file, {
      maxFileSize: 50, // 50MB limit
      allowedTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf'],
      compressionQuality: 0.8
    });

    if (!validation.isValid) {
      return { error: validation.error };
    }

    const processedFile = validation.file!;

    // Use chunked upload for large files
    if (processedFile.size > 10 * 1024 * 1024) { // 10MB threshold
      if (showProgress) {
        toast.info(`Uploading large file: ${filename} (${formatFileSize(processedFile.size)})`);
      }

      const result = await requestSizeManager.uploadFileInChunks(
        processedFile,
        '/api/upload',
        {
          onProgress: showProgress ? (progress) => {
            toast.info(`Uploading: ${Math.round(progress)}%`, { id: 'upload-progress' });
          } : undefined
        }
      );

      if (showProgress) {
        toast.dismiss('upload-progress');
      }

      if (!result.success) {
        return { error: result.error };
      }

      return { data: result.fileId };
    }

    // Standard upload for smaller files
    try {
      return await (window.ezsite?.apis?.upload || (() => Promise.resolve({ error: 'Upload API not available' })))({
        filename,
        file: processedFile
      });
    } catch (error) {
      return { error: `Upload failed: ${(error as Error).message}` };
    }
  }

  /**
   * Retry mechanism for API calls
   */
  private async withRetry<T>(
    operation: () => Promise<T>,
    maxRetries: number,
    delay: number
  ): Promise<T> {
    let lastError: any;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error: any) {
        lastError = error;
        
        // Don't retry on certain errors
        if (error.status === 400 || error.status === 401 || error.status === 403) {
          throw error;
        }

        if (attempt < maxRetries) {
          await new Promise(resolve => setTimeout(resolve, delay * attempt));
        }
      }
    }

    throw lastError;
  }

  /**
   * Optimize query parameters to reduce request size
   */
  private optimizeQueryParams(params: any): any {
    if (!params) return params;

    const optimized = { ...params };

    // Compress filters if they're too large
    if (optimized.Filters && Array.isArray(optimized.Filters)) {
      optimized.Filters = optimized.Filters.slice(0, 50); // Limit filters
    }

    // Ensure reasonable page size
    if (optimized.PageSize > 1000) {
      optimized.PageSize = 1000;
    }

    return optimized;
  }

  /**
   * Get table ID from table name
   */
  private getTableId(tableName: string): number | null {
    const tableMapping: Record<string, number> = {
      'sales_transactions': 38156,
      'products': 38157,
      'customers': 38563,
      'suppliers': 38564,
      'invoices': 38565,
      'employees': 37818,
      'expenses': 38512,
      'salary_structures': 38566,
      'salary_calculations': 38567,
      'salary_advances': 38568,
      'salary_payments': 38569,
      'accounts': 38570,
      'journal_entries': 38571,
      'journal_entry_lines': 38572,
      'data_operations': 37730,
      'audit_logs': 37723
    };

    return tableMapping[tableName] || null;
  }
}

// Create enhanced API instance
export const enhancedApiWrapper = new EnhancedApiWrapper();

// Extend global ezsite APIs with enhanced functionality
if (typeof window !== 'undefined' && window.ezsite) {
  const originalApis = window.ezsite.apis;
  
  window.ezsite.apis = {
    ...originalApis,
    // Enhanced methods
    tableCreateEnhanced: (tableId: number | string, data: any, options?: EnhancedApiOptions) =>
      enhancedApiWrapper.tableCreate(tableId, data, options),
    tableUpdateEnhanced: (tableId: number | string, data: any, options?: EnhancedApiOptions) =>
      enhancedApiWrapper.tableUpdate(tableId, data, options),
    tablePageEnhanced: (tableId: number | string, queryParams: any, options?: EnhancedApiOptions) =>
      enhancedApiWrapper.tablePage(tableId, queryParams, options),
    uploadEnhanced: (fileInfo: any, options?: EnhancedApiOptions) =>
      enhancedApiWrapper.upload(fileInfo, options),
  };
}

export default enhancedApiWrapper;