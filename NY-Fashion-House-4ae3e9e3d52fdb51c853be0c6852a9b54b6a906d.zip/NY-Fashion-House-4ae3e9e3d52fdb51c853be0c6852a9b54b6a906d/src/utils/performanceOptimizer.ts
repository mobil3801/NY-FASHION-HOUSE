interface PerformanceMetrics {
  averageCaptureTime: number;
  maxCaptureTime: number;
  minCaptureTime: number;
  totalOperations: number;
  memoryUsage?: number;
  peakMemoryUsage?: number;
  operationsPerSecond: number;
}

export class PerformanceOptimizer {
  private metrics: PerformanceMetrics = {
    averageCaptureTime: 0,
    maxCaptureTime: 0,
    minCaptureTime: Infinity,
    totalOperations: 0,
    operationsPerSecond: 0
  };

  private operationTimes: number[] = [];
  private startTime = performance.now();
  private isMonitoring = false;

  startMonitoring() {
    if (this.isMonitoring) return;

    this.isMonitoring = true;
    this.startTime = performance.now();

    // Monitor memory usage if available
    if ((performance as any).memory) {
      setInterval(() => {
        const memory = (performance as any).memory;
        this.metrics.memoryUsage = memory.usedJSHeapSize;
        this.metrics.peakMemoryUsage = Math.max(
          this.metrics.peakMemoryUsage || 0,
          memory.usedJSHeapSize
        );
      }, 5000);
    }
  }

  stopMonitoring() {
    this.isMonitoring = false;
  }

  withPerformanceTracking<T>(operationName: string, operation: () => T): T {
    const start = performance.now();

    try {
      const result = operation();
      const duration = performance.now() - start;
      this.recordOperation(duration);
      return result;
    } catch (error) {
      const duration = performance.now() - start;
      this.recordOperation(duration);
      throw error;
    }
  }

  async withAsyncPerformanceTracking<T>(
  operationName: string,
  operation: () => Promise<T>)
  : Promise<T> {
    const start = performance.now();

    try {
      const result = await operation();
      const duration = performance.now() - start;
      this.recordOperation(duration);
      return result;
    } catch (error) {
      const duration = performance.now() - start;
      this.recordOperation(duration);
      throw error;
    }
  }

  private recordOperation(duration: number) {
    this.operationTimes.push(duration);
    this.metrics.totalOperations++;
    this.metrics.maxCaptureTime = Math.max(this.metrics.maxCaptureTime, duration);
    this.metrics.minCaptureTime = Math.min(this.metrics.minCaptureTime, duration);

    // Keep only last 1000 operations for average calculation
    if (this.operationTimes.length > 1000) {
      this.operationTimes = this.operationTimes.slice(-1000);
    }

    // Calculate average
    this.metrics.averageCaptureTime =
    this.operationTimes.reduce((sum, time) => sum + time, 0) / this.operationTimes.length;

    // Calculate operations per second
    const elapsedSeconds = (performance.now() - this.startTime) / 1000;
    this.metrics.operationsPerSecond = this.metrics.totalOperations / Math.max(elapsedSeconds, 1);
  }

  getMetrics(): PerformanceMetrics {
    return { ...this.metrics };
  }

  reset() {
    this.metrics = {
      averageCaptureTime: 0,
      maxCaptureTime: 0,
      minCaptureTime: Infinity,
      totalOperations: 0,
      operationsPerSecond: 0
    };
    this.operationTimes = [];
    this.startTime = performance.now();
  }

  // Optimize for production - debounce frequent operations
  debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number)
  : (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout | null = null;

    return (...args: Parameters<T>) => {
      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(() => func(...args), wait);
    };
  }

  // Throttle high-frequency operations
  throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number)
  : (...args: Parameters<T>) => void {
    let inThrottle: boolean = false;

    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        func(...args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }
}