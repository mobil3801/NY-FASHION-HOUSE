// Enhanced stack trace parsing with component detection
import { DevToolsStackFrame } from './devToolsErrorCollector';

export interface ParsedStackFrame {
  originalFrame: DevToolsStackFrame;
  isReactComponent: boolean;
  isUserCode: boolean;
  isLibraryCode: boolean;
  componentName?: string;
  hookName?: string;
  filePath: string;
  fileName: string;
  relativeFilePath: string;
}

export interface StackTraceAnalysis {
  frames: ParsedStackFrame[];
  errorOrigin: ParsedStackFrame | null;
  reactComponentChain: ParsedStackFrame[];
  userCodeFrames: ParsedStackFrame[];
  libraryFrames: ParsedStackFrame[];
  summary: string;
}

class EnhancedStackTraceParser {
  private readonly REACT_PATTERNS = [
  /react-dom/i,
  /react/i,
  /Component\.render/,
  /createElement/,
  /callCallback/,
  /invokeCallback/,
  /commitWork/,
  /updateComponent/];


  private readonly USER_CODE_PATTERNS = [
  /^(https?:\/\/[^\/]+)?\/(src|components|pages|utils|services|hooks|lib)\//,
  /\.tsx?$/,
  /\.jsx?$/];


  private readonly LIBRARY_PATTERNS = [
  /node_modules/,
  /webpack/,
  /lodash/,
  /moment/,
  /@babel/,
  /core-js/,
  /regenerator/];


  private readonly HOOK_PATTERNS = [
  /use[A-Z][a-zA-Z]*/,
  /useState/,
  /useEffect/,
  /useCallback/,
  /useMemo/,
  /useContext/,
  /useReducer/,
  /useRef/];


  public analyzeStackTrace(frames: DevToolsStackFrame[]): StackTraceAnalysis {
    const parsedFrames = frames.map((frame) => this.parseFrame(frame));

    const errorOrigin = this.findErrorOrigin(parsedFrames);
    const reactComponentChain = this.extractReactComponentChain(parsedFrames);
    const userCodeFrames = parsedFrames.filter((frame) => frame.isUserCode);
    const libraryFrames = parsedFrames.filter((frame) => frame.isLibraryCode);

    const summary = this.generateSummary(parsedFrames, errorOrigin);

    return {
      frames: parsedFrames,
      errorOrigin,
      reactComponentChain,
      userCodeFrames,
      libraryFrames,
      summary
    };
  }

  private parseFrame(frame: DevToolsStackFrame): ParsedStackFrame {
    const filePath = frame.fileName || '';
    const fileName = filePath.split('/').pop() || filePath;
    const relativeFilePath = this.getRelativeFilePath(filePath);

    const isReactComponent = this.isReactComponentFrame(frame);
    const isUserCode = this.isUserCodeFrame(frame);
    const isLibraryCode = this.isLibraryCodeFrame(frame);

    const componentName = this.extractComponentName(frame);
    const hookName = this.extractHookName(frame);

    return {
      originalFrame: frame,
      isReactComponent,
      isUserCode,
      isLibraryCode,
      componentName,
      hookName,
      filePath,
      fileName,
      relativeFilePath
    };
  }

  private isReactComponentFrame(frame: DevToolsStackFrame): boolean {
    const fileName = frame.fileName || '';
    const functionName = frame.functionName || '';

    return this.REACT_PATTERNS.some((pattern) =>
    pattern.test(fileName) || pattern.test(functionName)
    ) || this.isReactComponentFunction(functionName);
  }

  private isReactComponentFunction(functionName: string): boolean {
    if (!functionName) return false;

    // Check if it's a React component (starts with capital letter)
    const isComponent = /^[A-Z][a-zA-Z0-9]*/.test(functionName);

    // Check if it's in a component file
    const isInComponentFile = /Component|\.tsx?$/.test(functionName);

    return isComponent || isInComponentFile;
  }

  private isUserCodeFrame(frame: DevToolsStackFrame): boolean {
    const fileName = frame.fileName || '';

    return this.USER_CODE_PATTERNS.some((pattern) =>
    pattern.test(fileName)
    ) && !this.isLibraryCodeFrame(frame);
  }

  private isLibraryCodeFrame(frame: DevToolsStackFrame): boolean {
    const fileName = frame.fileName || '';

    return this.LIBRARY_PATTERNS.some((pattern) =>
    pattern.test(fileName)
    );
  }

  private extractComponentName(frame: DevToolsStackFrame): string | undefined {
    const functionName = frame.functionName || '';

    // Extract React component name
    const componentMatch = functionName.match(/^([A-Z][a-zA-Z0-9]*)/);
    if (componentMatch) {
      return componentMatch[1];
    }

    // Extract from file path
    const fileName = frame.fileName || '';
    const fileComponentMatch = fileName.match(/\/([A-Z][a-zA-Z0-9]*)\.(tsx?|jsx?)$/);
    if (fileComponentMatch) {
      return fileComponentMatch[1];
    }

    return undefined;
  }

  private extractHookName(frame: DevToolsStackFrame): string | undefined {
    const functionName = frame.functionName || '';

    const hookMatch = this.HOOK_PATTERNS.find((pattern) =>
    pattern.test(functionName)
    );

    return hookMatch ? functionName : undefined;
  }

  private getRelativeFilePath(filePath: string): string {
    // Convert absolute paths to relative paths for better readability
    if (filePath.includes('/src/')) {
      return filePath.substring(filePath.indexOf('/src/') + 1);
    }

    if (filePath.includes('localhost') || filePath.includes('http')) {
      const url = new URL(filePath);
      return url.pathname.substring(1); // Remove leading slash
    }

    return filePath;
  }

  private findErrorOrigin(frames: ParsedStackFrame[]): ParsedStackFrame | null {
    // Find the first user code frame as the likely error origin
    const userCodeFrame = frames.find((frame) => frame.isUserCode);
    if (userCodeFrame) return userCodeFrame;

    // If no user code, find the first non-library frame
    const nonLibraryFrame = frames.find((frame) => !frame.isLibraryCode);
    if (nonLibraryFrame) return nonLibraryFrame;

    // Fallback to first frame
    return frames[0] || null;
  }

  private extractReactComponentChain(frames: ParsedStackFrame[]): ParsedStackFrame[] {
    return frames.
    filter((frame) => frame.isReactComponent && frame.componentName).
    slice(0, 5); // Limit to top 5 components to avoid noise
  }

  private generateSummary(frames: ParsedStackFrame[], errorOrigin: ParsedStackFrame | null): string {
    if (!errorOrigin) {
      return 'Error occurred in unknown location';
    }

    const location = `${errorOrigin.fileName}:${errorOrigin.originalFrame.lineNumber}`;

    if (errorOrigin.componentName) {
      return `Error in ${errorOrigin.componentName} component at ${location}`;
    }

    if (errorOrigin.hookName) {
      return `Error in ${errorOrigin.hookName} hook at ${location}`;
    }

    if (errorOrigin.isUserCode) {
      return `Error in user code at ${location}`;
    }

    return `Error at ${location}`;
  }

  public formatAnalysisForDisplay(analysis: StackTraceAnalysis): string {
    let formatted = `${analysis.summary}\n\n`;

    if (analysis.reactComponentChain.length > 0) {
      formatted += 'React Component Chain:\n';
      analysis.reactComponentChain.forEach((frame, index) => {
        formatted += `  ${index + 1}. ${frame.componentName} (${frame.relativeFilePath})\n`;
      });
      formatted += '\n';
    }

    if (analysis.userCodeFrames.length > 0) {
      formatted += 'User Code Stack:\n';
      analysis.userCodeFrames.slice(0, 5).forEach((frame, index) => {
        const func = frame.originalFrame.functionName ? `${frame.originalFrame.functionName} ` : '';
        formatted += `  ${index + 1}. ${func}at ${frame.relativeFilePath}:${frame.originalFrame.lineNumber}\n`;
      });
      formatted += '\n';
    }

    return formatted;
  }

  public getErrorLocation(analysis: StackTraceAnalysis): string {
    if (!analysis.errorOrigin) return 'Unknown location';

    const frame = analysis.errorOrigin;
    return `${frame.relativeFilePath}:${frame.originalFrame.lineNumber}:${frame.originalFrame.columnNumber}`;
  }

  public getComponentContext(analysis: StackTraceAnalysis): string[] {
    return analysis.reactComponentChain.
    map((frame) => frame.componentName).
    filter((name): name is string => !!name);
  }
}

export const enhancedStackTraceParser = new EnhancedStackTraceParser();