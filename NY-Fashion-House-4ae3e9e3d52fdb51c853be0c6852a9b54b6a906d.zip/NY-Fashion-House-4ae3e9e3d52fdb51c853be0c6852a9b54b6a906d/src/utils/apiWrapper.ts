// Enhanced API wrapper with EasySite API integration
import { handleApiError } from '@/utils/enhancedGlobalErrorHandler';
import { ErrorContext } from '@/types/errorTypes';

// EasySite API Configuration
const EASYSITE_API_CONFIG = {
  baseUrl: 'https://easysite.ai/autodev/CustomTableValue',
  randomCode: 'y0to43847qzd',
  projectToken: 'qKsyly/7nVSr4F+JUBmF5x6f6oavKZ02Xs/fQeBsX4oKnBnfwoYJgfdUa0ltsqn1RYoR24v5AUpKlUZ/bmXPlMofCwW1+dVGxg+26WofoI3MUpVN6Pb3ILuK4mTbWZDc'
};

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  params?: any;
  body?: any;
  timeout?: number;
  context?: Partial<ErrorContext>;
}

// Table mapping for database operations
const TABLE_MAPPING: Record<number, string> = {
  38156: 'sales_transactions',
  38157: 'products',
  38563: 'customers',
  38564: 'suppliers',
  38565: 'invoices',
  37818: 'employees',
  38512: 'expenses',
  38566: 'salary_structures',
  38567: 'salary_calculations',
  38568: 'salary_advances',
  38569: 'salary_payments',
  38570: 'accounts',
  38571: 'journal_entries',
  38572: 'journal_entry_lines'
};

class ApiWrapper {
  private baseUrl: string = '';
  private defaultHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    'customauth': EASYSITE_API_CONFIG.projectToken
  };

  // Enhanced API call with comprehensive error handling
  async call<T>(endpoint: string, options: ApiOptions = {}): Promise<T> {
    const {
      method = 'GET',
      headers = {},
      params = {},
      body,
      timeout = 30000,
      context = {}
    } = options;

    const url = this.buildUrl(endpoint, params);
    const requestConfig: RequestInit = {
      method,
      headers: {
        ...this.defaultHeaders,
        ...headers
      }
    };

    // Add timeout signal if supported
    if (typeof AbortSignal !== 'undefined' && 'timeout' in AbortSignal) {
      requestConfig.signal = AbortSignal.timeout(timeout);
    }

    if (body && method !== 'GET') {
      requestConfig.body = JSON.stringify(body);
    }

    const requestDetails = {
      url: endpoint,
      method,
      params,
      headers: requestConfig.headers,
      body
    };

    try {
      const response = await fetch(url, requestConfig);

      if (!response.ok) {
        const errorData = await response.text().catch(() => '');
        const error = new Error(`${method} ${endpoint} failed: ${response.statusText}`);

        // Handle API error with enhanced reporting
        const correlationId = handleApiError(
          {
            ...error,
            status: response.status,
            statusText: response.statusText,
            data: errorData
          },
          requestDetails,
          {
            ...context,
            severity: response.status >= 500 ? 'high' : 'medium'
          }
        );

        throw Object.assign(error, {
          status: response.status,
          statusText: response.statusText,
          data: errorData,
          correlationId
        });
      }

      const responseText = await response.text();

      try {
        return responseText ? JSON.parse(responseText) : null;
      } catch (parseError) {
        // Handle JSON parse errors
        const error = new Error(`Failed to parse JSON response from ${endpoint}`);
        handleApiError(
          parseError as Error,
          requestDetails,
          {
            ...context,
            action: `Parse response from ${method} ${endpoint}`,
            severity: 'medium'
          }
        );
        throw error;
      }

    } catch (fetchError: any) {
      // Handle network errors, timeouts, etc.
      if (fetchError.name === 'AbortError' || fetchError.name === 'TimeoutError') {
        const error = new Error(`Request to ${endpoint} timed out`);
        handleApiError(
          error,
          requestDetails,
          {
            ...context,
            action: `${method} ${endpoint}`,
            severity: 'medium',
            category: 'network'
          }
        );
        throw error;
      }

      // Re-throw if already handled API error
      if (fetchError.correlationId) {
        throw fetchError;
      }

      // Handle other fetch errors
      const error = new Error(`Network error: ${fetchError.message}`);
      handleApiError(
        fetchError,
        requestDetails,
        {
          ...context,
          action: `${method} ${endpoint}`,
          severity: 'high',
          category: 'network'
        }
      );
      throw error;
    }
  }

  // Convenience methods with enhanced error handling
  async get<T>(endpoint: string, params?: any, context?: Partial<ErrorContext>): Promise<T> {
    return this.call<T>(endpoint, {
      method: 'GET',
      params,
      context: { ...context, action: `GET ${endpoint}` }
    });
  }

  async post<T>(endpoint: string, body?: any, context?: Partial<ErrorContext>): Promise<T> {
    return this.call<T>(endpoint, {
      method: 'POST',
      body,
      context: { ...context, action: `POST ${endpoint}` }
    });
  }

  async put<T>(endpoint: string, body?: any, context?: Partial<ErrorContext>): Promise<T> {
    return this.call<T>(endpoint, {
      method: 'PUT',
      body,
      context: { ...context, action: `PUT ${endpoint}` }
    });
  }

  async delete<T>(endpoint: string, context?: Partial<ErrorContext>): Promise<T> {
    return this.call<T>(endpoint, {
      method: 'DELETE',
      context: { ...context, action: `DELETE ${endpoint}` }
    });
  }

  // Upload with error handling
  async upload<T>(endpoint: string, file: File, context?: Partial<ErrorContext>): Promise<T> {
    const formData = new FormData();
    formData.append('file', file);

    const requestDetails = {
      url: endpoint,
      method: 'POST' as const,
      body: { fileName: file.name, fileSize: file.size, fileType: file.type }
    };

    try {
      const response = await fetch(this.buildUrl(endpoint), {
        method: 'POST',
        headers: {
          'customauth': EASYSITE_API_CONFIG.projectToken
        },
        body: formData
      });

      if (!response.ok) {
        const error = new Error(`Upload to ${endpoint} failed: ${response.statusText}`);
        handleApiError(
          {
            ...error,
            status: response.status,
            statusText: response.statusText
          },
          requestDetails,
          {
            ...context,
            action: `Upload to ${endpoint}`,
            severity: 'medium'
          }
        );
        throw error;
      }

      const responseText = await response.text();
      return responseText ? JSON.parse(responseText) : null;

    } catch (uploadError: any) {
      if (!uploadError.correlationId) {
        handleApiError(
          uploadError,
          requestDetails,
          {
            ...context,
            action: `Upload to ${endpoint}`,
            severity: 'medium',
            category: 'network'
          }
        );
      }
      throw uploadError;
    }
  }

  private buildUrl(endpoint: string, params?: any): string {
    // Handle EasySite API endpoints
    if (endpoint.startsWith('/easysite/')) {
      const path = endpoint.replace('/easysite/', '');
      return `${EASYSITE_API_CONFIG.baseUrl}/${path}`;
    }

    const url = new URL(endpoint, this.baseUrl || window.location.origin);

    if (params) {
      Object.keys(params).forEach((key) => {
        if (params[key] !== undefined && params[key] !== null) {
          url.searchParams.append(key, String(params[key]));
        }
      });
    }

    return url.toString();
  }

  // Set authentication header
  setAuthToken(token: string): void {
    this.defaultHeaders['Authorization'] = `Bearer ${token}`;
  }

  // Remove authentication header
  clearAuthToken(): void {
    delete this.defaultHeaders['Authorization'];
  }

  // Set base URL
  setBaseUrl(url: string): void {
    this.baseUrl = url;
  }

  // EasySite API methods
  async getTableList(context?: Partial<ErrorContext>): Promise<{data?: any;error?: string;}> {
    try {
      const url = `${EASYSITE_API_CONFIG.baseUrl}/GetTableList/${EASYSITE_API_CONFIG.randomCode}`;
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'customauth': EASYSITE_API_CONFIG.projectToken,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        return { error: `Failed to fetch table list: ${response.statusText}` };
      }

      const data = await response.json();
      return { data };
    } catch (error: any) {
      handleApiError(
        error,
        { url: 'GetTableList', method: 'GET' },
        {
          ...context,
          action: 'Get table list',
          severity: 'medium',
          category: 'database'
        }
      );
      return { error: error.message };
    }
  }

  // Database table operations using EasySite API
  async tablePage(tableId: number, queryParams: any, context?: Partial<ErrorContext>): Promise<{data?: any;error?: string;}> {
    try {
      const url = `${EASYSITE_API_CONFIG.baseUrl}/Page/${EASYSITE_API_CONFIG.randomCode}/${tableId}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'customauth': EASYSITE_API_CONFIG.projectToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ pageFilter: queryParams })
      });

      if (!response.ok) {
        return { error: `Database query failed: ${response.statusText}` };
      }

      const data = await response.json();
      return { data };
    } catch (error: any) {
      handleApiError(
        error,
        { url: `tablePage/${tableId}`, method: 'POST', params: queryParams },
        {
          ...context,
          action: `Query table ${tableId}`,
          severity: 'medium',
          category: 'database'
        }
      );
      return { error: error.message };
    }
  }

  async tableCreate(tableId: number, data: any, context?: Partial<ErrorContext>): Promise<{error?: string;}> {
    try {
      const url = `${EASYSITE_API_CONFIG.baseUrl}/Create/${EASYSITE_API_CONFIG.randomCode}/${tableId}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'customauth': EASYSITE_API_CONFIG.projectToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ create: data })
      });

      if (!response.ok) {
        const errorText = await response.text();
        return { error: `Create operation failed: ${errorText}` };
      }

      return {};
    } catch (error: any) {
      handleApiError(
        error,
        { url: `tableCreate/${tableId}`, method: 'POST', body: data },
        {
          ...context,
          action: `Create record in table ${tableId}`,
          severity: 'medium',
          category: 'database'
        }
      );
      return { error: error.message };
    }
  }

  async tableUpdate(tableId: number, data: any, context?: Partial<ErrorContext>): Promise<{error?: string;}> {
    try {
      const url = `${EASYSITE_API_CONFIG.baseUrl}/UD/${EASYSITE_API_CONFIG.randomCode}/${tableId}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'customauth': EASYSITE_API_CONFIG.projectToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ update: data })
      });

      if (!response.ok) {
        const errorText = await response.text();
        return { error: `Update operation failed: ${errorText}` };
      }

      return {};
    } catch (error: any) {
      handleApiError(
        error,
        { url: `tableUpdate/${tableId}`, method: 'POST', body: data },
        {
          ...context,
          action: `Update record in table ${tableId}`,
          severity: 'medium',
          category: 'database'
        }
      );
      return { error: error.message };
    }
  }

  async tableDelete(tableId: number, params: any, context?: Partial<ErrorContext>): Promise<{error?: string;}> {
    try {
      const url = `${EASYSITE_API_CONFIG.baseUrl}/Delete/${EASYSITE_API_CONFIG.randomCode}/${tableId}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'customauth': EASYSITE_API_CONFIG.projectToken,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(params)
      });

      if (!response.ok) {
        const errorText = await response.text();
        return { error: `Delete operation failed: ${errorText}` };
      }

      return {};
    } catch (error: any) {
      handleApiError(
        error,
        { url: `tableDelete/${tableId}`, method: 'POST', params },
        {
          ...context,
          action: `Delete record from table ${tableId}`,
          severity: 'medium',
          category: 'database'
        }
      );
      return { error: error.message };
    }
  }
}

// Create singleton instance
export const apiWrapper = new ApiWrapper();

// Create global ezsite APIs compatibility layer
if (typeof window !== 'undefined') {
  window.ezsite = window.ezsite || {};
  window.ezsite.apis = {
    tablePage: (tableId: number, queryParams: any) => apiWrapper.tablePage(tableId, queryParams),
    tableCreate: (tableId: number, data: any) => apiWrapper.tableCreate(tableId, data),
    tableUpdate: (tableId: number, data: any) => apiWrapper.tableUpdate(tableId, data),
    tableDelete: (tableId: number, params: any) => apiWrapper.tableDelete(tableId, params),
    getTableList: () => apiWrapper.getTableList(),

    // Authentication methods (placeholder - would need implementation)
    register: async (credentials: any) => ({ error: 'Auth not implemented' }),
    login: async (credentials: any) => ({ error: 'Auth not implemented' }),
    logout: async () => ({ error: 'Auth not implemented' }),
    getUserInfo: async () => ({ error: 'Auth not implemented' }),
    sendResetPwdEmail: async (email: any) => ({ error: 'Auth not implemented' }),
    resetPassword: async (resetInfo: any) => ({ error: 'Auth not implemented' }),

    // Upload methods (placeholder)
    upload: async (fileInfo: any) => ({ error: 'Upload not implemented' }),
    getUploadUrl: async (storeFileId: number) => ({ error: 'Upload not implemented' })
  };
}

export default apiWrapper;

// TypeScript declarations for global ezsite APIs
declare global {
  interface Window {
    ezsite: {
      apis: {
        tablePage: (tableId: number, queryParams: any) => Promise<{data?: any;error?: string;}>;
        tableCreate: (tableId: number, data: any) => Promise<{error?: string;}>;
        tableUpdate: (tableId: number, data: any) => Promise<{error?: string;}>;
        tableDelete: (tableId: number, params: any) => Promise<{error?: string;}>;
        getTableList: () => Promise<{data?: any;error?: string;}>;
        register: (credentials: any) => Promise<{error?: string;}>;
        login: (credentials: any) => Promise<{error?: string;}>;
        logout: () => Promise<{error?: string;}>;
        getUserInfo: () => Promise<{data?: any;error?: string;}>;
        sendResetPwdEmail: (email: any) => Promise<{error?: string;}>;
        resetPassword: (resetInfo: any) => Promise<{error?: string;}>;
        upload: (fileInfo: any) => Promise<{data?: any;error?: string;}>;
        getUploadUrl: (storeFileId: number) => Promise<{data?: any;error?: string;}>;
      };
    };
  }
}