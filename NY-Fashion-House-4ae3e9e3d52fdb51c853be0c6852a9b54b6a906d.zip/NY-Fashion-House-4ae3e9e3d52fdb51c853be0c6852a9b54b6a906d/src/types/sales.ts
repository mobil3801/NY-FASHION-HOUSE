
export interface SaleItem {
  id: string;
  productId: string;
  productName: string;
  productSku: string;
  sellingPrice: number;
  quantity: number;
  size?: string;
  color?: string;
  discount: number;
  total: number;
}

export interface Sale {
  id: string;
  customerId?: string;
  customerName?: string;
  customerPhone?: string;
  items: SaleItem[];
  subtotal: number;
  discountAmount: number;
  discountPercentage: number;
  taxAmount: number;
  taxPercentage: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentDetails?: PaymentDetails;
  status: 'pending' | 'completed' | 'cancelled' | 'refunded';
  createdAt: Date;
  completedAt?: Date;
  cashierId: string;
  notes?: string;
  receiptNumber: string;
}

export interface PaymentMethod {
  type: 'cash' | 'card' | 'mobile-banking' | 'digital-wallet' | 'mixed';
  label: string;
}

export interface PaymentDetails {
  cashReceived?: number;
  changeGiven?: number;
  cardType?: string;
  cardLastFour?: string;
  transactionId?: string;
  mobileProvider?: string;
  mobileNumber?: string;
  digitalWalletProvider?: string;
  digitalWalletId?: string;
}

export interface TaxConfig {
  id: string;
  name: string;
  percentage: number;
  isDefault: boolean;
  applicableCategories?: string[];
}

export interface DiscountConfig {
  type: 'percentage' | 'fixed';
  value: number;
  minAmount?: number;
  maxDiscount?: number;
}

export interface CartItem extends SaleItem {
  product: {
    id: string;
    name: string;
    sku: string;
    sellingPrice: number;
    stockLevel: number;
    sizes: string[];
    colors: string[];
    images: string[];
  };
}

export interface POSSettings {
  taxPercentage: number;
  defaultPaymentMethod: string;
  requireCustomer: boolean;
  autoGenerateReceipt: boolean;
  printReceipt: boolean;
  currency: string;
  language: 'en' | 'bn';
}