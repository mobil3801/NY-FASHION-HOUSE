
export interface ReportFilter {
  startDate: Date;
  endDate: Date;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  customerId?: string;
  productId?: string;
  employeeId?: string;
}

export interface SalesReport {
  period: string;
  totalSales: number;
  totalOrders: number;
  averageOrderValue: number;
  topProducts: Array<{
    id: string;
    name: string;
    quantity: number;
    revenue: number;
  }>;
  salesByDay: Array<{
    date: string;
    sales: number;
    orders: number;
  }>;
}

export interface InventoryReport {
  totalProducts: number;
  totalStockValue: number;
  lowStockItems: Array<{
    id: string;
    name: string;
    currentStock: number;
    minStock: number;
  }>;
  fastMovingItems: Array<{
    id: string;
    name: string;
    salesVelocity: number;
    revenue: number;
  }>;
  deadStockItems: Array<{
    id: string;
    name: string;
    daysWithoutSale: number;
    stockValue: number;
  }>;
  stockByCategory: Array<{
    category: string;
    quantity: number;
    value: number;
  }>;
}

export interface CustomerAnalytics {
  totalCustomers: number;
  activeCustomers: number;
  newCustomers: number;
  topCustomers: Array<{
    id: string;
    name: string;
    totalSpent: number;
    orderCount: number;
    lastPurchase: Date;
  }>;
  customersBySegment: Array<{
    segment: string;
    count: number;
    revenue: number;
  }>;
  purchasePatterns: Array<{
    hour: number;
    orders: number;
  }>;
}

export interface EmployeePerformanceReport {
  employeeId: string;
  name: string;
  salesCount: number;
  revenue: number;
  avgOrderValue: number;
  customersSserved: number;
  workingHours: number;
  efficiency: number;
  targets: {
    salesTarget: number;
    salesAchieved: number;
    revenueTarget: number;
    revenueAchieved: number;
  };
}

export interface FinancialSummary {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  grossMargin: number;
  operatingMargin: number;
  revenueByMonth: Array<{
    month: string;
    revenue: number;
    expenses: number;
    profit: number;
  }>;
  expenseBreakdown: Array<{
    category: string;
    amount: number;
    percentage: number;
  }>;
}

export interface ReportExportOptions {
  format: 'pdf' | 'excel';
  includeCharts: boolean;
  language: 'en' | 'bn';
}

export interface AutoReportSchedule {
  id: string;
  name: string;
  reportType: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  recipients: string[];
  isActive: boolean;
  lastRun?: Date;
  nextRun: Date;
}