
export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  position: string;
  department: string;
  hireDate: string;
  salary: number;
  employmentStatus: 'active' | 'inactive' | 'terminated';
  roleId: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
    email: string;
  };
  photoUrl?: string;
  photoIdFileId?: number;
  photoIdType?: 'Passport' | 'Driving License' | 'National ID';
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface EmployeeRole {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  createdAt: string;
  updatedAt: string;
}

export interface Permission {
  id: string;
  name: string;
  description: string;
  module: string;
  action: 'create' | 'read' | 'update' | 'delete' | 'manage';
}

export interface Attendance {
  id: string;
  employeeId: string;
  date: string;
  clockIn: string;
  clockOut?: string;
  breakDuration: number; // in minutes
  totalHours: number;
  status: 'present' | 'absent' | 'late' | 'half-day' | 'overtime';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PerformanceNote {
  id: string;
  employeeId: string;
  type: 'achievement' | 'improvement' | 'disciplinary' | 'goal' | 'review';
  title: string;
  description: string;
  rating?: number; // 1-5 scale
  reviewDate: string;
  reviewerId: string;
  followUpDate?: string;
  status: 'open' | 'in-progress' | 'completed' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}

export interface EmployeeStats {
  totalEmployees: number;
  activeEmployees: number;
  newHiresThisMonth: number;
  departmentBreakdown: {[key: string]: number;};
  averageTenure: number;
  attendanceRate: number;
  performanceAverage: number;
}

export interface EmployeeSearchFilters {
  search: string;
  department: string;
  position: string;
  employmentStatus: string;
  roleId: string;
}