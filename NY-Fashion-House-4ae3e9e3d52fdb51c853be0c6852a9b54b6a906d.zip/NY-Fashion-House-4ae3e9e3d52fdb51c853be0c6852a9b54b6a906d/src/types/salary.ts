// Salary Management Types

export interface SalaryStructure {
  id: string;
  position: string;
  department: string;
  baseSalary: number;
  allowances: Allowance[];
  deductions: DeductionRule[];
  overtimeRate: number; // per hour
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Allowance {
  id: string;
  name: string;
  type: 'fixed' | 'percentage';
  amount: number;
  isActive: boolean;
}

export interface DeductionRule {
  id: string;
  name: string;
  type: 'fixed' | 'percentage' | 'tax';
  amount: number;
  isActive: boolean;
  taxBracket?: TaxBracket;
}

export interface TaxBracket {
  minIncome: number;
  maxIncome: number;
  rate: number;
}

export interface SalaryCalculation {
  id: string;
  employeeId: string;
  payPeriod: string; // YYYY-MM format
  bengaliMonth: string;
  bengaliYear: string;
  baseSalary: number;
  allowances: CalculatedAllowance[];
  overtime: OvertimeCalculation;
  deductions: CalculatedDeduction[];
  grossSalary: number;
  netSalary: number;
  status: 'draft' | 'calculated' | 'approved' | 'paid' | 'cancelled';
  calculatedAt: string;
  calculatedBy: string;
  approvedAt?: string;
  approvedBy?: string;
  paidAt?: string;
  notes?: string;
}

export interface CalculatedAllowance {
  id: string;
  name: string;
  type: 'fixed' | 'percentage';
  baseAmount: number;
  calculatedAmount: number;
}

export interface CalculatedDeduction {
  id: string;
  name: string;
  type: 'fixed' | 'percentage' | 'tax';
  baseAmount: number;
  calculatedAmount: number;
  taxDetails?: {
    taxableIncome: number;
    taxRate: number;
  };
}

export interface OvertimeCalculation {
  regularHours: number;
  overtimeHours: number;
  overtimeRate: number;
  overtimeAmount: number;
}

export interface Advance {
  id: string;
  employeeId: string;
  amount: number;
  reason: string;
  requestDate: string;
  approvalStatus: 'pending' | 'approved' | 'rejected';
  approvedBy?: string;
  approvedAt?: string;
  deductionSchedule: AdvanceDeductionSchedule[];
  totalDeducted: number;
  remainingBalance: number;
  isFullyPaid: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AdvanceDeductionSchedule {
  payPeriod: string;
  amount: number;
  isDeducted: boolean;
  deductedAt?: string;
}

export interface PaymentRecord {
  id: string;
  employeeId: string;
  salaryCalculationId: string;
  payPeriod: string;
  amount: number;
  paymentMethod: 'cash' | 'bank_transfer' | 'cheque';
  paymentDate: string;
  bankDetails?: {
    accountNumber: string;
    bankName: string;
    branchCode: string;
  };
  chequeDetails?: {
    chequeNumber: string;
    bankName: string;
  };
  transactionId?: string;
  paidBy: string;
  notes?: string;
  createdAt: string;
}

export interface SalarySlip {
  id: string;
  employeeId: string;
  employee: {
    firstName: string;
    lastName: string;
    employeeCode: string;
    position: string;
    department: string;
  };
  salaryCalculation: SalaryCalculation;
  paymentRecord?: PaymentRecord;
  generatedAt: string;
  generatedBy: string;
}

export interface BulkSalaryProcess {
  id: string;
  payPeriod: string;
  bengaliMonth: string;
  bengaliYear: string;
  employeeIds: string[];
  totalEmployees: number;
  processedEmployees: number;
  failedEmployees: FailedEmployee[];
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  startedAt: string;
  startedBy: string;
  completedAt?: string;
  notes?: string;
}

export interface FailedEmployee {
  employeeId: string;
  employeeName: string;
  error: string;
}

export interface SalaryReport {
  id: string;
  type: 'monthly' | 'departmental' | 'yearly' | 'tax' | 'advance' | 'overtime';
  title: string;
  description: string;
  parameters: ReportParameters;
  data: any;
  generatedAt: string;
  generatedBy: string;
}

export interface ReportParameters {
  payPeriod?: string;
  startDate?: string;
  endDate?: string;
  department?: string;
  employeeIds?: string[];
  includeAdvances?: boolean;
  includeOvertime?: boolean;
}

export interface BengaliDate {
  bengaliDay: number;
  bengaliMonth: number;
  bengaliYear: number;
  bengaliMonthName: string;
  englishDate: Date;
}

export interface PayPeriod {
  id: string;
  startDate: string;
  endDate: string;
  payPeriod: string; // YYYY-MM format
  bengaliMonth: string;
  bengaliYear: string;
  isActive: boolean;
  paymentDueDate: string;
}

export interface SalaryStats {
  totalPayroll: number;
  totalEmployees: number;
  averageSalary: number;
  totalOvertime: number;
  totalAdvances: number;
  departmentBreakdown: {[key: string]: number;};
  monthlyTrend: MonthlyPayrollData[];
}

export interface MonthlyPayrollData {
  month: string;
  totalPayroll: number;
  totalEmployees: number;
  averageSalary: number;
}

export interface SalarySearchFilters {
  search: string;
  department: string;
  payPeriod: string;
  status: string;
  minSalary: number;
  maxSalary: number;
}