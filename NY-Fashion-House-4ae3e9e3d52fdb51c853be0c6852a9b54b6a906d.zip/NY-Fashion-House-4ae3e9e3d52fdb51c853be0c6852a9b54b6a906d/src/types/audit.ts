export interface AuditLog {
  id: number;
  user_id: number;
  user_name: string;
  user_email: string;
  action: string;
  table_name: string;
  record_id: string;
  old_values: string;
  new_values: string;
  ip_address: string;
  user_agent: string;
  timestamp: string;
  session_id: string;
  is_security_event: boolean;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  event_description: string;
  metadata: string;
}

export interface AuditLogFilters {
  user_id?: number;
  user_name?: string;
  user_email?: string;
  action?: string;
  table_name?: string;
  start_date?: string;
  end_date?: string;
  ip_address?: string;
  is_security_event?: boolean;
  severity?: string;
}

export interface SecurityEvent {
  type: string;
  description: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  metadata?: Record<string, any>;
}

export interface AuditStats {
  total_logs: number;
  security_events: number;
  failed_logins: number;
  data_modifications: number;
  unique_users: number;
  recent_activity_count: number;
  critical_events: number;
}

export interface AuditLogRetentionSettings {
  retention_days: number;
}