
export interface Role {
  id: number;
  name: string;
  code: string;
  remark?: string;
  create_time: string;
  userCount?: number;
}

export interface Permission {
  id: number;
  name: string;
  code: string;
  category: string;
  description?: string;
}

export interface RolePermission {
  id: number;
  role_id: number;
  permission_id: number;
  granted_at: string;
  granted_by: string;
}

export interface RoleFormData {
  name: string;
  remark?: string;
  permissions: number[];
}

export interface RoleSearchFilters {
  search?: string;
  sortBy?: 'name' | 'code' | 'create_time' | 'userCount';
  sortOrder?: 'asc' | 'desc';
  userCountMin?: number;
  userCountMax?: number;
  dateFrom?: string;
  dateTo?: string;
}

export interface RoleStats {
  totalRoles: number;
  totalUsers: number;
  activeRoles: number;
  roleUsageDistribution: {
    roleName: string;
    userCount: number;
    percentage: number;
  }[];
}

export interface PermissionMatrix {
  roleId: number;
  roleName: string;
  permissions: {
    [category: string]: {
      [permissionCode: string]: boolean;
    };
  };
}