
export interface Account {
  id: string;
  code: string;
  name: string;
  type: AccountType;
  parentId?: string;
  description?: string;
  isActive: boolean;
  balance: number;
  createdAt: string;
  updatedAt: string;
}

export enum AccountType {
  ASSET = 'asset',
  LIABILITY = 'liability',
  EQUITY = 'equity',
  REVENUE = 'revenue', // Updated to REVENUE per USA GAAP
  EXPENSE = 'expense',
  // Keep INCOME for backward compatibility
  INCOME = 'revenue',
}

export interface JournalEntry {
  id: string;
  date: string;
  reference: string;
  description: string;
  totalAmount: number;
  entries: TransactionEntry[];
  source: TransactionSource;
  sourceId?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface TransactionEntry {
  id: string;
  journalEntryId: string;
  accountId: string;
  account?: Account;
  debitAmount: number;
  creditAmount: number;
  description: string;
}

export enum TransactionSource {
  MANUAL = 'manual',
  SALES = 'sales',
  PAYROLL = 'payroll', // Updated from SALARY to PAYROLL (USA standard)
  PURCHASE = 'purchase',
  EXPENSE = 'expense',
  PAYMENT = 'payment',
  CASH_RECEIPT = 'cash_receipt',
  BANK_DEPOSIT = 'bank_deposit',
  DEPRECIATION = 'depreciation',
}

export interface FinancialReport {
  id: string;
  type: ReportType;
  period: ReportPeriod;
  startDate: string;
  endDate: string;
  data: ReportData;
  generatedAt: string;
}

export enum ReportType {
  INCOME_STATEMENT = 'income_statement', // Updated from PROFIT_LOSS to INCOME_STATEMENT (USA GAAP)
  BALANCE_SHEET = 'balance_sheet',
  STATEMENT_OF_CASH_FLOWS = 'statement_of_cash_flows', // Updated from CASH_FLOW
  TRIAL_BALANCE = 'trial_balance',
  STATEMENT_OF_EQUITY = 'statement_of_equity' // Added for USA GAAP
  ,}

export interface ReportPeriod {
  type: 'monthly' | 'quarterly' | 'yearly' | 'custom';
  year: number;
  month?: number;
  quarter?: number;
}

export interface ReportData {
  [key: string]: any;
}

export interface IncomeStatementData extends ReportData {
  revenue: AccountBalance[];
  costOfGoodsSold: AccountBalance[];
  operatingExpenses: AccountBalance[];
  otherIncomeExpense: AccountBalance[];
  grossProfit: number;
  operatingIncome: number;
  netIncome: number; // Updated from netProfit to netIncome
  earningsPerShare?: number; // Added for USA GAAP
}

export interface BalanceSheetData extends ReportData {
  currentAssets: AccountBalance[];
  nonCurrentAssets: AccountBalance[];
  currentLiabilities: AccountBalance[];
  nonCurrentLiabilities: AccountBalance[];
  shareholdersEquity: AccountBalance[]; // Updated terminology
  totalAssets: number;
  totalLiabilities: number;
  totalShareholdersEquity: number;
}

export interface StatementOfCashFlowsData extends ReportData {
  operatingActivities: CashFlowItem[];
  investingActivities: CashFlowItem[];
  financingActivities: CashFlowItem[];
  netCashFlow: number;
  beginningCashBalance: number;
  endingCashBalance: number;
}

export interface AccountBalance {
  accountId: string;
  accountName: string;
  accountCode: string;
  balance: number;
  subAccounts?: AccountBalance[];
}

export interface CashFlowItem {
  description: string;
  amount: number;
  type: 'inflow' | 'outflow';
}

export interface TransactionSearchFilters {
  startDate?: string;
  endDate?: string;
  accountId?: string;
  source?: TransactionSource;
  reference?: string;
  description?: string;
  minAmount?: number;
  maxAmount?: number;
}

// USA GAAP specific account codes and structure
export const USA_GAAP_ACCOUNT_CODES = {
  // Assets (100-199)
  CURRENT_ASSETS: '100-199',
  CASH_AND_CASH_EQUIVALENTS: '101',
  ACCOUNTS_RECEIVABLE: '120',
  INVENTORY: '130',
  PREPAID_EXPENSES: '140',

  // Non-Current Assets (200-299)
  NON_CURRENT_ASSETS: '200-299',
  PROPERTY_PLANT_EQUIPMENT: '200',
  ACCUMULATED_DEPRECIATION: '201',

  // Liabilities (300-399)
  CURRENT_LIABILITIES: '300-349',
  ACCOUNTS_PAYABLE: '300',
  ACCRUED_LIABILITIES: '310',
  SHORT_TERM_DEBT: '320',

  // Non-Current Liabilities (350-399)
  LONG_TERM_DEBT: '350',

  // Stockholders' Equity (400-499)
  COMMON_STOCK: '400',
  RETAINED_EARNINGS: '410',
  ADDITIONAL_PAID_IN_CAPITAL: '420',

  // Revenue (500-599)
  SALES_REVENUE: '500',
  SERVICE_REVENUE: '510',

  // Cost of Goods Sold (600-699)
  COST_OF_GOODS_SOLD: '600',

  // Operating Expenses (700-899)
  SELLING_EXPENSES: '700',
  ADMINISTRATIVE_EXPENSES: '800',

  // Other Income/Expense (900-999)
  INTEREST_INCOME: '900',
  INTEREST_EXPENSE: '910'
};