
export interface Invoice {
  id: string;
  invoiceNumber: string;
  saleId?: string; // Reference to sale if generated from POS
  customerId: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  customerAddress?: string;

  // Invoice details
  issueDate: Date;
  dueDate: Date;

  // Items
  items: InvoiceItem[];

  // Amounts
  subtotal: number;
  discountAmount: number;
  discountPercentage: number;
  taxAmount: number;
  taxPercentage: number;
  totalAmount: number;

  // Status and payments
  status: 'draft' | 'sent' | 'viewed' | 'paid' | 'overdue' | 'cancelled';
  paidAmount: number;
  remainingAmount: number;

  // Metadata
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;

  // Additional fields
  notes?: string;
  terms?: string;
  footerText?: string;
}

export interface InvoiceItem {
  id: string;
  productId?: string;
  productName: string;
  productSku?: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  total: number;
  size?: string;
  color?: string;
}

export interface InvoicePayment {
  id: string;
  invoiceId: string;
  amount: number;
  paymentDate: Date;
  paymentMethod: 'cash' | 'card' | 'mobile-banking' | 'digital-wallet' | 'bank-transfer' | 'check';
  paymentDetails?: {
    transactionId?: string;
    checkNumber?: string;
    bankName?: string;
    accountNumber?: string;
  };
  notes?: string;
  recordedBy: string;
  recordedAt: Date;
}

export interface InvoiceTemplate {
  id: string;
  name: string;
  isDefault: boolean;

  // Company/Store information
  companyName: string;
  companyLogo?: string;
  companyAddress: string;
  companyPhone: string;
  companyEmail: string;
  companyWebsite?: string;
  taxId?: string;

  // Design settings
  primaryColor: string;
  secondaryColor: string;
  fontFamily: string;

  // Content settings
  includeItemDescription: boolean;
  includeItemSku: boolean;
  includeDiscounts: boolean;
  includeTax: boolean;

  // Terms and footer
  defaultTerms: string;
  defaultFooter: string;
  defaultDueDays: number;
}

export interface InvoiceFilters {
  customerId?: string;
  status?: Invoice['status'];
  dateFrom?: Date;
  dateTo?: Date;
  dueDateFrom?: Date;
  dueDateTo?: Date;
  amountMin?: number;
  amountMax?: number;
  searchQuery?: string;
}

export interface InvoiceStats {
  totalInvoices: number;
  totalAmount: number;
  paidAmount: number;
  pendingAmount: number;
  overdueAmount: number;
  draftCount: number;
  paidCount: number;
  overdueCount: number;
  pendingCount: number;
}