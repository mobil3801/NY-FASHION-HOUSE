// Enhanced error types for comprehensive error reporting
export interface ErrorContext {
  // What happened
  description?: string;
  title?: string;

  // Action that triggered the error
  action?: string;
  operation?: string;

  // Technical details
  stack?: string;
  componentStack?: string;

  // Request/Input context
  requestDetails?: {
    url?: string;
    method?: string;
    params?: any;
    headers?: any;
    body?: any;
  };
  userInputs?: any;
  formData?: any;

  // User context
  userId?: string;
  userRole?: string;
  sessionId?: string;

  // System context
  service?: string;
  component?: string;
  route?: string;
  userAgent?: string;
  timestamp?: string;

  // Error classification
  severity?: 'low' | 'medium' | 'high' | 'critical';
  category?: 'network' | 'validation' | 'authentication' | 'authorization' | 'server' | 'client' | 'unknown';

  // Additional metadata
  additionalData?: any;
  environment?: string;
  buildVersion?: string;
}

export interface EnhancedError extends Error {
  context?: ErrorContext;
  correlationId?: string;
  rootCause?: string;
  remediation?: string[];
  isRecoverable?: boolean;
}

export interface ErrorReport {
  // Core information
  correlationId: string;
  timestamp: string;

  // What happened
  title: string;
  description: string;

  // Root cause analysis
  rootCause: string;
  category: ErrorContext['category'];

  // Technical details
  errorMessage: string;
  stack?: string;
  componentStack?: string;

  // Context
  action: string;
  context: ErrorContext;

  // Remediation
  remediation: string[];
  isRecoverable: boolean;

  // Severity
  severity: ErrorContext['severity'];
}

export interface ErrorAnalysis {
  possibleCauses: string[];
  rootCause: string;
  category: ErrorContext['category'];
  remediation: string[];
  isRecoverable: boolean;
}