export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  notes?: string;
  createdAt: string;
  lastPurchase?: string;
  totalPurchases: number;
  totalSpent: number;
  status: 'active' | 'inactive';
}

export interface Purchase {
  id: string;
  customerId: string;
  amount: number;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'cancelled';
}

export interface CustomerFilters {
  search: string;
  status: 'all' | 'active' | 'inactive';
  sortBy: 'name' | 'email' | 'totalSpent' | 'createdAt';
  sortOrder: 'asc' | 'desc';
}