
export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: {
    street: string;
    city: string;
    state: string;
    pincode: string;
    country: string;
  };
  gstNumber?: string;
  panNumber?: string;
  bankDetails?: {
    accountNumber: string;
    ifscCode: string;
    bankName: string;
    accountHolderName: string;
  };
  paymentTerms: string;
  categories: string[];
  isActive: boolean;
  rating: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface SupplierOrder {
  id: string;
  supplierId: string;
  orderNumber: string;
  orderDate: Date;
  expectedDeliveryDate: Date;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  items: {
    productId: string;
    quantity: number;
    unitPrice: number;
    totalPrice: number;
  }[];
  totalAmount: number;
  notes?: string;
}