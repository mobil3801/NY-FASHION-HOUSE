
export interface User {
  id: number;
  name: string;
  email: string;
  phone_number: string;
  is_activated: boolean;
  role_id: number | null;
  role_name: string;
  role_code: string;
  create_time: string;
}

export interface Role {
  id: number;
  name: string;
  code: string;
  remark?: string;
}

export interface UserFormData {
  name: string;
  email: string;
  phoneNumber: string;
  roleId?: number;
  isActivated: boolean;
  password?: string;
}

export interface UserSearchFilters {
  search?: string;
  roleId?: number;
  isActivated?: boolean;
  dateFrom?: string;
  dateTo?: string;
}