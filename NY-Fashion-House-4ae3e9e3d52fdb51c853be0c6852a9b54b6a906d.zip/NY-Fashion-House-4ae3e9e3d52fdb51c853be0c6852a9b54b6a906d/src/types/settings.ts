
export interface SystemSetting {
  id?: number;
  setting_key: string;
  setting_value: string;
  description: string;
  category: string;
  data_type: 'string' | 'number' | 'boolean' | 'select' | 'json';
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
  options?: string[]; // For select type settings
}

export interface SettingsCategory {
  key: string;
  name: string;
  description: string;
  icon: string;
}

export interface SettingsValidation {
  required?: boolean;
  min?: number;
  max?: number;
  pattern?: string;
  options?: string[];
}

export interface SettingsExport {
  version: string;
  exported_at: string;
  settings: SystemSetting[];
}