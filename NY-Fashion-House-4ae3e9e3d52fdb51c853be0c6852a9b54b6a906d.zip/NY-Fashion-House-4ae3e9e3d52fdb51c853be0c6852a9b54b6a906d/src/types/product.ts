
export interface Product {
  id: string;
  sku: string; // Unique 9-11 digit numeric SKU auto-generated on creation
  name: string;
  description: string;
  category: ProductCategory;
  costPrice: number;
  sellingPrice: number;
  images: string[];
  imageIds: number[];
  sizes: string[];
  colors: string[];
  stockLevel: number;
  minStockLevel: number;
  supplierId: string;
  barcode: string;
  createdAt: Date;
  updatedAt: Date;
  isActive: boolean;
}

export interface ProductVariant {
  id: string;
  productId: string;
  size: string;
  color: string;
  sku: string;
  stockLevel: number;
  additionalPrice: number;
}

export interface StockAdjustment {
  id: string;
  productId: string;
  variantId?: string;
  type: 'in' | 'out' | 'adjustment';
  quantity: number;
  reason: string;
  performedBy: string;
  date: Date;
  notes?: string;
}

export interface LowStockAlert {
  id: string;
  productId: string;
  productName: string;
  currentStock: number;
  minStockLevel: number;
  createdAt: Date;
  isResolved: boolean;
}

export type ProductCategory =
'Jamdani Saree' |
'Katan' |
'Silk' |
'Muslin' |
'Tangail' |
'Cotton' |
'Half-Silk' |
'Linen' |
'Organza' |
'Georgette' |
'Chiffon' |
'Salwar Kameez/Three-Piece' |
'Kurti/Tunic' |
'Lehenga/Bridal' |
'Abaya' |
'Hijab/Scarf/Khimar' |
'Orna/Dupatta' |
'Blouse' |
'Petticoat' |
'Palazzo/Pant' |
'Skirt' |
'Shawl/Stole' |
'Winterwear' |
'Nightwear' |
'Maternity' |
'Kids (Girls)' |
'Accessories' |
'Tailoring';

export interface ProductFilters {
  category?: ProductCategory;
  size?: string;
  color?: string;
  priceRange?: [number, number];
  inStock?: boolean;
  lowStock?: boolean;
  supplier?: string;
}

export interface ProductSearchParams extends ProductFilters {
  query?: string;
  sortBy?: 'name' | 'price' | 'stock' | 'category' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
}