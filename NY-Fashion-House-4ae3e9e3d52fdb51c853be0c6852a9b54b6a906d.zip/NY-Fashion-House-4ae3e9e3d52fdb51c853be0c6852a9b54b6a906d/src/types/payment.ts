
export interface PaymentRecord {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  amount: number;
  paymentDate: Date;
  paymentMethod: PaymentMethodType;
  paymentDetails?: PaymentMethodDetails;
  notes?: string;
  recordedBy: string;
  recordedAt: Date;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
}

export type PaymentMethodType =
'cash' |
'card' |
'mobile-banking' |
'digital-wallet' |
'bank-transfer' |
'check' |
'other';

export interface PaymentMethodDetails {
  // Card payments
  cardType?: string;
  cardLastFour?: string;
  transactionId?: string;

  // Mobile banking
  mobileProvider?: string;
  mobileNumber?: string;

  // Digital wallet
  walletProvider?: string;
  walletId?: string;

  // Bank transfer
  bankName?: string;
  accountNumber?: string;
  routingNumber?: string;

  // Check
  checkNumber?: string;
  checkDate?: Date;

  // Other
  description?: string;
}

export interface PaymentMethodOption {
  type: PaymentMethodType;
  label: string;
  icon?: string;
  requiresDetails?: boolean;
}