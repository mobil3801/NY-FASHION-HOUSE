import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';

interface SalesUser {
  id: string;
  email: string;
  name: string;
  role: string;
  isActive: boolean;
}

interface SalesAuthContextType {
  user: SalesUser | null;
  isLoading: boolean;
  error: string | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{success: boolean;error?: string;}>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

const SalesAuthContext = createContext<SalesAuthContextType | undefined>(undefined);

export const useSalesAuth = () => {
  const context = useContext(SalesAuthContext);
  if (!context) {
    throw new Error('useSalesAuth must be used within a SalesAuthProvider');
  }
  return context;
};

interface SalesAuthProviderProps {
  children: ReactNode;
}

export const SalesAuthProvider = ({ children }: SalesAuthProviderProps) => {
  const [user, setUser] = useState<SalesUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const login = async (email: string, password: string): Promise<{success: boolean;error?: string;}> => {
    try {
      setIsLoading(true);
      setError(null);

      // Use the main authentication system
      const { error: loginError } = await window.ezsite.apis.login({
        email,
        password
      });

      if (loginError) {
        setError(loginError);
        return { success: false, error: loginError };
      }

      // Get user info after successful login
      const { data: userInfo, error: userError } = await window.ezsite.apis.getUserInfo();

      if (userError) {
        setError(userError);
        return { success: false, error: userError };
      }

      if (!userInfo) {
        const errorMessage = 'Failed to retrieve user information';
        setError(errorMessage);
        return { success: false, error: errorMessage };
      }

      // Check if user has sales role
      const roles = userInfo.Roles || '';
      const hasSalesRole = roles.includes('r-WzDn7C') || roles.includes('Sales') || roles.includes('Administrator');

      if (!hasSalesRole) {
        await window.ezsite.apis.logout();
        const errorMessage = 'Access denied: Sales role required';
        setError(errorMessage);
        return { success: false, error: errorMessage };
      }

      setUser({
        id: userInfo.ID?.toString() || '',
        email: userInfo.Email || email,
        name: userInfo.Name || 'Sales User',
        role: roles.includes('Administrator') ? 'Administrator' : 'Sales',
        isActive: true
      });

      return { success: true };

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Login failed';
      setError(errorMessage);
      return { success: false, error: errorMessage };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await window.ezsite.apis.logout();
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      setUser(null);
      setError(null);
    }
  };

  const checkAuth = async (): Promise<void> => {
    try {
      setIsLoading(true);
      setError(null);

      const { data: userInfo, error: userError } = await window.ezsite.apis.getUserInfo();

      if (userError || !userInfo) {
        setUser(null);
        return;
      }

      // Check if user has sales role
      const roles = userInfo.Roles || '';
      const hasSalesRole = roles.includes('r-WzDn7C') || roles.includes('Sales') || roles.includes('Administrator');

      if (!hasSalesRole) {
        setUser(null);
        return;
      }

      setUser({
        id: userInfo.ID?.toString() || '',
        email: userInfo.Email || '',
        name: userInfo.Name || 'Sales User',
        role: roles.includes('Administrator') ? 'Administrator' : 'Sales',
        isActive: true
      });

    } catch (err) {
      console.error('Auth check failed:', err);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const contextValue: SalesAuthContextType = {
    user,
    isLoading,
    error,
    isAuthenticated: !!user,
    login,
    logout,
    checkAuth
  };

  return (
    <SalesAuthContext.Provider value={contextValue}>
      {children}
    </SalesAuthContext.Provider>);

};

export default SalesAuthProvider;