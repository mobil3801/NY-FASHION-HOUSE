# Comprehensive API Documentation

## Overview
This documentation provides a detailed guide to the API endpoints across various services in our application. Each service is documented with its endpoints, request/response formats, parameters, data types, error handling, and usage examples.

## Authentication
All API endpoints require authentication unless explicitly noted. Authentication is managed through JWT tokens passed in the Authorization header.

## Services and Endpoints

### 1. Customer Service (`customerService.ts`)
#### Endpoints:
- `GET /customers`
  - Description: Retrieve all customers
  - Parameters: 
    - `page` (optional): Pagination page number
    - `limit` (optional): Number of results per page
  - Response: Array of Customer objects
  - Status Codes: 
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

- `POST /customers`
  - Description: Create a new customer
  - Request Body: Customer object
  - Response: Created customer with ID
  - Status Codes:
    - 201: Customer created successfully
    - 400: Invalid input
    - 401: Unauthorized

- `GET /customers/{id}`
  - Description: Retrieve specific customer by ID
  - Response: Detailed customer object
  - Status Codes:
    - 200: Customer found
    - 404: Customer not found
    - 401: Unauthorized

### 2. Product Service (`productService.ts`)
#### Endpoints:
- `GET /products`
  - Description: Retrieve all products
  - Parameters:
    - `category` (optional): Filter by product category
    - `inStock` (optional): Filter by stock availability
  - Response: Array of Product objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

- `POST /products`
  - Description: Create a new product
  - Request Body: Product object
  - Response: Created product with ID
  - Status Codes:
    - 201: Product created successfully
    - 400: Invalid input
    - 401: Unauthorized

### 3. Supplier Service (`supplierService.ts`)
#### Endpoints:
- `GET /suppliers`
  - Description: Retrieve all suppliers
  - Response: Array of Supplier objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

- `POST /suppliers`
  - Description: Create a new supplier
  - Request Body: Supplier object
  - Response: Created supplier with ID
  - Status Codes:
    - 201: Supplier created successfully
    - 400: Invalid input
    - 401: Unauthorized

### 4. Sales Service (`salesService.ts`)
#### Endpoints:
- `GET /sales`
  - Description: Retrieve sales records
  - Parameters:
    - `startDate` (optional): Filter sales from a specific date
    - `endDate` (optional): Filter sales to a specific date
  - Response: Array of Sales objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

- `POST /sales`
  - Description: Create a new sales record
  - Request Body: Sales object
  - Response: Created sales record with ID
  - Status Codes:
    - 201: Sales record created successfully
    - 400: Invalid input
    - 401: Unauthorized

### 5. Invoice Service (`invoiceService.ts`)
#### Endpoints:
- `GET /invoices`
  - Description: Retrieve all invoices
  - Parameters:
    - `status` (optional): Filter by invoice status
  - Response: Array of Invoice objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

- `POST /invoices`
  - Description: Create a new invoice
  - Request Body: Invoice object
  - Response: Created invoice with ID
  - Status Codes:
    - 201: Invoice created successfully
    - 400: Invalid input
    - 401: Unauthorized

### 6. Employee Service (`employeeService.ts`)
#### Endpoints:
- `GET /employees`
  - Description: Retrieve all employees
  - Parameters:
    - `department` (optional): Filter by department
  - Response: Array of Employee objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

- `POST /employees`
  - Description: Create a new employee
  - Request Body: Employee object
  - Response: Created employee with ID
  - Status Codes:
    - 201: Employee created successfully
    - 400: Invalid input
    - 401: Unauthorized

### 7. Salary Service (`salaryService.ts`)
#### Endpoints:
- `GET /salaries`
  - Description: Retrieve salary records
  - Parameters:
    - `employeeId` (optional): Filter by specific employee
    - `month` (optional): Filter by specific month
  - Response: Array of Salary objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

### 8. Accounting Service (`accountingService.ts`)
#### Endpoints:
- `GET /accounting/financial-reports`
  - Description: Retrieve financial reports
  - Parameters:
    - `reportType` (optional): Specific type of financial report
  - Response: Financial report object
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

### 9. Report Service (`reportService.ts`)
#### Endpoints:
- `GET /reports`
  - Description: Generate various business reports
  - Parameters:
    - `type`: Type of report (sales, inventory, performance)
  - Response: Detailed report object
  - Status Codes:
    - 200: Report generated successfully
    - 400: Invalid report type
    - 401: Unauthorized

### 10. Audit Service (`auditService.ts`)
#### Endpoints:
- `GET /audit-logs`
  - Description: Retrieve system audit logs
  - Parameters:
    - `startDate` (optional): Filter logs from a specific date
    - `endDate` (optional): Filter logs to a specific date
  - Response: Array of Audit Log objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

### 11. User Service (`userService.ts`)
#### Endpoints:
- `POST /users/login`
  - Description: User authentication
  - Request Body: 
    - `username`: User's username
    - `password`: User's password
  - Response: JWT token and user details
  - Status Codes:
    - 200: Login successful
    - 401: Invalid credentials
    - 400: Bad request

- `POST /users/register`
  - Description: User registration
  - Request Body: User registration details
  - Response: Created user profile
  - Status Codes:
    - 201: User registered successfully
    - 400: Invalid registration details
    - 409: User already exists

### 12. Role Service (`roleService.ts`)
#### Endpoints:
- `GET /roles`
  - Description: Retrieve all system roles
  - Response: Array of Role objects
  - Status Codes:
    - 200: Successful retrieval
    - 401: Unauthorized
    - 500: Server error

## Error Handling
All endpoints follow a consistent error response format:
```json
{
  "error": true,
  "message": "Detailed error description",
  "code": "ERROR_CODE"
}
```

## Integration Examples
### Using Fetch API
```typescript
// Example of fetching customers
async function fetchCustomers() {
  try {
    const response = await fetch('/api/customers', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch customers');
    }
    
    const customers = await response.json();
    return customers;
  } catch (error) {
    console.error('Error fetching customers:', error);
  }
}
```

## Best Practices
1. Always include authentication token
2. Handle errors gracefully
3. Use appropriate HTTP methods
4. Validate input data before sending requests

## Versioning
Current API Version: v1.0
Base URL: `/api/v1`

## Rate Limiting
- Maximum 100 requests per minute per endpoint
- Exceeding limit results in 429 (Too Many Requests) status

## Notes
- Documentation is auto-generated and may be periodically updated
- For the most recent information, always refer to the latest documentation
