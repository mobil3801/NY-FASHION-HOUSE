
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Minus, RotateCcw, History } from 'lucide-react';
import { Product, StockAdjustment as StockAdjustmentType } from '@/types/product';
import { productService } from '@/services/productService';
import { toast } from 'sonner';

interface StockAdjustmentProps {
  product: Product;
  onStockUpdated: (updatedProduct: Product) => void;
}

interface StockAdjustmentHistory {
  adjustments: StockAdjustmentType[];
  loading: boolean;
}

const StockAdjustment: React.FC<StockAdjustmentProps> = ({
  product,
  onStockUpdated
}) => {
  const [isAdjustmentOpen, setIsAdjustmentOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [adjustmentType, setAdjustmentType] = useState<'in' | 'out' | 'adjustment'>('in');
  const [quantity, setQuantity] = useState<number>(0);
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<StockAdjustmentHistory>({
    adjustments: [],
    loading: false
  });

  const handleStockAdjustment = async () => {
    if (quantity <= 0) {
      toast.error('Please enter a valid quantity');
      return;
    }

    if (!reason.trim()) {
      toast.error('Please provide a reason for the adjustment');
      return;
    }

    setLoading(true);
    try {
      await productService.adjustStock({
        productId: product.id,
        type: adjustmentType,
        quantity,
        reason,
        notes,
        performedBy: 'Current User' // In a real app, this would be the logged-in user
      });

      // Get updated product
      const updatedProduct = await productService.getProductById(product.id);
      if (updatedProduct) {
        onStockUpdated(updatedProduct);
        toast.success('Stock adjusted successfully');
        setIsAdjustmentOpen(false);
        resetForm();
      }
    } catch (error) {
      toast.error('Failed to adjust stock. Please try again.');
      console.error('Error adjusting stock:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadHistory = async () => {
    setHistory((prev) => ({ ...prev, loading: true }));
    try {
      const adjustments = await productService.getStockAdjustments(product.id);
      setHistory({ adjustments, loading: false });
    } catch (error) {
      toast.error('Failed to load stock history');
      setHistory({ adjustments: [], loading: false });
    }
  };

  const resetForm = () => {
    setQuantity(0);
    setReason('');
    setNotes('');
    setAdjustmentType('in');
  };

  const getAdjustmentTypeIcon = (type: 'in' | 'out' | 'adjustment') => {
    switch (type) {
      case 'in':
        return <Plus className="w-4 h-4 text-green-600" />;
      case 'out':
        return <Minus className="w-4 h-4 text-red-600" />;
      case 'adjustment':
        return <RotateCcw className="w-4 h-4 text-blue-600" />;
    }
  };

  const getAdjustmentTypeColor = (type: 'in' | 'out' | 'adjustment') => {
    switch (type) {
      case 'in':
        return 'text-green-600 bg-green-50';
      case 'out':
        return 'text-red-600 bg-red-50';
      case 'adjustment':
        return 'text-blue-600 bg-blue-50';
    }
  };

  const reasonOptions = {
    in: [
    'Purchase received',
    'Return from customer',
    'Transfer from another location',
    'Production completed',
    'Initial stock entry'],

    out: [
    'Sale to customer',
    'Damage/wastage',
    'Transfer to another location',
    'Return to supplier',
    'Promotional giveaway'],

    adjustment: [
    'Inventory count correction',
    'System error correction',
    'Damaged goods write-off',
    'Expired goods removal',
    'Theft/loss']

  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Stock Management
          <div className="flex gap-2">
            <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" onClick={loadHistory}>
                  <History className="w-4 h-4 mr-1" />
                  History
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Stock Adjustment History - {product.name}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {history.loading ?
                  <div className="text-center py-8">Loading history...</div> :
                  history.adjustments.length === 0 ?
                  <div className="text-center py-8 text-gray-500">
                      No stock adjustments found
                    </div> :

                  <div className="space-y-2">
                      {history.adjustments.map((adjustment) =>
                    <div
                      key={adjustment.id}
                      className="flex items-center justify-between p-3 border rounded-lg">

                          <div className="flex items-center gap-3">
                            {getAdjustmentTypeIcon(adjustment.type)}
                            <div>
                              <p className="font-medium">
                                {adjustment.type === 'in' ? '+' : adjustment.type === 'out' ? '-' : '±'}
                                {adjustment.quantity} units
                              </p>
                              <p className="text-sm text-gray-600">{adjustment.reason}</p>
                              {adjustment.notes &&
                          <p className="text-xs text-gray-500">{adjustment.notes}</p>
                          }
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">
                              {adjustment.performedBy}
                            </p>
                            <p className="text-xs text-gray-500">
                              {adjustment.date.toLocaleString()}
                            </p>
                          </div>
                        </div>
                    )}
                    </div>
                  }
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isAdjustmentOpen} onOpenChange={setIsAdjustmentOpen}>
              <DialogTrigger asChild>
                <Button variant="default" size="sm">
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Adjust Stock
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Adjust Stock - {product.name}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center">
                      <span>Current Stock:</span>
                      <span className="font-bold text-lg">{product.stockLevel} units</span>
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-600">
                      <span>Minimum Stock:</span>
                      <span>{product.minStockLevel} units</span>
                    </div>
                  </div>

                  <div>
                    <Label>Adjustment Type</Label>
                    <Select
                      value={adjustmentType}
                      onValueChange={(value: 'in' | 'out' | 'adjustment') => {
                        setAdjustmentType(value);
                        setReason(''); // Reset reason when type changes
                      }}>

                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="in">
                          <div className="flex items-center gap-2">
                            <Plus className="w-4 h-4 text-green-600" />
                            Stock In (Add)
                          </div>
                        </SelectItem>
                        <SelectItem value="out">
                          <div className="flex items-center gap-2">
                            <Minus className="w-4 h-4 text-red-600" />
                            Stock Out (Remove)
                          </div>
                        </SelectItem>
                        <SelectItem value="adjustment">
                          <div className="flex items-center gap-2">
                            <RotateCcw className="w-4 h-4 text-blue-600" />
                            Adjustment (Correct)
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Quantity</Label>
                    <Input
                      type="number"
                      min="1"
                      value={quantity || ''}
                      onChange={(e) => setQuantity(Number(e.target.value))}
                      placeholder="Enter quantity" />

                  </div>

                  <div>
                    <Label>Reason</Label>
                    <Select value={reason} onValueChange={setReason}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a reason" />
                      </SelectTrigger>
                      <SelectContent>
                        {reasonOptions[adjustmentType].map((reasonOption) =>
                        <SelectItem key={reasonOption} value={reasonOption}>
                            {reasonOption}
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Notes (Optional)</Label>
                    <Textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Additional notes..."
                      rows={3} />

                  </div>

                  {quantity > 0 &&
                  <div className="p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm">
                        <strong>Preview:</strong> Stock will change from{' '}
                        <span className="font-bold">{product.stockLevel}</span> to{' '}
                        <span className="font-bold">
                          {adjustmentType === 'out' ?
                        Math.max(0, product.stockLevel - quantity) :
                        product.stockLevel + quantity
                        }
                        </span> units
                      </p>
                    </div>
                  }

                  <div className="flex gap-2 pt-4">
                    <Button
                      onClick={handleStockAdjustment}
                      disabled={loading || quantity <= 0 || !reason}
                      className="flex-1">

                      {loading ? 'Processing...' : 'Apply Adjustment'}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsAdjustmentOpen(false)}
                      className="flex-1">

                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold">{product.stockLevel}</p>
            <p className="text-sm text-gray-600">Current Stock</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold">{product.minStockLevel}</p>
            <p className="text-sm text-gray-600">Minimum Stock</p>
          </div>
        </div>

        {product.stockLevel <= product.minStockLevel &&
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                Low Stock Alert
              </Badge>
            </div>
            <p className="text-sm text-yellow-700 mt-1">
              Stock level is at or below the minimum threshold. Consider restocking soon.
            </p>
          </div>
        }

        {product.stockLevel === 0 &&
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center gap-2">
              <Badge variant="destructive">Out of Stock</Badge>
            </div>
            <p className="text-sm text-red-700 mt-1">
              This product is currently out of stock and unavailable for sale.
            </p>
          </div>
        }
      </CardContent>
    </Card>);

};

export default StockAdjustment;