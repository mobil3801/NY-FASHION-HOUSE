
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Globe, Chrome, Monitor, Smartphone,
  AlertTriangle, CheckCircle, XCircle, Clock,
  Shield, Zap, Bug, Brain,
  Activity, TrendingUp, TrendingDown,
  RefreshCw, Play, Pause } from
'lucide-react';
import {
  crossBrowserErrorTestService,
  CrossBrowserErrorReport,
  ErrorTestResult,
  BrowserTestEnvironment,
  ErrorScenario } from
'@/services/crossBrowserErrorTestService';
import { toast } from 'sonner';

interface TestExecutionState {
  isRunning: boolean;
  currentBrowser: string;
  currentScenario: string;
  progress: number;
  startTime?: Date;
}

const CrossBrowserErrorTestDashboard: React.FC = () => {
  const [report, setReport] = useState<CrossBrowserErrorReport | null>(null);
  const [executionState, setExecutionState] = useState<TestExecutionState>({
    isRunning: false,
    currentBrowser: '',
    currentScenario: '',
    progress: 0
  });
  const [selectedBrowsers, setSelectedBrowsers] = useState<string[]>([]);
  const [selectedScenarios, setSelectedScenarios] = useState<string[]>([]);
  const [supportedBrowsers] = useState<BrowserTestEnvironment[]>(
    crossBrowserErrorTestService.getSupportedBrowsers()
  );
  const [availableScenarios] = useState<ErrorScenario[]>(
    crossBrowserErrorTestService.getAvailableScenarios()
  );
  const [selectedResult, setSelectedResult] = useState<ErrorTestResult | null>(null);

  useEffect(() => {
    // Initialize with all browsers and scenarios selected
    setSelectedBrowsers(supportedBrowsers.map((b) => b.name));
    setSelectedScenarios(availableScenarios.map((s) => s.id));
  }, []);

  const runErrorTests = async () => {
    if (selectedBrowsers.length === 0 || selectedScenarios.length === 0) {
      toast.error('Please select at least one browser and one scenario');
      return;
    }

    setExecutionState({
      isRunning: true,
      currentBrowser: '',
      currentScenario: '',
      progress: 0,
      startTime: new Date()
    });

    try {
      // Simulate progress updates
      const totalSteps = selectedBrowsers.length * selectedScenarios.length;
      let currentStep = 0;

      const progressInterval = setInterval(() => {
        currentStep++;
        const browserIndex = Math.floor((currentStep - 1) / selectedScenarios.length);
        const scenarioIndex = (currentStep - 1) % selectedScenarios.length;

        if (browserIndex < selectedBrowsers.length && scenarioIndex < selectedScenarios.length) {
          setExecutionState((prev) => ({
            ...prev,
            currentBrowser: selectedBrowsers[browserIndex],
            currentScenario: availableScenarios.find((s) => s.id === selectedScenarios[scenarioIndex])?.name || '',
            progress: currentStep / totalSteps * 100
          }));
        }

        if (currentStep >= totalSteps) {
          clearInterval(progressInterval);
        }
      }, 500);

      const testReport = await crossBrowserErrorTestService.runCrossBrowserErrorTests(
        selectedBrowsers,
        selectedScenarios
      );

      clearInterval(progressInterval);
      setReport(testReport);
      toast.success(`Error testing completed: ${testReport.summary.passed}/${testReport.summary.totalTests} tests passed`);

    } catch (error) {
      console.error('Error testing failed:', error);
      toast.error('Cross-browser error testing failed');
    } finally {
      setExecutionState({
        isRunning: false,
        currentBrowser: '',
        currentScenario: '',
        progress: 0
      });
    }
  };

  const getBrowserIcon = (browserName: string) => {
    switch (browserName) {
      case 'Chrome':return <Chrome className="h-4 w-4 text-blue-500" />;
      case 'Firefox':return <Globe className="h-4 w-4 text-orange-500" />;
      case 'Safari':return <Smartphone className="h-4 w-4 text-blue-600" />;
      case 'Edge':return <Monitor className="h-4 w-4 text-blue-400" />;
      default:return <Globe className="h-4 w-4" />;
    }
  };

  const getScenarioIcon = (type: string) => {
    switch (type) {
      case 'runtime':return <Bug className="h-4 w-4 text-red-500" />;
      case 'network':return <Globe className="h-4 w-4 text-blue-500" />;
      case 'component':return <Activity className="h-4 w-4 text-green-500" />;
      case 'memory':return <Brain className="h-4 w-4 text-purple-500" />;
      case 'security':return <Shield className="h-4 w-4 text-orange-500" />;
      default:return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':return <XCircle className="h-4 w-4 text-yellow-500" />;
      case 'error':return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'low':return 'text-green-600 bg-green-50';
      case 'medium':return 'text-yellow-600 bg-yellow-50';
      case 'high':return 'text-orange-600 bg-orange-50';
      case 'critical':return 'text-red-600 bg-red-50';
      default:return 'text-gray-600 bg-gray-50';
    }
  };

  const renderTestConfiguration = () =>
  <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5" />
          Test Configuration
        </CardTitle>
        <CardDescription>
          Select browsers and error scenarios to test
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Browser Selection */}
        <div>
          <h4 className="text-sm font-medium mb-3">Target Browsers</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {supportedBrowsers.map((browser) =>
          <div
            key={browser.name}
            className={`flex items-center space-x-2 p-3 border rounded cursor-pointer transition-colors ${
            selectedBrowsers.includes(browser.name) ?
            'border-blue-500 bg-blue-50' :
            'border-gray-200 hover:border-gray-300'}`
            }
            onClick={() => {
              setSelectedBrowsers((prev) =>
              prev.includes(browser.name) ?
              prev.filter((b) => b !== browser.name) :
              [...prev, browser.name]
              );
            }}>

                {getBrowserIcon(browser.name)}
                <div>
                  <div className="font-medium text-sm">{browser.name}</div>
                  <div className="text-xs text-gray-500">{browser.version}</div>
                </div>
              </div>
          )}
          </div>
        </div>

        {/* Scenario Selection */}
        <div>
          <h4 className="text-sm font-medium mb-3">Error Scenarios</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {availableScenarios.map((scenario) =>
          <div
            key={scenario.id}
            className={`flex items-center space-x-3 p-2 border rounded cursor-pointer transition-colors ${
            selectedScenarios.includes(scenario.id) ?
            'border-blue-500 bg-blue-50' :
            'border-gray-200 hover:border-gray-300'}`
            }
            onClick={() => {
              setSelectedScenarios((prev) =>
              prev.includes(scenario.id) ?
              prev.filter((s) => s !== scenario.id) :
              [...prev, scenario.id]
              );
            }}>

                {getScenarioIcon(scenario.type)}
                <div className="flex-1">
                  <div className="font-medium text-sm">{scenario.name}</div>
                  <div className="text-xs text-gray-500">{scenario.description}</div>
                </div>
                <Badge variant="outline" className="text-xs">
                  {scenario.severity}
                </Badge>
              </div>
          )}
          </div>
        </div>

        {/* Test Controls */}
        <div className="flex items-center justify-between pt-4 border-t">
          <div className="text-sm text-gray-600">
            {selectedBrowsers.length} browsers × {selectedScenarios.length} scenarios = {selectedBrowsers.length * selectedScenarios.length} tests
          </div>
          <Button
          onClick={runErrorTests}
          disabled={executionState.isRunning}
          className="flex items-center gap-2">

            {executionState.isRunning ?
          <>
                <Pause className="h-4 w-4" />
                Running Tests...
              </> :

          <>
                <Play className="h-4 w-4" />
                Run Error Tests
              </>
          }
          </Button>
        </div>
      </CardContent>
    </Card>;


  const renderExecutionProgress = () => {
    if (!executionState.isRunning) return null;

    return (
      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                <span className="font-medium">
                  Testing {executionState.currentScenario} on {executionState.currentBrowser}
                </span>
              </div>
              <Badge variant="outline">
                {Math.round(executionState.progress)}%
              </Badge>
            </div>
            <Progress value={executionState.progress} className="w-full" />
            {executionState.startTime &&
            <div className="text-sm text-gray-600">
                Started at {executionState.startTime.toLocaleTimeString()}
              </div>
            }
          </div>
        </CardContent>
      </Card>);

  };

  const renderSummaryCards = () => {
    if (!report) return null;

    const { summary, errorTrackingValidation } = report;

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-8 w-8 text-green-500" />
              <div>
                <div className="text-2xl font-bold">{summary.passed}</div>
                <div className="text-sm text-gray-600">Passed Tests</div>
              </div>
            </div>
            <div className="mt-2">
              <Progress value={summary.passed / summary.totalTests * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-8 w-8 text-red-500" />
              <div>
                <div className="text-2xl font-bold">{summary.errors}</div>
                <div className="text-sm text-gray-600">Critical Issues</div>
              </div>
            </div>
            <div className="mt-2">
              <Progress value={summary.criticalIssues / summary.totalTests * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Zap className="h-8 w-8 text-blue-500" />
              <div>
                <div className="text-2xl font-bold">{Math.round(summary.errorRecoveryScore)}%</div>
                <div className="text-sm text-gray-600">Recovery Score</div>
              </div>
            </div>
            <div className="mt-2">
              <Progress value={summary.errorRecoveryScore} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Activity className="h-8 w-8 text-purple-500" />
              <div>
                <div className="text-2xl font-bold">{Math.round(errorTrackingValidation.trackingAccuracy)}%</div>
                <div className="text-sm text-gray-600">Tracking Accuracy</div>
              </div>
            </div>
            <div className="mt-2">
              <Progress value={errorTrackingValidation.trackingAccuracy} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>);

  };

  const renderBrowserCompatibility = () => {
    if (!report) return null;

    return (
      <Card>
        <CardHeader>
          <CardTitle>Browser Compatibility</CardTitle>
          <CardDescription>
            Error handling performance across different browsers
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(report.summary.browserCompatibility).map(([browser, score]) =>
            <div key={browser} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {getBrowserIcon(browser)}
                    <span className="font-medium">{browser}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={score >= 80 ? 'default' : score >= 60 ? 'secondary' : 'destructive'}>
                      {Math.round(score)}%
                    </Badge>
                    {score >= 90 && <TrendingUp className="h-4 w-4 text-green-500" />}
                    {score < 60 && <TrendingDown className="h-4 w-4 text-red-500" />}
                  </div>
                </div>
                <Progress value={score} className="w-full" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>);

  };

  const renderTestResults = () => {
    if (!report) return null;

    return (
      <Card>
        <CardHeader>
          <CardTitle>Test Results</CardTitle>
          <CardDescription>
            Detailed error scenario test results by browser
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Browser</TableHead>
                  <TableHead>Scenario</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Impact</TableHead>
                  <TableHead>Recovery</TableHead>
                  <TableHead>Experience</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {report.results.map((result, index) =>
                <TableRow
                  key={index}
                  className="cursor-pointer hover:bg-gray-50"
                  onClick={() => setSelectedResult(result)}>

                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getBrowserIcon(result.browser)}
                        <span>{result.browser}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getScenarioIcon(availableScenarios.find((s) => s.id === result.scenarioId)?.type || 'runtime')}
                        <span>{availableScenarios.find((s) => s.id === result.scenarioId)?.name || result.scenarioId}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(result.status)}
                        <Badge variant={result.status === 'passed' ? 'default' : result.status === 'failed' ? 'secondary' : 'destructive'}>
                          {result.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getImpactColor(result.impact)} border-0`}>
                        {result.impact}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {result.recoveryTime ?
                    <span className="text-sm text-green-600">
                          {result.recoveryTime}ms
                        </span> :

                    <span className="text-sm text-gray-400">N/A</span>
                    }
                    </TableCell>
                    <TableCell>
                      <Badge variant={
                    result.userExperience === 'good' ? 'default' :
                    result.userExperience === 'degraded' ? 'secondary' : 'destructive'
                    }>
                        {result.userExperience}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {result.executionTime}ms
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>);

  };

  const renderRecommendations = () => {
    if (!report || report.recommendations.length === 0) return null;

    return (
      <Card>
        <CardHeader>
          <CardTitle>Recommendations</CardTitle>
          <CardDescription>
            Browser-specific recommendations for improving error handling
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {report.recommendations.map((rec, index) =>
            <Alert key={index} className={
            rec.priority === 'critical' ? 'border-red-200 bg-red-50' :
            rec.priority === 'high' ? 'border-orange-200 bg-orange-50' :
            rec.priority === 'medium' ? 'border-yellow-200 bg-yellow-50' :
            'border-blue-200 bg-blue-50'
            }>
                <div className="flex items-start space-x-2">
                  {getBrowserIcon(rec.browser)}
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{rec.browser}</h4>
                      <Badge variant="outline" className={
                    rec.priority === 'critical' ? 'text-red-600' :
                    rec.priority === 'high' ? 'text-orange-600' :
                    rec.priority === 'medium' ? 'text-yellow-600' :
                    'text-blue-600'
                    }>
                        {rec.priority}
                      </Badge>
                    </div>
                    
                    {rec.issues.length > 0 &&
                  <div className="mb-3">
                        <h5 className="text-sm font-medium mb-1">Issues:</h5>
                        <ul className="text-sm space-y-1">
                          {rec.issues.map((issue, i) =>
                      <li key={i} className="flex items-start space-x-1">
                              <span className="text-red-500 mt-1">•</span>
                              <span>{issue}</span>
                            </li>
                      )}
                        </ul>
                      </div>
                  }
                    
                    {rec.suggestions.length > 0 &&
                  <div>
                        <h5 className="text-sm font-medium mb-1">Suggestions:</h5>
                        <ul className="text-sm space-y-1">
                          {rec.suggestions.map((suggestion, i) =>
                      <li key={i} className="flex items-start space-x-1">
                              <span className="text-green-500 mt-1">•</span>
                              <span>{suggestion}</span>
                            </li>
                      )}
                        </ul>
                      </div>
                  }
                  </div>
                </div>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>);

  };

  const renderResultModal = () => {
    if (!selectedResult) return null;

    const scenario = availableScenarios.find((s) => s.id === selectedResult.scenarioId);

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-hidden">
          <div className="p-6 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {getStatusIcon(selectedResult.status)}
                <h2 className="text-lg font-semibold">Test Result Details</h2>
              </div>
              <Button variant="outline" size="sm" onClick={() => setSelectedResult(null)}>
                Close
              </Button>
            </div>
          </div>
          
          <ScrollArea className="p-6 space-y-6 max-h-[calc(90vh-120px)]">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-medium mb-2">Browser</h3>
                <div className="flex items-center space-x-2">
                  {getBrowserIcon(selectedResult.browser)}
                  <span>{selectedResult.browser}</span>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Scenario</h3>
                <div className="flex items-center space-x-2">
                  {scenario && getScenarioIcon(scenario.type)}
                  <span>{scenario?.name || selectedResult.scenarioId}</span>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Status</h3>
                <Badge variant={selectedResult.status === 'passed' ? 'default' : 'destructive'}>
                  {selectedResult.status}
                </Badge>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Impact</h3>
                <Badge className={`${getImpactColor(selectedResult.impact)} border-0`}>
                  {selectedResult.impact}
                </Badge>
              </div>
              
              <div>
                <h3 className="font-medium mb-2">Execution Time</h3>
                <span>{selectedResult.executionTime}ms</span>
              </div>
              
              {selectedResult.recoveryTime &&
              <div>
                  <h3 className="font-medium mb-2">Recovery Time</h3>
                  <span className="text-green-600">{selectedResult.recoveryTime}ms</span>
                </div>
              }
            </div>

            {selectedResult.errorDetails &&
            <div>
                <h3 className="font-medium mb-2">Error Details</h3>
                <div className="bg-gray-50 p-4 rounded space-y-2">
                  <div>
                    <strong>Message:</strong> {selectedResult.errorDetails.message}
                  </div>
                  <div>
                    <strong>Type:</strong> {selectedResult.errorDetails.type}
                  </div>
                  <div>
                    <strong>Recoverable:</strong> 
                    <Badge variant={selectedResult.errorDetails.recoverable ? 'default' : 'destructive'} className="ml-2">
                      {selectedResult.errorDetails.recoverable ? 'Yes' : 'No'}
                    </Badge>
                  </div>
                  {selectedResult.errorDetails.stack &&
                <div>
                      <strong>Stack Trace:</strong>
                      <pre className="mt-1 text-xs bg-white p-2 rounded border overflow-x-auto">
                        {selectedResult.errorDetails.stack}
                      </pre>
                    </div>
                }
                </div>
              </div>
            }

            {scenario &&
            <div>
                <h3 className="font-medium mb-2">Scenario Details</h3>
                <div className="bg-gray-50 p-4 rounded space-y-2">
                  <div><strong>Description:</strong> {scenario.description}</div>
                  <div><strong>Type:</strong> {scenario.type}</div>
                  <div><strong>Severity:</strong> {scenario.severity}</div>
                </div>
              </div>
            }
          </ScrollArea>
        </div>
      </div>);

  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Cross-Browser Error Testing</h1>
          <p className="text-muted-foreground mt-2">
            Comprehensive error scenario validation across different browsers and environments
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            onClick={() => window.location.reload()}
            disabled={executionState.isRunning}>

            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {renderTestConfiguration()}
      {renderExecutionProgress()}
      
      {report &&
      <Tabs defaultValue="summary" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="compatibility">Compatibility</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="summary" className="space-y-4">
            {renderSummaryCards()}
          </TabsContent>

          <TabsContent value="compatibility" className="space-y-4">
            {renderBrowserCompatibility()}
          </TabsContent>

          <TabsContent value="results" className="space-y-4">
            {renderTestResults()}
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-4">
            {renderRecommendations()}
          </TabsContent>
        </Tabs>
      }

      {renderResultModal()}
    </div>);

};

export default CrossBrowserErrorTestDashboard;