import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Play,
  Pause,
  Square,
  Download,
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  Activity,
  Target,
  TrendingUp } from
'lucide-react';
import { apiEndpointDiscoveryService, ServiceRegistry, ServiceEndpoint } from '@/services/apiEndpointDiscoveryService';
import { automatedTestGeneratorService, TestSuite, TestCase } from '@/services/automatedTestGeneratorService';
import { testExecutionEngineService, TestExecutionReport } from '@/services/testExecutionEngineService';
import { errorHandlingVerificationService, ErrorHandlingReport } from '@/services/errorHandlingVerificationService';
import { requestResponseValidationService, ApiValidationReport } from '@/services/requestResponseValidationService';
import { apiTestReportingService, DetailedTestReport, EndpointHealthScore } from '@/services/apiTestReportingService';
import { EndpointSelectionPanel } from './EndpointSelectionPanel';
import { TestExecutionControls } from './TestExecutionControls';
import { TestResultsDisplay } from './TestResultsDisplay';
import { TestReportViewer } from './TestReportViewer';
import { toast } from 'sonner';

interface TestExecutionState {
  isRunning: boolean;
  isPaused: boolean;
  currentTest?: string;
  progress: number;
  totalTests: number;
  startTime?: Date;
}

interface ServiceStats {
  totalServices: number;
  totalEndpoints: number;
  endpointsByType: Record<string, number>;
  endpointsByService: Record<string, number>;
}

export const ApiTestingDashboard: React.FC = () => {
  // State management
  const [serviceRegistries, setServiceRegistries] = useState<ServiceRegistry[]>([]);
  const [serviceStats, setServiceStats] = useState<ServiceStats | null>(null);
  const [selectedEndpoints, setSelectedEndpoints] = useState<ServiceEndpoint[]>([]);
  const [testSuite, setTestSuite] = useState<TestSuite | null>(null);
  const [executionState, setExecutionState] = useState<TestExecutionState>({
    isRunning: false,
    isPaused: false,
    progress: 0,
    totalTests: 0
  });
  const [currentReport, setCurrentReport] = useState<DetailedTestReport | null>(null);
  const [healthScores, setHealthScores] = useState<EndpointHealthScore[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Initialize dashboard
  useEffect(() => {
    initializeDashboard();
  }, []);

  const initializeDashboard = async () => {
    try {
      setLoading(true);
      setError(null);

      // Discover all service endpoints
      const registries = await apiEndpointDiscoveryService.discoverAllEndpoints();
      setServiceRegistries(registries);

      // Get service statistics
      const stats = await apiEndpointDiscoveryService.getServiceStatistics();
      setServiceStats(stats);

      // Get endpoint health scores
      const scores = apiTestReportingService.getEndpointHealthScores();
      setHealthScores(scores);

      toast.success(`Discovered ${stats.totalEndpoints} endpoints across ${stats.totalServices} services`);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to initialize dashboard';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleEndpointsSelected = useCallback((endpoints: ServiceEndpoint[]) => {
    setSelectedEndpoints(endpoints);

    if (endpoints.length > 0) {
      // Generate test suite for selected endpoints
      const suite = automatedTestGeneratorService.generateTestSuite(
        endpoints,
        `Selected Endpoints Test Suite - ${new Date().toLocaleDateString()}`
      );
      setTestSuite(suite);
      toast.info(`Generated ${suite.testCases.length} test cases for ${endpoints.length} endpoints`);
    } else {
      setTestSuite(null);
    }
  }, []);

  const handleTestExecution = async () => {
    if (!testSuite || testSuite.testCases.length === 0) {
      toast.error('No test suite available. Please select endpoints first.');
      return;
    }

    try {
      setExecutionState((prev) => ({
        ...prev,
        isRunning: true,
        isPaused: false,
        progress: 0,
        totalTests: testSuite.testCases.length,
        startTime: new Date()
      }));

      toast.info('Starting comprehensive API testing...');

      // Execute test suite
      const executionReport = await testExecutionEngineService.executeTestCases(
        testSuite.testCases,
        {
          maxRetries: 1,
          parallelExecution: false,
          stopOnFirstFailure: false,
          detailedLogging: true
        }
      );

      // Update progress
      setExecutionState((prev) => ({ ...prev, progress: 33 }));

      // Test error handling
      toast.info('Testing error handling...');
      const errorReports = await errorHandlingVerificationService.testMultipleEndpointsErrorHandling(
        selectedEndpoints
      );

      // Update progress
      setExecutionState((prev) => ({ ...prev, progress: 66 }));

      // Validate requests and responses
      toast.info('Validating API contracts...');
      const validationReports = await Promise.all(
        selectedEndpoints.map(async (endpoint, index) => {
          const testCase = testSuite.testCases.find((tc) =>
          tc.endpointId === `${endpoint.serviceName}.${endpoint.methodName}`
          );
          if (testCase) {
            return await requestResponseValidationService.validateApiEndpoint(
              endpoint,
              testCase,
              testCase.testData,
              executionReport.results[index]?.result
            );
          }
          return null;
        })
      ).then((reports) => reports.filter(Boolean) as ApiValidationReport[]);

      // Update progress
      setExecutionState((prev) => ({ ...prev, progress: 90 }));

      // Generate comprehensive report
      toast.info('Generating comprehensive report...');
      const detailedReport = await apiTestReportingService.generateDetailedReport(
        executionReport,
        errorReports,
        validationReports,
        serviceRegistries
      );

      setCurrentReport(detailedReport);

      // Update health scores
      const updatedHealthScores = apiTestReportingService.getEndpointHealthScores();
      setHealthScores(updatedHealthScores);

      // Complete execution
      setExecutionState((prev) => ({ ...prev, progress: 100 }));

      toast.success(`Testing completed! ${executionReport.summary.passed}/${executionReport.summary.totalTests} tests passed`);

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Test execution failed';
      toast.error(errorMessage);
      setError(errorMessage);
    } finally {
      setExecutionState((prev) => ({
        ...prev,
        isRunning: false,
        isPaused: false
      }));
    }
  };

  const handleStopExecution = () => {
    setExecutionState((prev) => ({
      ...prev,
      isRunning: false,
      isPaused: false,
      progress: 0
    }));
    toast.info('Test execution stopped');
  };

  const handleExportReport = (format: 'json' | 'html') => {
    if (!currentReport) {
      toast.error('No report available to export');
      return;
    }

    try {
      let content: string;
      let fileName: string;
      let mimeType: string;

      if (format === 'json') {
        content = apiTestReportingService.exportReportAsJson(currentReport);
        fileName = `api-test-report-${currentReport.reportId}.json`;
        mimeType = 'application/json';
      } else {
        content = apiTestReportingService.generateHtmlReport(currentReport);
        fileName = `api-test-report-${currentReport.reportId}.html`;
        mimeType = 'text/html';
      }

      // Create download link
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success(`Report exported as ${format.toUpperCase()}`);
    } catch (err) {
      toast.error('Failed to export report');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-500" />
          <p className="text-lg">Discovering API endpoints...</p>
        </div>
      </div>);

  }

  if (error) {
    return (
      <div className="p-6">
        <Alert variant="destructive">
          <XCircle className="h-4 w-4" />
          <AlertDescription>
            {error}
            <Button
              variant="outline"
              size="sm"
              onClick={initializeDashboard}
              className="ml-4">

              Retry
            </Button>
          </AlertDescription>
        </Alert>
      </div>);

  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">API Testing Framework</h1>
              <p className="text-gray-600 mt-1">
                Comprehensive endpoint discovery, testing, and validation
              </p>
            </div>
            <Button
              variant="outline"
              onClick={initializeDashboard}
              disabled={loading}>

              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          {/* Quick Stats */}
          {serviceStats &&
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center">
                  <Target className="h-8 w-8 text-blue-500" />
                  <div className="ml-3">
                    <p className="text-sm font-medium text-blue-700">Services</p>
                    <p className="text-2xl font-bold text-blue-900">{serviceStats.totalServices}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-center">
                  <Activity className="h-8 w-8 text-green-500" />
                  <div className="ml-3">
                    <p className="text-sm font-medium text-green-700">Endpoints</p>
                    <p className="text-2xl font-bold text-green-900">{serviceStats.totalEndpoints}</p>
                  </div>
                </div>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="flex items-center">
                  <CheckCircle className="h-8 w-8 text-purple-500" />
                  <div className="ml-3">
                    <p className="text-sm font-medium text-purple-700">Selected</p>
                    <p className="text-2xl font-bold text-purple-900">{selectedEndpoints.length}</p>
                  </div>
                </div>
              </div>

              <div className="bg-orange-50 p-4 rounded-lg">
                <div className="flex items-center">
                  <TrendingUp className="h-8 w-8 text-orange-500" />
                  <div className="ml-3">
                    <p className="text-sm font-medium text-orange-700">Test Cases</p>
                    <p className="text-2xl font-bold text-orange-900">{testSuite?.testCases.length || 0}</p>
                  </div>
                </div>
              </div>
            </div>
          }
        </div>

        {/* Main Content */}
        <Tabs defaultValue="endpoints" className="space-y-6">
          <TabsList className="grid grid-cols-4 w-full max-w-md">
            <TabsTrigger value="endpoints">Endpoints</TabsTrigger>
            <TabsTrigger value="testing">Testing</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="endpoints" className="space-y-6">
            <EndpointSelectionPanel
              serviceRegistries={serviceRegistries}
              selectedEndpoints={selectedEndpoints}
              onEndpointsSelected={handleEndpointsSelected} />

          </TabsContent>

          <TabsContent value="testing" className="space-y-6">
            <TestExecutionControls
              testSuite={testSuite}
              executionState={executionState}
              onStartExecution={handleTestExecution}
              onStopExecution={handleStopExecution}
              disabled={selectedEndpoints.length === 0} />


            {/* Execution Progress */}
            {executionState.isRunning &&
            <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="h-5 w-5 mr-2 animate-pulse" />
                    Test Execution in Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">
                        {executionState.currentTest || 'Initializing...'}
                      </span>
                      <span className="text-sm font-medium">
                        {executionState.progress.toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={executionState.progress} />
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      Started: {executionState.startTime?.toLocaleTimeString()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            }
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            <TestResultsDisplay
              report={currentReport}
              healthScores={healthScores} />

          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <TestReportViewer
              currentReport={currentReport}
              onExportReport={handleExportReport} />

          </TabsContent>
        </Tabs>
      </div>
    </div>);

};

export default ApiTestingDashboard;