import React, { useState, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  CheckCircle,
  Circle,
  Search,
  Filter,
  Server,
  Database,
  FileText,
  Edit,
  Trash,
  Settings } from
'lucide-react';
import { ServiceRegistry, ServiceEndpoint } from '@/services/apiEndpointDiscoveryService';

interface EndpointSelectionPanelProps {
  serviceRegistries: ServiceRegistry[];
  selectedEndpoints: ServiceEndpoint[];
  onEndpointsSelected: (endpoints: ServiceEndpoint[]) => void;
}

const operationTypeColors = {
  CREATE: 'bg-green-100 text-green-800',
  READ: 'bg-blue-100 text-blue-800',
  UPDATE: 'bg-yellow-100 text-yellow-800',
  DELETE: 'bg-red-100 text-red-800',
  UTILITY: 'bg-purple-100 text-purple-800'
};

const operationTypeIcons = {
  CREATE: <Database className="h-3 w-3" />,
  READ: <FileText className="h-3 w-3" />,
  UPDATE: <Edit className="h-3 w-3" />,
  DELETE: <Trash className="h-3 w-3" />,
  UTILITY: <Settings className="h-3 w-3" />
};

export const EndpointSelectionPanel: React.FC<EndpointSelectionPanelProps> = ({
  serviceRegistries,
  selectedEndpoints,
  onEndpointsSelected
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedService, setSelectedService] = useState<string>('all');
  const [selectedOperationType, setSelectedOperationType] = useState<string>('all');

  // Get all endpoints flattened
  const allEndpoints = useMemo(() => {
    const endpoints: ServiceEndpoint[] = [];
    serviceRegistries.forEach((registry) => {
      endpoints.push(...registry.endpoints);
    });
    return endpoints;
  }, [serviceRegistries]);

  // Filter endpoints based on search and filters
  const filteredEndpoints = useMemo(() => {
    return allEndpoints.filter((endpoint) => {
      const matchesSearch = !searchTerm ||
      endpoint.serviceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      endpoint.methodName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      endpoint.description.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesService = selectedService === 'all' || endpoint.serviceName === selectedService;
      const matchesOperation = selectedOperationType === 'all' || endpoint.operationType === selectedOperationType;

      return matchesSearch && matchesService && matchesOperation;
    });
  }, [allEndpoints, searchTerm, selectedService, selectedOperationType]);

  // Group filtered endpoints by service
  const groupedEndpoints = useMemo(() => {
    const groups: {[serviceName: string]: ServiceEndpoint[];} = {};
    filteredEndpoints.forEach((endpoint) => {
      if (!groups[endpoint.serviceName]) {
        groups[endpoint.serviceName] = [];
      }
      groups[endpoint.serviceName].push(endpoint);
    });
    return groups;
  }, [filteredEndpoints]);

  const isEndpointSelected = (endpoint: ServiceEndpoint): boolean => {
    return selectedEndpoints.some((selected) =>
    selected.serviceName === endpoint.serviceName &&
    selected.methodName === endpoint.methodName
    );
  };

  const toggleEndpoint = (endpoint: ServiceEndpoint) => {
    if (isEndpointSelected(endpoint)) {
      // Remove endpoint
      const updated = selectedEndpoints.filter((selected) =>
      !(selected.serviceName === endpoint.serviceName && selected.methodName === endpoint.methodName)
      );
      onEndpointsSelected(updated);
    } else {
      // Add endpoint
      onEndpointsSelected([...selectedEndpoints, endpoint]);
    }
  };

  const selectAllInService = (serviceName: string) => {
    const serviceEndpoints = groupedEndpoints[serviceName] || [];
    const currentlySelected = selectedEndpoints.filter((ep) => ep.serviceName !== serviceName);
    const newSelected = [...currentlySelected, ...serviceEndpoints];
    onEndpointsSelected(newSelected);
  };

  const deselectAllInService = (serviceName: string) => {
    const updated = selectedEndpoints.filter((ep) => ep.serviceName !== serviceName);
    onEndpointsSelected(updated);
  };

  const selectAllByOperationType = (operationType: string) => {
    const typeEndpoints = allEndpoints.filter((ep) => ep.operationType === operationType);
    const currentlySelected = selectedEndpoints.filter((ep) => ep.operationType !== operationType);
    const newSelected = [...currentlySelected, ...typeEndpoints];
    onEndpointsSelected(newSelected);
  };

  const selectAllEndpoints = () => {
    onEndpointsSelected(allEndpoints);
  };

  const clearSelection = () => {
    onEndpointsSelected([]);
  };

  const getServiceStats = (serviceName: string) => {
    const serviceEndpoints = allEndpoints.filter((ep) => ep.serviceName === serviceName);
    const selectedInService = selectedEndpoints.filter((ep) => ep.serviceName === serviceName);
    return {
      total: serviceEndpoints.length,
      selected: selectedInService.length
    };
  };

  return (
    <div className="space-y-6">
      {/* Selection Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <Server className="h-5 w-5 mr-2" />
              Endpoint Selection
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">
                {selectedEndpoints.length} of {allEndpoints.length} selected
              </Badge>
              <Button variant="outline" size="sm" onClick={selectAllEndpoints}>
                Select All
              </Button>
              <Button variant="outline" size="sm" onClick={clearSelection}>
                Clear All
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Search and Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                placeholder="Search endpoints..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" />

            </div>

            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">

              <option value="all">All Services</option>
              {serviceRegistries.map((registry) =>
              <option key={registry.serviceName} value={registry.serviceName}>
                  {registry.serviceName}
                </option>
              )}
            </select>

            <select
              value={selectedOperationType}
              onChange={(e) => setSelectedOperationType(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">

              <option value="all">All Operations</option>
              <option value="CREATE">CREATE</option>
              <option value="READ">READ</option>
              <option value="UPDATE">UPDATE</option>
              <option value="DELETE">DELETE</option>
              <option value="UTILITY">UTILITY</option>
            </select>
          </div>

          {/* Quick Selection by Operation Type */}
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="text-sm font-medium text-gray-700">Quick select by type:</span>
            {Object.entries(operationTypeColors).map(([type, colorClass]) =>
            <Button
              key={type}
              variant="outline"
              size="sm"
              onClick={() => selectAllByOperationType(type)}
              className="text-xs">

                <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${colorClass}`}>
                  {operationTypeIcons[type as keyof typeof operationTypeIcons]}
                  <span className="ml-1">{type}</span>
                </div>
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Endpoint List */}
      <Tabs value="services" className="w-full">
        <TabsList>
          <TabsTrigger value="services">By Services</TabsTrigger>
          <TabsTrigger value="operations">By Operations</TabsTrigger>
        </TabsList>

        <TabsContent value="services" className="space-y-4">
          {Object.entries(groupedEndpoints).map(([serviceName, endpoints]) => {
            const stats = getServiceStats(serviceName);
            return (
              <Card key={serviceName}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center">
                      <Server className="h-4 w-4 mr-2" />
                      {serviceName}
                      <Badge variant="outline" className="ml-2">
                        {stats.selected}/{stats.total}
                      </Badge>
                    </CardTitle>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => selectAllInService(serviceName)}>

                        Select All
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deselectAllInService(serviceName)}>

                        Clear All
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                    {endpoints.map((endpoint, index) => {
                      const isSelected = isEndpointSelected(endpoint);
                      return (
                        <div
                          key={`${endpoint.serviceName}-${endpoint.methodName}-${index}`}
                          onClick={() => toggleEndpoint(endpoint)}
                          className={`p-3 rounded-lg border cursor-pointer transition-all duration-200 hover:shadow-md ${
                          isSelected ?
                          'border-blue-500 bg-blue-50 shadow-sm' :
                          'border-gray-200 bg-white hover:border-gray-300'}`
                          }>

                          <div className="flex items-start justify-between">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center">
                                {isSelected ?
                                <CheckCircle className="h-4 w-4 text-blue-500 mr-2 flex-shrink-0" /> :

                                <Circle className="h-4 w-4 text-gray-400 mr-2 flex-shrink-0" />
                                }
                                <span className="font-medium text-sm truncate">
                                  {endpoint.methodName}
                                </span>
                              </div>
                              <p className="text-xs text-gray-600 mt-1 line-clamp-2">
                                {endpoint.description}
                              </p>
                              <div className="flex items-center mt-2 space-x-2">
                                <Badge
                                  className={`text-xs ${operationTypeColors[endpoint.operationType]}`}>

                                  {operationTypeIcons[endpoint.operationType]}
                                  <span className="ml-1">{endpoint.operationType}</span>
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {endpoint.returnType}
                                </Badge>
                                {endpoint.requiresAuth &&
                                <Badge variant="outline" className="text-xs text-orange-600">
                                    Auth Required
                                  </Badge>
                                }
                              </div>
                            </div>
                          </div>
                        </div>);

                    })}
                  </div>
                </CardContent>
              </Card>);

          })}

          {Object.keys(groupedEndpoints).length === 0 &&
          <Card>
              <CardContent className="text-center py-8">
                <Search className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-600">No endpoints found matching your filters.</p>
                <p className="text-sm text-gray-500 mt-1">Try adjusting your search or filter criteria.</p>
              </CardContent>
            </Card>
          }
        </TabsContent>

        <TabsContent value="operations" className="space-y-4">
          {Object.entries(operationTypeColors).map(([operationType, colorClass]) => {
            const operationEndpoints = filteredEndpoints.filter((ep) => ep.operationType === operationType);
            const selectedCount = selectedEndpoints.filter((ep) => ep.operationType === operationType).length;

            if (operationEndpoints.length === 0) return null;

            return (
              <Card key={operationType}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center">
                      <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${colorClass} mr-3`}>
                        {operationTypeIcons[operationType as keyof typeof operationTypeIcons]}
                        <span className="ml-1">{operationType} Operations</span>
                      </div>
                      <Badge variant="outline">
                        {selectedCount}/{operationEndpoints.length}
                      </Badge>
                    </CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => selectAllByOperationType(operationType)}>

                      Select All {operationType}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                    {operationEndpoints.map((endpoint, index) => {
                      const isSelected = isEndpointSelected(endpoint);
                      return (
                        <div
                          key={`${endpoint.serviceName}-${endpoint.methodName}-${index}`}
                          onClick={() => toggleEndpoint(endpoint)}
                          className={`p-3 rounded-lg border cursor-pointer transition-all duration-200 hover:shadow-md ${
                          isSelected ?
                          'border-blue-500 bg-blue-50 shadow-sm' :
                          'border-gray-200 bg-white hover:border-gray-300'}`
                          }>

                          <div className="flex items-start justify-between">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center">
                                {isSelected ?
                                <CheckCircle className="h-4 w-4 text-blue-500 mr-2 flex-shrink-0" /> :

                                <Circle className="h-4 w-4 text-gray-400 mr-2 flex-shrink-0" />
                                }
                                <span className="font-medium text-sm truncate">
                                  {endpoint.serviceName}.{endpoint.methodName}
                                </span>
                              </div>
                              <p className="text-xs text-gray-600 mt-1 line-clamp-2">
                                {endpoint.description}
                              </p>
                            </div>
                          </div>
                        </div>);

                    })}
                  </div>
                </CardContent>
              </Card>);

          })}
        </TabsContent>
      </Tabs>
    </div>);

};