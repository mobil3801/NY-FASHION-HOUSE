
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import {
  Play,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  TrendingUp,
  TrendingDown,
  Shield,
  ShoppingCart,
  BarChart3,
  RefreshCw,
  Download } from
'lucide-react';
import { criticalFlowTests, CriticalFlowTestResult } from '@/services/criticalFlowTests';
import { testValidationEngine } from '@/services/testValidationEngine';
import { automatedTestSuites } from '@/services/automatedTestSuites';
import { toast } from 'sonner';

interface TestManagerState {
  isRunning: boolean;
  currentFlow: string | null;
  progress: number;
  results: {
    authentication: CriticalFlowTestResult | null;
    posCheckout: CriticalFlowTestResult | null;
    reports: CriticalFlowTestResult | null;
  };
  systemHealth: any | null;
  lastRunTime: Date | null;
}

const CriticalFlowTestManager: React.FC = () => {
  const [testState, setTestState] = useState<TestManagerState>({
    isRunning: false,
    currentFlow: null,
    progress: 0,
    results: {
      authentication: null,
      posCheckout: null,
      reports: null
    },
    systemHealth: null,
    lastRunTime: null
  });

  const [selectedFlow, setSelectedFlow] = useState<CriticalFlowTestResult | null>(null);
  const [autoRunEnabled, setAutoRunEnabled] = useState(false);

  useEffect(() => {
    // Initialize test suites in database on component mount
    initializeTestSuites();
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (autoRunEnabled) {
      // Run tests every 30 minutes when auto-run is enabled
      interval = setInterval(runAllCriticalFlows, 30 * 60 * 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRunEnabled]);

  const initializeTestSuites = async () => {
    try {
      await automatedTestSuites.createTestSuitesInDatabase();
      console.log('Test suites initialized successfully');
    } catch (error) {
      console.error('Error initializing test suites:', error);
      toast.error('Failed to initialize test suites');
    }
  };

  const runAllCriticalFlows = async () => {
    setTestState((prev) => ({
      ...prev,
      isRunning: true,
      progress: 0,
      currentFlow: 'Initializing...'
    }));

    try {
      console.log('Starting comprehensive critical flow testing...');

      // Run authentication tests
      setTestState((prev) => ({ ...prev, currentFlow: 'Authentication Flow', progress: 10 }));
      const authResult = await criticalFlowTests.executeAuthenticationFlowTests();
      setTestState((prev) => ({
        ...prev,
        results: { ...prev.results, authentication: authResult },
        progress: 35
      }));

      // Run POS checkout tests
      setTestState((prev) => ({ ...prev, currentFlow: 'POS Checkout Flow', progress: 40 }));
      const posResult = await criticalFlowTests.executePOSFlowTests();
      setTestState((prev) => ({
        ...prev,
        results: { ...prev.results, posCheckout: posResult },
        progress: 70
      }));

      // Run reports tests
      setTestState((prev) => ({ ...prev, currentFlow: 'Reports Flow', progress: 75 }));
      const reportsResult = await criticalFlowTests.executeReportsFlowTests();
      setTestState((prev) => ({
        ...prev,
        results: { ...prev.results, reports: reportsResult },
        progress: 90
      }));

      // Perform system health check
      setTestState((prev) => ({ ...prev, currentFlow: 'System Health Check', progress: 95 }));
      const systemHealth = await testValidationEngine.performSystemHealthCheck();

      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentFlow: null,
        progress: 100,
        systemHealth,
        lastRunTime: new Date()
      }));

      // Show completion notification
      const totalIssues = authResult.criticalIssues.length + posResult.criticalIssues.length + reportsResult.criticalIssues.length;

      if (totalIssues === 0) {
        toast.success('All critical flow tests passed successfully!');
      } else {
        toast.warning(`Critical flow tests completed with ${totalIssues} issues detected`);
      }

    } catch (error) {
      console.error('Error running critical flow tests:', error);
      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentFlow: null
      }));
      toast.error('Critical flow test execution failed');
    }
  };

  const runIndividualFlow = async (flowType: 'authentication' | 'posCheckout' | 'reports') => {
    setTestState((prev) => ({
      ...prev,
      isRunning: true,
      currentFlow: flowType,
      progress: 0
    }));

    try {
      let result: CriticalFlowTestResult;

      switch (flowType) {
        case 'authentication':
          result = await criticalFlowTests.executeAuthenticationFlowTests();
          break;
        case 'posCheckout':
          result = await criticalFlowTests.executePOSFlowTests();
          break;
        case 'reports':
          result = await criticalFlowTests.executeReportsFlowTests();
          break;
      }

      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentFlow: null,
        progress: 100,
        results: {
          ...prev.results,
          [flowType]: result
        }
      }));

      toast.success(`${result.flowName} tests completed`);

    } catch (error) {
      console.error(`Error running ${flowType} tests:`, error);
      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentFlow: null
      }));
      toast.error(`${flowType} test execution failed`);
    }
  };

  const getFlowStatusBadge = (result: CriticalFlowTestResult | null) => {
    if (!result) return <Badge variant="outline">Not Run</Badge>;

    if (result.flowCompleted && result.criticalIssues.length === 0) {
      return <Badge className="bg-green-500 hover:bg-green-600">Excellent</Badge>;
    } else if (result.flowCompleted && result.criticalIssues.length <= 2) {
      return <Badge className="bg-blue-500 hover:bg-blue-600">Good</Badge>;
    } else if (result.criticalIssues.length <= 5) {
      return <Badge className="bg-yellow-500 hover:bg-yellow-600">Fair</Badge>;
    } else {
      return <Badge variant="destructive">Poor</Badge>;
    }
  };

  const renderFlowSummary = (result: CriticalFlowTestResult | null, icon: React.ReactNode) => {
    if (!result) {
      return (
        <div className="text-center py-8 text-gray-500">
          <div className="mb-2">{icon}</div>
          <p>No test results available</p>
        </div>);

    }

    const passedTests = result.executionResults.filter((r) => r.status === 'passed').length;
    const totalTests = result.executionResults.length;
    const passRate = totalTests > 0 ? passedTests / totalTests * 100 : 0;

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {icon}
            <h3 className="font-semibold">{result.flowName}</h3>
          </div>
          {getFlowStatusBadge(result)}
        </div>

        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-green-600">{passedTests}</div>
            <div className="text-sm text-gray-600">Passed</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-red-600">
              {result.executionResults.filter((r) => r.status === 'failed').length}
            </div>
            <div className="text-sm text-gray-600">Failed</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-orange-600">
              {result.executionResults.filter((r) => r.status === 'error').length}
            </div>
            <div className="text-sm text-gray-600">Errors</div>
          </div>
        </div>

        <div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Success Rate</span>
            <span className="text-sm">{passRate.toFixed(1)}%</span>
          </div>
          <Progress value={passRate} className="w-full" />
        </div>

        {result.criticalIssues.length > 0 &&
        <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Critical Issues Detected</AlertTitle>
            <AlertDescription>
              <ul className="list-disc list-inside space-y-1 mt-2">
                {result.criticalIssues.slice(0, 3).map((issue, index) =>
              <li key={index} className="text-sm">{issue}</li>
              )}
                {result.criticalIssues.length > 3 &&
              <li className="text-sm font-medium">
                    +{result.criticalIssues.length - 3} more issues...
                  </li>
              }
              </ul>
            </AlertDescription>
          </Alert>
        }

        {result.recommendations.length > 0 &&
        <div className="space-y-2">
            <h4 className="font-medium text-sm">Recommendations:</h4>
            <ul className="space-y-1">
              {result.recommendations.slice(0, 2).map((rec, index) =>
            <li key={index} className="text-sm text-gray-600 flex items-start space-x-2">
                  <TrendingUp className="h-3 w-3 mt-0.5 text-blue-500 flex-shrink-0" />
                  <span>{rec}</span>
                </li>
            )}
            </ul>
          </div>
        }

        <Button
          variant="outline"
          size="sm"
          onClick={() => setSelectedFlow(result)}
          className="w-full">

          View Details
        </Button>
      </div>);

  };

  const renderSystemHealth = () => {
    if (!testState.systemHealth) return null;

    const health = testState.systemHealth;
    const healthScore = [
    health.databaseConnectivity,
    health.apiResponsiveness,
    health.authenticationWorking,
    health.dataIntegrity].
    filter(Boolean).length;

    const healthPercentage = healthScore / 4 * 100;

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>System Health Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className={`text-lg font-bold ${health.databaseConnectivity ? 'text-green-600' : 'text-red-600'}`}>
                {health.databaseConnectivity ? 'OK' : 'FAIL'}
              </div>
              <div className="text-sm text-gray-600">Database</div>
            </div>
            <div className="text-center">
              <div className={`text-lg font-bold ${health.apiResponsiveness ? 'text-green-600' : 'text-red-600'}`}>
                {health.apiResponsiveness ? 'OK' : 'FAIL'}
              </div>
              <div className="text-sm text-gray-600">API</div>
            </div>
            <div className="text-center">
              <div className={`text-lg font-bold ${health.authenticationWorking ? 'text-green-600' : 'text-red-600'}`}>
                {health.authenticationWorking ? 'OK' : 'FAIL'}
              </div>
              <div className="text-sm text-gray-600">Auth</div>
            </div>
            <div className="text-center">
              <div className={`text-lg font-bold ${health.dataIntegrity ? 'text-green-600' : 'text-red-600'}`}>
                {health.dataIntegrity ? 'OK' : 'FAIL'}
              </div>
              <div className="text-sm text-gray-600">Data</div>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Overall Health</span>
              <span className="text-sm">{healthPercentage.toFixed(0)}%</span>
            </div>
            <Progress value={healthPercentage} className="w-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <span className="font-medium">Avg Response Time:</span>
              <div className={`text-lg ${health.performanceMetrics.avgResponseTime > 1000 ? 'text-orange-600' : 'text-green-600'}`}>
                {health.performanceMetrics.avgResponseTime.toFixed(0)}ms
              </div>
            </div>
            <div>
              <span className="font-medium">Slow Queries:</span>
              <div className={`text-lg ${health.performanceMetrics.slowQueries > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                {health.performanceMetrics.slowQueries}
              </div>
            </div>
            <div>
              <span className="font-medium">Error Rate:</span>
              <div className={`text-lg ${health.performanceMetrics.errorRate > 5 ? 'text-red-600' : 'text-green-600'}`}>
                {health.performanceMetrics.errorRate.toFixed(1)}%
              </div>
            </div>
          </div>

          {health.recommendations && health.recommendations.length > 0 &&
          <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>System Recommendations</AlertTitle>
              <AlertDescription>
                <ul className="list-disc list-inside space-y-1 mt-2">
                  {health.recommendations.map((rec: string, index: number) =>
                <li key={index} className="text-sm">{rec}</li>
                )}
                </ul>
              </AlertDescription>
            </Alert>
          }
        </CardContent>
      </Card>);

  };

  const renderFlowDetails = (result: CriticalFlowTestResult) => {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <Card className="w-full max-w-4xl max-h-96 overflow-hidden">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>{result.flowName} - Detailed Results</CardTitle>
              <Button variant="outline" size="sm" onClick={() => setSelectedFlow(null)}>
                Close
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-80">
              <div className="space-y-6">
                {/* Scenarios Overview */}
                <div>
                  <h4 className="font-semibold mb-3">Test Scenarios</h4>
                  <div className="space-y-3">
                    {result.scenarios.map((scenario, index) => {
                      const execution = result.executionResults[index];
                      return (
                        <div key={index} className="border rounded p-3">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              {execution ?
                              execution.status === 'passed' ?
                              <CheckCircle className="h-4 w-4 text-green-500" /> :
                              execution.status === 'failed' ?
                              <XCircle className="h-4 w-4 text-red-500" /> :

                              <AlertTriangle className="h-4 w-4 text-orange-500" /> :


                              <Clock className="h-4 w-4 text-gray-500" />
                              }
                              <span className="font-medium">{scenario.name}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline">{scenario.category}</Badge>
                              <Badge variant={scenario.priority === 'high' ? 'default' : 'secondary'}>
                                {scenario.priority}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{scenario.description}</p>
                          
                          {execution &&
                          <div className="text-xs space-y-1">
                              <div className="flex justify-between">
                                <span>Duration:</span>
                                <span>{execution.duration}ms</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Steps:</span>
                                <span>{execution.details.steps.length}</span>
                              </div>
                              {execution.details.error &&
                            <div className="text-red-600 mt-2">
                                  Error: {execution.details.error}
                                </div>
                            }
                            </div>
                          }
                        </div>);

                    })}
                  </div>
                </div>

                {/* Critical Issues */}
                {result.criticalIssues.length > 0 &&
                <div>
                    <h4 className="font-semibold mb-3 text-red-600">Critical Issues</h4>
                    <div className="space-y-2">
                      {result.criticalIssues.map((issue, index) =>
                    <Alert key={index} variant="destructive">
                          <XCircle className="h-4 w-4" />
                          <AlertDescription>{issue}</AlertDescription>
                        </Alert>
                    )}
                    </div>
                  </div>
                }

                {/* Recommendations */}
                {result.recommendations.length > 0 &&
                <div>
                    <h4 className="font-semibold mb-3">Recommendations</h4>
                    <div className="space-y-2">
                      {result.recommendations.map((rec, index) =>
                    <div key={index} className="flex items-start space-x-2 p-2 bg-blue-50 rounded">
                          <TrendingUp className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{rec}</span>
                        </div>
                    )}
                    </div>
                  </div>
                }
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>);

  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Critical Flow Test Manager</h1>
          <p className="text-gray-600">
            Automated testing for authentication, POS checkout, and reports functionality
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="autoRun"
              checked={autoRunEnabled}
              onChange={(e) => setAutoRunEnabled(e.target.checked)}
              className="rounded" />

            <label htmlFor="autoRun" className="text-sm">Auto-run every 30min</label>
          </div>
          <Button
            onClick={runAllCriticalFlows}
            disabled={testState.isRunning}
            className="bg-blue-600 hover:bg-blue-700">

            {testState.isRunning ?
            <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Running...
              </> :

            <>
                <Play className="h-4 w-4 mr-2" />
                Run All Flows
              </>
            }
          </Button>
        </div>
      </div>

      {/* Test Execution Status */}
      {testState.isRunning &&
      <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                  <span className="font-medium">Executing: {testState.currentFlow}</span>
                </div>
                <Badge variant="outline">{testState.progress}%</Badge>
              </div>
              <Progress value={testState.progress} className="w-full" />
            </div>
          </CardContent>
        </Card>
      }

      {/* Last Run Information */}
      {testState.lastRunTime &&
      <Alert>
          <Clock className="h-4 w-4" />
          <AlertDescription>
            Last comprehensive test run: {testState.lastRunTime.toLocaleString()}
            {autoRunEnabled && ' (Auto-run enabled)'}
          </AlertDescription>
        </Alert>
      }

      {/* System Health Status */}
      {renderSystemHealth()}

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="authentication">Authentication</TabsTrigger>
          <TabsTrigger value="pos">POS Checkout</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Authentication Flow Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Authentication Flow</CardTitle>
                <CardDescription>Login, logout, and role-based access tests</CardDescription>
              </CardHeader>
              <CardContent>
                {renderFlowSummary(testState.results.authentication, <Shield className="h-8 w-8 text-blue-500" />)}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-4"
                  onClick={() => runIndividualFlow('authentication')}
                  disabled={testState.isRunning}>

                  Run Auth Tests
                </Button>
              </CardContent>
            </Card>

            {/* POS Checkout Flow Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">POS Checkout Flow</CardTitle>
                <CardDescription>Product selection, cart, and payment tests</CardDescription>
              </CardHeader>
              <CardContent>
                {renderFlowSummary(testState.results.posCheckout, <ShoppingCart className="h-8 w-8 text-green-500" />)}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-4"
                  onClick={() => runIndividualFlow('posCheckout')}
                  disabled={testState.isRunning}>

                  Run POS Tests
                </Button>
              </CardContent>
            </Card>

            {/* Reports Flow Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Reports Flow</CardTitle>
                <CardDescription>Data loading, filtering, and export tests</CardDescription>
              </CardHeader>
              <CardContent>
                {renderFlowSummary(testState.results.reports, <BarChart3 className="h-8 w-8 text-purple-500" />)}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-4"
                  onClick={() => runIndividualFlow('reports')}
                  disabled={testState.isRunning}>

                  Run Report Tests
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="authentication">
          <Card>
            <CardHeader>
              <CardTitle>Authentication Flow Test Results</CardTitle>
              <CardDescription>
                Detailed results for login, logout, and role-based access control tests
              </CardDescription>
            </CardHeader>
            <CardContent>
              {testState.results.authentication ?
              <div className="space-y-4">
                  {testState.results.authentication.executionResults.map((result, index) =>
                <div key={index} className="border rounded p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {result.status === 'passed' ?
                      <CheckCircle className="h-4 w-4 text-green-500" /> :
                      result.status === 'failed' ?
                      <XCircle className="h-4 w-4 text-red-500" /> :

                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                      }
                          <span className="font-medium">
                            {testState.results.authentication.scenarios[index]?.name || 'Test'}
                          </span>
                        </div>
                        <Badge variant={result.status === 'passed' ? 'default' : 'destructive'}>
                          {result.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 mb-2">
                        Duration: {result.duration}ms | Steps: {result.details.steps.length}
                      </div>
                      {result.details.error &&
                  <Alert variant="destructive" className="mt-2">
                          <AlertDescription>{result.details.error}</AlertDescription>
                        </Alert>
                  }
                    </div>
                )}
                </div> :

              <div className="text-center py-8 text-gray-500">
                  No authentication test results available. Run tests to see results.
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pos">
          <Card>
            <CardHeader>
              <CardTitle>POS Checkout Flow Test Results</CardTitle>
              <CardDescription>
                Detailed results for product selection, cart management, and payment processing tests
              </CardDescription>
            </CardHeader>
            <CardContent>
              {testState.results.posCheckout ?
              <div className="space-y-4">
                  {testState.results.posCheckout.executionResults.map((result, index) =>
                <div key={index} className="border rounded p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {result.status === 'passed' ?
                      <CheckCircle className="h-4 w-4 text-green-500" /> :
                      result.status === 'failed' ?
                      <XCircle className="h-4 w-4 text-red-500" /> :

                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                      }
                          <span className="font-medium">
                            {testState.results.posCheckout.scenarios[index]?.name || 'Test'}
                          </span>
                        </div>
                        <Badge variant={result.status === 'passed' ? 'default' : 'destructive'}>
                          {result.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 mb-2">
                        Duration: {result.duration}ms | Steps: {result.details.steps.length}
                      </div>
                      {result.details.error &&
                  <Alert variant="destructive" className="mt-2">
                          <AlertDescription>{result.details.error}</AlertDescription>
                        </Alert>
                  }
                    </div>
                )}
                </div> :

              <div className="text-center py-8 text-gray-500">
                  No POS checkout test results available. Run tests to see results.
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Reports Flow Test Results</CardTitle>
              <CardDescription>
                Detailed results for data loading, filtering, and export functionality tests
              </CardDescription>
            </CardHeader>
            <CardContent>
              {testState.results.reports ?
              <div className="space-y-4">
                  {testState.results.reports.executionResults.map((result, index) =>
                <div key={index} className="border rounded p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {result.status === 'passed' ?
                      <CheckCircle className="h-4 w-4 text-green-500" /> :
                      result.status === 'failed' ?
                      <XCircle className="h-4 w-4 text-red-500" /> :

                      <AlertTriangle className="h-4 w-4 text-orange-500" />
                      }
                          <span className="font-medium">
                            {testState.results.reports.scenarios[index]?.name || 'Test'}
                          </span>
                        </div>
                        <Badge variant={result.status === 'passed' ? 'default' : 'destructive'}>
                          {result.status.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 mb-2">
                        Duration: {result.duration}ms | Steps: {result.details.steps.length}
                      </div>
                      {result.details.error &&
                  <Alert variant="destructive" className="mt-2">
                          <AlertDescription>{result.details.error}</AlertDescription>
                        </Alert>
                  }
                    </div>
                )}
                </div> :

              <div className="text-center py-8 text-gray-500">
                  No reports test results available. Run tests to see results.
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Flow Details Modal */}
      {selectedFlow && renderFlowDetails(selectedFlow)}
    </div>);

};

export default CriticalFlowTestManager;