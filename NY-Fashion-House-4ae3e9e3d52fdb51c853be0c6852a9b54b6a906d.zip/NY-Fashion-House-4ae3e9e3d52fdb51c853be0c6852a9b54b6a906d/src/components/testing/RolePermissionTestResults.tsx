
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  Shield,
  Users,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  AlertCircle,
  Clock,
  ChevronDown,
  ChevronRight } from
'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface RolePermissionTestResultsProps {
  results: any;
}

const RolePermissionTestResults: React.FC<RolePermissionTestResultsProps> = ({ results }) => {
  const [expandedTests, setExpandedTests] = useState<Set<string>>(new Set());

  if (!results) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-center text-muted-foreground">
            <Shield className="h-12 w-12 mx-auto mb-4" />
            <p>No role permission test results available</p>
          </div>
        </CardContent>
      </Card>);

  }

  const toggleExpanded = (testId: string) => {
    const newExpanded = new Set(expandedTests);
    if (newExpanded.has(testId)) {
      newExpanded.delete(testId);
    } else {
      newExpanded.add(testId);
    }
    setExpandedTests(newExpanded);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getAccessIcon = (access: string) => {
    switch (access) {
      case 'allow':
        return <Unlock className="h-4 w-4 text-green-500" />;
      case 'deny':
        return <Lock className="h-4 w-4 text-red-500" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed':
        return 'border-green-200 bg-green-50';
      case 'failed':
        return 'border-red-200 bg-red-50';
      case 'error':
        return 'border-yellow-200 bg-yellow-50';
      default:
        return 'border-gray-200 bg-gray-50';
    }
  };

  const roleIcons = {
    'Administrator': <Shield className="h-4 w-4" />,
    'Sales': <Users className="h-4 w-4" />,
    'General User': <Eye className="h-4 w-4" />
  };

  return (
    <Tabs defaultValue="permissions" className="space-y-4">
      <TabsList>
        <TabsTrigger value="permissions">Role Permissions</TabsTrigger>
        <TabsTrigger value="boundaries">Boundary Tests</TabsTrigger>
        <TabsTrigger value="unauthorized">Unauthorized Access</TabsTrigger>
        <TabsTrigger value="restrictions">Functionality Restrictions</TabsTrigger>
        <TabsTrigger value="summary">Summary</TabsTrigger>
      </TabsList>

      {/* Role Permissions Tab */}
      <TabsContent value="permissions" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Role Permission Test Results
            </CardTitle>
            <CardDescription>
              Validation of role-based access controls for each user role
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Role Summary */}
              <div className="grid gap-4 md:grid-cols-3">
                {['Administrator', 'Sales', 'General User'].map((roleName) => {
                  const roleTests = results.rolePermissionTests?.filter((test: any) =>
                  test.roleName.includes(roleName.split(' ')[0])) || [];
                  const passed = roleTests.filter((test: any) => test.status === 'passed').length;
                  const failed = roleTests.filter((test: any) => test.status === 'failed').length;
                  const total = roleTests.length;
                  const passRate = total > 0 ? passed / total * 100 : 0;

                  return (
                    <div key={roleName} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {roleIcons[roleName as keyof typeof roleIcons]}
                          <h4 className="font-medium">{roleName}</h4>
                        </div>
                        {getStatusIcon(passRate === 100 ? 'passed' : passRate > 70 ? 'failed' : 'error')}
                      </div>
                      <div className="space-y-2">
                        <div className="text-2xl font-bold">{passed}/{total}</div>
                        <Progress value={passRate} className="h-2" />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Passed: {passed}</span>
                          <span>Failed: {failed}</span>
                        </div>
                      </div>
                    </div>);

                })}
              </div>

              {/* Detailed Permission Tests */}
              <div className="space-y-2">
                <h4 className="font-medium">Detailed Permission Tests</h4>
                {results.rolePermissionTests?.map((test: any, index: number) =>
                <Collapsible key={index}>
                    <div className={`border rounded-lg ${getStatusColor(test.status)}`}>
                      <CollapsibleTrigger
                      className="w-full p-3 flex items-center justify-between hover:bg-opacity-80 transition-colors"
                      onClick={() => toggleExpanded(test.testId)}>

                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <div className="text-left">
                            <div className="font-medium">{test.testName}</div>
                            <div className="text-sm text-muted-foreground">
                              {test.roleName} • {test.resource} • {test.operation}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1">
                            <span className="text-xs">Expected:</span>
                            {getAccessIcon(test.expectedAccess)}
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-xs">Actual:</span>
                            {getAccessIcon(test.actualAccess)}
                          </div>
                          <Badge variant="outline">
                            <Clock className="h-3 w-3 mr-1" />
                            {test.details.responseTime}ms
                          </Badge>
                          {expandedTests.has(test.testId) ?
                        <ChevronDown className="h-4 w-4" /> :

                        <ChevronRight className="h-4 w-4" />
                        }
                        </div>
                      </CollapsibleTrigger>
                      
                      <CollapsibleContent>
                        <div className="px-3 pb-3 border-t border-opacity-50">
                          <div className="mt-3 space-y-3">
                            <div className="grid gap-4 md:grid-cols-2">
                              <div>
                                <h5 className="text-sm font-medium mb-1">Test Details</h5>
                                <div className="text-xs space-y-1">
                                  <div><strong>Role:</strong> {test.roleCode}</div>
                                  <div><strong>Resource:</strong> {test.resource}</div>
                                  <div><strong>Operation:</strong> {test.operation}</div>
                                  <div><strong>Expected Access:</strong> {test.expectedAccess}</div>
                                  <div><strong>Actual Access:</strong> {test.actualAccess}</div>
                                </div>
                              </div>
                              
                              <div>
                                <h5 className="text-sm font-medium mb-1">Performance</h5>
                                <div className="text-xs space-y-1">
                                  <div><strong>Response Time:</strong> {test.details.responseTime}ms</div>
                                  {test.details.httpStatus &&
                                <div><strong>HTTP Status:</strong> {test.details.httpStatus}</div>
                                }
                                  {test.details.unauthorizedAttempt &&
                                <div className="text-red-600">
                                      <strong>⚠️ Unauthorized Access Detected</strong>
                                    </div>
                                }
                                </div>
                              </div>
                            </div>

                            {test.details.errorMessage &&
                          <div>
                                <h5 className="text-sm font-medium mb-1 text-red-600">Error Message</h5>
                                <div className="text-xs bg-red-100 p-2 rounded text-red-800">
                                  {test.details.errorMessage}
                                </div>
                              </div>
                          }
                          </div>
                        </div>
                      </CollapsibleContent>
                    </div>
                  </Collapsible>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Boundary Tests Tab */}
      <TabsContent value="boundaries" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Permission Boundary Tests
            </CardTitle>
            <CardDescription>
              Tests that verify security boundaries and prevent unauthorized access attempts
            </CardDescription>
          </CardHeader>
          <CardContent>
            {results.boundaryTests && results.boundaryTests.length > 0 ?
            <div className="space-y-4">
                {/* Security Violations Summary */}
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                      <span className="font-medium">Security Violations</span>
                    </div>
                    <div className="text-2xl font-bold text-red-600">
                      {results.boundaryTests.filter((test: any) => test.securityViolation).length}
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="font-medium">Boundaries Secure</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      {results.boundaryTests.filter((test: any) => !test.securityViolation && test.status === 'passed').length}
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <XCircle className="h-4 w-4 text-yellow-500" />
                      <span className="font-medium">Test Failures</span>
                    </div>
                    <div className="text-2xl font-bold text-yellow-600">
                      {results.boundaryTests.filter((test: any) => test.status === 'failed' || test.status === 'error').length}
                    </div>
                  </div>
                </div>

                {/* Detailed Boundary Test Results */}
                <div className="space-y-3">
                  {results.boundaryTests.map((test: any, index: number) => {
                  const borderColor = test.securityViolation ? 'border-red-300 bg-red-50' :
                  test.status === 'passed' ? 'border-green-300 bg-green-50' :
                  'border-yellow-300 bg-yellow-50';

                  return (
                    <div key={index} className={`p-4 border rounded-lg ${borderColor}`}>
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium">{test.testName}</h4>
                          <div className="flex items-center gap-2">
                            {test.securityViolation &&
                          <Badge className="bg-red-100 text-red-800">SECURITY VIOLATION</Badge>
                          }
                            {getStatusIcon(test.status)}
                          </div>
                        </div>

                        <div className="grid gap-4 md:grid-cols-2 mb-3">
                          <div>
                            <div className="text-sm text-muted-foreground">Role</div>
                            <div className="font-medium">{test.roleCode}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Attempted Action</div>
                            <div className="font-medium">{test.attemptedAction}</div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div>
                            <div className="text-sm font-medium text-green-700">Expected Behavior</div>
                            <div className="text-sm text-green-600">{test.expectedBehavior}</div>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-blue-700">Actual Behavior</div>
                            <div className="text-sm text-blue-600">{test.actualBehavior}</div>
                          </div>
                        </div>

                        {test.details.dataLeakage &&
                      <div className="mt-3 p-3 bg-red-100 border border-red-300 rounded text-sm text-red-700">
                            <strong>⚠️ Data Leakage Detected:</strong> Sensitive data may have been exposed
                          </div>
                      }

                        {test.details.bypassAttempted &&
                      <div className="mt-3 p-3 bg-red-100 border border-red-300 rounded text-sm text-red-700">
                            <strong>⚠️ Bypass Attempt:</strong> User attempted to bypass security controls
                          </div>
                      }

                        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                          <span>Response Time: {test.details.responseTime}ms</span>
                          <span>Timestamp: {new Date(test.timestamp).toLocaleString()}</span>
                        </div>
                      </div>);

                })}
                </div>
              </div> :

            <div className="text-center py-8 text-muted-foreground">
                <Lock className="h-12 w-12 mx-auto mb-4" />
                <p>No boundary test results available</p>
              </div>
            }
          </CardContent>
        </Card>
      </TabsContent>

      {/* Unauthorized Access Tab */}
      <TabsContent value="unauthorized" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <EyeOff className="h-5 w-5" />
              Unauthorized Access Tests
            </CardTitle>
            <CardDescription>
              Tests that attempt unauthorized access to verify security controls work correctly
            </CardDescription>
          </CardHeader>
          <CardContent>
            {results.unauthorizedAccessTests && results.unauthorizedAccessTests.length > 0 ?
            <div className="space-y-3">
                {results.unauthorizedAccessTests.map((test: any, index: number) =>
              <div key={index} className={`p-4 border rounded-lg ${getStatusColor(test.status)}`}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(test.status)}
                        <h4 className="font-medium">{test.testName}</h4>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{test.roleCode}</Badge>
                        {test.details.unauthorizedAttempt &&
                    <Badge className="bg-red-100 text-red-800">UNAUTHORIZED</Badge>
                    }
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-3">
                      <div>
                        <div className="text-sm text-muted-foreground">Resource</div>
                        <div className="font-medium">{test.resource}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Operation</div>
                        <div className="font-medium">{test.operation}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Expected Result</div>
                        <div className="flex items-center gap-1">
                          {getAccessIcon(test.expectedAccess)}
                          <span className="font-medium">{test.expectedAccess}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm">
                        <span>Actual: {test.actualAccess}</span>
                        <span>Response: {test.details.responseTime}ms</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(test.timestamp).toLocaleString()}
                      </div>
                    </div>

                    {test.details.errorMessage &&
                <div className="mt-3 text-xs bg-gray-100 p-2 rounded">
                        <strong>Error:</strong> {test.details.errorMessage}
                      </div>
                }
                  </div>
              )}
              </div> :

            <div className="text-center py-8 text-muted-foreground">
                <EyeOff className="h-12 w-12 mx-auto mb-4" />
                <p>No unauthorized access test results available</p>
              </div>
            }
          </CardContent>
        </Card>
      </TabsContent>

      {/* Functionality Restrictions Tab */}
      <TabsContent value="restrictions" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Functionality Restriction Tests
            </CardTitle>
            <CardDescription>
              Tests that verify each role can only access their authorized functionality
            </CardDescription>
          </CardHeader>
          <CardContent>
            {results.functionalityRestrictionTests && results.functionalityRestrictionTests.length > 0 ?
            <div className="space-y-3">
                {results.functionalityRestrictionTests.map((test: any, index: number) =>
              <div key={index} className={`p-4 border rounded-lg ${getStatusColor(test.status)}`}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(test.status)}
                        <h4 className="font-medium">{test.testName}</h4>
                      </div>
                      <div className="flex items-center gap-2">
                        {roleIcons[test.roleName as keyof typeof roleIcons]}
                        <Badge variant="outline">{test.roleCode}</Badge>
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-3">
                      <div>
                        <div className="text-sm text-muted-foreground">Resource</div>
                        <div className="font-medium">{test.resource}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Operation</div>
                        <div className="font-medium">{test.operation}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Access Level</div>
                        <div className="flex items-center gap-1">
                          {getAccessIcon(test.expectedAccess)}
                          <span className={`font-medium ${
                      test.expectedAccess === 'allow' ? 'text-green-600' : 'text-red-600'}`
                      }>
                            {test.expectedAccess}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between text-sm">
                      <div className={`${test.status === 'passed' ? 'text-green-600' : 'text-red-600'}`}>
                        Test Result: {test.status === 'passed' ? 'Restrictions Working' : 'Restriction Failed'}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {test.details.responseTime}ms • {new Date(test.timestamp).toLocaleString()}
                      </div>
                    </div>
                  </div>
              )}
              </div> :

            <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4" />
                <p>No functionality restriction test results available</p>
              </div>
            }
          </CardContent>
        </Card>
      </TabsContent>

      {/* Summary Tab */}
      <TabsContent value="summary" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Role Permission Test Summary
            </CardTitle>
            <CardDescription>
              Overall assessment of role-based access control effectiveness
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Overall Metrics */}
              <div className="grid gap-4 md:grid-cols-5">
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold mb-1">{results.summary?.totalTests || 0}</div>
                  <div className="text-sm text-muted-foreground">Total Tests</div>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">{results.summary?.passed || 0}</div>
                  <div className="text-sm text-muted-foreground">Passed</div>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold text-red-600 mb-1">{results.summary?.failed || 0}</div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold text-yellow-600 mb-1">{results.summary?.errors || 0}</div>
                  <div className="text-sm text-muted-foreground">Errors</div>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold text-red-600 mb-1">{results.summary?.securityViolations || 0}</div>
                  <div className="text-sm text-muted-foreground">Violations</div>
                </div>
              </div>

              {/* Security Status */}
              <div className="p-6 border rounded-lg text-center">
                <div className="text-4xl font-bold mb-2">
                  {results.summary?.securityViolations === 0 ? '✅' : '❌'}
                </div>
                <div className="text-lg font-medium mb-2">
                  {results.summary?.securityViolations === 0 ? 'Security Compliant' : 'Security Issues Detected'}
                </div>
                <div className="text-sm text-muted-foreground">
                  {results.summary?.securityViolations === 0 ?
                  'All role-based access controls are working correctly' :
                  `${results.summary?.securityViolations} security violations found`}
                </div>
              </div>

              {/* Pass Rate Progress */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Overall Pass Rate</span>
                  <span className="text-sm">
                    {results.summary && results.summary.totalTests > 0 ?
                    (results.summary.passed / results.summary.totalTests * 100).toFixed(1) : 0}%
                  </span>
                </div>
                <Progress
                  value={results.summary && results.summary.totalTests > 0 ?
                  results.summary.passed / results.summary.totalTests * 100 : 0}
                  className="h-3" />

              </div>

              {/* Execution Time */}
              {results.summary?.executionTime &&
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Total Execution Time</span>
                  </div>
                  <span className="text-sm">
                    {(results.summary.executionTime / 1000).toFixed(2)}s
                  </span>
                </div>
              }
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>);

};

export default RolePermissionTestResults;