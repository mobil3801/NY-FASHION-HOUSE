
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Activity, Globe, Shield, Brain, Zap,
  CheckCircle, XCircle, AlertTriangle, Clock,
  TrendingUp, TrendingDown, RefreshCw, Play,
  Bug, Network, Component, Memory, Lock } from
'lucide-react';
import AutomatedTestRunner from './AutomatedTestRunner';
import CrossBrowserTestManager from '../performance/CrossBrowserTestManager';
import CrossBrowserErrorTestDashboard from './CrossBrowserErrorTestDashboard';
import PerformanceTestDashboard from '../performance/PerformanceTestDashboard';
import { comprehensiveTestManager, ComprehensiveTestReport } from '@/services/comprehensiveTestManager';
import { crossBrowserErrorTestService } from '@/services/crossBrowserErrorTestService';
import { toast } from 'sonner';

interface TestSuiteStatus {
  name: string;
  isRunning: boolean;
  lastRun?: Date;
  status: 'pending' | 'running' | 'completed' | 'error';
  results?: any;
}

interface OverallHealthMetrics {
  systemHealth: number;
  errorHandling: number;
  crossBrowserCompatibility: number;
  performance: number;
  security: number;
  dataIntegrity: number;
  overallScore: number;
}

const EnhancedComprehensiveTestDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [comprehensiveReport, setComprehensiveReport] = useState<ComprehensiveTestReport | null>(null);
  const [healthMetrics, setHealthMetrics] = useState<OverallHealthMetrics | null>(null);
  const [testSuites, setTestSuites] = useState<TestSuiteStatus[]>([
  { name: 'Data Integrity Tests', isRunning: false, status: 'pending' },
  { name: 'Cross-Browser Error Tests', isRunning: false, status: 'pending' },
  { name: 'Performance Tests', isRunning: false, status: 'pending' },
  { name: 'Security Tests', isRunning: false, status: 'pending' },
  { name: 'Automated Flow Tests', isRunning: false, status: 'pending' }]
  );
  const [isRunningAll, setIsRunningAll] = useState(false);

  useEffect(() => {
    // Load initial health metrics
    loadHealthMetrics();
  }, []);

  const loadHealthMetrics = async () => {
    try {
      const healthCheck = await comprehensiveTestManager.generateQuickHealthCheck();

      const metrics: OverallHealthMetrics = {
        systemHealth: healthCheck.score,
        errorHandling: Math.max(0, healthCheck.score - healthCheck.issues.length * 10),
        crossBrowserCompatibility: 85, // Default value
        performance: 78, // Default value
        security: healthCheck.issues.some((i) => i.includes('security')) ? 60 : 90,
        dataIntegrity: healthCheck.issues.some((i) => i.includes('data')) ? 70 : 95,
        overallScore: healthCheck.score
      };

      setHealthMetrics(metrics);

      if (healthCheck.status === 'critical') {
        toast.error('Critical system health issues detected');
      } else if (healthCheck.status === 'warning') {
        toast.warning('System health warnings detected');
      }
    } catch (error) {
      console.error('Error loading health metrics:', error);
      toast.error('Failed to load system health metrics');
    }
  };

  const runAllTests = async () => {
    setIsRunningAll(true);

    try {
      // Update all test suites to running
      setTestSuites((prev) => prev.map((suite) => ({ ...suite, isRunning: true, status: 'running' as const })));

      toast.info('Starting comprehensive test suite execution...');

      // Run comprehensive tests
      const report = await comprehensiveTestManager.runComprehensiveTests();
      setComprehensiveReport(report);

      // Run cross-browser error tests
      const errorTestReport = await crossBrowserErrorTestService.runCrossBrowserErrorTests();

      // Update test suites status
      setTestSuites((prev) => prev.map((suite) => ({
        ...suite,
        isRunning: false,
        status: 'completed' as const,
        lastRun: new Date(),
        results: suite.name.includes('Cross-Browser') ? errorTestReport : report
      })));

      // Update health metrics based on results
      const newMetrics: OverallHealthMetrics = {
        systemHealth: report.overallSummary.passRate,
        errorHandling: errorTestReport.summary.errorRecoveryScore,
        crossBrowserCompatibility: Object.values(errorTestReport.summary.browserCompatibility).reduce((a, b) => a + b, 0) / 4,
        performance: 75, // Would be updated by actual performance tests
        security: report.overallSummary.securityViolations === 0 ? 95 : Math.max(60, 95 - report.overallSummary.securityViolations * 10),
        dataIntegrity: report.testCategories.dataIntegrity.summary.passRate,
        overallScore: (report.overallSummary.passRate + errorTestReport.summary.errorRecoveryScore) / 2
      };

      setHealthMetrics(newMetrics);

      toast.success(`All tests completed! Overall score: ${Math.round(newMetrics.overallScore)}%`);

    } catch (error) {
      console.error('Error running comprehensive tests:', error);
      toast.error('Failed to complete all tests');

      // Reset test suites on error
      setTestSuites((prev) => prev.map((suite) => ({ ...suite, isRunning: false, status: 'error' as const })));
    } finally {
      setIsRunningAll(false);
    }
  };

  const runSingleTestSuite = async (suiteName: string) => {
    // Update specific test suite status
    setTestSuites((prev) => prev.map((suite) =>
    suite.name === suiteName ?
    { ...suite, isRunning: true, status: 'running' as const } :
    suite
    ));

    try {
      let results;

      switch (suiteName) {
        case 'Data Integrity Tests':
          results = await comprehensiveTestManager.runComprehensiveTests();
          setComprehensiveReport(results);
          break;
        case 'Cross-Browser Error Tests':
          results = await crossBrowserErrorTestService.runCrossBrowserErrorTests();
          break;
        default:
          // Simulate test execution for other suites
          await new Promise((resolve) => setTimeout(resolve, 2000));
          results = { status: 'completed' };
      }

      setTestSuites((prev) => prev.map((suite) =>
      suite.name === suiteName ?
      { ...suite, isRunning: false, status: 'completed' as const, lastRun: new Date(), results } :
      suite
      ));

      toast.success(`${suiteName} completed successfully`);

    } catch (error) {
      console.error(`Error running ${suiteName}:`, error);
      setTestSuites((prev) => prev.map((suite) =>
      suite.name === suiteName ?
      { ...suite, isRunning: false, status: 'error' as const } :
      suite
      ));
      toast.error(`${suiteName} failed`);
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    if (score >= 50) return 'text-orange-600';
    return 'text-red-600';
  };

  const getHealthIcon = (score: number) => {
    if (score >= 90) return <CheckCircle className="h-5 w-5 text-green-500" />;
    if (score >= 70) return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
    return <XCircle className="h-5 w-5 text-red-500" />;
  };

  const renderOverview = () =>
  <div className="space-y-6">
      {/* System Health Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            System Health Overview
          </CardTitle>
          <CardDescription>
            Real-time monitoring of system health and test results
          </CardDescription>
        </CardHeader>
        <CardContent>
          {healthMetrics ?
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className="text-center space-y-2">
                <div className={`text-2xl font-bold ${getHealthColor(healthMetrics.systemHealth)}`}>
                  {Math.round(healthMetrics.systemHealth)}%
                </div>
                <div className="text-sm text-gray-600">System Health</div>
                {getHealthIcon(healthMetrics.systemHealth)}
              </div>
              
              <div className="text-center space-y-2">
                <div className={`text-2xl font-bold ${getHealthColor(healthMetrics.errorHandling)}`}>
                  {Math.round(healthMetrics.errorHandling)}%
                </div>
                <div className="text-sm text-gray-600">Error Handling</div>
                {getHealthIcon(healthMetrics.errorHandling)}
              </div>
              
              <div className="text-center space-y-2">
                <div className={`text-2xl font-bold ${getHealthColor(healthMetrics.crossBrowserCompatibility)}`}>
                  {Math.round(healthMetrics.crossBrowserCompatibility)}%
                </div>
                <div className="text-sm text-gray-600">Cross-Browser</div>
                {getHealthIcon(healthMetrics.crossBrowserCompatibility)}
              </div>
              
              <div className="text-center space-y-2">
                <div className={`text-2xl font-bold ${getHealthColor(healthMetrics.performance)}`}>
                  {Math.round(healthMetrics.performance)}%
                </div>
                <div className="text-sm text-gray-600">Performance</div>
                {getHealthIcon(healthMetrics.performance)}
              </div>
              
              <div className="text-center space-y-2">
                <div className={`text-2xl font-bold ${getHealthColor(healthMetrics.security)}`}>
                  {Math.round(healthMetrics.security)}%
                </div>
                <div className="text-sm text-gray-600">Security</div>
                {getHealthIcon(healthMetrics.security)}
              </div>
              
              <div className="text-center space-y-2">
                <div className={`text-2xl font-bold ${getHealthColor(healthMetrics.dataIntegrity)}`}>
                  {Math.round(healthMetrics.dataIntegrity)}%
                </div>
                <div className="text-sm text-gray-600">Data Integrity</div>
                {getHealthIcon(healthMetrics.dataIntegrity)}
              </div>
            </div> :

        <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
              <span className="ml-2">Loading health metrics...</span>
            </div>
        }
          
          {healthMetrics &&
        <div className="mt-6 pt-6 border-t">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Overall System Score</span>
                <span className={`text-lg font-bold ${getHealthColor(healthMetrics.overallScore)}`}>
                  {Math.round(healthMetrics.overallScore)}%
                </span>
              </div>
              <Progress value={healthMetrics.overallScore} className="h-3" />
            </div>
        }
        </CardContent>
      </Card>

      {/* Test Suites Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Test Suites
            </div>
            <Button
            onClick={runAllTests}
            disabled={isRunningAll}
            className="flex items-center gap-2">

              {isRunningAll ?
            <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                  Running All Tests...
                </> :

            <>
                  <Play className="h-4 w-4" />
                  Run All Tests
                </>
            }
            </Button>
          </CardTitle>
          <CardDescription>
            Individual test suite status and controls
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {testSuites.map((suite, index) =>
          <div key={index} className="flex items-center justify-between p-4 border rounded">
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0">
                    {suite.name.includes('Error') && <Bug className="h-5 w-5 text-red-500" />}
                    {suite.name.includes('Performance') && <Zap className="h-5 w-5 text-blue-500" />}
                    {suite.name.includes('Data') && <Shield className="h-5 w-5 text-green-500" />}
                    {suite.name.includes('Security') && <Lock className="h-5 w-5 text-orange-500" />}
                    {suite.name.includes('Automated') && <Activity className="h-5 w-5 text-purple-500" />}
                  </div>
                  <div>
                    <div className="font-medium">{suite.name}</div>
                    {suite.lastRun &&
                <div className="text-sm text-gray-500">
                        Last run: {suite.lastRun.toLocaleString()}
                      </div>
                }
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  {suite.isRunning ?
              <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                      <Badge variant="outline">Running</Badge>
                    </div> :

              <>
                      <Badge variant={
                suite.status === 'completed' ? 'default' :
                suite.status === 'error' ? 'destructive' :
                'secondary'
                }>
                        {suite.status}
                      </Badge>
                      <Button
                  variant="outline"
                  size="sm"
                  onClick={() => runSingleTestSuite(suite.name)}
                  disabled={isRunningAll}>

                        Run
                      </Button>
                    </>
              }
                </div>
              </div>
          )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab('error-testing')}>
          <CardContent className="p-6 text-center">
            <Bug className="h-8 w-8 text-red-500 mx-auto mb-2" />
            <h3 className="font-semibold mb-1">Error Testing</h3>
            <p className="text-sm text-gray-600">Cross-browser error scenarios</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab('performance')}>
          <CardContent className="p-6 text-center">
            <Zap className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <h3 className="font-semibold mb-1">Performance</h3>
            <p className="text-sm text-gray-600">Load testing & optimization</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab('automated')}>
          <CardContent className="p-6 text-center">
            <Activity className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <h3 className="font-semibold mb-1">Automated Tests</h3>
            <p className="text-sm text-gray-600">Critical flow validation</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setActiveTab('cross-browser')}>
          <CardContent className="p-6 text-center">
            <Globe className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <h3 className="font-semibold mb-1">Cross-Browser</h3>
            <p className="text-sm text-gray-600">Compatibility testing</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Issues Alert */}
      {comprehensiveReport && comprehensiveReport.criticalFindings.length > 0 &&
    <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Critical Issues Detected:</strong> {comprehensiveReport.criticalFindings.length} critical findings require immediate attention.
            <Button variant="link" className="p-0 h-auto ml-2 text-red-600" onClick={() => setActiveTab('comprehensive')}>
              View Details →
            </Button>
          </AlertDescription>
        </Alert>
    }
    </div>;


  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Comprehensive Test Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Complete testing suite with error scenarios, performance monitoring, and cross-browser validation
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            onClick={loadHealthMetrics}
            disabled={isRunningAll}>

            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Health
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="error-testing" className="flex items-center gap-2">
            <Bug className="h-4 w-4" />
            Error Testing
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="automated" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Automated
          </TabsTrigger>
          <TabsTrigger value="cross-browser" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            Cross-Browser
          </TabsTrigger>
          <TabsTrigger value="comprehensive" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Comprehensive
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {renderOverview()}
        </TabsContent>

        <TabsContent value="error-testing" className="space-y-6">
          <CrossBrowserErrorTestDashboard />
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <PerformanceTestDashboard />
        </TabsContent>

        <TabsContent value="automated" className="space-y-6">
          <AutomatedTestRunner />
        </TabsContent>

        <TabsContent value="cross-browser" className="space-y-6">
          <CrossBrowserTestManager />
        </TabsContent>

        <TabsContent value="comprehensive" className="space-y-6">
          {comprehensiveReport ?
          <Card>
              <CardHeader>
                <CardTitle>Comprehensive Test Report</CardTitle>
                <CardDescription>
                  Detailed results from all test categories
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{comprehensiveReport.overallSummary.totalTests}</div>
                    <div className="text-sm text-gray-600">Total Tests</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{comprehensiveReport.overallSummary.passed}</div>
                    <div className="text-sm text-gray-600">Passed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">{comprehensiveReport.overallSummary.failed}</div>
                    <div className="text-sm text-gray-600">Failed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">{comprehensiveReport.overallSummary.criticalIssues}</div>
                    <div className="text-sm text-gray-600">Critical Issues</div>
                  </div>
                </div>
                
                <Progress value={comprehensiveReport.overallSummary.passRate} className="h-3 mb-6" />
                
                {comprehensiveReport.recommendations.length > 0 &&
              <div className="space-y-3">
                    <h3 className="font-semibold">Recommendations</h3>
                    {comprehensiveReport.recommendations.slice(0, 5).map((rec, index) =>
                <Alert key={index} className={
                rec.priority === 'critical' ? 'border-red-200 bg-red-50' :
                rec.priority === 'high' ? 'border-orange-200 bg-orange-50' :
                'border-yellow-200 bg-yellow-50'
                }>
                        <AlertDescription>
                          <strong>{rec.category}:</strong> {rec.recommendation}
                        </AlertDescription>
                      </Alert>
                )}
                  </div>
              }
              </CardContent>
            </Card> :

          <Card>
              <CardContent className="p-8 text-center">
                <Brain className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Comprehensive Report Available</h3>
                <p className="text-gray-600 mb-4">Run the comprehensive test suite to see detailed results</p>
                <Button onClick={() => runSingleTestSuite('Data Integrity Tests')}>
                  Run Comprehensive Tests
                </Button>
              </CardContent>
            </Card>
          }
        </TabsContent>
      </Tabs>
    </div>);

};

export default EnhancedComprehensiveTestDashboard;