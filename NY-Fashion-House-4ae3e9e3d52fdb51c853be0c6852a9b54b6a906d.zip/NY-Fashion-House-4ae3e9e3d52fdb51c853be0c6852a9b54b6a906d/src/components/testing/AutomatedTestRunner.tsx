
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, XCircle, AlertCircle, Clock, Play, Pause, RefreshCw } from 'lucide-react';
import { automatedTestSuites, TestExecutionResult } from '@/services/automatedTestSuites';
import { qaTestingService } from '@/services/qaTestingService';
import { toast } from 'sonner';

interface TestRunnerState {
  isRunning: boolean;
  currentSuite: string | null;
  progress: number;
  results: {
    authentication: TestExecutionResult[];
    posCheckout: TestExecutionResult[];
    reports: TestExecutionResult[];
  };
  summary: {
    totalTests: number;
    passed: number;
    failed: number;
    errors: number;
    duration: number;
  } | null;
}

const AutomatedTestRunner: React.FC = () => {
  const [testState, setTestState] = useState<TestRunnerState>({
    isRunning: false,
    currentSuite: null,
    progress: 0,
    results: {
      authentication: [],
      posCheckout: [],
      reports: []
    },
    summary: null
  });

  const [testHistory, setTestHistory] = useState<any[]>([]);
  const [selectedTest, setSelectedTest] = useState<TestExecutionResult | null>(null);

  useEffect(() => {
    loadTestHistory();
  }, []);

  const loadTestHistory = async () => {
    try {
      const executions = await qaTestingService.getRecentExecutions(20);
      setTestHistory(executions);
    } catch (error) {
      console.error('Error loading test history:', error);
      toast.error('Failed to load test history');
    }
  };

  const runAllTests = async () => {
    setTestState((prev) => ({
      ...prev,
      isRunning: true,
      progress: 0,
      currentSuite: 'Initializing...',
      results: {
        authentication: [],
        posCheckout: [],
        reports: []
      },
      summary: null
    }));

    try {
      // Update progress as we run different suites
      setTestState((prev) => ({ ...prev, currentSuite: 'Authentication Tests', progress: 10 }));
      const authResults = await automatedTestSuites.executeAuthenticationTests();
      setTestState((prev) => ({
        ...prev,
        results: { ...prev.results, authentication: authResults },
        progress: 40
      }));

      setTestState((prev) => ({ ...prev, currentSuite: 'POS Checkout Tests', progress: 45 }));
      const posResults = await automatedTestSuites.executePOSCheckoutTests();
      setTestState((prev) => ({
        ...prev,
        results: { ...prev.results, posCheckout: posResults },
        progress: 70
      }));

      setTestState((prev) => ({ ...prev, currentSuite: 'Reports Tests', progress: 75 }));
      const reportsResults = await automatedTestSuites.executeReportsTests();
      setTestState((prev) => ({
        ...prev,
        results: { ...prev.results, reports: reportsResults },
        progress: 95
      }));

      // Calculate summary
      const allResults = [...authResults, ...posResults, ...reportsResults];
      const summary = {
        totalTests: allResults.length,
        passed: allResults.filter((r) => r.status === 'passed').length,
        failed: allResults.filter((r) => r.status === 'failed').length,
        errors: allResults.filter((r) => r.status === 'error').length,
        duration: allResults.reduce((sum, r) => sum + r.duration, 0)
      };

      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentSuite: null,
        progress: 100,
        summary
      }));

      // Record execution in database
      await qaTestingService.startTestExecution(1, `Automated Test Run - ${new Date().toLocaleString()}`);

      toast.success(`Test execution completed: ${summary.passed}/${summary.totalTests} tests passed`);

      // Reload history to show new execution
      await loadTestHistory();

    } catch (error) {
      console.error('Error running automated tests:', error);
      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentSuite: null
      }));
      toast.error('Test execution failed');
    }
  };

  const runSingleSuite = async (suiteType: 'authentication' | 'posCheckout' | 'reports') => {
    setTestState((prev) => ({
      ...prev,
      isRunning: true,
      currentSuite: suiteType,
      progress: 0
    }));

    try {
      let results: TestExecutionResult[] = [];

      switch (suiteType) {
        case 'authentication':
          results = await automatedTestSuites.executeAuthenticationTests();
          break;
        case 'posCheckout':
          results = await automatedTestSuites.executePOSCheckoutTests();
          break;
        case 'reports':
          results = await automatedTestSuites.executeReportsTests();
          break;
      }

      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentSuite: null,
        progress: 100,
        results: {
          ...prev.results,
          [suiteType]: results
        }
      }));

      const passed = results.filter((r) => r.status === 'passed').length;
      toast.success(`${suiteType} tests completed: ${passed}/${results.length} passed`);

    } catch (error) {
      console.error(`Error running ${suiteType} tests:`, error);
      setTestState((prev) => ({
        ...prev,
        isRunning: false,
        currentSuite: null
      }));
      toast.error(`${suiteType} test execution failed`);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-orange-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed':
        return 'bg-green-500';
      case 'failed':
        return 'bg-red-500';
      case 'error':
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  const renderTestResults = (results: TestExecutionResult[], suiteName: string) => {
    if (results.length === 0) {
      return (
        <div className="text-center py-8 text-gray-500">
          No test results available. Run tests to see results.
        </div>);

    }

    return (
      <div className="space-y-4">
        {results.map((result, index) =>
        <Card
          key={`${suiteName}-${index}`}
          className="cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => setSelectedTest(result)}>

            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {getStatusIcon(result.status)}
                  <div>
                    <h4 className="font-medium">Test #{index + 1}</h4>
                    <p className="text-sm text-gray-600">Duration: {result.duration}ms</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={result.status === 'passed' ? 'default' : 'destructive'}>
                    {result.status.toUpperCase()}
                  </Badge>
                  <div className="text-right">
                    <div className="text-sm font-medium">
                      {result.details.steps.filter((s) => s.status === 'passed').length}/
                      {result.details.steps.length} steps
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>);

  };

  const renderTestDetails = (test: TestExecutionResult) => {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              {getStatusIcon(test.status)}
              <span>Test Details</span>
            </CardTitle>
            <Button variant="outline" size="sm" onClick={() => setSelectedTest(null)}>
              Close
            </Button>
          </div>
          <CardDescription>
            Test ID: {test.testId} | Duration: {test.duration}ms
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">Test Steps</h4>
              <div className="space-y-2">
                {test.details.steps.map((step, index) =>
                <div key={index} className="flex items-center space-x-3 p-2 rounded border">
                    {getStatusIcon(step.status)}
                    <div className="flex-1">
                      <div className="font-medium">{step.step}</div>
                      <div className="text-sm text-gray-600">{step.message}</div>
                      <div className="text-xs text-gray-400">{step.timestamp.toLocaleString()}</div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {test.details.error &&
            <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{test.details.error}</AlertDescription>
              </Alert>
            }

            <div>
              <h4 className="font-medium mb-2">Actual Result</h4>
              <div className="p-3 bg-gray-50 rounded border">
                {test.details.actualResult}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>);

  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Automated Test Suites</h1>
          <p className="text-gray-600">
            Comprehensive testing for critical application flows
          </p>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            onClick={loadTestHistory}
            disabled={testState.isRunning}>

            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button
            onClick={runAllTests}
            disabled={testState.isRunning}
            className="bg-blue-600 hover:bg-blue-700">

            {testState.isRunning ?
            <>
                <Pause className="h-4 w-4 mr-2" />
                Running...
              </> :

            <>
                <Play className="h-4 w-4 mr-2" />
                Run All Tests
              </>
            }
          </Button>
        </div>
      </div>

      {/* Test Execution Status */}
      {testState.isRunning &&
      <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                  <span className="font-medium">Running: {testState.currentSuite}</span>
                </div>
                <Badge variant="outline">{testState.progress}%</Badge>
              </div>
              <Progress value={testState.progress} className="w-full" />
            </div>
          </CardContent>
        </Card>
      }

      {/* Test Summary */}
      {testState.summary &&
      <Card>
          <CardHeader>
            <CardTitle>Test Execution Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{testState.summary.totalTests}</div>
                <div className="text-sm text-gray-600">Total Tests</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{testState.summary.passed}</div>
                <div className="text-sm text-gray-600">Passed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{testState.summary.failed}</div>
                <div className="text-sm text-gray-600">Failed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{testState.summary.errors}</div>
                <div className="text-sm text-gray-600">Errors</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{Math.round(testState.summary.duration / 1000)}s</div>
                <div className="text-sm text-gray-600">Duration</div>
              </div>
            </div>

            <div className="mt-4">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-sm font-medium">Success Rate:</span>
                <Badge variant={testState.summary.passed / testState.summary.totalTests >= 0.9 ? 'default' : 'destructive'}>
                  {Math.round(testState.summary.passed / testState.summary.totalTests * 100)}%
                </Badge>
              </div>
              <Progress
              value={testState.summary.passed / testState.summary.totalTests * 100}
              className="w-full" />

            </div>
          </CardContent>
        </Card>
      }

      {/* Test Results */}
      <Tabs defaultValue="authentication" className="w-full">
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="authentication" className="flex items-center space-x-2">
              <span>Authentication</span>
              {testState.results.authentication.length > 0 &&
              <Badge variant="outline" className="ml-1">
                  {testState.results.authentication.filter((r) => r.status === 'passed').length}/
                  {testState.results.authentication.length}
                </Badge>
              }
            </TabsTrigger>
            <TabsTrigger value="pos" className="flex items-center space-x-2">
              <span>POS Checkout</span>
              {testState.results.posCheckout.length > 0 &&
              <Badge variant="outline" className="ml-1">
                  {testState.results.posCheckout.filter((r) => r.status === 'passed').length}/
                  {testState.results.posCheckout.length}
                </Badge>
              }
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center space-x-2">
              <span>Reports</span>
              {testState.results.reports.length > 0 &&
              <Badge variant="outline" className="ml-1">
                  {testState.results.reports.filter((r) => r.status === 'passed').length}/
                  {testState.results.reports.length}
                </Badge>
              }
            </TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => runSingleSuite('authentication')}
              disabled={testState.isRunning}>

              Run Auth Tests
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => runSingleSuite('posCheckout')}
              disabled={testState.isRunning}>

              Run POS Tests
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => runSingleSuite('reports')}
              disabled={testState.isRunning}>

              Run Report Tests
            </Button>
          </div>
        </div>

        <TabsContent value="authentication">
          <Card>
            <CardHeader>
              <CardTitle>Authentication Flow Tests</CardTitle>
              <CardDescription>
                Tests for login, logout, role-based access, and session management
              </CardDescription>
            </CardHeader>
            <CardContent>
              {renderTestResults(testState.results.authentication, 'authentication')}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pos">
          <Card>
            <CardHeader>
              <CardTitle>POS Checkout Workflow Tests</CardTitle>
              <CardDescription>
                End-to-end tests for product selection, cart management, and payment processing
              </CardDescription>
            </CardHeader>
            <CardContent>
              {renderTestResults(testState.results.posCheckout, 'pos')}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Reports and Dashboard Tests</CardTitle>
              <CardDescription>
                Tests for data loading, filtering, export features, and dashboard functionality
              </CardDescription>
            </CardHeader>
            <CardContent>
              {renderTestResults(testState.results.reports, 'reports')}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Test Execution History</CardTitle>
              <CardDescription>
                Previous test executions and their results
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-2">
                  {testHistory.map((execution, index) =>
                  <div key={execution.id || index} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <div className="font-medium">{execution.execution_name}</div>
                        <div className="text-sm text-gray-600">
                          {new Date(execution.started_at).toLocaleString()}
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-sm">
                          <span className="text-green-600">{execution.passed_tests || 0} passed</span> / 
                          <span className="text-red-600 ml-1">{execution.failed_tests || 0} failed</span>
                        </div>
                        <Badge variant={execution.status === 'completed' ? 'default' : 'destructive'}>
                          {execution.status}
                        </Badge>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Test Details Modal */}
      {selectedTest &&
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-4xl max-h-96 overflow-hidden">
            <ScrollArea className="h-96">
              <div className="p-6">
                {renderTestDetails(selectedTest)}
              </div>
            </ScrollArea>
          </div>
        </div>
      }
    </div>);

};

export default AutomatedTestRunner;