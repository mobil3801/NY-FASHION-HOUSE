import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Download,
  FileText,
  Code,
  Calendar,
  Clock,
  Target,
  BarChart3,
  Activity,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  ExternalLink } from
'lucide-react';
import { DetailedTestReport } from '@/services/apiTestReportingService';

interface TestReportViewerProps {
  currentReport: DetailedTestReport | null;
  onExportReport: (format: 'json' | 'html') => void;
}

export const TestReportViewer: React.FC<TestReportViewerProps> = ({
  currentReport,
  onExportReport
}) => {
  const [selectedReport, setSelectedReport] = useState<DetailedTestReport | null>(currentReport);

  if (!selectedReport) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-600">No test report available.</p>
          <p className="text-sm text-gray-500 mt-1">Run tests to generate a comprehensive report.</p>
        </CardContent>
      </Card>);

  }

  const formatDuration = (ms: number): string => {
    if (ms < 1000) return `${ms.toFixed(0)}ms`;
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    }
    return `${seconds}s`;
  };

  return (
    <div className="space-y-6">
      {/* Report Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Test Report: {selectedReport.reportId}
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Generated on {selectedReport.generatedAt.toLocaleDateString()} at {selectedReport.generatedAt.toLocaleTimeString()}
              </p>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => onExportReport('html')}
                className="flex items-center">

                <FileText className="h-4 w-4 mr-2" />
                Export HTML
              </Button>
              <Button
                variant="outline"
                onClick={() => onExportReport('json')}
                className="flex items-center">

                <Code className="h-4 w-4 mr-2" />
                Export JSON
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">
                {selectedReport.executionSummary.successRate.toFixed(1)}%
              </p>
              <p className="text-sm text-gray-600">Success Rate</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">
                {selectedReport.executionSummary.totalTests}
              </p>
              <p className="text-sm text-gray-600">Total Tests</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-purple-600">
                {selectedReport.coverageAnalysis.coveragePercentage.toFixed(1)}%
              </p>
              <p className="text-sm text-gray-600">Coverage</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">
                {formatDuration(selectedReport.executionSummary.totalExecutionTime)}
              </p>
              <p className="text-sm text-gray-600">Duration</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Content */}
      <Tabs defaultValue="executive-summary" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="executive-summary">Executive Summary</TabsTrigger>
          <TabsTrigger value="test-execution">Test Execution</TabsTrigger>
          <TabsTrigger value="error-handling">Error Handling</TabsTrigger>
          <TabsTrigger value="validation">Validation</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="executive-summary" className="space-y-6">
          {/* Overall Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-5 w-5 mr-2" />
                Test Execution Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-green-600">
                    {selectedReport.executionSummary.passed}
                  </p>
                  <p className="text-sm text-green-700">Passed</p>
                </div>

                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-red-600">
                    {selectedReport.executionSummary.failed}
                  </p>
                  <p className="text-sm text-red-700">Failed</p>
                </div>

                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <AlertTriangle className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-yellow-600">
                    {selectedReport.executionSummary.errors}
                  </p>
                  <p className="text-sm text-yellow-700">Errors</p>
                </div>

                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <Clock className="h-8 w-8 text-orange-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-orange-600">
                    {selectedReport.executionSummary.timeouts}
                  </p>
                  <p className="text-sm text-orange-700">Timeouts</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Critical Issues */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-red-600">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Critical Issues
                <Badge variant="outline" className="ml-2">
                  {selectedReport.issueSummary.criticalIssues.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedReport.issueSummary.criticalIssues.length > 0 ?
              <div className="space-y-3">
                  {selectedReport.issueSummary.criticalIssues.map((issue, index) =>
                <div key={index} className="flex items-start space-x-3 p-3 bg-red-50 border-l-4 border-red-400 rounded-r">
                      <AlertTriangle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-red-800">{issue}</p>
                    </div>
                )}
                </div> :

              <div className="text-center py-6">
                  <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <p className="text-green-600 font-medium">No critical issues found!</p>
                  <p className="text-sm text-gray-500">Your API endpoints are functioning properly.</p>
                </div>
              }
            </CardContent>
          </Card>

          {/* Top Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-blue-600">
                <TrendingUp className="h-5 w-5 mr-2" />
                Key Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {selectedReport.issueSummary.recommendations.slice(0, 5).map((rec, index) =>
                <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 border-l-4 border-blue-400 rounded-r">
                    <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 mt-2"></div>
                    <p className="text-sm text-blue-800">{rec}</p>
                  </div>
                )}
                {selectedReport.issueSummary.recommendations.length > 5 &&
                <p className="text-sm text-gray-500 text-center">
                    +{selectedReport.issueSummary.recommendations.length - 5} more recommendations
                  </p>
                }
              </div>
            </CardContent>
          </Card>

          {/* Coverage Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Coverage Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Endpoint Coverage</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-48 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${selectedReport.coverageAnalysis.coveragePercentage}%` }}>
                      </div>
                    </div>
                    <span className="text-sm font-medium">
                      {selectedReport.coverageAnalysis.coveragePercentage.toFixed(1)}%
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Total Endpoints:</span>
                    <span className="ml-2 font-medium">{selectedReport.coverageAnalysis.totalEndpoints}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Tested Endpoints:</span>
                    <span className="ml-2 font-medium">{selectedReport.coverageAnalysis.testedEndpoints}</span>
                  </div>
                </div>
                {selectedReport.coverageAnalysis.untestedEndpoints.length > 0 &&
                <div className="bg-yellow-50 p-3 rounded">
                    <p className="text-sm font-medium text-yellow-800 mb-2">Untested Endpoints:</p>
                    <div className="flex flex-wrap gap-1">
                      {selectedReport.coverageAnalysis.untestedEndpoints.slice(0, 10).map((endpoint, index) =>
                    <Badge key={index} variant="outline" className="text-xs">
                          {endpoint}
                        </Badge>
                    )}
                      {selectedReport.coverageAnalysis.untestedEndpoints.length > 10 &&
                    <Badge variant="outline" className="text-xs">
                          +{selectedReport.coverageAnalysis.untestedEndpoints.length - 10} more
                        </Badge>
                    }
                    </div>
                  </div>
                }
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="test-execution" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2" />
                Test Execution Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Execution Timeline</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Started:</span>
                      <span className="font-medium">{selectedReport.startTime.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Completed:</span>
                      <span className="font-medium">{selectedReport.endTime.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Duration:</span>
                      <span className="font-medium">
                        {formatDuration(selectedReport.executionSummary.totalExecutionTime)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Test Configuration</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Max Retries:</span>
                      <span className="font-medium">{selectedReport.testConfiguration.maxRetries}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Parallel Execution:</span>
                      <span className="font-medium">
                        {selectedReport.testConfiguration.parallelExecution ? 'Yes' : 'No'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Stop on Failure:</span>
                      <span className="font-medium">
                        {selectedReport.testConfiguration.stopOnFirstFailure ? 'Yes' : 'No'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Test Results by Status */}
              <div className="mt-6">
                <h4 className="font-medium text-gray-900 mb-3">Results Breakdown</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-green-50 p-3 rounded text-center">
                    <p className="text-lg font-bold text-green-600">
                      {selectedReport.executionSummary.passed}
                    </p>
                    <p className="text-sm text-green-700">Passed</p>
                    <p className="text-xs text-green-600">
                      {(selectedReport.executionSummary.passed / selectedReport.executionSummary.totalTests * 100).toFixed(1)}%
                    </p>
                  </div>

                  <div className="bg-red-50 p-3 rounded text-center">
                    <p className="text-lg font-bold text-red-600">
                      {selectedReport.executionSummary.failed}
                    </p>
                    <p className="text-sm text-red-700">Failed</p>
                    <p className="text-xs text-red-600">
                      {(selectedReport.executionSummary.failed / selectedReport.executionSummary.totalTests * 100).toFixed(1)}%
                    </p>
                  </div>

                  <div className="bg-yellow-50 p-3 rounded text-center">
                    <p className="text-lg font-bold text-yellow-600">
                      {selectedReport.executionSummary.errors}
                    </p>
                    <p className="text-sm text-yellow-700">Errors</p>
                    <p className="text-xs text-yellow-600">
                      {(selectedReport.executionSummary.errors / selectedReport.executionSummary.totalTests * 100).toFixed(1)}%
                    </p>
                  </div>

                  <div className="bg-orange-50 p-3 rounded text-center">
                    <p className="text-lg font-bold text-orange-600">
                      {selectedReport.executionSummary.timeouts}
                    </p>
                    <p className="text-sm text-orange-700">Timeouts</p>
                    <p className="text-xs text-orange-600">
                      {(selectedReport.executionSummary.timeouts / selectedReport.executionSummary.totalTests * 100).toFixed(1)}%
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="error-handling" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Error Handling Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedReport.errorHandlingReports.length > 0 ?
              <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <p className="text-lg font-bold text-blue-600">
                        {selectedReport.errorHandlingReports.length}
                      </p>
                      <p className="text-sm text-blue-700">Endpoints Tested</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-lg font-bold text-green-600">
                        {selectedReport.errorHandlingReports.reduce((sum, r) => sum + r.passedScenarios, 0)}
                      </p>
                      <p className="text-sm text-green-700">Scenarios Passed</p>
                    </div>
                    <div className="text-center p-4 bg-red-50 rounded-lg">
                      <p className="text-lg font-bold text-red-600">
                        {selectedReport.errorHandlingReports.reduce((sum, r) => sum + r.failedScenarios, 0)}
                      </p>
                      <p className="text-sm text-red-700">Scenarios Failed</p>
                    </div>
                  </div>

                  {/* Top Error Handling Issues */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">Error Handling Scores by Endpoint</h4>
                    {selectedReport.errorHandlingReports.
                  sort((a, b) => a.overallScore - b.overallScore).
                  slice(0, 10).
                  map((report, index) =>
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium text-sm">{report.endpointId}</p>
                          <p className="text-xs text-gray-500">
                            {report.passedScenarios}/{report.totalScenarios} scenarios passed
                          </p>
                        </div>
                        <div className="text-right">
                          <div className={`inline-block px-2 py-1 rounded text-sm font-medium ${
                      report.overallScore >= 80 ? 'bg-green-100 text-green-800' :
                      report.overallScore >= 60 ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'}`
                      }>
                            {report.overallScore.toFixed(1)}%
                          </div>
                        </div>
                      </div>
                  )}
                  </div>
                </div> :

              <div className="text-center py-8">
                  <AlertTriangle className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">No error handling analysis available.</p>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="validation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                Validation Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedReport.validationReports.length > 0 ?
              <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-lg font-bold text-green-600">
                        {selectedReport.validationReports.filter((r) => r.overallStatus === 'PASS').length}
                      </p>
                      <p className="text-sm text-green-700">Passed</p>
                    </div>
                    <div className="text-center p-4 bg-yellow-50 rounded-lg">
                      <p className="text-lg font-bold text-yellow-600">
                        {selectedReport.validationReports.filter((r) => r.overallStatus === 'WARNING').length}
                      </p>
                      <p className="text-sm text-yellow-700">Warnings</p>
                    </div>
                    <div className="text-center p-4 bg-red-50 rounded-lg">
                      <p className="text-lg font-bold text-red-600">
                        {selectedReport.validationReports.filter((r) => r.overallStatus === 'FAIL').length}
                      </p>
                      <p className="text-sm text-red-700">Failed</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium text-gray-900">Validation Results by Endpoint</h4>
                    {selectedReport.validationReports.map((report, index) =>
                  <div key={index} className="p-3 border rounded-lg">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-sm">{report.endpoint}</p>
                          <Badge className={
                      report.overallStatus === 'PASS' ? 'bg-green-100 text-green-800' :
                      report.overallStatus === 'WARNING' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                      }>
                            {report.overallStatus}
                          </Badge>
                        </div>
                        {(report.requestValidation.errors.length > 0 || report.responseValidation.errors.length > 0) &&
                    <div className="mt-2 text-xs text-red-600">
                            {[...report.requestValidation.errors, ...report.responseValidation.errors].join(', ')}
                          </div>
                    }
                      </div>
                  )}
                  </div>
                </div> :

              <div className="text-center py-8">
                  <CheckCircle className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">No validation analysis available.</p>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Performance Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Response Time Metrics</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Average Response Time</span>
                      <span className="font-medium">
                        {selectedReport.performanceMetrics.averageResponseTime.toFixed(2)}ms
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Fastest Endpoint</span>
                      <div className="text-right">
                        <p className="font-medium text-sm">
                          {selectedReport.performanceMetrics.fastestEndpoint.time.toFixed(2)}ms
                        </p>
                        <p className="text-xs text-gray-500">
                          {selectedReport.performanceMetrics.fastestEndpoint.name}
                        </p>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Slowest Endpoint</span>
                      <div className="text-right">
                        <p className="font-medium text-sm">
                          {selectedReport.performanceMetrics.slowestEndpoint.time.toFixed(2)}ms
                        </p>
                        <p className="text-xs text-gray-500">
                          {selectedReport.performanceMetrics.slowestEndpoint.name}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-gray-900">Execution Metrics</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Total Execution Time</span>
                      <span className="font-medium">
                        {formatDuration(selectedReport.executionSummary.totalExecutionTime)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Average Test Time</span>
                      <span className="font-medium">
                        {selectedReport.executionSummary.averageExecutionTime.toFixed(2)}ms
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Timeout Occurrences</span>
                      <span className="font-medium">
                        {selectedReport.performanceMetrics.timeoutOccurrences}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Performance Recommendations */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Performance Recommendations</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  {selectedReport.performanceMetrics.averageResponseTime > 1000 &&
                  <li>• Consider optimizing endpoints with response times over 1000ms</li>
                  }
                  {selectedReport.performanceMetrics.timeoutOccurrences > 0 &&
                  <li>• Investigate and resolve timeout issues in affected endpoints</li>
                  }
                  <li>• Monitor performance trends over time to identify degradation</li>
                  <li>• Implement caching strategies for frequently accessed data</li>
                  <li>• Consider pagination for endpoints returning large datasets</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};