
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  Database,
  Link,
  Search,
  FileX,
  TrendingDown,
  AlertCircle,
  Clock,
  Eye,
  ChevronDown,
  ChevronRight } from
'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface DataIntegrityTestResultsProps {
  results: any;
}

const DataIntegrityTestResults: React.FC<DataIntegrityTestResultsProps> = ({ results }) => {
  const [expandedTests, setExpandedTests] = useState<Set<string>>(new Set());

  if (!results) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-center text-muted-foreground">
            <Database className="h-12 w-12 mx-auto mb-4" />
            <p>No data integrity test results available</p>
          </div>
        </CardContent>
      </Card>);

  }

  const toggleExpanded = (testId: string) => {
    const newExpanded = new Set(expandedTests);
    if (newExpanded.has(testId)) {
      newExpanded.delete(testId);
    } else {
      newExpanded.add(testId);
    }
    setExpandedTests(newExpanded);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed':
        return 'border-green-200 bg-green-50';
      case 'failed':
        return 'border-red-200 bg-red-50';
      case 'error':
        return 'border-yellow-200 bg-yellow-50';
      default:
        return 'border-gray-200 bg-gray-50';
    }
  };

  return (
    <Tabs defaultValue="crud" className="space-y-4">
      <TabsList>
        <TabsTrigger value="crud">CRUD Operations</TabsTrigger>
        <TabsTrigger value="referential">Referential Integrity</TabsTrigger>
        <TabsTrigger value="corruption">Data Corruption</TabsTrigger>
        <TabsTrigger value="summary">Summary</TabsTrigger>
      </TabsList>

      {/* CRUD Operations Tab */}
      <TabsContent value="crud" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              CRUD Operations Test Results
            </CardTitle>
            <CardDescription>
              Detailed results of Create, Read, Update, Delete operations across database tables
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* CRUD Summary */}
              <div className="grid gap-4 md:grid-cols-4">
                {['create', 'read', 'update', 'delete'].map((operation) => {
                  const opTests = results.crudTests?.filter((test: any) => test.operation === operation) || [];
                  const passed = opTests.filter((test: any) => test.status === 'passed').length;
                  const failed = opTests.filter((test: any) => test.status === 'failed').length;
                  const errors = opTests.filter((test: any) => test.status === 'error').length;
                  const total = opTests.length;
                  const passRate = total > 0 ? passed / total * 100 : 0;

                  return (
                    <div key={operation} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium capitalize">{operation}</h4>
                        {getStatusIcon(passRate === 100 ? 'passed' : passRate > 50 ? 'failed' : 'error')}
                      </div>
                      <div className="space-y-2">
                        <div className="text-2xl font-bold">{passed}/{total}</div>
                        <Progress value={passRate} className="h-2" />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>P:{passed}</span>
                          <span>F:{failed}</span>
                          <span>E:{errors}</span>
                        </div>
                      </div>
                    </div>);

                })}
              </div>

              {/* Detailed Test Results */}
              <div className="space-y-2">
                <h4 className="font-medium">Detailed Results</h4>
                {results.crudTests?.map((test: any, index: number) =>
                <Collapsible key={index}>
                    <div className={`border rounded-lg ${getStatusColor(test.status)}`}>
                      <CollapsibleTrigger
                      className="w-full p-3 flex items-center justify-between hover:bg-opacity-80 transition-colors"
                      onClick={() => toggleExpanded(test.testId)}>

                        <div className="flex items-center gap-3">
                          {getStatusIcon(test.status)}
                          <div className="text-left">
                            <div className="font-medium">{test.testName}</div>
                            <div className="text-sm text-muted-foreground">
                              {test.tableName} • {test.operation.toUpperCase()}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">
                            <Clock className="h-3 w-3 mr-1" />
                            {test.details.executionTime}ms
                          </Badge>
                          {expandedTests.has(test.testId) ?
                        <ChevronDown className="h-4 w-4" /> :

                        <ChevronRight className="h-4 w-4" />
                        }
                        </div>
                      </CollapsibleTrigger>
                      
                      <CollapsibleContent>
                        <div className="px-3 pb-3 border-t border-opacity-50">
                          {/* Test Details */}
                          <div className="mt-3 space-y-3">
                            {test.details.testData &&
                          <div>
                                <h5 className="text-sm font-medium mb-1">Test Data</h5>
                                <pre className="text-xs bg-gray-100 p-2 rounded overflow-x-auto">
                                  {JSON.stringify(test.details.testData, null, 2)}
                                </pre>
                              </div>
                          }

                            {test.details.actualResult &&
                          <div>
                                <h5 className="text-sm font-medium mb-1">Actual Result</h5>
                                <pre className="text-xs bg-gray-100 p-2 rounded overflow-x-auto">
                                  {typeof test.details.actualResult === 'object' ?
                              JSON.stringify(test.details.actualResult, null, 2) :
                              test.details.actualResult}
                                </pre>
                              </div>
                          }

                            {test.details.errorMessage &&
                          <div>
                                <h5 className="text-sm font-medium mb-1 text-red-600">Error Message</h5>
                                <div className="text-xs bg-red-100 p-2 rounded text-red-800">
                                  {test.details.errorMessage}
                                </div>
                              </div>
                          }

                            {/* Validations */}
                            {test.details.validations && test.details.validations.length > 0 &&
                          <div>
                                <h5 className="text-sm font-medium mb-2">Validations</h5>
                                <div className="space-y-2">
                                  {test.details.validations.map((validation: any, vIndex: number) =>
                              <div key={vIndex} className="flex items-start gap-2 text-xs">
                                      {getStatusIcon(validation.passed ? 'passed' : 'failed')}
                                      <div className="flex-1">
                                        <div className={validation.passed ? 'text-green-700' : 'text-red-700'}>
                                          {validation.validation}: {validation.message}
                                        </div>
                                        {validation.expected &&
                                  <div className="text-muted-foreground mt-1">
                                            Expected: {validation.expected}
                                            {validation.actual && ` | Actual: ${validation.actual}`}
                                          </div>
                                  }
                                      </div>
                                    </div>
                              )}
                                </div>
                              </div>
                          }
                          </div>
                        </div>
                      </CollapsibleContent>
                    </div>
                  </Collapsible>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Referential Integrity Tab */}
      <TabsContent value="referential" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Link className="h-5 w-5" />
              Referential Integrity Tests
            </CardTitle>
            <CardDescription>
              Tests for foreign key relationships and data consistency across related tables
            </CardDescription>
          </CardHeader>
          <CardContent>
            {results.referentialIntegrityTests && results.referentialIntegrityTests.length > 0 ?
            <div className="space-y-4">
                {results.referentialIntegrityTests.map((test: any, index: number) =>
              <div key={index} className={`p-4 border rounded-lg ${getStatusColor(test.testResult)}`}>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(test.testResult)}
                        <h4 className="font-medium">
                          Table {test.parentTable} → Table {test.childTable}
                        </h4>
                      </div>
                      <Badge variant="outline">{test.foreignKeyField}</Badge>
                    </div>
                    
                    <div className="grid gap-4 md:grid-cols-3">
                      <div>
                        <div className="text-sm text-muted-foreground">Parent Table</div>
                        <div className="font-medium">{test.parentTable}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Child Table</div>
                        <div className="font-medium">{test.childTable}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Orphaned Records</div>
                        <div className={`font-medium ${test.orphanedRecords > 0 ? 'text-red-600' : 'text-green-600'}`}>
                          {test.orphanedRecords}
                        </div>
                      </div>
                    </div>

                    {test.errorMessage &&
                <div className="mt-3 p-3 bg-red-100 border border-red-300 rounded text-sm text-red-700">
                        {test.errorMessage}
                      </div>
                }
                  </div>
              )}
              </div> :

            <div className="text-center py-8 text-muted-foreground">
                <Link className="h-12 w-12 mx-auto mb-4" />
                <p>No referential integrity test results available</p>
              </div>
            }
          </CardContent>
        </Card>
      </TabsContent>

      {/* Data Corruption Tab */}
      <TabsContent value="corruption" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileX className="h-5 w-5" />
              Data Corruption Detection
            </CardTitle>
            <CardDescription>
              Analysis of data quality issues, corruption patterns, and integrity violations
            </CardDescription>
          </CardHeader>
          <CardContent>
            {results.dataCorruptionTests && results.dataCorruptionTests.length > 0 ?
            <div className="space-y-4">
                {/* Corruption Summary */}
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingDown className="h-4 w-4 text-red-500" />
                      <span className="font-medium">High Corruption</span>
                    </div>
                    <div className="text-2xl font-bold text-red-600">
                      {results.dataCorruptionTests.filter((test: any) => test.corruptionPercentage > 10).length}
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-yellow-500" />
                      <span className="font-medium">Medium Corruption</span>
                    </div>
                    <div className="text-2xl font-bold text-yellow-600">
                      {results.dataCorruptionTests.filter((test: any) =>
                    test.corruptionPercentage > 1 && test.corruptionPercentage <= 10).length}
                    </div>
                  </div>
                  
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="font-medium">Clean Data</span>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      {results.dataCorruptionTests.filter((test: any) => test.corruptionPercentage <= 1).length}
                    </div>
                  </div>
                </div>

                {/* Detailed Corruption Results */}
                <div className="space-y-3">
                  {results.dataCorruptionTests.map((test: any, index: number) => {
                  const severityColor = test.corruptionPercentage > 10 ? 'border-red-300 bg-red-50' :
                  test.corruptionPercentage > 1 ? 'border-yellow-300 bg-yellow-50' :
                  'border-green-300 bg-green-50';

                  return (
                    <div key={index} className={`p-4 border rounded-lg ${severityColor}`}>
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-medium">{test.testType.replace(/_/g, ' ').toUpperCase()}</h4>
                          <div className="flex items-center gap-2">
                            <Badge className={
                          test.corruptionPercentage > 10 ? 'bg-red-100 text-red-800' :
                          test.corruptionPercentage > 1 ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                          }>
                              {test.corruptionPercentage.toFixed(2)}%
                            </Badge>
                            {test.corruptionPercentage > 10 &&
                          <Badge className="bg-red-100 text-red-800">CRITICAL</Badge>
                          }
                          </div>
                        </div>

                        <div className="grid gap-4 md:grid-cols-4 mb-3">
                          <div>
                            <div className="text-sm text-muted-foreground">Field</div>
                            <div className="font-medium">{test.fieldName}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Corrupted Records</div>
                            <div className="font-medium">{test.corruptedRecords}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Total Records</div>
                            <div className="font-medium">{test.totalRecords}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Corruption Rate</div>
                            <div className="font-medium">{test.corruptionPercentage.toFixed(2)}%</div>
                          </div>
                        </div>

                        {test.examples && test.examples.length > 0 &&
                      <div>
                            <h5 className="text-sm font-medium mb-2">Examples</h5>
                            <div className="bg-gray-100 p-3 rounded text-xs">
                              <pre>{JSON.stringify(test.examples, null, 2)}</pre>
                            </div>
                          </div>
                      }
                      </div>);

                })}
                </div>
              </div> :

            <div className="text-center py-8 text-muted-foreground">
                <FileX className="h-12 w-12 mx-auto mb-4" />
                <p>No data corruption test results available</p>
              </div>
            }
          </CardContent>
        </Card>
      </TabsContent>

      {/* Summary Tab */}
      <TabsContent value="summary" className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Data Integrity Summary
            </CardTitle>
            <CardDescription>
              Overall assessment of data integrity across all test categories
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Overall Metrics */}
              <div className="grid gap-4 md:grid-cols-4">
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold mb-1">{results.summary?.totalTests || 0}</div>
                  <div className="text-sm text-muted-foreground">Total Tests</div>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">{results.summary?.passed || 0}</div>
                  <div className="text-sm text-muted-foreground">Passed</div>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold text-red-600 mb-1">{results.summary?.failed || 0}</div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </div>
                <div className="p-4 border rounded-lg text-center">
                  <div className="text-2xl font-bold text-yellow-600 mb-1">{results.summary?.errors || 0}</div>
                  <div className="text-sm text-muted-foreground">Errors</div>
                </div>
              </div>

              {/* Pass Rate Progress */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Overall Pass Rate</span>
                  <span className="text-sm">
                    {results.summary ?
                    results.summary.totalTests > 0 ?
                    (results.summary.passed / results.summary.totalTests * 100).toFixed(1) : 0 :
                    0}%
                  </span>
                </div>
                <Progress
                  value={results.summary ?
                  results.summary.totalTests > 0 ?
                  results.summary.passed / results.summary.totalTests * 100 : 0 :
                  0}
                  className="h-3" />

              </div>

              {/* Execution Time */}
              {results.summary?.executionTime &&
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Total Execution Time</span>
                  </div>
                  <span className="text-sm">
                    {(results.summary.executionTime / 1000).toFixed(2)}s
                  </span>
                </div>
              }

              {/* Key Findings */}
              <div>
                <h4 className="font-medium mb-3">Key Findings</h4>
                <div className="space-y-2">
                  {results.crudTests &&
                  <div className="flex items-center justify-between p-2 bg-blue-50 border border-blue-200 rounded">
                      <span className="text-sm">CRUD Operations Coverage</span>
                      <Badge variant="outline">{results.crudTests.length} tests</Badge>
                    </div>
                  }
                  
                  {results.referentialIntegrityTests &&
                  <div className="flex items-center justify-between p-2 bg-purple-50 border border-purple-200 rounded">
                      <span className="text-sm">Referential Integrity Checks</span>
                      <Badge variant="outline">{results.referentialIntegrityTests.length} relationships</Badge>
                    </div>
                  }
                  
                  {results.dataCorruptionTests &&
                  <div className="flex items-center justify-between p-2 bg-orange-50 border border-orange-200 rounded">
                      <span className="text-sm">Data Corruption Analysis</span>
                      <Badge variant="outline">{results.dataCorruptionTests.length} checks</Badge>
                    </div>
                  }
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>);

};

export default DataIntegrityTestResults;