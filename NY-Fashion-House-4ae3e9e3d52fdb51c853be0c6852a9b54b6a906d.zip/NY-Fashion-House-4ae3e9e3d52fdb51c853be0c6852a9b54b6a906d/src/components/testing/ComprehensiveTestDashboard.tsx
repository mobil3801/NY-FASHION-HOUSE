
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  Play,
  RefreshCw,
  Shield,
  Database,
  Users,
  TrendingUp,
  Clock,
  AlertCircle,
  FileText,
  Activity,
  Globe,
  Bug } from
'lucide-react';
import EnhancedComprehensiveTestDashboard from './EnhancedComprehensiveTestDashboard';
import { comprehensiveTestManager, ComprehensiveTestReport } from '@/services/comprehensiveTestManager';
import { toast } from 'sonner';

const ComprehensiveTestDashboard: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentReport, setCurrentReport] = useState<ComprehensiveTestReport | null>(null);
  const [healthStatus, setHealthStatus] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadHealthStatus();
  }, []);

  const loadHealthStatus = async () => {
    try {
      const health = await comprehensiveTestManager.generateQuickHealthCheck();
      setHealthStatus(health);
    } catch (error) {
      console.error('Failed to load health status:', error);
    }
  };

  const runComprehensiveTests = async () => {
    setIsRunning(true);
    setLoading(true);

    try {
      toast.info('Starting comprehensive tests...', {
        description: 'This may take several minutes to complete.'
      });

      const report = await comprehensiveTestManager.runComprehensiveTests(
        `Comprehensive Test - ${new Date().toLocaleString()}`
      );

      setCurrentReport(report);

      toast.success('Comprehensive tests completed!', {
        description: `${report.overallSummary.totalTests} tests executed with ${report.overallSummary.passRate.toFixed(1)}% pass rate.`
      });

      // Refresh health status
      await loadHealthStatus();

    } catch (error) {
      console.error('Comprehensive test execution failed:', error);
      toast.error('Test execution failed', {
        description: error instanceof Error ? error.message : 'Unknown error occurred'
      });
    } finally {
      setIsRunning(false);
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
      case 'healthy':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'failed':
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'error':
      case 'critical':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed':
      case 'healthy':
        return 'text-green-600 bg-green-50 border-green-200';
      case 'failed':
      case 'warning':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'error':
      case 'critical':
        return 'text-red-600 bg-red-50 border-red-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const formatDuration = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    }
    return `${seconds}s`;
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Comprehensive Test Dashboard</h1>
          <p className="text-muted-foreground">
            Data integrity validation, role-based permission testing, and system health monitoring
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={loadHealthStatus}
            disabled={loading}>

            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            onClick={runComprehensiveTests}
            disabled={isRunning}>

            {isRunning ?
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> :

            <Play className="h-4 w-4 mr-2" />
            }
            Run Tests
          </Button>
        </div>
      </div>

      {/* System Health Overview */}
      {healthStatus &&
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">System Health</CardTitle>
              {getStatusIcon(healthStatus.status)}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthStatus.score}%</div>
              <p className="text-xs text-muted-foreground">
                Overall system score
              </p>
              <Progress value={healthStatus.score} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Issues</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{healthStatus.issues.length}</div>
              <p className="text-xs text-muted-foreground">
                Issues requiring attention
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Test Coverage</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {currentReport ? currentReport.overallSummary.totalTests : '—'}
              </div>
              <p className="text-xs text-muted-foreground">
                Total tests available
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pass Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {currentReport ? `${currentReport.overallSummary.passRate.toFixed(1)}%` : '—'}
              </div>
              <p className="text-xs text-muted-foreground">
                Latest test execution
              </p>
            </CardContent>
          </Card>
        </div>
      }

      {/* Current Issues Alert */}
      {healthStatus && healthStatus.issues.length > 0 &&
      <Alert className="border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle className="text-yellow-800">System Issues Detected</AlertTitle>
          <AlertDescription className="text-yellow-700">
            <ul className="mt-2 list-disc list-inside space-y-1">
              {healthStatus.issues.map((issue: string, index: number) =>
            <li key={index}>{issue}</li>
            )}
            </ul>
            {healthStatus.recommendations.length > 0 &&
          <div className="mt-3">
                <strong>Recommendations:</strong>
                <ul className="mt-1 list-disc list-inside space-y-1">
                  {healthStatus.recommendations.map((rec: string, index: number) =>
              <li key={index}>{rec}</li>
              )}
                </ul>
              </div>
          }
          </AlertDescription>
        </Alert>
      }

      {/* Test Results */}
      {currentReport &&
      <Tabs defaultValue="enhanced" className="space-y-4">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="enhanced" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Enhanced Suite
            </TabsTrigger>
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="data-integrity" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              Data Integrity
            </TabsTrigger>
            <TabsTrigger value="permissions" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Role Permissions
            </TabsTrigger>
            <TabsTrigger value="compliance" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Compliance
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="flex items-center gap-2">
              <Bug className="h-4 w-4" />
              Recommendations
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="enhanced" className="space-y-6">
            <EnhancedComprehensiveTestDashboard />
          </TabsContent>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Test Execution Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Total Tests</span>
                    <Badge variant="secondary">{currentReport.overallSummary.totalTests}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Passed</span>
                    <Badge className="bg-green-100 text-green-800">
                      {currentReport.overallSummary.passed}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Failed</span>
                    <Badge className="bg-red-100 text-red-800">
                      {currentReport.overallSummary.failed}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Errors</span>
                    <Badge className="bg-yellow-100 text-yellow-800">
                      {currentReport.overallSummary.errors}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Duration</span>
                    <Badge variant="outline">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatDuration(currentReport.totalDuration)}
                    </Badge>
                  </div>
                  <div className="pt-2">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm">Pass Rate</span>
                      <span className="text-sm font-medium">
                        {currentReport.overallSummary.passRate.toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={currentReport.overallSummary.passRate} />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Critical Issues
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Security Violations</span>
                    <Badge className={currentReport.overallSummary.securityViolations > 0 ?
                  "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}>
                      {currentReport.overallSummary.securityViolations}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Data Integrity Issues</span>
                    <Badge className={currentReport.overallSummary.dataIntegrityIssues > 0 ?
                  "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}>
                      {currentReport.overallSummary.dataIntegrityIssues}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Critical Issues</span>
                    <Badge className={currentReport.overallSummary.criticalIssues > 0 ?
                  "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}>
                      {currentReport.overallSummary.criticalIssues}
                    </Badge>
                  </div>
                  {currentReport.criticalFindings.length > 0 &&
                <div className="pt-2">
                      <h4 className="text-sm font-medium mb-2">Recent Critical Findings</h4>
                      <div className="space-y-2">
                        {currentReport.criticalFindings.slice(0, 3).map((finding, index) =>
                    <div key={index} className="p-2 bg-red-50 border border-red-200 rounded text-xs">
                            <div className="font-medium text-red-800">{finding.title}</div>
                            <div className="text-red-600 mt-1">{finding.description}</div>
                          </div>
                    )}
                      </div>
                    </div>
                }
                </CardContent>
              </Card>
            </div>

            {/* Test Categories Overview */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {Object.entries(currentReport.testCategories).map(([key, category]) => {
              const categoryNames = {
                dataIntegrity: 'Data Integrity',
                rolePermissions: 'Role Permissions',
                databaseConstraints: 'DB Constraints',
                dataCorruption: 'Data Corruption'
              };

              return (
                <Card key={key}>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">
                        {categoryNames[key as keyof typeof categoryNames]}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-2xl font-bold">{category.summary.totalTests}</span>
                        {getStatusIcon(category.summary.passRate === 100 ? 'passed' :
                      category.summary.passRate > 80 ? 'warning' : 'error')}
                      </div>
                      <div className="space-y-1 text-xs text-muted-foreground">
                        <div>Passed: {category.summary.passed}</div>
                        <div>Failed: {category.summary.failed}</div>
                        <div>Errors: {category.summary.errors}</div>
                      </div>
                      <Progress value={category.summary.passRate} className="mt-2" />
                      <div className="text-xs text-center mt-1">
                        {category.summary.passRate.toFixed(1)}%
                      </div>
                    </CardContent>
                  </Card>);

            })}
            </div>
          </TabsContent>

          {/* Data Integrity Tab */}
          <TabsContent value="data-integrity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="h-5 w-5" />
                  CRUD Operations Test Results
                </CardTitle>
                <CardDescription>
                  Validation of Create, Read, Update, Delete operations across all database tables
                </CardDescription>
              </CardHeader>
              <CardContent>
                {currentReport.testCategories.dataIntegrity.results?.crudTests &&
              <div className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-4">
                      {['create', 'read', 'update', 'delete'].map((operation) => {
                    const opTests = currentReport.testCategories.dataIntegrity.results.crudTests.
                    filter((test: any) => test.operation === operation);
                    const passed = opTests.filter((test: any) => test.status === 'passed').length;
                    const total = opTests.length;

                    return (
                      <div key={operation} className="p-3 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium capitalize">{operation}</span>
                              {getStatusIcon(passed === total ? 'passed' : 'failed')}
                            </div>
                            <div className="text-2xl font-bold">{passed}/{total}</div>
                            <Progress value={total > 0 ? passed / total * 100 : 0} className="mt-2" />
                          </div>);

                  })}
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-medium">Test Details</h4>
                      {currentReport.testCategories.dataIntegrity.results.crudTests.
                  slice(0, 10).
                  map((test: any, index: number) =>
                  <div key={index} className={`flex items-center justify-between p-2 border rounded ${getStatusColor(test.status)}`}>
                            <div className="flex items-center gap-2">
                              {getStatusIcon(test.status)}
                              <span className="text-sm">{test.testName}</span>
                            </div>
                            <div className="flex items-center gap-2 text-xs">
                              <Badge variant="outline">{test.operation.toUpperCase()}</Badge>
                              <span>{test.details.executionTime}ms</span>
                            </div>
                          </div>
                  )}
                    </div>
                  </div>
              }
              </CardContent>
            </Card>
          </TabsContent>

          {/* Role Permissions Tab */}
          <TabsContent value="permissions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Role-Based Permission Tests
                </CardTitle>
                <CardDescription>
                  Validation of access controls and permission boundaries for all user roles
                </CardDescription>
              </CardHeader>
              <CardContent>
                {currentReport.testCategories.rolePermissions.results &&
              <div className="space-y-4">
                    {/* Role Summary */}
                    <div className="grid gap-4 md:grid-cols-3">
                      {['Administrator', 'Sales', 'General User'].map((role) => {
                    const roleTests = currentReport.testCategories.rolePermissions.results.rolePermissionTests?.
                    filter((test: any) => test.roleName.includes(role)) || [];
                    const passed = roleTests.filter((test: any) => test.status === 'passed').length;
                    const total = roleTests.length;

                    return (
                      <div key={role} className="p-3 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium">{role}</span>
                              <Users className="h-4 w-4 text-muted-foreground" />
                            </div>
                            <div className="text-2xl font-bold">{passed}/{total}</div>
                            <Progress value={total > 0 ? passed / total * 100 : 0} className="mt-2" />
                          </div>);

                  })}
                    </div>

                    {/* Security Violations */}
                    {currentReport.testCategories.rolePermissions.results.boundaryTests &&
                <div className="space-y-2">
                        <h4 className="font-medium text-red-600">Security Boundary Tests</h4>
                        {currentReport.testCategories.rolePermissions.results.boundaryTests.
                  map((test: any, index: number) =>
                  <div key={index} className={`p-3 border rounded ${
                  test.securityViolation ? 'border-red-300 bg-red-50' : 'border-green-300 bg-green-50'}`
                  }>
                              <div className="flex items-center justify-between">
                                <div>
                                  <div className="font-medium">{test.testName}</div>
                                  <div className="text-sm text-muted-foreground">
                                    Role: {test.roleCode}
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  {test.securityViolation &&
                        <Badge className="bg-red-100 text-red-800">VIOLATION</Badge>
                        }
                                  {getStatusIcon(test.status)}
                                </div>
                              </div>
                              <div className="text-sm mt-2">
                                <div><strong>Expected:</strong> {test.expectedBehavior}</div>
                                <div><strong>Actual:</strong> {test.actualBehavior}</div>
                              </div>
                            </div>
                  )}
                      </div>
                }
                  </div>
              }
              </CardContent>
            </Card>
          </TabsContent>

          {/* Compliance Tab */}
          <TabsContent value="compliance" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Compliance Report
                </CardTitle>
                <CardDescription>
                  Overall system compliance assessment across key areas
                </CardDescription>
              </CardHeader>
              <CardContent>
                {currentReport.complianceReport &&
              <div className="space-y-6">
                    {/* Overall Compliance Score */}
                    <div className="text-center p-6 border rounded-lg">
                      <div className="text-4xl font-bold mb-2">
                        {currentReport.complianceReport.overallCompliance.score.toFixed(1)}%
                      </div>
                      <div className="text-lg capitalize mb-2">
                        {currentReport.complianceReport.overallCompliance.level}
                      </div>
                      <Badge className={currentReport.complianceReport.overallCompliance.compliant ?
                  "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                        {currentReport.complianceReport.overallCompliance.compliant ? 'Compliant' : 'Non-Compliant'}
                      </Badge>
                    </div>

                    {/* Compliance Areas */}
                    <div className="grid gap-4 md:grid-cols-2">
                      {Object.entries(currentReport.complianceReport).
                  filter(([key]) => key !== 'overallCompliance').
                  map(([key, area]: [string, any]) =>
                  <div key={key} className="p-4 border rounded-lg">
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-medium capitalize">
                                {key.replace(/([A-Z])/g, ' $1').trim()}
                              </h4>
                              {getStatusIcon(area.compliant ? 'passed' : 'failed')}
                            </div>
                            <div className="text-2xl font-bold mb-2">{area.score.toFixed(1)}%</div>
                            <Progress value={area.score} className="mb-3" />
                            <Badge className={area.compliant ?
                    "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                              {area.compliant ? 'Compliant' : 'Non-Compliant'}
                            </Badge>
                            {area.issues.length > 0 &&
                    <div className="mt-3">
                                <div className="text-sm font-medium mb-1">Issues:</div>
                                <ul className="text-xs text-muted-foreground space-y-1">
                                  {area.issues.map((issue: string, index: number) =>
                        <li key={index}>• {issue}</li>
                        )}
                                </ul>
                              </div>
                    }
                          </div>
                  )}
                    </div>
                  </div>
              }
              </CardContent>
            </Card>
          </TabsContent>

          {/* Recommendations Tab */}
          <TabsContent value="recommendations" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Test Recommendations</CardTitle>
                <CardDescription>
                  Actionable recommendations based on test results
                </CardDescription>
              </CardHeader>
              <CardContent>
                {currentReport.recommendations.length > 0 ?
              <div className="space-y-4">
                    {currentReport.recommendations.map((rec, index) =>
                <div key={index} className={`p-4 border rounded-lg ${
                rec.priority === 'critical' ? 'border-red-300 bg-red-50' :
                rec.priority === 'high' ? 'border-orange-300 bg-orange-50' :
                rec.priority === 'medium' ? 'border-yellow-300 bg-yellow-50' :
                'border-blue-300 bg-blue-50'}`
                }>
                        <div className="flex items-start justify-between mb-2">
                          <Badge className={
                    rec.priority === 'critical' ? 'bg-red-100 text-red-800' :
                    rec.priority === 'high' ? 'bg-orange-100 text-orange-800' :
                    rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-blue-100 text-blue-800'
                    }>
                            {rec.priority.toUpperCase()}
                          </Badge>
                          <Badge variant="outline">{rec.category}</Badge>
                        </div>
                        <h4 className="font-medium mb-2">{rec.issue}</h4>
                        <p className="text-sm mb-3">{rec.recommendation}</p>
                        <div className="grid grid-cols-2 gap-4 text-xs">
                          <div>
                            <strong>Impact:</strong> {rec.impact}
                          </div>
                          <div>
                            <strong>Effort:</strong> {rec.effort}
                          </div>
                        </div>
                      </div>
                )}
                  </div> :

              <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-500" />
                    <p>No recommendations available. All tests are passing!</p>
                  </div>
              }
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      }

      {/* Loading State */}
      {isRunning &&
      <Card>
          <CardContent className="flex items-center justify-center py-12">
            <div className="text-center">
              <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
              <h3 className="font-medium mb-2">Running Comprehensive Tests</h3>
              <p className="text-sm text-muted-foreground">
                Please wait while we validate data integrity, permissions, and system health...
              </p>
            </div>
          </CardContent>
        </Card>
      }
    </div>);

};

export default ComprehensiveTestDashboard;