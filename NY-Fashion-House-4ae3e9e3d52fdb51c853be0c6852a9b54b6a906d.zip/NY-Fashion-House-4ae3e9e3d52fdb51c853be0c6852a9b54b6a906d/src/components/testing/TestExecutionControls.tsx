import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Play,
  Square,
  Clock,
  Target,
  AlertCircle,
  CheckCircle,
  Info } from
'lucide-react';
import { TestSuite } from '@/services/automatedTestGeneratorService';

interface TestExecutionState {
  isRunning: boolean;
  isPaused: boolean;
  currentTest?: string;
  progress: number;
  totalTests: number;
  startTime?: Date;
}

interface TestExecutionControlsProps {
  testSuite: TestSuite | null;
  executionState: TestExecutionState;
  onStartExecution: () => void;
  onStopExecution: () => void;
  disabled: boolean;
}

export const TestExecutionControls: React.FC<TestExecutionControlsProps> = ({
  testSuite,
  executionState,
  onStartExecution,
  onStopExecution,
  disabled
}) => {
  const formatDuration = (ms: number): string => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor(ms % 60000 / 1000);
    return `${minutes}m ${seconds}s`;
  };

  const getTestCasesByType = () => {
    if (!testSuite) return {};

    const types = testSuite.testCases.reduce((acc, testCase) => {
      acc[testCase.testType] = (acc[testCase.testType] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return types;
  };

  const getTestCasesByOperation = () => {
    if (!testSuite) return {};

    const operations = testSuite.testCases.reduce((acc, testCase) => {
      acc[testCase.operationType] = (acc[testCase.operationType] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return operations;
  };

  const testTypeColors = {
    POSITIVE: 'bg-green-100 text-green-800',
    NEGATIVE: 'bg-red-100 text-red-800',
    EDGE_CASE: 'bg-yellow-100 text-yellow-800',
    PERFORMANCE: 'bg-purple-100 text-purple-800'
  };

  const operationColors = {
    CREATE: 'bg-blue-100 text-blue-800',
    READ: 'bg-gray-100 text-gray-800',
    UPDATE: 'bg-orange-100 text-orange-800',
    DELETE: 'bg-red-100 text-red-800',
    UTILITY: 'bg-indigo-100 text-indigo-800'
  };

  return (
    <div className="space-y-6">
      {/* Test Suite Overview */}
      {testSuite ?
      <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="h-5 w-5 mr-2" />
              Test Suite: {testSuite.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">{testSuite.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Test Count */}
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-700">Total Test Cases</p>
                    <p className="text-2xl font-bold text-blue-900">{testSuite.testCases.length}</p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-blue-500" />
                </div>
              </div>

              {/* Estimated Duration */}
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-green-700">Estimated Duration</p>
                    <p className="text-2xl font-bold text-green-900">
                      {formatDuration(testSuite.estimatedDuration)}
                    </p>
                  </div>
                  <Clock className="h-8 w-8 text-green-500" />
                </div>
              </div>

              {/* Unique Services */}
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-purple-700">Services Covered</p>
                    <p className="text-2xl font-bold text-purple-900">
                      {new Set(testSuite.testCases.map((tc) => tc.serviceName)).size}
                    </p>
                  </div>
                  <Target className="h-8 w-8 text-purple-500" />
                </div>
              </div>
            </div>

            {/* Test Distribution */}
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Test Types Distribution</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(getTestCasesByType()).map(([type, count]) =>
              <Badge
                key={type}
                className={`${testTypeColors[type as keyof typeof testTypeColors]} px-3 py-1`}>

                    {type}: {count}
                  </Badge>
              )}
              </div>
            </div>

            <div className="mt-4">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Operation Types</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(getTestCasesByOperation()).map(([operation, count]) =>
              <Badge
                key={operation}
                className={`${operationColors[operation as keyof typeof operationColors]} px-3 py-1`}>

                    {operation}: {count}
                  </Badge>
              )}
              </div>
            </div>
          </CardContent>
        </Card> :

      <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            Select endpoints to generate a test suite automatically.
          </AlertDescription>
        </Alert>
      }

      {/* Execution Controls */}
      <Card>
        <CardHeader>
          <CardTitle>Test Execution Controls</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Status Messages */}
            {disabled &&
            <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Please select at least one endpoint to begin testing.
                </AlertDescription>
              </Alert>
            }

            {!testSuite && !disabled &&
            <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Test suite will be generated automatically when you select endpoints.
                </AlertDescription>
              </Alert>
            }

            {executionState.isRunning &&
            <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  Test execution is in progress. This may take several minutes depending on the number of endpoints selected.
                </AlertDescription>
              </Alert>
            }

            {/* Execution Buttons */}
            <div className="flex space-x-4">
              <Button
                onClick={onStartExecution}
                disabled={disabled || !testSuite || executionState.isRunning}
                className="flex items-center"
                size="lg">

                <Play className="h-4 w-4 mr-2" />
                {executionState.isRunning ? 'Running...' : 'Start Comprehensive Testing'}
              </Button>

              <Button
                variant="outline"
                onClick={onStopExecution}
                disabled={!executionState.isRunning}
                className="flex items-center"
                size="lg">

                <Square className="h-4 w-4 mr-2" />
                Stop Execution
              </Button>
            </div>

            {/* Test Phases Information */}
            {testSuite &&
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-3">Test Execution Phases</h4>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                    <span>Phase 1: Functional Testing ({testSuite.testCases.length} test cases)</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-2"></div>
                    <span>Phase 2: Error Handling Verification</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                    <span>Phase 3: Request/Response Validation</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mr-2"></div>
                    <span>Phase 4: Report Generation</span>
                  </div>
                </div>
              </div>
            }

            {/* Execution Details */}
            {testSuite &&
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">What will be tested:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Functional correctness of all selected endpoints</li>
                  <li>• Input validation and error handling</li>
                  <li>• Response format and data integrity</li>
                  <li>• Performance and timeout behavior</li>
                  <li>• Security and injection vulnerability checks</li>
                  <li>• CRUD operation consistency</li>
                </ul>
              </div>
            }
          </div>
        </CardContent>
      </Card>
    </div>);

};