import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  TrendingUp,
  Activity,
  BarChart3,
  Shield,
  Search,
  ChevronDown,
  ChevronRight,
  Info } from
'lucide-react';
import { DetailedTestReport, EndpointHealthScore } from '@/services/apiTestReportingService';
import { TestResult } from '@/services/testExecutionEngineService';

interface TestResultsDisplayProps {
  report: DetailedTestReport | null;
  healthScores: EndpointHealthScore[];
}

export const TestResultsDisplay: React.FC<TestResultsDisplayProps> = ({
  report,
  healthScores
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());

  if (!report) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <Activity className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-600">No test results available.</p>
          <p className="text-sm text-gray-500 mt-1">Run tests to see detailed results here.</p>
        </CardContent>
      </Card>);

  }

  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedItems(newExpanded);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PASS':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'FAIL':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'ERROR':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'TIMEOUT':
        return <Clock className="h-4 w-4 text-orange-500" />;
      default:
        return <Info className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PASS':
        return 'bg-green-100 text-green-800';
      case 'FAIL':
        return 'bg-red-100 text-red-800';
      case 'ERROR':
        return 'bg-yellow-100 text-yellow-800';
      case 'TIMEOUT':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredResults = report.testResults.filter((result) => {
    const matchesSearch = !searchTerm ||
    result.testCaseId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || result.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const getHealthScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-100';
    if (score >= 75) return 'text-yellow-600 bg-yellow-100';
    if (score >= 60) return 'text-orange-600 bg-orange-100';
    return 'text-red-600 bg-red-100';
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 text-green-500" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold text-gray-900">
                  {report.executionSummary.successRate.toFixed(1)}%
                </p>
              </div>
            </div>
            <Progress
              value={report.executionSummary.successRate}
              className="mt-3" />

          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Activity className="h-8 w-8 text-blue-500" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Total Tests</p>
                <p className="text-2xl font-bold text-gray-900">
                  {report.executionSummary.totalTests}
                </p>
              </div>
            </div>
            <div className="mt-3 flex space-x-2 text-xs">
              <span className="text-green-600">✓ {report.executionSummary.passed}</span>
              <span className="text-red-600">✗ {report.executionSummary.failed}</span>
              <span className="text-yellow-600">⚠ {report.executionSummary.errors}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-purple-500" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Avg Response</p>
                <p className="text-2xl font-bold text-gray-900">
                  {report.performanceMetrics.averageResponseTime.toFixed(0)}ms
                </p>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              Total: {(report.executionSummary.totalExecutionTime / 1000).toFixed(1)}s
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <BarChart3 className="h-8 w-8 text-orange-500" />
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Coverage</p>
                <p className="text-2xl font-bold text-gray-900">
                  {report.coverageAnalysis.coveragePercentage.toFixed(1)}%
                </p>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-3">
              {report.coverageAnalysis.testedEndpoints}/{report.coverageAnalysis.totalEndpoints} endpoints
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="results" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="results">Test Results</TabsTrigger>
          <TabsTrigger value="health">Endpoint Health</TabsTrigger>
          <TabsTrigger value="issues">Issues</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="results" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search test cases..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />

                </div>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">

                  <option value="all">All Status</option>
                  <option value="PASS">Passed</option>
                  <option value="FAIL">Failed</option>
                  <option value="ERROR">Errors</option>
                  <option value="TIMEOUT">Timeouts</option>
                </select>
              </div>
            </CardContent>
          </Card>

          {/* Test Results List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Test Results
                <Badge variant="outline">
                  Showing {filteredResults.length} of {report.testResults.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {filteredResults.map((result, index) =>
                <div
                  key={`${result.testCaseId}-${index}`}
                  className="border rounded-lg p-4 hover:bg-gray-50">

                    <div
                    className="flex items-center justify-between cursor-pointer"
                    onClick={() => toggleExpanded(result.testCaseId)}>

                      <div className="flex items-center space-x-3">
                        {expandedItems.has(result.testCaseId) ?
                      <ChevronDown className="h-4 w-4 text-gray-500" /> :

                      <ChevronRight className="h-4 w-4 text-gray-500" />
                      }
                        {getStatusIcon(result.status)}
                        <div>
                          <p className="font-medium text-sm">{result.testCaseId}</p>
                          <p className="text-xs text-gray-500">
                            {result.executionTime.toFixed(2)}ms • {result.timestamp.toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={getStatusColor(result.status)}>
                          {result.status}
                        </Badge>
                        {result.retryCount > 0 &&
                      <Badge variant="outline">
                            Retried {result.retryCount}x
                          </Badge>
                      }
                      </div>
                    </div>

                    {expandedItems.has(result.testCaseId) &&
                  <div className="mt-4 pl-7 space-y-3">
                        {result.error &&
                    <Alert variant="destructive">
                            <XCircle className="h-4 w-4" />
                            <AlertDescription>
                              <strong>Error:</strong> {result.error}
                            </AlertDescription>
                          </Alert>
                    }
                        
                        {result.result &&
                    <div className="bg-gray-50 p-3 rounded">
                            <p className="text-sm font-medium text-gray-700 mb-2">Result:</p>
                            <pre className="text-xs text-gray-600 whitespace-pre-wrap">
                              {typeof result.result === 'object' ?
                        JSON.stringify(result.result, null, 2) :
                        String(result.result)
                        }
                            </pre>
                          </div>
                    }

                        {result.actualError &&
                    <div className="bg-red-50 p-3 rounded">
                            <p className="text-sm font-medium text-red-700 mb-2">Stack Trace:</p>
                            <pre className="text-xs text-red-600 whitespace-pre-wrap">
                              {result.actualError.stack || result.actualError.message}
                            </pre>
                          </div>
                    }
                      </div>
                  }
                  </div>
                )}

                {filteredResults.length === 0 &&
                <div className="text-center py-8">
                    <Search className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No test results match your filters.</p>
                  </div>
                }
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="health" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Endpoint Health Scores
              </CardTitle>
            </CardHeader>
            <CardContent>
              {healthScores.length > 0 ?
              <div className="space-y-3">
                  {healthScores.slice(0, 20).map((score, index) =>
                <div key={score.endpointId} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{score.endpointId}</p>
                        <p className="text-xs text-gray-500">{score.serviceName} • {score.operationType}</p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="text-right">
                          <div className={`inline-block px-2 py-1 rounded text-sm font-medium ${getHealthScoreColor(score.overallScore)}`}>
                            {score.overallScore.toFixed(1)}%
                          </div>
                          <p className="text-xs text-gray-500 mt-1">
                            F:{score.functionalityScore.toFixed(0)} E:{score.errorHandlingScore.toFixed(0)} V:{score.validationScore.toFixed(0)}
                          </p>
                        </div>
                      </div>
                    </div>
                )}
                  {healthScores.length > 20 &&
                <p className="text-center text-sm text-gray-500">
                      Showing top 20 endpoints. Full list available in detailed report.
                    </p>
                }
                </div> :

              <div className="text-center py-8">
                  <Shield className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-600">No health scores available.</p>
                  <p className="text-sm text-gray-500">Run tests to generate health scores.</p>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="issues" className="space-y-4">
          {/* Critical Issues */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-red-600">
                <XCircle className="h-5 w-5 mr-2" />
                Critical Issues
              </CardTitle>
            </CardHeader>
            <CardContent>
              {report.issueSummary.criticalIssues.length > 0 ?
              <div className="space-y-2">
                  {report.issueSummary.criticalIssues.map((issue, index) =>
                <Alert key={index} variant="destructive">
                      <XCircle className="h-4 w-4" />
                      <AlertDescription>{issue}</AlertDescription>
                    </Alert>
                )}
                </div> :

              <div className="text-center py-8">
                  <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <p className="text-green-600 font-medium">No critical issues found!</p>
                  <p className="text-sm text-gray-500">Your API endpoints are performing well.</p>
                </div>
              }
            </CardContent>
          </Card>

          {/* Warnings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-yellow-600">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Warnings
              </CardTitle>
            </CardHeader>
            <CardContent>
              {report.issueSummary.warnings.length > 0 ?
              <div className="space-y-2">
                  {report.issueSummary.warnings.slice(0, 10).map((warning, index) =>
                <Alert key={index}>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{warning}</AlertDescription>
                    </Alert>
                )}
                  {report.issueSummary.warnings.length > 10 &&
                <p className="text-sm text-gray-500 text-center">
                      +{report.issueSummary.warnings.length - 10} more warnings in detailed report
                    </p>
                }
                </div> :

              <div className="text-center py-8">
                  <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                  <p className="text-green-600">No warnings found!</p>
                </div>
              }
            </CardContent>
          </Card>

          {/* Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-blue-600">
                <TrendingUp className="h-5 w-5 mr-2" />
                Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {report.issueSummary.recommendations.slice(0, 8).map((recommendation, index) =>
                <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                    <p className="text-sm text-blue-800">{recommendation}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Average Response Time</span>
                    <span className="font-medium">{report.performanceMetrics.averageResponseTime.toFixed(2)}ms</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Fastest Endpoint</span>
                    <div className="text-right">
                      <p className="font-medium">{report.performanceMetrics.fastestEndpoint.time.toFixed(2)}ms</p>
                      <p className="text-xs text-gray-500">{report.performanceMetrics.fastestEndpoint.name}</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Slowest Endpoint</span>
                    <div className="text-right">
                      <p className="font-medium">{report.performanceMetrics.slowestEndpoint.time.toFixed(2)}ms</p>
                      <p className="text-xs text-gray-500">{report.performanceMetrics.slowestEndpoint.name}</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Timeout Occurrences</span>
                    <span className="font-medium">{report.performanceMetrics.timeoutOccurrences}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Test Execution Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Total Execution Time</span>
                    <span className="font-medium">
                      {(report.executionSummary.totalExecutionTime / 1000).toFixed(2)}s
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Average Test Time</span>
                    <span className="font-medium">
                      {report.executionSummary.averageExecutionTime.toFixed(2)}ms
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Started</span>
                    <span className="font-medium">{report.startTime.toLocaleTimeString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Completed</span>
                    <span className="font-medium">{report.endTime.toLocaleTimeString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>);

};