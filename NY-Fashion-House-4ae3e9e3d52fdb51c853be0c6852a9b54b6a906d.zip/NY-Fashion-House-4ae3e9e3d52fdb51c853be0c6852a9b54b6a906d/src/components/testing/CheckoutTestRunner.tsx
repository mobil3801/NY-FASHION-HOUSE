
import React, { useState } from 'react';
import { Play, AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { criticalFlowTests } from '@/services/criticalFlowTests';
import { testDataSeeder } from '@/services/testDataSeeder';

interface TestResult {
  testId: string;
  name: string;
  status: 'running' | 'passed' | 'failed' | 'error';
  duration: number;
  message: string;
  details?: any;
}

const CheckoutTestRunner: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [progress, setProgress] = useState(0);
  const [setupComplete, setSetupComplete] = useState(false);

  // Setup test environment
  const setupTestEnvironment = async (): Promise<boolean> => {
    try {
      console.log('[CheckoutTestRunner] Setting up test environment...');

      // Seed test data
      const seedResult = await testDataSeeder.seedTestProducts();
      if (!seedResult.success) {
        console.warn('[CheckoutTestRunner] Test data seeding failed:', seedResult.message);
      }

      setSetupComplete(true);
      return true;
    } catch (error) {
      console.error('[CheckoutTestRunner] Setup failed:', error);
      return false;
    }
  };

  // Run the complete checkout process test
  const runCheckoutTest = async () => {
    if (isRunning) return;

    setIsRunning(true);
    setTestResults([]);
    setProgress(0);

    try {
      // Setup environment first
      const setupSuccess = await setupTestEnvironment();
      if (!setupSuccess) {
        setTestResults([{
          testId: 'setup-error',
          name: 'Environment Setup',
          status: 'error',
          duration: 0,
          message: 'Failed to setup test environment'
        }]);
        setIsRunning(false);
        return;
      }

      setProgress(20);

      // Run POS checkout flow tests
      console.log('[CheckoutTestRunner] Starting POS checkout flow tests...');

      const posResults = await criticalFlowTests.executePOSFlowTests();
      setProgress(80);

      // Convert results to display format
      const displayResults: TestResult[] = posResults.executionResults.map((result) => ({
        testId: result.testId,
        name: posResults.scenarios.find((s) => s.name === result.details.steps[0]?.step)?.name || 'Unknown Test',
        status: result.status as any,
        duration: result.duration,
        message: result.details.error || result.details.actualResult || 'Test completed',
        details: result.details
      }));

      setTestResults(displayResults);
      setProgress(100);

      console.log('[CheckoutTestRunner] Test execution completed:', {
        flowCompleted: posResults.flowCompleted,
        criticalIssues: posResults.criticalIssues.length,
        recommendations: posResults.recommendations.length
      });

    } catch (error) {
      console.error('[CheckoutTestRunner] Test execution failed:', error);
      setTestResults([{
        testId: 'execution-error',
        name: 'Test Execution',
        status: 'error',
        duration: 0,
        message: error instanceof Error ? error.message : 'Unknown error occurred'
      }]);
    } finally {
      setIsRunning(false);
      setTimeout(() => setProgress(0), 2000);
    }
  };

  const getStatusIcon = (status: TestResult['status']) => {
    switch (status) {
      case 'running':
        return <Clock className="h-4 w-4 text-yellow-500 animate-spin" />;
      case 'passed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-orange-500" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: TestResult['status']) => {
    switch (status) {
      case 'running':
        return 'yellow';
      case 'passed':
        return 'green';
      case 'failed':
        return 'red';
      case 'error':
        return 'orange';
      default:
        return 'gray';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-2xl font-bold">POS Checkout Test Runner</h2>
            <p className="text-gray-600 mt-1">
              Test the complete checkout process from product search to payment completion
            </p>
          </div>
          <Button
            onClick={runCheckoutTest}
            disabled={isRunning}
            className="flex items-center gap-2">

            <Play className="h-4 w-4" />
            {isRunning ? 'Running Tests...' : 'Run Checkout Test'}
          </Button>
        </div>

        {isRunning &&
        <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Test Progress</span>
              <span className="text-sm text-gray-500">{progress}%</span>
            </div>
            <Progress value={progress} className="w-full" />
          </div>
        }

        {setupComplete &&
        <div className="mb-4 p-3 bg-green-50 rounded-lg">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span className="text-sm text-green-700">Test environment setup completed</span>
            </div>
          </div>
        }
      </Card>

      {testResults.length > 0 &&
      <Card className="p-6">
          <h3 className="text-xl font-semibold mb-4">Test Results</h3>
          
          <div className="space-y-4">
            {testResults.map((result, index) =>
          <div key={result.testId} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(result.status)}
                    <div>
                      <h4 className="font-medium">{result.name}</h4>
                      <p className="text-sm text-gray-600">{result.testId}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant={getStatusColor(result.status) as any}>
                      {result.status}
                    </Badge>
                    <p className="text-xs text-gray-500 mt-1">{result.duration}ms</p>
                  </div>
                </div>

                <div className="bg-gray-50 p-3 rounded text-sm">
                  <p className="font-medium mb-1">Result:</p>
                  <p>{result.message}</p>
                  
                  {result.details && result.details.steps &&
              <div className="mt-3">
                      <p className="font-medium mb-2">Test Steps:</p>
                      <div className="space-y-1">
                        {result.details.steps.map((step: any, stepIndex: number) =>
                  <div key={stepIndex} className="flex justify-between items-center text-xs">
                            <span>{step.step}</span>
                            <Badge variant={step.status === 'passed' ? 'default' : 'destructive'} className="text-xs">
                              {step.status}
                            </Badge>
                          </div>
                  )}
                      </div>
                    </div>
              }
                </div>
              </div>
          )}
          </div>
        </Card>
      }
    </div>);

};

export default CheckoutTestRunner;