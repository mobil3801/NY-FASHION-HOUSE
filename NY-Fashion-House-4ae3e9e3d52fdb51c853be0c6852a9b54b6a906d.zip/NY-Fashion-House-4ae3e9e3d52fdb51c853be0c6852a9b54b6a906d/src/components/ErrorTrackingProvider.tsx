// Error Tracking Provider - Unified error boundary and context provider
import React, { Component, ReactNode, createContext, useContext } from 'react';
import { comprehensiveErrorTrackingService, ComprehensiveErrorReport } from '@/services/comprehensiveErrorTrackingService';
import { ErrorContext } from '@/types/errorTypes';

interface ErrorTrackingContextType {
  logError: (error: Error | string, context?: ErrorContext) => Promise<string>;
  getErrorReports: () => ComprehensiveErrorReport[];
  resolveError: (id: string) => boolean;
  retryOperation: (errorId: string) => Promise<boolean>;
  clearAllErrors: () => void;
}

const ErrorTrackingContext = createContext<ErrorTrackingContextType | null>(null);

interface ErrorTrackingProviderProps {
  children: ReactNode;
  level?: 'root' | 'page' | 'component';
  component?: string;
  fallback?: ReactNode;
}

interface ErrorTrackingState {
  hasError: boolean;
  errorId: string | null;
  error: Error | null;
}

export class ErrorTrackingProvider extends Component<ErrorTrackingProviderProps, ErrorTrackingState> {
  public state: ErrorTrackingState = {
    hasError: false,
    errorId: null,
    error: null
  };

  public static getDerivedStateFromError(error: Error): Partial<ErrorTrackingState> {
    return { hasError: true, error };
  }

  public async componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    const errorHandler = comprehensiveErrorTrackingService.createErrorBoundaryHandler(
      this.props.component || 'Unknown',
      this.props.level || 'component'
    );

    await errorHandler(error, errorInfo);

    const errorId = await comprehensiveErrorTrackingService.logError(error, {
      category: 'client',
      severity: this.props.level === 'root' ? 'critical' : 'high',
      component: this.props.component,
      action: 'React Error Boundary',
      componentStack: errorInfo.componentStack,
      additionalData: {
        errorBoundaryLevel: this.props.level,
        reactErrorInfo: errorInfo
      }
    });

    this.setState({ errorId });
  }

  private handleRetry = () => {
    this.setState({
      hasError: false,
      errorId: null,
      error: null
    });
  };

  private handleResolve = () => {
    if (this.state.errorId) {
      comprehensiveErrorTrackingService.resolveError(this.state.errorId);
    }
    this.handleRetry();
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      const isRootLevel = this.props.level === 'root';

      return (
        <div className={`${isRootLevel ? 'min-h-screen bg-gray-50 flex items-center justify-center p-4' : 'p-4 border border-red-200 bg-red-50 rounded-lg'}`}>
          <div className="max-w-md w-full">
            <div className="text-center">
              <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
              </div>
              
              <h2 className="text-lg font-semibold text-red-600 mb-2">
                {isRootLevel ? 'Application Error' : 'Component Error'}
              </h2>
              
              <p className="text-sm text-gray-600 mb-4">
                {isRootLevel ?
                'The application encountered an unexpected error.' :
                'This section failed to load properly.'
                }
              </p>

              {this.state.errorId &&
              <p className="text-xs text-gray-500 mb-4 p-2 bg-gray-100 rounded">
                  Error ID: {this.state.errorId}
                </p>
              }

              <div className="flex gap-2 justify-center">
                <button
                  onClick={this.handleRetry}
                  className="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700 transition-colors">

                  Try Again
                </button>
                
                <button
                  onClick={this.handleResolve}
                  className="px-4 py-2 bg-gray-300 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-400 transition-colors">

                  Dismiss
                </button>

                {isRootLevel &&
                <button
                  onClick={() => window.location.href = '/'}
                  className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 transition-colors">

                    Home
                  </button>
                }
              </div>

              {process.env.NODE_ENV === 'development' && this.state.error &&
              <details className="mt-4 text-left">
                  <summary className="cursor-pointer text-sm font-medium text-gray-700">
                    Debug Information
                  </summary>
                  <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded text-xs">
                    <p className="font-medium text-red-800 mb-2">Error:</p>
                    <pre className="text-red-700 whitespace-pre-wrap mb-2">
                      {this.state.error.message}
                    </pre>
                    {this.state.error.stack &&
                  <>
                        <p className="font-medium text-red-800 mb-2">Stack:</p>
                        <pre className="text-red-600 whitespace-pre-wrap text-xs max-h-32 overflow-y-auto">
                          {this.state.error.stack}
                        </pre>
                      </>
                  }
                  </div>
                </details>
              }
            </div>
          </div>
        </div>);

    }

    const contextValue: ErrorTrackingContextType = {
      logError: comprehensiveErrorTrackingService.logError.bind(comprehensiveErrorTrackingService),
      getErrorReports: comprehensiveErrorTrackingService.getErrorReports.bind(comprehensiveErrorTrackingService),
      resolveError: comprehensiveErrorTrackingService.resolveError.bind(comprehensiveErrorTrackingService),
      retryOperation: comprehensiveErrorTrackingService.retryOperation.bind(comprehensiveErrorTrackingService),
      clearAllErrors: comprehensiveErrorTrackingService.clearAllErrors.bind(comprehensiveErrorTrackingService)
    };

    return (
      <ErrorTrackingContext.Provider value={contextValue}>
        {this.props.children}
      </ErrorTrackingContext.Provider>);

  }
}

// Hook for accessing error tracking context
export const useErrorTracking = (): ErrorTrackingContextType => {
  const context = useContext(ErrorTrackingContext);
  if (!context) {
    throw new Error('useErrorTracking must be used within an ErrorTrackingProvider');
  }
  return context;
};

// Higher-order component for wrapping components with error tracking
export const withErrorTracking = <P extends object,>(
Component: React.ComponentType<P>,
options: {
  component?: string;
  level?: 'page' | 'component';
  fallback?: ReactNode;
} = {}) =>
{
  return React.forwardRef<any, P>((props, ref) =>
  <ErrorTrackingProvider {...options}>
      <Component {...props} ref={ref} />
    </ErrorTrackingProvider>
  );
};

export default ErrorTrackingProvider;