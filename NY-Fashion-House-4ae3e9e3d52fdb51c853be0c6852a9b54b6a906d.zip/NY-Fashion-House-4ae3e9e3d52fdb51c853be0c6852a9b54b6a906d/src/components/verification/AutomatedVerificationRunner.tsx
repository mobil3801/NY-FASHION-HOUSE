import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Play,
  Pause,
  Square,
  Clock,
  Calendar,
  Settings,
  History,
  CheckCircle2,
  XCircle,
  AlertTriangle } from
'lucide-react';
import { toast } from 'sonner';
import { dataVerificationService } from '@/services/comprehensiveDataVerificationService';
import { dataFlowVerificationService } from '@/services/dataFlowVerificationService';

interface ScheduleConfig {
  enabled: boolean;
  interval: 'hourly' | 'daily' | 'weekly' | 'monthly';
  includeIntegrity: boolean;
  includeFlow: boolean;
  lastRun?: string;
  nextRun?: string;
}

interface TestRun {
  id: string;
  timestamp: string;
  type: 'integrity' | 'flow' | 'both';
  status: 'running' | 'completed' | 'failed';
  duration: number;
  results?: {
    integrityPassed?: boolean;
    flowPassed?: boolean;
    totalErrors: number;
    totalWarnings: number;
  };
}

export const AutomatedVerificationRunner: React.FC = () => {
  const [scheduleConfig, setScheduleConfig] = useState<ScheduleConfig>({
    enabled: false,
    interval: 'daily',
    includeIntegrity: true,
    includeFlow: true
  });

  const [testRuns, setTestRuns] = useState<TestRun[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [currentRun, setCurrentRun] = useState<TestRun | null>(null);

  // Load saved configuration from localStorage
  useEffect(() => {
    const savedConfig = localStorage.getItem('verificationSchedule');
    if (savedConfig) {
      try {
        const config = JSON.parse(savedConfig);
        setScheduleConfig(config);
      } catch (error) {
        console.error('Failed to load saved schedule configuration:', error);
      }
    }

    const savedRuns = localStorage.getItem('verificationRuns');
    if (savedRuns) {
      try {
        const runs = JSON.parse(savedRuns);
        setTestRuns(runs);
      } catch (error) {
        console.error('Failed to load saved test runs:', error);
      }
    }
  }, []);

  // Save configuration changes
  useEffect(() => {
    localStorage.setItem('verificationSchedule', JSON.stringify(scheduleConfig));
    updateNextRunTime();
  }, [scheduleConfig]);

  // Save test runs changes
  useEffect(() => {
    localStorage.setItem('verificationRuns', JSON.stringify(testRuns));
  }, [testRuns]);

  const updateNextRunTime = () => {
    if (!scheduleConfig.enabled) return;

    const now = new Date();
    let nextRun = new Date();

    switch (scheduleConfig.interval) {
      case 'hourly':
        nextRun = new Date(now.getTime() + 60 * 60 * 1000);
        break;
      case 'daily':
        nextRun = new Date(now.getTime() + 24 * 60 * 60 * 1000);
        break;
      case 'weekly':
        nextRun = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        nextRun = new Date(now.getFullYear(), now.getMonth() + 1, now.getDate());
        break;
    }

    setScheduleConfig((prev) => ({
      ...prev,
      nextRun: nextRun.toISOString()
    }));
  };

  const runVerification = async (type: 'integrity' | 'flow' | 'both' = 'both', isScheduled = false) => {
    const runId = `run_${Date.now()}`;
    const startTime = Date.now();

    const newRun: TestRun = {
      id: runId,
      timestamp: new Date().toISOString(),
      type,
      status: 'running',
      duration: 0
    };

    setCurrentRun(newRun);
    setTestRuns((prev) => [newRun, ...prev.slice(0, 49)]); // Keep last 50 runs
    setIsRunning(true);

    if (!isScheduled) {
      toast.info(`Starting ${type} verification...`);
    }

    try {
      let integrityPassed = true;
      let flowPassed = true;
      let totalErrors = 0;
      let totalWarnings = 0;

      if (type === 'integrity' || type === 'both') {
        const integrityReport = await dataVerificationService.runComprehensiveVerification();
        integrityPassed = integrityReport.overallStatus === 'PASSED';
        totalErrors += integrityReport.summary.criticalErrors;
        totalWarnings += integrityReport.summary.warnings;
      }

      if (type === 'flow' || type === 'both') {
        const flowReport = await dataFlowVerificationService.runCrossServiceValidation();
        flowPassed = flowReport.overallSuccess;
        // Count flow errors and warnings
        flowReport.testResults.forEach((test) => {
          totalErrors += test.errors.length;
          totalWarnings += test.warnings.length;
        });
      }

      const duration = Date.now() - startTime;
      const completedRun: TestRun = {
        ...newRun,
        status: 'completed',
        duration,
        results: {
          integrityPassed: type === 'integrity' || type === 'both' ? integrityPassed : undefined,
          flowPassed: type === 'flow' || type === 'both' ? flowPassed : undefined,
          totalErrors,
          totalWarnings
        }
      };

      setCurrentRun(completedRun);
      setTestRuns((prev) => [completedRun, ...prev.slice(1)]);

      // Update last run time in schedule
      setScheduleConfig((prev) => ({
        ...prev,
        lastRun: new Date().toISOString()
      }));

      const overallSuccess = (type === 'integrity' || type === 'both' ? integrityPassed : true) && (
      type === 'flow' || type === 'both' ? flowPassed : true);

      if (!isScheduled) {
        if (overallSuccess) {
          toast.success('Verification completed successfully');
        } else {
          toast.error(`Verification completed with ${totalErrors} errors and ${totalWarnings} warnings`);
        }
      }

    } catch (error) {
      console.error('Verification failed:', error);

      const failedRun: TestRun = {
        ...newRun,
        status: 'failed',
        duration: Date.now() - startTime,
        results: {
          totalErrors: 1,
          totalWarnings: 0
        }
      };

      setCurrentRun(failedRun);
      setTestRuns((prev) => [failedRun, ...prev.slice(1)]);

      if (!isScheduled) {
        toast.error('Verification failed: ' + (error instanceof Error ? error.message : 'Unknown error'));
      }
    } finally {
      setIsRunning(false);
    }
  };

  const toggleSchedule = (enabled: boolean) => {
    setScheduleConfig((prev) => ({ ...prev, enabled }));

    if (enabled) {
      toast.success('Automated verification scheduled');
    } else {
      toast.info('Automated verification disabled');
    }
  };

  const getRunStatusIcon = (status: TestRun['status'], results?: TestRun['results']) => {
    if (status === 'running') {
      return <Clock size={16} className="text-blue-600 animate-pulse" />;
    } else if (status === 'failed') {
      return <XCircle size={16} className="text-red-600" />;
    } else if (results && results.totalErrors > 0) {
      return <XCircle size={16} className="text-red-600" />;
    } else if (results && results.totalWarnings > 0) {
      return <AlertTriangle size={16} className="text-yellow-600" />;
    }
    return <CheckCircle2 size={16} className="text-green-600" />;
  };

  const getRunStatusBadge = (run: TestRun) => {
    if (run.status === 'running') {
      return <Badge className="bg-blue-100 text-blue-800">Running</Badge>;
    } else if (run.status === 'failed') {
      return <Badge className="bg-red-100 text-red-800">Failed</Badge>;
    } else if (run.results && run.results.totalErrors > 0) {
      return <Badge className="bg-red-100 text-red-800">Errors</Badge>;
    } else if (run.results && run.results.totalWarnings > 0) {
      return <Badge className="bg-yellow-100 text-yellow-800">Warnings</Badge>;
    }
    return <Badge className="bg-green-100 text-green-800">Passed</Badge>;
  };

  const formatDuration = (ms: number) => {
    if (ms < 1000) return `${ms}ms`;
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    }
    return `${seconds}s`;
  };

  const clearHistory = () => {
    setTestRuns([]);
    toast.success('Test run history cleared');
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Automated Verification Runner</h1>
        <p className="text-gray-600">
          Schedule and manage automated data integrity and flow verification tests
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Schedule Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings size={20} />
              Schedule Configuration
            </CardTitle>
            <CardDescription>
              Set up automated verification schedules
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium">Enable Automated Verification</span>
              <Switch
                checked={scheduleConfig.enabled}
                onCheckedChange={toggleSchedule} />

            </div>

            {scheduleConfig.enabled &&
            <>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Run Interval</label>
                  <Select
                  value={scheduleConfig.interval}
                  onValueChange={(value: any) =>
                  setScheduleConfig((prev) => ({ ...prev, interval: value }))
                  }>

                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <label className="text-sm font-medium">Include Tests</label>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Data Integrity Verification</span>
                    <Switch
                    checked={scheduleConfig.includeIntegrity}
                    onCheckedChange={(checked) =>
                    setScheduleConfig((prev) => ({ ...prev, includeIntegrity: checked }))
                    } />

                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Data Flow Verification</span>
                    <Switch
                    checked={scheduleConfig.includeFlow}
                    onCheckedChange={(checked) =>
                    setScheduleConfig((prev) => ({ ...prev, includeFlow: checked }))
                    } />

                  </div>
                </div>

                {scheduleConfig.nextRun &&
              <Alert>
                    <Calendar size={16} />
                    <AlertDescription>
                      Next scheduled run: {new Date(scheduleConfig.nextRun).toLocaleString()}
                    </AlertDescription>
                  </Alert>
              }
              </>
            }
          </CardContent>
        </Card>

        {/* Manual Controls */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Play size={20} />
              Manual Controls
            </CardTitle>
            <CardDescription>
              Run verification tests manually
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-3">
              <Button
                onClick={() => runVerification('integrity')}
                disabled={isRunning}
                className="justify-start">

                Run Data Integrity Check
              </Button>
              <Button
                onClick={() => runVerification('flow')}
                disabled={isRunning}
                variant="outline"
                className="justify-start">

                Run Data Flow Verification
              </Button>
              <Button
                onClick={() => runVerification('both')}
                disabled={isRunning}
                variant="secondary"
                className="justify-start">

                Run Complete Verification
              </Button>
            </div>

            {currentRun && currentRun.status === 'running' &&
            <Alert>
                <Clock size={16} className="animate-pulse" />
                <AlertDescription>
                  Running {currentRun.type} verification...
                </AlertDescription>
              </Alert>
            }
          </CardContent>
        </Card>
      </div>

      {/* Test Run History */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <History size={20} />
                Test Run History
              </CardTitle>
              <CardDescription>
                Recent verification test results
              </CardDescription>
            </div>
            {testRuns.length > 0 &&
            <Button variant="outline" size="sm" onClick={clearHistory}>
                Clear History
              </Button>
            }
          </div>
        </CardHeader>
        <CardContent>
          {testRuns.length === 0 ?
          <div className="text-center text-gray-500 py-8">
              No test runs yet. Run a verification to see results here.
            </div> :

          <ScrollArea className="h-96">
              <div className="space-y-3">
                {testRuns.map((run) =>
              <div
                key={run.id}
                className="border rounded-lg p-4 hover:bg-gray-50">

                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        {getRunStatusIcon(run.status, run.results)}
                        <span className="font-medium">
                          {run.type.charAt(0).toUpperCase() + run.type.slice(1)} Verification
                        </span>
                        {getRunStatusBadge(run)}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span>{new Date(run.timestamp).toLocaleString()}</span>
                        <span>•</span>
                        <span>{formatDuration(run.duration)}</span>
                      </div>
                    </div>

                    {run.results &&
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        {run.results.integrityPassed !== undefined &&
                  <div>
                            <span className="text-gray-600">Data Integrity:</span>
                            <span className={`ml-2 font-medium ${
                    run.results.integrityPassed ? 'text-green-600' : 'text-red-600'}`
                    }>
                              {run.results.integrityPassed ? 'Passed' : 'Failed'}
                            </span>
                          </div>
                  }
                        {run.results.flowPassed !== undefined &&
                  <div>
                            <span className="text-gray-600">Data Flow:</span>
                            <span className={`ml-2 font-medium ${
                    run.results.flowPassed ? 'text-green-600' : 'text-red-600'}`
                    }>
                              {run.results.flowPassed ? 'Passed' : 'Failed'}
                            </span>
                          </div>
                  }
                        <div>
                          <span className="text-gray-600">Errors:</span>
                          <span className="ml-2 font-medium text-red-600">
                            {run.results.totalErrors}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-600">Warnings:</span>
                          <span className="ml-2 font-medium text-yellow-600">
                            {run.results.totalWarnings}
                          </span>
                        </div>
                      </div>
                }
                  </div>
              )}
              </div>
            </ScrollArea>
          }
        </CardContent>
      </Card>
    </div>);

};

export default AutomatedVerificationRunner;