import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Database,
  Activity,
  Play,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Info } from
'lucide-react';
import { toast } from 'sonner';
import {
  dataVerificationService,
  type DataIntegrityReport,
  type TableValidationResult } from
'@/services/comprehensiveDataVerificationService';
import {
  dataFlowVerificationService,
  type CrossServiceValidationResult } from
'@/services/dataFlowVerificationService';

export const DataVerificationDashboard: React.FC = () => {
  const [integrityReport, setIntegrityReport] = useState<DataIntegrityReport | null>(null);
  const [flowReport, setFlowReport] = useState<CrossServiceValidationResult | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedTable, setSelectedTable] = useState<TableValidationResult | null>(null);

  const runVerification = async (type: 'integrity' | 'flow' | 'both' = 'both') => {
    setIsRunning(true);
    try {
      if (type === 'integrity' || type === 'both') {
        toast.info('Running data integrity verification...');
        const report = await dataVerificationService.runComprehensiveVerification();
        setIntegrityReport(report);
      }

      if (type === 'flow' || type === 'both') {
        toast.info('Running data flow verification...');
        const flowReport = await dataFlowVerificationService.runCrossServiceValidation();
        setFlowReport(flowReport);
      }

      toast.success('Verification completed successfully');
    } catch (error) {
      console.error('Verification failed:', error);
      toast.error('Verification failed: ' + (error instanceof Error ? error.message : 'Unknown error'));
    } finally {
      setIsRunning(false);
    }
  };

  const getStatusIcon = (status: string, size: number = 20) => {
    switch (status) {
      case 'PASSED':
        return <CheckCircle2 size={size} className="text-green-600" />;
      case 'FAILED':
        return <XCircle size={size} className="text-red-600" />;
      case 'WARNING':
        return <AlertTriangle size={size} className="text-yellow-600" />;
      default:
        return <Info size={size} className="text-blue-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PASSED':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'FAILED':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'WARNING':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const formatExecutionTime = (time: number) => {
    if (time < 1000) return `${time}ms`;
    return `${(time / 1000).toFixed(2)}s`;
  };

  const OverviewTab = () =>
  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Data Integrity Summary */}
      {integrityReport &&
    <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Database size={20} />
              Data Integrity Report
            </CardTitle>
            <CardDescription>
              Comprehensive database validation results
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium">Overall Status</span>
              <div className="flex items-center gap-2">
                {getStatusIcon(integrityReport.overallStatus)}
                <Badge className={getStatusColor(integrityReport.overallStatus)}>
                  {integrityReport.overallStatus}
                </Badge>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Tables Checked</span>
                  <span className="font-medium">{integrityReport.summary.tablesChecked}/{integrityReport.summary.totalTables}</span>
                </div>
                <div className="flex justify-between">
                  <span>Critical Errors</span>
                  <span className="font-medium text-red-600">{integrityReport.summary.criticalErrors}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Warnings</span>
                  <span className="font-medium text-yellow-600">{integrityReport.summary.warnings}</span>
                </div>
                <div className="flex justify-between">
                  <span>Execution Time</span>
                  <span className="font-medium">{formatExecutionTime(integrityReport.performanceMetrics.totalExecutionTime)}</span>
                </div>
              </div>
            </div>

            <Progress
          value={integrityReport.summary.successfulOperations / integrityReport.summary.tablesChecked * 100}
          className="h-2" />

          </CardContent>
        </Card>
    }

      {/* Data Flow Summary */}
      {flowReport &&
    <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Activity size={20} />
              Data Flow Report
            </CardTitle>
            <CardDescription>
              Cross-service integration validation results
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium">Overall Status</span>
              <div className="flex items-center gap-2">
                {getStatusIcon(flowReport.overallSuccess ? 'PASSED' : 'FAILED')}
                <Badge className={getStatusColor(flowReport.overallSuccess ? 'PASSED' : 'FAILED')}>
                  {flowReport.overallSuccess ? 'PASSED' : 'FAILED'}
                </Badge>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Tests Passed</span>
                  <span className="font-medium text-green-600">{flowReport.summary.passedTests}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tests Failed</span>
                  <span className="font-medium text-red-600">{flowReport.summary.failedTests}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Total Operations</span>
                  <span className="font-medium">{flowReport.summary.totalOperations}</span>
                </div>
                <div className="flex justify-between">
                  <span>Avg Response</span>
                  <span className="font-medium">{formatExecutionTime(flowReport.summary.averageExecutionTime)}</span>
                </div>
              </div>
            </div>

            <Progress
          value={flowReport.summary.passedTests / flowReport.summary.totalTests * 100}
          className="h-2" />

          </CardContent>
        </Card>
    }

      {/* Quick Actions */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Button
            onClick={() => runVerification('integrity')}
            disabled={isRunning}
            className="flex items-center gap-2">

              {isRunning ? <RefreshCw size={16} className="animate-spin" /> : <Database size={16} />}
              Run Data Integrity Check
            </Button>
            <Button
            onClick={() => runVerification('flow')}
            disabled={isRunning}
            className="flex items-center gap-2"
            variant="outline">

              {isRunning ? <RefreshCw size={16} className="animate-spin" /> : <Activity size={16} />}
              Run Flow Verification
            </Button>
            <Button
            onClick={() => runVerification('both')}
            disabled={isRunning}
            className="flex items-center gap-2"
            variant="secondary">

              {isRunning ? <RefreshCw size={16} className="animate-spin" /> : <Play size={16} />}
              Run Complete Verification
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>;


  const IntegrityDetailsTab = () =>
  <div className="space-y-6">
      {integrityReport ?
    <>
          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp size={20} />
                Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">
                    {formatExecutionTime(integrityReport.performanceMetrics.totalExecutionTime)}
                  </div>
                  <div className="text-gray-600">Total Execution Time</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">
                    {formatExecutionTime(integrityReport.performanceMetrics.averageResponseTime)}
                  </div>
                  <div className="text-gray-600">Average Response Time</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-lg font-bold text-orange-600">
                    {integrityReport.performanceMetrics.slowestOperation || 'N/A'}
                  </div>
                  <div className="text-gray-600">Slowest Operation</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Table Results */}
          <Card>
            <CardHeader>
              <CardTitle>Table Validation Results</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {integrityReport.tableResults.map((table, index) =>
              <div
                key={index}
                className="border rounded-lg p-4 cursor-pointer hover:bg-gray-50"
                onClick={() => setSelectedTable(table)}>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(table.isValid ? 'PASSED' : 'FAILED', 16)}
                          <span className="font-medium">{table.tableName}</span>
                          <Badge variant="secondary">ID: {table.tableId}</Badge>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <span>{table.recordsChecked} records</span>
                          {table.errors.length > 0 &&
                    <Badge variant="destructive">{table.errors.length} errors</Badge>
                    }
                          {table.warnings.length > 0 &&
                    <Badge className="bg-yellow-100 text-yellow-800">{table.warnings.length} warnings</Badge>
                    }
                        </div>
                      </div>
                    </div>
              )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </> :

    <Alert>
          <Info size={16} />
          <AlertDescription>
            No data integrity report available. Run a verification to see detailed results.
          </AlertDescription>
        </Alert>
    }
    </div>;


  const FlowDetailsTab = () =>
  <div className="space-y-6">
      {flowReport ?
    <>
          {/* Flow Test Results */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity size={20} />
                Cross-Service Flow Tests
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {flowReport.testResults.map((test, index) =>
              <Card key={index} className="border">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            {getStatusIcon(test.success ? 'PASSED' : 'FAILED', 16)}
                            <span className="font-medium">{test.testName}</span>
                          </div>
                          <Badge className={getStatusColor(test.success ? 'PASSED' : 'FAILED')}>
                            {test.success ? 'PASSED' : 'FAILED'}
                          </Badge>
                        </div>
                        
                        <p className="text-sm text-gray-600 mb-3">{test.description}</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium">Operations:</span> {test.operations.length}
                          </div>
                          <div>
                            <span className="font-medium">Execution Time:</span> {formatExecutionTime(test.executionTime)}
                          </div>
                          <div>
                            <span className="font-medium">Issues:</span> {test.errors.length + test.warnings.length}
                          </div>
                        </div>

                        {test.errors.length > 0 &&
                  <Alert className="mt-3 border-red-200">
                            <XCircle size={16} className="text-red-600" />
                            <AlertDescription>
                              <ul className="list-disc list-inside">
                                {test.errors.map((error, i) =>
                        <li key={i} className="text-red-700">{error}</li>
                        )}
                              </ul>
                            </AlertDescription>
                          </Alert>
                  }

                        {test.warnings.length > 0 &&
                  <Alert className="mt-3 border-yellow-200">
                            <AlertTriangle size={16} className="text-yellow-600" />
                            <AlertDescription>
                              <ul className="list-disc list-inside">
                                {test.warnings.map((warning, i) =>
                        <li key={i} className="text-yellow-700">{warning}</li>
                        )}
                              </ul>
                            </AlertDescription>
                          </Alert>
                  }
                      </CardContent>
                    </Card>
              )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </> :

    <Alert>
          <Info size={16} />
          <AlertDescription>
            No data flow report available. Run a verification to see detailed results.
          </AlertDescription>
        </Alert>
    }
    </div>;


  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Data Verification Dashboard</h1>
        <p className="text-gray-600">
          Comprehensive validation of data integrity, relationships, and cross-service flows
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <TrendingUp size={16} />
            Overview
          </TabsTrigger>
          <TabsTrigger value="integrity" className="flex items-center gap-2">
            <Database size={16} />
            Data Integrity
          </TabsTrigger>
          <TabsTrigger value="flows" className="flex items-center gap-2">
            <Activity size={16} />
            Data Flows
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab />
        </TabsContent>

        <TabsContent value="integrity">
          <IntegrityDetailsTab />
        </TabsContent>

        <TabsContent value="flows">
          <FlowDetailsTab />
        </TabsContent>
      </Tabs>

      {/* Table Details Modal */}
      {selectedTable &&
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-4xl max-h-[80vh] overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  {getStatusIcon(selectedTable.isValid ? 'PASSED' : 'FAILED')}
                  {selectedTable.tableName} Details
                </CardTitle>
                <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedTable(null)}>

                  ×
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Table ID:</span> {selectedTable.tableId}
                    </div>
                    <div>
                      <span className="font-medium">Records Checked:</span> {selectedTable.recordsChecked}
                    </div>
                  </div>

                  {selectedTable.errors.length > 0 &&
                <Alert className="border-red-200">
                      <XCircle size={16} className="text-red-600" />
                      <AlertDescription>
                        <strong>Errors:</strong>
                        <ul className="list-disc list-inside mt-2">
                          {selectedTable.errors.map((error, i) =>
                      <li key={i} className="text-red-700">{error}</li>
                      )}
                        </ul>
                      </AlertDescription>
                    </Alert>
                }

                  {selectedTable.warnings.length > 0 &&
                <Alert className="border-yellow-200">
                      <AlertTriangle size={16} className="text-yellow-600" />
                      <AlertDescription>
                        <strong>Warnings:</strong>
                        <ul className="list-disc list-inside mt-2">
                          {selectedTable.warnings.map((warning, i) =>
                      <li key={i} className="text-yellow-700">{warning}</li>
                      )}
                        </ul>
                      </AlertDescription>
                    </Alert>
                }

                  {selectedTable.businessRuleResults.length > 0 &&
                <div>
                      <h4 className="font-medium mb-2">Business Rule Results</h4>
                      <div className="space-y-2">
                        {selectedTable.businessRuleResults.map((rule, i) =>
                    <div key={i} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                            <span>{rule.rule}</span>
                            {getStatusIcon(rule.result.isValid ? 'PASSED' : 'FAILED', 14)}
                          </div>
                    )}
                      </div>
                    </div>
                }
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      }
    </div>);

};

export default DataVerificationDashboard;