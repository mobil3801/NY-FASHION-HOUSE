import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Calendar, Search, Filter, Eye, Download, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface SalesTransaction {
  id: number;
  product_id: number;
  product_name: string;
  quantity_sold: number;
  unit_price: number;
  total_amount: number;
  sale_date: string;
  employee_id: number;
  employee_name: string;
  notes: string;
}

interface SalesHistoryProps {
  employeeId?: number;
  showAllEmployees?: boolean;
}

const SalesHistory: React.FC<SalesHistoryProps> = ({ employeeId, showAllEmployees = false }) => {
  const [transactions, setTransactions] = useState<SalesTransaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<SalesTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('all');
  const [employeeFilter, setEmployeeFilter] = useState('all');
  const [selectedTransaction, setSelectedTransaction] = useState<SalesTransaction | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  useEffect(() => {
    loadTransactions();
  }, [employeeId]);

  useEffect(() => {
    filterTransactions();
  }, [transactions, searchTerm, dateFilter, employeeFilter]);

  const loadTransactions = async () => {
    try {
      setLoading(true);
      const filters: any[] = [];

      // If specific employee, filter by employee ID
      if (employeeId && !showAllEmployees) {
        filters.push({
          name: 'employee_id',
          op: 'Equal',
          value: employeeId
        });
      }

      const { data, error } = await window.ezsite.apis.tablePage(38156, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'sale_date',
        IsAsc: false,
        Filters: filters
      });

      if (error) throw new Error(error);
      setTransactions(data?.List || []);
    } catch (error) {
      console.error('Error loading sales history:', error);
      toast.error('Failed to load sales history');
    } finally {
      setLoading(false);
    }
  };

  const filterTransactions = () => {
    let filtered = [...transactions];

    // Search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter((transaction) =>
      transaction.product_name.toLowerCase().includes(term) ||
      transaction.employee_name.toLowerCase().includes(term) ||
      transaction.notes.toLowerCase().includes(term) ||
      transaction.id.toString().includes(term)
      );
    }

    // Date filter
    if (dateFilter !== 'all') {
      const now = new Date();
      const filterDate = new Date();

      switch (dateFilter) {
        case 'today':
          filterDate.setHours(0, 0, 0, 0);
          filtered = filtered.filter((t) => new Date(t.sale_date) >= filterDate);
          break;
        case 'week':
          filterDate.setDate(now.getDate() - 7);
          filtered = filtered.filter((t) => new Date(t.sale_date) >= filterDate);
          break;
        case 'month':
          filterDate.setDate(now.getDate() - 30);
          filtered = filtered.filter((t) => new Date(t.sale_date) >= filterDate);
          break;
        case 'quarter':
          filterDate.setDate(now.getDate() - 90);
          filtered = filtered.filter((t) => new Date(t.sale_date) >= filterDate);
          break;
      }
    }

    // Employee filter
    if (employeeFilter !== 'all') {
      filtered = filtered.filter((t) => t.employee_id.toString() === employeeFilter);
    }

    setFilteredTransactions(filtered);
    setCurrentPage(1);
  };

  const getUniqueEmployees = () => {
    const employees = transactions.reduce((acc, transaction) => {
      const key = `${transaction.employee_id}-${transaction.employee_name}`;
      if (!acc.find((emp) => emp.key === key)) {
        acc.push({
          key,
          id: transaction.employee_id,
          name: transaction.employee_name
        });
      }
      return acc;
    }, [] as Array<{key: string;id: number;name: string;}>);

    return employees.sort((a, b) => a.name.localeCompare(b.name));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTotalSales = () => {
    return filteredTransactions.reduce((sum, transaction) => sum + transaction.total_amount, 0);
  };

  const getTotalItems = () => {
    return filteredTransactions.reduce((sum, transaction) => sum + transaction.quantity_sold, 0);
  };

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedTransactions = filteredTransactions.slice(startIndex, startIndex + itemsPerPage);

  const exportToCSV = () => {
    const csvContent = [
    ['Transaction ID', 'Date', 'Product', 'Quantity', 'Unit Price', 'Total Amount', 'Employee', 'Notes'],
    ...filteredTransactions.map((t) => [
    t.id,
    formatDate(t.sale_date),
    t.product_name,
    t.quantity_sold,
    t.unit_price,
    t.total_amount,
    t.employee_name,
    t.notes || '']
    )].
    map((row) => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sales-history-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <span className="ml-2">Loading sales history...</span>
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Header with Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredTransactions.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Items Sold</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getTotalItems()}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Sales Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${getTotalSales().toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Sales History
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={loadTransactions}>

                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={exportToCSV}>

                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by product, employee, or transaction ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10" />

              </div>
            </div>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="md:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">Last Week</SelectItem>
                <SelectItem value="month">Last Month</SelectItem>
                <SelectItem value="quarter">Last Quarter</SelectItem>
              </SelectContent>
            </Select>
            {showAllEmployees &&
            <Select value={employeeFilter} onValueChange={setEmployeeFilter}>
                <SelectTrigger className="md:w-48">
                  <SelectValue placeholder="All Employees" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Employees</SelectItem>
                  {getUniqueEmployees().map((employee) =>
                <SelectItem key={employee.key} value={employee.id.toString()}>
                      {employee.name}
                    </SelectItem>
                )}
                </SelectContent>
              </Select>
            }
          </div>

          {/* Transactions Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transaction ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Unit Price</TableHead>
                  <TableHead>Total</TableHead>
                  {showAllEmployees && <TableHead>Employee</TableHead>}
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedTransactions.length === 0 ?
                <TableRow>
                    <TableCell
                    colSpan={showAllEmployees ? 8 : 7}
                    className="text-center text-gray-500 py-8">

                      No transactions found matching your criteria.
                    </TableCell>
                  </TableRow> :

                paginatedTransactions.map((transaction) =>
                <TableRow key={transaction.id}>
                      <TableCell className="font-medium">#{transaction.id}</TableCell>
                      <TableCell>{formatDate(transaction.sale_date)}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{transaction.product_name}</div>
                          {transaction.product_id &&
                      <div className="text-xs text-gray-500">
                              Product ID: {transaction.product_id}
                            </div>
                      }
                        </div>
                      </TableCell>
                      <TableCell>{transaction.quantity_sold}</TableCell>
                      <TableCell>${transaction.unit_price.toFixed(2)}</TableCell>
                      <TableCell className="font-semibold text-green-600">
                        ${transaction.total_amount.toFixed(2)}
                      </TableCell>
                      {showAllEmployees &&
                  <TableCell>{transaction.employee_name}</TableCell>
                  }
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedTransaction(transaction)}>

                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle>Transaction Details</DialogTitle>
                              <DialogDescription>
                                Transaction #{selectedTransaction?.id}
                              </DialogDescription>
                            </DialogHeader>
                            {selectedTransaction &&
                        <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <strong>Date:</strong>
                                    <div>{formatDate(selectedTransaction.sale_date)}</div>
                                  </div>
                                  <div>
                                    <strong>Employee:</strong>
                                    <div>{selectedTransaction.employee_name}</div>
                                  </div>
                                </div>
                                <div>
                                  <strong>Product:</strong>
                                  <div>{selectedTransaction.product_name}</div>
                                  <div className="text-xs text-gray-500">
                                    Product ID: {selectedTransaction.product_id}
                                  </div>
                                </div>
                                <div className="grid grid-cols-3 gap-4 text-sm">
                                  <div>
                                    <strong>Quantity:</strong>
                                    <div>{selectedTransaction.quantity_sold}</div>
                                  </div>
                                  <div>
                                    <strong>Unit Price:</strong>
                                    <div>${selectedTransaction.unit_price.toFixed(2)}</div>
                                  </div>
                                  <div>
                                    <strong>Total:</strong>
                                    <div className="font-semibold text-green-600">
                                      ${selectedTransaction.total_amount.toFixed(2)}
                                    </div>
                                  </div>
                                </div>
                                {selectedTransaction.notes &&
                          <div>
                                    <strong>Notes:</strong>
                                    <div className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                                      {selectedTransaction.notes}
                                    </div>
                                  </div>
                          }
                              </div>
                        }
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                )
                }
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 &&
          <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">
                Showing {startIndex + 1} to {Math.min(startIndex + itemsPerPage, filteredTransactions.length)} of{' '}
                {filteredTransactions.length} transactions
              </p>
              <div className="flex items-center space-x-2">
                <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}>

                  Previous
                </Button>
                <span className="text-sm">
                  Page {currentPage} of {totalPages}
                </span>
                <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}>

                  Next
                </Button>
              </div>
            </div>
          }
        </CardContent>
      </Card>
    </div>);

};

export default SalesHistory;