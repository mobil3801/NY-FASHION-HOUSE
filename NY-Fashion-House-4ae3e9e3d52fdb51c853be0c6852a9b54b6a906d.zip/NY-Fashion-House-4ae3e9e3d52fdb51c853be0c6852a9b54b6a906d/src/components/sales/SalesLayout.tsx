
import React from 'react';
import { Outlet } from 'react-router-dom';
import SalesHeader from './SalesHeader';

const SalesLayout: React.FC = () => {
  return (
    <div className="min-h-screen transition-colors duration-300" style={{
      background: `linear-gradient(135deg, var(--theme-background), var(--theme-muted))`
    }}>
      <SalesHeader />
      
      <main className="min-h-[calc(100vh-64px)]">
        <div className="container mx-auto px-4 py-6">
          <Outlet />
        </div>
      </main>
    </div>);

};

export default SalesLayout;