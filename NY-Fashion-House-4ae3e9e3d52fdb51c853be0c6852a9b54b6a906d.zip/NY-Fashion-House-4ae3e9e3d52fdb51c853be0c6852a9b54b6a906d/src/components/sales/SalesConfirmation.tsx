import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { CheckCircle, Download, Printer, Mail, ArrowLeft } from 'lucide-react';

interface Product {
  id: number;
  sku: string;
  name: string;
  selling_price: number;
  stock_level: number;
}

interface CartItem {
  product: Product;
  quantity: number;
  size?: string;
  color?: string;
  subtotal: number;
}

interface SalesTransaction {
  id: number;
  receiptNumber: string;
  saleDate: string;
  employeeName: string;
  items: CartItem[];
  subtotal: number;
  discountAmount: number;
  discountPercentage: number;
  taxAmount: number;
  taxPercentage: number;
  totalAmount: number;
  paymentMethod: string;
}

interface SalesConfirmationProps {
  transaction: SalesTransaction;
  onBackToSales: () => void;
  onPrintReceipt: () => void;
  onEmailReceipt?: () => void;
}

const SalesConfirmation: React.FC<SalesConfirmationProps> = ({
  transaction,
  onBackToSales,
  onPrintReceipt,
  onEmailReceipt
}) => {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Success Header */}
      <Card className="bg-green-50 border-green-200">
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="rounded-full bg-green-100 p-3">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-green-800">Sale Completed Successfully!</h1>
              <p className="text-green-600">
                Transaction has been recorded and inventory updated.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Receipt Details */}
      <Card className="bg-white">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Sales Receipt</CardTitle>
          <div className="space-y-1">
            <p className="text-lg font-semibold">Receipt #{transaction.receiptNumber}</p>
            <p className="text-gray-600">{formatDate(transaction.saleDate)}</p>
            <p className="text-sm text-gray-500">Served by: {transaction.employeeName}</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Items List */}
          <div className="space-y-3">
            <h3 className="font-semibold text-lg border-b pb-2">Items Purchased</h3>
            {transaction.items.map((item, index) =>
            <div key={index} className="flex items-start justify-between py-2">
                <div className="flex-1">
                  <div className="font-medium">{item.product.name}</div>
                  <div className="text-sm text-gray-500">SKU: {item.product.sku}</div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {item.size &&
                  <Badge variant="outline" className="text-xs">
                        Size: {item.size}
                      </Badge>
                  }
                    {item.color &&
                  <Badge variant="outline" className="text-xs">
                        Color: {item.color}
                      </Badge>
                  }
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">
                    {item.quantity} × ${item.product.selling_price.toFixed(2)}
                  </div>
                  <div className="text-lg font-bold text-green-600">
                    ${item.subtotal.toFixed(2)}
                  </div>
                </div>
              </div>
            )}
          </div>

          <Separator />

          {/* Totals Section */}
          <div className="space-y-2">
            <div className="flex justify-between text-base">
              <span>Subtotal:</span>
              <span>${transaction.subtotal.toFixed(2)}</span>
            </div>
            
            {transaction.discountPercentage > 0 &&
            <div className="flex justify-between text-green-600">
                <span>Discount ({transaction.discountPercentage}%):</span>
                <span>-${transaction.discountAmount.toFixed(2)}</span>
              </div>
            }
            
            {transaction.taxPercentage > 0 &&
            <div className="flex justify-between">
                <span>Tax ({transaction.taxPercentage}%):</span>
                <span>${transaction.taxAmount.toFixed(2)}</span>
              </div>
            }
            
            <Separator />
            
            <div className="flex justify-between text-xl font-bold">
              <span>Total Amount:</span>
              <span className="text-green-600">${transaction.totalAmount.toFixed(2)}</span>
            </div>

            <div className="flex justify-between text-sm text-gray-600">
              <span>Payment Method:</span>
              <span className="capitalize">{transaction.paymentMethod}</span>
            </div>
          </div>

          <Separator />

          {/* Summary Information */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-800 mb-2">Transaction Summary</h4>
            <div className="grid grid-cols-2 gap-4 text-sm text-blue-700">
              <div>
                <strong>Total Items:</strong> {transaction.items.reduce((sum, item) => sum + item.quantity, 0)}
              </div>
              <div>
                <strong>Receipt Number:</strong> {transaction.receiptNumber}
              </div>
              <div>
                <strong>Transaction ID:</strong> {transaction.id}
              </div>
              <div>
                <strong>Date:</strong> {new Date(transaction.saleDate).toLocaleDateString()}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col md:flex-row gap-4 mt-8">
            <Button
              onClick={onBackToSales}
              variant="outline"
              className="flex items-center justify-center">

              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Sales
            </Button>
            
            <Button
              onClick={onPrintReceipt}
              className="flex items-center justify-center bg-blue-600 hover:bg-blue-700">

              <Printer className="h-4 w-4 mr-2" />
              Print Receipt
            </Button>
            
            <Button
              variant="outline"
              className="flex items-center justify-center"
              onClick={() => {
                // Download receipt as text file
                const receiptText = `
SALES RECEIPT
Receipt #${transaction.receiptNumber}
Date: ${formatDate(transaction.saleDate)}
Served by: ${transaction.employeeName}

ITEMS:
${transaction.items.map((item) =>
                `${item.product.name} (${item.product.sku})${item.size ? ` - Size: ${item.size}` : ''}${item.color ? ` - Color: ${item.color}` : ''}
  ${item.quantity} × $${item.product.selling_price.toFixed(2)} = $${item.subtotal.toFixed(2)}`
                ).join('\n')}

TOTALS:
Subtotal: $${transaction.subtotal.toFixed(2)}${transaction.discountPercentage > 0 ? `
Discount (${transaction.discountPercentage}%): -$${transaction.discountAmount.toFixed(2)}` : ''}${transaction.taxPercentage > 0 ? `
Tax (${transaction.taxPercentage}%): $${transaction.taxAmount.toFixed(2)}` : ''}
TOTAL: $${transaction.totalAmount.toFixed(2)}

Payment Method: ${transaction.paymentMethod}
Transaction ID: ${transaction.id}

Thank you for your business!
                `;

                const blob = new Blob([receiptText], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `receipt-${transaction.receiptNumber}.txt`;
                a.click();
                URL.revokeObjectURL(url);
              }}>

              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
            
            {onEmailReceipt &&
            <Button
              onClick={onEmailReceipt}
              variant="outline"
              className="flex items-center justify-center">

                <Mail className="h-4 w-4 mr-2" />
                Email Receipt
              </Button>
            }
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default SalesConfirmation;