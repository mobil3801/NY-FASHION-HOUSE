import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, ShoppingCart, Search, Calculator } from 'lucide-react';
import { toast } from 'sonner';
import { useSalesAuth } from '@/contexts/SalesAuthContext';

interface SalesItem {
  id: string;
  product_id: number;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string;
}

interface Product {
  id: number;
  name: string;
  price: number;
  stock: number;
  sku: string;
}

const SALES_TRANSACTIONS_TABLE_ID = 38156;
const CUSTOMERS_TABLE_ID = 38563;
const PRODUCTS_TABLE_ID = 38157;

const SalesEntryModule: React.FC = () => {
  const { salesUser } = useSalesAuth();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [salesItems, setSalesItems] = useState<SalesItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [loading, setLoading] = useState(true);

  // Load initial data
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);

      // Load customers
      const { data: customerData, error: customerError } = await window.ezsite.apis.tablePage(CUSTOMERS_TABLE_ID, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'name',
        IsAsc: true,
        Filters: []
      });

      if (customerError) throw new Error(customerError);

      const customerList: Customer[] = (customerData?.List || []).map((c: any) => ({
        id: c.id,
        name: c.name || 'Unknown Customer',
        email: c.email || '',
        phone: c.phone || ''
      }));

      setCustomers(customerList);

      // Load products
      const { data: productData, error: productError } = await window.ezsite.apis.tablePage(PRODUCTS_TABLE_ID, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'name',
        IsAsc: true,
        Filters: []
      });

      if (productError) throw new Error(productError);

      const productList: Product[] = (productData?.List || []).map((p: any) => ({
        id: p.id,
        name: p.name || 'Unknown Product',
        price: parseFloat(p.price) || 0,
        stock: parseInt(p.stock) || 0,
        sku: p.sku || ''
      }));

      setProducts(productList);

    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load customer and product data');
    } finally {
      setLoading(false);
    }
  };

  const addSalesItem = (product: Product) => {
    const existingItem = salesItems.find((item) => item.product_id === product.id);

    if (existingItem) {
      // Update quantity
      const updatedItems = salesItems.map((item) =>
      item.product_id === product.id ?
      { ...item, quantity: item.quantity + 1, total_price: (item.quantity + 1) * item.unit_price } :
      item
      );
      setSalesItems(updatedItems);
    } else {
      // Add new item
      const newItem: SalesItem = {
        id: Date.now().toString(),
        product_id: product.id,
        product_name: product.name,
        quantity: 1,
        unit_price: product.price,
        total_price: product.price
      };
      setSalesItems([...salesItems, newItem]);
    }
  };

  const updateItemQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeSalesItem(itemId);
      return;
    }

    const updatedItems = salesItems.map((item) =>
    item.id === itemId ?
    { ...item, quantity, total_price: quantity * item.unit_price } :
    item
    );
    setSalesItems(updatedItems);
  };

  const removeSalesItem = (itemId: string) => {
    setSalesItems(salesItems.filter((item) => item.id !== itemId));
  };

  const calculateTotal = () => {
    return salesItems.reduce((total, item) => total + item.total_price, 0);
  };

  const processSale = async () => {
    if (!selectedCustomer) {
      toast.error('Please select a customer');
      return;
    }

    if (salesItems.length === 0) {
      toast.error('Please add at least one item to the sale');
      return;
    }

    setIsProcessing(true);
    try {
      const saleData = {
        customer_id: selectedCustomer.id,
        customer_name: selectedCustomer.name,
        sales_person_id: salesUser?.ID || 0,
        sales_person_name: salesUser?.Name || '',
        total_amount: calculateTotal(),
        items: JSON.stringify(salesItems),
        transaction_date: new Date().toISOString(),
        status: 'COMPLETED'
      };

      const { error } = await window.ezsite.apis.tableCreate(SALES_TRANSACTIONS_TABLE_ID, saleData);

      if (error) throw new Error(error);

      toast.success('Sale processed successfully!');

      // Reset form
      setSalesItems([]);
      setSelectedCustomer(null);

    } catch (error) {
      console.error('Error processing sale:', error);
      toast.error('Failed to process sale. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const filteredProducts = products.filter((product) =>
  product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
  product.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Loading sales data...</p>
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Customer Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Customer Selection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Select value={selectedCustomer?.id.toString() || ''} onValueChange={(value) => {
              const customer = customers.find((c) => c.id.toString() === value);
              setSelectedCustomer(customer || null);
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Select a customer" />
              </SelectTrigger>
              <SelectContent>
                {customers.map((customer) =>
                <SelectItem key={customer.id} value={customer.id.toString()}>
                    {customer.name} - {customer.email}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
            
            {selectedCustomer &&
            <div className="p-3 bg-blue-50 rounded-lg">
                <p className="font-medium">{selectedCustomer.name}</p>
                <p className="text-sm text-gray-600">{selectedCustomer.email}</p>
                {selectedCustomer.phone &&
              <p className="text-sm text-gray-600">{selectedCustomer.phone}</p>
              }
              </div>
            }
          </div>
        </CardContent>
      </Card>

      {/* Product Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            Add Products
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Input
              placeholder="Search products by name or SKU..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)} />

            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-60 overflow-y-auto">
              {filteredProducts.map((product) =>
              <Card key={product.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex justify-between items-start">
                        <h4 className="font-medium text-sm">{product.name}</h4>
                        <Badge variant={product.stock > 0 ? 'secondary' : 'destructive'}>
                          {product.stock} in stock
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">SKU: {product.sku}</p>
                      <div className="flex justify-between items-center">
                        <span className="font-bold">${product.price.toFixed(2)}</span>
                        <Button
                        size="sm"
                        onClick={() => addSalesItem(product)}
                        disabled={product.stock <= 0}>

                          <Plus className="h-4 w-4 mr-1" />
                          Add
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sales Items */}
      {salesItems.length > 0 &&
      <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Sales Items
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {salesItems.map((item) =>
            <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium">{item.product_name}</h4>
                    <p className="text-sm text-gray-600">${item.unit_price.toFixed(2)} each</p>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Label htmlFor={`qty-${item.id}`} className="text-sm">Qty:</Label>
                      <Input
                    id={`qty-${item.id}`}
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateItemQuantity(item.id, parseInt(e.target.value) || 0)}
                    className="w-20"
                    min="1" />

                    </div>
                    
                    <div className="text-right">
                      <p className="font-bold">${item.total_price.toFixed(2)}</p>
                    </div>
                    
                    <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeSalesItem(item.id)}
                  className="text-red-600 hover:text-red-700">

                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
            )}
              
              <div className="border-t pt-4">
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total:</span>
                  <span>${calculateTotal().toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      }

      {/* Process Sale */}
      <div className="flex justify-end">
        <Button
          onClick={processSale}
          disabled={isProcessing || !selectedCustomer || salesItems.length === 0}
          size="lg">

          {isProcessing ? 'Processing...' : 'Process Sale'}
        </Button>
      </div>
    </div>);

};

export default SalesEntryModule;