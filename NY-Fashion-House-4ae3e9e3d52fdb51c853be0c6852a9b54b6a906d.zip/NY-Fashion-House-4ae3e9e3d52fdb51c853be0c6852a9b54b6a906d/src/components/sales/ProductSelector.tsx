
import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, RefreshCw, Package, DollarSign } from 'lucide-react';
import { formatUSD } from '@/utils/currencyUtils';
import { useToast } from '@/hooks/use-toast';
import { useDebounce } from '@/hooks/use-debounce';

interface Product {
  id: number;
  sku: string;
  name: string;
  description: string;
  category: string;
  cost_price: number;
  selling_price: number;
  stock_level: number;
  min_stock_level: number;
  supplier_id: string;
  barcode: string;
  sizes: string;
  colors: string;
  image_url: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  image_ids: string;
}

interface ProductSelectorProps {
  onProductSelect: (product: Product & {selectedSize?: string;quantity: number;}) => void;
  selectedProducts?: Array<Product & {selectedSize?: string;quantity: number;}>;
}

const ProductSelector: React.FC<ProductSelectorProps> = ({ onProductSelect, selectedProducts = [] }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(12);
  const [selectedSizes, setSelectedSizes] = useState<Record<number, string>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Debounce search term to avoid excessive API calls
  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  // Fetch products with search, pagination, and filtering
  const {
    data: productsData,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: ['products', debouncedSearchTerm, categoryFilter, currentPage, pageSize],
    queryFn: async () => {
      try {
        const filters = [];

        // Add active products filter
        filters.push({
          name: 'is_active',
          op: 'Equal',
          value: true
        });

        // Add search filter if search term exists
        if (debouncedSearchTerm.trim()) {
          filters.push({
            name: 'name',
            op: 'StringContains',
            value: debouncedSearchTerm.trim()
          });
        }

        // Add category filter if selected
        if (categoryFilter) {
          filters.push({
            name: 'category',
            op: 'Equal',
            value: categoryFilter
          });
        }

        const { data, error } = await window.ezsite.apis.tablePage(38157, {
          PageNo: currentPage,
          PageSize: pageSize,
          OrderByField: 'updated_at',
          IsAsc: false,
          Filters: filters
        });

        if (error) throw new Error(error);
        return data;
      } catch (err) {
        console.error('Error fetching products:', err);
        throw err;
      }
    },
    staleTime: 30000, // 30 seconds
    refetchOnWindowFocus: false
  });

  // Fetch categories for filter dropdown
  const { data: categoriesData } = useQuery({
    queryKey: ['product-categories'],
    queryFn: async () => {
      try {
        const { data, error } = await window.ezsite.apis.tablePage(38157, {
          PageNo: 1,
          PageSize: 1000,
          OrderByField: 'category',
          IsAsc: true,
          Filters: [
          {
            name: 'is_active',
            op: 'Equal',
            value: true
          }]

        });

        if (error) throw new Error(error);

        // Extract unique categories
        const categories = [...new Set(data.List.map((p: Product) => p.category).filter(Boolean))];
        return categories;
      } catch (err) {
        console.error('Error fetching categories:', err);
        return [];
      }
    },
    staleTime: 300000 // 5 minutes
  });

  // Get image URL from image_ids or image_url
  const getProductImage = async (product: Product): Promise<string> => {
    if (product.image_ids) {
      try {
        const imageIds = JSON.parse(product.image_ids);
        if (imageIds.length > 0) {
          const { data: imageUrl, error } = await window.ezsite.apis.getUploadUrl(imageIds[0]);
          if (!error && imageUrl) return imageUrl;
        }
      } catch (e) {
        console.warn('Error parsing image_ids:', e);
      }
    }
    return product.image_url || '/api/placeholder/150/150';
  };

  // Handle product selection with size
  const handleProductSelect = (product: Product) => {
    const sizes = product.sizes ? product.sizes.split(',').map((s) => s.trim()).filter(Boolean) : [];
    const selectedSize = selectedSizes[product.id] || (sizes.length > 0 ? sizes[0] : '');

    onProductSelect({
      ...product,
      selectedSize,
      quantity: 1
    });

    toast({
      title: "Product Added",
      description: `${product.name}${selectedSize ? ` (${selectedSize})` : ''} added to cart`
    });
  };

  // Handle size selection
  const handleSizeChange = (productId: number, size: string) => {
    setSelectedSizes((prev) => ({
      ...prev,
      [productId]: size
    }));
  };

  // Handle refresh
  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['products'] });
    queryClient.invalidateQueries({ queryKey: ['product-categories'] });
    refetch();
    toast({
      title: "Products Refreshed",
      description: "Product list has been updated"
    });
  };

  // Reset page when search/filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [debouncedSearchTerm, categoryFilter]);

  // Error handling
  if (error) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-red-500 mb-4">Error loading products: {error.message}</p>
          <Button onClick={handleRefresh} variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>);

  }

  const products = productsData?.List || [];
  const totalCount = productsData?.VirtualCount || 0;
  const totalPages = Math.ceil(totalCount / pageSize);
  const categories = categoriesData || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Product Search
          </div>
          <Button onClick={handleRefresh} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Search and Filter Controls */}
        <div className="space-y-4 mb-6">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10" />

            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Categories</SelectItem>
                {categories.map((category) =>
                <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          
          {/* Results count */}
          <div className="text-sm text-gray-600">
            {isLoading ? 'Loading...' : `${totalCount} products found`}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-6">
          {isLoading ?
          // Loading skeletons
          Array.from({ length: pageSize }).map((_, index) =>
          <Card key={index} className="overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-3 w-1/2 mb-2" />
                  <Skeleton className="h-6 w-20 mb-2" />
                  <Skeleton className="h-8 w-full" />
                </CardContent>
              </Card>
          ) :
          products.length === 0 ?
          <div className="col-span-full text-center py-8 text-gray-500">
              {debouncedSearchTerm || categoryFilter ? 'No products found matching your criteria.' : 'No products available.'}
            </div> :

          products.map((product) => {
            const sizes = product.sizes ? product.sizes.split(',').map((s) => s.trim()).filter(Boolean) : [];
            const selectedSize = selectedSizes[product.id] || (sizes.length > 0 ? sizes[0] : '');
            const isSelected = selectedProducts.some((p) =>
            p.id === product.id && p.selectedSize === selectedSize
            );

            return (
              <ProductCard
                key={`${product.id}-${selectedSize}`}
                product={product}
                sizes={sizes}
                selectedSize={selectedSize}
                isSelected={isSelected}
                onSizeChange={(size) => handleSizeChange(product.id, size)}
                onSelect={() => handleProductSelect(product)} />);


          })
          }
        </div>

        {/* Pagination */}
        {totalPages > 1 &&
        <div className="flex justify-center">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  className={currentPage <= 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'} />

                </PaginationItem>
                
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const page = currentPage <= 3 ? i + 1 :
                currentPage >= totalPages - 2 ? totalPages - 4 + i :
                currentPage - 2 + i;

                if (page < 1 || page > totalPages) return null;

                return (
                  <PaginationItem key={page}>
                      <PaginationLink
                      onClick={() => setCurrentPage(page)}
                      isActive={currentPage === page}
                      className="cursor-pointer">

                        {page}
                      </PaginationLink>
                    </PaginationItem>);

              })}
                
                <PaginationItem>
                  <PaginationNext
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  className={currentPage >= totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'} />

                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        }
      </CardContent>
    </Card>);

};

// Separate ProductCard component for better performance
interface ProductCardProps {
  product: Product;
  sizes: string[];
  selectedSize: string;
  isSelected: boolean;
  onSizeChange: (size: string) => void;
  onSelect: () => void;
}

const ProductCard: React.FC<ProductCardProps> = React.memo(({
  product,
  sizes,
  selectedSize,
  isSelected,
  onSizeChange,
  onSelect
}) => {
  const [imageUrl, setImageUrl] = useState<string>('/api/placeholder/150/150');

  useEffect(() => {
    const loadImage = async () => {
      if (product.image_ids) {
        try {
          const imageIds = JSON.parse(product.image_ids);
          if (imageIds.length > 0) {
            const { data: url, error } = await window.ezsite.apis.getUploadUrl(imageIds[0]);
            if (!error && url) {
              setImageUrl(url);
              return;
            }
          }
        } catch (e) {
          console.warn('Error parsing image_ids:', e);
        }
      }
      if (product.image_url) {
        setImageUrl(product.image_url);
      }
    };

    loadImage();
  }, [product.image_ids, product.image_url]);

  const isLowStock = product.stock_level <= product.min_stock_level;
  const isOutOfStock = product.stock_level <= 0;

  return (
    <Card className={`overflow-hidden transition-all hover:shadow-md ${isSelected ? 'ring-2 ring-blue-500' : ''}`}>
      <div className="aspect-square overflow-hidden bg-gray-100">
        <img
          src={imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform hover:scale-105"
          onError={(e) => {
            (e.target as HTMLImageElement).src = '/api/placeholder/150/150';
          }} />

      </div>
      
      <CardContent className="p-4">
        <div className="space-y-2">
          <div>
            <h3 className="font-medium text-sm truncate" title={product.name}>
              {product.name}
            </h3>
            <p className="text-xs text-gray-600 truncate" title={product.category}>
              {product.category}
            </p>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-green-600" />
              <span className="font-semibold text-green-600">
                {formatUSD(product.selling_price)}
              </span>
            </div>
            
            <div className="flex items-center gap-1">
              <Package className="w-3 h-3 text-gray-400" />
              <span className={`text-xs ${isOutOfStock ? 'text-red-500' : isLowStock ? 'text-orange-500' : 'text-gray-600'}`}>
                {product.stock_level}
              </span>
            </div>
          </div>

          {sizes.length > 0 &&
          <div>
              <Select value={selectedSize} onValueChange={onSizeChange}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue placeholder="Select size" />
                </SelectTrigger>
                <SelectContent>
                  {sizes.map((size) =>
                <SelectItem key={size} value={size} className="text-xs">
                      {size}
                    </SelectItem>
                )}
                </SelectContent>
              </Select>
            </div>
          }

          <div className="flex gap-2">
            {isLowStock &&
            <Badge variant="outline" className="text-xs text-orange-600 border-orange-200">
                Low Stock
              </Badge>
            }
            {isOutOfStock &&
            <Badge variant="destructive" className="text-xs">
                Out of Stock
              </Badge>
            }
          </div>

          <Button
            onClick={onSelect}
            disabled={isOutOfStock}
            size="sm"
            className="w-full h-8 text-xs"
            variant={isSelected ? "secondary" : "default"}>

            {isSelected ? 'Selected' : isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
          </Button>
        </div>
      </CardContent>
    </Card>);

});

ProductCard.displayName = 'ProductCard';

export default ProductSelector;