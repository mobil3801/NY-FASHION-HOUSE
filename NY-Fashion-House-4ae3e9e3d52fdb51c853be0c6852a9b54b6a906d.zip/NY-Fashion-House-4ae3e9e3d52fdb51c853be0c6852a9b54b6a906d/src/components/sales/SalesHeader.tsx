
import React, { useState } from 'react';
import { useSalesAuth } from '@/contexts/SalesAuthContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger } from
'@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ChevronDown, LogOut, User, ShoppingCart } from 'lucide-react';
import ImageWithFallback from '../ImageWithFallback';

const SalesHeader: React.FC = () => {
  const { salesUser, logout } = useSalesAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await logout();
    } finally {
      setIsLoggingOut(false);
    }
  };

  const getInitials = (name: string) => {
    return name.
    split(' ').
    map((word) => word[0]).
    join('').
    toUpperCase().
    slice(0, 2);
  };

  return (
    <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Title */}
          <div className="flex items-center space-x-3">
            <ImageWithFallback
              src="https://cdn.ezsite.ai/AutoDev/19016/95c2a8a3-4455-4cc1-91c1-442a3cf63926.jpeg"
              fallbackSrc="/logo-placeholder.svg"
              alt="NY FASHION HOUSE Logo"
              className="h-8 w-8 rounded-lg object-cover" />

            <div>
              <h1 className="text-lg font-bold text-gray-900">NY FASHION HOUSE - Sales Portal</h1>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <div className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-blue-50">
              <ShoppingCart className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">Sales Entry</span>
            </div>
          </nav>

          {/* User Menu */}
          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="flex items-center space-x-2 h-10 px-3 hover:bg-gray-100">

                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-blue-500 text-white text-sm">
                      {salesUser ? getInitials(salesUser.Name) : 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden sm:block text-left">
                    <p className="text-sm font-medium text-gray-900">
                      {salesUser?.Name || 'User'}
                    </p>
                    <p className="text-xs text-gray-500">Sales Team</p>
                  </div>
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium text-gray-900">{salesUser?.Name}</p>
                  <p className="text-xs text-gray-500">{salesUser?.Email}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="cursor-pointer text-red-600 focus:text-red-600 focus:bg-red-50"
                  onClick={handleLogout}
                  disabled={isLoggingOut}>

                  <LogOut className="mr-2 h-4 w-4" />
                  {isLoggingOut ? 'Signing Out...' : 'Sign Out'}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>);

};

export default SalesHeader;