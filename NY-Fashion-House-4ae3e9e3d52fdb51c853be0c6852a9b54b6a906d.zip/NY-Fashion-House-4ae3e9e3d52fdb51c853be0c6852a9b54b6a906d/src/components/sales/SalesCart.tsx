import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Trash2, ShoppingCart, Minus, Plus } from 'lucide-react';
import { toast } from 'sonner';

interface Product {
  id: number;
  sku: string;
  name: string;
  description: string;
  category: string;
  cost_price: number;
  selling_price: number;
  stock_level: number;
  min_stock_level: number;
  sizes: string;
  colors: string;
  image_url: string;
  is_active: boolean;
}

interface CartItem {
  product: Product;
  quantity: number;
  size?: string;
  color?: string;
  subtotal: number;
}

interface SalesCartProps {
  cartItems: CartItem[];
  onUpdateQuantity: (index: number, quantity: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
  discount: number;
  onDiscountChange: (discount: number) => void;
  tax: number;
  onTaxChange: (tax: number) => void;
}

const SalesCart: React.FC<SalesCartProps> = ({
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  discount,
  onDiscountChange,
  tax,
  onTaxChange
}) => {
  const calculateSubtotal = () => {
    return cartItems.reduce((sum, item) => sum + item.subtotal, 0);
  };

  const calculateDiscountAmount = () => {
    const subtotal = calculateSubtotal();
    return subtotal * discount / 100;
  };

  const calculateTaxAmount = () => {
    const subtotal = calculateSubtotal();
    const discountAmount = calculateDiscountAmount();
    return (subtotal - discountAmount) * tax / 100;
  };

  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const discountAmount = calculateDiscountAmount();
    const taxAmount = calculateTaxAmount();
    return subtotal - discountAmount + taxAmount;
  };

  const handleQuantityChange = (index: number, newQuantity: number) => {
    const item = cartItems[index];
    if (newQuantity > item.product.stock_level) {
      toast.error(`Cannot exceed stock limit of ${item.product.stock_level} items`);
      return;
    }
    if (newQuantity < 1) {
      toast.error('Quantity must be at least 1');
      return;
    }
    onUpdateQuantity(index, newQuantity);
  };

  const incrementQuantity = (index: number) => {
    const item = cartItems[index];
    handleQuantityChange(index, item.quantity + 1);
  };

  const decrementQuantity = (index: number) => {
    const item = cartItems[index];
    if (item.quantity > 1) {
      handleQuantityChange(index, item.quantity - 1);
    }
  };

  if (cartItems.length === 0) {
    return (
      <Card className="bg-gray-50">
        <CardContent className="flex flex-col items-center justify-center py-8">
          <ShoppingCart className="h-12 w-12 text-gray-300 mb-4" />
          <p className="text-gray-500 text-center">
            Your cart is empty.<br />
            Start by selecting products from the catalog.
          </p>
        </CardContent>
      </Card>);

  }

  return (
    <Card className="bg-white">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center">
          <ShoppingCart className="h-5 w-5 mr-2" />
          Shopping Cart ({cartItems.length} items)
        </CardTitle>
        <Button
          variant="outline"
          size="sm"
          onClick={onClearCart}
          className="text-red-600 hover:text-red-700">

          Clear All
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Cart Items */}
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {cartItems.map((item, index) =>
          <div key={`${item.product.id}-${item.size}-${item.color}-${index}`} className="border rounded-lg p-3">
              <div className="flex items-start space-x-3">
                {item.product.image_url &&
              <img
                src={item.product.image_url}
                alt={item.product.name}
                className="w-16 h-16 object-cover rounded-md" />

              }
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm truncate">{item.product.name}</h4>
                  <p className="text-xs text-gray-500">SKU: {item.product.sku}</p>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {item.size &&
                  <Badge variant="outline" className="text-xs">
                        Size: {item.size}
                      </Badge>
                  }
                    {item.color &&
                  <Badge variant="outline" className="text-xs">
                        Color: {item.color}
                      </Badge>
                  }
                  </div>
                  <div className="text-sm font-semibold text-green-600 mt-1">
                    ${item.product.selling_price.toFixed(2)} each
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-2">
                  <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onRemoveItem(index)}
                  className="text-red-600 hover:text-red-700 h-6 w-6 p-0">

                    <Trash2 className="h-3 w-3" />
                  </Button>
                  <div className="text-sm font-bold">
                    ${item.subtotal.toFixed(2)}
                  </div>
                </div>
              </div>
              
              {/* Quantity Controls */}
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center space-x-2">
                  <Button
                  variant="outline"
                  size="sm"
                  onClick={() => decrementQuantity(index)}
                  disabled={item.quantity <= 1}
                  className="h-8 w-8 p-0">

                    <Minus className="h-3 w-3" />
                  </Button>
                  <Input
                  type="number"
                  min="1"
                  max={item.product.stock_level}
                  value={item.quantity}
                  onChange={(e) => handleQuantityChange(index, parseInt(e.target.value) || 1)}
                  className="w-20 h-8 text-center" />

                  <Button
                  variant="outline"
                  size="sm"
                  onClick={() => incrementQuantity(index)}
                  disabled={item.quantity >= item.product.stock_level}
                  className="h-8 w-8 p-0">

                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
                <div className="text-xs text-gray-500">
                  Stock: {item.product.stock_level}
                </div>
              </div>
            </div>
          )}
        </div>

        <Separator />

        {/* Discount and Tax Controls */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Discount (%)</label>
            <Input
              type="number"
              min="0"
              max="100"
              step="0.1"
              value={discount}
              onChange={(e) => onDiscountChange(parseFloat(e.target.value) || 0)}
              placeholder="0" />

          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Tax (%)</label>
            <Input
              type="number"
              min="0"
              max="100"
              step="0.1"
              value={tax}
              onChange={(e) => onTaxChange(parseFloat(e.target.value) || 0)}
              placeholder="0" />

          </div>
        </div>

        <Separator />

        {/* Totals */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Subtotal:</span>
            <span>${calculateSubtotal().toFixed(2)}</span>
          </div>
          {discount > 0 &&
          <div className="flex justify-between text-sm text-green-600">
              <span>Discount ({discount}%):</span>
              <span>-${calculateDiscountAmount().toFixed(2)}</span>
            </div>
          }
          {tax > 0 &&
          <div className="flex justify-between text-sm">
              <span>Tax ({tax}%):</span>
              <span>${calculateTaxAmount().toFixed(2)}</span>
            </div>
          }
          <Separator />
          <div className="flex justify-between text-lg font-bold">
            <span>Total:</span>
            <span className="text-green-600">${calculateTotal().toFixed(2)}</span>
          </div>
        </div>

        {/* Total Items Summary */}
        <div className="text-xs text-gray-500 text-center">
          {cartItems.reduce((sum, item) => sum + item.quantity, 0)} items in cart
        </div>
      </CardContent>
    </Card>);

};

export default SalesCart;