import React, { useState, useEffect } from 'react';
import { Clock, User, AlertCircle, Activity, ChevronRight, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { formatDistanceToNow, format } from 'date-fns';
import { AuditLog } from '@/types/audit';
import { useIsMobile } from '@/hooks/use-mobile';

interface UserUpdateLog {
  id: number;
  user_name: string;
  user_email: string;
  action: string;
  table_name: string;
  record_id: string;
  timestamp: string;
  event_description: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  is_security_event: boolean;
  metadata?: string;
}

const UserUpdateLogsDropdown: React.FC = () => {
  const [logs, setLogs] = useState<UserUpdateLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const isMobile = useIsMobile();

  const fetchRecentLogs = async () => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: fetchError } = await window.ezsite.apis.tablePage(37723, {
        PageNo: 1,
        PageSize: 20,
        OrderByField: 'timestamp',
        IsAsc: false,
        Filters: [
        {
          name: 'action',
          op: 'StringContains' as const,
          value: ''
        }]

      });

      if (fetchError) throw fetchError;

      const transformedLogs: UserUpdateLog[] = data.List.map((log: any) => ({
        id: log.id,
        user_name: log.user_name || log.user_email || 'Unknown User',
        user_email: log.user_email || '',
        action: log.action || 'UNKNOWN',
        table_name: log.table_name || 'system',
        record_id: log.record_id || '',
        timestamp: log.timestamp,
        event_description: log.event_description || log.details || `${log.action} performed on ${log.table_name}`,
        severity: log.severity || 'LOW',
        is_security_event: log.is_security_event || false,
        metadata: log.metadata
      }));

      setLogs(transformedLogs);

      // Calculate unread count (logs from last hour)
      const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
      const recentLogs = transformedLogs.filter((log) =>
      new Date(log.timestamp) > hourAgo
      );
      setUnreadCount(recentLogs.length);
    } catch (err) {
      console.error('Failed to fetch audit logs:', err);
      setError('Failed to load recent updates');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecentLogs();

    // Refresh logs every 30 seconds
    const interval = setInterval(fetchRecentLogs, 30000);
    return () => clearInterval(interval);
  }, []);

  const getActionIcon = (action: string, isSecurityEvent: boolean) => {
    if (isSecurityEvent) return <AlertCircle className="h-3 w-3 text-red-500" />;

    switch (action.toUpperCase()) {
      case 'CREATE':
        return <Database className="h-3 w-3 text-green-500" />;
      case 'UPDATE':
        return <Activity className="h-3 w-3 text-blue-500" />;
      case 'DELETE':
        return <AlertCircle className="h-3 w-3 text-red-500" />;
      case 'LOGIN':
        return <User className="h-3 w-3 text-green-500" />;
      case 'LOGOUT':
        return <User className="h-3 w-3 text-gray-500" />;
      default:
        return <Clock className="h-3 w-3 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toUpperCase()) {
      case 'CRITICAL':
        return 'bg-red-500 text-white';
      case 'HIGH':
        return 'bg-orange-500 text-white';
      case 'MEDIUM':
        return 'bg-yellow-500 text-black';
      case 'LOW':
        return 'bg-green-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getTableDisplayName = (tableName: string) => {
    const tableMap: Record<string, string> = {
      'products': 'Products',
      'sales_transactions': 'Sales',
      'employees': 'Employees',
      'customers': 'Customers',
      'suppliers': 'Suppliers',
      'expenses': 'Expenses',
      'invoices': 'Invoices',
      'easysite_auth_users': 'Users',
      'system': 'System'
    };
    return tableMap[tableName] || tableName;
  };

  const formatTimeAgo = (timestamp: string) => {
    try {
      return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
    } catch {
      return 'Unknown time';
    }
  };

  const renderLogItem = (log: UserUpdateLog) =>
  <div key={log.id} className="flex items-start space-x-3 p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-md transition-colors">
      <div className="flex-shrink-0 mt-1">
        {getActionIcon(log.action, log.is_security_event)}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1">
          <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">
            {log.user_name}
          </p>
          <Badge variant="outline" className={`text-xs ${getSeverityColor(log.severity)}`}>
            {log.severity}
          </Badge>
        </div>
        <p className="text-xs text-gray-600 dark:text-gray-400 mb-1">
          {log.action.toLowerCase().replace(/_/g, ' ')} • {getTableDisplayName(log.table_name)}
        </p>
        <p className="text-xs text-gray-500 dark:text-gray-500 truncate">
          {log.event_description}
        </p>
        <p className="text-xs text-gray-400 dark:text-gray-600 mt-1">
          {formatTimeAgo(log.timestamp)}
        </p>
      </div>
    </div>;


  const renderMobileView = () =>
  <Card className="w-screen max-w-sm mx-4">
      <CardContent className="p-0">
        <div className="p-4 border-b">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Recent Updates</h3>
            <Button variant="ghost" size="sm" onClick={fetchRecentLogs} disabled={loading}>
              <Activity className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
          {unreadCount > 0 &&
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {unreadCount} new update{unreadCount !== 1 ? 's' : ''} in the last hour
            </p>
        }
        </div>
        <ScrollArea className="h-80">
          <div className="p-2">
            {loading && logs.length === 0 ?
          <div className="space-y-3">
                {[...Array(5)].map((_, i) =>
            <div key={i} className="flex space-x-3">
                    <Skeleton className="h-4 w-4 rounded-full" />
                    <div className="space-y-1 flex-1">
                      <Skeleton className="h-3 w-24" />
                      <Skeleton className="h-3 w-32" />
                      <Skeleton className="h-2 w-20" />
                    </div>
                  </div>
            )}
              </div> :
          error ?
          <div className="text-center py-8">
                <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                <p className="text-sm text-gray-600 dark:text-gray-400">{error}</p>
              </div> :
          logs.length === 0 ?
          <div className="text-center py-8">
                <Clock className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600 dark:text-gray-400">No recent updates</p>
              </div> :

          <div className="space-y-1">
                {logs.map(renderLogItem)}
              </div>
          }
          </div>
        </ScrollArea>
      </CardContent>
    </Card>;


  const renderDesktopView = () =>
  <div className="w-96 max-h-96 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg">
      <div className="p-3 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Recent Updates</h3>
          <Button variant="ghost" size="sm" onClick={fetchRecentLogs} disabled={loading}>
            <Activity className={`h-3 w-3 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
        {unreadCount > 0 &&
      <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
            {unreadCount} new update{unreadCount !== 1 ? 's' : ''} in the last hour
          </p>
      }
      </div>
      <ScrollArea className="h-80">
        <div className="p-2">
          {loading && logs.length === 0 ?
        <div className="space-y-2">
              {[...Array(5)].map((_, i) =>
          <div key={i} className="flex space-x-2">
                  <Skeleton className="h-3 w-3 rounded-full" />
                  <div className="space-y-1 flex-1">
                    <Skeleton className="h-3 w-20" />
                    <Skeleton className="h-2 w-28" />
                    <Skeleton className="h-2 w-16" />
                  </div>
                </div>
          )}
            </div> :
        error ?
        <div className="text-center py-6">
              <AlertCircle className="h-6 w-6 text-red-500 mx-auto mb-2" />
              <p className="text-xs text-gray-600 dark:text-gray-400">{error}</p>
            </div> :
        logs.length === 0 ?
        <div className="text-center py-6">
              <Clock className="h-6 w-6 text-gray-400 mx-auto mb-2" />
              <p className="text-xs text-gray-600 dark:text-gray-400">No recent updates</p>
            </div> :

        <div className="space-y-1">
              {logs.map(renderLogItem)}
            </div>
        }
        </div>
      </ScrollArea>
    </div>;


  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="relative p-2 transition-colors duration-300"
          style={{ color: 'var(--theme-text)' }}>

          <Activity className="h-4 w-4 sm:h-5 sm:w-5" />
          {unreadCount > 0 &&
          <span className="absolute -top-1 -right-1 h-2 w-2 sm:h-3 sm:w-3 bg-blue-500 rounded-full animate-pulse" />
          }
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className="p-0 w-auto"
        align="end"
        sideOffset={5}
        avoidCollisions
        collisionPadding={isMobile ? 16 : 8}>

        {isMobile ? renderMobileView() : renderDesktopView()}
      </PopoverContent>
    </Popover>);

};

export default UserUpdateLogsDropdown;