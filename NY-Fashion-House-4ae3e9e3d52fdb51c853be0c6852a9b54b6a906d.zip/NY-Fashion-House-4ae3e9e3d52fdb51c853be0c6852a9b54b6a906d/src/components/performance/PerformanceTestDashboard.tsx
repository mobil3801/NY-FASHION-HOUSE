
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity, Globe, Smartphone, Brain, Zap, BarChart3 } from 'lucide-react';
import PerformanceTestRunner from './PerformanceTestRunner';
import CrossBrowserTestManager from './CrossBrowserTestManager';
import ResponsivenessTestSuite from './ResponsivenessTestSuite';
import MemoryLeakDetector from './MemoryLeakDetector';
import LoadTestSimulator from './LoadTestSimulator';

const PerformanceTestDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Performance Testing Suite</h1>
        <p className="text-muted-foreground mt-2">
          Comprehensive automated testing for performance, compatibility, and responsiveness
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="cross-browser" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            Cross-Browser
          </TabsTrigger>
          <TabsTrigger value="responsive" className="flex items-center gap-2">
            <Smartphone className="h-4 w-4" />
            Responsive
          </TabsTrigger>
          <TabsTrigger value="memory" className="flex items-center gap-2">
            <Brain className="h-4 w-4" />
            Memory
          </TabsTrigger>
          <TabsTrigger value="load" className="flex items-center gap-2">
            <Zap className="h-4 w-4" />
            Load Testing
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Activity className="h-5 w-5 text-blue-500" />
                  Performance Testing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Measure page load times, API response times, and identify performance bottlenecks
                </p>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• Page load time measurement</li>
                  <li>• API response time testing</li>
                  <li>• Performance bottleneck detection</li>
                  <li>• Resource usage monitoring</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Globe className="h-5 w-5 text-green-500" />
                  Cross-Browser Testing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Ensure compatibility across Chrome, Firefox, Safari, and Edge browsers
                </p>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• Browser compatibility checks</li>
                  <li>• Performance comparison</li>
                  <li>• Feature support detection</li>
                  <li>• Rendering differences</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Smartphone className="h-5 w-5 text-purple-500" />
                  Responsive Design Testing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Validate UI components and layout across different screen sizes
                </p>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• Mobile, tablet, desktop testing</li>
                  <li>• Layout integrity validation</li>
                  <li>• UI component visibility</li>
                  <li>• Navigation usability</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Brain className="h-5 w-5 text-orange-500" />
                  Memory Leak Detection
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Monitor JavaScript heap memory and detect potential memory leaks
                </p>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• Real-time memory monitoring</li>
                  <li>• Memory leak detection</li>
                  <li>• Garbage collection tracking</li>
                  <li>• Memory usage analysis</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Zap className="h-5 w-5 text-red-500" />
                  Load Testing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Simulate high-load conditions to test system performance limits
                </p>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• Concurrent user simulation</li>
                  <li>• Stress testing capabilities</li>
                  <li>• Performance under load</li>
                  <li>• Bottleneck identification</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <BarChart3 className="h-5 w-5 text-indigo-500" />
                  Comprehensive Reporting
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-3">
                  Detailed analytics and insights from all performance tests
                </p>
                <ul className="text-xs space-y-1 text-muted-foreground">
                  <li>• Performance metrics tracking</li>
                  <li>• Visual test result displays</li>
                  <li>• Historical performance trends</li>
                  <li>• Actionable recommendations</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Getting Started</CardTitle>
              <CardDescription>
                Follow these steps to run comprehensive performance tests on your application
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-sm font-medium">1</div>
                  <div>
                    <h4 className="font-medium">Performance Testing</h4>
                    <p className="text-sm text-muted-foreground">Start with basic performance tests to measure page load times and API responses</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-sm font-medium">2</div>
                  <div>
                    <h4 className="font-medium">Cross-Browser Compatibility</h4>
                    <p className="text-sm text-muted-foreground">Test your application across different browsers to ensure consistent experience</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-sm font-medium">3</div>
                  <div>
                    <h4 className="font-medium">Responsive Design</h4>
                    <p className="text-sm text-muted-foreground">Validate your UI across different screen sizes and orientations</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center text-sm font-medium">4</div>
                  <div>
                    <h4 className="font-medium">Memory Analysis</h4>
                    <p className="text-sm text-muted-foreground">Monitor memory usage and detect potential leaks in your application</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-100 text-red-600 flex items-center justify-center text-sm font-medium">5</div>
                  <div>
                    <h4 className="font-medium">Load Testing</h4>
                    <p className="text-sm text-muted-foreground">Simulate high traffic to understand your system's performance limits</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance">
          <PerformanceTestRunner />
        </TabsContent>

        <TabsContent value="cross-browser">
          <CrossBrowserTestManager />
        </TabsContent>

        <TabsContent value="responsive">
          <ResponsivenessTestSuite />
        </TabsContent>

        <TabsContent value="memory">
          <MemoryLeakDetector />
        </TabsContent>

        <TabsContent value="load">
          <LoadTestSimulator />
        </TabsContent>
      </Tabs>
    </div>);

};

export default PerformanceTestDashboard;