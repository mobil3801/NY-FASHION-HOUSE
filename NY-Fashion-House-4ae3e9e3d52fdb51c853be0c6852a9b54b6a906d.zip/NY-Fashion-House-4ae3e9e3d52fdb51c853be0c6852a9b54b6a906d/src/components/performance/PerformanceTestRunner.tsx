
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Play, Square, RotateCcw, Activity, Monitor, Smartphone, Tablet } from 'lucide-react';
import { PerformanceTestService, PerformanceTestCase, PerformanceTestResult } from '@/services/performanceTestService';
import { toast } from 'sonner';

interface PerformanceTestRunnerProps {
  onResultsUpdate?: (results: PerformanceTestResult[]) => void;
}

const PerformanceTestRunner: React.FC<PerformanceTestRunnerProps> = ({ onResultsUpdate }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTest, setCurrentTest] = useState<string>('');
  const [testCases, setTestCases] = useState<PerformanceTestCase[]>([]);
  const [results, setResults] = useState<PerformanceTestResult[]>([]);
  const [executionId, setExecutionId] = useState<string>('');

  const loadTestCases = async () => {
    try {
      const cases = await PerformanceTestService.getTestCases();
      setTestCases(cases);
      toast.success(`Loaded ${cases.length} test cases`);
    } catch (error) {
      console.error('Failed to load test cases:', error);
      toast.error('Failed to load test cases');
    }
  };

  const runPerformanceTests = async () => {
    if (testCases.length === 0) {
      toast.error('No test cases available. Please create some test cases first.');
      return;
    }

    setIsRunning(true);
    setProgress(0);
    setResults([]);
    const newExecutionId = `exec_${Date.now()}`;
    setExecutionId(newExecutionId);

    const browserInfo = PerformanceTestService.getBrowserInfo();
    const deviceInfo = PerformanceTestService.getDeviceInfo();
    const allResults: PerformanceTestResult[] = [];

    try {
      for (let i = 0; i < testCases.length; i++) {
        const testCase = testCases[i];
        setCurrentTest(testCase.test_name);
        setProgress(i / testCases.length * 100);

        try {
          let loadTime = 0;
          let apiResponseTime = 0;
          let memoryUsage = PerformanceTestService.getMemoryUsage();
          let memoryLeaksDetected = false;
          let bottlenecks: string[] = [];

          // Run specific test based on type
          switch (testCase.test_type) {
            case 'page_load':
              loadTime = await PerformanceTestService.measurePageLoadTime(testCase.target_url);
              bottlenecks = PerformanceTestService.detectPerformanceBottlenecks();
              break;
            case 'api_response':
              apiResponseTime = await PerformanceTestService.measureApiResponseTime(testCase.target_url);
              break;
            case 'memory_leak':
              memoryLeaksDetected = await PerformanceTestService.detectMemoryLeaks();
              memoryUsage = PerformanceTestService.getMemoryUsage();
              break;
            case 'cross_browser':
              loadTime = await PerformanceTestService.measurePageLoadTime(testCase.target_url);
              apiResponseTime = await PerformanceTestService.measureApiResponseTime(testCase.target_url);
              break;
            case 'responsiveness':
              // Test responsiveness across different viewports
              loadTime = await PerformanceTestService.measurePageLoadTime(testCase.target_url);
              break;
          }

          const performanceScore = PerformanceTestService.calculatePerformanceScore(
            Math.max(loadTime, apiResponseTime),
            testCase.expected_threshold_ms,
            memoryUsage
          );

          const testStatus = performanceScore >= 70 ? 'Pass' : performanceScore >= 40 ? 'Fail' : 'Error';

          const result: PerformanceTestResult = {
            test_case_id: testCase.id,
            execution_id: newExecutionId,
            browser: `${browserInfo.name} ${browserInfo.version}`,
            device_type: deviceInfo.type,
            screen_resolution: `${deviceInfo.screenWidth}x${deviceInfo.screenHeight}`,
            load_time_ms: loadTime,
            api_response_time_ms: apiResponseTime,
            memory_usage_mb: memoryUsage,
            cpu_usage_percent: Math.random() * 20, // Simulated CPU usage
            test_status: testStatus,
            performance_score: performanceScore,
            bottlenecks_detected: JSON.stringify(bottlenecks),
            memory_leaks_detected: memoryLeaksDetected,
            executed_at: new Date().toISOString()
          };

          await PerformanceTestService.saveTestResult(result);
          allResults.push(result);
          setResults([...allResults]);

          toast.success(`Test completed: ${testCase.test_name} - ${testStatus}`);
        } catch (error) {
          console.error(`Test failed: ${testCase.test_name}`, error);
          toast.error(`Test failed: ${testCase.test_name}`);
        }

        // Small delay between tests
        await new Promise((resolve) => setTimeout(resolve, 500));
      }

      setProgress(100);
      toast.success('All performance tests completed');
      onResultsUpdate?.(allResults);
    } catch (error) {
      console.error('Performance test suite failed:', error);
      toast.error('Performance test suite failed');
    } finally {
      setIsRunning(false);
      setCurrentTest('');
    }
  };

  const stopTests = () => {
    setIsRunning(false);
    setCurrentTest('');
    setProgress(0);
    toast.info('Performance tests stopped');
  };

  React.useEffect(() => {
    loadTestCases();
  }, []);

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case 'Mobile':return <Smartphone className="h-4 w-4" />;
      case 'Tablet':return <Tablet className="h-4 w-4" />;
      default:return <Monitor className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Performance Test Runner
          </CardTitle>
          <CardDescription>
            Automated performance testing suite for load times, API responses, and system resources
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Button
                onClick={runPerformanceTests}
                disabled={isRunning || testCases.length === 0}
                className="flex items-center gap-2">

                <Play className="h-4 w-4" />
                Run Performance Tests
              </Button>
              {isRunning &&
              <Button
                onClick={stopTests}
                variant="destructive"
                className="flex items-center gap-2">

                  <Square className="h-4 w-4" />
                  Stop Tests
                </Button>
              }
              <Button
                onClick={loadTestCases}
                variant="outline"
                className="flex items-center gap-2">

                <RotateCcw className="h-4 w-4" />
                Reload Test Cases
              </Button>
            </div>
            <div className="flex items-center gap-2">
              {getDeviceIcon(PerformanceTestService.getDeviceInfo().type)}
              <span className="text-sm text-muted-foreground">
                {PerformanceTestService.getBrowserInfo().name}
              </span>
            </div>
          </div>

          {isRunning &&
          <div className="mb-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Running: {currentTest}</span>
                <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="w-full" />
            </div>
          }

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{testCases.length}</div>
              <div className="text-sm text-muted-foreground">Test Cases</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{results.length}</div>
              <div className="text-sm text-muted-foreground">Tests Run</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">
                {results.filter((r) => r.test_status === 'Pass').length}
              </div>
              <div className="text-sm text-muted-foreground">Passed</div>
            </div>
          </div>

          {results.length > 0 &&
          <div className="space-y-2">
              <h4 className="font-medium">Recent Test Results</h4>
              <div className="max-h-40 overflow-y-auto space-y-1">
                {results.slice(-5).map((result, index) =>
              <div key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                    <div className="flex items-center gap-2">
                      <Badge variant={
                  result.test_status === 'Pass' ? 'default' :
                  result.test_status === 'Fail' ? 'destructive' : 'secondary'
                  }>
                        {result.test_status}
                      </Badge>
                      <span className="text-sm">Test Case #{result.test_case_id}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span>Score: {result.performance_score}</span>
                      <span>{result.load_time_ms}ms</span>
                    </div>
                  </div>
              )}
              </div>
            </div>
          }
        </CardContent>
      </Card>
    </div>);

};

export default PerformanceTestRunner;