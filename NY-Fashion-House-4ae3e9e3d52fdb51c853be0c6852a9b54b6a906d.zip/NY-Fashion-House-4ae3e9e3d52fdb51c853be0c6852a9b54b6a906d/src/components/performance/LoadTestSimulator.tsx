
import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Zap, Play, Square, Users, Clock, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';

interface LoadTestConfig {
  concurrentUsers: number;
  requestsPerUser: number;
  testDuration: number; // seconds
  targetEndpoint: string;
  rampUpTime: number; // seconds
}

interface LoadTestMetrics {
  timestamp: number;
  activeUsers: number;
  requestsPerSecond: number;
  averageResponseTime: number;
  errorRate: number;
  successfulRequests: number;
  failedRequests: number;
}

interface LoadTestResult {
  config: LoadTestConfig;
  duration: number;
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  averageResponseTime: number;
  minResponseTime: number;
  maxResponseTime: number;
  requestsPerSecond: number;
  errorRate: number;
  metrics: LoadTestMetrics[];
  performanceGrade: 'A' | 'B' | 'C' | 'D' | 'F';
  bottlenecks: string[];
}

const LoadTestSimulator: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<LoadTestResult | null>(null);
  const [currentMetrics, setCurrentMetrics] = useState<LoadTestMetrics | null>(null);
  const [config, setConfig] = useState<LoadTestConfig>({
    concurrentUsers: 10,
    requestsPerUser: 5,
    testDuration: 30,
    targetEndpoint: window.location.origin + '/api/test',
    rampUpTime: 5
  });

  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const metricsRef = useRef<LoadTestMetrics[]>([]);
  const activeRequestsRef = useRef<Set<Promise<any>>>(new Set());

  const startLoadTest = async () => {
    setIsRunning(true);
    setProgress(0);
    setResult(null);
    metricsRef.current = [];
    activeRequestsRef.current.clear();

    const startTime = Date.now();
    let successfulRequests = 0;
    let failedRequests = 0;
    let responseTimeSum = 0;
    let minResponseTime = Infinity;
    let maxResponseTime = 0;

    try {
      toast.success('Load test started');

      // Start metrics collection
      const metricsInterval = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const progressPercent = Math.min(elapsed / config.testDuration * 100, 100);
        setProgress(progressPercent);

        const currentUsers = Math.min(
          Math.floor(elapsed / config.rampUpTime * config.concurrentUsers),
          config.concurrentUsers
        );

        const metrics: LoadTestMetrics = {
          timestamp: Date.now(),
          activeUsers: currentUsers,
          requestsPerSecond: (successfulRequests + failedRequests) / Math.max(elapsed, 1),
          averageResponseTime: successfulRequests > 0 ? responseTimeSum / successfulRequests : 0,
          errorRate: failedRequests / Math.max(successfulRequests + failedRequests, 1) * 100,
          successfulRequests,
          failedRequests
        };

        metricsRef.current.push(metrics);
        setCurrentMetrics(metrics);

        if (elapsed >= config.testDuration) {
          clearInterval(metricsInterval);
          completeLoadTest();
        }
      }, 1000);

      // Simulate concurrent users with ramp-up
      for (let user = 0; user < config.concurrentUsers; user++) {
        const userDelay = config.rampUpTime * 1000 * user / config.concurrentUsers;

        setTimeout(async () => {
          for (let req = 0; req < config.requestsPerUser; req++) {
            const requestPromise = simulateRequest();
            activeRequestsRef.current.add(requestPromise);

            try {
              const responseTime = await requestPromise;
              successfulRequests++;
              responseTimeSum += responseTime;
              minResponseTime = Math.min(minResponseTime, responseTime);
              maxResponseTime = Math.max(maxResponseTime, responseTime);
            } catch (error) {
              failedRequests++;
            } finally {
              activeRequestsRef.current.delete(requestPromise);
            }

            // Add delay between requests for the same user
            if (req < config.requestsPerUser - 1) {
              await new Promise((resolve) => setTimeout(resolve, Math.random() * 1000 + 500));
            }
          }
        }, userDelay);
      }

    } catch (error) {
      console.error('Load test failed:', error);
      toast.error('Load test failed');
      setIsRunning(false);
    }
  };

  const simulateRequest = async (): Promise<number> => {
    const startTime = performance.now();

    try {
      // Simulate API request with varying response times
      const baseResponseTime = 200;
      const variance = Math.random() * 300;
      const simulatedNetworkDelay = Math.random() * 100;
      const totalDelay = baseResponseTime + variance + simulatedNetworkDelay;

      await new Promise((resolve) => setTimeout(resolve, totalDelay));

      // Simulate occasional failures (5% failure rate)
      if (Math.random() < 0.05) {
        throw new Error('Simulated request failure');
      }

      return performance.now() - startTime;
    } catch (error) {
      throw error;
    }
  };

  const completeLoadTest = () => {
    const metrics = metricsRef.current;
    if (metrics.length === 0) return;

    const lastMetrics = metrics[metrics.length - 1];
    const totalRequests = lastMetrics.successfulRequests + lastMetrics.failedRequests;
    const duration = config.testDuration;

    const averageResponseTime = metrics.reduce((sum, m) => sum + m.averageResponseTime, 0) / metrics.length;
    const maxRPS = Math.max(...metrics.map((m) => m.requestsPerSecond));

    // Calculate performance grade
    let performanceGrade: 'A' | 'B' | 'C' | 'D' | 'F' = 'F';
    if (lastMetrics.errorRate < 1 && averageResponseTime < 200) performanceGrade = 'A';else
    if (lastMetrics.errorRate < 2 && averageResponseTime < 500) performanceGrade = 'B';else
    if (lastMetrics.errorRate < 5 && averageResponseTime < 1000) performanceGrade = 'C';else
    if (lastMetrics.errorRate < 10 && averageResponseTime < 2000) performanceGrade = 'D';

    // Identify bottlenecks
    const bottlenecks: string[] = [];
    if (averageResponseTime > 1000) bottlenecks.push('High response times detected');
    if (lastMetrics.errorRate > 5) bottlenecks.push('High error rate indicates server stress');
    if (maxRPS < config.concurrentUsers * 0.5) bottlenecks.push('Low throughput indicates capacity issues');

    const result: LoadTestResult = {
      config,
      duration,
      totalRequests,
      successfulRequests: lastMetrics.successfulRequests,
      failedRequests: lastMetrics.failedRequests,
      averageResponseTime,
      minResponseTime: 0, // Will be calculated from actual requests
      maxResponseTime: 0, // Will be calculated from actual requests
      requestsPerSecond: maxRPS,
      errorRate: lastMetrics.errorRate,
      metrics,
      performanceGrade,
      bottlenecks
    };

    setResult(result);
    setIsRunning(false);
    setProgress(100);
    toast.success(`Load test completed with grade: ${performanceGrade}`);
  };

  const stopLoadTest = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    // Cancel active requests
    activeRequestsRef.current.clear();

    setIsRunning(false);
    toast.info('Load test stopped');
  };

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A':return 'text-green-600 bg-green-50 border-green-200';
      case 'B':return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'C':return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'D':return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'F':return 'text-red-600 bg-red-50 border-red-200';
      default:return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Load Test Simulator
          </CardTitle>
          <CardDescription>
            Simulate high-load conditions to test system performance and identify bottlenecks
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="concurrentUsers">Concurrent Users</Label>
                <Input
                  id="concurrentUsers"
                  type="number"
                  min="1"
                  max="100"
                  value={config.concurrentUsers}
                  onChange={(e) => setConfig((prev) => ({ ...prev, concurrentUsers: parseInt(e.target.value) || 1 }))}
                  disabled={isRunning} />

              </div>
              <div>
                <Label htmlFor="requestsPerUser">Requests per User</Label>
                <Input
                  id="requestsPerUser"
                  type="number"
                  min="1"
                  max="20"
                  value={config.requestsPerUser}
                  onChange={(e) => setConfig((prev) => ({ ...prev, requestsPerUser: parseInt(e.target.value) || 1 }))}
                  disabled={isRunning} />

              </div>
              <div>
                <Label htmlFor="testDuration">Test Duration (seconds)</Label>
                <Input
                  id="testDuration"
                  type="number"
                  min="10"
                  max="300"
                  value={config.testDuration}
                  onChange={(e) => setConfig((prev) => ({ ...prev, testDuration: parseInt(e.target.value) || 10 }))}
                  disabled={isRunning} />

              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="rampUpTime">Ramp-up Time (seconds)</Label>
                <Input
                  id="rampUpTime"
                  type="number"
                  min="1"
                  max="60"
                  value={config.rampUpTime}
                  onChange={(e) => setConfig((prev) => ({ ...prev, rampUpTime: parseInt(e.target.value) || 1 }))}
                  disabled={isRunning} />

              </div>
              <div>
                <Label htmlFor="targetEndpoint">Target Endpoint</Label>
                <Input
                  id="targetEndpoint"
                  value={config.targetEndpoint}
                  onChange={(e) => setConfig((prev) => ({ ...prev, targetEndpoint: e.target.value }))}
                  disabled={isRunning} />

              </div>
              <div className="pt-4">
                <div className="text-sm text-muted-foreground">
                  <p>Total Requests: {config.concurrentUsers * config.requestsPerUser}</p>
                  <p>Expected Peak RPS: ~{Math.round(config.concurrentUsers / 2)}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 mb-6">
            <Button
              onClick={startLoadTest}
              disabled={isRunning}
              className="flex items-center gap-2">

              <Play className="h-4 w-4" />
              Start Load Test
            </Button>
            {isRunning &&
            <Button
              onClick={stopLoadTest}
              variant="destructive"
              className="flex items-center gap-2">

                <Square className="h-4 w-4" />
                Stop Test
              </Button>
            }
          </div>

          {isRunning &&
          <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Test Progress</span>
                <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="w-full" />
              
              {currentMetrics &&
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-muted/50 rounded">
                    <div className="text-lg font-bold flex items-center justify-center gap-1">
                      <Users className="h-4 w-4" />
                      {currentMetrics.activeUsers}
                    </div>
                    <div className="text-sm text-muted-foreground">Active Users</div>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded">
                    <div className="text-lg font-bold">{currentMetrics.requestsPerSecond.toFixed(1)}</div>
                    <div className="text-sm text-muted-foreground">RPS</div>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded">
                    <div className="text-lg font-bold flex items-center justify-center gap-1">
                      <Clock className="h-4 w-4" />
                      {currentMetrics.averageResponseTime.toFixed(0)}ms
                    </div>
                    <div className="text-sm text-muted-foreground">Avg Response</div>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded">
                    <div className="text-lg font-bold">{currentMetrics.errorRate.toFixed(1)}%</div>
                    <div className="text-sm text-muted-foreground">Error Rate</div>
                  </div>
                </div>
            }
            </div>
          }

          {result &&
          <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div className="text-center">
                  <div className={`text-3xl font-bold p-4 rounded-lg border ${getGradeColor(result.performanceGrade)}`}>
                    {result.performanceGrade}
                  </div>
                  <div className="text-sm text-muted-foreground mt-2">Performance Grade</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{result.totalRequests}</div>
                  <div className="text-sm text-muted-foreground">Total Requests</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{result.requestsPerSecond.toFixed(1)}</div>
                  <div className="text-sm text-muted-foreground">Peak RPS</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{result.averageResponseTime.toFixed(0)}ms</div>
                  <div className="text-sm text-muted-foreground">Avg Response</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{result.errorRate.toFixed(1)}%</div>
                  <div className="text-sm text-muted-foreground">Error Rate</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3 flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    Response Time Trend
                  </h4>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={result.metrics.map((metric, index) => ({
                      time: index,
                      responseTime: metric.averageResponseTime
                    }))}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip formatter={(value: number) => [`${value.toFixed(0)}ms`, 'Response Time']} />
                        <Line type="monotone" dataKey="responseTime" stroke="#8884d8" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Requests per Second</h4>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={result.metrics.map((metric, index) => ({
                      time: index,
                      rps: metric.requestsPerSecond
                    }))}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <Tooltip formatter={(value: number) => [`${value.toFixed(1)}`, 'RPS']} />
                        <Bar dataKey="rps" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {result.bottlenecks.length > 0 &&
            <div className="space-y-2">
                  <h4 className="font-medium">Performance Bottlenecks</h4>
                  <div className="space-y-2">
                    {result.bottlenecks.map((bottleneck, index) =>
                <div key={index} className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded">
                        <Zap className="h-4 w-4 text-yellow-600" />
                        <span className="text-sm text-yellow-800">{bottleneck}</span>
                      </div>
                )}
                  </div>
                </div>
            }
            </div>
          }
        </CardContent>
      </Card>
    </div>);

};

export default LoadTestSimulator;