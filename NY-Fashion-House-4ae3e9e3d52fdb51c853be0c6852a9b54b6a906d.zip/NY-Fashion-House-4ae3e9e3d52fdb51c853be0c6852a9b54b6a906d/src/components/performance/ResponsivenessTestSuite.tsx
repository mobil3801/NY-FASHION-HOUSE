
import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Smartphone, Tablet, Monitor, RotateCcw, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface ViewportTest {
  name: string;
  width: number;
  height: number;
  device: 'Mobile' | 'Tablet' | 'Desktop';
  icon: React.ReactNode;
}

interface ResponsivenessResult {
  viewport: ViewportTest;
  status: 'pass' | 'fail' | 'warning';
  issues: string[];
  layoutIntegrity: number;
  uiElementsVisible: boolean;
  navigationUsable: boolean;
  textReadable: boolean;
  performanceScore: number;
}

const ResponsivenessTestSuite: React.FC = () => {
  const [results, setResults] = useState<ResponsivenessResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [currentViewport, setCurrentViewport] = useState<string>('');
  const testFrameRef = useRef<HTMLIFrameElement>(null);

  const viewportTests: ViewportTest[] = [
  { name: 'iPhone SE', width: 375, height: 667, device: 'Mobile', icon: <Smartphone className="h-4 w-4" /> },
  { name: 'iPhone 12', width: 390, height: 844, device: 'Mobile', icon: <Smartphone className="h-4 w-4" /> },
  { name: 'Samsung Galaxy', width: 360, height: 740, device: 'Mobile', icon: <Smartphone className="h-4 w-4" /> },
  { name: 'iPad', width: 768, height: 1024, device: 'Tablet', icon: <Tablet className="h-4 w-4" /> },
  { name: 'iPad Pro', width: 1024, height: 1366, device: 'Tablet', icon: <Tablet className="h-4 w-4" /> },
  { name: 'Desktop HD', width: 1366, height: 768, device: 'Desktop', icon: <Monitor className="h-4 w-4" /> },
  { name: 'Desktop FHD', width: 1920, height: 1080, device: 'Desktop', icon: <Monitor className="h-4 w-4" /> },
  { name: 'Desktop 4K', width: 2560, height: 1440, device: 'Desktop', icon: <Monitor className="h-4 w-4" /> }];


  const runResponsivenessTests = async () => {
    setIsRunning(true);
    setResults([]);
    const testResults: ResponsivenessResult[] = [];

    try {
      for (const viewport of viewportTests) {
        setCurrentViewport(viewport.name);

        try {
          const result = await testViewport(viewport);
          testResults.push(result);
          setResults([...testResults]);

          toast.success(`${viewport.name} responsiveness test completed`);
          await new Promise((resolve) => setTimeout(resolve, 800));
        } catch (error) {
          console.error(`Responsiveness test failed for ${viewport.name}:`, error);
          toast.error(`Responsiveness test failed for ${viewport.name}`);
        }
      }

      toast.success('Responsiveness tests completed');
    } catch (error) {
      console.error('Responsiveness testing failed:', error);
      toast.error('Responsiveness testing failed');
    } finally {
      setIsRunning(false);
      setCurrentViewport('');
    }
  };

  const testViewport = async (viewport: ViewportTest): Promise<ResponsivenessResult> => {
    const issues: string[] = [];
    let layoutIntegrity = 100;
    let uiElementsVisible = true;
    let navigationUsable = true;
    let textReadable = true;

    // Simulate viewport testing
    await simulateViewportChange(viewport.width, viewport.height);

    // Check for common responsiveness issues
    if (viewport.device === 'Mobile') {
      // Mobile-specific checks
      if (viewport.width < 400) {
        issues.push('Text might be too small on narrow screens');
        textReadable = false;
        layoutIntegrity -= 15;
      }
      if (viewport.width < 350) {
        issues.push('Navigation menu may not be accessible');
        navigationUsable = false;
        layoutIntegrity -= 20;
      }
    }

    if (viewport.device === 'Tablet') {
      // Tablet-specific checks
      if (viewport.width < 800) {
        issues.push('Side navigation might collapse unexpectedly');
        layoutIntegrity -= 10;
      }
    }

    if (viewport.device === 'Desktop') {
      // Desktop-specific checks
      if (viewport.width > 2000) {
        issues.push('Content might appear stretched on ultra-wide screens');
        layoutIntegrity -= 5;
      }
    }

    // Simulate element visibility checks
    const elementsTest = await checkElementVisibility(viewport);
    if (!elementsTest.passed) {
      issues.push(...elementsTest.issues);
      uiElementsVisible = false;
      layoutIntegrity -= 25;
    }

    // Calculate performance score based on viewport
    const performanceScore = calculateResponsivenessScore(viewport, issues.length, layoutIntegrity);

    // Determine overall status
    const status = layoutIntegrity >= 80 && uiElementsVisible && navigationUsable ? 'pass' :
    layoutIntegrity >= 60 ? 'warning' : 'fail';

    return {
      viewport,
      status,
      issues,
      layoutIntegrity,
      uiElementsVisible,
      navigationUsable,
      textReadable,
      performanceScore
    };
  };

  const simulateViewportChange = async (width: number, height: number): Promise<void> => {
    // Simulate changing viewport size
    return new Promise((resolve) => setTimeout(resolve, 300));
  };

  const checkElementVisibility = async (viewport: ViewportTest): Promise<{passed: boolean;issues: string[];}> => {
    const issues: string[] = [];

    // Simulate element visibility checks
    if (viewport.width < 480) {
      issues.push('Some buttons may be too small to tap');
    }
    if (viewport.width < 320) {
      issues.push('Critical UI elements may be hidden');
    }

    return {
      passed: issues.length === 0,
      issues
    };
  };

  const calculateResponsivenessScore = (viewport: ViewportTest, issueCount: number, layoutIntegrity: number): number => {
    let score = layoutIntegrity;

    // Bonus for common device sizes
    const commonSizes = [375, 390, 768, 1366, 1920];
    if (commonSizes.includes(viewport.width)) {
      score += 5;
    }

    // Penalty for issues
    score -= issueCount * 10;

    return Math.max(0, Math.min(100, Math.round(score)));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail':return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default:return <AlertTriangle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getDeviceColor = (device: string) => {
    switch (device) {
      case 'Mobile':return 'text-blue-500';
      case 'Tablet':return 'text-purple-500';
      case 'Desktop':return 'text-green-500';
      default:return 'text-gray-500';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <RotateCcw className="h-5 w-5" />
          Responsiveness Testing Suite
        </CardTitle>
        <CardDescription>
          Test UI components and layout integrity across different screen sizes and orientations
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-6">
          <Button
            onClick={runResponsivenessTests}
            disabled={isRunning}
            className="flex items-center gap-2">

            <RotateCcw className="h-4 w-4" />
            {isRunning ? 'Running Tests...' : 'Run Responsiveness Tests'}
          </Button>
          {isRunning &&
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <RotateCcw className="h-4 w-4 animate-spin" />
              Testing {currentViewport}...
            </div>
          }
        </div>

        {results.length > 0 &&
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-500">
                  {results.filter((r) => r.status === 'pass').length}
                </div>
                <div className="text-sm text-muted-foreground">Passed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-500">
                  {results.filter((r) => r.status === 'warning').length}
                </div>
                <div className="text-sm text-muted-foreground">Warnings</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-500">
                  {results.filter((r) => r.status === 'fail').length}
                </div>
                <div className="text-sm text-muted-foreground">Failed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">
                  {Math.round(results.reduce((acc, r) => acc + r.performanceScore, 0) / results.length) || 0}
                </div>
                <div className="text-sm text-muted-foreground">Avg Score</div>
              </div>
            </div>

            <div className="border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Viewport</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Layout</TableHead>
                    <TableHead>Navigation</TableHead>
                    <TableHead>Text</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Issues</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {results.map((result, index) =>
                <TableRow key={index}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className={getDeviceColor(result.viewport.device)}>
                            {result.viewport.icon}
                          </span>
                          <div>
                            <div className="font-medium">{result.viewport.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {result.viewport.width} × {result.viewport.height}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getStatusIcon(result.status)}
                          <Badge variant={
                      result.status === 'pass' ? 'default' :
                      result.status === 'warning' ? 'secondary' : 'destructive'
                      }>
                            {result.status}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {result.layoutIntegrity >= 80 ?
                      <CheckCircle className="h-3 w-3 text-green-500" /> :
                      <XCircle className="h-3 w-3 text-red-500" />
                      }
                          <span className="text-sm">{result.layoutIntegrity}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {result.navigationUsable ?
                    <CheckCircle className="h-4 w-4 text-green-500" /> :
                    <XCircle className="h-4 w-4 text-red-500" />
                    }
                      </TableCell>
                      <TableCell>
                        {result.textReadable ?
                    <CheckCircle className="h-4 w-4 text-green-500" /> :
                    <XCircle className="h-4 w-4 text-red-500" />
                    }
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <span className="font-medium">{result.performanceScore}</span>
                          <span className="text-muted-foreground">/100</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {result.issues.length > 0 ?
                    <div className="space-y-1">
                            {result.issues.slice(0, 2).map((issue, i) =>
                      <Badge key={i} variant="outline" className="text-xs block">
                                {issue}
                              </Badge>
                      )}
                            {result.issues.length > 2 &&
                      <span className="text-xs text-muted-foreground">
                                +{result.issues.length - 2} more
                              </span>
                      }
                          </div> :

                    <span className="text-muted-foreground text-sm">No issues</span>
                    }
                      </TableCell>
                    </TableRow>
                )}
                </TableBody>
              </Table>
            </div>
          </div>
        }
      </CardContent>
    </Card>);

};

export default ResponsivenessTestSuite;