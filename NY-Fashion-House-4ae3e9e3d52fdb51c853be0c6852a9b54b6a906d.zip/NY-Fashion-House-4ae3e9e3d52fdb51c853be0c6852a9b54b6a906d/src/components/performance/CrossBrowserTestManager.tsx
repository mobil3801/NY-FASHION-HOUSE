
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Globe, Chrome, Globe2, Compass, Monitor, CheckCircle, XCircle, Clock, Bug, Shield, AlertTriangle } from 'lucide-react';
import { PerformanceTestService, PerformanceTestResult } from '@/services/performanceTestService';
import { crossBrowserErrorTestService, CrossBrowserErrorReport } from '@/services/crossBrowserErrorTestService';
import { toast } from 'sonner';

interface BrowserCompatibilityResult {
  browser: string;
  version: string;
  status: 'pass' | 'fail' | 'warning';
  loadTime: number;
  apiResponseTime: number;
  compatibilityScore: number;
  issues: string[];
}

const CrossBrowserTestManager: React.FC = () => {
  const [results, setResults] = useState<BrowserCompatibilityResult[]>([]);
  const [errorTestReport, setErrorTestReport] = useState<CrossBrowserErrorReport | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [currentBrowser, setCurrentBrowser] = useState<string>('');
  const [activeTab, setActiveTab] = useState('compatibility');

  const browserTargets = [
  { name: 'Chrome', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' },
  { name: 'Firefox', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0' },
  { name: 'Safari', userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15' },
  { name: 'Edge', userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59' }];


  const runCompatibilityTests = async () => {
    setIsRunning(true);
    setResults([]);
    const testResults: BrowserCompatibilityResult[] = [];

    try {
      for (const browser of browserTargets) {
        setCurrentBrowser(browser.name);

        try {
          // Simulate cross-browser testing
          const loadTime = await simulateBrowserTest(browser.name, 'page_load');
          const apiResponseTime = await simulateBrowserTest(browser.name, 'api_response');
          const compatibilityIssues = await checkBrowserCompatibility(browser.name);

          const compatibilityScore = calculateCompatibilityScore(loadTime, apiResponseTime, compatibilityIssues);
          const status = compatibilityScore >= 80 ? 'pass' : compatibilityScore >= 60 ? 'warning' : 'fail';

          const result: BrowserCompatibilityResult = {
            browser: browser.name,
            version: getBrowserVersion(browser.name),
            status,
            loadTime,
            apiResponseTime,
            compatibilityScore,
            issues: compatibilityIssues
          };

          testResults.push(result);
          setResults([...testResults]);

          toast.success(`${browser.name} compatibility test completed`);
          await new Promise((resolve) => setTimeout(resolve, 1000));
        } catch (error) {
          console.error(`Cross-browser test failed for ${browser.name}:`, error);
          toast.error(`Cross-browser test failed for ${browser.name}`);
        }
      }

      toast.success('Cross-browser compatibility tests completed');
    } catch (error) {
      console.error('Cross-browser testing failed:', error);
      toast.error('Cross-browser testing failed');
    } finally {
      setIsRunning(false);
      setCurrentBrowser('');
    }
  };

  const runErrorScenarioTests = async () => {
    setIsRunning(true);
    setCurrentBrowser('Initializing error tests...');

    try {
      toast.info('Starting cross-browser error scenario tests...');

      const report = await crossBrowserErrorTestService.runCrossBrowserErrorTests();
      setErrorTestReport(report);

      toast.success(`Error scenario tests completed: ${report.summary.passed}/${report.summary.totalTests} tests passed`);

    } catch (error) {
      console.error('Error scenario testing failed:', error);
      toast.error('Error scenario testing failed');
    } finally {
      setIsRunning(false);
      setCurrentBrowser('');
    }
  };

  const runAllTests = async () => {
    setIsRunning(true);

    try {
      toast.info('Running comprehensive cross-browser tests...');

      // Run compatibility tests
      await runCompatibilityTests();

      // Run error scenario tests  
      await runErrorScenarioTests();

      toast.success('All cross-browser tests completed successfully');
    } catch (error) {
      console.error('Cross-browser testing failed:', error);
      toast.error('Cross-browser testing failed');
    } finally {
      setIsRunning(false);
      setCurrentBrowser('');
    }
  };

  const simulateBrowserTest = async (browserName: string, testType: string): Promise<number> => {
    // Simulate different performance characteristics for different browsers
    const baseTime = testType === 'page_load' ? 1200 : 300;
    const browserMultiplier = {
      'Chrome': 1.0,
      'Firefox': 1.1,
      'Safari': 1.2,
      'Edge': 1.05
    }[browserName] || 1.0;

    const variance = Math.random() * 200 - 100; // ±100ms variance
    return Math.max(100, Math.round(baseTime * browserMultiplier + variance));
  };

  const checkBrowserCompatibility = async (browserName: string): Promise<string[]> => {
    const issues: string[] = [];

    // Simulate compatibility checks
    const compatibilityProblems = {
      'Chrome': [],
      'Firefox': ['CSS Grid layout differences', 'WebGL performance'],
      'Safari': ['Flexbox bugs', 'Date input styling', 'Audio autoplay restrictions'],
      'Edge': ['Legacy Edge compatibility']
    };

    return compatibilityProblems[browserName as keyof typeof compatibilityProblems] || [];
  };

  const calculateCompatibilityScore = (loadTime: number, apiTime: number, issues: string[]): number => {
    let score = 100;

    // Penalize slow performance
    if (loadTime > 2000) score -= 20;
    if (apiTime > 500) score -= 15;

    // Penalize compatibility issues
    score -= issues.length * 10;

    return Math.max(0, score);
  };

  const getBrowserVersion = (browserName: string): string => {
    const versions = {
      'Chrome': '91.0.4472.124',
      'Firefox': '89.0',
      'Safari': '14.1.1',
      'Edge': '91.0.864.59'
    };

    return versions[browserName as keyof typeof versions] || 'Unknown';
  };

  const getBrowserIcon = (browserName: string) => {
    switch (browserName) {
      case 'Chrome':return <Chrome className="h-4 w-4 text-blue-500" />;
      case 'Firefox':return <Globe2 className="h-4 w-4 text-orange-500" />;
      case 'Safari':return <Compass className="h-4 w-4 text-blue-600" />;
      case 'Edge':return <Monitor className="h-4 w-4 text-blue-400" />;
      default:return <Globe className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail':return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':return <Clock className="h-4 w-4 text-yellow-500" />;
      default:return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const renderCompatibilityTab = () =>
  <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-x-2">
          <Button
          onClick={runCompatibilityTests}
          disabled={isRunning}
          className="flex items-center gap-2">

            <Globe className="h-4 w-4" />
            {isRunning ? 'Running Tests...' : 'Run Compatibility Tests'}
          </Button>
          <Button
          onClick={runErrorScenarioTests}
          disabled={isRunning}
          variant="outline"
          className="flex items-center gap-2">

            <Bug className="h-4 w-4" />
            Run Error Tests
          </Button>
          <Button
          onClick={runAllTests}
          disabled={isRunning}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700">

            <Shield className="h-4 w-4" />
            Run All Tests
          </Button>
        </div>
        {isRunning &&
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4 animate-spin" />
            {currentBrowser}
          </div>
      }
      </div>

      {results.length > 0 &&
    <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {['pass', 'warning', 'fail'].map((status) =>
        <div key={status} className="text-center">
                <div className="text-2xl font-bold">
                  {results.filter((r) => r.status === status).length}
                </div>
                <div className="text-sm text-muted-foreground capitalize">
                  {status === 'pass' ? 'Passed' : status === 'warning' ? 'Warnings' : 'Failed'}
                </div>
              </div>
        )}
            <div className="text-center">
              <div className="text-2xl font-bold">
                {Math.round(results.reduce((acc, r) => acc + r.compatibilityScore, 0) / results.length) || 0}
              </div>
              <div className="text-sm text-muted-foreground">Avg Score</div>
            </div>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Browser</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Load Time</TableHead>
                  <TableHead>API Response</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Issues</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result, index) =>
            <TableRow key={index}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getBrowserIcon(result.browser)}
                        <div>
                          <div className="font-medium">{result.browser}</div>
                          <div className="text-xs text-muted-foreground">{result.version}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(result.status)}
                        <Badge variant={
                  result.status === 'pass' ? 'default' :
                  result.status === 'warning' ? 'secondary' : 'destructive'
                  }>
                          {result.status}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>{result.loadTime}ms</TableCell>
                    <TableCell>{result.apiResponseTime}ms</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-medium">{result.compatibilityScore}</span>
                        <span className="text-muted-foreground">/100</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {result.issues.length > 0 ?
                <div className="space-y-1">
                          {result.issues.map((issue, i) =>
                  <Badge key={i} variant="outline" className="text-xs">
                              {issue}
                            </Badge>
                  )}
                        </div> :

                <span className="text-muted-foreground text-sm">No issues</span>
                }
                    </TableCell>
                  </TableRow>
            )}
              </TableBody>
            </Table>
          </div>
        </div>
    }
    </div>;


  const renderErrorTestingTab = () =>
  <div className="space-y-6">
      {errorTestReport ?
    <>
          {/* Error Test Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-8 w-8 text-green-500" />
                  <div>
                    <div className="text-2xl font-bold">{errorTestReport.summary.passed}</div>
                    <div className="text-sm text-gray-600">Tests Passed</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <XCircle className="h-8 w-8 text-red-500" />
                  <div>
                    <div className="text-2xl font-bold">{errorTestReport.summary.errors}</div>
                    <div className="text-sm text-gray-600">Critical Errors</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <Globe className="h-8 w-8 text-blue-500" />
                  <div>
                    <div className="text-2xl font-bold">{Math.round(errorTestReport.summary.errorRecoveryScore)}%</div>
                    <div className="text-sm text-gray-600">Recovery Score</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-2">
                  <Shield className="h-8 w-8 text-orange-500" />
                  <div>
                    <div className="text-2xl font-bold">{Math.round(errorTestReport.errorTrackingValidation.trackingAccuracy)}%</div>
                    <div className="text-sm text-gray-600">Tracking Accuracy</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Browser Error Compatibility */}
          <Card>
            <CardHeader>
              <CardTitle>Browser Error Handling Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(errorTestReport.summary.browserCompatibility).map(([browser, score]) =>
            <div key={browser} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {getBrowserIcon(browser)}
                        <span className="font-medium">{browser}</span>
                      </div>
                      <Badge variant={score >= 80 ? 'default' : score >= 60 ? 'secondary' : 'destructive'}>
                        {Math.round(score)}% error handling
                      </Badge>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                  className={`h-2 rounded-full ${
                  score >= 80 ? 'bg-green-500' : score >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`
                  }
                  style={{ width: `${score}%` }}>
                </div>
                    </div>
                  </div>
            )}
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          {errorTestReport.recommendations.length > 0 &&
      <Card>
              <CardHeader>
                <CardTitle>Error Handling Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {errorTestReport.recommendations.map((rec, index) =>
            <Alert key={index} className={
            rec.priority === 'critical' ? 'border-red-200 bg-red-50' :
            rec.priority === 'high' ? 'border-orange-200 bg-orange-50' :
            'border-yellow-200 bg-yellow-50'
            }>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <strong>{rec.browser}</strong>
                            <Badge variant="outline" className={
                    rec.priority === 'critical' ? 'text-red-600' :
                    rec.priority === 'high' ? 'text-orange-600' :
                    'text-yellow-600'
                    }>
                              {rec.priority}
                            </Badge>
                          </div>
                          {rec.suggestions.slice(0, 2).map((suggestion, i) =>
                  <div key={i} className="text-sm">• {suggestion}</div>
                  )}
                        </div>
                      </AlertDescription>
                    </Alert>
            )}
                </div>
              </CardContent>
            </Card>
      }
        </> :

    <Card>
          <CardContent className="p-8 text-center">
            <Bug className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Error Test Results</h3>
            <p className="text-gray-600 mb-4">Run error scenario tests to see cross-browser error handling performance</p>
            <Button onClick={runErrorScenarioTests} disabled={isRunning}>
              <Bug className="h-4 w-4 mr-2" />
              Run Error Tests
            </Button>
          </CardContent>
        </Card>
    }
    </div>;


  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5" />
          Enhanced Cross-Browser Testing
        </CardTitle>
        <CardDescription>
          Test compatibility and error handling across Chrome, Firefox, Safari, and Edge browsers
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="compatibility" className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              Compatibility
            </TabsTrigger>
            <TabsTrigger value="error-handling" className="flex items-center gap-2">
              <Bug className="h-4 w-4" />
              Error Handling
            </TabsTrigger>
          </TabsList>

          <TabsContent value="compatibility" className="mt-6">
            {renderCompatibilityTab()}
          </TabsContent>

          <TabsContent value="error-handling" className="mt-6">
            {renderErrorTestingTab()}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>);


};

export default CrossBrowserTestManager;