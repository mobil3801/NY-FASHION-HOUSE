
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Brain, AlertTriangle, CheckCircle, XCircle, TrendingUp, Activity } from 'lucide-react';
import { toast } from 'sonner';

interface MemorySnapshot {
  timestamp: Date;
  usedJSHeapSize: number;
  totalJSHeapSize: number;
  jsHeapSizeLimit: number;
  usedMemoryMB: number;
  totalMemoryMB: number;
}

interface MemoryLeakResult {
  detected: boolean;
  severity: 'low' | 'medium' | 'high' | 'critical';
  leakRate: number; // MB/minute
  memoryGrowth: number; // percentage
  recommendations: string[];
  snapshots: MemorySnapshot[];
}

const MemoryLeakDetector: React.FC = () => {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [currentSnapshot, setCurrentSnapshot] = useState<MemorySnapshot | null>(null);
  const [memoryHistory, setMemoryHistory] = useState<MemorySnapshot[]>([]);
  const [leakResult, setLeakResult] = useState<MemoryLeakResult | null>(null);
  const [monitoringDuration, setMonitoringDuration] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isMonitoring) {
      interval = setInterval(() => {
        takeMemorySnapshot();
        setMonitoringDuration((prev) => prev + 1);
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isMonitoring]);

  const takeMemorySnapshot = () => {
    if ('performance' in window && 'memory' in (window.performance as any)) {
      const memory = (window.performance as any).memory;
      const snapshot: MemorySnapshot = {
        timestamp: new Date(),
        usedJSHeapSize: memory.usedJSHeapSize,
        totalJSHeapSize: memory.totalJSHeapSize,
        jsHeapSizeLimit: memory.jsHeapSizeLimit,
        usedMemoryMB: Math.round(memory.usedJSHeapSize / (1024 * 1024) * 100) / 100,
        totalMemoryMB: Math.round(memory.totalJSHeapSize / (1024 * 1024) * 100) / 100
      };

      setCurrentSnapshot(snapshot);
      setMemoryHistory((prev) => [...prev.slice(-59), snapshot]); // Keep last 60 snapshots
    } else {
      // Fallback for browsers without performance.memory
      const snapshot: MemorySnapshot = {
        timestamp: new Date(),
        usedJSHeapSize: 0,
        totalJSHeapSize: 0,
        jsHeapSizeLimit: 0,
        usedMemoryMB: 0,
        totalMemoryMB: 0
      };
      setCurrentSnapshot(snapshot);
    }
  };

  const startMonitoring = async () => {
    setIsMonitoring(true);
    setMonitoringDuration(0);
    setMemoryHistory([]);
    setLeakResult(null);
    takeMemorySnapshot();
    toast.info('Memory monitoring started');
  };

  const stopMonitoring = () => {
    setIsMonitoring(false);
    analyzeMemoryLeaks();
    toast.success('Memory monitoring stopped');
  };

  const analyzeMemoryLeaks = () => {
    if (memoryHistory.length < 10) {
      toast.warning('Insufficient data for leak analysis. Monitor for at least 10 seconds.');
      return;
    }

    const firstSnapshot = memoryHistory[0];
    const lastSnapshot = memoryHistory[memoryHistory.length - 1];
    const timeDiffMinutes = (lastSnapshot.timestamp.getTime() - firstSnapshot.timestamp.getTime()) / (1000 * 60);

    const memoryGrowth = (lastSnapshot.usedMemoryMB - firstSnapshot.usedMemoryMB) / firstSnapshot.usedMemoryMB * 100;
    const leakRate = (lastSnapshot.usedMemoryMB - firstSnapshot.usedMemoryMB) / Math.max(timeDiffMinutes, 1);

    // Analyze memory patterns
    let isIncreasing = true;
    let peakCount = 0;
    let valleyCount = 0;

    for (let i = 1; i < memoryHistory.length - 1; i++) {
      const prev = memoryHistory[i - 1].usedMemoryMB;
      const curr = memoryHistory[i].usedMemoryMB;
      const next = memoryHistory[i + 1].usedMemoryMB;

      if (curr > prev && curr > next) peakCount++;
      if (curr < prev && curr < next) valleyCount++;
      if (curr < prev) isIncreasing = false;
    }

    const detected = memoryGrowth > 10 || leakRate > 1 || isIncreasing && peakCount < 2;

    let severity: 'low' | 'medium' | 'high' | 'critical' = 'low';
    if (leakRate > 5 || memoryGrowth > 50) severity = 'critical';else
    if (leakRate > 2 || memoryGrowth > 25) severity = 'high';else
    if (leakRate > 0.5 || memoryGrowth > 15) severity = 'medium';

    const recommendations = generateRecommendations(detected, severity, leakRate, memoryGrowth, peakCount, valleyCount);

    const result: MemoryLeakResult = {
      detected,
      severity,
      leakRate,
      memoryGrowth,
      recommendations,
      snapshots: [...memoryHistory]
    };

    setLeakResult(result);
  };

  const generateRecommendations = (
  detected: boolean,
  severity: string,
  leakRate: number,
  memoryGrowth: number,
  peakCount: number,
  valleyCount: number)
  : string[] => {
    const recommendations: string[] = [];

    if (detected) {
      if (severity === 'critical') {
        recommendations.push('Critical memory leak detected - immediate action required');
        recommendations.push('Check for circular references and event listeners');
        recommendations.push('Use browser DevTools Memory tab for detailed analysis');
      }

      if (leakRate > 2) {
        recommendations.push('High memory growth rate detected');
        recommendations.push('Review component lifecycle methods for proper cleanup');
        recommendations.push('Check for unused variables and closures');
      }

      if (memoryGrowth > 25) {
        recommendations.push('Significant memory growth observed');
        recommendations.push('Consider implementing object pooling for frequently created objects');
        recommendations.push('Review DOM manipulations and ensure proper cleanup');
      }

      if (peakCount < 2) {
        recommendations.push('Memory is not being released properly');
        recommendations.push('Check garbage collection patterns');
        recommendations.push('Review React component unmounting and cleanup');
      }
    } else {
      recommendations.push('No significant memory leaks detected');
      recommendations.push('Memory usage appears stable');
      if (valleyCount > peakCount) {
        recommendations.push('Good garbage collection activity observed');
      }
    }

    return recommendations;
  };

  const simulateMemoryLeak = () => {
    // Create objects that won't be garbage collected easily
    const leakyObjects: any[] = [];

    for (let i = 0; i < 10000; i++) {
      const obj = {
        id: i,
        data: new Array(100).fill(`leak-${i}`),
        timestamp: new Date(),
        circular: null as any
      };
      obj.circular = obj; // Circular reference
      leakyObjects.push(obj);
    }

    // Add to global scope to prevent GC
    (window as any).__memoryLeakTest = leakyObjects;

    toast.warning('Memory leak simulation started - for testing purposes only');
  };

  const cleanupMemoryLeak = () => {
    if ((window as any).__memoryLeakTest) {
      delete (window as any).__memoryLeakTest;
      toast.success('Memory leak simulation cleaned up');
    }
  };

  const getMemoryUsageColor = (usedMB: number, totalMB: number) => {
    const percentage = usedMB / totalMB * 100;
    if (percentage > 80) return 'text-red-600';
    if (percentage > 60) return 'text-orange-600';
    if (percentage > 40) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':return 'border-red-500 bg-red-50';
      case 'high':return 'border-orange-500 bg-orange-50';
      case 'medium':return 'border-yellow-500 bg-yellow-50';
      case 'low':return 'border-green-500 bg-green-50';
      default:return 'border-gray-300 bg-gray-50';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          Memory Leak Detection
        </CardTitle>
        <CardDescription>
          Monitor JavaScript heap memory usage and detect potential memory leaks
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Control Panel */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              onClick={isMonitoring ? stopMonitoring : startMonitoring}
              className={isMonitoring ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'}>

              {isMonitoring ? 'Stop Monitoring' : 'Start Monitoring'}
            </Button>
            <Button
              variant="outline"
              onClick={simulateMemoryLeak}
              disabled={isMonitoring}>

              Simulate Leak
            </Button>
            <Button
              variant="outline"
              onClick={cleanupMemoryLeak}
              disabled={isMonitoring}>

              Cleanup Test
            </Button>
          </div>
          {isMonitoring &&
          <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 animate-pulse text-blue-500" />
              <Badge variant="outline">
                Monitoring: {Math.floor(monitoringDuration / 60)}:{String(monitoringDuration % 60).padStart(2, '0')}
              </Badge>
            </div>
          }
        </div>

        {/* Current Memory Status */}
        {currentSnapshot &&
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className={`text-2xl font-bold ${getMemoryUsageColor(currentSnapshot.usedMemoryMB, currentSnapshot.totalMemoryMB)}`}>
                      {currentSnapshot.usedMemoryMB}MB
                    </div>
                    <div className="text-sm text-gray-600">Used Memory</div>
                  </div>
                  <Brain className="h-8 w-8 text-blue-500" />
                </div>
                <Progress
                value={currentSnapshot.usedMemoryMB / currentSnapshot.totalMemoryMB * 100}
                className="mt-2" />

              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold">
                      {currentSnapshot.totalMemoryMB}MB
                    </div>
                    <div className="text-sm text-gray-600">Total Allocated</div>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold">
                      {Math.round(currentSnapshot.jsHeapSizeLimit / (1024 * 1024) * 100) / 100}MB
                    </div>
                    <div className="text-sm text-gray-600">Heap Limit</div>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>
        }

        {/* Memory History Graph */}
        {memoryHistory.length > 0 &&
        <Card>
            <CardHeader>
              <CardTitle className="text-lg">Memory Usage Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-40 flex items-end space-x-1">
                {memoryHistory.slice(-30).map((snapshot, index) => {
                const maxMemory = Math.max(...memoryHistory.map((s) => s.usedMemoryMB));
                const height = snapshot.usedMemoryMB / maxMemory * 100;

                return (
                  <div
                    key={index}
                    className="bg-blue-500 flex-1 min-w-0 transition-all duration-300"
                    style={{ height: `${height}%` }}
                    title={`${snapshot.usedMemoryMB}MB at ${snapshot.timestamp.toLocaleTimeString()}`} />);


              })}
              </div>
              <div className="mt-2 text-sm text-gray-600 text-center">
                Memory usage over time (last 30 snapshots)
              </div>
            </CardContent>
          </Card>
        }

        {/* Analysis Results */}
        {leakResult &&
        <Alert className={getSeverityColor(leakResult.severity)}>
            <div className="flex items-start space-x-2">
              {leakResult.detected ?
            <XCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" /> :

            <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
            }
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">
                    {leakResult.detected ? 'Memory Leak Detected' : 'No Memory Leaks Detected'}
                  </h3>
                  <Badge variant="outline" className={
                leakResult.severity === 'critical' ? 'text-red-600' :
                leakResult.severity === 'high' ? 'text-orange-600' :
                leakResult.severity === 'medium' ? 'text-yellow-600' :
                'text-green-600'
                }>
                    {leakResult.severity}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <span className="text-sm font-medium">Memory Growth:</span>
                    <span className="ml-2">{leakResult.memoryGrowth.toFixed(1)}%</span>
                  </div>
                  <div>
                    <span className="text-sm font-medium">Leak Rate:</span>
                    <span className="ml-2">{leakResult.leakRate.toFixed(2)} MB/min</span>
                  </div>
                </div>

                <AlertDescription>
                  <div className="space-y-1">
                    <strong>Recommendations:</strong>
                    {leakResult.recommendations.map((rec, index) =>
                  <div key={index} className="text-sm">
                        • {rec}
                      </div>
                  )}
                  </div>
                </AlertDescription>
              </div>
            </div>
          </Alert>
        }

        {/* Help Information */}
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Memory Leak Detection Tips:</strong>
            <div className="mt-2 space-y-1 text-sm">
              • Monitor for at least 30 seconds for accurate results
              • Perform user interactions during monitoring to simulate real usage
              • Use "Simulate Leak" to test the detection system
              • Check browser DevTools Memory tab for detailed analysis
              • Memory usage may fluctuate due to garbage collection cycles
            </div>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>);

};

export default MemoryLeakDetector;