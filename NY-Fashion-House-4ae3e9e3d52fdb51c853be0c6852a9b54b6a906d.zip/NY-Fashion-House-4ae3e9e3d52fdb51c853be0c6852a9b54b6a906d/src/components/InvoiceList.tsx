
import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Eye, MoreHorizontal, Mail, Printer, Edit, Trash2, DollarSign, AlertCircle, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { Invoice } from '@/types/invoice';

interface InvoiceListProps {
  invoices: Invoice[];
  onViewInvoice: (invoice: Invoice) => void;
  onEditInvoice: (invoice: Invoice) => void;
  onDeleteInvoice: (invoice: Invoice) => void;
  onPrintInvoice: (invoice: Invoice) => void;
  onEmailInvoice: (invoice: Invoice) => void;
  onRecordPayment: (invoice: Invoice) => void;
  loading?: boolean;
}

const statusColors = {
  draft: 'bg-gray-100 text-gray-800 border-gray-200',
  sent: 'bg-blue-100 text-blue-800 border-blue-200',
  viewed: 'bg-purple-100 text-purple-800 border-purple-200',
  paid: 'bg-green-100 text-green-800 border-green-200',
  overdue: 'bg-red-100 text-red-800 border-red-200',
  cancelled: 'bg-gray-100 text-gray-800 border-gray-200'
};

const InvoiceList: React.FC<InvoiceListProps> = ({
  invoices,
  onViewInvoice,
  onEditInvoice,
  onDeleteInvoice,
  onPrintInvoice,
  onEmailInvoice,
  onRecordPayment,
  loading = false
}) => {
  const formatCurrency = (amount: number) => `$${amount.toFixed(2)}`;

  const getStatusIcon = (status: Invoice['status']) => {
    switch (status) {
      case 'overdue':
        return <AlertCircle className="h-3 w-3 mr-1" />;
      case 'paid':
        return <DollarSign className="h-3 w-3 mr-1" />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        </CardContent>
      </Card>);

  }

  if (invoices.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center py-8">
            <div className="mx-auto h-12 w-12 text-gray-400 mb-4">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No invoices found</h3>
            <p className="text-gray-500">Create your first invoice or adjust your filters to see results.</p>
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Invoices ({invoices.length})</h3>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Invoice #</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Issue Date</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Paid</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[50px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoices.map((invoice) =>
              <TableRow key={invoice.id} className="hover:bg-gray-50">
                  <TableCell className="font-medium">
                    <button
                    onClick={() => onViewInvoice(invoice)}
                    className="text-blue-600 hover:text-blue-800 hover:underline">

                      {invoice.invoiceNumber}
                    </button>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{invoice.customerName}</div>
                      {invoice.customerPhone &&
                    <div className="text-sm text-gray-500">{invoice.customerPhone}</div>
                    }
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="h-3 w-3 mr-1" />
                      {format(invoice.issueDate, 'MMM dd, yyyy')}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className={`flex items-center text-sm ${
                  invoice.status === 'overdue' ? 'text-red-600' : 'text-gray-600'}`
                  }>
                      <Calendar className="h-3 w-3 mr-1" />
                      {format(invoice.dueDate, 'MMM dd, yyyy')}
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">
                    {formatCurrency(invoice.totalAmount)}
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium text-green-600">
                        {formatCurrency(invoice.paidAmount)}
                      </div>
                      {invoice.remainingAmount > 0 &&
                    <div className="text-xs text-gray-500">
                          {formatCurrency(invoice.remainingAmount)} due
                        </div>
                    }
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                    variant="secondary"
                    className={`${statusColors[invoice.status]} flex items-center w-fit`}>

                      {getStatusIcon(invoice.status)}
                      {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onViewInvoice(invoice)}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onEditInvoice(invoice)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onPrintInvoice(invoice)}>
                          <Printer className="h-4 w-4 mr-2" />
                          Print
                        </DropdownMenuItem>
                        {invoice.customerEmail &&
                      <DropdownMenuItem onClick={() => onEmailInvoice(invoice)}>
                            <Mail className="h-4 w-4 mr-2" />
                            Send Email
                          </DropdownMenuItem>
                      }
                        {invoice.remainingAmount > 0 &&
                      <DropdownMenuItem onClick={() => onRecordPayment(invoice)}>
                            <DollarSign className="h-4 w-4 mr-2" />
                            Record Payment
                          </DropdownMenuItem>
                      }
                        <DropdownMenuItem
                        onClick={() => onDeleteInvoice(invoice)}
                        className="text-red-600">

                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>);

};

export default InvoiceList;