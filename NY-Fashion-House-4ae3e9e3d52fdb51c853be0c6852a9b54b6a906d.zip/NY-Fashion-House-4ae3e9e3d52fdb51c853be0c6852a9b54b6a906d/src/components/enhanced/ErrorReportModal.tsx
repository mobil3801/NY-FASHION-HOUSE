import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle } from
'@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Copy, ExternalLink, Bug, Code, MapPin, Layers } from 'lucide-react';
import { toast } from 'sonner';
import { EnhancedErrorReport } from '@/services/enhancedDevToolsErrorService';

interface ErrorReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  errorReport: EnhancedErrorReport | null;
}

const ErrorReportModal: React.FC<ErrorReportModalProps> = ({
  isOpen,
  onClose,
  errorReport
}) => {
  if (!errorReport) return null;

  const handleCopyError = () => {
    navigator.clipboard.writeText(errorReport.formattedStack);
    toast.success('Error details copied to clipboard');
  };

  const handleCopyErrorId = () => {
    navigator.clipboard.writeText(errorReport.id);
    toast.success('Error ID copied to clipboard');
  };

  const getSeverityColor = (severity: EnhancedErrorReport['severity']) => {
    switch (severity) {
      case 'low':return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'medium':return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'high':return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'critical':return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Bug className="w-5 h-5" />
            Enhanced Error Report
          </DialogTitle>
          <DialogDescription className="flex items-center gap-2">
            <span>Error ID: {errorReport.id}</span>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 px-2"
              onClick={handleCopyErrorId}>

              <Copy className="w-3 h-3" />
            </Button>
            <span>•</span>
            <span>{new Date(errorReport.timestamp).toLocaleString()}</span>
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
              <TabsTrigger value="stack">Stack Trace</TabsTrigger>
              <TabsTrigger value="components">Components</TabsTrigger>
              <TabsTrigger value="context">Context</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Error Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Badge className={getSeverityColor(errorReport.severity)}>
                        {errorReport.severity}
                      </Badge>
                      <Badge variant="outline">{errorReport.category}</Badge>
                      {errorReport.devToolsDetails.parsedStack.length > 0 &&
                      <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                          DevTools Enhanced
                        </Badge>
                      }
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Message</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {errorReport.message}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">User-Friendly Message</h4>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        {errorReport.userFriendlyMessage}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Location</h4>
                      <code className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                        {errorReport.errorLocation}
                      </code>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Analysis</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Root Cause</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {errorReport.rootCause}
                      </p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Recoverable</h4>
                      <Badge variant={errorReport.isRecoverable ? 'default' : 'destructive'}>
                        {errorReport.isRecoverable ? 'Yes' : 'No'}
                      </Badge>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Stack Analysis</h4>
                      <div className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                        <div>User Code Frames: {errorReport.stackAnalysis.userCodeFrames.length}</div>
                        <div>Library Frames: {errorReport.stackAnalysis.libraryFrames.length}</div>
                        <div>React Components: {errorReport.stackAnalysis.reactComponentChain.length}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    {errorReport.recommendations.map((rec, index) =>
                    <li key={index} className="text-gray-700 dark:text-gray-300">
                        {rec}
                      </li>
                    )}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="location" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Error Location Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Primary Location</h4>
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md">
                      <code className="text-sm">{errorReport.errorLocation}</code>
                    </div>
                    <div className="mt-2">
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        {errorReport.stackAnalysis.summary}
                      </p>
                    </div>
                  </div>

                  {errorReport.devToolsDetails.sourceContext && errorReport.devToolsDetails.sourceContext.length > 0 &&
                  <div>
                      <h4 className="font-semibold mb-2">Source Context</h4>
                      {errorReport.devToolsDetails.sourceContext.map((context, index) =>
                    <div key={index} className="mb-4">
                          <h5 className="text-sm font-medium mb-1 flex items-center gap-2">
                            <Code className="w-3 h-3" />
                            {context.fileName.split('/').pop()}
                            <Badge variant="outline" className="text-xs">
                              Line {context.lineNumber}
                            </Badge>
                          </h5>
                          <div className="bg-gray-900 text-gray-100 p-3 rounded-md text-xs font-mono overflow-x-auto">
                            {context.contextLines.map((line, lineIndex) => {
                          const isErrorLine = line.startsWith(`${context.lineNumber}:`);
                          return (
                            <div key={lineIndex} className={isErrorLine ? 'bg-red-900 bg-opacity-50 px-1' : 'px-1'}>
                                  {isErrorLine ? '>>> ' : '    '}{line}
                                </div>);

                        })}
                          </div>
                          {context.errorColumn > 0 &&
                      <div className="mt-1 text-xs text-gray-500">
                              Error at column {context.errorColumn}
                            </div>
                      }
                        </div>
                    )}
                    </div>
                  }
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stack" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Code className="w-4 h-4" />
                    Enhanced Stack Trace
                  </CardTitle>
                  <Button variant="outline" size="sm" onClick={handleCopyError}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Stack
                  </Button>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="user-code">
                      <AccordionTrigger>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">
                            User Code Frames ({errorReport.stackAnalysis.userCodeFrames.length})
                          </Badge>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {errorReport.stackAnalysis.userCodeFrames.map((frame, index) =>
                          <div key={index} className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-md">
                              <div className="font-mono text-sm">
                                {frame.originalFrame.functionName &&
                              <div className="font-semibold text-blue-700 dark:text-blue-300">
                                    {frame.originalFrame.functionName}()
                                  </div>
                              }
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                  {frame.relativeFilePath}:{frame.originalFrame.lineNumber}:{frame.originalFrame.columnNumber}
                                </div>
                                <div className="flex gap-2 mt-1">
                                  {frame.componentName &&
                                <Badge variant="outline" className="text-xs">
                                      Component: {frame.componentName}
                                    </Badge>
                                }
                                  {frame.isReactComponent &&
                                <Badge variant="outline" className="text-xs bg-green-100">
                                      React
                                    </Badge>
                                }
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="library-code">
                      <AccordionTrigger>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">
                            Library Code Frames ({errorReport.stackAnalysis.libraryFrames.length})
                          </Badge>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {errorReport.stackAnalysis.libraryFrames.slice(0, 10).map((frame, index) =>
                          <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                              <div className="font-mono text-sm">
                                {frame.originalFrame.functionName &&
                              <div className="font-semibold">{frame.originalFrame.functionName}()</div>
                              }
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                  {frame.fileName.split('/').pop()}:{frame.originalFrame.lineNumber}
                                </div>
                              </div>
                            </div>
                          )}
                          {errorReport.stackAnalysis.libraryFrames.length > 10 &&
                          <div className="text-center text-xs text-gray-500">
                              ... and {errorReport.stackAnalysis.libraryFrames.length - 10} more frames
                            </div>
                          }
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="raw-stack">
                      <AccordionTrigger>Raw Stack Trace</AccordionTrigger>
                      <AccordionContent>
                        <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded-md overflow-x-auto whitespace-pre-wrap max-h-96">
                          {errorReport.devToolsDetails.stack}
                        </pre>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="components" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="w-4 h-4" />
                    React Component Context
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {errorReport.componentContext.length > 0 ?
                  <div className="space-y-3">
                      <div>
                        <h4 className="font-semibold mb-2">Component Chain</h4>
                        <div className="flex flex-wrap gap-2">
                          {errorReport.componentContext.map((component, index) =>
                        <div key={index} className="flex items-center">
                              <Badge variant="secondary" className="bg-green-100 text-green-800">
                                {component}
                              </Badge>
                              {index < errorReport.componentContext.length - 1 &&
                          <span className="mx-2 text-gray-400">→</span>
                          }
                            </div>
                        )}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Component Stack Details</h4>
                        <div className="space-y-2">
                          {errorReport.stackAnalysis.reactComponentChain.map((frame, index) =>
                        <div key={index} className="p-3 bg-green-50 dark:bg-green-900/20 rounded-md">
                              <div className="font-semibold text-green-700 dark:text-green-300 flex items-center gap-2">
                                <Layers className="w-3 h-3" />
                                {frame.componentName}
                              </div>
                              <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                                {frame.relativeFilePath}:{frame.originalFrame.lineNumber}
                              </div>
                              {frame.originalFrame.functionName &&
                          <div className="text-xs text-gray-500 mt-1">
                                  Function: {frame.originalFrame.functionName}
                                </div>
                          }
                            </div>
                        )}
                        </div>
                      </div>

                      {errorReport.devToolsDetails.componentStack &&
                    <div>
                          <h4 className="font-semibold mb-2">Raw Component Stack</h4>
                          <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded-md overflow-x-auto whitespace-pre-wrap max-h-48">
                            {errorReport.devToolsDetails.componentStack}
                          </pre>
                        </div>
                    }
                    </div> :

                  <div className="text-center py-8">
                      <Layers className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500 dark:text-gray-400">
                        No React component information available for this error
                      </p>
                    </div>
                  }
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="context" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Environment</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div>
                      <strong>URL:</strong>
                      <div className="text-xs text-blue-600 dark:text-blue-400 mt-1 break-all">
                        {errorReport.context.url}
                      </div>
                    </div>
                    <div>
                      <strong>User Agent:</strong>
                      <div className="text-xs text-gray-600 dark:text-gray-400 mt-1 break-all">
                        {errorReport.context.userAgent}
                      </div>
                    </div>
                    <div>
                      <strong>Session:</strong>
                      <code className="text-xs bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded">
                        {errorReport.context.sessionId}
                      </code>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">DevTools Info</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div>
                      <strong>Enhanced Mode:</strong>{' '}
                      <Badge variant={errorReport.devToolsDetails.devToolsInfo ? 'default' : 'secondary'}>
                        {errorReport.devToolsDetails.devToolsInfo ? 'Enabled' : 'Fallback'}
                      </Badge>
                    </div>
                    {errorReport.devToolsDetails.devToolsInfo &&
                    <>
                        <div>
                          <strong>Console Timestamp:</strong>
                          <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                            {new Date(errorReport.devToolsDetails.devToolsInfo.consoleTimestamp).toLocaleString()}
                          </div>
                        </div>
                        {errorReport.devToolsDetails.devToolsInfo.scriptId &&
                      <div>
                            <strong>Script ID:</strong>
                            <code className="text-xs bg-gray-100 dark:bg-gray-800 px-1 py-0.5 rounded ml-1">
                              {errorReport.devToolsDetails.devToolsInfo.scriptId}
                            </code>
                          </div>
                      }
                      </>
                    }
                    <div>
                      <strong>Stack Frames:</strong>
                      <div className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                        {errorReport.devToolsDetails.parsedStack.length} total frames parsed
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {errorReport.context.additionalData &&
              <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Additional Data</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap max-h-48">
                      {JSON.stringify(errorReport.context.additionalData, null, 2)}
                    </pre>
                  </CardContent>
                </Card>
              }

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Formatted Report</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap max-h-64">
                    {errorReport.formattedStack}
                  </pre>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex-shrink-0 flex justify-between items-center pt-4 border-t">
          <div className="text-xs text-gray-500">
            Report generated with DevTools integration
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleCopyError}>
              <Copy className="w-4 h-4 mr-2" />
              Copy Details
            </Button>
            <Button onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>);

};

export default ErrorReportModal;