// Enhanced error boundary with comprehensive reporting
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { ErrorContext } from '@/types/errorTypes';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import { enhancedDevToolsErrorService } from '@/services/enhancedDevToolsErrorService';
import ErrorReportModal from './ErrorReportModal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, RefreshCw, FileText } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo, correlationId: string) => void;
  level?: 'page' | 'component' | 'root';
  action?: string;
  component?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  correlationId: string | null;
  showDetailedReport: boolean;
}

class EnhancedErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    correlationId: null,
    showDetailedReport: false
  };

  public static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Collect comprehensive context
    const context: ErrorContext = {
      title: `Error in ${this.props.component || 'React Component'}`,
      description: 'A component failed to render properly',
      action: this.props.action || 'Component rendering',
      operation: 'React component lifecycle',
      component: this.props.component,
      componentStack: errorInfo.componentStack,
      severity: this.props.level === 'root' ? 'critical' : 'high',
      category: 'client',
      route: window.location.pathname,
      userAgent: navigator.userAgent,
      additionalData: {
        componentProps: this.props,
        errorBoundaryLevel: this.props.level,
        reactStack: errorInfo.componentStack
      }
    };

    // Use enhanced DevTools error service for detailed error collection
    enhancedDevToolsErrorService.logEnhancedError(error, context).
    then((errorReport) => {
      this.setState({
        error,
        errorInfo,
        correlationId: errorReport.id
      });

      // Call custom error handler
      if (this.props.onError) {
        this.props.onError(error, errorInfo, errorReport.id);
      }
    }).
    catch(() => {
      // Fallback to original error handler if DevTools service fails
      const correlationId = enhancedErrorLoggingService.logError(error, context);

      this.setState({
        error,
        errorInfo,
        correlationId
      });

      // Call custom error handler
      if (this.props.onError) {
        this.props.onError(error, errorInfo, correlationId);
      }
    });
  }

  private handleRetry = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      correlationId: null,
      showDetailedReport: false
    });
  };

  private handleShowReport = () => {
    this.setState({ showDetailedReport: true });
  };

  private handleCloseReport = () => {
    this.setState({ showDetailedReport: false });
  };

  private handleHome = () => {
    window.location.href = '/';
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      const errorReport = this.state.correlationId ?
      enhancedErrorLoggingService.getErrorReport(this.state.correlationId) : null;

      const isRootError = this.props.level === 'root';

      return (
        <div className={isRootError ? "min-h-screen bg-gray-50 flex items-center justify-center p-4" : ""}>
          <Card className={`${isRootError ? 'w-full max-w-2xl' : 'border-red-200 bg-red-50'}`}>
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle className="text-xl text-red-600">
                {isRootError ? 'Application Error' : 'Component Error'}
              </CardTitle>
              <CardDescription>
                {isRootError ?
                'The application encountered an unexpected error.' :
                'This section failed to load properly.'
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {this.state.correlationId &&
              <div className="text-center">
                  <div className="text-sm text-gray-500 bg-gray-100 p-3 rounded-lg">
                    <p className="font-medium">Error ID: {this.state.correlationId}</p>
                    <p className="text-xs mt-1">Reference this ID when reporting the issue</p>
                  </div>
                </div>
              }

              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button onClick={this.handleRetry} className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Try Again
                </Button>
                
                {errorReport &&
                <Button
                  variant="outline"
                  onClick={this.handleShowReport}
                  className="flex items-center gap-2">

                    <FileText className="w-4 h-4" />
                    View Details
                  </Button>
                }
                
                {isRootError &&
                <Button
                  variant="outline"
                  onClick={this.handleHome}
                  className="flex items-center gap-2">

                    <RefreshCw className="w-4 h-4" />
                    Reload Page
                  </Button>
                }
              </div>

              {/* Development-only debug info */}
              {process.env.NODE_ENV === 'development' && this.state.error &&
              <details className="mt-4">
                  <summary className="cursor-pointer text-sm font-medium text-gray-700">
                    Debug Information (Development Only)
                  </summary>
                  <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm font-medium text-red-800 mb-2">Error:</p>
                    <pre className="text-xs text-red-700 whitespace-pre-wrap mb-4">
                      {this.state.error.message}
                    </pre>
                    
                    {this.state.error.stack &&
                  <>
                        <p className="text-sm font-medium text-red-800 mb-2">Stack Trace:</p>
                        <pre className="text-xs text-red-600 whitespace-pre-wrap max-h-40 overflow-y-auto">
                          {this.state.error.stack}
                        </pre>
                      </>
                  }
                  </div>
                </details>
              }

              {/* Error Report Modal */}
              {errorReport &&
              <ErrorReportModal
                isOpen={this.state.showDetailedReport}
                onClose={this.handleCloseReport}
                errorReport={errorReport}
                onRetry={this.handleRetry}
                onHome={isRootError ? this.handleHome : undefined} />

              }
            </CardContent>
          </Card>
        </div>);

    }

    return this.props.children;
  }
}

export default EnhancedErrorBoundary;