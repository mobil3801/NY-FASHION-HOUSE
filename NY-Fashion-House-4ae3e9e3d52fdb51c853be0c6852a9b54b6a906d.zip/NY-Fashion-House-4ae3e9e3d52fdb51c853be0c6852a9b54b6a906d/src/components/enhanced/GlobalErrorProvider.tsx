// Global error context provider
import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ErrorReport } from '@/types/errorTypes';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import ErrorReportModal from './ErrorReportModal';

interface GlobalErrorContextType {
  showErrorReport: (correlationId: string) => void;
  hideErrorReport: () => void;
  currentErrorReport: ErrorReport | null;
  errorStatistics: ReturnType<typeof enhancedErrorLoggingService.getErrorStatistics>;
}

const GlobalErrorContext = createContext<GlobalErrorContextType | undefined>(undefined);

interface GlobalErrorProviderProps {
  children: ReactNode;
}

export const GlobalErrorProvider: React.FC<GlobalErrorProviderProps> = ({ children }) => {
  const [currentErrorReport, setCurrentErrorReport] = useState<ErrorReport | null>(null);
  const [showModal, setShowModal] = useState(false);

  const showErrorReport = (correlationId: string) => {
    const report = enhancedErrorLoggingService.getErrorReport(correlationId);
    if (report) {
      setCurrentErrorReport(report);
      setShowModal(true);
    }
  };

  const hideErrorReport = () => {
    setShowModal(false);
    setCurrentErrorReport(null);
  };

  const errorStatistics = enhancedErrorLoggingService.getErrorStatistics();

  const value: GlobalErrorContextType = {
    showErrorReport,
    hideErrorReport,
    currentErrorReport,
    errorStatistics
  };

  return (
    <GlobalErrorContext.Provider value={value}>
      {children}
      
      {currentErrorReport &&
      <ErrorReportModal
        isOpen={showModal}
        onClose={hideErrorReport}
        errorReport={currentErrorReport} />

      }
    </GlobalErrorContext.Provider>);

};

export const useGlobalError = () => {
  const context = useContext(GlobalErrorContext);
  if (context === undefined) {
    throw new Error('useGlobalError must be used within a GlobalErrorProvider');
  }
  return context;
};