// Button component to show error report modal
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FileText, AlertTriangle } from 'lucide-react';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';
import ErrorReportModal from './ErrorReportModal';

interface ErrorReportButtonProps {
  correlationId: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'default' | 'lg';
  showIcon?: boolean;
  className?: string;
}

const ErrorReportButton: React.FC<ErrorReportButtonProps> = ({
  correlationId,
  variant = 'outline',
  size = 'sm',
  showIcon = true,
  className = ''
}) => {
  const [showReport, setShowReport] = useState(false);

  const errorReport = enhancedErrorLoggingService.getErrorReport(correlationId);

  if (!errorReport) {
    return null;
  }

  const handleShowReport = () => {
    setShowReport(true);
  };

  const handleCloseReport = () => {
    setShowReport(false);
  };

  return (
    <>
      <Button
        variant={variant}
        size={size}
        onClick={handleShowReport}
        className={`flex items-center gap-2 ${className}`}>

        {showIcon && (
        errorReport.severity === 'critical' || errorReport.severity === 'high' ?
        <AlertTriangle className="w-4 h-4" /> :
        <FileText className="w-4 h-4" />)
        }
        Error Details
      </Button>

      <ErrorReportModal
        isOpen={showReport}
        onClose={handleCloseReport}
        errorReport={errorReport} />

    </>);

};

export default ErrorReportButton;