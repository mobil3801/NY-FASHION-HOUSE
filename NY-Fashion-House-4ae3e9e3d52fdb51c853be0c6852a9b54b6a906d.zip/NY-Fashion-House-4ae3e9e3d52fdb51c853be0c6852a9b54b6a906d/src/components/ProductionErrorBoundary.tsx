import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw, Home, Bug } from 'lucide-react';
import { toast } from 'sonner';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  level?: 'page' | 'component' | 'root';
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorId: string | null;
}

class ProductionErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    errorId: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      error,
      errorInfo: null,
      errorId: `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    const errorId = `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    this.setState({
      error,
      errorInfo,
      errorId
    });

    // Log error details
    const errorDetails = {
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      route: window.location.pathname,
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString(),
      sessionId: this.getSessionId(),
      severity: this.props.level === 'root' ? 'critical' : 'high',
      errorId,
      context: {
        type: 'react-error-boundary',
        level: this.props.level || 'component'
      }
    };

    console.error(`[Route: ${window.location.pathname}] [ErrorLog ${errorId}]`, JSON.stringify(errorDetails, null, 2));

    // Call custom error handler
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Show user-friendly toast
    if (this.props.level !== 'root') {
      toast.error('An unexpected error occurred. Please try refreshing the page.');
    }
  }

  private getSessionId(): string {
    let sessionId = sessionStorage.getItem('session_id');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('session_id', sessionId);
    }
    return sessionId;
  }

  private handleRetry = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: null
    });
  };

  private handleGoHome = () => {
    window.location.href = '/';
  };

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      const isRootError = this.props.level === 'root';

      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-2xl">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle className="text-xl text-gray-900">
                {isRootError ? 'Application Error' : 'Something went wrong'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  {isRootError ?
                  'The application encountered an unexpected error. Our team has been notified.' :
                  'This section of the page encountered an error. You can try refreshing or continue browsing.'
                  }
                </p>
                
                {this.state.errorId &&
                <div className="text-sm text-gray-500 bg-gray-100 p-3 rounded-lg mb-4">
                    <p className="font-medium">Error ID: {this.state.errorId}</p>
                    <p className="text-xs mt-1">Reference this ID when reporting the issue</p>
                  </div>
                }
              </div>

              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button onClick={this.handleRetry} className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Try Again
                </Button>
                
                {isRootError ?
                <Button onClick={this.handleReload} variant="outline" className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Reload Page
                  </Button> :

                <Button onClick={this.handleGoHome} variant="outline" className="flex items-center gap-2">
                    <Home className="w-4 h-4" />
                    Go Home
                  </Button>
                }
              </div>

              {process.env.NODE_ENV === 'development' && this.state.error &&
              <details className="mt-6">
                  <summary className="cursor-pointer text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Bug className="w-4 h-4" />
                    Debug Information (Development Only)
                  </summary>
                  <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm font-medium text-red-800 mb-2">Error:</p>
                    <pre className="text-xs text-red-700 whitespace-pre-wrap mb-4">
                      {this.state.error.message}
                    </pre>
                    
                    <p className="text-sm font-medium text-red-800 mb-2">Stack Trace:</p>
                    <pre className="text-xs text-red-600 whitespace-pre-wrap max-h-40 overflow-y-auto">
                      {this.state.error.stack}
                    </pre>
                    
                    {this.state.errorInfo?.componentStack &&
                  <>
                        <p className="text-sm font-medium text-red-800 mb-2 mt-4">Component Stack:</p>
                        <pre className="text-xs text-red-600 whitespace-pre-wrap max-h-32 overflow-y-auto">
                          {this.state.errorInfo.componentStack}
                        </pre>
                      </>
                  }
                  </div>
                </details>
              }
            </CardContent>
          </Card>
        </div>);

    }

    return this.props.children;
  }
}

export default ProductionErrorBoundary;