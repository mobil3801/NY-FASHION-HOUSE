import React, { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, DollarSign, Percent } from 'lucide-react';
import { SalaryStructure } from '@/types/salary';
import { toast } from 'sonner';

interface SalaryStructureFormProps {
  structure?: SalaryStructure;
  onSubmit: (data: Omit<SalaryStructure, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

const SalaryStructureForm: React.FC<SalaryStructureFormProps> = ({
  structure,
  onSubmit,
  onCancel,
  isLoading = false
}) => {
  const { register, handleSubmit, control, watch, setValue, formState: { errors } } = useForm({
    defaultValues: structure || {
      position: '',
      department: '',
      baseSalary: 0,
      allowances: [],
      deductions: [],
      overtimeRate: 0,
      isActive: true
    }
  });

  const { fields: allowanceFields, append: appendAllowance, remove: removeAllowance } = useFieldArray({
    control,
    name: 'allowances'
  });

  const { fields: deductionFields, append: appendDeduction, remove: removeDeduction } = useFieldArray({
    control,
    name: 'deductions'
  });

  const departments = [
  'Engineering',
  'Human Resources',
  'Marketing',
  'Sales',
  'Finance',
  'Operations',
  'Customer Service'];


  const positions = [
  'Software Engineer',
  'Senior Software Engineer',
  'Team Lead',
  'Manager',
  'Senior Manager',
  'HR Executive',
  'HR Manager',
  'Marketing Executive',
  'Sales Executive',
  'Accountant',
  'Finance Manager'];


  const addAllowance = () => {
    appendAllowance({
      id: Date.now().toString(),
      name: '',
      type: 'fixed',
      amount: 0,
      isActive: true
    });
  };

  const addDeduction = () => {
    appendDeduction({
      id: Date.now().toString(),
      name: '',
      type: 'fixed',
      amount: 0,
      isActive: true
    });
  };

  const onFormSubmit = async (data: any) => {
    try {
      await onSubmit(data);
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Basic Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="position">Position *</Label>
              <Select onValueChange={(value) => setValue('position', value)} defaultValue={structure?.position}>
                <SelectTrigger>
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  {positions.map((position) =>
                  <SelectItem key={position} value={position}>
                      {position}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              {errors.position &&
              <p className="text-sm text-red-600">Position is required</p>
              }
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">Department *</Label>
              <Select onValueChange={(value) => setValue('department', value)} defaultValue={structure?.department}>
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) =>
                  <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              {errors.department &&
              <p className="text-sm text-red-600">Department is required</p>
              }
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="baseSalary">Base Salary ($) *</Label>
              <Input
                id="baseSalary"
                type="number"
                step="0.01"
                {...register('baseSalary', {
                  required: 'Base salary is required',
                  min: { value: 0, message: 'Base salary must be positive' }
                })}
                placeholder="Enter base salary" />

              {errors.baseSalary &&
              <p className="text-sm text-red-600">{errors.baseSalary.message}</p>
              }
            </div>

            <div className="space-y-2">
              <Label htmlFor="overtimeRate">Overtime Rate ($/hour)</Label>
              <Input
                id="overtimeRate"
                type="number"
                step="0.01"
                {...register('overtimeRate', {
                  min: { value: 0, message: 'Overtime rate must be positive' }
                })}
                placeholder="Enter overtime rate" />

              {errors.overtimeRate &&
              <p className="text-sm text-red-600">{errors.overtimeRate.message}</p>
              }
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="isActive"
              {...register('isActive')}
              defaultChecked={structure?.isActive !== false} />

            <Label htmlFor="isActive">Active Structure</Label>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="allowances" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="allowances">Allowances</TabsTrigger>
          <TabsTrigger value="deductions">Deductions</TabsTrigger>
        </TabsList>

        <TabsContent value="allowances">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Allowances</CardTitle>
              <Button type="button" onClick={addAllowance} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Allowance
              </Button>
            </CardHeader>
            <CardContent>
              {allowanceFields.length === 0 ?
              <div className="text-center py-8 text-gray-500">
                  No allowances added yet. Click "Add Allowance" to get started.
                </div> :

              <div className="space-y-4">
                  {allowanceFields.map((field, index) =>
                <div key={field.id} className="p-4 border rounded-lg">
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                        <div className="space-y-2">
                          <Label>Allowance Name</Label>
                          <Input
                        {...register(`allowances.${index}.name`, { required: true })}
                        placeholder="e.g., House Rent" />

                        </div>

                        <div className="space-y-2">
                          <Label>Type</Label>
                          <Select onValueChange={(value) => setValue(`allowances.${index}.type`, value as 'fixed' | 'percentage')}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="fixed">Fixed Amount</SelectItem>
                              <SelectItem value="percentage">Percentage</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>Amount</Label>
                          <div className="relative">
                            <Input
                          type="number"
                          step="0.01"
                          {...register(`allowances.${index}.amount`, { required: true })}
                          placeholder="0" />

                            {watch(`allowances.${index}.type`) === 'percentage' &&
                        <Percent className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        }
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Switch
                          {...register(`allowances.${index}.isActive`)}
                          defaultChecked={true} />

                            <Label>Active</Label>
                          </div>
                          <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeAllowance(index)}>

                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                )}
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deductions">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Deductions</CardTitle>
              <Button type="button" onClick={addDeduction} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Deduction
              </Button>
            </CardHeader>
            <CardContent>
              {deductionFields.length === 0 ?
              <div className="text-center py-8 text-gray-500">
                  No deductions added yet. Click "Add Deduction" to get started.
                </div> :

              <div className="space-y-4">
                  {deductionFields.map((field, index) =>
                <div key={field.id} className="p-4 border rounded-lg">
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                        <div className="space-y-2">
                          <Label>Deduction Name</Label>
                          <Input
                        {...register(`deductions.${index}.name`, { required: true })}
                        placeholder="e.g., Income Tax" />

                        </div>

                        <div className="space-y-2">
                          <Label>Type</Label>
                          <Select onValueChange={(value) => setValue(`deductions.${index}.type`, value as 'fixed' | 'percentage' | 'tax')}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="fixed">Fixed Amount</SelectItem>
                              <SelectItem value="percentage">Percentage</SelectItem>
                              <SelectItem value="tax">Tax Bracket</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label>Amount/Rate</Label>
                          <div className="relative">
                            <Input
                          type="number"
                          step="0.01"
                          {...register(`deductions.${index}.amount`, { required: true })}
                          placeholder="0" />

                            {(watch(`deductions.${index}.type`) === 'percentage' || watch(`deductions.${index}.type`) === 'tax') &&
                        <Percent className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        }
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Switch
                          {...register(`deductions.${index}.isActive`)}
                          defaultChecked={true} />

                            <Label>Active</Label>
                          </div>
                          <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeDeduction(index)}>

                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                )}
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Form Actions */}
      <div className="flex items-center justify-end space-x-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Saving...' : structure ? 'Update Structure' : 'Create Structure'}
        </Button>
      </div>
    </form>);

};

export default SalaryStructureForm;