import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Customer } from "@/types/customer";
import { useFormValidation } from "@/hooks/use-form-validation";
import { validators, validateUSAStandards } from "@/utils/formatValidation";
import { toast } from "sonner";

interface CustomerFormProps {
  customer?: Customer;
  onSubmit: (customer: Omit<Customer, 'id' | 'createdAt' | 'totalPurchases' | 'totalSpent'>) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

const CustomerForm = ({ customer, onSubmit, onCancel, isLoading = false }: CustomerFormProps) => {
  const initialValues = {
    name: customer?.name || '',
    email: customer?.email || '',
    phone: customer?.phone || '',
    address: customer?.address || '',
    notes: customer?.notes || '',
    status: customer?.status || 'active'
  };

  const validationRules = {
    name: {
      required: true,
      minLength: 2,
      maxLength: 100
    },
    email: {
      required: true,
      custom: (value: string) => validators.email(value)
    },
    phone: {
      required: true,
      custom: (value: string) => validateUSAStandards.phoneNumber(value)
    },
    address: {
      required: true,
      minLength: 5,
      maxLength: 500
    },
    notes: {
      maxLength: 1000
    }
  };

  const {
    values,
    errors,
    touched,
    isValid,
    isSubmitting,
    setValue,
    setFieldTouched,
    handleSubmit,
    reset
  } = useFormValidation({
    initialValues,
    validationRules,
    onSubmit: async (formValues) => {
      try {
        await onSubmit({
          ...formValues,
          lastPurchase: customer?.lastPurchase
        });
        toast.success(customer ? 'Customer updated successfully' : 'Customer created successfully');
      } catch (error) {
        toast.error('Failed to save customer');
        throw error;
      }
    }
  });

  // Reset form when customer changes
  useEffect(() => {
    reset(initialValues);
  }, [customer]);

  const handleChange = (field: string, value: string) => {
    setValue(field, value);
  };

  const handleBlur = (field: string) => {
    setFieldTouched(field, true);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 lg:space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-sm font-medium">Name *</Label>
          <Input
            id="name"
            value={values.name}
            onChange={(e) => handleChange('name', e.target.value)}
            onBlur={() => handleBlur('name')}
            placeholder="Enter customer name"
            className={`h-11 ${touched.name && errors.name ? 'border-red-500' : ''}`}
            disabled={isLoading} />

          {touched.name && errors.name && <p className="text-sm text-red-500">{errors.name}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="email" className="text-sm font-medium">Email *</Label>
          <Input
            id="email"
            type="email"
            value={values.email}
            onChange={(e) => handleChange('email', e.target.value)}
            onBlur={() => handleBlur('email')}
            placeholder="Enter email address"
            className={`h-11 ${touched.email && errors.email ? 'border-red-500' : ''}`}
            disabled={isLoading} />

          {touched.email && errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone" className="text-sm font-medium">Phone *</Label>
          <Input
            id="phone"
            value={values.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            onBlur={() => handleBlur('phone')}
            placeholder="(555) 123-4567"
            className={`h-11 ${touched.phone && errors.phone ? 'border-red-500' : ''}`}
            disabled={isLoading} />

          {touched.phone && errors.phone && <p className="text-sm text-red-500">{errors.phone}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="status" className="text-sm font-medium">Status</Label>
          <Select value={values.status} onValueChange={(value) => handleChange('status', value)} disabled={isLoading}>
            <SelectTrigger className="h-11">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="address" className="text-sm font-medium">Address *</Label>
        <Input
          id="address"
          value={values.address}
          onChange={(e) => handleChange('address', e.target.value)}
          onBlur={() => handleBlur('address')}
          placeholder="Enter full address"
          className={`h-11 ${touched.address && errors.address ? 'border-red-500' : ''}`}
          disabled={isLoading} />

        {touched.address && errors.address && <p className="text-sm text-red-500">{errors.address}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes" className="text-sm font-medium">Notes</Label>
        <Textarea
          id="notes"
          value={values.notes}
          onChange={(e) => handleChange('notes', e.target.value)}
          onBlur={() => handleBlur('notes')}
          placeholder="Additional notes about the customer"
          rows={3}
          className={`resize-none ${touched.notes && errors.notes ? 'border-red-500' : ''}`}
          disabled={isLoading} />

        {touched.notes && errors.notes && <p className="text-sm text-red-500">{errors.notes}</p>}
      </div>

      <div className="flex flex-col-reverse sm:flex-row gap-3 justify-end pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={isLoading || isSubmitting}
          className="h-11 touch-manipulation">
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={isLoading || isSubmitting || !isValid}
          className="h-11 touch-manipulation">
          {isLoading || isSubmitting ? 'Saving...' : customer ? 'Update Customer' : 'Add Customer'}
        </Button>
      </div>
    </form>);

};

export default CustomerForm;