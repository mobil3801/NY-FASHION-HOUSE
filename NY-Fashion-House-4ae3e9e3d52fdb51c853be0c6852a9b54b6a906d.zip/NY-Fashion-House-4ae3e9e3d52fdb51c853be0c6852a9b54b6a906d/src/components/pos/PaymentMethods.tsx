
import { useState } from 'react';
import { CreditCard, Smartphone, Wallet, Banknote } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { PaymentMethod, PaymentDetails } from '@/types/sales';
import { formatUSD as formatCurrency } from '@/utils/currencyUtils';

interface PaymentMethodsProps {
  selectedMethod: PaymentMethod | null;
  onMethodSelect: (method: PaymentMethod) => void;
  paymentDetails: PaymentDetails;
  onDetailsChange: (details: PaymentDetails) => void;
  totalAmount: number;
}

const paymentMethods: PaymentMethod[] = [
{ type: 'cash', label: 'Cash' },
{ type: 'card', label: 'Credit/Debit Card' },
{ type: 'mobile-banking', label: 'Mobile Payment' },
{ type: 'digital-wallet', label: 'Digital Wallet' }];


const mobileProviders = [
'Apple Pay', 'Google Pay', 'Samsung Pay', 'Venmo', 'Cash App', 'Zelle'];


const walletProviders = [
'PayPal', 'Apple Pay', 'Google Pay', 'Samsung Pay', 'Venmo', 'Cash App'];


const PaymentMethods: React.FC<PaymentMethodsProps> = ({
  selectedMethod,
  onMethodSelect,
  paymentDetails,
  onDetailsChange,
  totalAmount
}) => {
  const { t } = useTranslation();

  const renderPaymentMethodIcon = (type: PaymentMethod['type']) => {
    switch (type) {
      case 'cash':
        return <Banknote className="h-5 w-5" />;
      case 'card':
        return <CreditCard className="h-5 w-5" />;
      case 'mobile-banking':
        return <Smartphone className="h-5 w-5" />;
      case 'digital-wallet':
        return <Wallet className="h-5 w-5" />;
      default:
        return <CreditCard className="h-5 w-5" />;
    }
  };

  const renderPaymentDetails = () => {
    if (!selectedMethod) return null;

    switch (selectedMethod.type) {
      case 'cash':
        return (
          <div className="space-y-3">
            <div>
              <Label htmlFor="cashReceived">{t('payment.cash_received')}</Label>
              <Input
                id="cashReceived"
                type="number"
                min={totalAmount}
                step="0.01"
                value={paymentDetails.cashReceived || ''}
                onChange={(e) => {
                  const received = parseFloat(e.target.value) || 0;
                  const change = Math.max(0, received - totalAmount);
                  onDetailsChange({
                    ...paymentDetails,
                    cashReceived: received,
                    changeGiven: change
                  });
                }}
                placeholder={`Minimum: ${formatCurrency(totalAmount)}`}
                className="text-lg font-mono" />

            </div>
            
            {paymentDetails.cashReceived && paymentDetails.cashReceived >= totalAmount &&
            <div className="p-3 bg-green-50 rounded-md">
                <div className="flex justify-between items-center">
                  <span className="font-medium">{t('payment.change')}</span>
                  <span className="text-lg font-semibold text-green-600">
                    {formatCurrency(paymentDetails.changeGiven || 0)}
                  </span>
                </div>
              </div>
            }
          </div>);


      case 'card':
        return (
          <div className="space-y-3">
            <div>
              <Label htmlFor="cardNumber">{t('payment.card_number')}</Label>
              <Input
                id="cardNumber"
                type="text"
                placeholder="**** **** **** 1234"
                value={paymentDetails.cardLastFour || ''}
                onChange={(e) => onDetailsChange({
                  ...paymentDetails,
                  cardLastFour: e.target.value.slice(-4)
                })}
                maxLength={19}
                className="font-mono" />

            </div>
            
            <div>
              <Label htmlFor="cardType">Card Type</Label>
              <Select
                value={paymentDetails.cardType || ''}
                onValueChange={(value) => onDetailsChange({
                  ...paymentDetails,
                  cardType: value
                })}>

                <SelectTrigger>
                  <SelectValue placeholder="Select card type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="visa">Visa</SelectItem>
                  <SelectItem value="mastercard">Mastercard</SelectItem>
                  <SelectItem value="american-express">American Express</SelectItem>
                  <SelectItem value="discover">Discover</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="transactionId">{t('payment.transaction_id')}</Label>
              <Input
                id="transactionId"
                type="text"
                value={paymentDetails.transactionId || ''}
                onChange={(e) => onDetailsChange({
                  ...paymentDetails,
                  transactionId: e.target.value
                })}
                placeholder="Authorization Code" />

            </div>
          </div>);


      case 'mobile-banking':
        return (
          <div className="space-y-3">
            <div>
              <Label>Mobile Payment Provider</Label>
              <Select
                value={paymentDetails.mobileProvider || ''}
                onValueChange={(value) => onDetailsChange({
                  ...paymentDetails,
                  mobileProvider: value
                })}>

                <SelectTrigger>
                  <SelectValue placeholder="Select provider" />
                </SelectTrigger>
                <SelectContent>
                  {mobileProviders.map((provider) =>
                  <SelectItem key={provider} value={provider}>{provider}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="mobileNumber">{t('payment.mobile_number')}</Label>
              <Input
                id="mobileNumber"
                type="tel"
                value={paymentDetails.mobileNumber || ''}
                onChange={(e) => onDetailsChange({
                  ...paymentDetails,
                  mobileNumber: e.target.value
                })}
                placeholder="(555) 123-4567" />

            </div>
            
            <div>
              <Label htmlFor="transactionId">{t('payment.transaction_id')}</Label>
              <Input
                id="transactionId"
                type="text"
                value={paymentDetails.transactionId || ''}
                onChange={(e) => onDetailsChange({
                  ...paymentDetails,
                  transactionId: e.target.value
                })}
                placeholder="Transaction reference" />

            </div>
          </div>);


      case 'digital-wallet':
        return (
          <div className="space-y-3">
            <div>
              <Label>Wallet Provider</Label>
              <Select
                value={paymentDetails.digitalWalletProvider || ''}
                onValueChange={(value) => onDetailsChange({
                  ...paymentDetails,
                  digitalWalletProvider: value
                })}>

                <SelectTrigger>
                  <SelectValue placeholder="Select wallet" />
                </SelectTrigger>
                <SelectContent>
                  {walletProviders.map((provider) =>
                  <SelectItem key={provider} value={provider}>{provider}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="walletId">Wallet ID</Label>
              <Input
                id="walletId"
                type="text"
                value={paymentDetails.digitalWalletId || ''}
                onChange={(e) => onDetailsChange({
                  ...paymentDetails,
                  digitalWalletId: e.target.value
                })}
                placeholder="Wallet account ID" />

            </div>
            
            <div>
              <Label htmlFor="transactionId">{t('payment.transaction_id')}</Label>
              <Input
                id="transactionId"
                type="text"
                value={paymentDetails.transactionId || ''}
                onChange={(e) => onDetailsChange({
                  ...paymentDetails,
                  transactionId: e.target.value
                })}
                placeholder="Transaction reference" />

            </div>
          </div>);


      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      <Label className="text-base font-semibold">{t('pos.payment.method')}</Label>
      
      {/* Payment Method Selection */}
      <div className="grid grid-cols-2 gap-3">
        {paymentMethods.map((method) =>
        <Button
          key={method.type}
          variant={selectedMethod?.type === method.type ? 'default' : 'outline'}
          onClick={() => onMethodSelect(method)}
          className="h-16 flex flex-col gap-2">

            {renderPaymentMethodIcon(method.type)}
            <span className="text-sm">{method.label}</span>
          </Button>
        )}
      </div>

      {/* Payment Details Form */}
      {selectedMethod &&
      <Card className="p-4">
          <h4 className="font-medium mb-3">Payment Details</h4>
          {renderPaymentDetails()}
        </Card>
      }

      {/* Amount Display */}
      <div className="p-4 bg-gray-50 rounded-lg">
        <div className="flex justify-between items-center">
          <span className="text-lg font-medium">Amount to Pay:</span>
          <span className="text-2xl font-bold text-green-600">
            {formatCurrency(totalAmount)}
          </span>
        </div>
      </div>
    </div>);

};

export default PaymentMethods;