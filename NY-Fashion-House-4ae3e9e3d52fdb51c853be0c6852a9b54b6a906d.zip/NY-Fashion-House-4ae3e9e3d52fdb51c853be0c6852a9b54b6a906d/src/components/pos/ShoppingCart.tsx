
import { useState, useEffect } from 'react';
import { Minus, Plus, Trash2, ShoppingCart as CartIcon } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { CartItem } from '@/types/sales';
import { formatUSD } from '@/utils/currencyUtils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface ShoppingCartProps {
  items: CartItem[];
  onUpdateQuantity: (itemId: string, quantity: number) => void;
  onRemoveItem: (itemId: string) => void;
  onUpdateVariant: (itemId: string, size?: string, color?: string) => void;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  onDiscountChange: (discount: number) => void;
}

const ShoppingCart: React.FC<ShoppingCartProps> = ({
  items,
  onUpdateQuantity,
  onRemoveItem,
  onUpdateVariant,
  subtotal,
  discount,
  tax,
  total,
  onDiscountChange
}) => {
  const { t } = useTranslation();
  const [discountPercentage, setDiscountPercentage] = useState(0);

  const handleDiscountChange = (value: string) => {
    const percentage = parseFloat(value) || 0;
    setDiscountPercentage(percentage);
    onDiscountChange(percentage);
  };

  if (items.length === 0) {
    return (
      <Card className="p-6 sm:p-8 text-center">
        <CartIcon className="mx-auto h-12 w-12 sm:h-16 sm:w-16 text-gray-300 mb-4" />
        <p className="text-gray-500 text-base sm:text-lg">{t('pos.cart.empty')}</p>
      </Card>);

  }

  return (
    <div className="space-y-4">
      {/* Cart Items */}
      <div className="space-y-3 max-h-60 sm:max-h-80 lg:max-h-96 overflow-y-auto scrollbar-hide">
        {items.map((item) =>
        <Card key={item.id} className="p-3 sm:p-4">
            <div className="flex gap-3 sm:gap-4">
              {/* Product Image */}
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gray-100 rounded-md overflow-hidden flex-shrink-0">
                {item.product.images?.length > 0 ?
              <img
                src={item.product.images[0]}
                alt={item.productName}
                className="w-full h-full object-cover"
                loading="lazy" /> :


              <div className="w-full h-full flex items-center justify-center">
                    <CartIcon className="h-4 w-4 sm:h-6 sm:w-6 text-gray-400" />
                  </div>
              }
              </div>

              {/* Product Details */}
              <div className="flex-1 space-y-2 min-w-0">
                <div className="flex justify-between items-start">
                  <div className="min-w-0 flex-1 mr-2">
                    <h3 className="font-medium text-sm truncate">{item.productName}</h3>
                    <p className="text-xs text-gray-500 truncate">{item.productSku}</p>
                  </div>
                  <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onRemoveItem(item.id)}
                  className="text-red-500 hover:text-red-700 h-8 w-8 p-0 touch-manipulation flex-shrink-0"
                  aria-label={t('Remove item')}>

                    <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                  </Button>
                </div>

                {/* Variants */}
                <div className="flex gap-2 overflow-x-auto scrollbar-hide">
                  {item.product.sizes && item.product.sizes.length > 1 &&
                <Select
                  value={item.size || ''}
                  onValueChange={(value) => onUpdateVariant(item.id, value, item.color)}>

                      <SelectTrigger className="w-16 sm:w-20 h-7 text-xs flex-shrink-0">
                        <SelectValue placeholder="Size" />
                      </SelectTrigger>
                      <SelectContent>
                        {item.product.sizes.map((size) =>
                    <SelectItem key={size} value={size}>{size}</SelectItem>
                    )}
                      </SelectContent>
                    </Select>
                }

                  {item.product.colors && item.product.colors.length > 1 &&
                <Select
                  value={item.color || ''}
                  onValueChange={(value) => onUpdateVariant(item.id, item.size, value)}>

                      <SelectTrigger className="w-16 sm:w-20 h-7 text-xs flex-shrink-0">
                        <SelectValue placeholder="Color" />
                      </SelectTrigger>
                      <SelectContent>
                        {item.product.colors.map((color) =>
                    <SelectItem key={color} value={color}>{color}</SelectItem>
                    )}
                      </SelectContent>
                    </Select>
                }
                </div>

                {/* Quantity and Price */}
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                    className="h-8 w-8 p-0 touch-manipulation"
                    aria-label={t('Decrease quantity')}>

                      <Minus className="h-3 w-3" />
                    </Button>
                    
                    <Input
                    type="number"
                    min="1"
                    max={item.product.stockLevel}
                    value={item.quantity}
                    onChange={(e) => onUpdateQuantity(item.id, Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-12 sm:w-16 h-8 text-center text-sm"
                    aria-label={t('Quantity')} />

                    
                    <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onUpdateQuantity(item.id, Math.min(item.product.stockLevel, item.quantity + 1))}
                    className="h-8 w-8 p-0 touch-manipulation"
                    disabled={item.quantity >= item.product.stockLevel}
                    aria-label={t('Increase quantity')}>

                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>

                  <div className="text-right flex-shrink-0 ml-2">
                    <p className="font-semibold text-green-600 text-sm">{formatUSD(item.total)}</p>
                    <p className="text-xs text-gray-500">{formatUSD(item.sellingPrice)} each</p>
                  </div>
                </div>

                {/* Stock Warning */}
                {item.quantity > item.product.stockLevel &&
              <Badge variant="destructive" className="text-xs">
                    {t('message.insufficient_stock')}
                  </Badge>
              }
              </div>
            </div>
          </Card>
        )}
      </div>

      <Separator />

      {/* Discount Input */}
      <div className="flex items-center justify-between gap-2">
        <label className="text-sm font-medium flex-shrink-0">{t('pos.cart.discount')} (%)</label>
        <Input
          type="number"
          min="0"
          max="100"
          step="0.1"
          value={discountPercentage}
          onChange={(e) => handleDiscountChange(e.target.value)}
          className="w-20 sm:w-24 h-8 text-right text-sm"
          placeholder="0"
          aria-label={t('Discount percentage')} />

      </div>

      {/* Cart Summary */}
      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span>{t('pos.cart.subtotal')}</span>
          <span>{formatUSD(subtotal)}</span>
        </div>
        
        {discount > 0 &&
        <div className="flex justify-between text-red-600">
            <span>{t('pos.cart.discount')} ({discountPercentage}%)</span>
            <span>-{formatUSD(discount)}</span>
          </div>
        }
        
        <div className="flex justify-between">
          <span>{t('pos.cart.tax')} (8.875%)</span>
          <span>{formatUSD(tax)}</span>
        </div>
        
        <Separator />
        
        <div className="flex justify-between text-base sm:text-lg font-semibold text-green-600">
          <span>{t('pos.cart.total')}</span>
          <span>{formatUSD(total)}</span>
        </div>
      </div>
    </div>);

};

export default ShoppingCart;