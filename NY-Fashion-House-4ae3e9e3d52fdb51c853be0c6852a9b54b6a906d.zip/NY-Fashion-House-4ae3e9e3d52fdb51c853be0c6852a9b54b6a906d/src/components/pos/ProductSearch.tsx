
import { useState, useEffect } from 'react';
import { Search, Package, Barcode, AlertTriangle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Product } from '@/types/product';
import { productService } from '@/services/productService';
import { useQuery } from '@tanstack/react-query';
import { formatUSD } from '@/utils/currencyUtils';
import ProductThumbnail from '@/components/ProductThumbnail';
import { toast } from 'sonner';

interface ProductSearchProps {
  onProductSelect: (product: Product) => void;
}

const ProductSearch: React.FC<ProductSearchProps> = ({ onProductSelect }) => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [showLowStock, setShowLowStock] = useState(false);

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['pos-products', debouncedSearchTerm, showLowStock],
    queryFn: () => productService.getAllProducts({
      query: debouncedSearchTerm,
      inStock: showLowStock ? undefined : true,
      lowStock: showLowStock,
      sortBy: 'name',
      sortOrder: 'asc'
    }),
    enabled: true
  });

  // Low stock products query
  const { data: lowStockProducts = [], isLoading: isLoadingLowStock } = useQuery({
    queryKey: ['low-stock-products'],
    queryFn: () => productService.getAllProducts({
      lowStock: true,
      sortBy: 'stock',
      sortOrder: 'asc'
    }),
    enabled: showLowStock
  });

  const handleBarcodeClick = async () => {
    try {
      // In a real app, this would open camera for barcode scanning
      const barcode = prompt('Enter or scan barcode:');
      if (!barcode) return;

      // Validate barcode format
      const validation = productService.validateBarcode(barcode);
      if (!validation.isValid) {
        toast.error(validation.error || 'Invalid barcode format');
        return;
      }

      // Search for product by barcode
      try {
        const product = await productService.searchProductByBarcode(barcode);
        if (product) {
          // Add product directly to selection
          handleProductSelect(product);
          setSearchTerm(''); // Clear search to show the found product
        } else {
          // If no product found, set search term to barcode for manual search
          setSearchTerm(barcode);
          toast.info('No product found with this barcode. Showing search results...');
        }
      } catch (searchError) {
        console.error('Barcode search error:', searchError);
        // Fallback to regular search
        setSearchTerm(barcode);
        toast.warning('Barcode search failed. Showing text search results...');
      }
    } catch (error) {
      console.error('Barcode scan error:', error);
      toast.error('Failed to process barcode. Please try entering it manually.');
    }
  };

  // Function to check if product can be added to cart
  const canAddToCart = (product: Product): boolean => {
    return product.isActive && product.stockLevel > 0;
  };

  // Enhanced product select with validation
  const handleProductSelect = (product: Product) => {
    if (!canAddToCart(product)) {
      if (product.stockLevel <= 0) {
        toast.error(`${product.name} is out of stock`);
      } else if (!product.isActive) {
        toast.error(`${product.name} is not available`);
      }
      return;
    }
    onProductSelect(product);
    toast.success(`${product.name} added to cart`);
  };

  return (
    <div className="space-y-4">
      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          type="text"
          placeholder="Search Products"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 pr-12 h-12 text-lg" />

        <Button
          variant="ghost"
          size="sm"
          onClick={handleBarcodeClick}
          className="absolute right-2 top-1/2 transform -translate-y-1/2">

          <Barcode className="h-5 w-5" />
        </Button>
      </div>

      {/* Search Options */}
      <div className="flex gap-2">
        <Button
          variant={showLowStock ? "default" : "outline"}
          size="sm"
          onClick={() => setShowLowStock(!showLowStock)}
          className="flex items-center gap-2">

          <AlertTriangle className="h-4 w-4" />
          Low Stock
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setSearchTerm('');
            setShowLowStock(false);
          }}>

          Clear
        </Button>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 max-h-96 overflow-y-auto">
        {isLoading ?
        Array.from({ length: 8 }).map((_, i) =>
        <Card key={i} className="p-4 animate-pulse">
              <div className="w-full h-32 bg-gray-200 rounded mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded"></div>
            </Card>
        ) :
        products.length === 0 && debouncedSearchTerm ?
        <div className="col-span-full text-center py-8 text-gray-500">
            <Package className="mx-auto h-12 w-12 mb-4" />
            <p>No products found</p>
          </div> :

        products.map((product) => {
          const addToCartAvailable = canAddToCart(product);
          return (
            <Card
              key={product.id}
              className={`p-4 cursor-pointer hover:shadow-md transition-shadow ${
              !addToCartAvailable ? 'opacity-60 cursor-not-allowed' : ''}`
              }
              onClick={() => handleProductSelect(product)}>

              <div className="aspect-square mb-3 overflow-hidden rounded-md bg-gray-100">
                <ProductThumbnail
                  imageIds={product.imageIds}
                  altText={product.name}
                  size="lg"
                  className="w-full h-full" />

              </div>
              
              <div className="space-y-2">
                <h3 className="font-medium text-sm line-clamp-2">{product.name}</h3>
                <p className="text-xs text-gray-500">{product.sku}</p>
                
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-green-600">
                    {formatUSD(product.sellingPrice)}
                  </span>
                  <Badge
                    variant={
                    product.stockLevel <= 0 ?
                    'destructive' :
                    product.stockLevel <= product.minStockLevel ?
                    'secondary' :
                    'default'
                    }>

                    {product.stockLevel} {t('product.stock')}
                  </Badge>
                </div>
                
                <div className="flex flex-wrap gap-1">
                  {product.stockLevel <= 0 &&
                  <Badge variant="destructive" className="w-full justify-center text-xs">
                      {t('product.out_of_stock')}
                    </Badge>
                  }
                  {product.stockLevel > 0 && product.stockLevel <= product.minStockLevel &&
                  <Badge variant="secondary" className="w-full justify-center text-xs">
                      Low Stock
                    </Badge>
                  }
                  {addToCartAvailable &&
                  <Badge variant="default" className="w-full justify-center text-xs bg-green-600">
                      Add to Cart Available
                    </Badge>
                  }
                </div>
              </div>
            </Card>);

        })
        }
      </div>
    </div>);

};

export default ProductSearch;