
import { useState } from 'react';
import { User, Plus, Search } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Customer } from '@/types/customer';
import * as customerService from '@/services/customerService';
import { useQuery } from '@tanstack/react-query';
// import { toast } from 'sonner'; // Removed error notifications

interface CustomerSelectorProps {
  selectedCustomer: Customer | null;
  onCustomerSelect: (customer: Customer | null) => void;
}

const CustomerSelector: React.FC<CustomerSelectorProps> = ({
  selectedCustomer,
  onCustomerSelect
}) => {
  const { t } = useTranslation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Quick add form state
  const [quickAddForm, setQuickAddForm] = useState({
    name: '',
    phone: '',
    email: ''
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => customerService.getCustomers()
  });

  const filteredCustomers = customers.filter((customer) =>
  customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
  customer.phone.includes(searchTerm) ||
  customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleQuickAdd = async () => {
    if (!quickAddForm.name || !quickAddForm.phone) {
      // Silently prevent adding if required fields missing
      return;
    }

    try {
      const newCustomer = await customerService.createCustomer({
        name: quickAddForm.name,
        phone: quickAddForm.phone,
        email: quickAddForm.email,
        address: '',
        status: 'active'
      });

      onCustomerSelect(newCustomer);
      setIsQuickAddOpen(false);
      setQuickAddForm({ name: '', phone: '', email: '' });
      // Silently handle success - no notification
    } catch (error) {




























































      // Silently handle error - no notification
    }};return <div className="space-y-2">
      <Label className="text-sm font-medium">Customer Name</Label>
      
      <div className="flex gap-2">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="flex-1 justify-start">
              <User className="h-4 w-4 mr-2" />
              {selectedCustomer ? selectedCustomer.name : t('pos.customer.none')}
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{t('pos.customer.select')}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input placeholder="Search customers..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />

              </div>

              {/* No Customer Option */}
              <Button variant="ghost" onClick={() => {onCustomerSelect(null);setIsDialogOpen(false);}} className="w-full justify-start">

                {t('pos.customer.none')}
              </Button>

              {/* Customer List */}
              <div className="max-h-64 overflow-y-auto space-y-1">
                {filteredCustomers.map((customer) => <Button key={customer.id} variant="ghost" onClick={() => {onCustomerSelect(customer);setIsDialogOpen(false);}} className="w-full justify-start p-3">

                    <div className="text-left">
                      <p className="font-medium">{customer.name}</p>
                      <p className="text-sm text-gray-500">{customer.phone}</p>
                    </div>
                  </Button>)}
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={isQuickAddOpen} onOpenChange={setIsQuickAddOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{t('pos.customer.quick_add')}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">{t('common.name')} *</Label>
                <Input id="name" value={quickAddForm.name} onChange={(e) => setQuickAddForm((prev) => ({ ...prev, name: e.target.value }))} placeholder="Customer name" />

              </div>
              
              <div>
                <Label htmlFor="phone">{t('common.phone')} *</Label>
                <Input id="phone" value={quickAddForm.phone} onChange={(e) => setQuickAddForm((prev) => ({ ...prev, phone: e.target.value }))} placeholder="Phone number" />

              </div>
              
              <div>
                <Label htmlFor="email">{t('common.email')}</Label>
                <Input id="email" type="email" value={quickAddForm.email} onChange={(e) => setQuickAddForm((prev) => ({ ...prev, email: e.target.value }))} placeholder="Email address (optional)" />

              </div>
              
              <div className="flex gap-2">
                <Button onClick={handleQuickAdd} className="flex-1">
                  {t('common.add')}
                </Button>
                <Button variant="outline" onClick={() => setIsQuickAddOpen(false)} className="flex-1">

                  {t('common.cancel')}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>;};export default CustomerSelector;