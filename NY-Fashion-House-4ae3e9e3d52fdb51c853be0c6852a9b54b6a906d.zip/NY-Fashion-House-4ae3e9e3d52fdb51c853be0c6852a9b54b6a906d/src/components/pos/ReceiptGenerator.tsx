
import { Printer, Download, Eye } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Sale } from '@/types/sales';

interface ReceiptGeneratorProps {
  sale: Sale;
  onPrint?: () => void;
  onDownload?: () => void;
}

const ReceiptGenerator: React.FC<ReceiptGeneratorProps> = ({
  sale,
  onPrint,
  onDownload
}) => {
  const { t } = useTranslation();

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>Receipt - ${sale.receiptNumber}</title>
          <style>
            body { font-family: 'Courier New', monospace; font-size: 12px; margin: 0; padding: 20px; }
            .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 10px; }
            .store-name { font-size: 18px; font-weight: bold; }
            .receipt-info { margin: 10px 0; }
            .items-table { width: 100%; border-collapse: collapse; margin: 10px 0; }
            .items-table th, .items-table td { text-align: left; padding: 5px 0; }
            .items-table th { border-bottom: 1px solid #000; }
            .totals { margin-top: 10px; padding-top: 10px; border-top: 1px solid #000; }
            .total-line { display: flex; justify-content: space-between; margin: 5px 0; }
            .grand-total { font-weight: bold; font-size: 14px; }
            .footer { text-align: center; margin-top: 20px; padding-top: 10px; border-top: 1px solid #000; }
          </style>
        </head>
        <body>
          ${generateReceiptHTML(sale)}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
      printWindow.close();
    }, 250);

    onPrint?.();
  };

  const handleDownload = () => {
    const receiptData = generateReceiptHTML(sale);
    const blob = new Blob([receiptData], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt-${sale.receiptNumber}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onDownload?.();
  };

  const generateReceiptHTML = (sale: Sale) => {
    return `
      <div class="header">
        <div class="store-name">NY FASHION HOUSE</div>
        <div>72-30 Broadway 2nd floor</div>
        <div>Jackson Heights, NY 11372</div>
        <div>Phone: +1 (646) 744-5934</div>
      </div>

      <div class="receipt-info">
        <div><strong>Receipt No:</strong> ${sale.receiptNumber}</div>
        <div><strong>Date:</strong> ${sale.createdAt.toLocaleString()}</div>
        <div><strong>Cashier:</strong> ${sale.cashierId}</div>
        ${sale.customerName ? `<div><strong>Customer:</strong> ${sale.customerName}</div>` : ''}
        ${sale.customerPhone ? `<div><strong>Phone:</strong> ${sale.customerPhone}</div>` : ''}
      </div>

      <table class="items-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          ${sale.items.map((item) => `
            <tr>
              <td>
                ${item.productName}<br>
                <small>${item.productSku}${item.size ? ` - ${item.size}` : ''}${item.color ? ` - ${item.color}` : ''}</small>
              </td>
              <td>${item.quantity}</td>
              <td>$${item.sellingPrice.toFixed(2)}</td>
              <td>$${item.total.toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <div class="totals">
        <div class="total-line">
          <span>Subtotal:</span>
          <span>$${sale.subtotal.toFixed(2)}</span>
        </div>
        ${sale.discountAmount > 0 ? `
          <div class="total-line">
            <span>Discount (${sale.discountPercentage}%):</span>
            <span>-$${sale.discountAmount.toFixed(2)}</span>
          </div>
        ` : ''}
        <div class="total-line">
          <span>Tax (${sale.taxPercentage}%):</span>
          <span>$${sale.taxAmount.toFixed(2)}</span>
        </div>
        <div class="total-line grand-total">
          <span>TOTAL:</span>
          <span>$${sale.totalAmount.toFixed(2)}</span>
        </div>
      </div>

      <div class="receipt-info">
        <div><strong>Payment Method:</strong> ${sale.paymentMethod.label}</div>
        ${sale.paymentDetails?.cashReceived ? `
          <div><strong>Cash Received:</strong> $${sale.paymentDetails.cashReceived.toFixed(2)}</div>
          <div><strong>Change:</strong> $${(sale.paymentDetails.changeGiven || 0).toFixed(2)}</div>
        ` : ''}
        ${sale.paymentDetails?.transactionId ? `
          <div><strong>Transaction ID:</strong> ${sale.paymentDetails.transactionId}</div>
        ` : ''}
      </div>

      <div class="footer">
        <div>Thank you for shopping with us!</div>
        <div>Please keep this receipt for your records</div>
        <div>*** NO REFUND WITHOUT RECEIPT ***</div>
      </div>
    `;
  };

  return (
    <div className="flex gap-3">
      <Button onClick={handlePrint} className="flex-1">
        <Printer className="h-4 w-4 mr-2" />
        {t('pos.receipt.print')}
      </Button>

      <Button variant="outline" onClick={handleDownload}>
        <Download className="h-4 w-4 mr-2" />
        Download
      </Button>

      <Dialog>
        <DialogTrigger asChild>
          <Button variant="outline" size="icon">
            <Eye className="h-4 w-4" />
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Receipt Preview - {sale.receiptNumber}</DialogTitle>
          </DialogHeader>
          <div
            className="font-mono text-sm border rounded p-4 bg-white"
            dangerouslySetInnerHTML={{ __html: generateReceiptHTML(sale) }} />
        </DialogContent>
      </Dialog>
    </div>);
};

export default ReceiptGenerator;