
import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  Home,
  Users,
  Package,
  ShoppingCart,
  UserCheck,
  DollarSign,
  Calculator,
  BarChart3,
  Settings,
  User,
  LogOut,
  X,
  Shield,
  Database,
  TestTube,
  Building2,
  Bug } from
'lucide-react';
import { Button } from '@/components/ui/button';
import ThemeToggle from '@/components/ThemeToggle';

const baseNavigation = [
{ name: 'Dashboard', href: '/', icon: Home },
{ name: 'Customers', href: '/customers', icon: Users },
{ name: 'Products', href: '/products', icon: Package },
{ name: 'Point of Sale', href: '/pos', icon: ShoppingCart },
{ name: 'Invoice & Sale Record', href: '/transaction-management', icon: DollarSign },
{ name: 'Supplier List', href: '/suppliers', icon: Building2 },
{ name: 'Employees', href: '/employees', icon: UserCheck },
{ name: 'Salary Management', href: '/salary', icon: DollarSign },
{ name: 'Accounting', href: '/accounting', icon: Calculator },
{ name: 'Reports', href: '/reports', icon: BarChart3 },
{ name: 'Backup Management', href: '/backup-management', icon: Shield },
{ name: 'Data Management', href: '/data-management', icon: Database },
{ name: 'Error Management', href: '/error-management', icon: Bug },
{ name: 'Settings', href: '/system-settings', icon: Settings }];

const devOnlyNavigation = [
{ name: 'QA Testing', href: '/qa-dashboard', icon: TestTube },
{ name: 'Performance Testing', href: '/performance-testing', icon: TestTube },
{ name: 'Error Dashboard', href: '/error-dashboard', icon: Bug },
{ name: 'Error Testing', href: '/error-testing', icon: Bug },
{ name: 'Error Management', href: '/comprehensive-error-management', icon: Shield },
{ name: 'Final Error Management', href: '/finalized-error-management', icon: Shield }];


// Show QA and Performance testing items only in development/testing environments
const navigation = import.meta.env.PROD ?
baseNavigation :
[...baseNavigation.slice(0, 9), ...devOnlyNavigation, ...baseNavigation.slice(9)];


interface NavigationMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const NavigationMenu: React.FC<NavigationMenuProps> = ({ isOpen, onClose }) => {
  const location = useLocation();
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.body.style.overflow = 'hidden'; // Prevent background scroll
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  // Close menu on escape key
  useEffect(() => {
    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscapeKey);
    }

    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isOpen, onClose]);

  return (
    <>
      {/* Backdrop overlay */}
      <div
        className={cn(
          'fixed inset-0 bg-black/50 z-50 transition-opacity duration-300',
          isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        )}
        onClick={onClose} />


      {/* Navigation Menu - Slides from LEFT */}
      <div
        ref={menuRef}
        className={cn(
          'fixed top-0 left-0 h-full w-80 max-w-[85vw] shadow-2xl z-50 transition-colors duration-300',
          'transform transition-all duration-300 ease-in-out',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
        style={{
          backgroundColor: 'var(--theme-card)',
          borderRight: '1px solid var(--theme-border)'
        }}>

        {/* Header */}
        <div className="flex items-center justify-between p-6 transition-colors duration-300" style={{
          borderBottom: '1px solid var(--theme-border)',
          backgroundColor: 'var(--theme-card)'
        }}>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-[4px] overflow-hidden flex items-center justify-center">
              <img
                src="https://cdn.ezsite.ai/AutoDev/19016/95c2a8a3-4455-4cc1-91c1-442a3cf63926.jpeg"
                alt="NY Fashion House Logo"
                className="w-full h-full object-cover rounded-[4px]" />

            </div>
            <div>
              <h2 className="text-lg font-bold" style={{ color: 'var(--theme-text)' }}>NY FASHION HOUSE</h2>
              <p className="text-sm" style={{ color: 'var(--theme-muted-foreground)' }}>Navigation Menu</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 rounded-full transition-colors duration-300">

              <X className="h-4 w-4" style={{ color: 'var(--theme-text)' }} />
            </Button>
          </div>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-4">
            {navigation.map((item, index) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={onClose}
                  className={cn(
                    'group flex items-center rounded-lg px-4 py-3 text-sm font-medium transition-all duration-300',
                    'transform hover:scale-105 hover:shadow-md',
                    isActive ?
                    'shadow-lg' :
                    'transition-colors duration-300'
                  )}
                  style={{
                    animationDelay: isOpen ? `${index * 50}ms` : '0ms',
                    backgroundColor: isActive ? 'var(--theme-primary)' : 'transparent',
                    color: isActive ? 'var(--theme-background)' : 'var(--theme-text)'
                  }}>

                  <item.icon
                    className={cn(
                      'mr-3 h-5 w-5 flex-shrink-0 transition-colors',
                      isActive ? '' : 'opacity-70 group-hover:opacity-100'
                    )}
                    style={{
                      color: isActive ? 'var(--theme-background)' : 'var(--theme-text)'
                    }} />

                  <span className="truncate">{item.name}</span>
                  {isActive &&
                  <div className="ml-auto w-2 h-2 rounded-full animate-pulse" style={{
                    backgroundColor: 'var(--theme-background)'
                  }} />
                  }
                </Link>);

            })}
          </nav>

          {/* Divider */}
          <div className="mx-4 my-6 border-t" style={{ borderColor: 'var(--theme-border)' }} />

          {/* User Actions */}
          <div className="space-y-1 px-4">
            <button className="group flex items-center rounded-lg px-4 py-3 text-sm font-medium transition-colors duration-300 w-full" style={{
              color: 'var(--theme-text)'
            }}>
              <User className="mr-3 h-5 w-5 opacity-70 group-hover:opacity-100" />
              <span>Profile</span>
            </button>
            <button className="group flex items-center rounded-lg px-4 py-3 text-sm font-medium transition-colors duration-300 w-full" style={{
              color: 'var(--theme-text)'
            }}>
              <Settings className="mr-3 h-5 w-5 opacity-70 group-hover:opacity-100" />
              <span>Settings</span>
            </button>
            <button className="group flex items-center rounded-lg px-4 py-3 text-sm font-medium transition-colors duration-300 w-full" style={{
              color: 'var(--theme-primary)'
            }}>
              <LogOut className="mr-3 h-5 w-5" />
              <span>Log Out</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 transition-colors duration-300" style={{
          borderTop: '1px solid var(--theme-border)',
          backgroundColor: 'var(--theme-muted)'
        }}>
          <div className="text-center">
            <p className="text-xs" style={{ color: 'var(--theme-muted-foreground)' }}>
              © 2024 Business Manager
            </p>
            <p className="text-xs mt-1" style={{ color: 'var(--theme-muted-foreground)' }}>
              Management System
            </p>
          </div>
        </div>
      </div>
    </>);

};

export default NavigationMenu;