import React from 'react';
import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer } from
'recharts';

interface BarData {
  dataKey: string;
  name: string;
  color: string;
}

interface BarChartProps {
  data: any[];
  bars: BarData[];
  xAxisKey: string;
  showTooltip?: boolean;
  responsive?: boolean;
  height?: number;
}

export function BarChart({
  data,
  bars,
  xAxisKey,
  showTooltip = true,
  responsive = true,
  height = 300
}: BarChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full min-h-[200px] text-muted-foreground">
        No data available
      </div>);

  }

  const ChartWrapper = responsive ? ResponsiveContainer : 'div';

  const chart =
  <RechartsBarChart
    data={data}
    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>

      <CartesianGrid strokeDasharray="3 3" />
      <XAxis
      dataKey={xAxisKey}
      tick={{ fontSize: 12 }}
      tickLine={false} />

      <YAxis
      tick={{ fontSize: 12 }}
      tickLine={false} />

      {showTooltip &&
    <Tooltip
      contentStyle={{
        backgroundColor: 'hsl(var(--card))',
        border: '1px solid hsl(var(--border))',
        borderRadius: '6px'
      }} />

    }
      <Legend />
      {bars.map((bar) =>
    <Bar
      key={bar.dataKey}
      dataKey={bar.dataKey}
      fill={bar.color}
      name={bar.name}
      radius={[4, 4, 0, 0]} />

    )}
    </RechartsBarChart>;


  if (responsive) {
    return (
      <ResponsiveContainer width="100%" height={height}>
        {chart}
      </ResponsiveContainer>);

  }

  return <div style={{ height }}>{chart}</div>;
}

export default BarChart;