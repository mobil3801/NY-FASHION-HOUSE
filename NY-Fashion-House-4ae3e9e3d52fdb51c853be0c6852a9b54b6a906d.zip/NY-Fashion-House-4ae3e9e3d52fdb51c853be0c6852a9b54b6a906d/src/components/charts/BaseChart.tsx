import React, { forwardRef } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions } from
'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export const defaultChartOptions: ChartOptions<any> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const,
      labels: {
        boxWidth: 12,
        padding: 15,
        font: {
          size: 12
        },
        // Responsive legend
        usePointStyle: true
      }
    },
    title: {
      display: false
    },
    tooltip: {
      backgroundColor: 'rgba(0, 0, 0, 0.8)',
      titleColor: 'white',
      bodyColor: 'white',
      cornerRadius: 8,
      padding: 12,
      // Better touch interaction
      mode: 'nearest',
      intersect: false
    }
  },
  scales: {
    x: {
      grid: {
        display: false
      },
      ticks: {
        font: {
          size: 11
        },
        // Responsive tick configuration
        maxRotation: 45,
        minRotation: 0,
        maxTicksLimit: window.innerWidth < 768 ? 6 : 12
      }
    },
    y: {
      grid: {
        color: 'rgba(0, 0, 0, 0.1)'
      },
      ticks: {
        font: {
          size: 11
        }
      }
    }
  },
  interaction: {
    mode: 'nearest',
    intersect: false
  }
};

// Mobile specific options
export const mobileChartOptions: ChartOptions<any> = {
  ...defaultChartOptions,
  plugins: {
    ...defaultChartOptions.plugins,
    legend: {
      ...defaultChartOptions.plugins!.legend,
      position: 'bottom' as const,
      labels: {
        ...defaultChartOptions.plugins!.legend!.labels,
        boxWidth: 10,
        padding: 10,
        font: {
          size: 10
        }
      }
    }
  },
  scales: {
    ...defaultChartOptions.scales,
    x: {
      ...defaultChartOptions.scales!.x,
      ticks: {
        ...defaultChartOptions.scales!.x!.ticks,
        maxTicksLimit: 4,
        maxRotation: 45
      }
    }
  }
};

interface BaseChartProps {
  className?: string;
  height?: number;
  isMobile?: boolean;
}

export const BaseChart = forwardRef<HTMLDivElement, BaseChartProps>(
  ({ className = '', height = 300, isMobile = false }, ref) => {
    // Responsive height
    const responsiveHeight = isMobile ? Math.min(height, 250) : height;

    return (
      <div
        ref={ref}
        className={`w-full ${className}`}
        style={{ height: `${responsiveHeight}px` }} />);




  }
);

BaseChart.displayName = 'BaseChart';