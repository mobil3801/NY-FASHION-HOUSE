import React from 'react';
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer } from
'recharts';

interface DoughnutChartProps {
  data: any[];
  dataKey: string;
  nameKey: string;
  showTooltip?: boolean;
  responsive?: boolean;
  height?: number;
}

// Default color palette
const COLORS = [
'#0088FE',
'#00C49F',
'#FFBB28',
'#FF8042',
'#8884d8',
'#82ca9d',
'#ffc658',
'#8dd1e1',
'#d084d0',
'#82d982'];


export function DoughnutChart({
  data,
  dataKey,
  nameKey,
  showTooltip = true,
  responsive = true,
  height = 300
}: DoughnutChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full min-h-[200px] text-muted-foreground">
        No data available
      </div>);

  }

  const chart =
  <PieChart>
      <Pie
      data={data}
      cx="50%"
      cy="50%"
      labelLine={false}
      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
      outerRadius={80}
      innerRadius={40}
      fill="#8884d8"
      dataKey={dataKey}>

        {data.map((entry, index) =>
      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
      )}
      </Pie>
      {showTooltip &&
    <Tooltip
      contentStyle={{
        backgroundColor: 'hsl(var(--card))',
        border: '1px solid hsl(var(--border))',
        borderRadius: '6px'
      }} />

    }
      <Legend />
    </PieChart>;


  if (responsive) {
    return (
      <ResponsiveContainer width="100%" height={height}>
        {chart}
      </ResponsiveContainer>);

  }

  return <div style={{ height }}>{chart}</div>;
}

export default DoughnutChart;