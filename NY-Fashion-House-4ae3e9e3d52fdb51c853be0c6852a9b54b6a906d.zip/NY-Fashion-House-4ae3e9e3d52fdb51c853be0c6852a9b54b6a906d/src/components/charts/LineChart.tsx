import React from 'react';
import {
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer } from
'recharts';

interface LineData {
  dataKey: string;
  name: string;
  color: string;
}

interface LineChartProps {
  data: any[];
  lines: LineData[];
  xAxisKey: string;
  showTooltip?: boolean;
  responsive?: boolean;
  height?: number;
}

export function LineChart({
  data,
  lines,
  xAxisKey,
  showTooltip = true,
  responsive = true,
  height = 300
}: LineChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full min-h-[200px] text-muted-foreground">
        No data available
      </div>);

  }

  const ChartWrapper = responsive ? ResponsiveContainer : 'div';

  const chart =
  <RechartsLineChart
    data={data}
    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>

      <CartesianGrid strokeDasharray="3 3" />
      <XAxis
      dataKey={xAxisKey}
      tick={{ fontSize: 12 }}
      tickLine={false} />

      <YAxis
      tick={{ fontSize: 12 }}
      tickLine={false} />

      {showTooltip &&
    <Tooltip
      contentStyle={{
        backgroundColor: 'hsl(var(--card))',
        border: '1px solid hsl(var(--border))',
        borderRadius: '6px'
      }} />

    }
      <Legend />
      {lines.map((line) =>
    <Line
      key={line.dataKey}
      type="monotone"
      dataKey={line.dataKey}
      stroke={line.color}
      name={line.name}
      strokeWidth={2}
      dot={{ r: 4 }}
      activeDot={{ r: 6 }} />

    )}
    </RechartsLineChart>;


  if (responsive) {
    return (
      <ResponsiveContainer width="100%" height={height}>
        {chart}
      </ResponsiveContainer>);

  }

  return <div style={{ height }}>{chart}</div>;
}

export default LineChart;