
import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { format } from 'date-fns';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, Award, Target, Clock } from 'lucide-react';
import { BarChart } from '../charts/BarChart';
import { EmployeePerformanceReport } from '@/types/report';
import { formatUSACurrency } from '@/utils/usaCalendar';
import { formatUSADate } from '@/utils/dateUtils';
import { exportToPDF, ExportData } from '@/utils/exportUtils';

interface EmployeePerformanceComponentProps {
  reports: EmployeePerformanceReport[];
  isLoading?: boolean;
}

export default function EmployeePerformanceComponent({ reports, isLoading = false }: EmployeePerformanceComponentProps) {
  const { t } = useTranslation();
  const performanceChartRef = useRef();

  const performanceData = {
    labels: reports.slice(0, 10).map((emp) => emp.name.split(' ')[0]),
    datasets: [
    {
      label: t('Sales Achievement (%)'),
      data: reports.slice(0, 10).map((emp) => emp.targets.salesAchieved / emp.targets.salesTarget * 100),
      backgroundColor: 'rgba(59, 130, 246, 0.8)',
      borderColor: 'rgb(59, 130, 246)',
      borderWidth: 1
    },
    {
      label: t('Revenue Achievement (%)'),
      data: reports.slice(0, 10).map((emp) => emp.targets.revenueAchieved / emp.targets.revenueTarget * 100),
      backgroundColor: 'rgba(34, 197, 94, 0.8)',
      borderColor: 'rgb(34, 197, 94)',
      borderWidth: 1
    }]

  };

  const handleExportPDF = () => {
    const exportData: ExportData = {
      title: t('Employee Performance Report'),
      headers: [t('Employee'), t('Sales'), t('Revenue'), t('Efficiency'), t('Sales Target'), t('Revenue Target')],
      rows: reports.map((emp) => [
      emp.name,
      emp.salesCount.toString(),
      formatUSACurrency(emp.revenue),
      `${emp.efficiency}%`,
      `${(emp.targets.salesAchieved / emp.targets.salesTarget * 100).toFixed(1)}%`,
      `${(emp.targets.revenueAchieved / emp.targets.revenueTarget * 100).toFixed(1)}%`]
      )
    };

    exportToPDF(exportData);
  };

  const getPerformanceBadge = (achieved: number, target: number) => {
    const percentage = achieved / target * 100;
    if (percentage >= 100) return { variant: 'default' as const, text: t('Excellent') };
    if (percentage >= 80) return { variant: 'secondary' as const, text: t('Good') };
    if (percentage >= 60) return { variant: 'outline' as const, text: t('Average') };
    return { variant: 'destructive' as const, text: t('Poor') };
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) =>
          <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>);

  }

  const totalSales = reports.reduce((sum, emp) => sum + emp.salesCount, 0);
  const totalRevenue = reports.reduce((sum, emp) => sum + emp.revenue, 0);
  const avgEfficiency = reports.reduce((sum, emp) => sum + emp.efficiency, 0) / reports.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">{t('Employee Performance Report')}</h2>
          <p className="text-muted-foreground">{formatUSADate(new Date())}</p>
        </div>
        <Button onClick={handleExportPDF} variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          {t('Export PDF')}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Award className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Total Sales')}</p>
                <p className="text-2xl font-bold">{totalSales}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Target className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Total Revenue')}</p>
                <p className="text-2xl font-bold">{formatUSACurrency(totalRevenue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Avg Efficiency')}</p>
                <p className="text-2xl font-bold">{avgEfficiency.toFixed(1)}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle>{t('Target Achievement Comparison')}</CardTitle>
        </CardHeader>
        <CardContent>
          <BarChart ref={performanceChartRef} data={performanceData} height={400} />
        </CardContent>
      </Card>

      {/* Employee Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t('Employee Performance Details')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('Employee')}</TableHead>
                <TableHead className="text-right">{t('Sales')}</TableHead>
                <TableHead className="text-right">{t('Revenue')}</TableHead>
                <TableHead className="text-right">{t('Efficiency')}</TableHead>
                <TableHead className="text-center">{t('Sales Target')}</TableHead>
                <TableHead className="text-center">{t('Revenue Target')}</TableHead>
                <TableHead className="text-center">{t('Overall')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reports.map((emp) => {
                const salesAchievement = emp.targets.salesAchieved / emp.targets.salesTarget * 100;
                const revenueAchievement = emp.targets.revenueAchieved / emp.targets.revenueTarget * 100;
                const salesBadge = getPerformanceBadge(emp.targets.salesAchieved, emp.targets.salesTarget);
                const revenueBadge = getPerformanceBadge(emp.targets.revenueAchieved, emp.targets.revenueTarget);
                const overallScore = (salesAchievement + revenueAchievement) / 2;
                const overallBadge = getPerformanceBadge(overallScore, 100);

                return (
                  <TableRow key={emp.employeeId}>
                    <TableCell className="font-medium">{emp.name}</TableCell>
                    <TableCell className="text-right">{emp.salesCount}</TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatUSACurrency(emp.revenue)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="outline">{emp.efficiency}%</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="space-y-1">
                        <Progress value={salesAchievement} className="h-2" />
                        <Badge variant={salesBadge.variant} className="text-xs">
                          {salesAchievement.toFixed(1)}%
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="space-y-1">
                        <Progress value={revenueAchievement} className="h-2" />
                        <Badge variant={revenueBadge.variant} className="text-xs">
                          {revenueAchievement.toFixed(1)}%
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant={overallBadge.variant}>
                        {overallBadge.text}
                      </Badge>
                    </TableCell>
                  </TableRow>);

              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>);

}