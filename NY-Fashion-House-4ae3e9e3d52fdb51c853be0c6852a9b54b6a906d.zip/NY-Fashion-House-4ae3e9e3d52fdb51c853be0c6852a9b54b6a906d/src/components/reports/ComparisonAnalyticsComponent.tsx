
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, DollarSign, Package, ShoppingCart, Target } from 'lucide-react';
import { BarChart } from '@/components/charts/BarChart';
import { reportService, ComparisonData } from '@/services/reportService';
import { formatUSD } from '@/utils/currencyUtils';
import {
  format,
  startOfDay,
  endOfDay,
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
  subDays,
  subWeeks,
  subMonths } from
'date-fns';
import { toast } from 'sonner';

const ComparisonAnalyticsComponent: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [comparisonType, setComparisonType] = useState<'day' | 'week' | 'month'>('day');
  const [comparisonData, setComparisonData] = useState<ComparisonData | null>(null);

  // Get comparison periods
  const getComparisonPeriods = () => {
    const today = new Date();

    switch (comparisonType) {
      case 'day':
        return {
          current: {
            start: startOfDay(today),
            end: endOfDay(today),
            label: format(today, 'EEEE, MMM dd')
          },
          previous: {
            start: startOfDay(subDays(today, 1)),
            end: endOfDay(subDays(today, 1)),
            label: format(subDays(today, 1), 'EEEE, MMM dd')
          }
        };
      case 'week':
        const currentWeekStart = startOfWeek(today);
        const currentWeekEnd = endOfWeek(today);
        const previousWeekStart = startOfWeek(subWeeks(today, 1));
        const previousWeekEnd = endOfWeek(subWeeks(today, 1));

        return {
          current: {
            start: currentWeekStart,
            end: currentWeekEnd,
            label: `Week of ${format(currentWeekStart, 'MMM dd')}`
          },
          previous: {
            start: previousWeekStart,
            end: previousWeekEnd,
            label: `Week of ${format(previousWeekStart, 'MMM dd')}`
          }
        };
      case 'month':
        const currentMonthStart = startOfMonth(today);
        const currentMonthEnd = endOfMonth(today);
        const previousMonthStart = startOfMonth(subMonths(today, 1));
        const previousMonthEnd = endOfMonth(subMonths(today, 1));

        return {
          current: {
            start: currentMonthStart,
            end: currentMonthEnd,
            label: format(currentMonthStart, 'MMMM yyyy')
          },
          previous: {
            start: previousMonthStart,
            end: previousMonthEnd,
            label: format(previousMonthStart, 'MMMM yyyy')
          }
        };
    }
  };

  // Load comparison data
  const loadComparisonData = async () => {
    try {
      setLoading(true);
      const periods = getComparisonPeriods();

      const comparison = await reportService.getPeriodComparison(
        periods.current.start,
        periods.current.end,
        comparisonType
      );

      setComparisonData(comparison);
    } catch (error) {
      console.error('Error loading comparison data:', error);
      toast.error('Failed to load comparison data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadComparisonData();
  }, [comparisonType]);

  // Render growth indicator
  const renderGrowthIndicator = (growth: number, isPositiveGood: boolean = true) => {
    const isPositive = growth >= 0;
    const isGood = isPositiveGood ? isPositive : !isPositive;

    return (
      <div className={`flex items-center space-x-1 ${isGood ? 'text-green-600' : 'text-red-600'}`}>
        {isPositive ?
        <TrendingUp className="h-4 w-4" /> :

        <TrendingDown className="h-4 w-4" />
        }
        <span className="font-medium">{Math.abs(growth).toFixed(1)}%</span>
      </div>);

  };

  // Render comparison cards
  const renderComparisonCards = () => {
    if (!comparisonData) return null;

    const periods = getComparisonPeriods();

    const cards = [
    {
      title: 'Sales Revenue',
      current: formatUSD(comparisonData.current.totalSales),
      previous: formatUSD(comparisonData.previous.totalSales),
      growth: comparisonData.growth.salesGrowth,
      icon: DollarSign,
      color: 'text-green-600'
    },
    {
      title: 'Quantity Sold',
      current: comparisonData.current.totalQuantity.toLocaleString(),
      previous: comparisonData.previous.totalQuantity.toLocaleString(),
      growth: comparisonData.growth.quantityGrowth,
      icon: Package,
      color: 'text-blue-600'
    },
    {
      title: 'Transactions',
      current: comparisonData.current.totalTransactions.toLocaleString(),
      previous: comparisonData.previous.totalTransactions.toLocaleString(),
      growth: comparisonData.growth.transactionGrowth,
      icon: ShoppingCart,
      color: 'text-purple-600'
    },
    {
      title: 'Avg Order Value',
      current: formatUSD(comparisonData.current.averageOrderValue),
      previous: formatUSD(comparisonData.previous.averageOrderValue),
      growth: comparisonData.growth.avgOrderValueGrowth,
      icon: Target,
      color: 'text-orange-600'
    }];


    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {cards.map((card, index) =>
        <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <card.icon className={`h-5 w-5 ${card.color}`} />
                  <h3 className="font-medium text-sm">{card.title}</h3>
                </div>
                {renderGrowthIndicator(card.growth)}
              </div>
              
              <div className="space-y-2">
                <div>
                  <div className="text-sm text-muted-foreground">{periods.current.label}</div>
                  <div className="text-lg font-bold">{card.current}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">{periods.previous.label}</div>
                  <div className="text-sm">{card.previous}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>);

  };

  // Render comparison chart
  const renderComparisonChart = () => {
    if (!comparisonData) return null;

    const periods = getComparisonPeriods();

    const chartData = {
      labels: ['Sales Revenue', 'Quantity Sold', 'Transactions', 'Avg Order Value'],
      datasets: [
      {
        label: periods.current.label,
        data: [
        comparisonData.current.totalSales,
        comparisonData.current.totalQuantity,
        comparisonData.current.totalTransactions,
        comparisonData.current.averageOrderValue],

        backgroundColor: 'rgba(59, 130, 246, 0.8)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 1
      },
      {
        label: periods.previous.label,
        data: [
        comparisonData.previous.totalSales,
        comparisonData.previous.totalQuantity,
        comparisonData.previous.totalTransactions,
        comparisonData.previous.averageOrderValue],

        backgroundColor: 'rgba(156, 163, 175, 0.8)',
        borderColor: 'rgba(156, 163, 175, 1)',
        borderWidth: 1
      }]

    };

    const chartOptions = {
      responsive: true,
      plugins: {
        legend: {
          position: 'top' as const
        },
        title: {
          display: true,
          text: `${comparisonType.charAt(0).toUpperCase() + comparisonType.slice(1)}-over-${comparisonType} Comparison`
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Value'
          }
        }
      }
    };

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Performance Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <BarChart data={chartData} options={chartOptions} />
          </div>
        </CardContent>
      </Card>);

  };

  // Render top performers comparison
  const renderTopPerformersComparison = () => {
    if (!comparisonData) return null;

    const periods = getComparisonPeriods();

    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Top Products - {periods.current.label}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {comparisonData.current.topProducts.slice(0, 5).map((product, index) =>
              <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary">{index + 1}</Badge>
                    <span className="font-medium">{product.productName}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{formatUSD(product.revenue)}</div>
                    <div className="text-sm text-muted-foreground">{product.quantity} units</div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Products - {periods.previous.label}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {comparisonData.previous.topProducts.slice(0, 5).map((product, index) =>
              <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline">{index + 1}</Badge>
                    <span className="font-medium">{product.productName}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{formatUSD(product.revenue)}</div>
                    <div className="text-sm text-muted-foreground">{product.quantity} units</div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>);

  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading comparison data...</p>
        </div>
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Period-over-Period Analysis</h2>
        
        <Select value={comparisonType} onValueChange={setComparisonType}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="day">Day vs Day</SelectItem>
            <SelectItem value="week">Week vs Week</SelectItem>
            <SelectItem value="month">Month vs Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Comparison Cards */}
      {renderComparisonCards()}

      {/* Comparison Chart */}
      {renderComparisonChart()}

      {/* Top Performers Comparison */}
      {renderTopPerformersComparison()}
    </div>);

};

export default ComparisonAnalyticsComponent;