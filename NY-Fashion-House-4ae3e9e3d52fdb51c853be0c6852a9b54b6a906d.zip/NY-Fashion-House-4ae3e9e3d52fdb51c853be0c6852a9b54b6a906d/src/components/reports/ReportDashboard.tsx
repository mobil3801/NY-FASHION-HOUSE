
import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  BarChart3,
  FileText,
  Users,
  UserCheck,
  DollarSign,
  Download,
  RefreshCw,
  Settings,
  TrendingUp,
  TrendingDown,
  Target,
  Wallet } from
'lucide-react';
import ReportFilters from './ReportFilters';
import SalesAnalyticsComponent from './SalesAnalyticsComponent';
import SalesReportComponent from './SalesReportComponent';
import FinancialSummaryComponent from './FinancialSummaryComponent';
import ComparisonAnalyticsComponent from './ComparisonAnalyticsComponent';
import { ReportFilter } from '@/types/report';
import { reportService } from '@/services/reportService';
import { financialService, FinancialAnalytics } from '@/services/financialService';
import { formatUSD as formatCurrency } from '@/utils/currencyUtils';
import { toast } from 'sonner';
import { LineChart, BarChart, PieChart, DoughnutChart } from '@/components/charts';

export default function ReportDashboard() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(false);
  const [financialAnalytics, setFinancialAnalytics] = useState<FinancialAnalytics | null>(null);
  const [salesTrend, setSalesTrend] = useState<any[]>([]);
  const [expenseBreakdown, setExpenseBreakdown] = useState<any[]>([]);
  const [financialTrend, setFinancialTrend] = useState<any[]>([]);

  // Filter state
  const [filter, setFilter] = useState<ReportFilter>(() => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - 1);
    return {
      startDate,
      endDate,
      period: 'monthly'
    };
  });

  // Load initial data
  useEffect(() => {
    loadDashboardData();
    // Set up real-time refresh
    const interval = setInterval(loadDashboardData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  // Reload data when filter changes
  useEffect(() => {
    if (filter.startDate && filter.endDate) {
      loadDashboardData();
    }
  }, [filter]);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      // Validate filter dates before making API calls
      if (!filter.startDate || !filter.endDate) {
        console.warn('[ReportDashboard] Invalid filter dates');
        return;
      }

      const [analytics, trend, expenses, financialTrendData] = await Promise.all([
      financialService.getFinancialAnalytics(),
      reportService.getDailySalesTrend(filter.startDate, filter.endDate),
      financialService.getExpenseCategoryBreakdown(filter.startDate, filter.endDate),
      financialService.getFinancialTrend('daily', 30)]
      );

      setFinancialAnalytics(analytics);
      setSalesTrend(trend || []);
      setExpenseBreakdown(expenses || []);
      setFinancialTrend(financialTrendData || []);
    } catch (error) {
      console.error('[ReportDashboard] Error loading dashboard data:', error);
      toast.error(t('Failed to load dashboard data'));

      // Set fallback data to prevent UI crashes
      setFinancialAnalytics(null);
      setSalesTrend([]);
      setExpenseBreakdown([]);
      setFinancialTrend([]);
    } finally {
      setLoading(false);
    }
  };

  const handleApplyFilter = () => {
    if (!filter.startDate || !filter.endDate) {
      toast.error(t('Please select valid start and end dates'));
      return;
    }

    if (filter.startDate > filter.endDate) {
      toast.error(t('Start date cannot be after end date'));
      return;
    }

    loadDashboardData();
    toast.success(t('Filters applied successfully'));
  };

  const exportDashboardData = async () => {
    try {
      // Implementation for exporting comprehensive report
      toast.success(t('Dashboard data exported successfully'));
    } catch (error) {
      toast.error(t('Failed to export dashboard data'));
    }
  };

  // Calculate growth indicators
  const getGrowthIndicator = (current: number, previous: number) => {
    if (previous === 0) return { value: 0, trend: 'neutral' as const };
    const growth = (current - previous) / previous * 100;
    return {
      value: Math.abs(growth),
      trend: growth > 0 ? 'up' : growth < 0 ? 'down' : 'neutral' as const
    };
  };

  const renderKPICard = (title: string, value: string, growth?: {value: number;trend: 'up' | 'down' | 'neutral';}, icon?: React.ReactNode) =>
  <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
            {growth &&
          <div className={`flex items-center gap-1 mt-2 text-sm ${
          growth.trend === 'up' ? 'text-green-600' :
          growth.trend === 'down' ? 'text-red-600' : 'text-gray-600'}`
          }>
                {growth.trend === 'up' ? <TrendingUp className="h-4 w-4" /> :
            growth.trend === 'down' ? <TrendingDown className="h-4 w-4" /> :
            <Target className="h-4 w-4" />}
                <span>{growth.value.toFixed(1)}%</span>
              </div>
          }
          </div>
          {icon && <div className="text-muted-foreground">{icon}</div>}
        </div>
      </CardContent>
    </Card>;


  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">{t('Financial Dashboard')}</h1>
          <p className="text-muted-foreground">{t('Real-time financial analytics and reporting')}</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button onClick={loadDashboardData} disabled={loading} variant="outline" className="gap-2">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            {t('Refresh')}
          </Button>
          <Button onClick={exportDashboardData} variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            {t('Export')}
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      {financialAnalytics &&
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {renderKPICard(
          t("Today's Revenue"),
          formatCurrency(financialAnalytics.daily.revenue),
          getGrowthIndicator(financialAnalytics.daily.revenue, financialAnalytics.weekly.revenue / 7),
          <DollarSign className="h-8 w-8 text-green-500" />
        )}
          
          {renderKPICard(
          t("Today's Expenses"),
          formatCurrency(financialAnalytics.daily.expenses),
          getGrowthIndicator(financialAnalytics.daily.expenses, financialAnalytics.weekly.expenses / 7),
          <Wallet className="h-8 w-8 text-red-500" />
        )}
          
          {renderKPICard(
          t("Today's Profit"),
          formatCurrency(financialAnalytics.daily.profit),
          getGrowthIndicator(financialAnalytics.daily.profit, financialAnalytics.weekly.profit / 7),
          <TrendingUp className="h-8 w-8 text-blue-500" />
        )}
          
          {renderKPICard(
          t('Profit Margin'),
          `${financialAnalytics.daily.profitMargin.toFixed(1)}%`,
          getGrowthIndicator(financialAnalytics.daily.profitMargin, financialAnalytics.weekly.profitMargin),
          <Target className="h-8 w-8 text-purple-500" />
        )}
        </div>
      }

      {/* Report Filters */}
      <ReportFilters
        filter={filter}
        onFilterChange={setFilter}
        onApplyFilter={handleApplyFilter}
        showCustomerFilter={false}
        showProductFilter={false}
        showEmployeeFilter={false}
        isLoading={loading} />



      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
          <TabsTrigger value="overview" className="gap-2">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">{t('Overview')}</span>
          </TabsTrigger>
          <TabsTrigger value="sales" className="gap-2">
            <TrendingUp className="h-4 w-4" />
            <span className="hidden sm:inline">{t('Sales')}</span>
          </TabsTrigger>
          <TabsTrigger value="financial" className="gap-2">
            <DollarSign className="h-4 w-4" />
            <span className="hidden sm:inline">{t('Financial')}</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-2">
            <FileText className="h-4 w-4" />
            <span className="hidden sm:inline">{t('Analytics')}</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Revenue vs Expenses Trend */}
            <Card>
              <CardHeader>
                <CardTitle>{t('Financial Trend (30 Days)')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <LineChart
                    data={financialTrend}
                    lines={[
                    { dataKey: 'revenue', name: t('Revenue'), color: '#22c55e' },
                    { dataKey: 'expenses', name: t('Expenses'), color: '#ef4444' },
                    { dataKey: 'profit', name: t('Profit'), color: '#3b82f6' }]
                    }
                    xAxisKey="period"
                    showTooltip
                    responsive />

                </div>
              </CardContent>
            </Card>

            {/* Profit Margin Trend */}
            <Card>
              <CardHeader>
                <CardTitle>{t('Profit Margin Trend')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <BarChart
                    data={financialTrend}
                    bars={[{ dataKey: 'profitMargin', name: t('Profit Margin (%)'), color: '#8b5cf6' }]}
                    xAxisKey="period"
                    showTooltip
                    responsive />

                </div>
              </CardContent>
            </Card>

            {/* Expense Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>{t('Expense Categories')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <PieChart
                    data={expenseBreakdown.map((item) => ({
                      name: item.category,
                      value: item.amount,
                      label: `${item.category}: ${formatCurrency(item.amount)}`
                    }))}
                    dataKey="value"
                    nameKey="name"
                    showTooltip
                    responsive />

                </div>
              </CardContent>
            </Card>

            {/* Monthly Performance Summary */}
            {financialAnalytics &&
            <Card>
                <CardHeader>
                  <CardTitle>{t('Monthly Performance')}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">{t('Revenue')}</p>
                      <p className="font-semibold">{formatCurrency(financialAnalytics.monthly.revenue)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">{t('Expenses')}</p>
                      <p className="font-semibold">{formatCurrency(financialAnalytics.monthly.expenses)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">{t('Gross Profit')}</p>
                      <p className="font-semibold">{formatCurrency(financialAnalytics.monthly.grossProfit)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">{t('Net Profit')}</p>
                      <p className="font-semibold">{formatCurrency(financialAnalytics.monthly.netProfit)}</p>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">{t('Cost of Goods Sold')}</span>
                      <span className="font-medium">{formatCurrency(financialAnalytics.monthly.costOfGoodsSold)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            }
          </div>
        </TabsContent>

        <TabsContent value="sales">
          <div className="min-h-[400px]">
            <SalesAnalyticsComponent filter={filter} />
          </div>
        </TabsContent>

        <TabsContent value="financial">
          <FinancialSummaryComponent
            report={financialAnalytics ? {
              totalRevenue: financialAnalytics.monthly.revenue,
              totalExpenses: financialAnalytics.monthly.expenses,
              netProfit: financialAnalytics.monthly.netProfit,
              profitMargin: financialAnalytics.monthly.profitMargin,
              revenueByMonth: financialTrend.map((item) => ({
                month: item.period,
                revenue: item.revenue,
                expenses: item.expenses,
                profit: item.profit
              })),
              expensesByCategory: expenseBreakdown.map((item) => ({
                category: item.category,
                amount: item.amount,
                percentage: item.percentage
              })),
              costOfGoodsSold: financialAnalytics.monthly.costOfGoodsSold
            } : null}
            isLoading={loading} />

        </TabsContent>

        <TabsContent value="analytics">
          <ComparisonAnalyticsComponent filter={filter} />
        </TabsContent>
      </Tabs>
    </div>);

}