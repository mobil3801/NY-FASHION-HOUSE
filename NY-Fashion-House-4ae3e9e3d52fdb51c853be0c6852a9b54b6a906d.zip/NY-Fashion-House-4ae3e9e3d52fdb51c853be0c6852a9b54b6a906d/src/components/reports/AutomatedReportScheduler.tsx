
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Calendar, Clock, Mail, Plus, Settings, Trash2 } from 'lucide-react';
import { AutoReportSchedule } from '@/types/report';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface AutomatedReportSchedulerProps {
  schedules: AutoReportSchedule[];
  onScheduleChange: (schedules: AutoReportSchedule[]) => void;
}

export default function AutomatedReportScheduler({ schedules, onScheduleChange }: AutomatedReportSchedulerProps) {
  const { t } = useTranslation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<AutoReportSchedule | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    reportType: '',
    frequency: 'weekly' as 'daily' | 'weekly' | 'monthly',
    recipients: '',
    isActive: true
  });

  const reportTypes = [
  { value: 'sales', label: t('Sales Report') },
  { value: 'inventory', label: t('Inventory Report') },
  { value: 'customer', label: t('Customer Analytics') },
  { value: 'employee', label: t('Employee Performance') },
  { value: 'financial', label: t('Financial Summary') }];


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.reportType || !formData.recipients) {
      toast.error(t('Please fill all required fields'));
      return;
    }

    const recipients = formData.recipients.split(',').map((email) => email.trim()).filter(Boolean);

    if (recipients.length === 0) {
      toast.error(t('Please provide at least one recipient email'));
      return;
    }

    const newSchedule: AutoReportSchedule = {
      id: editingSchedule?.id || `schedule_${Date.now()}`,
      name: formData.name,
      reportType: formData.reportType,
      frequency: formData.frequency,
      recipients,
      isActive: formData.isActive,
      lastRun: editingSchedule?.lastRun,
      nextRun: getNextRunDate(formData.frequency)
    };

    const updatedSchedules = editingSchedule ?
    schedules.map((s) => s.id === editingSchedule.id ? newSchedule : s) :
    [...schedules, newSchedule];

    onScheduleChange(updatedSchedules);

    setFormData({
      name: '',
      reportType: '',
      frequency: 'weekly',
      recipients: '',
      isActive: true
    });
    setEditingSchedule(null);
    setIsDialogOpen(false);

    toast.success(editingSchedule ? t('Schedule updated') : t('Schedule created'));
  };

  const getNextRunDate = (frequency: 'daily' | 'weekly' | 'monthly'): Date => {
    const now = new Date();
    switch (frequency) {
      case 'daily':
        return new Date(now.getTime() + 24 * 60 * 60 * 1000);
      case 'weekly':
        return new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      case 'monthly':
        return new Date(now.getFullYear(), now.getMonth() + 1, now.getDate());
      default:
        return now;
    }
  };

  const handleEdit = (schedule: AutoReportSchedule) => {
    setEditingSchedule(schedule);
    setFormData({
      name: schedule.name,
      reportType: schedule.reportType,
      frequency: schedule.frequency,
      recipients: schedule.recipients.join(', '),
      isActive: schedule.isActive
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (scheduleId: string) => {
    const updatedSchedules = schedules.filter((s) => s.id !== scheduleId);
    onScheduleChange(updatedSchedules);
    toast.success(t('Schedule deleted'));
  };

  const handleToggleActive = (scheduleId: string) => {
    const updatedSchedules = schedules.map((s) =>
    s.id === scheduleId ? { ...s, isActive: !s.isActive } : s
    );
    onScheduleChange(updatedSchedules);
  };

  const getFrequencyBadge = (frequency: string) => {
    const variants = {
      daily: 'default' as const,
      weekly: 'secondary' as const,
      monthly: 'outline' as const
    };
    return variants[frequency as keyof typeof variants] || 'outline';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            {t('Automated Report Scheduler')}
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                {t('Add Schedule')}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {editingSchedule ? t('Edit Schedule') : t('Create New Schedule')}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">{t('Schedule Name')}</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder={t('Enter schedule name')}
                    required />

                </div>

                <div>
                  <Label htmlFor="reportType">{t('Report Type')}</Label>
                  <Select value={formData.reportType} onValueChange={(value) => setFormData({ ...formData, reportType: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('Select report type')} />
                    </SelectTrigger>
                    <SelectContent>
                      {reportTypes.map((type) =>
                      <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="frequency">{t('Frequency')}</Label>
                  <Select value={formData.frequency} onValueChange={(value: 'daily' | 'weekly' | 'monthly') => setFormData({ ...formData, frequency: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">{t('Daily')}</SelectItem>
                      <SelectItem value="weekly">{t('Weekly')}</SelectItem>
                      <SelectItem value="monthly">{t('Monthly')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="recipients">{t('Email Recipients')}</Label>
                  <Input
                    id="recipients"
                    value={formData.recipients}
                    onChange={(e) => setFormData({ ...formData, recipients: e.target.value })}
                    placeholder="email1@example.com, email2@example.com"
                    required />

                  <p className="text-xs text-muted-foreground mt-1">
                    {t('Separate multiple emails with commas')}
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="isActive"
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })} />

                  <Label htmlFor="isActive">{t('Active')}</Label>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">
                    {editingSchedule ? t('Update') : t('Create')}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsDialogOpen(false);
                      setEditingSchedule(null);
                      setFormData({
                        name: '',
                        reportType: '',
                        frequency: 'weekly',
                        recipients: '',
                        isActive: true
                      });
                    }}>

                    {t('Cancel')}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {schedules.length === 0 ?
        <div className="text-center py-8 text-muted-foreground">
            <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>{t('No scheduled reports yet')}</p>
            <p className="text-sm">{t('Create your first automated report schedule')}</p>
          </div> :

        <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('Schedule Name')}</TableHead>
                <TableHead>{t('Report Type')}</TableHead>
                <TableHead>{t('Frequency')}</TableHead>
                <TableHead>{t('Recipients')}</TableHead>
                <TableHead>{t('Next Run')}</TableHead>
                <TableHead>{t('Status')}</TableHead>
                <TableHead>{t('Actions')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {schedules.map((schedule) =>
            <TableRow key={schedule.id}>
                  <TableCell className="font-medium">{schedule.name}</TableCell>
                  <TableCell>
                    {reportTypes.find((t) => t.value === schedule.reportType)?.label || schedule.reportType}
                  </TableCell>
                  <TableCell>
                    <Badge variant={getFrequencyBadge(schedule.frequency)}>
                      {t(schedule.frequency)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Mail className="h-3 w-3" />
                      {schedule.recipients.length}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      {format(schedule.nextRun, 'MMM dd, yyyy')}
                      <br />
                      <span className="text-muted-foreground">
                        {format(schedule.nextRun, 'HH:mm')}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch
                    checked={schedule.isActive}
                    onCheckedChange={() => handleToggleActive(schedule.id)}
                    size="sm" />

                      <Badge variant={schedule.isActive ? 'default' : 'secondary'}>
                        {schedule.isActive ? t('Active') : t('Inactive')}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(schedule)}>

                        <Settings className="h-3 w-3" />
                      </Button>
                      <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(schedule.id)}>

                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
            )}
            </TableBody>
          </Table>
        }
      </CardContent>
    </Card>);

}