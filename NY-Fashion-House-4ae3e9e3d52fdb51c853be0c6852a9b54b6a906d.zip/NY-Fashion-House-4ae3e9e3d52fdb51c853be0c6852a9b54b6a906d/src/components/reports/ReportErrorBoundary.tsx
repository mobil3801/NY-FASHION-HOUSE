import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface ReportErrorBoundaryState {
  hasError: boolean;
  error?: Error;
  errorInfo?: React.ErrorInfo;
}

interface ReportErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ComponentType<{error: Error;retry: () => void;}>;
}

class ReportErrorBoundary extends React.Component<ReportErrorBoundaryProps, ReportErrorBoundaryState> {
  constructor(props: ReportErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ReportErrorBoundaryState {
    return {
      hasError: true,
      error
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('[ReportErrorBoundary] Error caught:', error, errorInfo);

    this.setState({
      hasError: true,
      error,
      errorInfo
    });
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: undefined, errorInfo: undefined });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        const FallbackComponent = this.props.fallback;
        return <FallbackComponent error={this.state.error!} retry={this.handleRetry} />;
      }

      return <DefaultErrorFallback error={this.state.error!} retry={this.handleRetry} />;
    }

    return this.props.children;
  }
}

interface DefaultErrorFallbackProps {
  error: Error;
  retry: () => void;
}

function DefaultErrorFallback({ error, retry }: DefaultErrorFallbackProps) {
  const { t } = useTranslation();

  return (
    <Card className="w-full max-w-md mx-auto mt-8">
      <CardHeader className="text-center">
        <div className="flex items-center justify-center mb-4">
          <AlertTriangle className="h-12 w-12 text-red-500" />
        </div>
        <CardTitle className="text-red-600">
          {t('Report Error')}
        </CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <p className="text-muted-foreground">
          {t('Something went wrong while loading the report data. This might be due to:')}
        </p>
        
        <ul className="text-sm text-left list-disc list-inside space-y-1 text-muted-foreground">
          <li>{t('Network connectivity issues')}</li>
          <li>{t('Database connection problems')}</li>
          <li>{t('Invalid data format')}</li>
          <li>{t('Insufficient permissions')}</li>
        </ul>

        {process.env.NODE_ENV === 'development' &&
        <details className="text-left">
            <summary className="cursor-pointer font-semibold text-sm">
              {t('Technical Details')}
            </summary>
            <pre className="mt-2 text-xs bg-gray-100 p-2 rounded overflow-auto">
              {error.message}
              {error.stack}
            </pre>
          </details>
        }

        <div className="flex gap-2 justify-center">
          <Button onClick={retry} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            {t('Try Again')}
          </Button>
        </div>
      </CardContent>
    </Card>);

}

export default ReportErrorBoundary;