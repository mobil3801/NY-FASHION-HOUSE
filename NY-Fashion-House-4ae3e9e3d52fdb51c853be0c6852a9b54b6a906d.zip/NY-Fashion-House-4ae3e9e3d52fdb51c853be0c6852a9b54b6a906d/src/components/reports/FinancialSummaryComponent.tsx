
import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, DollarSign, TrendingUp, TrendingDown, Percent, Wallet } from 'lucide-react';
import { LineChart } from '../charts/LineChart';
import { PieChart } from '../charts/PieChart';
import { formatUSD as formatCurrency } from '@/utils/currencyUtils';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface FinancialSummaryProps {
  report: {
    totalRevenue: number;
    totalExpenses: number;
    netProfit: number;
    profitMargin: number;
    revenueByMonth: Array<{
      month: string;
      revenue: number;
      expenses: number;
      profit: number;
    }>;
    expensesByCategory: Array<{
      category: string;
      amount: number;
      percentage: number;
    }>;
    costOfGoodsSold: number;
  } | null;
  isLoading?: boolean;
}

export default function FinancialSummaryComponent({ report, isLoading = false }: FinancialSummaryProps) {
  const { t } = useTranslation();

  const handleExportPDF = () => {
    // Export functionality
    toast.success(t('Financial report exported successfully'));
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) =>
          <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>);

  }

  if (!report) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">{t('No financial data available')}</p>
      </div>);

  }

  const grossProfit = report.totalRevenue - report.costOfGoodsSold;
  const grossMargin = report.totalRevenue > 0 ? grossProfit / report.totalRevenue * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">{t('Financial Summary')}</h2>
          <p className="text-muted-foreground">{format(new Date(), 'PPP')}</p>
        </div>
        <Button onClick={handleExportPDF} variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          {t('Export PDF')}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Total Revenue')}</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(report.totalRevenue)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Wallet className="h-8 w-8 text-red-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Total Expenses')}</p>
                <p className="text-2xl font-bold text-red-600">
                  {formatCurrency(report.totalExpenses)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Net Profit')}</p>
                <p className={`text-2xl font-bold ${report.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {formatCurrency(report.netProfit)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Percent className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Profit Margin')}</p>
                <p className="text-2xl font-bold text-purple-600">
                  {report.profitMargin.toFixed(2)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>{t('Revenue vs Expenses Trend')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <LineChart
                data={report.revenueByMonth}
                lines={[
                { dataKey: 'revenue', name: t('Revenue'), color: '#22c55e' },
                { dataKey: 'expenses', name: t('Expenses'), color: '#ef4444' },
                { dataKey: 'profit', name: t('Profit'), color: '#3b82f6' }]
                }
                xAxisKey="month"
                showTooltip
                responsive />

            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('Expense Breakdown')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <PieChart
                data={report.expensesByCategory.map((exp) => ({
                  name: t(exp.category),
                  value: exp.amount,
                  label: `${t(exp.category)}: ${formatCurrency(exp.amount)}`
                }))}
                dataKey="value"
                nameKey="name"
                showTooltip
                responsive />

            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>{t('Monthly Financial Breakdown')}</CardTitle>
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('Month')}</TableHead>
                <TableHead className="text-right">{t('Revenue')}</TableHead>
                <TableHead className="text-right">{t('Expenses')}</TableHead>
                <TableHead className="text-right">{t('Profit')}</TableHead>
                <TableHead className="text-right">{t('Margin')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {report.revenueByMonth.map((month) => {
                const margin = month.revenue > 0 ? month.profit / month.revenue * 100 : 0;
                return (
                  <TableRow key={month.month}>
                    <TableCell className="font-medium">{month.month}</TableCell>
                    <TableCell className="text-right font-semibold text-green-600">
                      {formatCurrency(month.revenue)}
                    </TableCell>
                    <TableCell className="text-right font-semibold text-red-600">
                      {formatCurrency(month.expenses)}
                    </TableCell>
                    <TableCell className={`text-right font-semibold ${month.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(month.profit)}
                    </TableCell>
                    <TableCell className="text-right">
                      {margin.toFixed(2)}%
                    </TableCell>
                  </TableRow>);

              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Additional Financial Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>{t('Financial Metrics')}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t('Gross Profit')}</span>
              <span className="font-semibold">{formatCurrency(grossProfit)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t('Gross Margin')}</span>
              <span className="font-semibold">{grossMargin.toFixed(2)}%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t('Cost of Goods Sold')}</span>
              <span className="font-semibold">{formatCurrency(report.costOfGoodsSold)}</span>
            </div>
            <div className="flex justify-between items-center border-t pt-4">
              <span className="text-sm text-muted-foreground">{t('Operating Expenses')}</span>
              <span className="font-semibold">{formatCurrency(report.totalExpenses)}</span>
            </div>
          </CardContent>
        </Card>

        {/* Expense Categories Table */}
        <Card>
          <CardHeader>
            <CardTitle>{t('Expense Categories')}</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t('Category')}</TableHead>
                  <TableHead className="text-right">{t('Amount')}</TableHead>
                  <TableHead className="text-right">{t('Percentage')}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {report.expensesByCategory.map((expense) =>
                <TableRow key={expense.category}>
                    <TableCell className="font-medium">{t(expense.category)}</TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatCurrency(expense.amount)}
                    </TableCell>
                    <TableCell className="text-right">
                      {expense.percentage.toFixed(1)}%
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>);

}