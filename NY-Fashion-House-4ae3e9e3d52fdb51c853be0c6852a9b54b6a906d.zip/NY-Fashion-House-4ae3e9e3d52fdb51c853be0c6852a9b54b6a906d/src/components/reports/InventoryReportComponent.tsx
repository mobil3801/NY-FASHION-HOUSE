import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatUSD } from '@/utils/currencyUtils';
import { BarChart } from '@/components/charts/BarChart';

interface InventoryReportProps {
  inventoryValue: number;
  totalProducts: number;
  lowStockItems: number;
}

const InventoryReportComponent: React.FC<InventoryReportProps> = ({
  inventoryValue,
  totalProducts,
  lowStockItems
}) => {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Inventory Overview</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-muted p-4 rounded-lg">
            <h3 className="text-sm font-medium text-muted-foreground">
              Total Inventory Value
            </h3>
            <p className="text-2xl font-bold text-primary">
              {formatUSD(inventoryValue)}
            </p>
          </div>
          <div className="bg-muted p-4 rounded-lg">
            <h3 className="text-sm font-medium text-muted-foreground">
              Total Products
            </h3>
            <p className="text-2xl font-bold text-primary">
              {totalProducts}
            </p>
          </div>
          <div className="bg-muted p-4 rounded-lg">
            <h3 className="text-sm font-medium text-muted-foreground">
              Low Stock Items
            </h3>
            <p className="text-2xl font-bold text-destructive">
              {lowStockItems}
            </p>
          </div>
        </div>
        <BarChart
          data={[
          { name: 'Inventory Value', value: inventoryValue }]
          } />

      </CardContent>
    </Card>);

};

export default InventoryReportComponent;