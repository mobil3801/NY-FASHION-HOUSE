
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar, RefreshCw, Download, TrendingUp, TrendingDown, DollarSign, Package, ShoppingCart, Users, AlertTriangle } from 'lucide-react';
import ComparisonAnalyticsComponent from './ComparisonAnalyticsComponent';
import { BarChart } from '@/components/charts/BarChart';
import { LineChart } from '@/components/charts/LineChart';
import { PieChart } from '@/components/charts/PieChart';
import { DoughnutChart } from '@/components/charts/DoughnutChart';
import { reportService, SalesAnalyticsData, TrendData, ComparisonData, DailySalesData } from '@/services/reportService';
import { formatUSD } from '@/utils/currencyUtils';
import { format, subDays, subWeeks, subMonths, startOfDay, endOfDay, isValid } from 'date-fns';
import { toast } from 'sonner';

interface SalesAnalyticsComponentProps {
  filter?: {
    startDate: Date;
    endDate: Date;
    period?: 'daily' | 'weekly' | 'monthly';
  };
}

const SalesAnalyticsComponent: React.FC<SalesAnalyticsComponentProps> = ({ filter }) => {
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'custom'>('today');
  const [analytics, setAnalytics] = useState<SalesAnalyticsData | null>(null);
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [comparison, setComparison] = useState<ComparisonData | null>(null);
  const [dailyEmployeeSales, setDailyEmployeeSales] = useState<DailySalesData[]>([]);
  const [autoRefresh, setAutoRefresh] = useState(false);

  // Validate date range
  const validateDateRange = (start: Date, end: Date): boolean => {
    if (!start || !end || !isValid(start) || !isValid(end)) {
      return false;
    }

    if (start > end) {
      return false;
    }

    // Check if date range is too large (more than 1 year)
    const oneYear = 365 * 24 * 60 * 60 * 1000;
    if (end.getTime() - start.getTime() > oneYear) {
      return false;
    }

    return true;
  };

  // Get date range based on selection
  const getDateRange = useCallback(() => {
    try {
      const today = new Date();

      // Use external filter if provided
      if (filter?.startDate && filter?.endDate) {
        if (!validateDateRange(filter.startDate, filter.endDate)) {
          console.warn('Invalid external date range provided, using today');
          return {
            start: startOfDay(today),
            end: endOfDay(today),
            comparison: 'day' as const
          };
        }
        return {
          start: startOfDay(filter.startDate),
          end: endOfDay(filter.endDate),
          comparison: (filter.period === 'weekly' ? 'week' : filter.period === 'monthly' ? 'month' : 'day') as const
        };
      }

      switch (dateRange) {
        case 'today':
          return {
            start: startOfDay(today),
            end: endOfDay(today),
            comparison: 'day' as const
          };
        case 'week':
          return {
            start: startOfDay(subDays(today, 7)),
            end: endOfDay(today),
            comparison: 'week' as const
          };
        case 'month':
          return {
            start: startOfDay(subDays(today, 30)),
            end: endOfDay(today),
            comparison: 'month' as const
          };
        default:
          return {
            start: startOfDay(today),
            end: endOfDay(today),
            comparison: 'day' as const
          };
      }
    } catch (err) {
      console.error('Error calculating date range:', err);
      const today = new Date();
      return {
        start: startOfDay(today),
        end: endOfDay(today),
        comparison: 'day' as const
      };
    }
  }, [dateRange, filter]);

  // Load analytics data with comprehensive error handling
  const loadAnalytics = useCallback(async () => {
    if (loading) return;

    try {
      setLoading(true);
      setError(null);

      const { start, end, comparison } = getDateRange();

      if (!validateDateRange(start, end)) {
        throw new Error('Invalid date range');
      }

      console.log('[SalesAnalytics] Loading data for range:', { start, end, comparison });

      // Load all data in parallel with individual error handling
      const promises = [
      reportService.getSalesAnalytics(start, end).catch((err) => {
        console.error('[SalesAnalytics] Error loading analytics:', err);
        return null;
      }),
      reportService.getDailySalesTrend(start, end).catch((err) => {
        console.error('[SalesAnalytics] Error loading trend data:', err);
        return [];
      }),
      reportService.getPeriodComparison(start, end, comparison).catch((err) => {
        console.error('[SalesAnalytics] Error loading comparison:', err);
        return null;
      }),
      reportService.getDailySalesByEmployee(start).catch((err) => {
        console.error('[SalesAnalytics] Error loading employee data:', err);
        return [];
      })];


      const [analyticsData, trendResult, comparisonData, employeeData] = await Promise.all(promises);

      // Validate and set data with fallbacks
      setAnalytics(analyticsData || {
        totalSales: 0,
        totalQuantity: 0,
        totalTransactions: 0,
        averageOrderValue: 0,
        topProducts: [],
        categoryBreakdown: [],
        employeePerformance: []
      });

      setTrendData(Array.isArray(trendResult) ? trendResult : []);
      setComparison(comparisonData);
      setDailyEmployeeSales(Array.isArray(employeeData) ? employeeData : []);

      console.log('[SalesAnalytics] Data loaded successfully');

    } catch (error) {
      console.error('[SalesAnalytics] Critical error loading analytics:', error);
      setError(error instanceof Error ? error.message : 'Failed to load analytics data');

      // Set fallback data
      setAnalytics({
        totalSales: 0,
        totalQuantity: 0,
        totalTransactions: 0,
        averageOrderValue: 0,
        topProducts: [],
        categoryBreakdown: [],
        employeePerformance: []
      });
      setTrendData([]);
      setComparison(null);
      setDailyEmployeeSales([]);

      toast.error('Failed to load analytics data. Please try refreshing.');
    } finally {
      setLoading(false);
    }
  }, [dateRange, loading, getDateRange]);

  // Refresh data with error handling
  const refreshData = async () => {
    try {
      setRefreshing(true);
      setError(null);
      await loadAnalytics();
      toast.success('Data refreshed successfully');
    } catch (error) {
      console.error('[SalesAnalytics] Error refreshing data:', error);
      toast.error('Failed to refresh data');
    } finally {
      setRefreshing(false);
    }
  };

  // Export functionality with error handling
  const handleExport = async (format: 'pdf' | 'excel') => {
    try {
      const { start, end } = getDateRange();

      if (!validateDateRange(start, end)) {
        throw new Error('Invalid date range for export');
      }

      await reportService.exportSalesReport(start, end, format);
      toast.success(`Report exported as ${format.toUpperCase()}`);
    } catch (error) {
      console.error('[SalesAnalytics] Export error:', error);
      toast.error(`Failed to export ${format.toUpperCase()}`);
    }
  };

  // Auto-refresh effect with cleanup
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (autoRefresh) {
      interval = setInterval(() => {
        if (!loading && !refreshing) {
          refreshData();
        }
      }, 300000); // 5 minutes
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh, loading, refreshing]);

  // Initial load with dependency tracking
  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  // Loading skeleton component
  const LoadingSkeleton = () =>
  <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) =>
      <Card key={i}>
            <CardContent className="p-6">
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-8 w-24 mb-2" />
              <Skeleton className="h-3 w-16" />
            </CardContent>
          </Card>
      )}
      </div>
      <Card>
        <CardContent className="p-6">
          <Skeleton className="h-4 w-32 mb-4" />
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    </div>;


  // Error display component
  const ErrorDisplay = ({ error }: {error: string;}) =>
  <Alert className="mb-6">
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription>
        <div className="flex justify-between items-center">
          <span>Error: {error}</span>
          <Button onClick={refreshData} size="sm" variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
      </AlertDescription>
    </Alert>;


  // Summary cards with null safety
  const renderSummaryCards = () => {
    if (!analytics || !comparison) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[...Array(4)].map((_, i) =>
          <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-4 w-20 mb-2" />
                <Skeleton className="h-8 w-24 mb-2" />
                <Skeleton className="h-3 w-16" />
              </CardContent>
            </Card>
          )}
        </div>);

    }

    const cards = [
    {
      title: 'Total Sales',
      value: formatUSD(analytics.totalSales || 0),
      icon: DollarSign,
      growth: comparison.growth?.salesGrowth || 0,
      color: 'text-green-600'
    },
    {
      title: 'Quantity Sold',
      value: (analytics.totalQuantity || 0).toLocaleString(),
      icon: Package,
      growth: comparison.growth?.quantityGrowth || 0,
      color: 'text-blue-600'
    },
    {
      title: 'Transactions',
      value: (analytics.totalTransactions || 0).toLocaleString(),
      icon: ShoppingCart,
      growth: comparison.growth?.transactionGrowth || 0,
      color: 'text-purple-600'
    },
    {
      title: 'Avg Order Value',
      value: formatUSD(analytics.averageOrderValue || 0),
      icon: TrendingUp,
      growth: comparison.growth?.avgOrderValueGrowth || 0,
      color: 'text-orange-600'
    }];


    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {cards.map((card, index) =>
        <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                  <p className="text-2xl font-bold">{card.value}</p>
                  <div className="flex items-center mt-1">
                    {card.growth >= 0 ?
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" /> :
                  <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                  }
                    <span className={`text-sm ${card.growth >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {Math.abs(card.growth).toFixed(1)}%
                    </span>
                  </div>
                </div>
                <card.icon className={`h-8 w-8 ${card.color}`} />
              </div>
            </CardContent>
          </Card>
        )}
      </div>);

  };

  // Trend charts with null safety
  const renderTrendCharts = () => {
    if (!trendData || !Array.isArray(trendData) || trendData.length === 0) {
      return (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Sales & Quantity Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80 flex items-center justify-center">
              <div className="text-center">
                <Package className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                <p className="text-muted-foreground">No trend data available</p>
              </div>
            </div>
          </CardContent>
        </Card>);

    }

    const chartData = {
      labels: trendData.map((d) => d.period || 'Unknown'),
      datasets: [
      {
        label: 'Sales Revenue',
        data: trendData.map((d) => d.sales || 0),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)'
      },
      {
        label: 'Quantity Sold',
        data: trendData.map((d) => d.quantity || 0),
        borderColor: 'rgb(16, 185, 129)',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        yAxisID: 'y1'
      }]

    };

    const chartOptions = {
      responsive: true,
      interaction: {
        mode: 'index' as const,
        intersect: false
      },
      scales: {
        y: {
          type: 'linear' as const,
          display: true,
          position: 'left' as const,
          title: {
            display: true,
            text: 'Revenue ($)'
          }
        },
        y1: {
          type: 'linear' as const,
          display: true,
          position: 'right' as const,
          title: {
            display: true,
            text: 'Quantity'
          },
          grid: {
            drawOnChartArea: false
          }
        }
      }
    };

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Sales & Quantity Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <LineChart data={chartData} options={chartOptions} />
          </div>
        </CardContent>
      </Card>);

  };

  // Category breakdown chart with null safety
  const renderCategoryChart = () => {
    if (!analytics?.categoryBreakdown || !Array.isArray(analytics.categoryBreakdown) || analytics.categoryBreakdown.length === 0) {
      return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle>Category Revenue Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80 flex items-center justify-center">
                <div className="text-center">
                  <PieChart className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                  <p className="text-muted-foreground">No category data available</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Category Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80 flex items-center justify-center">
                <p className="text-muted-foreground">No performance data available</p>
              </div>
            </CardContent>
          </Card>
        </div>);

    }

    const pieData = {
      labels: analytics.categoryBreakdown.map((c) => c.category || 'Unknown'),
      datasets: [{
        data: analytics.categoryBreakdown.map((c) => c.revenue || 0),
        backgroundColor: [
        '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
        '#06B6D4', '#84CC16', '#F97316', '#EC4899', '#6366F1']

      }]
    };

    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Category Revenue Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <PieChart data={pieData} />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Category Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.categoryBreakdown.slice(0, 6).map((category, index) =>
              <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: pieData.datasets[0].backgroundColor[index] }} />

                    <span className="font-medium">{category.category || 'Unknown'}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{formatUSD(category.revenue || 0)}</div>
                    <div className="text-sm text-muted-foreground">
                      {(category.percentage || 0).toFixed(1)}% • {category.quantity || 0} units
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>);

  };

  // Employee performance table with null safety
  const renderEmployeePerformance = () => {
    if (!analytics?.employeePerformance || !Array.isArray(analytics.employeePerformance) || analytics.employeePerformance.length === 0) {
      return (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Employee Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 flex items-center justify-center">
              <div className="text-center">
                <Users className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                <p className="text-muted-foreground">No employee performance data available</p>
              </div>
            </div>
          </CardContent>
        </Card>);

    }

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Employee Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead className="text-right">Sales</TableHead>
                  <TableHead className="text-right">Quantity</TableHead>
                  <TableHead className="text-right">Transactions</TableHead>
                  <TableHead className="text-right">Avg per Transaction</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analytics.employeePerformance.slice(0, 10).map((emp, index) =>
                <TableRow key={emp.employeeId || index}>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary">{index + 1}</Badge>
                        <span className="font-medium">{emp.employeeName || 'Unknown Employee'}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatUSD(emp.sales || 0)}
                    </TableCell>
                    <TableCell className="text-right">
                      {(emp.quantity || 0).toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right">
                      {(emp.transactions || 0).toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatUSD(emp.transactions && emp.transactions > 0 ? (emp.sales || 0) / emp.transactions : 0)}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>);

  };

  // Daily employee sales table with null safety
  const renderDailyEmployeeSales = () => {
    if (!dailyEmployeeSales || !Array.isArray(dailyEmployeeSales) || dailyEmployeeSales.length === 0) {
      return (
        <Card>
          <CardHeader>
            <CardTitle>Daily Sales by Employee & Shift</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-48 flex items-center justify-center">
              <div className="text-center">
                <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                <p className="text-muted-foreground">No daily employee sales data available</p>
              </div>
            </div>
          </CardContent>
        </Card>);

    }

    return (
      <Card>
        <CardHeader>
          <CardTitle>Daily Sales by Employee & Shift</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Shift</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Quantity</TableHead>
                  <TableHead className="text-right">Products</TableHead>
                  <TableHead className="text-right">Transactions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dailyEmployeeSales.map((emp, index) =>
                <TableRow key={`${emp.employeeId || index}-${emp.shift || 'unknown'}`}>
                    <TableCell className="font-medium">{emp.employeeName || 'Unknown Employee'}</TableCell>
                    <TableCell>
                      <Badge variant={emp.shift === 'Morning' ? 'default' : emp.shift === 'Afternoon' ? 'secondary' : 'outline'}>
                        {emp.shift || 'Unknown'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatUSD(emp.totalAmount || 0)}
                    </TableCell>
                    <TableCell className="text-right">{emp.totalQuantity || 0}</TableCell>
                    <TableCell className="text-right">{emp.productsCount || 0}</TableCell>
                    <TableCell className="text-right">{emp.transactions || 0}</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
        </Card>);

  };

  return (
    <div className="space-y-6">
      {/* Error Display */}
      {error && <ErrorDisplay error={error} />}

      {/* Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center space-x-4">
          <Select value={dateRange} onValueChange={setDateRange} disabled={loading || !!filter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">7 Days</SelectItem>
              <SelectItem value="month">30 Days</SelectItem>
            </SelectContent>
          </Select>
          
          <Button
            variant="outline"
            size="sm"
            onClick={refreshData}
            disabled={refreshing || loading}>

            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}
            disabled={loading}>

            <Calendar className="h-4 w-4 mr-2" />
            Auto-refresh {autoRefresh ? 'ON' : 'OFF'}
          </Button>
        </div>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport('excel')}
            disabled={loading || !analytics}>

            <Download className="h-4 w-4 mr-2" />
            Excel
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleExport('pdf')}
            disabled={loading || !analytics}>

            <Download className="h-4 w-4 mr-2" />
            PDF
          </Button>
        </div>
      </div>

      {/* Main Content */}
      {loading ?
      <LoadingSkeleton /> :

      <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="trends">Trends</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="employees">Employees</TabsTrigger>
            <TabsTrigger value="comparison">Comparison</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-6">
            {renderSummaryCards()}
            {renderTrendCharts()}
          </TabsContent>
          
          <TabsContent value="trends" className="space-y-6">
            {renderTrendCharts()}
            {renderSummaryCards()}
          </TabsContent>
          
          <TabsContent value="categories" className="space-y-6">
            {renderCategoryChart()}
          </TabsContent>
          
          <TabsContent value="employees" className="space-y-6">
            {renderEmployeePerformance()}
            {renderDailyEmployeeSales()}
          </TabsContent>
          
          <TabsContent value="comparison" className="space-y-6">
            <ComparisonAnalyticsComponent filter={filter} />
          </TabsContent>
        </Tabs>
      }
    </div>);

};

export default SalesAnalyticsComponent;