
import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, TrendingUp, ShoppingCart, DollarSign } from 'lucide-react';
import { LineChart } from '../charts/LineChart';
import { BarChart } from '../charts/BarChart';
import { SalesReport } from '@/types/report';
import { formatUSACurrency } from '@/utils/usaCalendar';
import { exportToPDF, ExportData } from '@/utils/exportUtils';
import { format } from 'date-fns';

interface SalesReportComponentProps {
  report: SalesReport;
  isLoading?: boolean;
}

export default function SalesReportComponent({ report, isLoading = false }: SalesReportComponentProps) {
  const { t } = useTranslation();
  const lineChartRef = useRef();
  const barChartRef = useRef();

  const salesChartData = {
    labels: report.salesByDay.map((day) => format(new Date(day.date), 'MMM dd')),
    datasets: [
    {
      label: t('Sales'),
      data: report.salesByDay.map((day) => day.sales),
      borderColor: 'rgb(59, 130, 246)',
      backgroundColor: 'rgba(59, 130, 246, 0.1)',
      tension: 0.4
    }]

  };

  const ordersChartData = {
    labels: report.salesByDay.map((day) => format(new Date(day.date), 'MMM dd')),
    datasets: [
    {
      label: t('Orders'),
      data: report.salesByDay.map((day) => day.orders),
      backgroundColor: 'rgba(34, 197, 94, 0.8)',
      borderColor: 'rgb(34, 197, 94)',
      borderWidth: 1
    }]

  };

  const handleExportPDF = () => {
    const exportData: ExportData = {
      title: `Sales Report - ${report.period}`,
      headers: [t('Date'), t('Sales'), t('Orders')],
      rows: report.salesByDay.map((day) => [
      format(new Date(day.date), 'MMM dd, yyyy'),
      formatUSACurrency(day.sales),
      day.orders.toString()]
      ),
      summary: {
        [t('Total Sales')]: formatUSACurrency(report.totalSales),
        [t('Total Orders')]: report.totalOrders,
        [t('Average Order Value')]: formatUSACurrency(report.averageOrderValue)
      }
    };

    exportToPDF(exportData);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) =>
          <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">{t('Sales Report')}</h2>
          <p className="text-muted-foreground">{report.period}</p>
        </div>
        <Button onClick={handleExportPDF} variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          {t('Export PDF')}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Total Sales')}</p>
                <p className="text-2xl font-bold">{formatUSACurrency(report.totalSales)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <ShoppingCart className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Total Orders')}</p>
                <p className="text-2xl font-bold">{report.totalOrders}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Avg Order Value')}</p>
                <p className="text-2xl font-bold">{formatUSACurrency(report.averageOrderValue)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>{t('Sales Trend')}</CardTitle>
          </CardHeader>
          <CardContent>
            <LineChart ref={lineChartRef} data={salesChartData} height={300} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('Orders by Date')}</CardTitle>
          </CardHeader>
          <CardContent>
            <BarChart ref={barChartRef} data={ordersChartData} height={300} />
          </CardContent>
        </Card>
      </div>

      {/* Top Products */}
      <Card>
        <CardHeader>
          <CardTitle>{t('Top Selling Products')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('Product Name')}</TableHead>
                <TableHead className="text-right">{t('Quantity')}</TableHead>
                <TableHead className="text-right">{t('Revenue')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {report.topProducts.map((product, index) =>
              <TableRow key={product.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {product.name}
                      {index === 0 && <Badge variant="secondary">#{index + 1}</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">{product.quantity}</TableCell>
                  <TableCell className="text-right font-semibold">
                    {formatUSACurrency(product.revenue)}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>);

}