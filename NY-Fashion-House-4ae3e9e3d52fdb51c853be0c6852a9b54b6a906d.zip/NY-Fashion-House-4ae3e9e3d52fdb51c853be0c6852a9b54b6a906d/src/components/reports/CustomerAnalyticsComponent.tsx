
import React, { useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, Users, UserPlus, Crown } from 'lucide-react';
import { BarChart } from '../charts/BarChart';
import { DoughnutChart } from '../charts/DoughnutChart';
import { LineChart } from '../charts/LineChart';
import { CustomerAnalytics } from '@/types/report';
import { formatUSACurrency } from '@/utils/usaCalendar';
import { formatUSADate } from '@/utils/dateUtils';
import { exportToPDF, ExportData } from '@/utils/exportUtils';
import { format } from 'date-fns';

interface CustomerAnalyticsComponentProps {
  report: CustomerAnalytics;
  isLoading?: boolean;
}

export default function CustomerAnalyticsComponent({ report, isLoading = false }: CustomerAnalyticsComponentProps) {
  const { t } = useTranslation();
  const segmentChartRef = useRef();
  const purchasePatternRef = useRef();

  const customerSegmentData = {
    labels: report.customersBySegment.map((seg) => t(seg.segment)),
    datasets: [
    {
      data: report.customersBySegment.map((seg) => seg.revenue),
      backgroundColor: [
      'rgba(251, 191, 36, 0.8)',
      'rgba(59, 130, 246, 0.8)',
      'rgba(34, 197, 94, 0.8)'],

      borderColor: [
      'rgb(251, 191, 36)',
      'rgb(59, 130, 246)',
      'rgb(34, 197, 94)'],

      borderWidth: 2
    }]

  };

  const purchasePatternData = {
    labels: Array.from({ length: 24 }, (_, i) => `${i}:00`),
    datasets: [
    {
      label: t('Orders'),
      data: report.purchasePatterns.map((p) => p.orders),
      borderColor: 'rgb(168, 85, 247)',
      backgroundColor: 'rgba(168, 85, 247, 0.1)',
      tension: 0.4
    }]

  };

  const handleExportPDF = () => {
    const exportData: ExportData = {
      title: t('Customer Analytics Report'),
      headers: [t('Customer'), t('Total Spent'), t('Orders'), t('Last Purchase')],
      rows: report.topCustomers.map((customer) => [
      customer.name,
      formatUSACurrency(customer.totalSpent),
      customer.orderCount.toString(),
      format(customer.lastPurchase, 'MM/dd/yyyy')]
      ),
      summary: {
        [t('Total Customers')]: report.totalCustomers,
        [t('Active Customers')]: report.activeCustomers,
        [t('New Customers')]: report.newCustomers
      }
    };

    exportToPDF(exportData);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) =>
          <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">{t('Customer Analytics')}</h2>
          <p className="text-muted-foreground">{formatUSADate(new Date())}</p>
        </div>
        <Button onClick={handleExportPDF} variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          {t('Export PDF')}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Total Customers')}</p>
                <p className="text-2xl font-bold">{report.totalCustomers}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Crown className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('Active Customers')}</p>
                <p className="text-2xl font-bold">{report.activeCustomers}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <UserPlus className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">{t('New Customers')}</p>
                <p className="text-2xl font-bold">{report.newCustomers}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>{t('Revenue by Customer Segment')}</CardTitle>
          </CardHeader>
          <CardContent>
            <DoughnutChart ref={segmentChartRef} data={customerSegmentData} height={300} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t('Purchase Patterns by Hour')}</CardTitle>
          </CardHeader>
          <CardContent>
            <LineChart ref={purchasePatternRef} data={purchasePatternData} height={300} />
          </CardContent>
        </Card>
      </div>

      {/* Customer Segments Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t('Customer Segments')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('Segment')}</TableHead>
                <TableHead className="text-right">{t('Customers')}</TableHead>
                <TableHead className="text-right">{t('Revenue')}</TableHead>
                <TableHead className="text-right">{t('Avg Revenue')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {report.customersBySegment.map((segment) =>
              <TableRow key={segment.segment}>
                  <TableCell className="font-medium">
                    <Badge variant={segment.segment === 'VIP' ? 'default' : segment.segment === 'Regular' ? 'secondary' : 'outline'}>
                      {t(segment.segment)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">{segment.count}</TableCell>
                  <TableCell className="text-right font-semibold">
                    {formatUSACurrency(segment.revenue)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatUSACurrency(segment.revenue / segment.count)}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Top Customers */}
      <Card>
        <CardHeader>
          <CardTitle>{t('Top Customers')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('Customer')}</TableHead>
                <TableHead className="text-right">{t('Total Spent')}</TableHead>
                <TableHead className="text-right">{t('Orders')}</TableHead>
                <TableHead className="text-right">{t('Last Purchase')}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {report.topCustomers.slice(0, 10).map((customer, index) =>
              <TableRow key={customer.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {customer.name}
                      {index < 3 && <Badge variant="secondary">#{index + 1}</Badge>}
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-semibold">
                    {formatUSACurrency(customer.totalSpent)}
                  </TableCell>
                  <TableCell className="text-right">{customer.orderCount}</TableCell>
                  <TableCell className="text-right">
                    {format(customer.lastPurchase, 'MM/dd/yyyy')}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>);

}