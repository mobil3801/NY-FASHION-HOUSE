
import React from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { ReportFilter } from '@/types/report';

interface ReportFiltersProps {
  filter: ReportFilter;
  onFilterChange: (filter: ReportFilter) => void;
  onApplyFilter: () => void;
  showCustomerFilter?: boolean;
  showProductFilter?: boolean;
  showEmployeeFilter?: boolean;
  isLoading?: boolean;
}

export default function ReportFilters({
  filter,
  onFilterChange,
  onApplyFilter,
  showCustomerFilter = false,
  showProductFilter = false,
  showEmployeeFilter = false,
  isLoading = false
}: ReportFiltersProps) {
  const { t } = useTranslation();

  const handlePeriodChange = (period: 'daily' | 'weekly' | 'monthly' | 'yearly') => {
    try {
      const today = new Date();
      let startDate: Date;
      let endDate: Date = new Date(today);

      switch (period) {
        case 'daily':
          startDate = new Date(today);
          break;
        case 'weekly':
          startDate = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 7);
          break;
        case 'monthly':
          startDate = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());
          break;
        case 'yearly':
          startDate = new Date(today.getFullYear() - 1, today.getMonth(), today.getDate());
          break;
        default:
          startDate = new Date(today);
      }

      // Validate dates
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        console.error('[ReportFilters] Invalid date generated:', { startDate, endDate, period });
        return;
      }

      onFilterChange({ ...filter, period, startDate, endDate });
    } catch (error) {
      console.error('[ReportFilters] Error in handlePeriodChange:', error);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('Filter Reports')}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Period Selection */}
          <div className="space-y-2">
            <Label>{t('Period')}</Label>
            <Select value={filter.period} onValueChange={handlePeriodChange}>
              <SelectTrigger>
                <SelectValue placeholder={t('Select period')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">{t('Daily')}</SelectItem>
                <SelectItem value="weekly">{t('Weekly')}</SelectItem>
                <SelectItem value="monthly">{t('Monthly')}</SelectItem>
                <SelectItem value="yearly">{t('Yearly')}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Start Date */}
          <div className="space-y-2">
            <Label>{t('Start Date')}</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filter.startDate && "text-muted-foreground"
                  )}>

                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filter.startDate ?
                  format(filter.startDate, "MM/dd/yyyy") :

                  <span>{t('Pick a date')}</span>
                  }
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={filter.startDate}
                  onSelect={(date) => {
                    if (date && !isNaN(date.getTime())) {
                      onFilterChange({ ...filter, startDate: date });
                    }
                  }}
                  initialFocus />

              </PopoverContent>
            </Popover>
          </div>

          {/* End Date */}
          <div className="space-y-2">
            <Label>{t('End Date')}</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filter.endDate && "text-muted-foreground"
                  )}>

                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filter.endDate ?
                  format(filter.endDate, "MM/dd/yyyy") :

                  <span>{t('Pick a date')}</span>
                  }
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={filter.endDate}
                  onSelect={(date) => {
                    if (date && !isNaN(date.getTime())) {
                      onFilterChange({ ...filter, endDate: date });
                    }
                  }}
                  initialFocus />

              </PopoverContent>
            </Popover>
          </div>

          {/* Apply Button */}
          <div className="space-y-2">
            <Label className="invisible">Apply</Label>
            <Button
              onClick={onApplyFilter}
              className="w-full"
              disabled={isLoading || !filter.startDate || !filter.endDate}>

              {isLoading ?
              <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  {t('Loading...')}
                </> :

              t('Apply Filter')
              }
            </Button>
            
            {(!filter.startDate || !filter.endDate) &&
            <div className="flex items-center gap-1 text-xs text-amber-600">
                <AlertCircle className="h-3 w-3" />
                <span>{t('Please select both start and end dates')}</span>
              </div>
            }
          </div>
        </div>

        {/* Additional Filters */}
        {(showCustomerFilter || showProductFilter || showEmployeeFilter) &&
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
            {showCustomerFilter &&
          <div className="space-y-2">
                <Label>{t('Customer')}</Label>
                <Input
              placeholder={t('Customer ID or Name')}
              value={filter.customerId || ''}
              onChange={(e) => onFilterChange({ ...filter, customerId: e.target.value })} />

              </div>
          }

            {showProductFilter &&
          <div className="space-y-2">
                <Label>{t('Product')}</Label>
                <Input
              placeholder={t('Product ID or Name')}
              value={filter.productId || ''}
              onChange={(e) => onFilterChange({ ...filter, productId: e.target.value })} />

              </div>
          }

            {showEmployeeFilter &&
          <div className="space-y-2">
                <Label>{t('Employee')}</Label>
                <Input
              placeholder={t('Employee ID or Name')}
              value={filter.employeeId || ''}
              onChange={(e) => onFilterChange({ ...filter, employeeId: e.target.value })} />

              </div>
          }
          </div>
        }
      </CardContent>
    </Card>);

}