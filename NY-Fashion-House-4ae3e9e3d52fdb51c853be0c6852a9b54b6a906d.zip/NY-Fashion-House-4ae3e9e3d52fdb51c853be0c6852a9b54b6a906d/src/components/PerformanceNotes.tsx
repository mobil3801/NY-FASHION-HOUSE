
import React, { useState, useEffect } from 'react';
import { PerformanceNote } from '@/types/employee';
import { employeeService } from '@/services/employeeService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import {
  Plus,
  Star,
  TrendingUp,
  AlertTriangle,
  Target,
  FileText,
  Calendar,
  User } from
'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface PerformanceNotesProps {
  employeeId: string;
  employeeName: string;
  onNotesUpdate: () => void;
}

const PerformanceNotes: React.FC<PerformanceNotesProps> = ({
  employeeId,
  employeeName,
  onNotesUpdate
}) => {
  const [notes, setNotes] = useState<PerformanceNote[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [newNote, setNewNote] = useState({
    type: 'achievement' as const,
    title: '',
    description: '',
    rating: 5,
    reviewDate: format(new Date(), 'yyyy-MM-dd'),
    followUpDate: '',
    status: 'open' as const
  });

  useEffect(() => {
    loadNotes();
  }, [employeeId]);

  const loadNotes = async () => {
    setLoading(true);
    try {
      const data = await employeeService.getPerformanceNotesByEmployee(employeeId);
      setNotes(data);
    } catch (error) {
      console.error('Failed to load performance notes:', error);
      toast.error('Failed to load performance notes');
    } finally {
      setLoading(false);
    }
  };

  const handleAddNote = async () => {
    if (!newNote.title.trim() || !newNote.description.trim()) {
      toast.error('Title and description are required');
      return;
    }

    setLoading(true);
    try {
      await employeeService.createPerformanceNote({
        employeeId,
        type: newNote.type,
        title: newNote.title,
        description: newNote.description,
        rating: newNote.rating,
        reviewDate: newNote.reviewDate,
        reviewerId: 'current-user', // In a real app, this would be the current user's ID
        followUpDate: newNote.followUpDate || undefined,
        status: newNote.status
      });

      toast.success('Performance note added successfully');
      setIsDialogOpen(false);
      setNewNote({
        type: 'achievement',
        title: '',
        description: '',
        rating: 5,
        reviewDate: format(new Date(), 'yyyy-MM-dd'),
        followUpDate: '',
        status: 'open'
      });
      loadNotes();
      onNotesUpdate();
    } catch (error) {
      console.error('Failed to add performance note:', error);
      toast.error('Failed to add performance note');
    } finally {
      setLoading(false);
    }
  };

  const updateNoteStatus = async (noteId: string, status: PerformanceNote['status']) => {
    try {
      await employeeService.updatePerformanceNote(noteId, { status });
      toast.success('Note status updated');
      loadNotes();
    } catch (error) {
      console.error('Failed to update note status:', error);
      toast.error('Failed to update note status');
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'achievement':
        return <Star className="h-4 w-4 text-yellow-500" />;
      case 'improvement':
        return <TrendingUp className="h-4 w-4 text-blue-500" />;
      case 'disciplinary':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'goal':
        return <Target className="h-4 w-4 text-green-500" />;
      case 'review':
        return <FileText className="h-4 w-4 text-purple-500" />;
      default:
        return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'achievement':
        return 'bg-yellow-100 text-yellow-800';
      case 'improvement':
        return 'bg-blue-100 text-blue-800';
      case 'disciplinary':
        return 'bg-red-100 text-red-800';
      case 'goal':
        return 'bg-green-100 text-green-800';
      case 'review':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-blue-100 text-blue-800';
      case 'in-progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) =>
    <Star
      key={i}
      className={`h-4 w-4 ${
      i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`
      } />

    );
  };

  const stats = {
    total: notes.length,
    achievements: notes.filter((note) => note.type === 'achievement').length,
    improvements: notes.filter((note) => note.type === 'improvement').length,
    averageRating: notes.length > 0 ?
    (notes.reduce((sum, note) => sum + (note.rating || 0), 0) / notes.length).toFixed(1) :
    '0.0'
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Performance Notes</h2>
          <p className="text-gray-600">{employeeName}</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Note
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add Performance Note</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select
                    value={newNote.type}
                    onValueChange={(value: any) => setNewNote({ ...newNote, type: value })}>

                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="achievement">Achievement</SelectItem>
                      <SelectItem value="improvement">Improvement</SelectItem>
                      <SelectItem value="disciplinary">Disciplinary</SelectItem>
                      <SelectItem value="goal">Goal</SelectItem>
                      <SelectItem value="review">Review</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="rating">Rating (1-5)</Label>
                  <Select
                    value={newNote.rating.toString()}
                    onValueChange={(value) => setNewNote({ ...newNote, rating: parseInt(value) })}>

                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5].map((num) =>
                      <SelectItem key={num} value={num.toString()}>
                          {num} Star{num !== 1 ? 's' : ''}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={newNote.title}
                  onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
                  placeholder="Enter a title for this note..." />

              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newNote.description}
                  onChange={(e) => setNewNote({ ...newNote, description: e.target.value })}
                  placeholder="Provide detailed information about this performance note..."
                  className="min-h-32" />

              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="reviewDate">Review Date</Label>
                  <Input
                    id="reviewDate"
                    type="date"
                    value={newNote.reviewDate}
                    onChange={(e) => setNewNote({ ...newNote, reviewDate: e.target.value })} />

                </div>

                <div>
                  <Label htmlFor="followUpDate">Follow-up Date (Optional)</Label>
                  <Input
                    id="followUpDate"
                    type="date"
                    value={newNote.followUpDate}
                    onChange={(e) => setNewNote({ ...newNote, followUpDate: e.target.value })} />

                </div>
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select
                  value={newNote.status}
                  onValueChange={(value: any) => setNewNote({ ...newNote, status: value })}>

                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2 mt-6">
                <Button
                  onClick={handleAddNote}
                  disabled={loading}
                  className="flex-1">

                  {loading ? 'Adding...' : 'Add Note'}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1">

                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Total Notes</p>
              <p className="text-2xl font-bold text-blue-600">{stats.total}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Achievements</p>
              <p className="text-2xl font-bold text-yellow-600">{stats.achievements}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Improvements</p>
              <p className="text-2xl font-bold text-green-600">{stats.improvements}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Avg Rating</p>
              <p className="text-2xl font-bold text-purple-600">{stats.averageRating}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Notes List */}
      <Card>
        <CardHeader>
          <CardTitle>Performance History</CardTitle>
        </CardHeader>
        <CardContent>
          {notes.length === 0 ?
          <div className="text-center py-8">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No performance notes</h3>
              <p className="text-gray-600 mb-4">Start by adding the first performance note.</p>
              <Button onClick={() => setIsDialogOpen(true)} className="flex items-center gap-2 mx-auto">
                <Plus className="h-4 w-4" />
                Add First Note
              </Button>
            </div> :

          <div className="space-y-4">
              {notes.map((note) =>
            <div key={note.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      {getTypeIcon(note.type)}
                      <div>
                        <h3 className="font-semibold text-lg">{note.title}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className={getTypeColor(note.type)}>
                            {note.type}
                          </Badge>
                          <Badge className={getStatusColor(note.status)}>
                            {note.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      {note.rating &&
                  <div className="flex items-center gap-1 mb-2">
                          {renderStars(note.rating)}
                        </div>
                  }
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(note.reviewDate), 'MMM d, yyyy')}
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-700 mb-3 leading-relaxed">{note.description}</p>

                  {note.followUpDate &&
              <div className="flex items-center gap-2 text-sm text-orange-600 mb-3">
                      <Calendar className="h-3 w-3" />
                      Follow-up: {format(new Date(note.followUpDate), 'MMM d, yyyy')}
                    </div>
              }

                  <div className="flex items-center justify-between pt-3 border-t">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <User className="h-3 w-3" />
                      Reviewed by: {note.reviewerId}
                    </div>
                    
                    {note.status !== 'completed' && note.status !== 'cancelled' &&
                <div className="flex gap-2">
                        <Button
                    size="sm"
                    variant="outline"
                    onClick={() => updateNoteStatus(note.id, 'in-progress')}
                    disabled={note.status === 'in-progress'}>

                          In Progress
                        </Button>
                        <Button
                    size="sm"
                    variant="outline"
                    onClick={() => updateNoteStatus(note.id, 'completed')}
                    className="text-green-600">

                          Complete
                        </Button>
                      </div>
                }
                  </div>
                </div>
            )}
            </div>
          }
        </CardContent>
      </Card>
    </div>);

};

export default PerformanceNotes;