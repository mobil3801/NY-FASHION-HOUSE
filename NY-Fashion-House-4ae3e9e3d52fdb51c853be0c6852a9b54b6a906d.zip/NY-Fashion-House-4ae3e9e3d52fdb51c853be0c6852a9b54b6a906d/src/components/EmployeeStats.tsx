import React, { useState, useEffect } from 'react';
import { employeeService } from '@/services/employeeService';
import { EmployeeStats as StatsType } from '@/types/employee';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Users,
  UserCheck,
  UserPlus,
  TrendingUp,
  Calendar,
  BarChart3 } from
'lucide-react';
import { toast } from 'sonner';

const EmployeeStats: React.FC = () => {
  const [stats, setStats] = useState<StatsType | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setIsLoading(true);
      const statsData = await employeeService.getEmployeeStats();
      setStats(statsData);
    } catch (error) {
      console.error('Error loading employee stats:', error);
      toast.error('Failed to load employee statistics');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.from({ length: 6 }).map((_, i) =>
        <Card key={i}>
            <CardContent className="p-6">
              <div className="animate-pulse space-y-3">
                <div className="h-4 bg-gray-200 rounded w-1/2" />
                <div className="h-8 bg-gray-200 rounded w-3/4" />
                <div className="h-3 bg-gray-200 rounded w-full" />
              </div>
            </CardContent>
          </Card>
        )}
      </div>);

  }

  if (!stats) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">No statistics available</p>
      </div>);

  }

  const statCards = [
  {
    title: 'Total Employees',
    value: stats.totalEmployees,
    icon: Users,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  {
    title: 'Active Employees',
    value: stats.activeEmployees,
    icon: UserCheck,
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  {
    title: 'New Hires This Month',
    value: stats.newHiresThisMonth,
    icon: UserPlus,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50'
  },
  {
    title: 'Average Tenure',
    value: `${stats.averageTenure.toFixed(1)} years`,
    icon: Calendar,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50'
  },
  {
    title: 'Attendance Rate',
    value: `${stats.attendanceRate}%`,
    icon: TrendingUp,
    color: 'text-teal-600',
    bgColor: 'bg-teal-50'
  },
  {
    title: 'Performance Average',
    value: `${stats.performanceAverage}/5.0`,
    icon: BarChart3,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50'
  }];


  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {statCards.map((stat) =>
        <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {stat.title}
              </CardTitle>
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Department Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Department Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(stats.departmentBreakdown).map(([department, count]) =>
            <div key={department} className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">{department}</span>
                <div className="flex items-center space-x-2">
                  <div className="w-20 bg-gray-200 rounded-full h-2">
                    <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${count / stats.totalEmployees * 100}%` }} />

                  </div>
                  <Badge variant="secondary">{count}</Badge>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default EmployeeStats;