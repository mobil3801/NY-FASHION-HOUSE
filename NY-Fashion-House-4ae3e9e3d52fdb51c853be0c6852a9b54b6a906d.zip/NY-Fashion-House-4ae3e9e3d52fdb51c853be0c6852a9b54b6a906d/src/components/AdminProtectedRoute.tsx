
import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

interface AdminProtectedRouteProps {
  children: React.ReactNode;
}

interface UserInfo {
  ID: number;
  Name: string;
  Email: string;
  CreateTime: string;
  Roles: string;
}

const AdminProtectedRoute: React.FC<AdminProtectedRouteProps> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);

  useEffect(() => {
    const checkAdminAccess = async () => {
      try {
        const { data: userInfo, error } = await window.ezsite.apis.getUserInfo();

        if (error) {
          throw new Error(error);
        }

        if (!userInfo) {
          setIsAuthorized(false);
          return;
        }

        // Check if user has Administrator role
        const roles = userInfo.Roles ? userInfo.Roles.split(',') : [];
        const hasAdminRole = roles.includes('Administrator');

        if (hasAdminRole) {
          setIsAuthorized(true);
          setUserInfo(userInfo);
        } else {
          setIsAuthorized(false);
          toast.error('Access denied. Administrator role required.');
        }
      } catch (error) {
        console.error('Error checking admin access:', error);
        setIsAuthorized(false);
        toast.error('Authentication error. Please log in again.');
      } finally {
        setIsLoading(false);
      }
    };

    checkAdminAccess();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Verifying admin access...</p>
        </div>
      </div>);

  }

  if (!isAuthorized) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export default AdminProtectedRoute;