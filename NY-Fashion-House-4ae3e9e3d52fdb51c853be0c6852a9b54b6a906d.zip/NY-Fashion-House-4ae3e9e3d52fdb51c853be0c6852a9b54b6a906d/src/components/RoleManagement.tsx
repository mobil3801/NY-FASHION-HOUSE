import React, { useState, useEffect } from 'react';
import { employeeService } from '@/services/employeeService';
import { EmployeeRole, Permission } from '@/types/employee';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Shield,
  Users,
  Plus,
  Settings,
  Eye,
  Edit,
  Trash2 } from
'lucide-react';
import { toast } from 'sonner';

const RoleManagement: React.FC = () => {
  const [roles, setRoles] = useState<EmployeeRole[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [rolesData, permissionsData] = await Promise.all([
      employeeService.getAllRoles(),
      employeeService.getAllPermissions()]
      );
      setRoles(rolesData);
      setPermissions(permissionsData);
    } catch (error) {
      console.error('Error loading role data:', error);
      toast.error('Failed to load role information');
    } finally {
      setIsLoading(false);
    }
  };

  const getPermissionsByModule = (rolePermissions: Permission[]) => {
    const modules: {[key: string]: Permission[];} = {};
    rolePermissions.forEach((permission) => {
      if (!modules[permission.module]) {
        modules[permission.module] = [];
      }
      modules[permission.module].push(permission);
    });
    return modules;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Array.from({ length: 4 }).map((_, i) =>
          <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-1/3" />
                  <div className="h-3 bg-gray-200 rounded w-2/3" />
                  <div className="space-y-2">
                    <div className="h-2 bg-gray-200 rounded w-full" />
                    <div className="h-2 bg-gray-200 rounded w-3/4" />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-gray-600" />
          <h2 className="text-xl font-semibold text-gray-900">Role Management</h2>
        </div>
        <Button className="flex items-center gap-2" disabled>
          <Plus className="h-4 w-4" />
          Add Role (Coming Soon)
        </Button>
      </div>

      {/* Roles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {roles.map((role) => {
          const permissionModules = getPermissionsByModule(role.permissions);

          return (
            <Card key={role.id} className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-blue-600" />
                      {role.name}
                    </CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{role.description}</p>
                  </div>
                  <Badge variant="outline" className="ml-2">
                    {role.permissions.length} permissions
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Permission Modules */}
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Permissions by Module</h4>
                  <div className="space-y-2">
                    {Object.entries(permissionModules).map(([module, modulePermissions]) =>
                    <div key={module} className="flex items-center justify-between text-sm">
                        <span className="text-gray-600 capitalize">{module}</span>
                        <div className="flex gap-1">
                          {modulePermissions.map((permission) =>
                        <Badge
                          key={permission.id}
                          variant="secondary"
                          className="text-xs">

                              {permission.action}
                            </Badge>
                        )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Sample Permissions Display */}
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Key Permissions</h4>
                  <div className="flex flex-wrap gap-1">
                    {role.permissions.slice(0, 4).map((permission) =>
                    <Badge key={permission.id} variant="outline" className="text-xs">
                        {permission.name}
                      </Badge>
                    )}
                    {role.permissions.length > 4 &&
                    <Badge variant="outline" className="text-xs">
                        +{role.permissions.length - 4} more
                      </Badge>
                    }
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 pt-2 border-t">
                  <Button variant="outline" size="sm" className="flex-1" disabled>
                    <Eye className="h-3 w-3 mr-1" />
                    View
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1" disabled>
                    <Edit className="h-3 w-3 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    disabled>

                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>);

        })}
      </div>

      {/* Permission Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            System Permissions Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {permissions.map((permission) =>
            <div key={permission.id} className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-sm">{permission.name}</span>
                  <Badge variant="secondary" className="text-xs">
                    {permission.module}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600">{permission.description}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default RoleManagement;