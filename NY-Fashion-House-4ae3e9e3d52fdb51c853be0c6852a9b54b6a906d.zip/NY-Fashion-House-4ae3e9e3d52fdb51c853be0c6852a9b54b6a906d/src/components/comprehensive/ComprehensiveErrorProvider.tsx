import React, { createContext, useContext, useCallback, useEffect, useState, ReactNode } from 'react';
import { comprehensiveErrorManager, ErrorMetadata, ErrorAnalysis } from '../../services/comprehensiveErrorManager';
import { ComprehensiveErrorBoundary } from './ComprehensiveErrorBoundary';
import { toast } from '../../hooks/use-toast';

interface ErrorContextValue {
  errors: ErrorMetadata[];
  analysis: ErrorAnalysis | null;
  captureError: (error: Error, context?: Record<string, any>) => string;
  clearErrors: () => void;
  getErrorsByComponent: (component: string) => ErrorMetadata[];
  subscribeToErrors: (callback: (error: ErrorMetadata) => void) => () => void;
  exportErrors: () => string;
  isLoading: boolean;
}

const ErrorContext = createContext<ErrorContextValue | undefined>(undefined);

interface Props {
  children: ReactNode;
  enableAnalytics?: boolean;
  enableToasts?: boolean;
  toastCriticalErrors?: boolean;
  onCriticalError?: (error: ErrorMetadata) => void;
}

export const ComprehensiveErrorProvider: React.FC<Props> = ({
  children,
  enableAnalytics = true,
  enableToasts = true,
  toastCriticalErrors = true,
  onCriticalError
}) => {
  const [errors, setErrors] = useState<ErrorMetadata[]>([]);
  const [analysis, setAnalysis] = useState<ErrorAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const captureError = useCallback((error: Error, context?: Record<string, any>): string => {
    const errorId = comprehensiveErrorManager.captureError(error, {
      context,
      component: context?.component,
      category: context?.category || 'ui',
      level: context?.level || 'error'
    });

    // Show toast notification if enabled
    if (enableToasts) {
      const severity = context?.level || 'error';
      if (severity === 'critical' && toastCriticalErrors) {
        toast({
          title: 'Critical Error Detected',
          description: error.message,
          variant: 'destructive'
        });
      } else if (severity === 'error') {
        toast({
          title: 'Error Occurred',
          description: error.message,
          variant: 'destructive'
        });
      }
    }

    return errorId;
  }, [enableToasts, toastCriticalErrors]);

  const clearErrors = useCallback(() => {
    comprehensiveErrorManager.clearErrors();
    setErrors([]);
    setAnalysis(null);
  }, []);

  const getErrorsByComponent = useCallback((component: string): ErrorMetadata[] => {
    return comprehensiveErrorManager.getErrors({ component });
  }, []);

  const subscribeToErrors = useCallback((callback: (error: ErrorMetadata) => void): (() => void) => {
    return comprehensiveErrorManager.subscribe(callback);
  }, []);

  const exportErrors = useCallback((): string => {
    return comprehensiveErrorManager.exportErrors();
  }, []);

  const updateAnalysis = useCallback(() => {
    if (enableAnalytics) {
      const newAnalysis = comprehensiveErrorManager.generateAnalysis();
      setAnalysis(newAnalysis);

      // Check for critical errors
      newAnalysis.criticalErrors.forEach((error) => {
        if (onCriticalError) {
          onCriticalError(error);
        }
      });
    }
  }, [enableAnalytics, onCriticalError]);

  useEffect(() => {
    // Subscribe to new errors
    const unsubscribe = comprehensiveErrorManager.subscribe((error: ErrorMetadata) => {
      setErrors((prev) => [error, ...prev.slice(0, 99)]); // Keep last 100 errors

      // Update analysis periodically
      setTimeout(updateAnalysis, 1000);
    });

    // Initial load
    setErrors(comprehensiveErrorManager.getErrors());
    updateAnalysis();
    setIsLoading(false);

    // Periodic analysis update
    const analysisInterval = setInterval(updateAnalysis, 30000); // Every 30 seconds

    return () => {
      unsubscribe();
      clearInterval(analysisInterval);
    };
  }, [updateAnalysis]);

  const contextValue: ErrorContextValue = {
    errors,
    analysis,
    captureError,
    clearErrors,
    getErrorsByComponent,
    subscribeToErrors,
    exportErrors,
    isLoading
  };

  return (
    <ErrorContext.Provider value={contextValue}>
      <ComprehensiveErrorBoundary
        fallbackType="detailed"
        showRetry={true}
        showReporting={true}>

        {children}
      </ComprehensiveErrorBoundary>
    </ErrorContext.Provider>);

};

export const useError = (): ErrorContextValue => {
  const context = useContext(ErrorContext);
  if (context === undefined) {
    throw new Error('useError must be used within a ComprehensiveErrorProvider');
  }
  return context;
};

export default ComprehensiveErrorProvider;