import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '../ui/collapsible';
import { ScrollArea } from '../ui/scroll-area';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import {
  BookOpen,
  Code2,
  AlertTriangle,
  CheckCircle,
  XCircle,
  ChevronDown,
  ChevronRight,
  Play,
  Download,
  ExternalLink } from
'lucide-react';

interface DocumentationProps {
  showInteractiveExamples?: boolean;
  enableQuizMode?: boolean;
}

export const ErrorHandlingDocumentation: React.FC<DocumentationProps> = ({
  showInteractiveExamples = true,
  enableQuizMode = true
}) => {
  const [activeExample, setActiveExample] = useState<string | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, string>>({});
  const [showQuizResults, setShowQuizResults] = useState(false);

  const bestPractices = [
  {
    title: 'Use Error Boundaries Strategically',
    description: 'Place error boundaries at key component levels to prevent full app crashes',
    example: `// Good: Strategic placement
<ComprehensiveErrorBoundary fallbackType="detailed">
  <UserDashboard />
</ComprehensiveErrorBoundary>

<ComprehensiveErrorBoundary fallbackType="minimal">
  <OptionalWidget />
</ComprehensiveErrorBoundary>`,
    dos: [
    'Place at route level components',
    'Use different fallback types based on importance',
    'Include retry functionality',
    'Capture error metadata'],

    donts: [
    'Wrap every single component',
    'Use the same fallback everywhere',
    'Ignore error context',
    'Skip error reporting']

  },
  {
    title: 'Implement Comprehensive Error Logging',
    description: 'Capture detailed error information for effective debugging',
    example: `// Good: Detailed error capture
const { captureError } = useError();

try {
  await fetchUserData();
} catch (error) {
  captureError(error, {
    component: 'UserDashboard',
    category: 'api',
    level: 'error',
    context: {
      userId,
      action: 'fetchUserData',
      timestamp: Date.now()
    }
  });
}`,
    dos: [
    'Include relevant context',
    'Categorize errors properly',
    'Add component information',
    'Set appropriate error levels'],

    donts: [
    'Log sensitive information',
    'Capture too much noise',
    'Skip error categorization',
    'Ignore performance impact']

  },
  {
    title: 'Handle Async Operations Properly',
    description: 'Implement proper error handling for promises and async operations',
    example: `// Good: Proper async error handling
const [data, setData] = useState(null);
const [error, setError] = useState(null);
const [loading, setLoading] = useState(false);

const loadData = async () => {
  try {
    setLoading(true);
    setError(null);
    
    const result = await api.getData();
    setData(result);
  } catch (err) {
    setError(err);
    captureError(err, { 
      context: { action: 'loadData' } 
    });
  } finally {
    setLoading(false);
  }
};`,
    dos: [
    'Handle loading states',
    'Clear previous errors',
    'Use proper try-catch',
    'Show user feedback'],

    donts: [
    'Ignore promise rejections',
    'Leave users hanging',
    'Skip loading indicators',
    'Forget cleanup']

  },
  {
    title: 'Provide User-Friendly Error Messages',
    description: 'Show helpful, actionable error messages to users',
    example: `// Good: User-friendly error display
const ErrorMessage = ({ error }) => {
  const getMessage = (error) => {
    if (error.code === 'NETWORK_ERROR') {
      return 'Unable to connect. Please check your internet connection.';
    }
    if (error.code === 'VALIDATION_ERROR') {
      return 'Please check your input and try again.';
    }
    return 'Something went wrong. Please try again.';
  };

  return (
    <Alert variant="destructive">
      <AlertTriangle className="h-4 w-4" />
      <AlertTitle>Error</AlertTitle>
      <AlertDescription>{getMessage(error)}</AlertDescription>
    </Alert>
  );
};`,
    dos: [
    'Use clear, simple language',
    'Provide actionable guidance',
    'Match error to user context',
    'Include recovery options'],

    donts: [
    'Show technical stack traces',
    'Use developer jargon',
    'Leave users confused',
    'Blame the user']

  }];


  const commonPatterns = [
  {
    pattern: 'Network Request Failures',
    description: 'Handle API failures gracefully with retry logic',
    code: `const useApiWithRetry = (url, options = {}) => {
  const [state, setState] = useState({ data: null, loading: true, error: null });
  
  useEffect(() => {
    const fetchWithRetry = async (retries = 3) => {
      try {
        setState(prev => ({ ...prev, loading: true, error: null }));
        const response = await fetch(url, options);
        
        if (!response.ok) {
          throw new Error(\`HTTP \${response.status}: \${response.statusText}\`);
        }
        
        const data = await response.json();
        setState({ data, loading: false, error: null });
      } catch (error) {
        if (retries > 0) {
          setTimeout(() => fetchWithRetry(retries - 1), 1000);
        } else {
          setState(prev => ({ ...prev, loading: false, error }));
        }
      }
    };
    
    fetchWithRetry();
  }, [url]);
  
  return state;
};`
  },
  {
    pattern: 'Form Validation Errors',
    description: 'Display field-specific validation errors',
    code: `const FormWithValidation = () => {
  const [errors, setErrors] = useState({});
  
  const validateField = (name, value) => {
    const newErrors = { ...errors };
    
    if (name === 'email' && !value.includes('@')) {
      newErrors.email = 'Please enter a valid email address';
    } else {
      delete newErrors.email;
    }
    
    setErrors(newErrors);
  };
  
  return (
    <form>
      <input
        type="email"
        onChange={(e) => validateField('email', e.target.value)}
      />
      {errors.email && (
        <span className="text-red-500 text-sm">{errors.email}</span>
      )}
    </form>
  );
};`
  },
  {
    pattern: 'Component Error Recovery',
    description: 'Allow components to recover from errors',
    code: `const RecoverableComponent = () => {
  const [error, setError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  
  const retry = () => {
    setError(null);
    setRetryCount(prev => prev + 1);
  };
  
  if (error) {
    return (
      <div className="error-state">
        <p>Something went wrong</p>
        <Button onClick={retry}>Try Again</Button>
      </div>
    );
  }
  
  return (
    <ErrorBoundary onError={setError} key={retryCount}>
      <YourComponent />
    </ErrorBoundary>
  );
};`
  }];


  const quizQuestions = [
  {
    id: 'q1',
    question: 'When should you use error boundaries?',
    options: [
    'Around every single component',
    'Only at the root level',
    'At strategic component levels like routes and major sections',
    'Never, they are not needed'],

    correct: 2,
    explanation: 'Error boundaries should be placed strategically at component levels that make sense for isolation, such as routes and major application sections.'
  },
  {
    id: 'q2',
    question: 'What information should be included when logging errors?',
    options: [
    'Only the error message',
    'Error message, stack trace, and user passwords',
    'Error message, component context, user ID, and relevant metadata',
    'Just the timestamp'],

    correct: 2,
    explanation: 'Error logs should include relevant context like component information, user ID (when appropriate), and metadata, but never sensitive information like passwords.'
  },
  {
    id: 'q3',
    question: 'How should error messages be displayed to users?',
    options: [
    'Show the full stack trace',
    'Display technical error codes',
    'Use clear, actionable language with recovery options',
    'Hide all errors from users'],

    correct: 2,
    explanation: 'Error messages should use clear, user-friendly language and provide actionable guidance for recovery when possible.'
  }];


  const runExample = (exampleCode: string) => {
    try {
      // This would run the example in a safe environment
      console.log('Running example:', exampleCode);
      setActiveExample(exampleCode);
    } catch (error) {
      console.error('Error running example:', error);
    }
  };

  const submitQuiz = () => {
    setShowQuizResults(true);
  };

  const getQuizScore = () => {
    let correct = 0;
    quizQuestions.forEach((question) => {
      if (parseInt(quizAnswers[question.id]) === question.correct) {
        correct++;
      }
    });
    return { correct, total: quizQuestions.length };
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <BookOpen className="h-6 w-6" />
        <h1 className="text-3xl font-bold">Error Handling Documentation</h1>
      </div>

      <Tabs defaultValue="guide" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="guide">Quick Start Guide</TabsTrigger>
          <TabsTrigger value="practices">Best Practices</TabsTrigger>
          <TabsTrigger value="patterns">Common Patterns</TabsTrigger>
          <TabsTrigger value="quiz">Training Quiz</TabsTrigger>
        </TabsList>

        <TabsContent value="guide" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Getting Started with Error Handling</CardTitle>
              <CardDescription>
                A step-by-step guide to implementing robust error handling in your React application
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold">
                    1
                  </div>
                  <div>
                    <h3 className="font-semibold">Wrap your app with ErrorProvider</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Add the ComprehensiveErrorProvider at your app root
                    </p>
                    <pre className="bg-muted p-2 rounded text-xs mt-2 overflow-x-auto">
                      {`import { ComprehensiveErrorProvider } from './components/comprehensive/ComprehensiveErrorProvider';

function App() {
  return (
    <ComprehensiveErrorProvider>
      <Router>
        <Routes>
          {/* Your routes */}
        </Routes>
      </Router>
    </ComprehensiveErrorProvider>
  );
}`}
                    </pre>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold">
                    2
                  </div>
                  <div>
                    <h3 className="font-semibold">Add error boundaries to key components</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Wrap important sections with ComprehensiveErrorBoundary
                    </p>
                    <pre className="bg-muted p-2 rounded text-xs mt-2 overflow-x-auto">
                      {`import { ComprehensiveErrorBoundary } from './components/comprehensive/ComprehensiveErrorBoundary';

<ComprehensiveErrorBoundary fallbackType="detailed">
  <UserDashboard />
</ComprehensiveErrorBoundary>`}
                    </pre>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold">
                    3
                  </div>
                  <div>
                    <h3 className="font-semibold">Use the error hook in components</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Capture and handle errors in your components
                    </p>
                    <pre className="bg-muted p-2 rounded text-xs mt-2 overflow-x-auto">
                      {`import { useError } from './components/comprehensive/ComprehensiveErrorProvider';

const MyComponent = () => {
  const { captureError } = useError();
  
  const handleAction = async () => {
    try {
      await someAsyncOperation();
    } catch (error) {
      captureError(error, {
        component: 'MyComponent',
        context: { action: 'handleAction' }
      });
    }
  };
};`}
                    </pre>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="practices" className="space-y-4">
          {bestPractices.map((practice, index) =>
          <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Code2 className="h-5 w-5" />
                  <span>{practice.title}</span>
                </CardTitle>
                <CardDescription>{practice.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Collapsible>
                  <CollapsibleTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      View Example Code
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="mt-4">
                    <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
                      <code>{practice.example}</code>
                    </pre>
                    
                    {showInteractiveExamples &&
                  <Button
                    onClick={() => runExample(practice.example)}
                    className="mt-2"
                    size="sm">

                        <Play className="h-4 w-4 mr-2" />
                        Run Example
                      </Button>
                  }
                  </CollapsibleContent>
                </Collapsible>

                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <h4 className="font-semibold text-green-600 flex items-center mb-2">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Do
                    </h4>
                    <ul className="space-y-1 text-sm">
                      {practice.dos.map((item, i) =>
                    <li key={i} className="flex items-start space-x-2">
                          <span className="text-green-500 mt-1">•</span>
                          <span>{item}</span>
                        </li>
                    )}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-red-600 flex items-center mb-2">
                      <XCircle className="h-4 w-4 mr-2" />
                      Don't
                    </h4>
                    <ul className="space-y-1 text-sm">
                      {practice.donts.map((item, i) =>
                    <li key={i} className="flex items-start space-x-2">
                          <span className="text-red-500 mt-1">•</span>
                          <span>{item}</span>
                        </li>
                    )}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          {commonPatterns.map((pattern, index) =>
          <Card key={index}>
              <CardHeader>
                <CardTitle>{pattern.pattern}</CardTitle>
                <CardDescription>{pattern.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
                  <code>{pattern.code}</code>
                </pre>
                
                {showInteractiveExamples &&
              <div className="flex space-x-2 mt-4">
                    <Button
                  onClick={() => runExample(pattern.code)}
                  size="sm">

                      <Play className="h-4 w-4 mr-2" />
                      Try This Pattern
                    </Button>
                    <Button variant="outline" size="sm">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View in Sandbox
                    </Button>
                  </div>
              }
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="quiz" className="space-y-4">
          {enableQuizMode &&
          <>
              <Card>
                <CardHeader>
                  <CardTitle>Error Handling Knowledge Quiz</CardTitle>
                  <CardDescription>
                    Test your understanding of error handling best practices
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!showQuizResults ?
                <div className="space-y-6">
                      {quizQuestions.map((question, index) =>
                  <div key={question.id} className="space-y-3">
                          <h3 className="font-semibold">
                            {index + 1}. {question.question}
                          </h3>
                          <div className="space-y-2">
                            {question.options.map((option, optionIndex) =>
                      <label key={optionIndex} className="flex items-center space-x-2">
                                <input
                          type="radio"
                          name={question.id}
                          value={optionIndex.toString()}
                          onChange={(e) =>
                          setQuizAnswers((prev) => ({
                            ...prev,
                            [question.id]: e.target.value
                          }))
                          }
                          className="form-radio" />

                                <span className="text-sm">{option}</span>
                              </label>
                      )}
                          </div>
                        </div>
                  )}
                      
                      <Button onClick={submitQuiz} className="w-full">
                        Submit Quiz
                      </Button>
                    </div> :

                <div className="space-y-4">
                      {(() => {
                    const { correct, total } = getQuizScore();
                    const percentage = Math.round(correct / total * 100);
                    return (
                      <>
                            <Alert className={percentage >= 70 ? 'border-green-200' : 'border-yellow-200'}>
                              <AlertTitle>
                                Quiz Results: {correct}/{total} ({percentage}%)
                              </AlertTitle>
                              <AlertDescription>
                                {percentage >= 70 ?
                            'Great job! You have a good understanding of error handling.' :
                            'Consider reviewing the documentation and trying again.'}
                              </AlertDescription>
                            </Alert>
                            
                            {quizQuestions.map((question, index) => {
                          const userAnswer = parseInt(quizAnswers[question.id]);
                          const isCorrect = userAnswer === question.correct;

                          return (
                            <div key={question.id} className="border rounded p-4">
                                  <h3 className="font-semibold mb-2">
                                    {index + 1}. {question.question}
                                  </h3>
                                  <div className="flex items-center space-x-2 mb-2">
                                    {isCorrect ?
                                <CheckCircle className="h-4 w-4 text-green-500" /> :

                                <XCircle className="h-4 w-4 text-red-500" />
                                }
                                    <span className={isCorrect ? 'text-green-600' : 'text-red-600'}>
                                      {isCorrect ? 'Correct' : 'Incorrect'}
                                    </span>
                                  </div>
                                  <p className="text-sm text-muted-foreground">
                                    {question.explanation}
                                  </p>
                                </div>);

                        })}
                            
                            <Button
                          onClick={() => {
                            setShowQuizResults(false);
                            setQuizAnswers({});
                          }}
                          variant="outline">

                              Retake Quiz
                            </Button>
                          </>);

                  })()}
                    </div>
                }
                </CardContent>
              </Card>
            </>
          }
        </TabsContent>
      </Tabs>
    </div>);

};

export default ErrorHandlingDocumentation;