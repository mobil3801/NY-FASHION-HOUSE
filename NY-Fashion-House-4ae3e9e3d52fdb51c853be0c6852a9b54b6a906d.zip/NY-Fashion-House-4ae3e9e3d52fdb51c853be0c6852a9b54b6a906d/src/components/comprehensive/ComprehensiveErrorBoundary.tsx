import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home, Bug, Copy, Download } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '../ui/collapsible';
import { toast } from '../../hooks/use-toast';
import { comprehensiveErrorManager, ErrorMetadata } from '../../services/comprehensiveErrorManager';

interface Props {
  children: ReactNode;
  fallbackType?: 'minimal' | 'detailed' | 'full';
  showRetry?: boolean;
  showReporting?: boolean;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  customFallback?: (error: Error, reset: () => void) => ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorId: string | null;
  isRetrying: boolean;
  retryCount: number;
  showDetails: boolean;
}

export class ComprehensiveErrorBoundary extends Component<Props, State> {
  private maxRetries = 3;
  private retryDelay = 1000;

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: null,
      isRetrying: false,
      retryCount: 0,
      showDetails: false
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return {
      hasError: true,
      error
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    // Capture error with comprehensive metadata
    const errorId = comprehensiveErrorManager.captureError(error, {
      category: 'ui',
      level: 'error',
      component: this.getComponentName(),
      componentStack: errorInfo.componentStack,
      errorBoundary: 'ComprehensiveErrorBoundary',
      context: {
        errorInfo,
        props: this.props,
        retryCount: this.state.retryCount
      }
    });

    this.setState({
      errorInfo,
      errorId
    });

    // Call custom error handler
    this.props.onError?.(error, errorInfo);

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('Error Boundary caught an error:', error);
      console.error('Component Stack:', errorInfo.componentStack);
    }
  }

  private getComponentName(): string {
    try {
      const stack = new Error().stack;
      const match = stack?.match(/at\s+(\w+)/);
      return match?.[1] || 'UnknownComponent';
    } catch {
      return 'UnknownComponent';
    }
  }

  private handleRetry = async (): Promise<void> => {
    if (this.state.retryCount >= this.maxRetries) {
      toast({
        title: 'Maximum retries reached',
        description: 'Please refresh the page or contact support.',
        variant: 'destructive'
      });
      return;
    }

    this.setState({ isRetrying: true });

    // Add delay before retry
    await new Promise((resolve) => setTimeout(resolve, this.retryDelay));

    this.setState((prevState) => ({
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: null,
      isRetrying: false,
      retryCount: prevState.retryCount + 1,
      showDetails: false
    }));

    toast({
      title: 'Retrying...',
      description: `Attempt ${this.state.retryCount + 1} of ${this.maxRetries}`
    });
  };

  private handleRefresh = (): void => {
    window.location.reload();
  };

  private handleGoHome = (): void => {
    window.location.href = '/';
  };

  private handleCopyError = async (): Promise<void> => {
    if (!this.state.error || !this.state.errorInfo) return;

    const errorReport = {
      error: {
        name: this.state.error.name,
        message: this.state.error.message,
        stack: this.state.error.stack
      },
      errorInfo: this.state.errorInfo,
      errorId: this.state.errorId,
      timestamp: new Date().toISOString(),
      url: window.location.href,
      userAgent: navigator.userAgent
    };

    try {
      await navigator.clipboard.writeText(JSON.stringify(errorReport, null, 2));
      toast({
        title: 'Error details copied',
        description: 'Error information has been copied to clipboard.'
      });
    } catch (error) {
      console.error('Failed to copy error details:', error);
      toast({
        title: 'Copy failed',
        description: 'Unable to copy error details to clipboard.',
        variant: 'destructive'
      });
    }
  };

  private handleDownloadReport = (): void => {
    if (!this.state.error || !this.state.errorInfo) return;

    const errorReport = {
      error: {
        name: this.state.error.name,
        message: this.state.error.message,
        stack: this.state.error.stack
      },
      errorInfo: this.state.errorInfo,
      errorId: this.state.errorId,
      timestamp: new Date().toISOString(),
      url: window.location.href,
      userAgent: navigator.userAgent,
      retryCount: this.state.retryCount
    };

    const blob = new Blob([JSON.stringify(errorReport, null, 2)], {
      type: 'application/json'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `error-report-${this.state.errorId}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast({
      title: 'Report downloaded',
      description: 'Error report has been downloaded successfully.'
    });
  };

  private renderMinimalFallback(): ReactNode {
    return (
      <div className="flex items-center justify-center min-h-[200px] p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2 text-destructive mb-4">
              <AlertTriangle className="h-5 w-5" />
              <span className="font-medium">Something went wrong</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              We encountered an unexpected error. Please try again.
            </p>
            <div className="flex space-x-2">
              {this.props.showRetry !== false &&
              <Button
                onClick={this.handleRetry}
                disabled={this.state.isRetrying}
                size="sm">

                  {this.state.isRetrying ?
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> :

                <RefreshCw className="h-4 w-4 mr-2" />
                }
                  Retry
                </Button>
              }
              <Button variant="outline" onClick={this.handleRefresh} size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>);

  }

  private renderDetailedFallback(): ReactNode {
    const { error } = this.state;

    return (
      <div className="flex items-center justify-center min-h-[400px] p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-6 w-6 text-destructive" />
              <CardTitle className="text-lg">Application Error</CardTitle>
            </div>
            <CardDescription>
              An unexpected error occurred in the application
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error &&
            <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Badge variant="destructive">{error.name}</Badge>
                  <span className="text-sm font-mono">{this.state.errorId}</span>
                </div>
                <p className="text-sm font-medium">{error.message}</p>
              </div>
            }

            <Collapsible>
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => this.setState((prev) => ({ showDetails: !prev.showDetails }))}>

                  <Bug className="h-4 w-4 mr-2" />
                  {this.state.showDetails ? 'Hide' : 'Show'} Technical Details
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-2">
                {error?.stack &&
                <pre className="text-xs bg-muted p-3 rounded-md overflow-auto max-h-40">
                    {error.stack}
                  </pre>
                }
                {this.state.errorInfo?.componentStack &&
                <pre className="text-xs bg-muted p-3 rounded-md overflow-auto max-h-40">
                    {this.state.errorInfo.componentStack}
                  </pre>
                }
              </CollapsibleContent>
            </Collapsible>

            <div className="flex flex-wrap gap-2">
              {this.props.showRetry !== false &&
              <Button
                onClick={this.handleRetry}
                disabled={this.state.isRetrying || this.state.retryCount >= this.maxRetries}
                size="sm">

                  {this.state.isRetrying ?
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> :

                <RefreshCw className="h-4 w-4 mr-2" />
                }
                  Retry ({this.state.retryCount}/{this.maxRetries})
                </Button>
              }
              
              <Button variant="outline" onClick={this.handleRefresh} size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh Page
              </Button>
              
              <Button variant="outline" onClick={this.handleGoHome} size="sm">
                <Home className="h-4 w-4 mr-2" />
                Go Home
              </Button>

              {this.props.showReporting !== false &&
              <>
                  <Button variant="outline" onClick={this.handleCopyError} size="sm">
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Error
                  </Button>
                  
                  <Button variant="outline" onClick={this.handleDownloadReport} size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download Report
                  </Button>
                </>
              }
            </div>

            <p className="text-xs text-muted-foreground">
              If this error persists, please contact support with the error ID: {this.state.errorId}
            </p>
          </CardContent>
        </Card>
      </div>);

  }

  private renderFullFallback(): ReactNode {
    // Full fallback includes all debugging information and tools
    return this.renderDetailedFallback();
  }

  render(): ReactNode {
    if (this.state.hasError) {
      // Use custom fallback if provided
      if (this.props.customFallback && this.state.error) {
        return this.props.customFallback(this.state.error, this.handleRetry);
      }

      // Use fallback based on type
      switch (this.props.fallbackType) {
        case 'minimal':
          return this.renderMinimalFallback();
        case 'full':
          return this.renderFullFallback();
        case 'detailed':
        default:
          return this.renderDetailedFallback();
      }
    }

    return this.props.children;
  }
}

export default ComprehensiveErrorBoundary;