import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { ScrollArea } from '../ui/scroll-area';
import {
  Activity,
  AlertTriangle,
  TrendingUp,
  Users,
  Code,
  Download,
  Filter,
  Search,
  RefreshCw,
  Settings,
  BarChart3 } from
'lucide-react';
import { useError } from './ComprehensiveErrorProvider';
import { ErrorMetadata, ErrorPattern, ErrorAnalysis } from '../../services/comprehensiveErrorManager';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';

interface DashboardProps {
  showAdvancedFeatures?: boolean;
  enableRealTime?: boolean;
  refreshInterval?: number;
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#8dd1e1'];

export const ComprehensiveErrorMonitoringDashboard: React.FC<DashboardProps> = ({
  showAdvancedFeatures = true,
  enableRealTime = true,
  refreshInterval = 30000
}) => {
  const { errors, analysis, clearErrors, getErrorsByComponent, exportErrors, isLoading } = useError();

  const [filteredErrors, setFilteredErrors] = useState<ErrorMetadata[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [selectedComponent, setSelectedComponent] = useState<string>('all');
  const [autoRefresh, setAutoRefresh] = useState(enableRealTime);
  const [selectedTimeRange, setSelectedTimeRange] = useState('1h');

  // Filter errors based on criteria
  useEffect(() => {
    let filtered = errors;

    // Time range filter
    const now = new Date();
    const timeRangeHours = {
      '1h': 1,
      '6h': 6,
      '24h': 24,
      '7d': 168,
      'all': Infinity
    }[selectedTimeRange] || 1;

    if (timeRangeHours !== Infinity) {
      const cutoff = new Date(now.getTime() - timeRangeHours * 60 * 60 * 1000);
      filtered = filtered.filter((error) => error.timestamp >= cutoff);
    }

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter((error) =>
      error.context.message?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      error.component?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      error.id.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter((error) => error.category === selectedCategory);
    }

    // Level filter
    if (selectedLevel !== 'all') {
      filtered = filtered.filter((error) => error.level === selectedLevel);
    }

    // Component filter
    if (selectedComponent !== 'all') {
      filtered = filtered.filter((error) => error.component === selectedComponent);
    }

    setFilteredErrors(filtered);
  }, [errors, searchTerm, selectedCategory, selectedLevel, selectedComponent, selectedTimeRange]);

  // Auto refresh
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      // Force re-render to get latest data
      window.location.reload();
    }, refreshInterval);

    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval]);

  const prepareChartData = () => {
    const hourlyData: Record<string, number> = {};
    const now = new Date();

    // Initialize hourly buckets
    for (let i = 23; i >= 0; i--) {
      const hour = new Date(now.getTime() - i * 60 * 60 * 1000);
      const key = hour.getHours().toString().padStart(2, '0') + ':00';
      hourlyData[key] = 0;
    }

    // Count errors by hour
    filteredErrors.forEach((error) => {
      const hour = error.timestamp.getHours().toString().padStart(2, '0') + ':00';
      if (hourlyData[hour] !== undefined) {
        hourlyData[hour]++;
      }
    });

    return Object.entries(hourlyData).map(([time, count]) => ({
      time,
      errors: count
    }));
  };

  const prepareCategoryData = () => {
    if (!analysis) return [];

    return Object.entries(analysis.errorsByCategory).map(([category, count]) => ({
      name: category,
      value: count
    }));
  };

  const prepareComponentData = () => {
    if (!analysis) return [];

    return Object.entries(analysis.errorsByComponent).
    slice(0, 10).
    map(([component, count]) => ({
      component: component.length > 20 ? component.substring(0, 20) + '...' : component,
      errors: count
    }));
  };

  const getLevelColor = (level: string): string => {
    switch (level) {
      case 'critical':return 'destructive';
      case 'error':return 'destructive';
      case 'warn':return 'secondary';
      case 'info':return 'outline';
      default:return 'outline';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'ui':return <Code className="h-4 w-4" />;
      case 'api':return <Activity className="h-4 w-4" />;
      case 'network':return <TrendingUp className="h-4 w-4" />;
      case 'security':return <AlertTriangle className="h-4 w-4" />;
      default:return <Activity className="h-4 w-4" />;
    }
  };

  const exportReport = () => {
    const report = {
      timestamp: new Date().toISOString(),
      summary: analysis,
      errors: filteredErrors,
      filters: {
        searchTerm,
        category: selectedCategory,
        level: selectedLevel,
        component: selectedComponent,
        timeRange: selectedTimeRange
      }
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], {
      type: 'application/json'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `error-monitoring-report-${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>);

  }

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Error Monitoring</h1>
          <p className="text-muted-foreground">
            Comprehensive error tracking and analysis dashboard
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setAutoRefresh(!autoRefresh)}>

            <RefreshCw className={`h-4 w-4 mr-2 ${autoRefresh ? 'animate-spin' : ''}`} />
            {autoRefresh ? 'Auto' : 'Manual'}
          </Button>
          
          <Button variant="outline" size="sm" onClick={exportReport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          
          <Button variant="outline" size="sm" onClick={clearErrors}>
            Clear All
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Errors</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analysis?.totalErrors || 0}</div>
            <p className="text-xs text-muted-foreground">
              {filteredErrors.length} filtered
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Errors</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">
              {analysis?.criticalErrors.length || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Requires immediate attention
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Error Patterns</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analysis?.topPatterns.length || 0}</div>
            <p className="text-xs text-muted-foreground">
              Identified patterns
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Components Affected</CardTitle>
            <Code className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Object.keys(analysis?.errorsByComponent || {}).length}
            </div>
            <p className="text-xs text-muted-foreground">
              With errors
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search errors..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10" />

              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Time Range</label>
              <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1h">Last Hour</SelectItem>
                  <SelectItem value="6h">Last 6 Hours</SelectItem>
                  <SelectItem value="24h">Last 24 Hours</SelectItem>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="all">All Time</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="ui">UI</SelectItem>
                  <SelectItem value="api">API</SelectItem>
                  <SelectItem value="network">Network</SelectItem>
                  <SelectItem value="security">Security</SelectItem>
                  <SelectItem value="performance">Performance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Level</label>
              <Select value={selectedLevel} onValueChange={setSelectedLevel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="warn">Warning</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Component</label>
              <Select value={selectedComponent} onValueChange={setSelectedComponent}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Components</SelectItem>
                  {Object.keys(analysis?.errorsByComponent || {}).map((component) =>
                  <SelectItem key={component} value={component}>
                      {component}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts and Analysis */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="patterns">Patterns</TabsTrigger>
          <TabsTrigger value="errors">Errors</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Error Frequency</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={prepareChartData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="errors" stroke="#8884d8" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Errors by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={prepareCategoryData()}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8">

                      {prepareCategoryData().map((entry, index) =>
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      )}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Top Components with Errors</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={prepareComponentData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="component" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="errors" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          <div className="grid gap-4">
            {analysis?.topPatterns.map((pattern, index) =>
            <Card key={index}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{pattern.pattern}</CardTitle>
                    <div className="flex items-center space-x-2">
                      <Badge variant={pattern.severity === 'critical' ? 'destructive' : 'secondary'}>
                        {pattern.severity}
                      </Badge>
                      <Badge variant="outline">
                        {pattern.frequency} occurrences
                      </Badge>
                    </div>
                  </div>
                  <CardDescription>
                    Last seen: {pattern.lastOccurrence.toLocaleString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div>
                      <span className="font-medium">Components affected:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {pattern.components.map((component, i) =>
                      <Badge key={i} variant="outline" className="text-xs">
                            {component}
                          </Badge>
                      )}
                      </div>
                    </div>
                    
                    {pattern.suggestedFix &&
                  <Alert>
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Suggested Fix</AlertTitle>
                        <AlertDescription>{pattern.suggestedFix}</AlertDescription>
                      </Alert>
                  }
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="errors" className="space-y-4">
          <ScrollArea className="h-[600px]">
            <div className="space-y-4">
              {filteredErrors.map((error, index) =>
              <Card key={error.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {getCategoryIcon(error.category)}
                        <CardTitle className="text-sm font-mono">{error.id}</CardTitle>
                        <Badge variant={getLevelColor(error.level)}>{error.level}</Badge>
                        <Badge variant="outline">{error.category}</Badge>
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {error.timestamp.toLocaleString()}
                      </span>
                    </div>
                    <CardDescription className="font-medium">
                      {error.context.message}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Component:</span>
                        <span>{error.component || 'Unknown'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">URL:</span>
                        <span className="truncate max-w-xs">{error.url}</span>
                      </div>
                      {error.userId &&
                    <div className="flex justify-between">
                          <span className="text-muted-foreground">User ID:</span>
                          <span>{error.userId}</span>
                        </div>
                    }
                      {error.performance?.timing &&
                    <div className="flex justify-between">
                          <span className="text-muted-foreground">Capture Time:</span>
                          <span>{error.performance.timing.toFixed(2)}ms</span>
                        </div>
                    }
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <div className="grid gap-4">
            {analysis?.recommendations.map((recommendation, index) =>
            <Alert key={index}>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Recommendation {index + 1}</AlertTitle>
                <AlertDescription>{recommendation}</AlertDescription>
              </Alert>
            )}
            
            {(!analysis?.recommendations || analysis.recommendations.length === 0) &&
            <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>No Recommendations</AlertTitle>
                <AlertDescription>
                  No specific recommendations at this time. Continue monitoring for patterns.
                </AlertDescription>
              </Alert>
            }
          </div>
        </TabsContent>
      </Tabs>
    </div>);

};

export default ComprehensiveErrorMonitoringDashboard;