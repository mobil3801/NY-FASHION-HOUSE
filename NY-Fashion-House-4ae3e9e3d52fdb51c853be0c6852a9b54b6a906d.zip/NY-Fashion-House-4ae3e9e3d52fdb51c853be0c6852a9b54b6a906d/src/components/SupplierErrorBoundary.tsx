import React, { Component, ReactNode } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { errorLoggingService } from '@/services/errorLoggingService';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onRetry?: () => void;
  showRetry?: boolean;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorId: string | null;
}

export class SupplierErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, errorId: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      error,
      errorId: `supplier_error_${Date.now()}`
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Log the error with enhanced context
    const errorId = `supplier_error_${Date.now()}`;

    errorLoggingService.logError(error, {
      severity: 'high',
      context: {
        component: 'SupplierErrorBoundary',
        errorId,
        errorInfo: errorInfo.componentStack,
        props: JSON.stringify(this.props, null, 2)
      },
      userAction: 'supplier_interaction'
    });

    this.setState({ errorId });
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null, errorId: null });
    if (this.props.onRetry) {
      this.props.onRetry();
    }
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <Card className="w-full max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="w-5 h-5" />
              Supplier Data Error
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Something went wrong</AlertTitle>
              <AlertDescription>
                There was an error loading supplier information. This might be due to a network issue or temporary server problem.
              </AlertDescription>
            </Alert>
            
            <div className="text-sm text-muted-foreground">
              <p><strong>Error ID:</strong> {this.state.errorId}</p>
              <p><strong>Details:</strong> {this.state.error?.message || 'Unknown error occurred'}</p>
            </div>

            {this.props.showRetry !== false &&
            <Button
              onClick={this.handleRetry}
              variant="outline"
              className="w-full">

                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            }
          </CardContent>
        </Card>);

    }

    return this.props.children;
  }
}

export default SupplierErrorBoundary;