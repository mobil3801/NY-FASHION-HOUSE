
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, RefreshCcw } from 'lucide-react';
import { UserSearchFilters } from '@/types/user';

interface UserSearchFilterProps {
  filters: UserSearchFilters;
  onFiltersChange: (filters: UserSearchFilters) => void;
  roles: any[];
  onReset: () => void;
}

const UserSearchFilter: React.FC<UserSearchFilterProps> = ({
  filters,
  onFiltersChange,
  roles,
  onReset
}) => {
  const handleSearchChange = (value: string) => {
    onFiltersChange({ ...filters, search: value });
  };

  const handleRoleChange = (value: string) => {
    onFiltersChange({
      ...filters,
      roleId: value === 'all' ? undefined : parseInt(value)
    });
  };

  const handleStatusChange = (value: string) => {
    onFiltersChange({
      ...filters,
      isActivated: value === 'all' ? undefined : value === 'active'
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Search & Filter Users
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <Label htmlFor="search">Search</Label>
            <Input
              id="search"
              placeholder="Search by name or email..."
              value={filters.search || ''}
              onChange={(e) => handleSearchChange(e.target.value)} />

          </div>

          <div className="space-y-2">
            <Label>Role</Label>
            <Select
              value={filters.roleId ? filters.roleId.toString() : 'all'}
              onValueChange={handleRoleChange}>

              <SelectTrigger>
                <SelectValue placeholder="All roles" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                {roles.map((role) =>
                <SelectItem key={role.id} value={role.id.toString()}>
                    {role.name}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Status</Label>
            <Select
              value={
              filters.isActivated === undefined ?
              'all' :
              filters.isActivated ?
              'active' :
              'inactive'
              }
              onValueChange={handleStatusChange}>

              <SelectTrigger>
                <SelectValue placeholder="All statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end">
            <Button
              variant="outline"
              onClick={onReset}
              className="w-full">

              <RefreshCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>);

};

export default UserSearchFilter;