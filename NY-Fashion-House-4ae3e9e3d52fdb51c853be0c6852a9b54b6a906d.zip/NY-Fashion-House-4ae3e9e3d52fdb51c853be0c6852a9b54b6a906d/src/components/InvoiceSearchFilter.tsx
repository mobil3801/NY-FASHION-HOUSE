
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Search, X, Filter } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { InvoiceFilters, Invoice } from '@/types/invoice';

interface InvoiceSearchFilterProps {
  filters: InvoiceFilters;
  onFiltersChange: (filters: InvoiceFilters) => void;
  onClearFilters: () => void;
  hasActiveFilters: boolean;
}

const statusColors = {
  draft: 'bg-gray-100 text-gray-800',
  sent: 'bg-blue-100 text-blue-800',
  viewed: 'bg-purple-100 text-purple-800',
  paid: 'bg-green-100 text-green-800',
  overdue: 'bg-red-100 text-red-800',
  cancelled: 'bg-gray-100 text-gray-800'
};

const InvoiceSearchFilter: React.FC<InvoiceSearchFilterProps> = ({
  filters,
  onFiltersChange,
  onClearFilters,
  hasActiveFilters
}) => {
  const updateFilter = (key: keyof InvoiceFilters, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter Invoices
          </CardTitle>
          {hasActiveFilters &&
          <Button
            variant="outline"
            size="sm"
            onClick={onClearFilters}
            className="text-gray-600">

              <X className="h-4 w-4 mr-1" />
              Clear All
            </Button>
          }
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search Query */}
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search by invoice number, customer name, or phone..."
            value={filters.searchQuery || ''}
            onChange={(e) => updateFilter('searchQuery', e.target.value)}
            className="pl-10" />

        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Status Filter */}
          <div className="space-y-2">
            <Label>Status</Label>
            <Select
              value={filters.status || 'all'}
              onValueChange={(value) => updateFilter('status', value === 'all' ? undefined : value as Invoice['status'])}>

              <SelectTrigger>
                <SelectValue placeholder="All statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="draft">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className={statusColors.draft}>Draft</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="sent">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className={statusColors.sent}>Sent</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="viewed">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className={statusColors.viewed}>Viewed</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="paid">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className={statusColors.paid}>Paid</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="overdue">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className={statusColors.overdue}>Overdue</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="cancelled">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className={statusColors.cancelled}>Cancelled</Badge>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Amount Range */}
          <div className="space-y-2">
            <Label>Min Amount (৳)</Label>
            <Input
              type="number"
              placeholder="0"
              value={filters.amountMin || ''}
              onChange={(e) => updateFilter('amountMin', e.target.value ? Number(e.target.value) : undefined)} />

          </div>

          <div className="space-y-2">
            <Label>Max Amount (৳)</Label>
            <Input
              type="number"
              placeholder="No limit"
              value={filters.amountMax || ''}
              onChange={(e) => updateFilter('amountMax', e.target.value ? Number(e.target.value) : undefined)} />

          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Issue Date Range */}
          <div className="space-y-2">
            <Label>Issue Date From</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.dateFrom && "text-muted-foreground"
                  )}>

                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dateFrom ? format(filters.dateFrom, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={filters.dateFrom}
                  onSelect={(date) => updateFilter('dateFrom', date)}
                  initialFocus />

              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Issue Date To</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.dateTo && "text-muted-foreground"
                  )}>

                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dateTo ? format(filters.dateTo, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={filters.dateTo}
                  onSelect={(date) => updateFilter('dateTo', date)}
                  initialFocus />

              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Due Date Range */}
          <div className="space-y-2">
            <Label>Due Date From</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.dueDateFrom && "text-muted-foreground"
                  )}>

                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dueDateFrom ? format(filters.dueDateFrom, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={filters.dueDateFrom}
                  onSelect={(date) => updateFilter('dueDateFrom', date)}
                  initialFocus />

              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Due Date To</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.dueDateTo && "text-muted-foreground"
                  )}>

                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dueDateTo ? format(filters.dueDateTo, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={filters.dueDateTo}
                  onSelect={(date) => updateFilter('dueDateTo', date)}
                  initialFocus />

              </PopoverContent>
            </Popover>
          </div>
        </div>
      </CardContent>
    </Card>);

};

export default InvoiceSearchFilter;