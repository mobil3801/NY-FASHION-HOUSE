
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tag, Download, Printer, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { Product } from '@/types/product';

interface PriceTagGeneratorProps {
  products: Product[];
}

type TagSize = '2x1' | '2x1.25' | '2.25x1.25' | '2.5x1.5' | '3x2' | '3.5x2' | '4x2' | '4x3' | '5x3';

interface TagSizeConfig {
  width: number;
  height: number;
  displayName: string;
  printWidth: string;
  printHeight: string;
}

interface ScaledElements {
  padding: string;
  nameSize: string;
  categorySize: string;
  priceSize: string;
  barcodeWidth: number;
  barcodeHeight: number;
  spacing: string;
  borderWidth: string;
}

// Convert inches to pixels (96 DPI for screen display)
const inchesToPixels = (inches: number, dpi = 96) => Math.round(inches * dpi);

const tagSizeConfigs: Record<TagSize, TagSizeConfig> = {
  '2x1': {
    width: inchesToPixels(2),
    height: inchesToPixels(1),
    displayName: '2" × 1" (Standard Small)',
    printWidth: '2in',
    printHeight: '1in'
  },
  '2x1.25': {
    width: inchesToPixels(2),
    height: inchesToPixels(1.25),
    displayName: '2" × 1.25" (Small Rectangle)',
    printWidth: '2in',
    printHeight: '1.25in'
  },
  '2.25x1.25': {
    width: inchesToPixels(2.25),
    height: inchesToPixels(1.25),
    displayName: '2.25" × 1.25" (Standard)',
    printWidth: '2.25in',
    printHeight: '1.25in'
  },
  '2.5x1.5': {
    width: inchesToPixels(2.5),
    height: inchesToPixels(1.5),
    displayName: '2.5" × 1.5" (Popular)',
    printWidth: '2.5in',
    printHeight: '1.5in'
  },
  '3x2': {
    width: inchesToPixels(3),
    height: inchesToPixels(2),
    displayName: '3" × 2" (Medium)',
    printWidth: '3in',
    printHeight: '2in'
  },
  '3.5x2': {
    width: inchesToPixels(3.5),
    height: inchesToPixels(2),
    displayName: '3.5" × 2" (Wide Medium)',
    printWidth: '3.5in',
    printHeight: '2in'
  },
  '4x2': {
    width: inchesToPixels(4),
    height: inchesToPixels(2),
    displayName: '4" × 2" (Large Rectangle)',
    printWidth: '4in',
    printHeight: '2in'
  },
  '4x3': {
    width: inchesToPixels(4),
    height: inchesToPixels(3),
    displayName: '4" × 3" (Large)',
    printWidth: '4in',
    printHeight: '3in'
  },
  '5x3': {
    width: inchesToPixels(5),
    height: inchesToPixels(3),
    displayName: '5" × 3" (Extra Large)',
    printWidth: '5in',
    printHeight: '3in'
  }
};

// Base dimensions for scaling calculations (2.5" x 1.5" as reference)
const BASE_WIDTH = inchesToPixels(2.5);
const BASE_HEIGHT = inchesToPixels(1.5);

// Calculate responsive scaling for elements
const calculateScaledElements = (config: TagSizeConfig): ScaledElements => {
  const { width, height } = config;

  // Calculate scale factors based on area and dimensions
  const widthScale = width / BASE_WIDTH;
  const heightScale = height / BASE_HEIGHT;
  const areaScale = Math.sqrt(width * height / (BASE_WIDTH * BASE_HEIGHT));

  // Use combined scaling approach: area for text sizes, dimensions for spacing
  const textScale = Math.max(0.6, Math.min(2, areaScale)); // Clamp between 60% and 200%
  const spacingScale = Math.max(0.5, Math.min(1.8, (widthScale + heightScale) / 2));

  // Base sizes (optimized for 2.5" x 1.5" tag)
  const basePadding = 12;
  const baseNameSize = 14;
  const baseCategorySize = 11;
  const basePriceSize = 20;
  const baseBarcodeWidth = inchesToPixels(2);
  const baseBarcodeHeight = inchesToPixels(0.4);

  // Calculate minimum sizes to ensure readability
  const minNameSize = 8;
  const minCategorySize = 7;
  const minPriceSize = 12;
  const minBarcodeWidth = inchesToPixels(1.2);
  const minBarcodeHeight = inchesToPixels(0.25);

  // Calculate maximum sizes to prevent overflow
  const maxNameSize = Math.min(28, height * 0.15);
  const maxCategorySize = Math.min(18, height * 0.12);
  const maxPriceSize = Math.min(36, height * 0.25);
  const maxBarcodeWidth = Math.min(width * 0.85, inchesToPixels(4.5));
  const maxBarcodeHeight = Math.min(height * 0.3, inchesToPixels(0.8));

  // Apply scaling with constraints
  const scaledNameSize = Math.max(minNameSize, Math.min(maxNameSize, baseNameSize * textScale));
  const scaledCategorySize = Math.max(minCategorySize, Math.min(maxCategorySize, baseCategorySize * textScale));
  const scaledPriceSize = Math.max(minPriceSize, Math.min(maxPriceSize, basePriceSize * textScale));
  const scaledPadding = Math.max(4, Math.min(24, basePadding * spacingScale));

  // Barcode scaling with aspect ratio preservation
  const barcodeWidthScale = Math.max(0.6, Math.min(2.2, widthScale));
  const barcodeHeightScale = Math.max(0.6, Math.min(2, heightScale));

  const scaledBarcodeWidth = Math.max(
    minBarcodeWidth,
    Math.min(maxBarcodeWidth, baseBarcodeWidth * barcodeWidthScale)
  );
  const scaledBarcodeHeight = Math.max(
    minBarcodeHeight,
    Math.min(maxBarcodeHeight, baseBarcodeHeight * barcodeHeightScale)
  );

  return {
    padding: `${Math.round(scaledPadding)}px`,
    nameSize: `${Math.round(scaledNameSize)}px`,
    categorySize: `${Math.round(scaledCategorySize)}px`,
    priceSize: `${Math.round(scaledPriceSize)}px`,
    barcodeWidth: Math.round(scaledBarcodeWidth),
    barcodeHeight: Math.round(scaledBarcodeHeight),
    spacing: `${Math.round(scaledPadding * 0.3)}px`,
    borderWidth: Math.max(1, Math.min(3, Math.round(spacingScale))) + 'px'
  };
};

// Code 128 encoding tables
const CODE128_START_A = '11010000100';
const CODE128_START_B = '11010010000';
const CODE128_START_C = '11010011100';
const CODE128_STOP = '11000111010';

const CODE128_TABLE_B: Record<string, string> = {
  ' ': '11011001100', '!': '11001101100', '"': '11001100110', '#': '10010011000',
  '$': '10010001100', '%': '10001001100', '&': '10011001000', "'": '10011000100',
  '(': '10001100100', ')': '11001001000', '*': '11001000100', '+': '11000100100',
  ',': '10110011100', '-': '10011011100', '.': '10011001110', '/': '10111001100',
  '0': '10011101100', '1': '10011100110', '2': '11001110010', '3': '11001011100',
  '4': '11001001110', '5': '11011100100', '6': '11001110100', '7': '11101101110',
  '8': '11101001100', '9': '11100101100', ':': '11100100110', ';': '11101100100',
  '<': '11100110100', '=': '11100110010', '>': '11011011000', '?': '11011000110',
  '@': '11000110110', 'A': '10100011000', 'B': '10001011000', 'C': '10001000110',
  'D': '10110001000', 'E': '10001101000', 'F': '10001100010', 'G': '11010001000',
  'H': '11000101000', 'I': '11000100010', 'J': '10110111000', 'K': '10110001110',
  'L': '10001101110', 'M': '10111011000', 'N': '10111000110', 'O': '10001110110',
  'P': '11101110110', 'Q': '11010001110', 'R': '11000101110', 'S': '11011101000',
  'T': '11011100010', 'U': '11011101110', 'V': '11101011000', 'W': '11101000110',
  'X': '11100010110', 'Y': '11101101000', 'Z': '11101100010', '[': '11100011010',
  '\\': '11101111010', ']': '11001000010', '^': '11110001010', '_': '10100110000',
  '`': '10100001100', 'a': '10010110000', 'b': '10010000110', 'c': '10000101100',
  'd': '10000100110', 'e': '10110010000', 'f': '10110000100', 'g': '10011010000',
  'h': '10011000010', 'i': '10000110100', 'j': '10000110010', 'k': '11000010010',
  'l': '11001010000', 'm': '11110111010', 'n': '11000010100', 'o': '10001111010',
  'p': '10100111100', 'q': '10010111100', 'r': '10010011110', 's': '10111100100',
  't': '10011110100', 'u': '10011110010', 'v': '11110100100', 'w': '11110010100',
  'x': '11110010010', 'y': '11011011110', 'z': '11011110110', '{': '11110110110',
  '|': '10101111000', '}': '10100011110', '~': '10001011110'
};

// Generate proper Code 128 barcode
const generateCode128BarcodeDataURL = (value: string, width: number, height: number): string => {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d')!;

  canvas.width = width;
  canvas.height = height;

  // Fill white background
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, width, height);

  // Build barcode pattern
  let pattern = CODE128_START_B; // Start with Code B for alphanumeric
  let checksum = 104; // Start B value

  // Encode each character
  for (let i = 0; i < value.length; i++) {
    const char = value.charAt(i);
    const charPattern = CODE128_TABLE_B[char];
    if (charPattern) {
      pattern += charPattern;
      // Calculate checksum (position * character value)
      const charValue = Object.keys(CODE128_TABLE_B).indexOf(char) + 32;
      checksum += charValue * (i + 1);
    } else {
      // Fallback for unsupported characters
      pattern += CODE128_TABLE_B['?'] || '11011011000';
      checksum += 95 * (i + 1); // '?' value
    }
  }

  // Add checksum character
  const checksumValue = checksum % 103;
  const checksumChar = Object.keys(CODE128_TABLE_B)[checksumValue - 32] || ' ';
  pattern += CODE128_TABLE_B[checksumChar] || CODE128_TABLE_B[' '];

  // Add stop pattern
  pattern += CODE128_STOP;
  pattern += '11'; // Termination bars

  // Calculate bar width
  const barWidth = Math.max(1, Math.floor(width / pattern.length));
  const textHeight = Math.max(8, height * 0.15);
  const barcodeHeight = height - textHeight - 2;

  // Draw bars
  ctx.fillStyle = 'black';
  let x = (width - pattern.length * barWidth) / 2; // Center the barcode

  for (let i = 0; i < pattern.length; i++) {
    if (pattern[i] === '1') {
      ctx.fillRect(x, 2, barWidth, barcodeHeight);
    }
    x += barWidth;
  }

  // Add text
  ctx.fillStyle = 'black';
  ctx.font = `${Math.max(6, Math.floor(textHeight * 0.8))}px monospace`;
  ctx.textAlign = 'center';
  ctx.fillText(value, width / 2, height - 2);

  return canvas.toDataURL();
};

const PriceTagGenerator: React.FC<PriceTagGeneratorProps> = ({ products }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState<Set<string>>(new Set());
  const [tagSize, setTagSize] = useState<TagSize>('2.5x1.5');
  const [showPreview, setShowPreview] = useState(false);

  const selectedProductsList = products.filter((p) => selectedProducts.has(p.id));
  const tagConfig = tagSizeConfigs[tagSize];

  // Calculate scaled elements when tag size changes
  const scaledElements = useMemo(() => calculateScaledElements(tagConfig), [tagConfig]);

  // Auto-show preview when products and size are selected
  useEffect(() => {
    if (selectedProducts.size > 0 && tagSize) {
      setShowPreview(true);
    } else {
      setShowPreview(false);
    }
  }, [selectedProducts.size, tagSize]);

  const toggleProduct = (productId: string) => {
    const newSelected = new Set(selectedProducts);
    if (newSelected.has(productId)) {
      newSelected.delete(productId);
    } else {
      newSelected.add(productId);
    }
    setSelectedProducts(newSelected);
  };

  const selectAllProducts = () => {
    if (selectedProducts.size === products.length) {
      setSelectedProducts(new Set());
    } else {
      setSelectedProducts(new Set(products.map((p) => p.id)));
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };

  const formatCategoryName = (category: string) => {
    return category.
    split('-').
    map((word) => word.charAt(0).toUpperCase() + word.slice(1)).
    join(' ');
  };

  const handlePrint = () => {
    if (selectedProductsList.length === 0) {
      toast.error('Please select at least one product');
      return;
    }

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    // For tag printers, we print one tag per page at actual size
    const tagWidthInches = parseFloat(tagConfig.printWidth);
    const tagHeightInches = parseFloat(tagConfig.printHeight);
    const tagsPerPage = 1; // One tag per page for exact sizing

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Price Tags - ${new Date().toLocaleDateString()}</title>
          <meta charset="utf-8">
          <style>
            * { 
              box-sizing: border-box; 
              margin: 0; 
              padding: 0; 
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            
            /* Page setup for exact tag sizing - matches physical tag dimensions */
            @page {
              size: ${tagConfig.printWidth} ${tagConfig.printHeight}; /* Exact tag size */
              margin: 0; /* No margins for exact sizing */
            }
            
            body { 
              font-family: Arial, sans-serif; 
              background: white;
              margin: 0;
              padding: 0;
              width: ${tagConfig.printWidth};
              height: ${tagConfig.printHeight};
            }
            
            .page {
              width: ${tagConfig.printWidth};
              height: ${tagConfig.printHeight};
              display: flex;
              justify-content: center;
              align-items: center;
              page-break-after: always;
              margin: 0;
              padding: 0;
            }
            
            .page:last-child {
              page-break-after: avoid;
            }
            
            .print-container { 
              width: 100%;
              height: 100%;
              margin: 0;
              padding: 0;
            }
            
            .price-tag {
              width: 100%;
              height: 100%;
              padding: ${scaledElements.padding};
              border: ${scaledElements.borderWidth} solid #000;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              background: white;
              box-sizing: border-box;
              overflow: hidden;
              break-inside: avoid;
              page-break-inside: avoid;
            }
            
            .tag-name { 
              font-size: ${scaledElements.nameSize}; 
              font-weight: bold; 
              color: black; 
              text-align: center;
              margin-bottom: ${scaledElements.spacing};
              line-height: 1.1;
              overflow: hidden;
              text-overflow: ellipsis;
              word-wrap: break-word;
            }
            
            .tag-category { 
              font-size: ${scaledElements.categorySize}; 
              color: black; 
              text-align: center;
              margin-bottom: ${scaledElements.spacing};
              line-height: 1.1;
            }
            
            .tag-price { 
              font-size: ${scaledElements.priceSize}; 
              font-weight: bold; 
              color: #dc2626; 
              text-align: center;
              margin-bottom: ${scaledElements.spacing};
              line-height: 1;
            }
            
            .tag-barcode { 
              text-align: center;
              margin-top: auto;
              display: flex;
              justify-content: center;
              align-items: center;
            }
            
            .barcode-image {
              width: ${scaledElements.barcodeWidth}px;
              height: ${scaledElements.barcodeHeight}px;
              max-width: 100%;
              max-height: 100%;
            }
            
            /* Print-specific optimizations */
            @media print {
              * { 
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                color-adjust: exact !important;
              }
              
              @page {
                size: ${tagConfig.printWidth} ${tagConfig.printHeight} !important; /* Exact tag dimensions */
                margin: 0 !important; /* No margins for exact sizing */
              }
              
              html, body { 
                margin: 0 !important; 
                padding: 0 !important;
                font-size: 100% !important;
                width: ${tagConfig.printWidth} !important;
                height: ${tagConfig.printHeight} !important;
              }
              
              .page {
                width: ${tagConfig.printWidth} !important;
                height: ${tagConfig.printHeight} !important;
                page-break-after: always !important;
                page-break-inside: avoid !important;
                margin: 0 !important;
                padding: 0 !important;
              }
              
              .page:last-child {
                page-break-after: avoid !important;
              }
              
              .print-container { 
                width: 100% !important;
                height: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
              }
              
              .price-tag { 
                width: 100% !important;
                height: 100% !important;
                border: ${scaledElements.borderWidth} solid #000 !important;
                break-inside: avoid !important;
                page-break-inside: avoid !important;
                box-sizing: border-box !important;
                background: white !important;
              }
              
              .tag-price {
                color: #dc2626 !important;
              }
            }
            
            /* Instructions for user */
            .print-instructions {
              background: #f0f9ff;
              border: 1px solid #0ea5e9;
              border-radius: 6px;
              padding: 12px;
              margin-bottom: 20px;
              font-size: 14px;
              line-height: 1.4;
            }
            
            .print-instructions h3 {
              color: #0c4a6e;
              margin-bottom: 8px;
              font-size: 16px;
            }
            
            .print-instructions ul {
              margin: 8px 0;
              padding-left: 20px;
            }
            
            .print-instructions li {
              margin: 4px 0;
              color: #0c4a6e;
            }
            
            @media print {
              .print-instructions {
                display: none !important;
              }
            }
          </style>
        </head>
        <body>
          <div class="print-instructions">
            <h3>🏷️ Tag Printer Setup Instructions</h3>
            <ul>
              <li><strong>Print Mode:</strong> Tag Printer Mode (One tag per page)</li>
              <li><strong>Paper Size:</strong> ${tagConfig.printWidth} × ${tagConfig.printHeight} (Exact tag size)</li>
              <li><strong>Margins:</strong> None (0") - Perfect edge-to-edge printing</li>
              <li><strong>Scale:</strong> 100% (Default) - DO NOT change scaling</li>
              <li><strong>Background:</strong> Enabled (for colors and borders)</li>
              <li><strong>Tags per page:</strong> 1 tag per page (${selectedProductsList.length} pages total)</li>
              <li><strong>Output:</strong> ${tagConfig.printWidth} × ${tagConfig.printHeight} each</li>
            </ul>
            <p><strong>🎯 Perfect for tag printers:</strong> Each tag prints at exact physical size!</p>
          </div>
          
          ${selectedProductsList.map((product) => `
            <div class="page">
              <div class="print-container">
                <div class="price-tag">
                  <div class="tag-name">${product.name}</div>
                  <div class="tag-category">${formatCategoryName(product.category)}</div>
                  <div class="tag-price">${formatCurrency(product.sellingPrice)}</div>
                  <div class="tag-barcode">
                    <img src="${generateCode128BarcodeDataURL(product.sku, scaledElements.barcodeWidth, scaledElements.barcodeHeight)}" 
                         alt="Barcode" class="barcode-image" />
                  </div>
                </div>
              </div>
            </div>
          `).join('')}
        </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();

    // Add slight delay to ensure content is fully loaded
    setTimeout(() => {
      printWindow.print();
      toast.success(`Printing ${selectedProductsList.length} price tags (1 tag per page at exact ${tagConfig.printWidth} × ${tagConfig.printHeight} size)`);
    }, 500);
  };

  const handleDownload = () => {
    if (selectedProductsList.length === 0) {
      toast.error('Please select at least one product');
      return;
    }

    // Create a temporary container for the tags
    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.background = 'white';
    container.innerHTML = `
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(${tagConfig.width}px, 1fr)); gap: 10px; padding: 20px;">
        ${selectedProductsList.map((product) => `
          <div style="
            width: ${tagConfig.width}px;
            height: ${tagConfig.height}px;
            padding: ${scaledElements.padding};
            border: ${scaledElements.borderWidth} solid #000;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background: white;
            font-family: Arial, sans-serif;
            box-sizing: border-box;
          ">
            <div style="font-size: ${scaledElements.nameSize}; font-weight: bold; color: black; text-align: center; margin-bottom: ${scaledElements.spacing}; line-height: 1.1; overflow: hidden; text-overflow: ellipsis;">
              ${product.name}
            </div>
            <div style="font-size: ${scaledElements.categorySize}; color: black; text-align: center; margin-bottom: ${scaledElements.spacing}; line-height: 1.1;">
              ${formatCategoryName(product.category)}
            </div>
            <div style="font-size: ${scaledElements.priceSize}; font-weight: bold; color: #dc2626; text-align: center; margin-bottom: ${scaledElements.spacing}; line-height: 1;">
              ${formatCurrency(product.sellingPrice)}
            </div>
            <div style="text-align: center; margin-top: auto;">
              <img src="${generateCode128BarcodeDataURL(product.sku, scaledElements.barcodeWidth, scaledElements.barcodeHeight)}" 
                   alt="Barcode" style="width: ${scaledElements.barcodeWidth}px; height: ${scaledElements.barcodeHeight}px; max-width: 100%;" />
            </div>
          </div>
        `).join('')}
      </div>
    `;

    document.body.appendChild(container);

    // Use html2canvas to capture the content
    import('html2canvas').then((html2canvas) => {
      html2canvas.default(container.firstChild as HTMLElement, {
        backgroundColor: 'white',
        scale: 2,
        useCORS: true
      }).then((canvas) => {
        const link = document.createElement('a');
        link.download = `price-tags-${new Date().toISOString().split('T')[0]}.png`;
        link.href = canvas.toDataURL();
        link.click();

        document.body.removeChild(container);
        toast.success(`Downloaded ${selectedProductsList.length} price tags`);
      }).catch((error) => {
        console.error('Error generating image:', error);
        document.body.removeChild(container);
        toast.error('Failed to download price tags');
      });
    }).catch(() => {
      document.body.removeChild(container);
      toast.error('Failed to download price tags');
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Tag className="w-4 h-4" />
          Price Tags
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-6xl h-[80vh] flex flex-col">
        <ScrollArea className="w-full h-full">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5" />
            Price Tags Auto Setup Box
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-1 gap-6 overflow-hidden">
          {/* Left Panel - Product Selection */}
          <div className="flex-1 flex flex-col">
            <Card className="flex-1 flex flex-col">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Select Products</CardTitle>
                  <div className="flex items-center gap-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={selectAllProducts}>
                      {selectedProducts.size === products.length ? 'Deselect All' : 'Select All'}
                    </Button>
                    <Badge variant="secondary">
                      {selectedProducts.size} selected
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="flex-1 overflow-auto">
                <div className="space-y-2">
                  {products.map((product) =>
                    <div
                      key={product.id}
                      className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50">

                      <Checkbox
                        checked={selectedProducts.has(product.id)}
                        onCheckedChange={() => toggleProduct(product.id)} />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium truncate">{product.name}</p>
                          <Badge variant="outline" className="text-xs">
                            {formatCategoryName(product.category)}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-1">
                          <p className="text-sm text-gray-500">SKU: {product.sku}</p>
                          <p className="text-sm font-semibold text-green-600">
                            {formatCurrency(product.sellingPrice)}
                          </p>
                        </div>
                      </div>
                    </div>
                    )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Configuration and Preview */}
          <div className="w-96 flex flex-col">
            <Card className="mb-4">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Tag Size (Standard Printing Sizes)</label>
                  <Select value={tagSize} onValueChange={(value: TagSize) => setTagSize(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2x1">{tagSizeConfigs['2x1'].displayName}</SelectItem>
                      <SelectItem value="2x1.25">{tagSizeConfigs['2x1.25'].displayName}</SelectItem>
                      <SelectItem value="2.25x1.25">{tagSizeConfigs['2.25x1.25'].displayName}</SelectItem>
                      <SelectItem value="2.5x1.5">{tagSizeConfigs['2.5x1.5'].displayName}</SelectItem>
                      <SelectItem value="3x2">{tagSizeConfigs['3x2'].displayName}</SelectItem>
                      <SelectItem value="3.5x2">{tagSizeConfigs['3.5x2'].displayName}</SelectItem>
                      <SelectItem value="4x2">{tagSizeConfigs['4x2'].displayName}</SelectItem>
                      <SelectItem value="4x3">{tagSizeConfigs['4x3'].displayName}</SelectItem>
                      <SelectItem value="5x3">{tagSizeConfigs['5x3'].displayName}</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500 mt-1">Selected: {tagConfig.displayName}</p>
                  
                  {/* Scale Information */}
                  <div className="mt-2 p-2 bg-blue-50 rounded text-xs text-blue-700">
                    <div className="font-medium">Auto-Scaled Elements:</div>
                    <div className="mt-1 space-y-1">
                      <div>• Text sizes: {scaledElements.nameSize} / {scaledElements.categorySize} / {scaledElements.priceSize}</div>
                      <div>• Barcode: {scaledElements.barcodeWidth}×{scaledElements.barcodeHeight}px (Code 128)</div>
                      <div>• Padding: {scaledElements.padding}</div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Button
                      variant="outline"
                      className="w-full gap-2"
                      onClick={() => setShowPreview(!showPreview)}
                      disabled={selectedProductsList.length === 0}>
                    <Eye className="w-4 h-4" />
                    {showPreview ? 'Hide Preview' : 'Show Preview'}
                  </Button>
                  
                  <Button
                      variant="outline"
                      className="w-full gap-2"
                      onClick={handlePrint}
                      disabled={selectedProductsList.length === 0}>
                    <Printer className="w-4 h-4" />
                    Print ({selectedProductsList.length} tags)
                  </Button>
                  
                  <Button
                      variant="outline"
                      className="w-full gap-2"
                      onClick={handleDownload}
                      disabled={selectedProductsList.length === 0}>
                    <Download className="w-4 h-4" />
                    Download
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Preview */}
            {showPreview && selectedProductsList.length > 0 &&
              <Card className="flex-1 overflow-auto">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">
                    Preview
                    <span className="text-sm font-normal text-gray-500 ml-2">({tagConfig.displayName})</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded border text-center">
                      <strong>Print Size:</strong> {tagConfig.printWidth} × {tagConfig.printHeight}<br />
                      <span className="text-gray-600">Preview shown at screen resolution with auto-scaling</span><br />
                      <span className="text-green-600 font-medium">✓ Code 128 Barcodes</span>
                    </div>
                    
                    {selectedProductsList.slice(0, 3).map((product) =>
                    <div key={product.id} className="border-2 border-gray-300 rounded overflow-hidden h-[400px]">
                        <div
                        style={{
                          width: `${tagConfig.width}px`,
                          height: `${tagConfig.height}px`,
                          padding: scaledElements.padding,
                          transform: 'scale(0.8)',
                          transformOrigin: 'top left',
                          margin: '0 -10% -20% 0'
                        }}
                        className="bg-white flex flex-col justify-between border-2 border-black">

                          <div
                          style={{ fontSize: scaledElements.nameSize }}
                          className="font-bold text-black text-center leading-tight overflow-hidden text-ellipsis">
                            {product.name}
                          </div>
                          <div
                          style={{
                            fontSize: scaledElements.categorySize,
                            marginBottom: scaledElements.spacing
                          }}
                          className="text-black text-center">
                            {formatCategoryName(product.category)}
                          </div>
                          <div
                          style={{
                            fontSize: scaledElements.priceSize,
                            marginBottom: scaledElements.spacing
                          }}
                          className="font-bold text-red-600 text-center">
                            {formatCurrency(product.sellingPrice)}
                          </div>
                          <div className="text-center mt-auto">
                            <img
                            src={generateCode128BarcodeDataURL(
                              product.sku,
                              scaledElements.barcodeWidth,
                              scaledElements.barcodeHeight
                            )}
                            alt="Code 128 Barcode"
                            className="mx-auto"
                            style={{
                              width: `${scaledElements.barcodeWidth}px`,
                              height: `${scaledElements.barcodeHeight}px`
                            }} />
                          </div>
                        </div>
                      </div>
                    )}
                    {selectedProductsList.length > 3 &&
                    <p className="text-sm text-gray-500 text-center">
                        ...and {selectedProductsList.length - 3} more
                      </p>
                    }
                  </div>
                </CardContent>
              </Card>
              }
          </div>
        </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>);

};

export default PriceTagGenerator;