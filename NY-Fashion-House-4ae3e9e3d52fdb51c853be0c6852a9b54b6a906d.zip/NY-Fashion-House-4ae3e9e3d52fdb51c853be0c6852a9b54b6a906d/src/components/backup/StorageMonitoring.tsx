
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { HardDrive, RefreshCw, AlertTriangle, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface StorageStats {
  totalSpace: number; // in GB
  usedSpace: number; // in GB
  backupSpace: number; // in GB
  availableSpace: number; // in GB
  backupCount: number;
  oldestBackup: string | null;
  newestBackup: string | null;
}

export const StorageMonitoring: React.FC = () => {
  const [stats, setStats] = useState<StorageStats | null>(null);
  const [loading, setLoading] = useState(true);

  const loadStorageStats = async () => {
    setLoading(true);
    try {
      // Get storage statistics from Node.js function
      const { data: storageData, error: storageError } = await window.ezsite.apis.run({
        path: 'getStorageStatistics',
        param: []
      });

      if (storageError) throw new Error(storageError);

      // Get backup statistics from database
      const { data: backupData, error: backupError } = await window.ezsite.apis.tablePage(37724, {
        PageNo: 1,
        PageSize: 1000, // Get all backups for stats
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: [
        {
          name: 'status',
          op: 'Equal',
          value: 'completed'
        }]

      });

      if (backupError) throw new Error(backupError);

      const backups = backupData?.List || [];
      const totalBackupSize = backups.reduce((sum: number, backup: any) => sum + (backup.file_size || 0), 0) / 1024; // Convert MB to GB

      setStats({
        totalSpace: storageData.totalSpaceGB,
        usedSpace: storageData.usedSpaceGB,
        backupSpace: totalBackupSize,
        availableSpace: storageData.totalSpaceGB - storageData.usedSpaceGB,
        backupCount: backups.length,
        oldestBackup: backups.length > 0 ? backups[backups.length - 1].created_at : null,
        newestBackup: backups.length > 0 ? backups[0].created_at : null
      });

    } catch (error: any) {
      console.error('Error loading storage stats:', error);
      toast.error('Failed to load storage statistics: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStorageStats();
  }, []);

  const formatBytes = (bytes: number) => {
    return bytes.toFixed(2);
  };

  const getUsageStatus = () => {
    if (!stats) return { status: 'unknown', color: 'gray', icon: HardDrive };

    const usagePercentage = stats.usedSpace / stats.totalSpace * 100;

    if (usagePercentage < 70) {
      return { status: 'healthy', color: 'green', icon: CheckCircle };
    } else if (usagePercentage < 85) {
      return { status: 'warning', color: 'yellow', icon: AlertTriangle };
    } else {
      return { status: 'critical', color: 'red', icon: AlertTriangle };
    }
  };

  const usageStatus = getUsageStatus();

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <RefreshCw className="h-6 w-6 animate-spin" />
      </div>);

  }

  if (!stats) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Failed to load storage statistics</p>
        <Button onClick={loadStorageStats} className="mt-4">
          <RefreshCw className="mr-2 h-4 w-4" />
          Retry
        </Button>
      </div>);

  }

  const usagePercentage = stats.usedSpace / stats.totalSpace * 100;
  const backupPercentage = stats.backupSpace / stats.totalSpace * 100;

  return (
    <div className="space-y-6">
      {/* Storage Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Storage</p>
                <p className="text-2xl font-bold">{formatBytes(stats.totalSpace)} GB</p>
              </div>
              <HardDrive className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Used Storage</p>
                <p className="text-2xl font-bold">{formatBytes(stats.usedSpace)} GB</p>
              </div>
              <div className={`h-8 w-8 text-${usageStatus.color}-600`}>
                <usageStatus.icon className="h-8 w-8" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Available Storage</p>
                <p className="text-2xl font-bold">{formatBytes(stats.availableSpace)} GB</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Storage Usage Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Storage Usage</span>
            <Button variant="outline" size="sm" onClick={loadStorageStats}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Usage</span>
                <span>{usagePercentage.toFixed(1)}%</span>
              </div>
              <Progress
                value={usagePercentage}
                className={`h-3 ${usagePercentage > 85 ? 'bg-red-100' : usagePercentage > 70 ? 'bg-yellow-100' : 'bg-green-100'}`} />

            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Backup Files</span>
                <span>{backupPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={backupPercentage} className="h-2" />
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="font-medium text-gray-600">Backup Statistics</p>
              <p className="mt-1">Total Backups: {stats.backupCount}</p>
              <p>Backup Space: {formatBytes(stats.backupSpace)} GB</p>
            </div>
            <div>
              <p className="font-medium text-gray-600">Backup Timeline</p>
              {stats.oldestBackup &&
              <p className="mt-1">Oldest: {new Date(stats.oldestBackup).toLocaleDateString('en-US')}</p>
              }
              {stats.newestBackup &&
              <p>Newest: {new Date(stats.newestBackup).toLocaleDateString('en-US')}</p>
              }
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Storage Alerts */}
      {usagePercentage > 70 &&
      <Card className={`border-${usageStatus.color}-200 bg-${usageStatus.color}-50`}>
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertTriangle className={`h-5 w-5 text-${usageStatus.color}-600 mt-0.5`} />
              <div>
                <h4 className={`font-semibold text-${usageStatus.color}-900`}>
                  {usagePercentage > 85 ? 'Critical Storage Usage' : 'Storage Usage Warning'}
                </h4>
                <p className={`text-${usageStatus.color}-800 mt-1`}>
                  {usagePercentage > 85 ?
                'Storage usage is critically high. Consider cleaning up old backups or expanding storage capacity.' :
                'Storage usage is getting high. Monitor backup retention policies and consider cleanup.'
                }
                </p>
                {usagePercentage > 85 &&
              <div className="mt-3">
                    <Button size="sm" variant="outline">
                      View Cleanup Options
                    </Button>
                  </div>
              }
              </div>
            </div>
          </CardContent>
        </Card>
      }
    </div>);

};