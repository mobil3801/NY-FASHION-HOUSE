
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Save, AlertTriangle, Clock } from 'lucide-react';
import { toast } from 'sonner';

interface CleanupPolicy {
  enabled: boolean;
  retentionDays: number;
  maxBackupCount: number;
  autoCleanup: boolean;
  cleanupFrequency: 'daily' | 'weekly' | 'monthly';
  keepMinimum: number;
}

export const BackupCleanupSettings: React.FC = () => {
  const [policy, setPolicy] = useState<CleanupPolicy>({
    enabled: true,
    retentionDays: 30,
    maxBackupCount: 50,
    autoCleanup: true,
    cleanupFrequency: 'weekly',
    keepMinimum: 3
  });
  const [loading, setLoading] = useState(false);
  const [cleanupStats, setCleanupStats] = useState<{
    eligibleForCleanup: number;
    totalSize: number;
  } | null>(null);

  useEffect(() => {
    loadCleanupSettings();
    loadCleanupStats();
  }, []);

  const loadCleanupSettings = async () => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37722, {
        PageNo: 1,
        PageSize: 10,
        OrderByField: 'id',
        IsAsc: true,
        Filters: [
        {
          name: 'setting_key',
          op: 'StringStartsWith',
          value: 'backup_cleanup_'
        }]

      });

      if (error) throw new Error(error);

      const settingsMap: Record<string, any> = {};
      data?.List?.forEach((item: any) => {
        const key = item.setting_key.replace('backup_cleanup_', '');
        settingsMap[key] = item.setting_value;
      });

      if (Object.keys(settingsMap).length > 0) {
        setPolicy({
          enabled: settingsMap.enabled === 'true',
          retentionDays: parseInt(settingsMap.retentionDays) || 30,
          maxBackupCount: parseInt(settingsMap.maxBackupCount) || 50,
          autoCleanup: settingsMap.autoCleanup === 'true',
          cleanupFrequency: settingsMap.cleanupFrequency || 'weekly',
          keepMinimum: parseInt(settingsMap.keepMinimum) || 3
        });
      }
    } catch (error) {
      console.error('Error loading cleanup settings:', error);
    }
  };

  const loadCleanupStats = async () => {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - policy.retentionDays);

      const { data, error } = await window.ezsite.apis.tablePage(37724, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: true,
        Filters: [
        {
          name: 'status',
          op: 'Equal',
          value: 'completed'
        }]

      });

      if (error) throw new Error(error);

      const backups = data?.List || [];
      const eligibleBackups = backups.filter((backup: any) =>
      new Date(backup.created_at) < cutoffDate
      );

      const totalSize = eligibleBackups.reduce((sum: number, backup: any) =>
      sum + (backup.file_size || 0), 0
      );

      setCleanupStats({
        eligibleForCleanup: eligibleBackups.length,
        totalSize: totalSize / 1024 // Convert to GB
      });
    } catch (error) {
      console.error('Error loading cleanup stats:', error);
    }
  };

  const saveCleanupSettings = async () => {
    setLoading(true);

    try {
      const settingsToSave = [
      { key: 'backup_cleanup_enabled', value: policy.enabled.toString() },
      { key: 'backup_cleanup_retentionDays', value: policy.retentionDays.toString() },
      { key: 'backup_cleanup_maxBackupCount', value: policy.maxBackupCount.toString() },
      { key: 'backup_cleanup_autoCleanup', value: policy.autoCleanup.toString() },
      { key: 'backup_cleanup_cleanupFrequency', value: policy.cleanupFrequency },
      { key: 'backup_cleanup_keepMinimum', value: policy.keepMinimum.toString() }];


      for (const setting of settingsToSave) {
        // Check if setting exists
        const { data: existingData, error: checkError } = await window.ezsite.apis.tablePage(37722, {
          PageNo: 1,
          PageSize: 1,
          OrderByField: 'id',
          IsAsc: true,
          Filters: [
          {
            name: 'setting_key',
            op: 'Equal',
            value: setting.key
          }]

        });

        if (checkError) throw new Error(checkError);

        if (existingData?.List && existingData.List.length > 0) {
          // Update existing setting
          const { error: updateError } = await window.ezsite.apis.tableUpdate(37722, {
            ID: existingData.List[0].id,
            setting_value: setting.value
          });
          if (updateError) throw new Error(updateError);
        } else {
          // Create new setting
          const { error: createError } = await window.ezsite.apis.tableCreate(37722, {
            setting_key: setting.key,
            setting_value: setting.value,
            setting_description: `Backup cleanup setting: ${setting.key}`,
            created_at: new Date().toISOString()
          });
          if (createError) throw new Error(createError);
        }
      }

      toast.success('Cleanup settings saved successfully');
      loadCleanupStats(); // Refresh stats with new settings
    } catch (error: any) {
      console.error('Error saving cleanup settings:', error);
      toast.error('Failed to save settings: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const performManualCleanup = async () => {
    if (!confirm('Are you sure you want to clean up old backups? This action cannot be undone.')) {
      return;
    }

    setLoading(true);
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - policy.retentionDays);

      // Get backups eligible for cleanup
      const { data, error } = await window.ezsite.apis.tablePage(37724, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'created_at',
        IsAsc: true,
        Filters: [
        {
          name: 'status',
          op: 'Equal',
          value: 'completed'
        }]

      });

      if (error) throw new Error(error);

      const backups = data?.List || [];
      const eligibleBackups = backups.
      filter((backup: any) => new Date(backup.created_at) < cutoffDate).
      slice(policy.keepMinimum); // Keep minimum number of backups

      let cleanedCount = 0;
      for (const backup of eligibleBackups) {
        try {
          const { error: deleteError } = await window.ezsite.apis.tableDelete(37724, { ID: backup.id });
          if (!deleteError) {
            cleanedCount++;
          }
        } catch (deleteError) {
          console.error(`Failed to delete backup ${backup.id}:`, deleteError);
        }
      }

      toast.success(`Cleaned up ${cleanedCount} old backups`);
      loadCleanupStats(); // Refresh stats
    } catch (error: any) {
      console.error('Error performing cleanup:', error);
      toast.error('Failed to perform cleanup: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className={policy.enabled ? "bg-blue-50 border-blue-200" : "bg-gray-50 border-gray-200"}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trash2 className="h-5 w-5" />
            Cleanup Policy Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="cleanup-enabled" className="text-base font-medium">
                Enable Automatic Cleanup
              </Label>
              <p className="text-sm text-gray-600 mt-1">
                Automatically remove old backups according to retention policies
              </p>
            </div>
            <Switch
              id="cleanup-enabled"
              checked={policy.enabled}
              onCheckedChange={(enabled) => setPolicy((prev) => ({ ...prev, enabled }))} />

          </div>

          {cleanupStats && cleanupStats.eligibleForCleanup > 0 &&
          <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-900">Backups Ready for Cleanup</p>
                  <p className="text-yellow-800 text-sm mt-1">
                    {cleanupStats.eligibleForCleanup} backups ({cleanupStats.totalSize.toFixed(2)} GB) 
                    are eligible for cleanup based on current retention policy.
                  </p>
                </div>
              </div>
            </div>
          }
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Retention Policy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label>Retention Period (Days)</Label>
              <Input
                type="number"
                min="1"
                max="3650"
                value={policy.retentionDays}
                onChange={(e) => setPolicy((prev) => ({
                  ...prev,
                  retentionDays: parseInt(e.target.value) || 30
                }))}
                disabled={!policy.enabled} />

              <p className="text-sm text-gray-500">
                Backups older than this will be eligible for cleanup
              </p>
            </div>

            <div className="space-y-2">
              <Label>Maximum Backup Count</Label>
              <Input
                type="number"
                min="1"
                max="1000"
                value={policy.maxBackupCount}
                onChange={(e) => setPolicy((prev) => ({
                  ...prev,
                  maxBackupCount: parseInt(e.target.value) || 50
                }))}
                disabled={!policy.enabled} />

              <p className="text-sm text-gray-500">
                Maximum number of backups to keep regardless of age
              </p>
            </div>

            <div className="space-y-2">
              <Label>Minimum Backups to Keep</Label>
              <Input
                type="number"
                min="1"
                max="100"
                value={policy.keepMinimum}
                onChange={(e) => setPolicy((prev) => ({
                  ...prev,
                  keepMinimum: parseInt(e.target.value) || 3
                }))}
                disabled={!policy.enabled} />

              <p className="text-sm text-gray-500">
                Always keep at least this many backups, even if they exceed retention period
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Automatic Cleanup Schedule</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="auto-cleanup" className="text-base font-medium">
                Enable Scheduled Cleanup
              </Label>
              <p className="text-sm text-gray-600 mt-1">
                Automatically run cleanup according to schedule
              </p>
            </div>
            <Switch
              id="auto-cleanup"
              checked={policy.autoCleanup}
              onCheckedChange={(autoCleanup) => setPolicy((prev) => ({ ...prev, autoCleanup }))}
              disabled={!policy.enabled} />

          </div>

          {policy.autoCleanup &&
          <div className="space-y-2">
              <Label>Cleanup Frequency</Label>
              <Select
              value={policy.cleanupFrequency}
              onValueChange={(value: 'daily' | 'weekly' | 'monthly') =>
              setPolicy((prev) => ({ ...prev, cleanupFrequency: value }))
              }
              disabled={!policy.enabled}>

                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          }
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={performManualCleanup}
          disabled={loading || !policy.enabled || !cleanupStats?.eligibleForCleanup}>

          <Trash2 className="mr-2 h-4 w-4" />
          Run Cleanup Now
        </Button>

        <Button onClick={saveCleanupSettings} disabled={loading}>
          {loading ?
          <>
              <Clock className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </> :

          <>
              <Save className="mr-2 h-4 w-4" />
              Save Settings
            </>
          }
        </Button>
      </div>
    </div>);

};