
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Clock, Calendar, Save } from 'lucide-react';
import { toast } from 'sonner';

interface ScheduleSettings {
  enabled: boolean;
  frequency: 'daily' | 'weekly' | 'monthly';
  time: string;
  dayOfWeek?: number; // For weekly (0=Sunday, 1=Monday, etc.)
  dayOfMonth?: number; // For monthly
  retentionDays: number;
}

export const BackupScheduler: React.FC = () => {
  const [settings, setSettings] = useState<ScheduleSettings>({
    enabled: false,
    frequency: 'daily',
    time: '02:00',
    retentionDays: 30
  });
  const [loading, setLoading] = useState(false);
  const [lastScheduledBackup, setLastScheduledBackup] = useState<string | null>(null);

  useEffect(() => {
    loadScheduleSettings();
    loadLastScheduledBackup();
  }, []);

  const loadScheduleSettings = async () => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37722, {
        PageNo: 1,
        PageSize: 10,
        OrderByField: 'id',
        IsAsc: true,
        Filters: [
        {
          name: 'setting_key',
          op: 'StringStartsWith',
          value: 'backup_schedule_'
        }]

      });

      if (error) throw new Error(error);

      const settingsMap: Record<string, any> = {};
      data?.List?.forEach((item: any) => {
        const key = item.setting_key.replace('backup_schedule_', '');
        settingsMap[key] = item.setting_value;
      });

      if (Object.keys(settingsMap).length > 0) {
        setSettings({
          enabled: settingsMap.enabled === 'true',
          frequency: settingsMap.frequency || 'daily',
          time: settingsMap.time || '02:00',
          dayOfWeek: settingsMap.dayOfWeek ? parseInt(settingsMap.dayOfWeek) : undefined,
          dayOfMonth: settingsMap.dayOfMonth ? parseInt(settingsMap.dayOfMonth) : undefined,
          retentionDays: settingsMap.retentionDays ? parseInt(settingsMap.retentionDays) : 30
        });
      }
    } catch (error) {
      console.error('Error loading schedule settings:', error);
    }
  };

  const loadLastScheduledBackup = async () => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37724, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: [
        {
          name: 'backup_type',
          op: 'Equal',
          value: 'scheduled'
        }]

      });

      if (error) throw new Error(error);

      if (data?.List && data.List.length > 0) {
        setLastScheduledBackup(data.List[0].created_at);
      }
    } catch (error) {
      console.error('Error loading last scheduled backup:', error);
    }
  };

  const saveScheduleSettings = async () => {
    setLoading(true);

    try {
      const settingsToSave = [
      { key: 'backup_schedule_enabled', value: settings.enabled.toString() },
      { key: 'backup_schedule_frequency', value: settings.frequency },
      { key: 'backup_schedule_time', value: settings.time },
      { key: 'backup_schedule_retentionDays', value: settings.retentionDays.toString() }];


      if (settings.frequency === 'weekly' && settings.dayOfWeek !== undefined) {
        settingsToSave.push({ key: 'backup_schedule_dayOfWeek', value: settings.dayOfWeek.toString() });
      }

      if (settings.frequency === 'monthly' && settings.dayOfMonth !== undefined) {
        settingsToSave.push({ key: 'backup_schedule_dayOfMonth', value: settings.dayOfMonth.toString() });
      }

      for (const setting of settingsToSave) {
        // Check if setting exists
        const { data: existingData, error: checkError } = await window.ezsite.apis.tablePage(37722, {
          PageNo: 1,
          PageSize: 1,
          OrderByField: 'id',
          IsAsc: true,
          Filters: [
          {
            name: 'setting_key',
            op: 'Equal',
            value: setting.key
          }]

        });

        if (checkError) throw new Error(checkError);

        if (existingData?.List && existingData.List.length > 0) {
          // Update existing setting
          const { error: updateError } = await window.ezsite.apis.tableUpdate(37722, {
            ID: existingData.List[0].id,
            setting_value: setting.value
          });
          if (updateError) throw new Error(updateError);
        } else {
          // Create new setting
          const { error: createError } = await window.ezsite.apis.tableCreate(37722, {
            setting_key: setting.key,
            setting_value: setting.value,
            setting_description: `Backup schedule setting: ${setting.key}`,
            created_at: new Date().toISOString()
          });
          if (createError) throw new Error(createError);
        }
      }

      toast.success('Backup schedule settings saved successfully');
    } catch (error: any) {
      console.error('Error saving schedule settings:', error);
      toast.error('Failed to save settings: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const getNextScheduledTime = () => {
    if (!settings.enabled) return null;

    const now = new Date();
    const [hours, minutes] = settings.time.split(':').map(Number);

    let nextRun = new Date();
    nextRun.setHours(hours, minutes, 0, 0);

    switch (settings.frequency) {
      case 'daily':
        if (nextRun <= now) {
          nextRun.setDate(nextRun.getDate() + 1);
        }
        break;
      case 'weekly':
        const targetDay = settings.dayOfWeek || 0;
        const currentDay = nextRun.getDay();
        const daysUntilTarget = (targetDay - currentDay + 7) % 7;
        nextRun.setDate(nextRun.getDate() + (daysUntilTarget || 7));
        if (nextRun <= now && daysUntilTarget === 0) {
          nextRun.setDate(nextRun.getDate() + 7);
        }
        break;
      case 'monthly':
        const targetDate = settings.dayOfMonth || 1;
        nextRun.setDate(targetDate);
        if (nextRun <= now) {
          nextRun.setMonth(nextRun.getMonth() + 1);
        }
        break;
    }

    return nextRun;
  };

  const nextScheduledTime = getNextScheduledTime();

  return (
    <div className="space-y-6">
      <Card className={settings.enabled ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Schedule Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="schedule-enabled" className="text-base font-medium">
                  Enable Automatic Backups
                </Label>
                <p className="text-sm text-gray-600 mt-1">
                  Automatically create backups according to the schedule below
                </p>
              </div>
              <Switch
                id="schedule-enabled"
                checked={settings.enabled}
                onCheckedChange={(enabled) => setSettings((prev) => ({ ...prev, enabled }))} />

            </div>

            {settings.enabled && nextScheduledTime &&
            <div className="pt-4 border-t">
                <p className="text-sm font-medium text-green-800">
                  Next scheduled backup: {nextScheduledTime.toLocaleString('en-US')}
                </p>
              </div>
            }

            {lastScheduledBackup &&
            <div className="pt-2">
                <p className="text-sm text-gray-600">
                  Last scheduled backup: {new Date(lastScheduledBackup).toLocaleString('en-US')}
                </p>
              </div>
            }
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Schedule Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label>Backup Frequency</Label>
              <Select
                value={settings.frequency}
                onValueChange={(value: 'daily' | 'weekly' | 'monthly') =>
                setSettings((prev) => ({ ...prev, frequency: value }))
                }
                disabled={!settings.enabled}>

                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Backup Time</Label>
              <Input
                type="time"
                value={settings.time}
                onChange={(e) => setSettings((prev) => ({ ...prev, time: e.target.value }))}
                disabled={!settings.enabled} />

            </div>

            {settings.frequency === 'weekly' &&
            <div className="space-y-2">
                <Label>Day of Week</Label>
                <Select
                value={settings.dayOfWeek?.toString()}
                onValueChange={(value) =>
                setSettings((prev) => ({ ...prev, dayOfWeek: parseInt(value) }))
                }
                disabled={!settings.enabled}>

                  <SelectTrigger>
                    <SelectValue placeholder="Select day" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Sunday</SelectItem>
                    <SelectItem value="1">Monday</SelectItem>
                    <SelectItem value="2">Tuesday</SelectItem>
                    <SelectItem value="3">Wednesday</SelectItem>
                    <SelectItem value="4">Thursday</SelectItem>
                    <SelectItem value="5">Friday</SelectItem>
                    <SelectItem value="6">Saturday</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            }

            {settings.frequency === 'monthly' &&
            <div className="space-y-2">
                <Label>Day of Month</Label>
                <Select
                value={settings.dayOfMonth?.toString()}
                onValueChange={(value) =>
                setSettings((prev) => ({ ...prev, dayOfMonth: parseInt(value) }))
                }
                disabled={!settings.enabled}>

                  <SelectTrigger>
                    <SelectValue placeholder="Select day" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 28 }, (_, i) => i + 1).map((day) =>
                  <SelectItem key={day} value={day.toString()}>
                        {day}
                      </SelectItem>
                  )}
                  </SelectContent>
                </Select>
              </div>
            }

            <div className="space-y-2">
              <Label>Retention Days</Label>
              <Input
                type="number"
                min="1"
                max="365"
                value={settings.retentionDays}
                onChange={(e) => setSettings((prev) => ({
                  ...prev,
                  retentionDays: parseInt(e.target.value) || 30
                }))}
                disabled={!settings.enabled}
                placeholder="Days to keep backups" />

              <p className="text-sm text-gray-500">
                Number of days to keep scheduled backups before automatic cleanup
              </p>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t">
            <Button onClick={saveScheduleSettings} disabled={loading}>
              {loading ?
              <>
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </> :

              <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Schedule
                </>
              }
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>);

};