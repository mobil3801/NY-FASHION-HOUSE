
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Shield, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface ManualBackupFormProps {
  onBackupCreated: () => void;
}

export const ManualBackupForm: React.FC<ManualBackupFormProps> = ({ onBackupCreated }) => {
  const [formData, setFormData] = useState({
    backupName: '',
    description: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.backupName.trim()) {
      toast.error('Please enter a backup name');
      return;
    }

    setLoading(true);

    try {
      // Create backup record
      const backupRecord = {
        backup_name: formData.backupName.trim(),
        description: formData.description.trim(),
        backup_type: 'manual',
        schedule_frequency: '',
        status: 'pending',
        file_size: 0,
        backup_path: '',
        created_at: new Date().toISOString(),
        completed_at: '',
        error_message: '',
        retention_days: 30
      };

      const { error: createError } = await window.ezsite.apis.tableCreate(37724, backupRecord);
      if (createError) throw new Error(createError);

      // Get the created backup record
      const { data: backupData, error: fetchError } = await window.ezsite.apis.tablePage(37724, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'id',
        IsAsc: false,
        Filters: [
        {
          name: 'backup_name',
          op: 'Equal',
          value: formData.backupName.trim()
        }]

      });

      if (fetchError) throw new Error(fetchError);
      const backupId = backupData?.List[0]?.id;

      if (!backupId) {
        throw new Error('Failed to retrieve backup record ID');
      }

      // Start backup process
      toast.success('Backup initiated successfully');

      // Update status to in_progress
      await window.ezsite.apis.tableUpdate(37724, {
        ID: backupId,
        status: 'in_progress'
      });

      // Simulate backup process with Node.js function
      try {
        const { data: backupResult, error: backupError } = await window.ezsite.apis.run({
          path: 'createDatabaseBackup',
          param: [backupId, formData.backupName.trim()]
        });

        if (backupError) throw new Error(backupError);

        // Update backup record with completion details
        await window.ezsite.apis.tableUpdate(37724, {
          ID: backupId,
          status: 'completed',
          file_size: backupResult.fileSize,
          backup_path: backupResult.filePath,
          completed_at: new Date().toISOString()
        });

        toast.success('Backup completed successfully');
      } catch (backupError: any) {
        // Update backup record with error
        await window.ezsite.apis.tableUpdate(37724, {
          ID: backupId,
          status: 'failed',
          error_message: backupError.message || 'Backup process failed',
          completed_at: new Date().toISOString()
        });

        toast.error(`Backup failed: ${backupError.message}`);
      }

      // Reset form
      setFormData({ backupName: '', description: '' });
      onBackupCreated();

    } catch (error: any) {
      console.error('Error creating backup:', error);
      toast.error('Failed to create backup: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <Shield className="h-6 w-6 text-blue-600 mt-1" />
            <div>
              <h3 className="font-semibold text-blue-900 mb-2">Manual Backup Information</h3>
              <div className="text-sm text-blue-800 space-y-1">
                <p>• Creates a complete snapshot of all system data</p>
                <p>• Includes customer, product, sales, and configuration data</p>
                <p>• Backup will be stored securely and can be downloaded</p>
                <p>• Default retention period: 30 days</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid gap-4">
          <div className="space-y-2">
            <Label htmlFor="backupName">
              Backup Name <span className="text-red-500">*</span>
            </Label>
            <Input
              id="backupName"
              type="text"
              placeholder="Enter backup name (e.g., Manual_Backup_2024_01_15)"
              value={formData.backupName}
              onChange={(e) => setFormData((prev) => ({ ...prev, backupName: e.target.value }))}
              disabled={loading}
              required />

          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              placeholder="Enter backup description or notes..."
              value={formData.description}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              disabled={loading}
              rows={3} />

          </div>
        </div>

        <div className="flex justify-end">
          <Button
            type="submit"
            disabled={loading || !formData.backupName.trim()}
            className="min-w-32">

            {loading ?
            <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Creating...
              </> :

            <>
                <Shield className="mr-2 h-4 w-4" />
                Create Backup
              </>
            }
          </Button>
        </div>
      </form>
    </div>);

};