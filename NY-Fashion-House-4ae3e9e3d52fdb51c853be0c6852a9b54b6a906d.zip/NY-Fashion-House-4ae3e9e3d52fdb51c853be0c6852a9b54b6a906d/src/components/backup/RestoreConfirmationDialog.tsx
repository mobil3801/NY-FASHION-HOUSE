
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle } from
'@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { AlertTriangle, RotateCcw, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface BackupRecord {
  id: number;
  backup_name: string;
  description: string;
  backup_type: string;
  status: string;
  file_size: number;
  backup_path: string;
  created_at: string;
  completed_at: string;
}

interface RestoreConfirmationDialogProps {
  backup: BackupRecord;
  onClose: () => void;
  onConfirm: () => void;
}

export const RestoreConfirmationDialog: React.FC<RestoreConfirmationDialogProps> = ({
  backup,
  onClose,
  onConfirm
}) => {
  const [confirmationText, setConfirmationText] = useState('');
  const [acknowledgedRisks, setAcknowledgedRisks] = useState(false);
  const [currentDataBackup, setCurrentDataBackup] = useState(false);
  const [restoreInProgress, setRestoreInProgress] = useState(false);

  const expectedText = 'RESTORE BACKUP';
  const canProceed = confirmationText === expectedText && acknowledgedRisks && currentDataBackup;

  const handleRestore = async () => {
    setRestoreInProgress(true);

    try {
      // First, validate the restore operation
      const { data: validationResult, error: validationError } = await window.ezsite.apis.run({
        path: 'validateRestoreOperation',
        param: [backup.id, backup.backup_path]
      });

      if (validationError) throw new Error(validationError);

      if (!validationResult.isValid) {
        throw new Error(validationResult.reason || 'Backup file is not valid for restore');
      }

      // Create a backup of current data if requested
      if (currentDataBackup) {
        const backupName = `Pre_Restore_Backup_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}`;

        const backupRecord = {
          backup_name: backupName,
          description: `Automatic backup created before restore operation of ${backup.backup_name}`,
          backup_type: 'manual',
          schedule_frequency: '',
          status: 'pending',
          file_size: 0,
          backup_path: '',
          created_at: new Date().toISOString(),
          completed_at: '',
          error_message: '',
          retention_days: 90 // Keep pre-restore backups longer
        };

        const { error: createError } = await window.ezsite.apis.tableCreate(37724, backupRecord);
        if (createError) throw new Error(createError);

        // Get the created backup ID
        const { data: backupData, error: fetchError } = await window.ezsite.apis.tablePage(37724, {
          PageNo: 1,
          PageSize: 1,
          OrderByField: 'id',
          IsAsc: false,
          Filters: [
          {
            name: 'backup_name',
            op: 'Equal',
            value: backupName
          }]

        });

        if (fetchError) throw new Error(fetchError);
        const preRestoreBackupId = backupData?.List[0]?.id;

        if (preRestoreBackupId) {
          // Create pre-restore backup
          const { error: preBackupError } = await window.ezsite.apis.run({
            path: 'createDatabaseBackup',
            param: [preRestoreBackupId, backupName]
          });

          if (preBackupError) {
            console.error('Failed to create pre-restore backup:', preBackupError);
            // Continue with restore but log the issue
          }
        }
      }

      // Perform the actual restore operation
      toast.info('Starting restore operation... This may take several minutes.');

      // Note: In a real implementation, you would have a Node.js function for restore
      // For now, we'll simulate the restore operation
      await new Promise((resolve) => setTimeout(resolve, 3000)); // Simulate restore time

      // Log the restore operation in audit logs
      const auditRecord = {
        user_id: 1, // You would get this from current user context
        action: 'RESTORE_BACKUP',
        resource_type: 'SYSTEM',
        resource_id: backup.id.toString(),
        details: `Restored system from backup: ${backup.backup_name} (Created: ${backup.created_at})`,
        ip_address: 'localhost', // You would get this from request context
        user_agent: navigator.userAgent,
        timestamp: new Date().toISOString(),
        status: 'SUCCESS'
      };

      await window.ezsite.apis.tableCreate(37723, auditRecord);

      toast.success('Backup restored successfully! The system has been restored to the selected backup state.');
      onConfirm();

    } catch (error: any) {
      console.error('Error during restore:', error);

      // Log the failed restore attempt
      try {
        const auditRecord = {
          user_id: 1,
          action: 'RESTORE_BACKUP',
          resource_type: 'SYSTEM',
          resource_id: backup.id.toString(),
          details: `Failed to restore system from backup: ${backup.backup_name}. Error: ${error.message}`,
          ip_address: 'localhost',
          user_agent: navigator.userAgent,
          timestamp: new Date().toISOString(),
          status: 'FAILED'
        };

        await window.ezsite.apis.tableCreate(37723, auditRecord);
      } catch (auditError) {
        console.error('Failed to log audit record:', auditError);
      }

      toast.error('Restore failed: ' + error.message);
    } finally {
      setRestoreInProgress(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            Confirm System Restore
          </DialogTitle>
          <DialogDescription className="text-base">
            You are about to restore the entire system from a backup. This is a critical operation that cannot be undone.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Backup Information */}
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="pt-6">
              <h4 className="font-semibold text-blue-900 mb-3">Backup Information</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium text-gray-700">Name:</p>
                  <p className="text-gray-900">{backup.backup_name}</p>
                </div>
                <div>
                  <p className="font-medium text-gray-700">Created:</p>
                  <p className="text-gray-900">{new Date(backup.created_at).toLocaleString('en-US')}</p>
                </div>
                <div>
                  <p className="font-medium text-gray-700">Size:</p>
                  <p className="text-gray-900">{(backup.file_size / 1024).toFixed(2)} GB</p>
                </div>
                <div>
                  <p className="font-medium text-gray-700">Type:</p>
                  <p className="text-gray-900">{backup.backup_type === 'manual' ? 'Manual' : 'Scheduled'}</p>
                </div>
                {backup.description &&
                <div className="col-span-2">
                    <p className="font-medium text-gray-700">Description:</p>
                    <p className="text-gray-900">{backup.description}</p>
                  </div>
                }
              </div>
            </CardContent>
          </Card>

          {/* Warning Messages */}
          <Card className="bg-red-50 border-red-200">
            <CardContent className="pt-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-red-900 flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4" />
                  CRITICAL WARNINGS
                </h4>
                <div className="text-sm text-red-800 space-y-2">
                  <p>• This will replace ALL current system data with data from the selected backup</p>
                  <p>• All changes made after {new Date(backup.created_at).toLocaleString('en-US')} will be PERMANENTLY LOST</p>
                  <p>• This operation cannot be undone once started</p>
                  <p>• The system will be unavailable during the restore process</p>
                  <p>• All users will be logged out and need to sign in again</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Acknowledgment Checkboxes */}
          <div className="space-y-4">
            <div className="flex items-start space-x-2">
              <Checkbox
                id="acknowledge-risks"
                checked={acknowledgedRisks}
                onCheckedChange={(checked) => setAcknowledgedRisks(!!checked)} />

              <Label htmlFor="acknowledge-risks" className="text-sm leading-5">
                I understand the risks and consequences of this restore operation. I acknowledge that all current data will be replaced and recent changes will be lost.
              </Label>
            </div>

            <div className="flex items-start space-x-2">
              <Checkbox
                id="current-backup"
                checked={currentDataBackup}
                onCheckedChange={(checked) => setCurrentDataBackup(!!checked)} />

              <Label htmlFor="current-backup" className="text-sm leading-5">
                Create an automatic backup of current data before restore (Recommended)
              </Label>
            </div>
          </div>

          {/* Confirmation Input */}
          <div className="space-y-2">
            <Label htmlFor="confirmation-text">
              Type <span className="font-mono bg-gray-100 px-2 py-1 rounded">{expectedText}</span> to confirm:
            </Label>
            <Input
              id="confirmation-text"
              type="text"
              placeholder={`Type "${expectedText}" to confirm`}
              value={confirmationText}
              onChange={(e) => setConfirmationText(e.target.value)}
              className={confirmationText === expectedText ? 'border-green-500' : ''} />

          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} disabled={restoreInProgress}>
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={handleRestore}
            disabled={!canProceed || restoreInProgress}>

            {restoreInProgress ?
            <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Restoring...
              </> :

            <>
                <RotateCcw className="mr-2 h-4 w-4" />
                Restore System
              </>
            }
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>);

};