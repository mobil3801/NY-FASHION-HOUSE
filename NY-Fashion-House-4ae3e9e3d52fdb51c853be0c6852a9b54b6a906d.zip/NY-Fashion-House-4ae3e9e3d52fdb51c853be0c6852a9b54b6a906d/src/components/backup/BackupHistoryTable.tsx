
import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow } from
'@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RestoreConfirmationDialog } from './RestoreConfirmationDialog';
import { Download, RotateCcw, Trash2, Eye } from 'lucide-react';
import { toast } from 'sonner';

interface BackupRecord {
  id: number;
  backup_name: string;
  description: string;
  backup_type: string;
  status: string;
  file_size: number;
  backup_path: string;
  created_at: string;
  completed_at: string;
  error_message: string;
  retention_days: number;
}

interface BackupHistoryTableProps {
  refreshTrigger: number;
}

export const BackupHistoryTable: React.FC<BackupHistoryTableProps> = ({ refreshTrigger }) => {
  const [backups, setBackups] = useState<BackupRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBackup, setSelectedBackup] = useState<BackupRecord | null>(null);
  const [showRestoreDialog, setShowRestoreDialog] = useState(false);

  const loadBackups = async () => {
    try {
      setLoading(true);
      const { data, error } = await window.ezsite.apis.tablePage(37724, {
        PageNo: 1,
        PageSize: 50,
        OrderByField: 'created_at',
        IsAsc: false,
        Filters: []
      });

      if (error) throw new Error(error);
      setBackups(data?.List || []);
    } catch (error) {
      console.error('Error loading backups:', error);
      toast.error('Failed to load backup history');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBackups();
  }, [refreshTrigger]);

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      completed: { variant: 'default' as const, text: 'Completed', className: 'bg-green-100 text-green-800' },
      pending: { variant: 'secondary' as const, text: 'Pending', className: 'bg-yellow-100 text-yellow-800' },
      in_progress: { variant: 'secondary' as const, text: 'In Progress', className: 'bg-blue-100 text-blue-800' },
      failed: { variant: 'destructive' as const, text: 'Failed', className: 'bg-red-100 text-red-800' }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;

    return (
      <Badge variant={config.variant} className={config.className}>
        {config.text}
      </Badge>);

  };

  const handleDownload = async (backup: BackupRecord) => {
    try {
      // Call Node.js function to generate download URL
      const { data: downloadUrl, error } = await window.ezsite.apis.run({
        path: 'generateBackupDownloadUrl',
        param: [backup.id, backup.backup_path]
      });

      if (error) throw new Error(error);

      // Create temporary link and trigger download
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = backup.backup_name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Backup download started');
    } catch (error) {
      console.error('Error downloading backup:', error);
      toast.error('Failed to download backup');
    }
  };

  const handleRestore = (backup: BackupRecord) => {
    setSelectedBackup(backup);
    setShowRestoreDialog(true);
  };

  const handleDelete = async (backup: BackupRecord) => {
    if (!confirm('Are you sure you want to delete this backup? This action cannot be undone.')) {
      return;
    }

    try {
      const { error } = await window.ezsite.apis.tableDelete(37724, { ID: backup.id });
      if (error) throw new Error(error);

      toast.success('Backup deleted successfully');
      loadBackups();
    } catch (error) {
      console.error('Error deleting backup:', error);
      toast.error('Failed to delete backup');
    }
  };

  const formatFileSize = (sizeInMB: number) => {
    if (sizeInMB < 1024) {
      return `${sizeInMB.toFixed(1)} MB`;
    }
    return `${(sizeInMB / 1024).toFixed(2)} GB`;
  };

  if (loading) {
    return <div className="flex justify-center py-8">Loading backup history...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Backup Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>File Size</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Completed</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {backups.length === 0 ?
            <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                  No backup history found
                </TableCell>
              </TableRow> :

            backups.map((backup) =>
            <TableRow key={backup.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{backup.backup_name}</div>
                      {backup.description &&
                  <div className="text-sm text-gray-500">{backup.description}</div>
                  }
                      {backup.error_message &&
                  <div className="text-sm text-red-500 mt-1">{backup.error_message}</div>
                  }
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {backup.backup_type === 'manual' ? 'Manual' : 'Scheduled'}
                    </Badge>
                  </TableCell>
                  <TableCell>{getStatusBadge(backup.status)}</TableCell>
                  <TableCell>
                    {backup.file_size > 0 ? formatFileSize(backup.file_size) : '-'}
                  </TableCell>
                  <TableCell>
                    {format(new Date(backup.created_at), 'MM/dd/yyyy hh:mm a')}
                  </TableCell>
                  <TableCell>
                    {backup.completed_at ?
                format(new Date(backup.completed_at), 'MM/dd/yyyy hh:mm a') :
                '-'
                }
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {backup.status === 'completed' &&
                  <>
                          <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDownload(backup)}
                      className="h-8">

                            <Download className="h-3 w-3" />
                          </Button>
                          <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleRestore(backup)}
                      className="h-8">

                            <RotateCcw className="h-3 w-3" />
                          </Button>
                        </>
                  }
                      <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(backup)}
                    className="h-8 text-red-600 hover:text-red-700">

                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
            )
            }
          </TableBody>
        </Table>
      </div>

      {showRestoreDialog && selectedBackup &&
      <RestoreConfirmationDialog
        backup={selectedBackup}
        onClose={() => {
          setShowRestoreDialog(false);
          setSelectedBackup(null);
        }}
        onConfirm={() => {
          loadBackups();
          setShowRestoreDialog(false);
          setSelectedBackup(null);
        }} />

      }
    </div>);

};