import React, { useState, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Upload, X, Image as ImageIcon, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { requestSizeManager, formatFileSize, isFileSizeValid } from '@/utils/requestSizeManager';

interface ImageUploaderProps {
  value: number[];
  onChange: (imageIds: number[]) => void;
  maxFiles?: number;
  maxFileSize?: number; // in MB
  disabled?: boolean;
  className?: string;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({
  value = [],
  onChange,
  maxFiles = 5,
  maxFileSize = 5,
  disabled = false,
  className = ''
}) => {
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const handleFileUpload = useCallback(async (files: FileList) => {
    if (!files || files.length === 0) return;

    const fileArray = Array.from(files);

    // Validate file count
    if (value.length + fileArray.length > maxFiles) {
      toast.error(`Maximum ${maxFiles} files allowed`);
      return;
    }

    // Enhanced validation with size management
    const validFiles: File[] = [];
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

    for (const file of fileArray) {
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} is not an image file`);
        continue;
      }

      // Use request size manager for validation and potential compression
      const validation = await requestSizeManager.validateAndResizeImage(file, {
        maxFileSize: maxFileSize,
        allowedTypes,
        compressionQuality: 0.8
      });

      if (!validation.isValid) {
        toast.error(`${file.name}: ${validation.error}`);
        continue;
      }

      validFiles.push(validation.file!);
    }

    if (validFiles.length === 0) return;

    setUploading(true);
    const uploadedIds: number[] = [];

    try {
      // Process uploads with progress tracking
      for (let i = 0; i < validFiles.length; i++) {
        const file = validFiles[i];
        try {
          // Check if file needs chunked upload
          if (file.size > 10 * 1024 * 1024) {// 10MB threshold for chunking
            toast.info(`Uploading large file: ${file.name} (${formatFileSize(file.size)})`);

            const result = await requestSizeManager.uploadFileInChunks(file, '/api/upload', {
              onProgress: (progress) => {
                toast.info(`Uploading ${file.name}: ${Math.round(progress)}%`, {
                  id: `upload-${i}`,
                  duration: 1000
                });
              }
            });

            if (!result.success) {
              throw new Error(result.error || 'Upload failed');
            }

            if (result.fileId) {
              uploadedIds.push(result.fileId);
            }
          } else {
            // Standard upload for smaller files
            const { data: fileId, error } = await window.ezsite.apis.upload({
              filename: file.name,
              file: file
            });

            if (error) {
              throw new Error(error);
            }

            if (fileId) {
              uploadedIds.push(fileId);
            }
          }

          toast.dismiss(`upload-${i}`); // Clear progress toast
        } catch (error) {
          console.error(`Failed to upload ${file.name}:`, error);
          toast.error(`Failed to upload ${file.name}: ${(error as Error).message}`);
        }
      }

      if (uploadedIds.length > 0) {
        onChange([...value, ...uploadedIds]);
        toast.success(`Successfully uploaded ${uploadedIds.length} image(s)`);
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Upload failed');
    } finally {
      setUploading(false);
    }
  }, [value, onChange, maxFiles, maxFileSize]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);

    if (disabled || uploading) return;

    handleFileUpload(e.dataTransfer.files);
  }, [disabled, uploading, handleFileUpload]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled && !uploading) {
      setDragOver(true);
    }
  }, [disabled, uploading]);

  const handleDragLeave = useCallback(() => {
    setDragOver(false);
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFileUpload(e.target.files);
      e.target.value = ''; // Reset input
    }
  };

  const removeImage = (imageIdToRemove: number) => {
    onChange(value.filter((id) => id !== imageIdToRemove));
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Upload Area */}
      <Card
        className={`transition-colors cursor-pointer ${
        dragOver ? 'border-blue-500 bg-blue-50' : 'border-dashed border-gray-300'} ${
        disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}>

        <CardContent className="py-8">
          <div className="text-center">
            <div className="mx-auto w-12 h-12 mb-4 flex items-center justify-center rounded-full bg-gray-100">
              <Upload className="h-6 w-6 text-gray-400" />
            </div>
            
            <div className="space-y-2">
              <p className="text-sm font-medium">
                {uploading ? 'Uploading...' : 'Drop images here or click to browse'}
              </p>
              <p className="text-xs text-gray-500">
                Max {maxFiles} files, {maxFileSize}MB each. PNG, JPG, GIF supported.
              </p>
            </div>

            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileSelect}
              disabled={disabled || uploading}
              className="hidden"
              id="image-upload" />

            
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="mt-4"
              disabled={disabled || uploading || value.length >= maxFiles}
              onClick={() => document.getElementById('image-upload')?.click()}>

              <Upload className="h-4 w-4 mr-2" />
              {uploading ? 'Uploading...' : 'Choose Images'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Uploaded Images */}
      {value.length > 0 &&
      <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium">Uploaded Images</h4>
            <Badge variant="secondary">
              {value.length} of {maxFiles}
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {value.map((imageId) =>
          <ImagePreview
            key={imageId}
            imageId={imageId}
            onRemove={() => removeImage(imageId)}
            disabled={disabled} />

          )}
          </div>
        </div>
      }
    </div>);

};

// Image Preview Component
interface ImagePreviewProps {
  imageId: number;
  onRemove: () => void;
  disabled: boolean;
}

const ImagePreview: React.FC<ImagePreviewProps> = ({ imageId, onRemove, disabled }) => {
  const [imageUrl, setImageUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  React.useEffect(() => {
    const loadImage = async () => {
      try {
        const { data: url, error: urlError } = await window.ezsite.apis.getUploadUrl(imageId);

        if (urlError) {
          throw new Error(urlError);
        }

        setImageUrl(url);
      } catch (error) {
        console.error('Failed to load image:', error);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    loadImage();
  }, [imageId]);

  if (loading) {
    return (
      <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
        <ImageIcon className="h-8 w-8 text-gray-400" />
      </div>);

  }

  if (error) {
    return (
      <div className="aspect-square bg-red-50 rounded-lg flex flex-col items-center justify-center relative group">
        <AlertCircle className="h-8 w-8 text-red-400" />
        <p className="text-xs text-red-600 mt-1">Failed to load</p>
        
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={onRemove}
          disabled={disabled}>

          <X className="h-4 w-4" />
        </Button>
      </div>);

  }

  return (
    <div className="relative group aspect-square">
      <img
        src={imageUrl}
        alt="Uploaded"
        className="w-full h-full object-cover rounded-lg" />

      
      <Button
        type="button"
        variant="destructive"
        size="sm"
        className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={onRemove}
        disabled={disabled}>

        <X className="h-4 w-4" />
      </Button>
    </div>);

};

export default ImageUploader;