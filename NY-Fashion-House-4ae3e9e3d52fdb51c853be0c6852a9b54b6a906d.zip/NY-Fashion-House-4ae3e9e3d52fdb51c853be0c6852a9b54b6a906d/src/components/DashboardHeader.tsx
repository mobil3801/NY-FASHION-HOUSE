
import React, { useState } from 'react';
import { Bell, User, Settings, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AvatarWithFallback from '@/components/ui/avatar-with-fallback';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger } from
'@/components/ui/dropdown-menu';
import ThreeDotsMenu from './ThreeDotsMenu';
import NavigationMenu from './NavigationMenu';
import HorizontalNavigation from './HorizontalNavigation';
import ThemeToggle from '@/components/ThemeToggle';
import UserUpdateLogsDropdown from '@/components/UserUpdateLogsDropdown';

interface DashboardHeaderProps {
  onToggleSidebar?: () => void;
}

const DashboardHeader = ({ onToggleSidebar }: DashboardHeaderProps) => {
  const [isNavigationOpen, setIsNavigationOpen] = useState(false);

  return (
    <header
      className="shadow-sm sticky top-0 z-50 transition-colors duration-300"
      style={{
        backgroundColor: 'var(--theme-card)',
        borderBottom: '1px solid var(--theme-border)'
      }}>

      {/* Main header bar */}
      <div className="px-4 py-2">
        <div className="flex justify-between items-center">
          {/* Left side: Three Dots Menu and Logo */}
          <div className="flex items-center space-x-3">
            <ThreeDotsMenu
              isOpen={isNavigationOpen}
              onClick={() => setIsNavigationOpen(!isNavigationOpen)} />

            <div className="flex items-center space-x-3">
              {/* Reduced Logo Container */}
              <div
                className="w-12 h-12 sm:w-16 sm:h-16 rounded-lg flex items-center justify-center transition-colors duration-300">

                <img
                  src="https://cdn.ezsite.ai/AutoDev/19016/95c2a8a3-4455-4cc1-91c1-442a3cf63926.jpeg"
                  alt="NY FASHION HOUSE Logo"
                  className="w-full h-full object-contain rounded-lg" />

              </div>
            </div>
          </div>

          {/* Right side: Business Name and Icons - Aligned to the far right */}
          <div className="flex flex-col items-end space-y-0.5">
            {/* Business Name */}
            <div className="hidden sm:block text-right mb-0.5">
              <h1
                className="text-center text-lg sm:text-xl font-bold transition-colors duration-300"
                style={{ color: 'var(--theme-text)' }}>
                NY FASHION HOUSE
              </h1>
              <p
                className="text-xs transition-colors duration-300"
                style={{ color: 'var(--theme-muted-foreground)' }}>
                Jackson Heights, NY
              </p>
            </div>

            {/* Icons aligned to far right */}
            <div className="flex items-center space-x-1 sm:space-x-2">
              <ThemeToggle />
              <UserUpdateLogsDropdown />
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="relative h-7 w-7 rounded-full transition-colors duration-300">

                    <AvatarWithFallback
                      size="sm"
                      alt="Admin User"
                      fallback="AD" />



                  </Button>
                </DropdownMenuTrigger>
                
                <DropdownMenuContent
                  className="w-56"
                  align="end"
                  forceMount
                  style={{
                    backgroundColor: 'var(--theme-card)',
                    border: '1px solid var(--theme-border)'
                  }}>
                  {/* Existing dropdown menu content */}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </div>

      {/* Horizontal Navigation - Desktop only */}
      <HorizontalNavigation
        className="border-t"
        style={{ borderColor: 'var(--theme-border)' }} />

      {/* Navigation Menu - Slides from left (Mobile/Toggle) */}
      <NavigationMenu
        isOpen={isNavigationOpen}
        onClose={() => setIsNavigationOpen(false)} />

    </header>);
};

export default DashboardHeader;