import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CreditCard, Plus, Check, X, Clock, DollarSign, User, FileText } from 'lucide-react';
import { Employee } from '@/types/employee';
import { Advance, AdvanceDeductionSchedule } from '@/types/salary';
import { employeeService } from '@/services/employeeService';
import { salaryService } from '@/services/salaryService';
import { toast } from 'sonner';

const AdvanceManagement: React.FC = () => {
  const [advances, setAdvances] = useState<Advance[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [reason, setReason] = useState<string>('');
  const [installments, setInstallments] = useState<string>('6');
  const [loading, setLoading] = useState(false);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [advancesData, employeesData] = await Promise.all([
      salaryService.getAllAdvances(),
      employeeService.getAllEmployees()]
      );
      setAdvances(advancesData);
      setEmployees(employeesData.filter((emp) => emp.employmentStatus === 'active'));
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load data');
    }
  };

  const generateDeductionSchedule = (totalAmount: number, installments: number): AdvanceDeductionSchedule[] => {
    const schedule: AdvanceDeductionSchedule[] = [];
    const monthlyAmount = totalAmount / installments;
    const currentDate = new Date();

    for (let i = 0; i < installments; i++) {
      const payPeriodDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + i + 1, 1);
      const payPeriod = `${payPeriodDate.getFullYear()}-${String(payPeriodDate.getMonth() + 1).padStart(2, '0')}`;

      schedule.push({
        payPeriod,
        amount: monthlyAmount,
        isDeducted: false
      });
    }

    return schedule;
  };

  const handleCreateAdvance = async () => {
    if (!selectedEmployee || !amount || !reason) {
      toast.error('Please fill in all required fields');
      return;
    }

    const advanceAmount = parseFloat(amount);
    const installmentCount = parseInt(installments);

    if (advanceAmount <= 0 || installmentCount <= 0) {
      toast.error('Please enter valid amounts');
      return;
    }

    setLoading(true);
    try {
      const deductionSchedule = generateDeductionSchedule(advanceAmount, installmentCount);

      const newAdvance: Omit<Advance, 'id' | 'createdAt' | 'updatedAt'> = {
        employeeId: selectedEmployee,
        amount: advanceAmount,
        reason,
        requestDate: new Date().toISOString(),
        approvalStatus: 'pending',
        deductionSchedule,
        totalDeducted: 0,
        remainingBalance: advanceAmount,
        isFullyPaid: false
      };

      await salaryService.createAdvance(newAdvance);
      toast.success('Advance request created successfully');

      // Reset form
      setSelectedEmployee('');
      setAmount('');
      setReason('');
      setInstallments('6');
      setShowForm(false);

      loadData();
    } catch (error) {
      console.error('Failed to create advance:', error);
      toast.error('Failed to create advance request');
    } finally {
      setLoading(false);
    }
  };

  const handleApproveAdvance = async (advanceId: string) => {
    try {
      await salaryService.approveAdvance(advanceId, 'current-user');
      toast.success('Advance approved successfully');
      loadData();
    } catch (error) {
      console.error('Failed to approve advance:', error);
      toast.error('Failed to approve advance');
    }
  };

  const formatCurrency = (amount: number) => {
    return `৳${amount.toLocaleString('en-BD', { minimumFractionDigits: 2 })}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-BD');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="text-yellow-600 border-yellow-300"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="outline" className="text-green-600 border-green-300"><Check className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="text-red-600 border-red-300"><X className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find((emp) => emp.id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown Employee';
  };

  const totalAdvances = advances.reduce((sum, advance) => sum + advance.amount, 0);
  const totalPending = advances.filter((a) => a.approvalStatus === 'pending').length;
  const totalApproved = advances.filter((a) => a.approvalStatus === 'approved').length;
  const outstandingAmount = advances.
  filter((a) => a.approvalStatus === 'approved' && !a.isFullyPaid).
  reduce((sum, a) => sum + a.remainingBalance, 0);

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Advances</p>
                <p className="text-2xl font-bold">{formatCurrency(totalAdvances)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-yellow-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-2xl font-bold">{totalPending}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Check className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Approved</p>
                <p className="text-2xl font-bold">{totalApproved}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <CreditCard className="h-8 w-8 text-orange-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Outstanding</p>
                <p className="text-2xl font-bold">{formatCurrency(outstandingAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Header */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Advance Management
          </CardTitle>
          <Dialog open={showForm} onOpenChange={setShowForm}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Advance Request
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Advance Request</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Employee *</Label>
                  <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select employee" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.map((employee) =>
                      <SelectItem key={employee.id} value={employee.id}>
                          {employee.firstName} {employee.lastName} - {employee.position}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Amount (৳) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Enter advance amount" />

                </div>

                <div className="space-y-2">
                  <Label>Reason *</Label>
                  <Textarea
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="Enter reason for advance"
                    rows={3} />

                </div>

                <div className="space-y-2">
                  <Label>Number of Installments</Label>
                  <Select value={installments} onValueChange={setInstallments}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 months</SelectItem>
                      <SelectItem value="6">6 months</SelectItem>
                      <SelectItem value="12">12 months</SelectItem>
                      <SelectItem value="18">18 months</SelectItem>
                      <SelectItem value="24">24 months</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {amount && installments &&
                <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">Monthly Deduction:</p>
                    <p className="font-semibold">
                      {formatCurrency(parseFloat(amount || '0') / parseInt(installments))}
                    </p>
                  </div>
                }

                <div className="flex justify-end space-x-4">
                  <Button variant="outline" onClick={() => setShowForm(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateAdvance} disabled={loading}>
                    {loading ? 'Creating...' : 'Create Request'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
      </Card>

      {/* Advances List */}
      <Card>
        <CardHeader>
          <CardTitle>Advance Requests</CardTitle>
        </CardHeader>
        <CardContent>
          {advances.length === 0 ?
          <div className="text-center py-8 text-gray-500">
              <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No advance requests found</p>
              <Button className="mt-4" onClick={() => setShowForm(true)}>
                Create First Advance Request
              </Button>
            </div> :

          <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Request Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Remaining</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {advances.map((advance) =>
              <TableRow key={advance.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-gray-400" />
                        {getEmployeeName(advance.employeeId)}
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {formatCurrency(advance.amount)}
                    </TableCell>
                    <TableCell className="max-w-xs truncate">
                      {advance.reason}
                    </TableCell>
                    <TableCell>{formatDate(advance.requestDate)}</TableCell>
                    <TableCell>{getStatusBadge(advance.approvalStatus)}</TableCell>
                    <TableCell>
                      {advance.approvalStatus === 'approved' ?
                  <div className="text-sm">
                          <p className="font-medium">{formatCurrency(advance.remainingBalance)}</p>
                          <p className="text-gray-500">
                            {advance.totalDeducted > 0 &&
                      `Paid: ${formatCurrency(advance.totalDeducted)}`
                      }
                          </p>
                        </div> :

                  '-'
                  }
                    </TableCell>
                    <TableCell>
                      {advance.approvalStatus === 'pending' &&
                  <div className="flex space-x-2">
                          <Button
                      size="sm"
                      onClick={() => handleApproveAdvance(advance.id)}>

                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                      size="sm"
                      variant="outline">

                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                  }
                    </TableCell>
                  </TableRow>
              )}
              </TableBody>
            </Table>
          }
        </CardContent>
      </Card>
    </div>);

};

export default AdvanceManagement;