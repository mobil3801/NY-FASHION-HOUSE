
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow } from
'@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger } from
'@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle } from
'@/components/ui/alert-dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MoreHorizontal, Edit, Trash2, UserCheck, UserX, Mail, Shield } from 'lucide-react';
import { User } from '@/types/user';
import { format } from 'date-fns';

interface UserListProps {
  users: User[];
  loading?: boolean;
  onEditUser: (user: User) => void;
  onDeleteUser: (userId: number) => void;
  onToggleActivation: (userId: number, isActivated: boolean) => void;
  onSendPasswordReset: (email: string) => void;
  deleteConfirm: {
    open: boolean;
    userId: number | null;
  };
  setDeleteConfirm: (state: {open: boolean;userId: number | null;}) => void;
}

const UserList: React.FC<UserListProps> = ({
  users,
  loading = false,
  onEditUser,
  onDeleteUser,
  onToggleActivation,
  onSendPasswordReset,
  deleteConfirm,
  setDeleteConfirm
}) => {
  const handleDeleteClick = (userId: number) => {
    setDeleteConfirm({ open: true, userId });
  };

  const handleDeleteConfirm = () => {
    if (deleteConfirm.userId) {
      onDeleteUser(deleteConfirm.userId);
      setDeleteConfirm({ open: false, userId: null });
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MM/dd/yyyy hh:mm a');
    } catch {
      return dateString;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-4"></div>
            <div className="space-y-3">
              {[...Array(5)].map((_, i) =>
              <div key={i} className="h-12 bg-gray-200 rounded"></div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>User Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.length === 0 ?
                <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                      No users found
                    </TableCell>
                  </TableRow> :

                users.map((user) =>
                <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.phone_number || 'N/A'}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <Shield className="h-3 w-3" />
                          {user.role_name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                      variant={user.is_activated ? 'default' : 'destructive'}
                      className="flex items-center gap-1 w-fit">

                          {user.is_activated ?
                      <UserCheck className="h-3 w-3" /> :

                      <UserX className="h-3 w-3" />
                      }
                          {user.is_activated ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatDate(user.create_time)}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                          onClick={() => onEditUser(user)}
                          className="flex items-center gap-2">

                              <Edit className="h-4 w-4" />
                              Edit User
                            </DropdownMenuItem>
                            <DropdownMenuItem
                          onClick={() => onToggleActivation(user.id, !user.is_activated)}
                          className="flex items-center gap-2">

                              {user.is_activated ?
                          <UserX className="h-4 w-4" /> :

                          <UserCheck className="h-4 w-4" />
                          }
                              {user.is_activated ? 'Deactivate' : 'Activate'}
                            </DropdownMenuItem>
                            <DropdownMenuItem
                          onClick={() => onSendPasswordReset(user.email)}
                          className="flex items-center gap-2">

                              <Mail className="h-4 w-4" />
                              Send Password Reset
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                          onClick={() => handleDeleteClick(user.id)}
                          className="flex items-center gap-2 text-red-600">

                              <Trash2 className="h-4 w-4" />
                              Delete User
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                )
                }
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <AlertDialog
        open={deleteConfirm.open}
        onOpenChange={(open) => setDeleteConfirm({ open, userId: null })}>

        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the user
              account and remove all associated data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700">

              Delete User
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>);

};

export default UserList;