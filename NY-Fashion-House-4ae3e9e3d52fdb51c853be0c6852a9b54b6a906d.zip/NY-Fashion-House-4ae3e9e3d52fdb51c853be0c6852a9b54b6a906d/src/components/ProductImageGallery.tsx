
import React, { useState, useEffect } from 'react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious } from
"@/components/ui/carousel";
import { Card, CardContent } from '@/components/ui/card';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Package, Image as ImageIcon } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface ProductImageGalleryProps {
  imageIds: number[];
  productName: string;
}

const ProductImageGallery: React.FC<ProductImageGalleryProps> = ({
  imageIds,
  productName
}) => {
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    const fetchImageUrls = async () => {
      if (!imageIds || imageIds.length === 0) {
        setImageUrls([]);
        return;
      }

      setLoading(true);
      try {
        const urls: string[] = [];

        for (const imageId of imageIds) {
          try {
            const { data: fileUrl, error } = await window.ezsite.apis.getUploadUrl(imageId);
            if (error) {
              console.error('Error fetching image URL:', error);
              continue;
            }
            if (fileUrl) {
              urls.push(fileUrl);
            }
          } catch (err) {
            console.error('Error fetching image URL for ID', imageId, err);
          }
        }

        setImageUrls(urls);
      } catch (error) {
        console.error('Error fetching image URLs:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchImageUrls();
  }, [imageIds]);

  // Show placeholder when no images
  if (!imageIds || imageIds.length === 0) {
    return (
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="text-center py-12 text-gray-500">
            <Package className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">No Images Available</h3>
            <p className="text-sm">Upload images to showcase this product</p>
          </div>
        </CardContent>
      </Card>);

  }

  // Show loading state
  if (loading) {
    return (
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="space-y-4">
            <Skeleton className="w-full h-96 rounded-lg" />
            <div className="flex gap-2">
              {Array.from({ length: Math.min(imageIds.length, 4) }).map((_, i) =>
              <Skeleton key={i} className="w-20 h-20 rounded-lg flex-shrink-0" />
              )}
            </div>
          </div>
        </CardContent>
      </Card>);

  }

  // Show error state if no URLs were fetched
  if (imageUrls.length === 0) {
    return (
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="text-center py-12 text-gray-500">
            <ImageIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium mb-2">Images Unavailable</h3>
            <p className="text-sm">Unable to load product images</p>
          </div>
        </CardContent>
      </Card>);

  }

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.target as HTMLImageElement;
    img.src = 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=400&h=400&fit=crop';
  };

  return (
    <Card className="mb-6">
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Main Image Carousel */}
          <div className="relative">
            <AspectRatio ratio={16 / 10} className="bg-gray-100 rounded-lg overflow-hidden">
              {imageUrls.length === 1 ?
              <img
                src={imageUrls[0]}
                alt={`${productName} - Image 1`}
                className="w-full h-full object-cover"
                onError={handleImageError} /> :


              <Carousel className="w-full h-full">
                  <CarouselContent>
                    {imageUrls.map((url, index) =>
                  <CarouselItem key={index}>
                        <img
                      src={url}
                      alt={`${productName} - Image ${index + 1}`}
                      className="w-full h-full object-cover"
                      onError={handleImageError} />

                      </CarouselItem>
                  )}
                  </CarouselContent>
                  <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2" />
                  <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2" />
                </Carousel>
              }
            </AspectRatio>
          </div>

          {/* Thumbnail Navigation */}
          {imageUrls.length > 1 &&
          <div className="flex gap-2 overflow-x-auto pb-2">
              {imageUrls.map((url, index) =>
            <button
              key={index}
              onClick={() => setSelectedIndex(index)}
              className={`flex-shrink-0 relative w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
              selectedIndex === index ?
              'border-primary shadow-md' :
              'border-gray-200 hover:border-gray-300'}`
              }>

                  <img
                src={url}
                alt={`${productName} thumbnail ${index + 1}`}
                className="w-full h-full object-cover"
                onError={handleImageError} />

                </button>
            )}
            </div>
          }
        </div>
      </CardContent>
    </Card>);

};

export default ProductImageGallery;