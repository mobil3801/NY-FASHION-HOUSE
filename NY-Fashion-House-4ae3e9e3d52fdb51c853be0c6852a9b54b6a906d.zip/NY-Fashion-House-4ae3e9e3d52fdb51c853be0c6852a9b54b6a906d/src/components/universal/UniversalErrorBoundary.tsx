// Universal Error Boundary - Production-ready comprehensive error boundary system
import React, { Component, ReactNode, ErrorInfo } from 'react';
import { centralizedErrorManager } from '@/services/centralizedErrorManager';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, RefreshCcw, Bug, Home, FileText } from 'lucide-react';
import { toast } from 'sonner';

interface UniversalErrorBoundaryProps {
  children: ReactNode;
  level: 'root' | 'route' | 'component' | 'widget';
  componentName: string;
  fallbackComponent?: React.ComponentType<ErrorBoundaryFallbackProps>;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  enableRetry?: boolean;
  enableReporting?: boolean;
  showErrorDetails?: boolean;
  autoRetryAttempts?: number;
  autoRetryDelay?: number;
}

interface UniversalErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorId: string | null;
  retryCount: number;
  isRetrying: boolean;
  lastErrorTime: number;
}

interface ErrorBoundaryFallbackProps {
  error: Error;
  errorInfo: ErrorInfo;
  retry: () => void;
  goHome: () => void;
  reportError: () => void;
  errorId: string;
  level: string;
  componentName: string;
}

class UniversalErrorBoundary extends Component<UniversalErrorBoundaryProps, UniversalErrorBoundaryState> {
  private retryTimeoutId: NodeJS.Timeout | null = null;

  constructor(props: UniversalErrorBoundaryProps) {
    super(props);

    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: null,
      retryCount: 0,
      isRetrying: false,
      lastErrorTime: 0
    };
  }

  static getDerivedStateFromError(error: Error): Partial<UniversalErrorBoundaryState> {
    return {
      hasError: true,
      error,
      lastErrorTime: Date.now()
    };
  }

  async componentDidCatch(error: Error, errorInfo: ErrorInfo): Promise<void> {
    try {
      // Log to centralized error manager
      const errorId = await centralizedErrorManager.logError(error, {
        category: 'client',
        severity: this.getSeverityByLevel(this.props.level),
        component: this.props.componentName,
        action: 'React Error Boundary Triggered',
        componentStack: errorInfo.componentStack,
        additionalData: {
          errorBoundaryLevel: this.props.level,
          reactErrorInfo: errorInfo,
          retryCount: this.state.retryCount
        }
      });

      this.setState({
        errorInfo,
        errorId: typeof errorId === 'string' ? errorId : `error-${Date.now()}`
      });

      // Call custom error handler if provided
      if (this.props.onError) {
        this.props.onError(error, errorInfo);
      }

      // Show appropriate user notification
      this.showUserNotification(error);

      // Auto-retry for non-critical components
      if (this.shouldAutoRetry()) {
        this.scheduleAutoRetry();
      }

    } catch (loggingError) {
      console.error('[ERROR BOUNDARY] Failed to log error:', loggingError);

      // Fallback error handling
      this.setState({
        errorInfo,
        errorId: `fallback-${Date.now()}`
      });
    }
  }

  private getSeverityByLevel(level: string): 'low' | 'medium' | 'high' | 'critical' {
    switch (level) {
      case 'root':return 'critical';
      case 'route':return 'high';
      case 'component':return 'medium';
      case 'widget':return 'low';
      default:return 'medium';
    }
  }

  private showUserNotification(error: Error): void {
    const { level } = this.props;

    if (level === 'root' || level === 'route') {
      toast.error('Application Error', {
        description: 'A critical error has occurred. The page will attempt to recover automatically.',
        duration: 8000
      });
    } else if (level === 'component') {
      toast.warning('Component Error', {
        description: 'A component has encountered an issue. Attempting to recover...',
        duration: 5000
      });
    }
    // Don't show notifications for widget-level errors to avoid spam
  }

  private shouldAutoRetry(): boolean {
    const { enableRetry = true, autoRetryAttempts = 3, level } = this.props;
    const { retryCount } = this.state;

    return enableRetry &&
    retryCount < autoRetryAttempts && (
    level === 'component' || level === 'widget');
  }

  private scheduleAutoRetry(): void {
    const { autoRetryDelay = 2000 } = this.props;
    const delay = autoRetryDelay * Math.pow(2, this.state.retryCount); // Exponential backoff

    this.setState({ isRetrying: true });

    this.retryTimeoutId = setTimeout(() => {
      this.handleRetry();
    }, delay);
  }

  private handleRetry = (): void => {
    if (this.retryTimeoutId) {
      clearTimeout(this.retryTimeoutId);
      this.retryTimeoutId = null;
    }

    this.setState((prevState) => ({
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: null,
      retryCount: prevState.retryCount + 1,
      isRetrying: false
    }));

    toast.success('Retrying...', {
      description: 'Attempting to recover the component.',
      duration: 3000
    });
  };

  private handleGoHome = (): void => {
    window.location.href = '/';
  };

  private handleReportError = async (): Promise<void> => {
    const { error, errorId } = this.state;

    if (!error || !errorId) return;

    try {
      // Export diagnostic data
      const diagnosticData = centralizedErrorManager.exportDiagnosticData();

      // Create a downloadable report
      const blob = new Blob([diagnosticData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `error-report-${errorId}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success('Error Report Generated', {
        description: 'Diagnostic report has been downloaded. Please send it to support.',
        duration: 5000
      });
    } catch (reportError) {
      console.error('[ERROR BOUNDARY] Failed to generate report:', reportError);
      toast.error('Failed to generate error report');
    }
  };

  componentWillUnmount(): void {
    if (this.retryTimeoutId) {
      clearTimeout(this.retryTimeoutId);
    }
  }

  render(): ReactNode {
    const { hasError, error, errorInfo, errorId, isRetrying } = this.state;
    const {
      children,
      level,
      componentName,
      fallbackComponent: CustomFallback,
      showErrorDetails = process.env.NODE_ENV === 'development',
      enableReporting = true
    } = this.props;

    if (!hasError) {
      return children;
    }

    // Use custom fallback if provided
    if (CustomFallback && error && errorInfo && errorId) {
      return (
        <CustomFallback
          error={error}
          errorInfo={errorInfo}
          retry={this.handleRetry}
          goHome={this.handleGoHome}
          reportError={this.handleReportError}
          errorId={errorId}
          level={level}
          componentName={componentName} />);


    }

    // Default fallback UI based on error level
    return this.renderDefaultFallback();
  }

  private renderDefaultFallback(): ReactNode {
    const { hasError, error, errorInfo, errorId, isRetrying, retryCount } = this.state;
    const { level, componentName, enableRetry = true, enableReporting = true } = this.props;

    if (isRetrying) {
      return this.renderRetryingState();
    }

    // Root level - Full page error
    if (level === 'root') {
      return this.renderRootLevelError();
    }

    // Route level - Page section error
    if (level === 'route') {
      return this.renderRouteLevelError();
    }

    // Component level - Component error
    if (level === 'component') {
      return this.renderComponentLevelError();
    }

    // Widget level - Minimal error display
    if (level === 'widget') {
      return this.renderWidgetLevelError();
    }

    return this.renderComponentLevelError(); // Default fallback
  }

  private renderRetryingState(): ReactNode {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="flex items-center space-x-3">
          <RefreshCcw className="h-6 w-6 animate-spin text-blue-500" />
          <div>
            <p className="text-sm font-medium">Recovering...</p>
            <p className="text-xs text-muted-foreground">Please wait while we restore the component</p>
          </div>
        </div>
      </div>);

  }

  private renderRootLevelError(): ReactNode {
    const { error, errorId } = this.state;
    const { enableReporting } = this.props;

    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6 text-red-600 dark:text-red-400" />
            </div>
            <CardTitle className="text-xl">Application Error</CardTitle>
            <CardDescription>
              A critical error has occurred. We apologize for the inconvenience.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <Bug className="h-4 w-4" />
              <AlertTitle>Error ID: {errorId}</AlertTitle>
              <AlertDescription>
                Please include this ID when reporting the issue.
              </AlertDescription>
            </Alert>
            
            <div className="flex flex-col space-y-2">
              <Button onClick={this.handleGoHome} variant="default" className="w-full">
                <Home className="w-4 h-4 mr-2" />
                Go to Home
              </Button>
              <Button onClick={() => window.location.reload()} variant="outline" className="w-full">
                <RefreshCcw className="w-4 h-4 mr-2" />
                Reload Page
              </Button>
              {enableReporting &&
              <Button onClick={this.handleReportError} variant="ghost" className="w-full">
                  <FileText className="w-4 h-4 mr-2" />
                  Download Error Report
                </Button>
              }
            </div>
          </CardContent>
        </Card>
      </div>);

  }

  private renderRouteLevelError(): ReactNode {
    const { error, errorId, retryCount } = this.state;
    const { componentName, enableRetry, enableReporting } = this.props;

    return (
      <div className="p-8">
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 text-orange-600 dark:text-orange-400" />
              </div>
              <div>
                <CardTitle className="text-lg">Page Section Error</CardTitle>
                <CardDescription>
                  {componentName} encountered an error
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Badge variant="secondary" className="text-xs">
                Error ID: {errorId}
              </Badge>
              {retryCount > 0 &&
              <Badge variant="outline" className="text-xs">
                  Retry #{retryCount}
                </Badge>
              }
            </div>
            
            <Separator />
            
            <div className="flex flex-wrap gap-2">
              {enableRetry &&
              <Button onClick={this.handleRetry} size="sm">
                  <RefreshCcw className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
              }
              <Button onClick={this.handleGoHome} variant="outline" size="sm">
                <Home className="w-4 h-4 mr-2" />
                Home
              </Button>
              {enableReporting &&
              <Button onClick={this.handleReportError} variant="ghost" size="sm">
                  <FileText className="w-4 h-4 mr-2" />
                  Report
                </Button>
              }
            </div>
          </CardContent>
        </Card>
      </div>);

  }

  private renderComponentLevelError(): ReactNode {
    const { errorId, retryCount } = this.state;
    const { componentName, enableRetry } = this.props;

    return (
      <div className="p-4 border border-orange-200 dark:border-orange-800 rounded-lg bg-orange-50 dark:bg-orange-950">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-5 h-5 text-orange-600 dark:text-orange-400 mt-0.5 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-medium text-orange-800 dark:text-orange-200">
              {componentName} Error
            </h4>
            <p className="text-sm text-orange-700 dark:text-orange-300 mt-1">
              This component encountered an issue and couldn't load properly.
            </p>
            <div className="flex items-center justify-between mt-3">
              <p className="text-xs text-orange-600 dark:text-orange-400">
                ID: {errorId} {retryCount > 0 && `(Retry #${retryCount})`}
              </p>
              {enableRetry &&
              <Button onClick={this.handleRetry} size="sm" variant="outline">
                  <RefreshCcw className="w-3 h-3 mr-1" />
                  Retry
                </Button>
              }
            </div>
          </div>
        </div>
      </div>);

  }

  private renderWidgetLevelError(): ReactNode {
    const { enableRetry } = this.props;

    return (
      <div className="flex items-center justify-center p-4 text-muted-foreground">
        <div className="flex items-center space-x-2 text-sm">
          <AlertTriangle className="w-4 h-4" />
          <span>Widget unavailable</span>
          {enableRetry &&
          <button
            onClick={this.handleRetry}
            className="ml-2 text-xs underline hover:no-underline">

              retry
            </button>
          }
        </div>
      </div>);

  }
}

export default UniversalErrorBoundary;

// Higher-order component for easy wrapping
export function withUniversalErrorBoundary<P extends object>(
Component: React.ComponentType<P>,
options: {
  level?: UniversalErrorBoundaryProps['level'];
  componentName?: string;
  enableRetry?: boolean;
  enableReporting?: boolean;
} = {})
{
  const WrappedComponent = (props: P) =>
  <UniversalErrorBoundary
    level={options.level || 'component'}
    componentName={options.componentName || Component.displayName || Component.name || 'Component'}
    enableRetry={options.enableRetry}
    enableReporting={options.enableReporting}>

      <Component {...props} />
    </UniversalErrorBoundary>;


  WrappedComponent.displayName = `withUniversalErrorBoundary(${Component.displayName || Component.name})`;

  return WrappedComponent;
}

// Custom hook for programmatic error boundary usage
export function useErrorBoundary() {
  const [error, setError] = React.useState<Error | null>(null);

  const captureError = React.useCallback((error: Error) => {
    setError(error);
  }, []);

  if (error) {
    throw error;
  }

  return { captureError };
}