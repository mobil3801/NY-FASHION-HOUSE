import React from 'react';
import { Employee, EmployeeRole } from '@/types/employee';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Edit,
  Mail,
  Phone,
  MapPin,
  Calendar,
  DollarSign,
  Briefcase,
  User,
  Users,
  FileText } from
'lucide-react';

interface EmployeeProfileProps {
  employee: Employee;
  role: EmployeeRole | null;
  onEdit: (employee: Employee) => void;
}

const EmployeeProfile: React.FC<EmployeeProfileProps> = ({
  employee,
  role,
  onEdit
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':return 'bg-green-100 text-green-800';
      case 'inactive':return 'bg-red-100 text-red-800';
      case 'on_leave':return 'bg-yellow-100 text-yellow-800';
      default:return 'bg-gray-100 text-gray-800';
    }
  };

  const formatSalary = (salary: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(salary);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={employee.photoUrl} alt={`${employee.firstName} ${employee.lastName}`} />
                <AvatarFallback className="bg-blue-100 text-blue-600 text-xl">
                  {employee.firstName[0]}{employee.lastName[0]}
                </AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-2xl">
                  {employee.firstName} {employee.lastName}
                </CardTitle>
                <p className="text-gray-600 text-lg">{employee.position}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className={getStatusColor(employee.employmentStatus)}>
                    {employee.employmentStatus.replace('_', ' ').toUpperCase()}
                  </Badge>
                  {role &&
                  <Badge variant="outline">
                      {role.name}
                    </Badge>
                  }
                </div>
              </div>
            </div>
            <Button onClick={() => onEdit(employee)} className="flex items-center gap-2">
              <Edit className="h-4 w-4" />
              Edit Employee
            </Button>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <Mail className="h-4 w-4 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Email</p>
                <p className="font-medium">{employee.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Phone className="h-4 w-4 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Phone</p>
                <p className="font-medium">{employee.phone}</p>
              </div>
            </div>

            {(employee.address.street || employee.address.city) &&
            <div className="flex items-start gap-3">
                <MapPin className="h-4 w-4 text-gray-400 mt-1" />
                <div>
                  <p className="text-sm text-gray-600">Address</p>
                  <div className="font-medium">
                    {employee.address.street && <p>{employee.address.street}</p>}
                    <p>
                      {employee.address.city && employee.address.city}
                      {employee.address.state && `, ${employee.address.state}`}
                      {employee.address.zipCode && ` ${employee.address.zipCode}`}
                    </p>
                    {employee.address.country && <p>{employee.address.country}</p>}
                  </div>
                </div>
              </div>
            }
          </CardContent>
        </Card>

        {/* Employment Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Employment Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <Users className="h-4 w-4 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Department</p>
                <p className="font-medium">{employee.department}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Calendar className="h-4 w-4 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Hire Date</p>
                <p className="font-medium">{formatDate(employee.hireDate)}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <DollarSign className="h-4 w-4 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Salary</p>
                <p className="font-medium">{formatSalary(employee.salary)}</p>
              </div>
            </div>

            {role &&
            <div>
                <Separator className="my-4" />
                <div>
                  <p className="text-sm text-gray-600 mb-2">Role Permissions</p>
                  <div className="flex flex-wrap gap-1">
                    {role.permissions.slice(0, 3).map((permission) =>
                  <Badge key={permission.id} variant="secondary" className="text-xs">
                        {permission.name}
                      </Badge>
                  )}
                    {role.permissions.length > 3 &&
                  <Badge variant="secondary" className="text-xs">
                        +{role.permissions.length - 3} more
                      </Badge>
                  }
                  </div>
                </div>
              </div>
            }
          </CardContent>
        </Card>

        {/* Emergency Contact */}
        {(employee.emergencyContact.name || employee.emergencyContact.phone) &&
        <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Emergency Contact
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {employee.emergencyContact.name &&
            <div>
                  <p className="text-sm text-gray-600">Name</p>
                  <p className="font-medium">{employee.emergencyContact.name}</p>
                </div>
            }

              {employee.emergencyContact.relationship &&
            <div>
                  <p className="text-sm text-gray-600">Relationship</p>
                  <p className="font-medium">{employee.emergencyContact.relationship}</p>
                </div>
            }

              {employee.emergencyContact.phone &&
            <div>
                  <p className="text-sm text-gray-600">Phone</p>
                  <p className="font-medium">{employee.emergencyContact.phone}</p>
                </div>
            }

              {employee.emergencyContact.email &&
            <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-medium">{employee.emergencyContact.email}</p>
                </div>
            }
            </CardContent>
          </Card>
        }

        {/* Additional Information */}
        {employee.notes &&
        <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Additional Notes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 whitespace-pre-wrap">{employee.notes}</p>
            </CardContent>
          </Card>
        }
      </div>
    </div>);

};

export default EmployeeProfile;