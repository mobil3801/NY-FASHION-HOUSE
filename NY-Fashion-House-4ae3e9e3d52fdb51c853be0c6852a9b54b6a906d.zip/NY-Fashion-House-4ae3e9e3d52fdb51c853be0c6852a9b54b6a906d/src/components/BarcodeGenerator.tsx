import React, { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, BarChart3 } from 'lucide-react';

interface BarcodeGeneratorProps {
  value: string;
  width?: number;
  height?: number;
  format?: 'CODE128' | 'CODE39' | 'EAN13' | 'EAN8' | 'UPC';
  displayValue?: boolean;
  className?: string;
}

const BarcodeGenerator: React.FC<BarcodeGeneratorProps> = ({
  value,
  width = 2,
  height = 100,
  format = 'CODE128',
  displayValue = true,
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [barcodeError, setBarcodeError] = React.useState<string>('');

  useEffect(() => {
    if (!value || !canvasRef.current) return;

    try {
      setBarcodeError('');
      generateBarcode();
    } catch (error) {
      setBarcodeError('Failed to generate barcode');
      console.error('Barcode generation error:', error);
    }
  }, [value, width, height, format, displayValue]);

  const generateBarcode = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Simple barcode generation (CODE128-like pattern)
    // In a real implementation, you would use a proper barcode library
    const barcodeWidth = value.length * 12 * width;
    const barcodeHeight = height;

    canvas.width = barcodeWidth + 40; // Padding
    canvas.height = barcodeHeight + (displayValue ? 30 : 20); // Space for text

    // Clear canvas
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Generate simple barcode pattern
    ctx.fillStyle = '#000000';
    let x = 20; // Start with padding

    // Start pattern
    drawBar(ctx, x, 10, 2 * width, barcodeHeight);
    x += 3 * width;

    // Data bars (simplified)
    for (let i = 0; i < value.length; i++) {
      const charCode = value.charCodeAt(i) % 95 + 32;
      const pattern = getSimplePattern(charCode);

      for (let j = 0; j < pattern.length; j++) {
        if (pattern[j] === '1') {
          drawBar(ctx, x, 10, width, barcodeHeight);
        }
        x += width;
      }
    }

    // End pattern
    drawBar(ctx, x, 10, 2 * width, barcodeHeight);
    x += 2 * width;
    drawBar(ctx, x, 10, width, barcodeHeight);

    // Display value
    if (displayValue) {
      ctx.font = '12px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(value, canvas.width / 2, canvas.height - 5);
    }
  };

  const drawBar = (ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) => {
    ctx.fillRect(x, y, w, h);
  };

  const getSimplePattern = (charCode: number): string => {
    // Simplified pattern generation
    // In reality, CODE128 has specific encoding tables
    const patterns = [
    '11010010000', '11010011000', '11010011100', '10010011000',
    '10010001100', '10001001100', '10011001000', '10011000100',
    '10001100100', '11001001000', '11001000100', '11000100100'];

    return patterns[charCode % patterns.length];
  };

  const downloadBarcode = () => {
    if (!canvasRef.current) return;

    const link = document.createElement('a');
    link.download = `barcode-${value}.png`;
    link.href = canvasRef.current.toDataURL();
    link.click();
  };

  if (!value) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Barcode
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500 py-8">
            Enter a value to generate barcode
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Barcode: {format}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {barcodeError ?
        <div className="text-center text-red-500 py-4">
            {barcodeError}
          </div> :

        <>
            <div className="flex justify-center">
              <canvas
              ref={canvasRef}
              style={{ border: '1px solid #e5e7eb', borderRadius: '4px' }} />

            </div>
            <div className="flex justify-center">
              <Button
              onClick={downloadBarcode}
              variant="outline"
              size="sm"
              className="gap-2">

                <Download className="h-4 w-4" />
                Download PNG
              </Button>
            </div>
          </>
        }
      </CardContent>
    </Card>);

};

export default BarcodeGenerator;