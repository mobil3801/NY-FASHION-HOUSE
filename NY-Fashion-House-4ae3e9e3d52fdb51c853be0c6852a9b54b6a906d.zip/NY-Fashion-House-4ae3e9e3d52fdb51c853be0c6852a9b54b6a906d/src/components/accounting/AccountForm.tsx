
import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Account, AccountType } from '@/types/accounting';
import { accountingService } from '@/services/accountingService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

interface AccountFormData {
  code: string;
  name: string;
  type: AccountType;
  parentId?: string;
  description?: string;
  isActive: boolean;
  balance: number;
}

interface AccountFormProps {
  account?: Account | null;
  onSave?: (account: Account) => void;
  onCancel?: () => void;
}

const AccountForm = ({ account, onSave, onCancel }: AccountFormProps) => {
  const [loading, setLoading] = useState(false);
  const [parentAccounts, setParentAccounts] = useState<Account[]>([]);

  const { register, handleSubmit, formState: { errors }, watch, setValue, reset } = useForm<AccountFormData>({
    defaultValues: {
      code: account?.code || '',
      name: account?.name || '',
      type: account?.type || AccountType.ASSET,
      parentId: account?.parentId || '',
      description: account?.description || '',
      isActive: account?.isActive ?? true,
      balance: account?.balance || 0
    }
  });

  const selectedType = watch('type');

  useEffect(() => {
    loadParentAccounts();
  }, [selectedType]);

  useEffect(() => {
    if (account) {
      reset({
        code: account.code,
        name: account.name,
        type: account.type,
        parentId: account.parentId || '',
        description: account.description || '',
        isActive: account.isActive,
        balance: account.balance
      });
    }
  }, [account, reset]);

  const loadParentAccounts = async () => {
    try {
      const accounts = await accountingService.getAccountsByType(selectedType);
      setParentAccounts(accounts.filter((acc) => acc.id !== account?.id));
    } catch (error) {
      console.error('Failed to load parent accounts:', error);
    }
  };

  const onSubmit = async (data: AccountFormData) => {
    try {
      setLoading(true);

      let savedAccount: Account;
      if (account) {
        savedAccount = await accountingService.updateAccount(account.id, data);
        toast.success('Account updated successfully');
      } else {
        savedAccount = await accountingService.createAccount(data);
        toast.success('Account created successfully');
      }

      onSave?.(savedAccount);
    } catch (error) {
      toast.error('Failed to save account');
    } finally {
      setLoading(false);
    }
  };

  const getAccountTypeLabel = (type: AccountType) => {
    return type.charAt(0).toUpperCase() + type.slice(1);
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>
          {account ? 'Edit Account' : 'Create New Account'}
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="code">Account Code *</Label>
              <Input
                id="code"
                {...register('code', { required: 'Account code is required' })}
                placeholder="e.g., 1000" />

              {errors.code &&
              <p className="text-sm text-red-600 mt-1">{errors.code.message}</p>
              }
            </div>

            <div>
              <Label htmlFor="name">Account Name *</Label>
              <Input
                id="name"
                {...register('name', { required: 'Account name is required' })}
                placeholder="e.g., Cash" />

              {errors.name &&
              <p className="text-sm text-red-600 mt-1">{errors.name.message}</p>
              }
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="type">Account Type *</Label>
              <Select
                value={selectedType}
                onValueChange={(value) => setValue('type', value as AccountType)}>

                <SelectTrigger>
                  <SelectValue placeholder="Select account type" />
                </SelectTrigger>
                <SelectContent>
                  {Object.values(AccountType).map((type) =>
                  <SelectItem key={type} value={type}>
                      {getAccountTypeLabel(type)}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="parentId">Parent Account (Optional)</Label>
              <Select
                value={watch('parentId') || ''}
                onValueChange={(value) => setValue('parentId', value || undefined)}>

                <SelectTrigger>
                  <SelectValue placeholder="Select parent account" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {parentAccounts.map((parentAccount) =>
                  <SelectItem key={parentAccount.id} value={parentAccount.id}>
                      {parentAccount.code} - {parentAccount.name}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              {...register('description')}
              placeholder="Optional description for this account"
              rows={3} />

          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="balance">Initial Balance</Label>
              <Input
                id="balance"
                type="number"
                step="0.01"
                {...register('balance', { valueAsNumber: true })}
                placeholder="0.00" />

            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="isActive"
                checked={watch('isActive')}
                onCheckedChange={(checked) => setValue('isActive', checked)} />

              <Label htmlFor="isActive">Active Account</Label>
            </div>
          </div>

          <div className="flex justify-end space-x-4">
            {onCancel &&
            <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
            }
            <Button type="submit" disabled={loading}>
              {loading ? 'Saving...' : account ? 'Update Account' : 'Create Account'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>);

};

export default AccountForm;