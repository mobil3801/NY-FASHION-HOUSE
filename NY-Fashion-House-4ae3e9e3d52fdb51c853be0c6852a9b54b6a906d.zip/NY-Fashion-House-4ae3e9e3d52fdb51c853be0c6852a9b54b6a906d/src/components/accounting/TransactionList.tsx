import React from 'react';
import usaStandardsFormatter from '@/utils/usaStandardsFormatter';
import { Table, TableHeader, TableBody, TableRow, TableCell, TableHead } from '@/components/ui/table';

interface Transaction {
  id: string;
  date: Date;
  amount: number;
  description: string;
}

const TransactionList: React.FC = () => {
  // Mock data - in real scenario, this would come from a service
  const transactions: Transaction[] = [
  {
    id: '001',
    date: new Date(),
    amount: 5678.90,
    description: 'Office Supplies Purchase'
  },
  {
    id: '002',
    date: new Date(),
    amount: 12345.67,
    description: 'Software Licensing'
  }];


  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Transaction ID</TableHead>
          <TableHead>Date</TableHead>
          <TableHead>Amount</TableHead>
          <TableHead>Description</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {transactions.map((transaction) =>
        <TableRow key={transaction.id}>
            <TableCell>{transaction.id}</TableCell>
            <TableCell>{usaStandardsFormatter.formatDate(transaction.date)}</TableCell>
            <TableCell>{usaStandardsFormatter.formatCurrency(transaction.amount)}</TableCell>
            <TableCell>{transaction.description}</TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>);

};

export default TransactionList;