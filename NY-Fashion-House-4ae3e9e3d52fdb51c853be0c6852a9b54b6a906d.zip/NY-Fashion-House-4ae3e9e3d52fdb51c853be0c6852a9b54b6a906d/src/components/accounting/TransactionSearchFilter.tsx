
import { useState, useEffect } from 'react';
import { Account, TransactionSource, TransactionSearchFilters } from '@/types/accounting';
import { accountingService } from '@/services/accountingService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, X, Calendar, DollarSign, FileText } from 'lucide-react';
import { toast } from 'sonner';

interface TransactionSearchFilterProps {
  onFiltersChange: (filters: TransactionSearchFilters) => void;
  initialFilters?: TransactionSearchFilters;
}

const TransactionSearchFilter = ({ onFiltersChange, initialFilters }: TransactionSearchFilterProps) => {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [filters, setFilters] = useState<TransactionSearchFilters>(initialFilters || {});

  useEffect(() => {
    loadAccounts();
  }, []);

  const loadAccounts = async () => {
    try {
      const accountsData = await accountingService.getAccounts();
      setAccounts(accountsData.filter((acc) => acc.isActive));
    } catch (error) {
      toast.error('Failed to load accounts');
    }
  };

  const updateFilter = (key: keyof TransactionSearchFilters, value: string | number | undefined) => {
    const newFilters = { ...filters };

    if (value === '' || value === undefined) {
      delete newFilters[key];
    } else {
      newFilters[key] = value as any;
    }

    setFilters(newFilters);
  };

  const applyFilters = () => {
    onFiltersChange(filters);
  };

  const clearFilters = () => {
    const emptyFilters = {};
    setFilters(emptyFilters);
    onFiltersChange(emptyFilters);
  };

  const hasActiveFilters = Object.keys(filters).length > 0;

  // Set default date range to current month if no filters are set
  const currentDate = new Date();
  const defaultStartDate = filters.startDate || new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString().split('T')[0];
  const defaultEndDate = filters.endDate || new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString().split('T')[0];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5" />
          Transaction Filters
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Date Range */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="startDate" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Start Date
            </Label>
            <Input
              id="startDate"
              type="date"
              value={filters.startDate || defaultStartDate}
              onChange={(e) => updateFilter('startDate', e.target.value)} />

          </div>
          
          <div>
            <Label htmlFor="endDate" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              End Date
            </Label>
            <Input
              id="endDate"
              type="date"
              value={filters.endDate || defaultEndDate}
              onChange={(e) => updateFilter('endDate', e.target.value)} />

          </div>
        </div>

        {/* Account and Source */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>Account</Label>
            <Select
              value={filters.accountId || ''}
              onValueChange={(value) => updateFilter('accountId', value || undefined)}>

              <SelectTrigger>
                <SelectValue placeholder="All accounts" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All accounts</SelectItem>
                {accounts.map((account) =>
                <SelectItem key={account.id} value={account.id}>
                    {account.code} - {account.name}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label>Source</Label>
            <Select
              value={filters.source || ''}
              onValueChange={(value) => updateFilter('source', value as TransactionSource || undefined)}>

              <SelectTrigger>
                <SelectValue placeholder="All sources" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All sources</SelectItem>
                {Object.values(TransactionSource).map((source) =>
                <SelectItem key={source} value={source}>
                    {source.charAt(0).toUpperCase() + source.slice(1)}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Reference and Description */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="reference" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Reference
            </Label>
            <Input
              id="reference"
              value={filters.reference || ''}
              onChange={(e) => updateFilter('reference', e.target.value)}
              placeholder="Search by reference..." />

          </div>
          
          <div>
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={filters.description || ''}
              onChange={(e) => updateFilter('description', e.target.value)}
              placeholder="Search by description..." />

          </div>
        </div>

        {/* Amount Range */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="minAmount" className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Min Amount
            </Label>
            <Input
              id="minAmount"
              type="number"
              step="0.01"
              value={filters.minAmount || ''}
              onChange={(e) => updateFilter('minAmount', e.target.value ? parseFloat(e.target.value) : undefined)}
              placeholder="0.00" />

          </div>
          
          <div>
            <Label htmlFor="maxAmount" className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Max Amount
            </Label>
            <Input
              id="maxAmount"
              type="number"
              step="0.01"
              value={filters.maxAmount || ''}
              onChange={(e) => updateFilter('maxAmount', e.target.value ? parseFloat(e.target.value) : undefined)}
              placeholder="999999.99" />

          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between items-center pt-4 border-t">
          <div className="flex gap-2">
            <Button onClick={applyFilters} className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              Apply Filters
            </Button>
            
            {hasActiveFilters &&
            <Button onClick={clearFilters} variant="outline" className="flex items-center gap-2">
                <X className="w-4 h-4" />
                Clear Filters
              </Button>
            }
          </div>
          
          <div className="text-sm text-muted-foreground">
            {hasActiveFilters ? `${Object.keys(filters).length} filter(s) active` : 'No filters applied'}
          </div>
        </div>
      </CardContent>
    </Card>);

};

export default TransactionSearchFilter;