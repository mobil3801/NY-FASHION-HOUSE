import React from 'react';
import usaStandardsFormatter from '@/utils/usaStandardsFormatter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface FinancialReport {
  date: Date;
  revenue: number;
  expenses: number;
  profit: number;
  phoneContact: string;
}

const FinancialReports: React.FC = () => {
  // Mock data - in real scenario, this would come from a service
  const report: FinancialReport = {
    date: new Date(),
    revenue: 1234567.89,
    expenses: 987654.32,
    profit: 246913.57,
    phoneContact: '5551234567'
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Financial Report</CardTitle>
      </CardHeader>
      <CardContent>
        <div>
          <p>Date: {usaStandardsFormatter.formatDate(report.date)}</p>
          <p>Time: {usaStandardsFormatter.formatTime(report.date)}</p>
          <p>Timezone: {usaStandardsFormatter.getTimezone()}</p>
          <p>Revenue: {usaStandardsFormatter.formatCurrency(report.revenue)}</p>
          <p>Expenses: {usaStandardsFormatter.formatCurrency(report.expenses)}</p>
          <p>Profit: {usaStandardsFormatter.formatCurrency(report.profit)}</p>
          <p>Contact: {usaStandardsFormatter.formatPhoneNumber(report.phoneContact)}</p>
        </div>
      </CardContent>
    </Card>);

};

export default FinancialReports;