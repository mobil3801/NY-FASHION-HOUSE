
import { useState, useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { Account, JournalEntry, TransactionSource, TransactionEntry } from '@/types/accounting';
import { accountingService } from '@/services/accountingService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Calculator } from 'lucide-react';
import { toast } from 'sonner';

interface JournalEntryFormData {
  date: string;
  reference: string;
  description: string;
  entries: Array<{
    accountId: string;
    debitAmount: number;
    creditAmount: number;
    description: string;
  }>;
}

interface JournalEntryFormProps {
  onSave?: (entry: JournalEntry) => void;
  onCancel?: () => void;
}

const JournalEntryForm = ({ onSave, onCancel }: JournalEntryFormProps) => {
  const [loading, setLoading] = useState(false);
  const [accounts, setAccounts] = useState<Account[]>([]);

  const { register, handleSubmit, formState: { errors }, watch, control, setValue } = useForm<JournalEntryFormData>({
    defaultValues: {
      date: new Date().toISOString().split('T')[0],
      reference: '',
      description: '',
      entries: [
      { accountId: '', debitAmount: 0, creditAmount: 0, description: '' },
      { accountId: '', debitAmount: 0, creditAmount: 0, description: '' }]

    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'entries'
  });

  const watchedEntries = watch('entries');

  useEffect(() => {
    loadAccounts();
    generateReference();
  }, []);

  const loadAccounts = async () => {
    try {
      const accountsData = await accountingService.getAccounts();
      setAccounts(accountsData.filter((acc) => acc.isActive));
    } catch (error) {
      toast.error('Failed to load accounts');
    }
  };

  const generateReference = () => {
    const now = new Date();
    const ref = `JE-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}-${now.getTime().toString().slice(-6)}`;
    setValue('reference', ref);
  };

  const calculateTotals = () => {
    const totalDebits = watchedEntries.reduce((sum, entry) => sum + (entry.debitAmount || 0), 0);
    const totalCredits = watchedEntries.reduce((sum, entry) => sum + (entry.creditAmount || 0), 0);
    const difference = totalDebits - totalCredits;

    return { totalDebits, totalCredits, difference, isBalanced: Math.abs(difference) < 0.01 };
  };

  const { totalDebits, totalCredits, difference, isBalanced } = calculateTotals();

  const onSubmit = async (data: JournalEntryFormData) => {
    if (!isBalanced) {
      toast.error('Journal entry must be balanced (debits must equal credits)');
      return;
    }

    try {
      setLoading(true);

      const entries: Omit<TransactionEntry, 'id' | 'journalEntryId' | 'account'>[] = data.entries.
      filter((entry) => entry.accountId && (entry.debitAmount > 0 || entry.creditAmount > 0)).
      map((entry) => ({
        accountId: entry.accountId,
        debitAmount: entry.debitAmount || 0,
        creditAmount: entry.creditAmount || 0,
        description: entry.description || data.description
      }));

      const journalEntry = await accountingService.createJournalEntry({
        date: data.date,
        reference: data.reference,
        description: data.description,
        totalAmount: Math.max(totalDebits, totalCredits),
        entries,
        source: TransactionSource.MANUAL,
        createdBy: 'current-user' // TODO: Replace with actual user
      });

      toast.success('Journal entry created successfully');
      onSave?.(journalEntry);
    } catch (error) {
      toast.error('Failed to create journal entry');
    } finally {
      setLoading(false);
    }
  };

  const addEntry = () => {
    append({ accountId: '', debitAmount: 0, creditAmount: 0, description: '' });
  };

  const getAccountLabel = (accountId: string) => {
    const account = accounts.find((acc) => acc.id === accountId);
    return account ? `${account.code} - ${account.name}` : '';
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Create Journal Entry</CardTitle>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Header Information */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                {...register('date', { required: 'Date is required' })} />

              {errors.date &&
              <p className="text-sm text-red-600 mt-1">{errors.date.message}</p>
              }
            </div>

            <div>
              <Label htmlFor="reference">Reference *</Label>
              <div className="flex gap-2">
                <Input
                  id="reference"
                  {...register('reference', { required: 'Reference is required' })}
                  placeholder="e.g., JE-2024-001" />

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={generateReference}>

                  <Calculator className="w-4 h-4" />
                </Button>
              </div>
              {errors.reference &&
              <p className="text-sm text-red-600 mt-1">{errors.reference.message}</p>
              }
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              {...register('description', { required: 'Description is required' })}
              placeholder="Describe this journal entry"
              rows={2} />

            {errors.description &&
            <p className="text-sm text-red-600 mt-1">{errors.description.message}</p>
            }
          </div>

          {/* Transaction Entries */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <Label className="text-lg font-semibold">Transaction Entries</Label>
              <Button type="button" onClick={addEntry} size="sm" variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Entry
              </Button>
            </div>

            <div className="space-y-4">
              {fields.map((field, index) =>
              <div key={field.id} className="p-4 border rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
                    <div className="md:col-span-2">
                      <Label>Account *</Label>
                      <Select
                      value={watchedEntries[index]?.accountId || ''}
                      onValueChange={(value) => setValue(`entries.${index}.accountId`, value)}>

                        <SelectTrigger>
                          <SelectValue placeholder="Select account" />
                        </SelectTrigger>
                        <SelectContent>
                          {accounts.map((account) =>
                        <SelectItem key={account.id} value={account.id}>
                              {account.code} - {account.name}
                            </SelectItem>
                        )}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Debit Amount</Label>
                      <Input
                      type="number"
                      step="0.01"
                      {...register(`entries.${index}.debitAmount`, { valueAsNumber: true })}
                      placeholder="0.00" />

                    </div>

                    <div>
                      <Label>Credit Amount</Label>
                      <Input
                      type="number"
                      step="0.01"
                      {...register(`entries.${index}.creditAmount`, { valueAsNumber: true })}
                      placeholder="0.00" />

                    </div>

                    <div className="flex gap-2">
                      <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => remove(index)}
                      disabled={fields.length <= 2}>

                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="mt-2">
                    <Label>Entry Description</Label>
                    <Input
                    {...register(`entries.${index}.description`)}
                    placeholder="Optional description for this entry" />

                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Balance Summary */}
          <Card className={`${isBalanced ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
            <CardContent className="p-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-sm text-muted-foreground">Total Debits</div>
                  <div className="text-lg font-semibold">${totalDebits.toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Total Credits</div>
                  <div className="text-lg font-semibold">${totalCredits.toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Difference</div>
                  <div className={`text-lg font-semibold ${isBalanced ? 'text-green-600' : 'text-red-600'}`}>
                    ${Math.abs(difference).toFixed(2)}
                  </div>
                </div>
              </div>
              
              <div className="mt-2 text-center">
                {isBalanced ?
                <span className="text-green-600 text-sm">✓ Entry is balanced</span> :

                <span className="text-red-600 text-sm">⚠ Entry must be balanced before saving</span>
                }
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end space-x-4">
            {onCancel &&
            <Button type="button" variant="outline" onClick={onCancel}>
                Cancel
              </Button>
            }
            <Button type="submit" disabled={loading || !isBalanced}>
              {loading ? 'Creating...' : 'Create Journal Entry'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>);

};

export default JournalEntryForm;