
import { useState, useEffect } from 'react';
import { Account, AccountType } from '@/types/accounting';
import { accountingService } from '@/services/accountingService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Eye, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { formatUSD } from '@/utils/currencyUtils';

interface ChartOfAccountsProps {
  onAccountSelect?: (account: Account) => void;
  onAddAccount?: () => void;
  onEditAccount?: (account: Account) => void;
}

const ChartOfAccounts = ({ onAccountSelect, onAddAccount, onEditAccount }: ChartOfAccountsProps) => {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedType, setSelectedType] = useState<AccountType | 'all'>('all');

  useEffect(() => {
    loadAccounts();
  }, []);

  const loadAccounts = async () => {
    try {
      setLoading(true);
      const accountsData = await accountingService.getAccounts();
      setAccounts(accountsData);
    } catch (error) {
      toast.error('Failed to load accounts');
    } finally {
      setLoading(false);
    }
  };

  const getAccountTypeColor = (type: AccountType) => {
    const colors = {
      [AccountType.ASSET]: 'bg-green-100 text-green-800',
      [AccountType.LIABILITY]: 'bg-red-100 text-red-800',
      [AccountType.EQUITY]: 'bg-blue-100 text-blue-800',
      [AccountType.REVENUE]: 'bg-purple-100 text-purple-800', // Changed from INCOME to REVENUE for USA GAAP
      [AccountType.EXPENSE]: 'bg-orange-100 text-orange-800',
      [AccountType.INCOME]: 'bg-purple-100 text-purple-800' // Keeping for backward compatibility
    };
    return colors[type] || 'bg-gray-100 text-gray-800';
  };

  const getAccountTypeLabel = (type: AccountType) => {
    const labels = {
      [AccountType.ASSET]: 'Assets',
      [AccountType.LIABILITY]: 'Liabilities',
      [AccountType.EQUITY]: 'Stockholders\' Equity',
      [AccountType.REVENUE]: 'Revenue',
      [AccountType.EXPENSE]: 'Expenses',
      [AccountType.INCOME]: 'Revenue' // Map old INCOME to Revenue
    };
    return labels[type] || type.charAt(0).toUpperCase() + type.slice(1);
  };

  const filteredAccounts = selectedType === 'all' ?
  accounts :
  accounts.filter((account) => account.type === selectedType);

  const groupedAccounts = filteredAccounts.reduce((groups, account) => {
    const type = account.type;
    if (!groups[type]) groups[type] = [];
    groups[type].push(account);
    return groups;
  }, {} as Record<AccountType, Account[]>);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">Loading accounts...</div>
        </CardContent>
      </Card>);

  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Chart of Accounts (USA GAAP)</CardTitle>
          {onAddAccount &&
          <Button onClick={onAddAccount} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Account
            </Button>
          }
        </div>
        
        {/* Filter by account type */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedType === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedType('all')}>

            All
          </Button>
          {Object.values(AccountType).map((type) =>
          <Button
            key={type}
            variant={selectedType === type ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedType(type)}>

              {getAccountTypeLabel(type)}
            </Button>
          )}
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-6">
          {Object.entries(groupedAccounts).map(([type, typeAccounts]) =>
          <div key={type}>
              <h3 className="font-semibold text-lg mb-3 capitalize">
                {getAccountTypeLabel(type as AccountType)}
              </h3>
              
              <div className="space-y-2">
                {typeAccounts.map((account) =>
              <div
                key={account.id}
                className={`p-4 rounded-lg border transition-colors ${
                onAccountSelect ? 'cursor-pointer hover:bg-muted' : ''}`
                }
                onClick={() => onAccountSelect?.(account)}>

                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="font-mono text-sm text-muted-foreground">
                            {account.code}
                          </span>
                          <span className="font-medium">{account.name}</span>
                          <Badge className={getAccountTypeColor(account.type)}>
                            {getAccountTypeLabel(account.type)}
                          </Badge>
                          {!account.isActive &&
                      <Badge variant="outline">Inactive</Badge>
                      }
                        </div>
                        
                        {account.description &&
                    <p className="text-sm text-muted-foreground mb-2">
                            {account.description}
                          </p>
                    }
                        
                        <div className="text-sm">
                          <span className="text-muted-foreground">Balance: </span>
                          <span className={`font-medium ${
                      account.balance >= 0 ? 'text-green-600' : 'text-red-600'}`
                      }>
                            {formatUSD(Math.abs(account.balance))}
                            {account.balance < 0 ? ' (CR)' : ''}
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        {onAccountSelect &&
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onAccountSelect(account);
                      }}>

                            <Eye className="w-4 h-4" />
                          </Button>
                    }
                        
                        {onEditAccount &&
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditAccount(account);
                      }}>

                            <Edit className="w-4 h-4" />
                          </Button>
                    }
                      </div>
                    </div>
                  </div>
              )}
              </div>
            </div>
          )}
        </div>
        
        {filteredAccounts.length === 0 &&
        <div className="text-center py-8 text-muted-foreground">
            No accounts found for the selected filter.
          </div>
        }
      </CardContent>
    </Card>);

};

export default ChartOfAccounts;