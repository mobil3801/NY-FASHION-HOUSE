
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { X, Plus, Upload, Save, ArrowLeft } from 'lucide-react';
import { Product } from '@/types/product';
import { Supplier } from '@/types/supplier';
import { productService } from '@/services/productService';
import { supplierService } from '@/services/supplierService';
import { skuGenerator } from '@/services/skuGenerator';
import BarcodeGenerator from './BarcodeGenerator';
import ImageUploader from './ImageUploader';
import { SupplierDropdown } from './SupplierDropdown';
import { toast } from 'sonner';

interface ProductFormProps {
  product?: Product | null;
  onSave: (product: Product) => void;
  onCancel: () => void;
  isLoading?: boolean;
  onSuccess?: () => void; // Add callback for successful save
}

interface ProductFormData {
  name: string;
  description: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  sku: string;
  supplierId: string;
  stockLevel: number;
  minStockLevel: number;
  sizes: string[];
  colors: string[];
  imageIds: number[];
  isActive: boolean;
}

const ProductForm: React.FC<ProductFormProps> = ({
  product,
  onSave,
  onCancel,
  isLoading = false,
  onSuccess
}) => {
  const [selectedSizes, setSelectedSizes] = useState<string[]>(product?.sizes || []);
  const [selectedColors, setSelectedColors] = useState<string[]>(product?.colors || []);
  const [imageIds, setImageIds] = useState<number[]>(product?.imageIds || []);
  const [generatedSku, setGeneratedSku] = useState<string>(product?.sku || '');
  const queryClient = useQueryClient();

  // Note: Supplier fetching is now handled by SupplierDropdown component
  // This provides better error handling, loading states, and data management

  const categories = productService.getCategories();
  const availableSizes = productService.getSizes();
  const availableColors = productService.getColors();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset,
    trigger
  } = useForm<ProductFormData>({
    mode: 'onBlur',
    defaultValues: {
      name: product?.name || '',
      description: product?.description || '',
      category: product?.category || '',
      costPrice: product?.costPrice || 0,
      sellingPrice: product?.sellingPrice || 0,
      sku: product?.sku || '',
      supplierId: product?.supplierId || '',
      stockLevel: product?.stockLevel || 0,
      minStockLevel: product?.minStockLevel || 5,
      sizes: product?.sizes || [],
      colors: product?.colors || [],
      imageIds: product?.imageIds || [],
      isActive: product?.isActive !== undefined ? product.isActive : true
    }
  });

  const watchedSKU = watch('sku');
  const watchedName = watch('name');
  const watchedCategory = watch('category');

  // Auto-generate 9-11 digit SKU if not editing existing product
  useEffect(() => {
    if (!product && watchedName && watchedCategory && watchedName.length >= 2) {
      const generateSkuAsync = async () => {
        try {
          const newSku = await skuGenerator.generateSKU(watchedName, watchedCategory);
          setGeneratedSku(newSku);
          setValue('sku', newSku);
          // Validate the generated SKU
          trigger('sku');
        } catch (error) {
          console.error('Error generating SKU:', error);
          toast.error('Failed to generate SKU. Please try again.');
          // Generate a fallback simple SKU
          const fallbackSku = skuGenerator.generateSimpleSKU();
          setGeneratedSku(fallbackSku);
          setValue('sku', fallbackSku);
        }
      };

      generateSkuAsync();
    }
  }, [watchedName, watchedCategory, product, setValue, trigger]);

  // Generate initial SKU for new products
  useEffect(() => {
    if (!product && !generatedSku) {
      const generateInitialSku = async () => {
        try {
          // Use default values for initial generation
          const initialSku = skuGenerator.generateSimpleSKU();
          setGeneratedSku(initialSku);
          setValue('sku', initialSku);
        } catch (error) {
          console.error('Error generating initial SKU:', error);
        }
      };

      generateInitialSku();
    }
  }, [product, generatedSku, setValue]);

  const addSize = (size: string) => {
    if (!selectedSizes.includes(size)) {
      const newSizes = [...selectedSizes, size];
      setSelectedSizes(newSizes);
      setValue('sizes', newSizes);
    }
  };

  const removeSize = (size: string) => {
    const newSizes = selectedSizes.filter((s) => s !== size);
    setSelectedSizes(newSizes);
    setValue('sizes', newSizes);
  };

  const addColor = (color: string) => {
    if (!selectedColors.includes(color)) {
      const newColors = [...selectedColors, color];
      setSelectedColors(newColors);
      setValue('colors', newColors);
    }
  };

  const removeColor = (color: string) => {
    const newColors = selectedColors.filter((c) => c !== color);
    setSelectedColors(newColors);
    setValue('colors', newColors);
  };

  const handleImageChange = (newImageIds: number[]) => {
    setImageIds(newImageIds);
    setValue('imageIds', newImageIds);
  };

  const onSubmit = async (data: ProductFormData) => {
    try {
      // Validate required fields that are not in the form validation
      if (!data.category) {
        setValue('category', '');
        trigger('category');
        toast.error('Please select a category');
        return;
      }

      if (!data.supplierId) {
        setValue('supplierId', '');
        trigger('supplierId');
        toast.error('Please select a supplier');
        return;
      }

      const productData = {
        ...data,
        sizes: selectedSizes,
        colors: selectedColors,
        imageIds: imageIds,
        costPrice: Number(data.costPrice),
        sellingPrice: Number(data.sellingPrice),
        stockLevel: Number(data.stockLevel),
        minStockLevel: Number(data.minStockLevel)
      };

      let savedProduct: Product;

      if (product) {
        // Update existing product
        savedProduct = await productService.updateProduct(product.id, productData);
        toast.success('Product updated successfully');
      } else {
        // Create new product - include the auto-generated SKU
        savedProduct = await productService.createProduct(productData);
        toast.success('Product created successfully');
      }

      onSave(savedProduct);

      // Note: Supplier data invalidation is now handled by SupplierDropdown component
      // This provides better separation of concerns and data management

      // Call success callback to trigger refresh
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      const errorMessage = error?.message || 'Failed to save product. Please try again.';
      toast.error(errorMessage);
      console.error('Error saving product:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">
            {product ? 'Edit Product' : 'Add New Product'}
          </h2>
          <p className="text-gray-600">
            {product ? 'Update product information' : 'Create a new product in your inventory'}
          </p>
        </div>
        <Button variant="outline" onClick={onCancel}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Product Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Product Name *</Label>
                    <Input
                      id="name"
                      {...register('name', {
                        required: 'Product name is required',
                        minLength: { value: 2, message: 'Product name must be at least 2 characters' },
                        maxLength: { value: 100, message: 'Product name must be less than 100 characters' }
                      })}
                      placeholder="Enter product name"
                      className={errors.name ? 'border-red-500' : ''} />


                    {errors.name &&
                    <p className="text-sm text-red-600 mt-1">{errors.name.message}</p>
                    }
                  </div>

                  <div>
                    <Label htmlFor="sku">SKU * <span className="text-xs text-gray-500">(9-11 digit auto-generated)</span></Label>
                    <Input
                      id="sku"
                      {...register('sku', {
                        required: 'SKU is required',
                        minLength: { value: 9, message: 'SKU must be between 9-11 digits' },
                        maxLength: { value: 11, message: 'SKU must be between 9-11 digits' },
                        pattern: { value: /^\d+$/, message: 'SKU must contain only digits' }
                      })}
                      placeholder="Auto-generated 9-11 digit SKU"
                      readOnly={!product} // Read-only for new products (auto-generated), editable for existing products
                      className={`${errors.sku ? 'border-red-500' : ''} ${!product ? 'bg-gray-50' : ''} font-mono text-sm`} />


                    {errors.sku &&
                    <p className="text-sm text-red-600 mt-1">{errors.sku.message}</p>
                    }
                    {!product && generatedSku &&
                    <p className="text-xs text-green-600 mt-1">✓ SKU auto-generated successfully</p>
                    }
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    {...register('description')}
                    placeholder="Enter product description"
                    rows={3} />

                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Category *</Label>
                    <Select
                      value={watch('category')}
                      onValueChange={(value) => setValue('category', value)}>

                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) =>
                        <SelectItem key={category} value={category}>
                            {category.split('-').map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    {errors.category &&
                    <p className="text-sm text-red-600 mt-1">{errors.category.message || 'Category is required'}</p>
                    }
                  </div>

                  <div>
                    <Label htmlFor="supplierId">Supplier *</Label>
                    <SupplierDropdown
                      value={watch('supplierId')}
                      onValueChange={(value) => setValue('supplierId', value)}
                      placeholder="Select supplier"
                      disabled={isLoading}
                      required={true}
                      error={errors.supplierId?.message}
                      showRefreshButton={true}
                      showAddButton={false}
                      className="mt-1" />

                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Pricing */}
            <Card>
              <CardHeader>
                <CardTitle>Pricing</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="costPrice">Cost Price ($) *</Label>
                    <Input
                      id="costPrice"
                      type="number"
                      step="0.01"
                      {...register('costPrice', {
                        required: 'Cost price is required',
                        min: { value: 0, message: 'Cost price must be positive' },
                        max: { value: 999999.99, message: 'Cost price is too high' },
                        validate: {
                          decimal: (value) => {
                            const str = value.toString();
                            const decimalPart = str.split('.')[1];
                            return !decimalPart || decimalPart.length <= 2 || 'Maximum 2 decimal places allowed';
                          }
                        }
                      })}
                      className={errors.costPrice ? 'border-red-500' : ''}
                      placeholder="0.00" />

                    {errors.costPrice &&
                    <p className="text-sm text-red-600 mt-1">{errors.costPrice.message}</p>
                    }
                  </div>

                  <div>
                    <Label htmlFor="sellingPrice">Selling Price ($) *</Label>
                    <Input
                      id="sellingPrice"
                      type="number"
                      step="0.01"
                      {...register('sellingPrice', {
                        required: 'Selling price is required',
                        min: { value: 0, message: 'Selling price must be positive' },
                        max: { value: 999999.99, message: 'Selling price is too high' },
                        validate: {
                          decimal: (value) => {
                            const str = value.toString();
                            const decimalPart = str.split('.')[1];
                            return !decimalPart || decimalPart.length <= 2 || 'Maximum 2 decimal places allowed';
                          },
                          profitMargin: (value) => {
                            const costPrice = watch('costPrice');
                            if (costPrice && value < costPrice) {
                              return 'Selling price should be higher than cost price for profit';
                            }
                            return true;
                          }
                        }
                      })}
                      className={errors.sellingPrice ? 'border-red-500' : ''}
                      placeholder="0.00" />

                    {errors.sellingPrice &&
                    <p className="text-sm text-red-600 mt-1">{errors.sellingPrice.message}</p>
                    }
                  </div>
                </div>

                {/* Profit Margin Display */}
                {watch('costPrice') > 0 && watch('sellingPrice') > 0 &&
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm">
                      <span className="font-medium">Profit Margin: </span>
                      ${(watch('sellingPrice') - watch('costPrice')).toFixed(2)} 
                      ({((watch('sellingPrice') - watch('costPrice')) / watch('costPrice') * 100).toFixed(1)}%)
                    </p>
                  </div>
                }
              </CardContent>
            </Card>

            {/* Inventory */}
            <Card>
              <CardHeader>
                <CardTitle>Inventory</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="stockLevel">Current Stock Level *</Label>
                    <Input
                      id="stockLevel"
                      type="number"
                      {...register('stockLevel', {
                        required: 'Stock level is required',
                        min: { value: 0, message: 'Stock level cannot be negative' },
                        max: { value: 999999, message: 'Stock level is too high' },
                        validate: {
                          integer: (value) => Number.isInteger(Number(value)) || 'Stock level must be a whole number'
                        }
                      })}
                      className={errors.stockLevel ? 'border-red-500' : ''}
                      placeholder="0" />

                    {errors.stockLevel &&
                    <p className="text-sm text-red-600 mt-1">{errors.stockLevel.message}</p>
                    }
                  </div>

                  <div>
                    <Label htmlFor="minStockLevel">Minimum Stock Level *</Label>
                    <Input
                      id="minStockLevel"
                      type="number"
                      {...register('minStockLevel', {
                        required: 'Minimum stock level is required',
                        min: { value: 0, message: 'Minimum stock level cannot be negative' },
                        max: { value: 9999, message: 'Minimum stock level is too high' },
                        validate: {
                          integer: (value) => Number.isInteger(Number(value)) || 'Minimum stock level must be a whole number',
                          lessThanStock: (value) => {
                            const stockLevel = watch('stockLevel');
                            if (stockLevel && value > stockLevel) {
                              return 'Minimum stock level should not exceed current stock level';
                            }
                            return true;
                          }
                        }
                      })}
                      className={errors.minStockLevel ? 'border-red-500' : ''}
                      placeholder="5" />

                    {errors.minStockLevel &&
                    <p className="text-sm text-red-600 mt-1">{errors.minStockLevel.message}</p>
                    }
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Variants */}
            <Card>
              <CardHeader>
                <CardTitle>Product Variants</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Sizes */}
                <div>
                  <Label>Available Sizes</Label>
                  <div className="mt-2 space-y-2">
                    <Select onValueChange={addSize}>
                      <SelectTrigger>
                        <SelectValue placeholder="Add a size" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableSizes.
                        filter((size) => !selectedSizes.includes(size)).
                        map((size) =>
                        <SelectItem key={size} value={size}>{size}</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    
                    <div className="flex flex-wrap gap-2">
                      {selectedSizes.map((size) =>
                      <Badge key={size} variant="secondary" className="gap-1">
                          {size}
                          <X
                          className="w-3 h-3 cursor-pointer"
                          onClick={() => removeSize(size)} />

                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Colors */}
                <div>
                  <Label>Available Colors</Label>
                  <div className="mt-2 space-y-2">
                    <Select onValueChange={addColor}>
                      <SelectTrigger>
                        <SelectValue placeholder="Add a color" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableColors.
                        filter((color) => !selectedColors.includes(color)).
                        map((color) =>
                        <SelectItem key={color} value={color}>{color}</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    
                    <div className="flex flex-wrap gap-2">
                      {selectedColors.map((color) =>
                      <Badge key={color} variant="outline" className="gap-1">
                          {color}
                          <X
                          className="w-3 h-3 cursor-pointer"
                          onClick={() => removeColor(color)} />

                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Images */}
            <Card>
              <CardHeader>
                <CardTitle>Product Images</CardTitle>
              </CardHeader>
              <CardContent>
                <ImageUploader
                  value={imageIds}
                  onChange={handleImageChange}
                  maxFiles={8}
                  disabled={isLoading} />

              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Barcode */}
            {watchedSKU &&
            <BarcodeGenerator value={watchedSKU} />
            }

            {/* Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isLoading}>

                  <Save className="w-4 h-4 mr-2" />
                  {isLoading ? 'Saving...' : product ? 'Update Product' : 'Create Product'}
                </Button>
                
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={onCancel}>

                  Cancel
                </Button>

                <Separator />

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isActive"
                    {...register('isActive')}
                    className="rounded" />

                  <Label htmlFor="isActive">Product is active</Label>
                </div>
              </CardContent>
            </Card>

            {/* Product Stats */}
            {product &&
            <Card>
                <CardHeader>
                  <CardTitle>Product Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Created:</span>
                    <span>{product.createdAt.toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Last Updated:</span>
                    <span>{product.updatedAt.toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Barcode:</span>
                    <span className="font-mono">{product.barcode}</span>
                  </div>
                </CardContent>
              </Card>
            }
          </div>
        </div>
      </form>
    </div>);

};

export default ProductForm;