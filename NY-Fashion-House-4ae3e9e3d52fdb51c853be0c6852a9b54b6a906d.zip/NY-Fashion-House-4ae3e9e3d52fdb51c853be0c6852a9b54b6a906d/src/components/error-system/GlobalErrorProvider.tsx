import React, { createContext, useContext, useCallback, ReactNode } from 'react';
import { FinalizedErrorService } from '../../services/error-system/FinalizedErrorService';

interface ErrorContextValue {
  reportError: (error: Error, metadata?: any) => string;
  reportIssue: (errorId: string, details: any) => boolean;
  getErrorStats: () => any;
  generateHealthReport: () => any;
}

const ErrorContext = createContext<ErrorContextValue | null>(null);

interface GlobalErrorProviderProps {
  children: ReactNode;
}

export const GlobalErrorProvider: React.FC<GlobalErrorProviderProps> = ({ children }) => {
  const errorService = FinalizedErrorService.getInstance();

  const reportError = useCallback((error: Error, metadata?: any) => {
    return errorService.captureError(error, metadata);
  }, [errorService]);

  const reportIssue = useCallback((errorId: string, details: any) => {
    return errorService.reportIssue(errorId, details);
  }, [errorService]);

  const getErrorStats = useCallback(() => {
    return errorService.getErrorStats();
  }, [errorService]);

  const generateHealthReport = useCallback(() => {
    return errorService.generateHealthReport();
  }, [errorService]);

  const value: ErrorContextValue = {
    reportError,
    reportIssue,
    getErrorStats,
    generateHealthReport
  };

  return (
    <ErrorContext.Provider value={value}>
      {children}
    </ErrorContext.Provider>);

};

export const useErrorReporting = () => {
  const context = useContext(ErrorContext);
  if (!context) {
    throw new Error('useErrorReporting must be used within a GlobalErrorProvider');
  }
  return context;
};