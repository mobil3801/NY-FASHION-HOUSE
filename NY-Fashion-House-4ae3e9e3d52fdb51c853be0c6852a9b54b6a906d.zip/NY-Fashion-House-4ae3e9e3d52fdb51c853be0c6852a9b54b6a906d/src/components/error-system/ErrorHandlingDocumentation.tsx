import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { Button } from '../ui/button';
import {
  Book,
  Code,
  AlertTriangle,
  CheckCircle,
  Info,
  Lightbulb,
  Download,
  ExternalLink } from
'lucide-react';

export const ErrorHandlingDocumentation: React.FC = () => {
  const [activeExample, setActiveExample] = useState<string>('');

  const codeExamples = {
    basicUsage: `import { FinalErrorBoundary } from '../components/error-system/FinalErrorBoundary';
import { useErrorReporting } from '../components/error-system/GlobalErrorProvider';

// Wrap components with error boundary
function MyPage() {
  return (
    <FinalErrorBoundary level="page" identifier="my-page">
      <MyPageContent />
    </FinalErrorBoundary>
  );
}

// Use error reporting hook
function MyComponent() {
  const { reportError } = useErrorReporting();
  
  const handleError = (error: Error) => {
    const errorId = reportError(error, {
      level: 'component',
      identifier: 'my-component',
      feature: 'user-action',
      context: { userId: 'user123' }
    });
    console.log('Error reported with ID:', errorId);
  };
  
  return <div>...</div>;
}`,

    errorBoundary: `// Custom error boundary with fallback
<FinalErrorBoundary 
  level="section"
  identifier="user-profile"
  fallback={(error, errorInfo) => (
    <div className="p-4 bg-red-50 rounded">
      <h3>Profile Loading Error</h3>
      <p>We couldn't load your profile. Please try again.</p>
      <Button onClick={() => window.location.reload()}>
        Retry
      </Button>
    </div>
  )}
  onError={(error, errorInfo) => {
    // Custom error handling logic
    analytics.track('profile_error', {
      error: error.message,
      component: errorInfo.componentStack
    });
  }}
>
  <UserProfile />
</FinalErrorBoundary>`,

    asyncErrors: `// Handling async errors
import { useErrorReporting } from '../components/error-system/GlobalErrorProvider';

function DataFetcher() {
  const { reportError } = useErrorReporting();
  
  const fetchData = async () => {
    try {
      const response = await api.getData();
      return response.data;
    } catch (error) {
      const errorId = reportError(error as Error, {
        level: 'system',
        identifier: 'data-fetcher',
        context: {
          operation: 'fetchData',
          timestamp: new Date().toISOString()
        }
      });
      
      // Show user-friendly message
      toast.error('Failed to load data. Please try again.');
      
      throw error;
    }
  };
  
  return <div>...</div>;
}`,

    globalSetup: `// App.tsx - Global error system setup
import { GlobalErrorProvider } from './components/error-system/GlobalErrorProvider';
import { FinalErrorBoundary } from './components/error-system/FinalErrorBoundary';

function App() {
  return (
    <GlobalErrorProvider>
      <FinalErrorBoundary level="page" identifier="app-root">
        <Router>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/users" element={
              <FinalErrorBoundary level="page" identifier="users-page">
                <UsersPage />
              </FinalErrorBoundary>
            } />
          </Routes>
        </Router>
      </FinalErrorBoundary>
    </GlobalErrorProvider>
  );
}`,

    customHooks: `// Custom error handling hooks
import { useErrorReporting } from '../components/error-system/GlobalErrorProvider';
import { useCallback } from 'react';

export function useAsyncErrorHandler() {
  const { reportError } = useErrorReporting();
  
  return useCallback(async (asyncFn: () => Promise<any>, context?: any) => {
    try {
      return await asyncFn();
    } catch (error) {
      reportError(error as Error, {
        level: 'component',
        identifier: context?.component || 'unknown',
        context
      });
      throw error;
    }
  }, [reportError]);
}

// Usage
function MyComponent() {
  const handleAsync = useAsyncErrorHandler();
  
  const loadData = () => {
    return handleAsync(
      () => api.loadData(),
      { component: 'my-component', operation: 'load-data' }
    );
  };
  
  return <div>...</div>;
}`
  };

  const bestPractices = [
  {
    title: "Error Boundary Placement",
    description: "Place error boundaries at strategic points in your component tree",
    examples: [
    "Page level: Catch entire page failures",
    "Feature level: Isolate feature-specific errors",
    "Component level: Protect critical UI components"],

    severity: "high"
  },
  {
    title: "Error Context",
    description: "Always provide meaningful context when reporting errors",
    examples: [
    "Include user ID and session information",
    "Add operation being performed",
    "Include relevant state or props"],

    severity: "medium"
  },
  {
    title: "User Experience",
    description: "Provide helpful fallback UI and recovery options",
    examples: [
    "Show actionable error messages",
    "Provide retry mechanisms",
    "Offer alternative navigation paths"],

    severity: "high"
  },
  {
    title: "Performance",
    description: "Minimize performance impact of error handling",
    examples: [
    "Use performance-optimized error capture",
    "Batch error reports when possible",
    "Avoid blocking the main thread"],

    severity: "medium"
  }];


  const troubleshooting = [
  {
    issue: "Error boundary not catching errors",
    cause: "Error boundaries only catch errors in render methods, lifecycle methods, and constructors",
    solution: "Use try-catch blocks for event handlers and async operations"
  },
  {
    issue: "Too many error reports",
    cause: "Same error being reported multiple times",
    solution: "Error system automatically deduplicates based on error fingerprint"
  },
  {
    issue: "Missing error context",
    cause: "Not providing enough metadata when reporting errors",
    solution: "Always include level, identifier, and relevant context information"
  },
  {
    issue: "Performance degradation",
    cause: "Error handling impacting application performance",
    solution: "Use the built-in performance optimization features"
  }];


  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Book className="h-8 w-8 text-blue-500" />
            Error Handling System Documentation
          </h1>
          <p className="text-muted-foreground mt-2">
            Comprehensive guide to implementing and using the error handling system
          </p>
        </div>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export PDF
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
          <TabsTrigger value="best-practices">Best Practices</TabsTrigger>
          <TabsTrigger value="troubleshooting">Troubleshooting</TabsTrigger>
          <TabsTrigger value="api">API Reference</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="h-5 w-5" />
                System Overview
              </CardTitle>
              <CardDescription>
                Understanding the comprehensive error handling system architecture
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Core Components</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">FinalErrorBoundary - React error boundaries</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">FinalizedErrorService - Centralized error management</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">GlobalErrorProvider - Context and hooks</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">ErrorMonitoringDashboard - Real-time monitoring</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold mb-3">Key Features</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">Automatic Error Capture</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">Performance Optimization</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">Pattern Detection</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">DevTools Integration</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">Real-time Monitoring</Badge>
                    </div>
                  </div>
                </div>
              </div>

              <Alert>
                <Lightbulb className="h-4 w-4" />
                <AlertDescription>
                  The error handling system is designed to be lightweight, performant, and developer-friendly. 
                  It automatically captures errors, provides detailed debugging information, and offers 
                  graceful fallback experiences for users.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Error Severity Levels</CardTitle>
              <CardDescription>
                Understanding different error severities and their implications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Badge variant="destructive">Critical</Badge>
                    <span className="text-sm">Page-level failures, security issues, data loss</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary">High</Badge>
                    <span className="text-sm">System errors, API failures, authentication issues</span>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline">Medium</Badge>
                    <span className="text-sm">Component failures, validation errors, UI issues</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline">Low</Badge>
                    <span className="text-sm">Minor UI glitches, non-critical component errors</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="implementation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5" />
                Implementation Guide
              </CardTitle>
              <CardDescription>
                Step-by-step guide to implementing the error handling system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeExample} onValueChange={setActiveExample}>
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="basicUsage">Basic Usage</TabsTrigger>
                  <TabsTrigger value="errorBoundary">Error Boundaries</TabsTrigger>
                  <TabsTrigger value="asyncErrors">Async Errors</TabsTrigger>
                  <TabsTrigger value="globalSetup">Global Setup</TabsTrigger>
                  <TabsTrigger value="customHooks">Custom Hooks</TabsTrigger>
                </TabsList>
                
                {Object.entries(codeExamples).map(([key, code]) =>
                <TabsContent key={key} value={key} className="mt-4">
                    <pre className="bg-gray-50 p-4 rounded-lg overflow-x-auto text-sm">
                      <code>{code}</code>
                    </pre>
                  </TabsContent>
                )}
              </Tabs>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Integration Steps</CardTitle>
              <CardDescription>
                Complete integration checklist
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-medium">1</div>
                  <div>
                    <h4 className="font-medium">Wrap your app with GlobalErrorProvider</h4>
                    <p className="text-sm text-muted-foreground">Add the provider at the root of your application</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-medium">2</div>
                  <div>
                    <h4 className="font-medium">Add error boundaries at key points</h4>
                    <p className="text-sm text-muted-foreground">Place FinalErrorBoundary components strategically</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-medium">3</div>
                  <div>
                    <h4 className="font-medium">Use error reporting hooks</h4>
                    <p className="text-sm text-muted-foreground">Implement useErrorReporting in components that handle async operations</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-medium">4</div>
                  <div>
                    <h4 className="font-medium">Configure monitoring dashboard</h4>
                    <p className="text-sm text-muted-foreground">Add the ErrorMonitoringDashboard to your admin interface</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm font-medium">5</div>
                  <div>
                    <h4 className="font-medium">Test and validate</h4>
                    <p className="text-sm text-muted-foreground">Verify error boundaries work correctly and errors are captured</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="best-practices" className="space-y-6">
          <div className="grid gap-6">
            {bestPractices.map((practice, index) =>
            <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {practice.severity === 'high' ?
                  <AlertTriangle className="h-5 w-5 text-red-500" /> :

                  <Info className="h-5 w-5 text-blue-500" />
                  }
                    {practice.title}
                    <Badge variant={practice.severity === 'high' ? 'destructive' : 'secondary'}>
                      {practice.severity}
                    </Badge>
                  </CardTitle>
                  <CardDescription>{practice.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {practice.examples.map((example, exIndex) =>
                  <li key={exIndex} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                        {example}
                      </li>
                  )}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="troubleshooting" className="space-y-6">
          <div className="space-y-4">
            {troubleshooting.map((item, index) =>
            <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    {item.issue}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <h4 className="font-medium text-sm text-red-600 mb-1">Likely Cause:</h4>
                    <p className="text-sm">{item.cause}</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm text-green-600 mb-1">Solution:</h4>
                    <p className="text-sm">{item.solution}</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="api" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>API Reference</CardTitle>
              <CardDescription>
                Complete API documentation for the error handling system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-lg mb-3">FinalErrorBoundary Props</h3>
                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <strong>Property</strong>
                      <strong>Type</strong>
                      <strong>Description</strong>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>level</code>
                      <code>'page' | 'component' | 'section'</code>
                      <span>Error boundary level for severity calculation</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>identifier</code>
                      <code>string</code>
                      <span>Unique identifier for the component</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>fallback</code>
                      <code>Function</code>
                      <span>Custom fallback UI renderer</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>onError</code>
                      <code>Function</code>
                      <span>Error event handler</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-lg mb-3">useErrorReporting Hook</h3>
                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <strong>Method</strong>
                      <strong>Parameters</strong>
                      <strong>Description</strong>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>reportError</code>
                      <code>(error: Error, metadata?: any) =&gt; string</code>
                      <span>Report an error with optional metadata</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>reportIssue</code>
                      <code>(errorId: string, details: any) =&gt; boolean</code>
                      <span>Report user feedback for an error</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>getErrorStats</code>
                      <code>() =&gt; any</code>
                      <span>Get current error statistics</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm py-2 border-t">
                      <code>generateHealthReport</code>
                      <code>() =&gt; any</code>
                      <span>Generate comprehensive health report</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};