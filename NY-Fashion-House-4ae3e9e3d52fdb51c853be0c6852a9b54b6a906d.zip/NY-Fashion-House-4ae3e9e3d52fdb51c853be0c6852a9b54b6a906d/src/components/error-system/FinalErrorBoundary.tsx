import React, { Component, ReactNode, ErrorInfo } from 'react';
import { AlertTriangle, RefreshCw, Home, FileText } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { FinalizedErrorService } from '../../services/error-system/FinalizedErrorService';

interface Props {
  children: ReactNode;
  fallback?: (error: Error, errorInfo: ErrorInfo) => ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  level?: 'page' | 'component' | 'section';
  identifier?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorId: string | null;
  isRecovering: boolean;
}

export class FinalErrorBoundary extends Component<Props, State> {
  private errorService: FinalizedErrorService;

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: null,
      isRecovering: false
    };
    this.errorService = FinalizedErrorService.getInstance();
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return {
      hasError: true,
      error
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    const errorId = this.errorService.captureError(error, {
      errorInfo,
      level: this.props.level || 'component',
      identifier: this.props.identifier,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      componentStack: errorInfo.componentStack
    });

    this.setState({
      error,
      errorInfo,
      errorId
    });

    this.props.onError?.(error, errorInfo);
  }

  private handleRetry = () => {
    this.setState({ isRecovering: true });

    setTimeout(() => {
      this.setState({
        hasError: false,
        error: null,
        errorInfo: null,
        errorId: null,
        isRecovering: false
      });
    }, 1000);
  };

  private handleReportIssue = () => {
    if (this.state.errorId) {
      this.errorService.reportIssue(this.state.errorId, {
        userFeedback: 'User reported issue from error boundary',
        reproductionSteps: 'Error occurred during normal application usage'
      });
    }
  };

  private renderErrorFallback() {
    const { error, errorInfo, errorId, isRecovering } = this.state;
    const { level = 'component' } = this.props;

    if (this.props.fallback && error && errorInfo) {
      return this.props.fallback(error, errorInfo);
    }

    const severity = level === 'page' ? 'high' : level === 'section' ? 'medium' : 'low';
    const canRetry = level !== 'page';

    return (
      <Card className="w-full max-w-2xl mx-auto my-4">
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className={`h-5 w-5 ${
            severity === 'high' ? 'text-red-500' :
            severity === 'medium' ? 'text-yellow-500' : 'text-blue-500'}`
            } />
            <CardTitle className="text-lg">
              {severity === 'high' ? 'Page Error' : 'Component Error'}
            </CardTitle>
            <Badge variant={severity === 'high' ? 'destructive' : 'secondary'}>
              {severity.toUpperCase()}
            </Badge>
          </div>
          <CardDescription>
            {severity === 'high' ?
            'This page encountered an unexpected error' :
            'A component on this page encountered an error'
            }
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {process.env.NODE_ENV === 'development' &&
          <Alert>
              <FileText className="h-4 w-4" />
              <AlertDescription className="font-mono text-sm">
                <div className="mb-2">
                  <strong>Error:</strong> {error?.message}
                </div>
                <div className="mb-2">
                  <strong>Error ID:</strong> {errorId}
                </div>
                <details className="mt-2">
                  <summary className="cursor-pointer text-sm font-medium">
                    Stack Trace
                  </summary>
                  <pre className="mt-2 text-xs overflow-auto max-h-40 bg-gray-50 p-2 rounded">
                    {error?.stack}
                  </pre>
                </details>
                {errorInfo &&
              <details className="mt-2">
                    <summary className="cursor-pointer text-sm font-medium">
                      Component Stack
                    </summary>
                    <pre className="mt-2 text-xs overflow-auto max-h-40 bg-gray-50 p-2 rounded">
                      {errorInfo.componentStack}
                    </pre>
                  </details>
              }
              </AlertDescription>
            </Alert>
          }

          <div className="flex flex-wrap gap-2">
            {canRetry &&
            <Button
              onClick={this.handleRetry}
              disabled={isRecovering}
              variant="default"
              size="sm">

                {isRecovering ?
              <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Recovering...
                  </> :

              <>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Try Again
                  </>
              }
              </Button>
            }
            
            <Button
              onClick={() => window.location.href = '/'}
              variant="outline"
              size="sm">

              <Home className="h-4 w-4 mr-2" />
              Go Home
            </Button>

            <Button
              onClick={this.handleReportIssue}
              variant="outline"
              size="sm">

              <FileText className="h-4 w-4 mr-2" />
              Report Issue
            </Button>
          </div>
        </CardContent>
      </Card>);

  }

  render() {
    if (this.state.hasError) {
      return this.renderErrorFallback();
    }

    return this.props.children;
  }
}