import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Alert, AlertDescription } from '../ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import {
  AlertTriangle,
  TrendingUp,
  Activity,
  Download,
  RefreshCw,
  BarChart3,
  Clock,
  Shield,
  Zap } from
'lucide-react';
import { useErrorReporting } from './GlobalErrorProvider';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const SEVERITY_COLORS = {
  low: '#10B981',
  medium: '#F59E0B',
  high: '#EF4444',
  critical: '#DC2626'
};

export const ErrorMonitoringDashboard: React.FC = () => {
  const { getErrorStats, generateHealthReport } = useErrorReporting();
  const [stats, setStats] = useState<any>(null);
  const [healthReport, setHealthReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const refreshData = async () => {
    setLoading(true);
    try {
      const errorStats = getErrorStats();
      const health = generateHealthReport();
      setStats(errorStats);
      setHealthReport(health);
    } catch (error) {
      console.error('Failed to refresh dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(refreshData, 30000); // Refresh every 30 seconds
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const exportHealthReport = () => {
    if (!healthReport) return;

    const dataStr = JSON.stringify(healthReport, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `error-health-report-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (loading && !stats) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-4">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto text-blue-500" />
          <p className="text-sm text-muted-foreground">Loading error monitoring data...</p>
        </div>
      </div>);

  }

  const severityData = stats ? Object.entries(stats.severityDistribution).map(([key, value]) => ({
    name: key.charAt(0).toUpperCase() + key.slice(1),
    value: value as number,
    color: SEVERITY_COLORS[key as keyof typeof SEVERITY_COLORS]
  })) : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Error Monitoring Dashboard</h1>
          <p className="text-muted-foreground">
            Real-time error tracking and system health monitoring
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setAutoRefresh(!autoRefresh)}
            variant={autoRefresh ? "default" : "outline"}
            size="sm">

            <Activity className={`h-4 w-4 mr-2 ${autoRefresh ? 'animate-pulse' : ''}`} />
            Auto Refresh
          </Button>
          <Button onClick={refreshData} variant="outline" size="sm" disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button onClick={exportHealthReport} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* System Health Alert */}
      {healthReport?.recommendations?.length > 0 &&
      <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <div className="font-medium mb-2">System Health Recommendations:</div>
            <ul className="list-disc list-inside space-y-1">
              {healthReport.recommendations.map((rec: string, index: number) =>
            <li key={index} className="text-sm">{rec}</li>
            )}
            </ul>
          </AlertDescription>
        </Alert>
      }

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Errors</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalErrors || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.uniqueErrors || 0} unique errors
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Error Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats?.errorRate ? stats.errorRate.toFixed(2) : '0.00'}
            </div>
            <p className="text-xs text-muted-foreground">
              errors per unique issue
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resolved</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.resolvedErrors || 0}</div>
            <div className="mt-2">
              <Progress
                value={stats?.uniqueErrors > 0 ? stats.resolvedErrors / stats.uniqueErrors * 100 : 0}
                className="h-2" />

            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              <Badge
                variant={
                stats?.severityDistribution?.critical > 0 ? "destructive" :
                stats?.severityDistribution?.high > 0 ? "secondary" :
                "default"
                }>

                {stats?.severityDistribution?.critical > 0 ? "Critical" :
                stats?.severityDistribution?.high > 0 ? "Warning" :
                "Healthy"}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Last updated: {healthReport?.timestamp ?
              new Date(healthReport.timestamp).toLocaleTimeString() : 'Never'}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="errors">Error List</TabsTrigger>
          <TabsTrigger value="patterns">Patterns</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Severity Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Error Severity Distribution</CardTitle>
                <CardDescription>
                  Breakdown of errors by severity level
                </CardDescription>
              </CardHeader>
              <CardContent>
                {severityData.length > 0 ?
                <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                      data={severityData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      dataKey="value">

                        {severityData.map((entry, index) =>
                      <Cell key={`cell-${index}`} fill={entry.color} />
                      )}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer> :

                <div className="flex items-center justify-center h-48 text-muted-foreground">
                    No error data available
                  </div>
                }
                <div className="flex flex-wrap gap-2 mt-4">
                  {severityData.map((item) =>
                  <div key={item.name} className="flex items-center gap-2">
                      <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }} />

                      <span className="text-sm">
                        {item.name}: {item.value}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Impact</CardTitle>
                <CardDescription>
                  Error handling performance metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                {healthReport?.performance ?
                <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Average Capture Time</span>
                      <span className="font-mono text-sm">
                        {healthReport.performance.averageCaptureTime || 0}ms
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Total Operations</span>
                      <span className="font-mono text-sm">
                        {healthReport.performance.totalOperations || 0}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Memory Usage</span>
                      <span className="font-mono text-sm">
                        {healthReport.performance.memoryUsage ?
                      `${(healthReport.performance.memoryUsage / 1024 / 1024).toFixed(1)}MB` :
                      'N/A'}
                      </span>
                    </div>
                  </div> :

                <div className="flex items-center justify-center h-32 text-muted-foreground">
                    Performance data not available
                  </div>
                }
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="errors" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Errors</CardTitle>
              <CardDescription>
                Latest errors captured by the system
              </CardDescription>
            </CardHeader>
            <CardContent>
              {stats?.topErrors?.length > 0 ?
              <div className="space-y-4">
                  {stats.topErrors.map((error: any, index: number) =>
                <div key={error.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex justify-between items-start">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium truncate">
                            {error.error.message}
                          </h4>
                          <p className="text-sm text-muted-foreground">
                            {error.metadata.identifier || 'Unknown component'}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Badge
                        variant={
                        error.metadata.severity === 'critical' ? 'destructive' :
                        error.metadata.severity === 'high' ? 'secondary' :
                        'outline'
                        }>

                            {error.metadata.severity || 'low'}
                          </Badge>
                          <span className="text-sm font-mono">
                            {error.count}x
                          </span>
                        </div>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>First: {new Date(error.firstSeen).toLocaleString()}</span>
                        <span>Last: {new Date(error.lastSeen).toLocaleString()}</span>
                      </div>
                    </div>
                )}
                </div> :

              <div className="flex items-center justify-center h-32 text-muted-foreground">
                  No errors captured yet
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Error Patterns</CardTitle>
              <CardDescription>
                Automated pattern analysis and insights
              </CardDescription>
            </CardHeader>
            <CardContent>
              {healthReport?.patterns ?
              <div className="space-y-4">
                  {healthReport.patterns.commonComponents &&
                <div>
                      <h4 className="font-medium mb-2">Frequently Affected Components</h4>
                      <div className="flex flex-wrap gap-2">
                        {healthReport.patterns.commonComponents.map((component: string, index: number) =>
                    <Badge key={index} variant="outline">{component}</Badge>
                    )}
                      </div>
                    </div>
                }
                  
                  {healthReport.patterns.timePatterns &&
                <div>
                      <h4 className="font-medium mb-2">Time Patterns</h4>
                      <p className="text-sm text-muted-foreground">
                        Peak error times: {healthReport.patterns.timePatterns.join(', ')}
                      </p>
                    </div>
                }
                  
                  {healthReport.patterns.anomalies?.length > 0 &&
                <div>
                      <h4 className="font-medium mb-2">Anomalies Detected</h4>
                      <div className="space-y-2">
                        {healthReport.patterns.anomalies.map((anomaly: string, index: number) =>
                    <Alert key={index}>
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>{anomaly}</AlertDescription>
                          </Alert>
                    )}
                      </div>
                    </div>
                }
                </div> :

              <div className="flex items-center justify-center h-32 text-muted-foreground">
                  Pattern analysis not available
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription>
                Detailed performance impact analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              {healthReport?.performance ?
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">Capture Performance</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Average Time</span>
                        <span className="font-mono text-sm">
                          {healthReport.performance.averageCaptureTime || 0}ms
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Max Time</span>
                        <span className="font-mono text-sm">
                          {healthReport.performance.maxCaptureTime || 0}ms
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Min Time</span>
                        <span className="font-mono text-sm">
                          {healthReport.performance.minCaptureTime || 0}ms
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-medium">Memory Usage</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">Current</span>
                        <span className="font-mono text-sm">
                          {healthReport.performance.memoryUsage ?
                        `${(healthReport.performance.memoryUsage / 1024 / 1024).toFixed(1)}MB` :
                        'N/A'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Peak</span>
                        <span className="font-mono text-sm">
                          {healthReport.performance.peakMemoryUsage ?
                        `${(healthReport.performance.peakMemoryUsage / 1024 / 1024).toFixed(1)}MB` :
                        'N/A'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div> :

              <div className="flex items-center justify-center h-32 text-muted-foreground">
                  Performance metrics not available
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};