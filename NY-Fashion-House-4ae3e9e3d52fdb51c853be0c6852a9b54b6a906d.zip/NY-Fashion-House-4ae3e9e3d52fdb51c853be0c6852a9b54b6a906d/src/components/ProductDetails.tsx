
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Edit, Package, DollarSign, Users, Calendar, Barcode, AlertTriangle } from 'lucide-react';
import { Product } from '@/types/product';
import { Supplier } from '@/types/supplier';
import BarcodeGenerator from './BarcodeGenerator';
import StockAdjustment from './StockAdjustment';
import ProductImageGallery from './ProductImageGallery';

interface ProductDetailsProps {
  product: Product | null;
  supplier?: Supplier | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit: (product: Product) => void;
  onProductUpdate?: (product: Product) => void;
}

const ProductDetails: React.FC<ProductDetailsProps> = ({
  product,
  supplier,
  open,
  onOpenChange,
  onEdit,
  onProductUpdate
}) => {
  if (!product) return null;

  const formatPrice = (price: number, currencyCode: string = 'INR') => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currencyCode
    }).format(price);
  };

  const getStockStatus = () => {
    if (product.stockLevel === 0) {
      return { label: 'Out of Stock', variant: 'destructive' as const, icon: Package };
    }
    if (product.stockLevel <= product.minStockLevel) {
      return { label: 'Low Stock', variant: 'secondary' as const, icon: AlertTriangle };
    }
    return { label: 'In Stock', variant: 'default' as const, icon: Package };
  };

  const stockStatus = getStockStatus();
  const profitMargin = product.sellingPrice - product.costPrice;
  const profitPercentage = (profitMargin / product.costPrice * 100).toFixed(1);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-2xl">{product.name}</DialogTitle>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline">{product.sku}</Badge>
                <Badge variant="outline">
                  {product.category.charAt(0).toUpperCase() + product.category.slice(1).replace('-', ' ')}
                </Badge>
                <Badge variant={stockStatus.variant}>
                  <stockStatus.icon className="w-3 h-3 mr-1" />
                  {stockStatus.label}
                </Badge>
              </div>
            </div>
            <Button onClick={() => onEdit(product)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Product
            </Button>
          </div>
        </DialogHeader>

        {/* Product Image Gallery - Moved to top */}
        <ProductImageGallery
          imageIds={product.imageIds}
          productName={product.name} />


        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">

            {/* Description */}
            {product.description &&
            <Card>
                <CardHeader>
                  <CardTitle>Description</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">{product.description}</p>
                </CardContent>
              </Card>
            }

            {/* Variants */}
            <Card>
              <CardHeader>
                <CardTitle>Product Variants</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Sizes */}
                {product.sizes.length > 0 &&
                <div>
                    <h4 className="font-medium mb-2">Available Sizes</h4>
                    <div className="flex flex-wrap gap-2">
                      {product.sizes.map((size) =>
                    <Badge key={size} variant="outline">
                          {size}
                        </Badge>
                    )}
                    </div>
                  </div>
                }

                {product.sizes.length > 0 && product.colors.length > 0 && <Separator />}

                {/* Colors */}
                {product.colors.length > 0 &&
                <div>
                    <h4 className="font-medium mb-2">Available Colors</h4>
                    <div className="flex flex-wrap gap-2">
                      {product.colors.map((color) =>
                    <Badge key={color} variant="secondary">
                          {color}
                        </Badge>
                    )}
                    </div>
                  </div>
                }

                {product.sizes.length === 0 && product.colors.length === 0 &&
                <p className="text-gray-500 text-center py-4">No variants configured</p>
                }
              </CardContent>
            </Card>

            {/* Supplier Information */}
            {supplier &&
            <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Supplier Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">{supplier.name}</h4>
                        <p className="text-sm text-gray-600">{supplier.contactPerson}</p>
                      </div>
                      <Badge variant="outline">{supplier.paymentTerms}</Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Email:</span>
                        <p>{supplier.email}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Phone:</span>
                        <p>{supplier.phone}</p>
                      </div>
                    </div>

                    <div className="text-sm">
                      <span className="text-gray-600">Address:</span>
                      <p>
                        {supplier.address.city}, {supplier.address.state} - {supplier.address.pincode}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            }
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Pricing Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  Pricing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Cost Price:</span>
                  <span className="font-medium">{formatPrice(product.costPrice, 'USD')}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Selling Price:</span>
                  <span className="font-medium text-green-600">{formatPrice(product.sellingPrice, 'USD')}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Profit Margin:</span>
                  <div className="text-right">
                    <p className="font-medium text-green-600">{formatPrice(profitMargin, 'USD')}</p>
                    <p className="text-sm text-gray-500">({profitPercentage}%)</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Stock Management */}
            <StockAdjustment
              product={product}
              onStockUpdated={(updatedProduct) => {
                onProductUpdate?.(updatedProduct);
              }} />


            {/* Barcode */}
            <BarcodeGenerator value={product.barcode} />

            {/* Product Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Created:</span>
                  <span>{product.createdAt.toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Last Updated:</span>
                  <span>{product.updatedAt.toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <Badge variant={product.isActive ? "default" : "secondary"}>
                    {product.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>);

};

export default ProductDetails;