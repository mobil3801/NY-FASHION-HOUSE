
import React, { useState, useEffect } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CalendarIcon, Plus, Trash2, Save, X } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Invoice, InvoiceItem } from '@/types/invoice';
import { Customer } from '@/types/customer';
import { Product } from '@/types/product';
import { customerService } from '@/services/customerService';
import { productService } from '@/services/productService';
import { invoiceService } from '@/services/invoiceService';
import { toast } from 'sonner';
import { validators, validateUSAStandards } from '@/utils/formatValidation';

interface InvoiceFormProps {
  invoice?: Invoice;
  onSave: (invoice: Invoice) => void;
  onCancel: () => void;
}

interface InvoiceFormData {
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  issueDate: Date;
  dueDate: Date;
  items: InvoiceItem[];
  discountPercentage: number;
  taxPercentage: number;
  notes: string;
  terms: string;
  footerText: string;
  status: Invoice['status'];
}

const InvoiceForm: React.FC<InvoiceFormProps> = ({ invoice, onSave, onCancel }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);

  const { control, register, handleSubmit, watch, setValue, formState: { errors }, trigger } = useForm<InvoiceFormData>({
    mode: 'onBlur',
    defaultValues: {
      customerId: invoice?.customerId || '',
      customerName: invoice?.customerName || '',
      customerEmail: invoice?.customerEmail || '',
      customerPhone: invoice?.customerPhone || '',
      customerAddress: invoice?.customerAddress || '',
      issueDate: invoice?.issueDate || new Date(),
      dueDate: invoice?.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      items: invoice?.items || [{ id: '1', productName: '', description: '', quantity: 1, unitPrice: 0, discount: 0, total: 0 }],
      discountPercentage: invoice?.discountPercentage || 0,
      taxPercentage: invoice?.taxPercentage || 8.875, // NYC sales tax rate
      notes: invoice?.notes || '',
      terms: invoice?.terms || invoiceService.getDefaultTemplate().defaultTerms,
      footerText: invoice?.footerText || invoiceService.getDefaultTemplate().defaultFooter,
      status: invoice?.status || 'draft'
    }
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items'
  });

  const watchedItems = watch('items');
  const watchedDiscountPercentage = watch('discountPercentage');
  const watchedTaxPercentage = watch('taxPercentage');

  // Calculate totals
  const totals = React.useMemo(() => {
    return invoiceService.calculateInvoiceTotals(watchedItems, watchedDiscountPercentage, watchedTaxPercentage);
  }, [watchedItems, watchedDiscountPercentage, watchedTaxPercentage]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [customersData, productsData] = await Promise.all([
        customerService.getAllCustomers(),
        productService.getAllProducts()]
        );
        setCustomers(customersData);
        setProducts(productsData);
      } catch (error) {
        toast.error('Failed to load customers and products');
      }
    };
    loadData();
  }, []);

  // Auto-calculate item totals
  useEffect(() => {
    watchedItems.forEach((item, index) => {
      const total = item.unitPrice * item.quantity - item.discount;
      if (item.total !== total) {
        setValue(`items.${index}.total`, total);
      }
    });
  }, [watchedItems, setValue]);

  const onSubmit = async (data: InvoiceFormData) => {
    setLoading(true);
    try {
      // Additional validation
      if (!data.customerName?.trim()) {
        toast.error('Customer name is required');
        return;
      }

      if (data.items.length === 0) {
        toast.error('At least one item is required');
        return;
      }

      // Validate items
      const hasInvalidItems = data.items.some((item) =>
      !item.productName?.trim() ||
      !item.quantity ||
      item.quantity <= 0 ||
      !item.unitPrice ||
      item.unitPrice < 0
      );

      if (hasInvalidItems) {
        toast.error('Please check all items have valid product names, quantities, and prices');
        return;
      }

      // Check due date is not before issue date
      if (data.dueDate < data.issueDate) {
        toast.error('Due date cannot be before issue date');
        return;
      }

      const invoiceData: Omit<Invoice, 'id' | 'invoiceNumber' | 'createdAt' | 'updatedAt' | 'remainingAmount'> = {
        saleId: invoice?.saleId,
        customerId: data.customerId,
        customerName: data.customerName.trim(),
        customerEmail: data.customerEmail?.trim() || '',
        customerPhone: data.customerPhone?.trim() || '',
        customerAddress: data.customerAddress?.trim() || '',
        issueDate: data.issueDate,
        dueDate: data.dueDate,
        items: data.items.map((item) => ({
          ...item,
          productName: item.productName.trim(),
          description: item.description?.trim() || '',
          quantity: Number(item.quantity),
          unitPrice: Number(item.unitPrice),
          discount: Number(item.discount || 0)
        })),
        subtotal: totals.subtotal,
        discountAmount: totals.discountAmount,
        discountPercentage: Number(data.discountPercentage || 0),
        taxAmount: totals.taxAmount,
        taxPercentage: Number(data.taxPercentage || 0),
        totalAmount: totals.totalAmount,
        status: data.status,
        paidAmount: invoice?.paidAmount || 0,
        createdBy: 'current-user', // In real app, get from auth context
        notes: data.notes?.trim() || '',
        terms: data.terms?.trim() || '',
        footerText: data.footerText?.trim() || ''
      };

      let savedInvoice: Invoice;
      if (invoice) {
        savedInvoice = await invoiceService.updateInvoice(invoice.id, invoiceData);
        toast.success('Invoice updated successfully');
      } else {
        savedInvoice = await invoiceService.createManualInvoice(invoiceData);
        toast.success('Invoice created successfully');
      }

      onSave(savedInvoice);
    } catch (error: any) {
      const errorMessage = error?.message || 'Failed to save invoice';
      toast.error(errorMessage);
      console.error('Invoice save error:', error);
    } finally {
      setLoading(false);
    }
  };

  const addNewItem = () => {
    append({
      id: Date.now().toString(),
      productName: '',
      description: '',
      quantity: 1,
      unitPrice: 0,
      discount: 0,
      total: 0
    });
  };

  const selectProduct = (itemIndex: number, productId: string) => {
    const product = products.find((p) => p.id === productId);
    if (product) {
      setValue(`items.${itemIndex}.productId`, product.id);
      setValue(`items.${itemIndex}.productName`, product.name);
      setValue(`items.${itemIndex}.productSku`, product.sku);
      setValue(`items.${itemIndex}.unitPrice`, product.sellingPrice);
      setValue(`items.${itemIndex}.description`, product.description || product.name);
    }
  };

  const selectCustomer = (customerId: string) => {
    const customer = customers.find((c) => c.id === customerId);
    if (customer) {
      setValue('customerId', customer.id);
      setValue('customerName', customer.name);
      setValue('customerEmail', customer.email || '');
      setValue('customerPhone', customer.phone);
      setValue('customerAddress', customer.address || '');
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Customer Information */}
      <Card>
        <CardHeader>
          <CardTitle>Customer Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customer-select">Select Customer</Label>
              <Select onValueChange={selectCustomer}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose existing customer..." />
                </SelectTrigger>
                <SelectContent>
                  {customers.map((customer) =>
                  <SelectItem key={customer.id} value={customer.id}>
                      {customer.name} - {customer.phone}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customerName">Customer Name *</Label>
              <Input
                id="customerName"
                {...register('customerName', {
                  required: 'Customer name is required',
                  minLength: { value: 2, message: 'Customer name must be at least 2 characters' },
                  maxLength: { value: 100, message: 'Customer name must be less than 100 characters' }
                })}
                className={errors.customerName ? 'border-red-500' : ''}
                placeholder="Enter customer name" />


              {errors.customerName &&
              <p className="text-sm text-red-600">{errors.customerName.message}</p>
              }
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerPhone">Phone</Label>
              <Input
                id="customerPhone"
                {...register('customerPhone', {
                  validate: (value) => !value || validateUSAStandards.phoneNumber(value).isValid || 'Invalid phone number format'
                })}
                placeholder="(555) 123-4567"
                className={errors.customerPhone ? 'border-red-500' : ''} />

              {errors.customerPhone &&
              <p className="text-sm text-red-600">{errors.customerPhone.message}</p>
              }
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customerEmail">Email</Label>
              <Input
                id="customerEmail"
                type="email"
                {...register('customerEmail', {
                  validate: (value) => !value || validators.email(value).isValid || 'Invalid email format'
                })}
                placeholder="customer@email.com"
                className={errors.customerEmail ? 'border-red-500' : ''} />

              {errors.customerEmail &&
              <p className="text-sm text-red-600">{errors.customerEmail.message}</p>
              }
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerAddress">Address</Label>
              <Input id="customerAddress" {...register('customerAddress')} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoice Details */}
      <Card>
        <CardHeader>
          <CardTitle>Invoice Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Issue Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !watch('issueDate') && "text-muted-foreground"
                    )}>

                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {watch('issueDate') ? format(watch('issueDate'), "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={watch('issueDate')}
                    onSelect={(date) => date && setValue('issueDate', date)}
                    initialFocus />

                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Due Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !watch('dueDate') && "text-muted-foreground"
                    )}>

                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {watch('dueDate') ? format(watch('dueDate'), "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={watch('dueDate')}
                    onSelect={(date) => date && setValue('dueDate', date)}
                    initialFocus />

                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={watch('status')} onValueChange={(value) => setValue('status', value as Invoice['status'])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoice Items */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Invoice Items</CardTitle>
            <Button type="button" onClick={addNewItem} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Item
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product/Service</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Qty</TableHead>
                  <TableHead>Unit Price</TableHead>
                  <TableHead>Discount</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead className="w-[50px]">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fields.map((field, index) =>
                <TableRow key={field.id}>
                    <TableCell>
                      <div className="space-y-2">
                        <Select onValueChange={(value) => selectProduct(index, value)}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select product..." />
                          </SelectTrigger>
                          <SelectContent>
                            {products.map((product) =>
                          <SelectItem key={product.id} value={product.id}>
                                {product.name} - ${product.sellingPrice}
                              </SelectItem>
                          )}
                          </SelectContent>
                        </Select>
                        <Input
                        {...register(`items.${index}.productName`, {
                          required: 'Product name is required',
                          minLength: { value: 2, message: 'Product name must be at least 2 characters' }
                        })}
                        placeholder="Or enter product name..."
                        className={`text-sm ${errors.items?.[index]?.productName ? 'border-red-500' : ''}`} />

                        {errors.items?.[index]?.productName &&
                      <p className="text-xs text-red-600 mt-1">{errors.items[index].productName?.message}</p>
                      }

                      </div>
                    </TableCell>
                    <TableCell>
                      <Input
                      {...register(`items.${index}.description`, {
                        maxLength: { value: 200, message: 'Description must be less than 200 characters' }
                      })}
                      placeholder="Description..."
                      className={`text-sm ${errors.items?.[index]?.description ? 'border-red-500' : ''}`} />

                      {errors.items?.[index]?.description &&
                    <p className="text-xs text-red-600 mt-1">{errors.items[index].description?.message}</p>
                    }

                    </TableCell>
                    <TableCell>
                      <Input
                      type="number"
                      {...register(`items.${index}.quantity`, {
                        required: 'Quantity is required',
                        min: { value: 1, message: 'Minimum quantity is 1' },
                        max: { value: 99999, message: 'Quantity too high' },
                        validate: {
                          integer: (value) => Number.isInteger(Number(value)) || 'Quantity must be a whole number'
                        }
                      })}
                      className={`w-20 text-sm ${errors.items?.[index]?.quantity ? 'border-red-500' : ''}`} />

                      {errors.items?.[index]?.quantity &&
                    <p className="text-xs text-red-600 mt-1">{errors.items[index].quantity?.message}</p>
                    }

                    </TableCell>
                    <TableCell>
                      <Input
                      type="number"
                      step="0.01"
                      {...register(`items.${index}.unitPrice`, {
                        required: 'Unit price is required',
                        min: { value: 0, message: 'Price must be positive' },
                        max: { value: 999999.99, message: 'Price too high' },
                        validate: {
                          decimal: (value) => {
                            const str = value.toString();
                            const decimalPart = str.split('.')[1];
                            return !decimalPart || decimalPart.length <= 2 || 'Maximum 2 decimal places allowed';
                          }
                        }
                      })}
                      className={`w-24 text-sm ${errors.items?.[index]?.unitPrice ? 'border-red-500' : ''}`} />

                      {errors.items?.[index]?.unitPrice &&
                    <p className="text-xs text-red-600 mt-1">{errors.items[index].unitPrice?.message}</p>
                    }

                    </TableCell>
                    <TableCell>
                      <Input
                      type="number"
                      step="0.01"
                      {...register(`items.${index}.discount`, {
                        min: { value: 0, message: 'Discount cannot be negative' },
                        validate: {
                          lessThanTotal: (value, formValues) => {
                            const quantity = formValues.items?.[index]?.quantity || 0;
                            const unitPrice = formValues.items?.[index]?.unitPrice || 0;
                            const total = quantity * unitPrice;
                            return !value || value <= total || 'Discount cannot exceed item total';
                          }
                        }
                      })}
                      className={`w-24 text-sm ${errors.items?.[index]?.discount ? 'border-red-500' : ''}`} />

                      {errors.items?.[index]?.discount &&
                    <p className="text-xs text-red-600 mt-1">{errors.items[index].discount?.message}</p>
                    }

                    </TableCell>
                    <TableCell>
                      <div className="font-medium">
                        ${watchedItems[index]?.total?.toFixed(2) || '0.00'}
                      </div>
                    </TableCell>
                    <TableCell>
                      {fields.length > 1 &&
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => remove(index)}
                      className="text-red-600 hover:text-red-800">

                          <Trash2 className="h-4 w-4" />
                        </Button>
                    }
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Totals and Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Totals & Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="discountPercentage">Discount (%)</Label>
                  <Input
                    id="discountPercentage"
                    type="number"
                    step="0.01"
                    {...register('discountPercentage', {
                      min: { value: 0, message: 'Discount cannot be negative' },
                      max: { value: 100, message: 'Discount cannot exceed 100%' }
                    })}
                    className={errors.discountPercentage ? 'border-red-500' : ''} />

                  {errors.discountPercentage &&
                  <p className="text-sm text-red-600 mt-1">{errors.discountPercentage.message}</p>
                  }

                </div>
                <div className="space-y-2">
                  <Label htmlFor="taxPercentage">Tax (%)</Label>
                  <Input
                    id="taxPercentage"
                    type="number"
                    step="0.01"
                    {...register('taxPercentage', {
                      min: { value: 0, message: 'Tax cannot be negative' },
                      max: { value: 100, message: 'Tax cannot exceed 100%' }
                    })}
                    className={errors.taxPercentage ? 'border-red-500' : ''} />

                  {errors.taxPercentage &&
                  <p className="text-sm text-red-600 mt-1">{errors.taxPercentage.message}</p>
                  }

                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  {...register('notes')}
                  placeholder="Additional notes for this invoice..."
                  rows={3} />

              </div>
            </div>

            <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>${totals.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>Discount ({watchedDiscountPercentage}%):</span>
                <span>-${totals.discountAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>Tax ({watchedTaxPercentage}%):</span>
                <span>${totals.taxAmount.toFixed(2)}</span>
              </div>
              <hr className="border-gray-300" />
              <div className="flex justify-between font-semibold text-lg">
                <span>Total Amount:</span>
                <span>${totals.totalAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="terms">Payment Terms</Label>
              <Textarea
                id="terms"
                {...register('terms')}
                placeholder="Payment terms and conditions..."
                rows={2} />

            </div>
            <div className="space-y-2">
              <Label htmlFor="footerText">Footer Text</Label>
              <Textarea
                id="footerText"
                {...register('footerText')}
                placeholder="Footer message..."
                rows={2} />

            </div>
          </div>
        </CardContent>
      </Card>

      {/* Form Actions */}
      <div className="flex items-center justify-end space-x-4 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          <X className="h-4 w-4 mr-2" />
          Cancel
        </Button>
        <Button type="submit" disabled={loading}>
          <Save className="h-4 w-4 mr-2" />
          {loading ? 'Saving...' : invoice ? 'Update Invoice' : 'Create Invoice'}
        </Button>
      </div>
    </form>);

};

export default InvoiceForm;