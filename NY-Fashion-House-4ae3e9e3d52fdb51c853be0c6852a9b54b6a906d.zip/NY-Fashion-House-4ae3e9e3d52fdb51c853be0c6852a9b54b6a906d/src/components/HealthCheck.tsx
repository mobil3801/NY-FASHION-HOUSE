import { useEffect } from 'react';

interface HealthCheckProps {
  onHealthCheck?: (status: 'healthy' | 'unhealthy') => void;
}

const HealthCheck: React.FC<HealthCheckProps> = ({ onHealthCheck }) => {
  useEffect(() => {
    const performHealthCheck = async () => {
      try {
        // Basic health checks
        const checks = {
          localStorage: (() => {
            try {
              const test = 'health-check-test';
              localStorage.setItem(test, test);
              localStorage.removeItem(test);
              return true;
            } catch {
              return false;
            }
          })(),

          sessionStorage: (() => {
            try {
              const test = 'health-check-test';
              sessionStorage.setItem(test, test);
              sessionStorage.removeItem(test);
              return true;
            } catch {
              return false;
            }
          })(),

          fetch: (() => {
            try {
              return typeof fetch === 'function';
            } catch {
              return false;
            }
          })(),

          promises: (() => {
            try {
              return typeof Promise === 'function';
            } catch {
              return false;
            }
          })()
        };

        const healthyChecks = Object.values(checks).filter(Boolean).length;
        const totalChecks = Object.keys(checks).length;
        const healthStatus = healthyChecks === totalChecks ? 'healthy' : 'unhealthy';

        console.log('[Health Check]', {
          status: healthStatus,
          checks,
          score: `${healthyChecks}/${totalChecks}`,
          timestamp: new Date().toISOString()
        });

        onHealthCheck?.(healthStatus);
      } catch (error) {
        console.error('[Health Check Failed]', error);
        onHealthCheck?.('unhealthy');
      }
    };

    performHealthCheck();
  }, [onHealthCheck]);

  return null; // This component doesn't render anything
};

export default HealthCheck;