import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, DollarSign, TrendingUp, ShoppingBag } from "lucide-react";
import { Customer } from "@/types/customer";

interface CustomerStatsProps {
  customers: Customer[];
}

const CustomerStats = ({ customers }: CustomerStatsProps) => {
  const totalCustomers = customers.length;
  const activeCustomers = customers.filter((c) => c.status === 'active').length;
  const totalRevenue = customers.reduce((sum, c) => sum + c.totalSpent, 0);
  const averageOrderValue = totalCustomers > 0 ? totalRevenue / customers.reduce((sum, c) => sum + c.totalPurchases, 0) : 0;

  const stats = [
  {
    title: "Total Customers",
    value: totalCustomers.toString(),
    icon: Users,
    color: "text-blue-600"
  },
  {
    title: "Active Customers",
    value: activeCustomers.toString(),
    icon: TrendingUp,
    color: "text-green-600"
  },
  {
    title: "Total Revenue",
    value: `$${totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
    icon: DollarSign,
    color: "text-yellow-600"
  },
  {
    title: "Avg. Order Value",
    value: `$${averageOrderValue.toFixed(2)}`,
    icon: ShoppingBag,
    color: "text-purple-600"
  }];


  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <Icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>);

      })}
    </div>);

};

export default CustomerStats;