
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Package, Eye, ShoppingCart } from 'lucide-react';
import { LowStockAlert } from '@/types/product';
import { productService } from '@/services/productService';
import { toast } from 'sonner';

interface LowStockAlertsProps {
  onViewProduct?: (productId: string) => void;
  maxAlerts?: number;
}

const LowStockAlerts: React.FC<LowStockAlertsProps> = ({
  onViewProduct,
  maxAlerts = 10
}) => {
  const [alerts, setAlerts] = useState<LowStockAlert[]>([]);
  const [loading, setLoading] = useState(true);

  const loadAlerts = async () => {
    try {
      const lowStockAlerts = await productService.getLowStockAlerts();
      setAlerts(lowStockAlerts.slice(0, maxAlerts));
    } catch (error) {
      toast.error('Failed to load low stock alerts');
      console.error('Error loading alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAlerts();

    // Refresh alerts every 5 minutes
    const interval = setInterval(loadAlerts, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [maxAlerts]);

  const getAlertSeverity = (alert: LowStockAlert) => {
    if (alert.currentStock === 0) {
      return { level: 'critical', color: 'bg-red-50 border-red-200 text-red-800' };
    }
    if (alert.currentStock <= alert.minStockLevel * 0.5) {
      return { level: 'high', color: 'bg-orange-50 border-orange-200 text-orange-800' };
    }
    return { level: 'medium', color: 'bg-yellow-50 border-yellow-200 text-yellow-800' };
  };

  const getSeverityIcon = (level: string) => {
    switch (level) {
      case 'critical':
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'high':
        return <AlertTriangle className="w-4 h-4 text-orange-600" />;
      default:
        return <Package className="w-4 h-4 text-yellow-600" />;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Low Stock Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[...Array(3)].map((_, i) =>
            <div key={i} className="animate-pulse">
                <div className="h-16 bg-gray-200 rounded-lg" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5" />
          Low Stock Alerts
          {alerts.length > 0 &&
          <Badge variant="secondary" className="ml-auto">
              {alerts.length}
            </Badge>
          }
        </CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ?
        <div className="text-center py-8">
            <Package className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600 font-medium">All products are well stocked!</p>
            <p className="text-sm text-gray-500">No low stock alerts at this time.</p>
          </div> :

        <div className="space-y-3">
            {alerts.map((alert) => {
            const severity = getAlertSeverity(alert);

            return (
              <Alert key={alert.id} className={severity.color}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      {getSeverityIcon(severity.level)}
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm">
                          {alert.productName}
                        </h4>
                        <AlertDescription className="text-xs mt-1">
                          {alert.currentStock === 0 ?
                        <span className="font-medium text-red-700">
                              Out of stock
                            </span> :

                        <>
                              <span className="font-medium">
                                {alert.currentStock} remaining
                              </span>
                              {' • '}
                              <span>
                                Min: {alert.minStockLevel}
                              </span>
                            </>
                        }
                        </AlertDescription>
                        <p className="text-xs text-gray-500 mt-1">
                          Alert created: {alert.createdAt.toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex gap-1">
                      {onViewProduct &&
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onViewProduct(alert.productId)}>

                          <Eye className="w-3 h-3" />
                        </Button>
                    }
                      <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        // In a real app, this might open a purchase order form
                        toast.info('Restock feature coming soon');
                      }}>

                        <ShoppingCart className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </Alert>);

          })}

            <div className="mt-4 pt-3 border-t">
              <Button
              variant="outline"
              size="sm"
              onClick={loadAlerts}
              className="w-full">

                Refresh Alerts
              </Button>
            </div>
          </div>
        }
      </CardContent>
    </Card>);

};

export default LowStockAlerts;