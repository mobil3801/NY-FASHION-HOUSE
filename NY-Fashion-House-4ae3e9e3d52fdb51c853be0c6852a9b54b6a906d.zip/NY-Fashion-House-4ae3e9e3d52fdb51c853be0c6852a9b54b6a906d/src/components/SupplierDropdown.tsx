import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw, AlertTriangle, Users, Plus } from 'lucide-react';
import { useSupplierList } from '@/hooks/useSupplierList';
import { SupplierErrorBoundary } from './SupplierErrorBoundary';
import { SupplierLoadingIndicator } from './SupplierLoadingIndicator';
import { toast } from 'sonner';

interface SupplierDropdownProps {
  value?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  error?: string;
  showRefreshButton?: boolean;
  showAddButton?: boolean;
  onAddSupplier?: () => void;
  className?: string;
}

const SupplierDropdownContent: React.FC<SupplierDropdownProps> = ({
  value,
  onValueChange,
  placeholder = "Select supplier",
  disabled = false,
  required = false,
  error,
  showRefreshButton = true,
  showAddButton = false,
  onAddSupplier,
  className
}) => {
  const {
    suppliers,
    isLoading,
    isError,
    error: fetchError,
    isRefetching,
    refresh,
    isEmpty,
    hasActiveSuppliers,
    activeSuppliers,
    totalCount
  } = useSupplierList({
    onError: (err) => {
      console.error('Supplier fetch error:', err);
      toast.error('Failed to load suppliers. Please try again.');
    },
    onSuccess: (data) => {
      console.log(`Loaded ${data.length} suppliers successfully`);
    }
  });

  const handleRefresh = async () => {
    try {
      await refresh();
      toast.success('Suppliers refreshed successfully');
    } catch (err) {
      console.error('Error refreshing suppliers:', err);
      toast.error('Failed to refresh suppliers');
    }
  };

  const getPlaceholderText = () => {
    if (isLoading) return "Loading suppliers...";
    if (isError) return "Error loading suppliers";
    if (isEmpty) return "No suppliers available";
    if (!hasActiveSuppliers) return "No active suppliers";
    return placeholder;
  };

  // Loading state
  if (isLoading) {
    return (
      <SupplierLoadingIndicator
        variant="dropdown"
        message="Fetching suppliers from database..."
        animated={true}
        className={className} />);


  }

  // Error state
  if (isError) {
    return (
      <div className={`space-y-2 ${className}`}>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span>Failed to load suppliers: {fetchError?.message || 'Unknown error'}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRefresh}
              disabled={isRefetching}
              className="h-6 w-6 p-0 ml-2">

              <RefreshCw className={`w-3 h-3 ${isRefetching ? 'animate-spin' : ''}`} />
            </Button>
          </AlertDescription>
        </Alert>
      </div>);

  }

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {showRefreshButton &&
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefetching}
            className="h-6 w-6 p-0"
            title="Refresh suppliers">

              <RefreshCw className={`w-3 h-3 ${isRefetching ? 'animate-spin' : ''}`} />
            </Button>
          }
          {showAddButton && onAddSupplier &&
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onAddSupplier}
            className="h-6 w-6 p-0"
            title="Add new supplier">

              <Plus className="w-3 h-3" />
            </Button>
          }
        </div>
        <div className="text-xs text-muted-foreground flex items-center gap-1">
          <Users className="w-3 h-3" />
          {totalCount} suppliers ({activeSuppliers.length} active)
        </div>
      </div>

      <Select
        value={value}
        onValueChange={onValueChange}
        disabled={disabled || isLoading}>

        <SelectTrigger className={error ? 'border-red-500' : ''}>
          <SelectValue placeholder={getPlaceholderText()} />
        </SelectTrigger>
        <SelectContent>
          {!hasActiveSuppliers ?
          <div className="p-3 text-sm text-center text-muted-foreground space-y-2">
              <div className="flex items-center justify-center gap-2">
                <Users className="w-4 h-4" />
                <span>No active suppliers found</span>
              </div>
              {showAddButton && onAddSupplier &&
            <Button
              variant="outline"
              size="sm"
              onClick={onAddSupplier}
              className="w-full">

                  <Plus className="w-3 h-3 mr-1" />
                  Add First Supplier
                </Button>
            }
            </div> :

          <>
              {activeSuppliers.map((supplier) =>
            <SelectItem key={supplier.id} value={supplier.id}>
                  <div className="flex items-center justify-between w-full">
                    <span>{supplier.name}</span>
                    {supplier.status !== 'active' &&
                <span className="text-xs text-muted-foreground ml-2">
                        ({supplier.status})
                      </span>
                }
                  </div>
                </SelectItem>
            )}
              
              {/* Separator for inactive suppliers if any */}
              {activeSuppliers.length > 0 && suppliers.length > activeSuppliers.length &&
            <>
                  <div className="px-2 py-1 text-xs text-muted-foreground border-t">
                    Inactive Suppliers
                  </div>
                  {suppliers.filter((s) => s.status !== 'active').map((supplier) =>
              <SelectItem key={supplier.id} value={supplier.id} disabled>
                      <div className="flex items-center justify-between w-full opacity-60">
                        <span>{supplier.name}</span>
                        <span className="text-xs text-muted-foreground ml-2">
                          ({supplier.status})
                        </span>
                      </div>
                    </SelectItem>
              )}
                </>
            }
            </>
          }
        </SelectContent>
      </Select>

      {error &&
      <p className="text-sm text-red-600">{error}</p>
      }

      {/* Helpful status messages */}
      {isEmpty && !isLoading &&
      <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            No suppliers found. {showAddButton ? 'Click the + button to add your first supplier.' : 'Please add suppliers first.'}
          </AlertDescription>
        </Alert>
      }
    </div>);

};

export const SupplierDropdown: React.FC<SupplierDropdownProps> = (props) => {
  return (
    <SupplierErrorBoundary onRetry={() => window.location.reload()}>
      <SupplierDropdownContent {...props} />
    </SupplierErrorBoundary>);

};

export default SupplierDropdown;