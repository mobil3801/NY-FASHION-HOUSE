import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { RefreshCw, Users, Database } from 'lucide-react';

interface SupplierLoadingIndicatorProps {
  variant?: 'dropdown' | 'list' | 'card' | 'inline';
  message?: string;
  showIcon?: boolean;
  animated?: boolean;
  className?: string;
}

export const SupplierLoadingIndicator: React.FC<SupplierLoadingIndicatorProps> = ({
  variant = 'inline',
  message = 'Loading suppliers...',
  showIcon = true,
  animated = true,
  className = ''
}) => {
  const baseClasses = `flex items-center gap-2 ${className}`;

  const renderIcon = () => {
    if (!showIcon) return null;

    return (
      <div className="flex items-center gap-1">
        {animated ?
        <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" /> :

        <Users className="w-4 h-4 text-muted-foreground" />
        }
        <Database className="w-3 h-3 text-muted-foreground opacity-60" />
      </div>);

  };

  switch (variant) {
    case 'dropdown':
      return (
        <div className={baseClasses}>
          <div className="space-y-2 w-full">
            <div className="flex items-center justify-between">
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-6 w-6 rounded" />
            </div>
            <Skeleton className="h-10 w-full" />
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground py-2">
              {renderIcon()}
              <span>{message}</span>
            </div>
          </div>
        </div>);


    case 'list':
      return (
        <div className={`space-y-3 ${className}`}>
          {[1, 2, 3, 4, 5].map((item) =>
          <div key={item} className="flex items-center space-x-3 p-2 border rounded">
              <Skeleton className="h-8 w-8 rounded-full" />
              <div className="space-y-1 flex-1">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
              <Skeleton className="h-8 w-16" />
            </div>
          )}
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground py-4">
            {renderIcon()}
            <span>{message}</span>
          </div>
        </div>);


    case 'card':
      return (
        <Card className={className}>
          <CardHeader>
            <div className="space-y-2">
              <Skeleton className="h-6 w-32" />
              <Skeleton className="h-4 w-48" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <Skeleton className="h-10" />
                <Skeleton className="h-10" />
              </div>
              <Skeleton className="h-20" />
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground py-2">
                {renderIcon()}
                <span>{message}</span>
              </div>
            </div>
          </CardContent>
        </Card>);


    case 'inline':
    default:
      return (
        <div className={baseClasses}>
          {renderIcon()}
          <span className="text-sm text-muted-foreground">{message}</span>
        </div>);

  }
};

export default SupplierLoadingIndicator;