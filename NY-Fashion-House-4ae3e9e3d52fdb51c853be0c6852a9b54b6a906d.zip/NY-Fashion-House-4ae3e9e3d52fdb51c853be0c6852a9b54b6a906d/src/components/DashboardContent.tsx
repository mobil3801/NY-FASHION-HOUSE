import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  ShoppingCart,
  Package,
  FileText,
  CreditCard,
  UserCheck,
  Settings,
  BarChart3 } from
'lucide-react';

const DashboardContent: React.FC = () => {
  const navigate = useNavigate();

  const quickActions = [
  {
    title: 'Customer Management',
    description: 'Manage customers and view purchase history',
    icon: Users,
    action: () => navigate('/customers'),
    color: 'bg-blue-500'
  },
  {
    title: 'Product Management',
    description: 'Add, edit, and organize your products',
    icon: Package,
    action: () => navigate('/products'),
    color: 'bg-green-500'
  },
  {
    title: 'Point of Sale',
    description: 'Process sales and transactions',
    icon: ShoppingCart,
    action: () => navigate('/pos'),
    color: 'bg-purple-500'
  },
  {
    title: 'Reports',
    description: 'View sales reports and analytics',
    icon: BarChart3,
    action: () => navigate('/reports'),
    color: 'bg-orange-500'
  }];


  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {quickActions.map((action, index) => {
            const IconComponent = action.icon;
            return (
              <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center space-x-2">
                    <div className={`p-2 rounded-lg ${action.color} text-white`}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                    <CardTitle className="text-sm font-medium">
                      {action.title}
                    </CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-xs text-muted-foreground mb-3">
                    {action.description}
                  </p>
                  <Button
                    size="sm"
                    className="w-full"
                    onClick={action.action}>

                    Open
                  </Button>
                </CardContent>
              </Card>);

          })}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-sm">New customer registered</div>
                <div className="text-xs text-muted-foreground">2 min ago</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">Sale completed - $125.50</div>
                <div className="text-xs text-muted-foreground">5 min ago</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">Product inventory updated</div>
                <div className="text-xs text-muted-foreground">15 min ago</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Payment Methods
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Cash</span>
                <span className="text-sm font-medium">45%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Credit Card</span>
                <span className="text-sm font-medium">35%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Digital Payment</span>
                <span className="text-sm font-medium">20%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

};

export default DashboardContent;