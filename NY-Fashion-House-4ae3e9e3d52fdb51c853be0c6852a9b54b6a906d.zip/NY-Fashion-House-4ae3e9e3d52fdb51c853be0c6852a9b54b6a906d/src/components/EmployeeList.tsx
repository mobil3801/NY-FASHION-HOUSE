import React, { useState } from 'react';
import { Employee } from '@/types/employee';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Users,
  UserPlus,
  Search,
  Edit,
  Trash2,
  Eye,
  Phone,
  Mail,
  MapPin } from
'lucide-react';

interface EmployeeListProps {
  employees: Employee[];
  onEditEmployee: (employee: Employee) => void;
  onDeleteEmployee: (id: string) => void;
  onViewEmployee: (employee: Employee) => void;
  onCreateEmployee: () => void;
}

const EmployeeList: React.FC<EmployeeListProps> = ({
  employees,
  onEditEmployee,
  onDeleteEmployee,
  onViewEmployee,
  onCreateEmployee
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');

  const filteredEmployees = employees.filter((employee) => {
    const matchesSearch =
    employee.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    employee.position.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesDepartment = selectedDepartment === 'all' || employee.department === selectedDepartment;

    return matchesSearch && matchesDepartment;
  });

  const departments = Array.from(new Set(employees.map((emp) => emp.department))).filter(Boolean);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':return 'bg-green-100 text-green-800';
      case 'inactive':return 'bg-red-100 text-red-800';
      case 'on_leave':return 'bg-yellow-100 text-yellow-800';
      default:return 'bg-gray-100 text-gray-800';
    }
  };

  const formatSalary = (salary: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(salary);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5 text-gray-600" />
          <h2 className="text-xl font-semibold text-gray-900">
            Employees ({filteredEmployees.length})
          </h2>
        </div>
        <Button onClick={onCreateEmployee} className="flex items-center gap-2">
          <UserPlus className="h-4 w-4" />
          Add Employee
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search employees..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10" />

        </div>
        <select
          value={selectedDepartment}
          onChange={(e) => setSelectedDepartment(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">

          <option value="all">All Departments</option>
          {departments.map((dept) =>
          <option key={dept} value={dept}>{dept}</option>
          )}
        </select>
      </div>

      {/* Employee Grid */}
      {filteredEmployees.length === 0 ?
      <Card>
          <CardContent className="py-12 text-center">
            <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No employees found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm || selectedDepartment !== 'all' ?
            'Try adjusting your filters' :
            'Get started by adding your first employee'
            }
            </p>
            {!searchTerm && selectedDepartment === 'all' &&
          <Button onClick={onCreateEmployee}>
                <UserPlus className="h-4 w-4 mr-2" />
                Add First Employee
              </Button>
          }
          </CardContent>
        </Card> :

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEmployees.map((employee) =>
        <Card key={employee.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={employee.photoUrl} alt={`${employee.firstName} ${employee.lastName}`} />
                    <AvatarFallback className="bg-blue-100 text-blue-600">
                      {employee.firstName[0]}{employee.lastName[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-lg truncate">
                      {employee.firstName} {employee.lastName}
                    </CardTitle>
                    <CardDescription className="truncate">
                      {employee.position}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge className={getStatusColor(employee.employmentStatus)}>
                      {employee.employmentStatus.replace('_', ' ').toUpperCase()}
                    </Badge>
                    <span className="text-sm font-medium text-gray-900">
                      {formatSalary(employee.salary)}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-3 w-3" />
                      <span className="truncate">{employee.department}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="h-3 w-3" />
                      <span className="truncate">{employee.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="h-3 w-3" />
                      <span className="truncate">{employee.phone}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t">
                    <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onViewEmployee(employee)}
                  className="flex-1">

                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                    <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEditEmployee(employee)}
                  className="flex-1">

                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onDeleteEmployee(employee.id)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50">

                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
        )}
        </div>
      }
    </div>);

};

export default EmployeeList;