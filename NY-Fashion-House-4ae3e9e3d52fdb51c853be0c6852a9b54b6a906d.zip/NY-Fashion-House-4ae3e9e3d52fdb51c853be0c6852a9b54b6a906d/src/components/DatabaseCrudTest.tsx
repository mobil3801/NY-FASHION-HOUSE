import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { AlertCircle, CheckCircle, Database, Plus, Edit, Trash2, Eye, RefreshCw } from 'lucide-react';

interface TestResult {
  operation: string;
  table: string;
  status: 'success' | 'error' | 'pending';
  message: string;
  timestamp: string;
}

const DatabaseCrudTest: React.FC = () => {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [testData, setTestData] = useState({
    product: {
      sku: `TEST-${Date.now()}`,
      name: 'Test Product',
      description: 'Test product for CRUD operations',
      category: 'Test Category',
      cost_price: 10.00,
      selling_price: 20.00,
      stock_level: 50,
      min_stock_level: 10,
      is_active: true
    },
    employee: {
      first_name: 'Test',
      last_name: 'Employee',
      email: `test.employee.${Date.now()}@company.com`,
      phone: '555-0123',
      position: 'Test Position',
      department: 'Test Department',
      salary: 50000,
      employment_status: 'active'
    },
    sales_transaction: {
      product_id: 1,
      product_name: 'Test Product',
      quantity_sold: 2,
      unit_price: 20.00,
      total_amount: 40.00,
      employee_id: 1,
      employee_name: 'Test Employee',
      notes: 'Test transaction for CRUD verification'
    }
  });

  const addTestResult = (result: Omit<TestResult, 'timestamp'>) => {
    const newResult: TestResult = {
      ...result,
      timestamp: new Date().toISOString()
    };
    setTestResults((prev) => [newResult, ...prev]);
  };

  // Test CREATE operations
  const testCreate = async (tableName: string, tableId: number, data: any) => {
    try {
      addTestResult({
        operation: 'CREATE',
        table: tableName,
        status: 'pending',
        message: 'Starting CREATE test...'
      });

      const { error } = await window.ezsite.apis.tableCreate(tableId, data);

      if (error) {
        addTestResult({
          operation: 'CREATE',
          table: tableName,
          status: 'error',
          message: `CREATE failed: ${error}`
        });
        return null;
      }

      addTestResult({
        operation: 'CREATE',
        table: tableName,
        status: 'success',
        message: 'CREATE operation successful'
      });
      return true;
    } catch (error) {
      addTestResult({
        operation: 'CREATE',
        table: tableName,
        status: 'error',
        message: `CREATE exception: ${error}`
      });
      return null;
    }
  };

  // Test READ operations
  const testRead = async (tableName: string, tableId: number) => {
    try {
      addTestResult({
        operation: 'READ',
        table: tableName,
        status: 'pending',
        message: 'Starting READ test...'
      });

      const { data, error } = await window.ezsite.apis.tablePage(tableId, {
        PageNo: 1,
        PageSize: 10,
        OrderByField: 'id',
        IsAsc: false,
        Filters: []
      });

      if (error) {
        addTestResult({
          operation: 'READ',
          table: tableName,
          status: 'error',
          message: `READ failed: ${error}`
        });
        return null;
      }

      addTestResult({
        operation: 'READ',
        table: tableName,
        status: 'success',
        message: `READ successful - found ${data?.List?.length || 0} records`
      });
      return data?.List || [];
    } catch (error) {
      addTestResult({
        operation: 'READ',
        table: tableName,
        status: 'error',
        message: `READ exception: ${error}`
      });
      return null;
    }
  };

  // Test UPDATE operations
  const testUpdate = async (tableName: string, tableId: number, recordId: number, updateData: any) => {
    try {
      addTestResult({
        operation: 'UPDATE',
        table: tableName,
        status: 'pending',
        message: 'Starting UPDATE test...'
      });

      const { error } = await window.ezsite.apis.tableUpdate(tableId, {
        id: recordId,
        ...updateData
      });

      if (error) {
        addTestResult({
          operation: 'UPDATE',
          table: tableName,
          status: 'error',
          message: `UPDATE failed: ${error}`
        });
        return null;
      }

      addTestResult({
        operation: 'UPDATE',
        table: tableName,
        status: 'success',
        message: 'UPDATE operation successful'
      });
      return true;
    } catch (error) {
      addTestResult({
        operation: 'UPDATE',
        table: tableName,
        status: 'error',
        message: `UPDATE exception: ${error}`
      });
      return null;
    }
  };

  // Test DELETE operations
  const testDelete = async (tableName: string, tableId: number, recordId: number) => {
    try {
      addTestResult({
        operation: 'DELETE',
        table: tableName,
        status: 'pending',
        message: 'Starting DELETE test...'
      });

      const { error } = await window.ezsite.apis.tableDelete(tableId, { id: recordId });

      if (error) {
        addTestResult({
          operation: 'DELETE',
          table: tableName,
          status: 'error',
          message: `DELETE failed: ${error}`
        });
        return null;
      }

      addTestResult({
        operation: 'DELETE',
        table: tableName,
        status: 'success',
        message: 'DELETE operation successful'
      });
      return true;
    } catch (error) {
      addTestResult({
        operation: 'DELETE',
        table: tableName,
        status: 'error',
        message: `DELETE exception: ${error}`
      });
      return null;
    }
  };

  // Run comprehensive CRUD tests
  const runComprehensiveTest = async () => {
    setIsLoading(true);
    setTestResults([]);

    const tables = [
    { name: 'products', id: 38157, data: testData.product },
    { name: 'employees', id: 37818, data: testData.employee },
    { name: 'sales_transactions', id: 38156, data: testData.sales_transaction }];


    for (const table of tables) {
      console.log(`Testing CRUD operations for ${table.name}...`);

      // Test CREATE
      const createResult = await testCreate(table.name, table.id, table.data);
      if (!createResult) continue;

      // Test READ to get the created record
      const records = await testRead(table.name, table.id);
      if (!records || records.length === 0) continue;

      const createdRecord = records[0]; // Get the most recent record
      const recordId = createdRecord.id;

      // Test UPDATE
      const updateData = table.name === 'products' ?
      { name: 'Updated Test Product' } :
      table.name === 'employees' ?
      { first_name: 'Updated Test' } :
      { notes: 'Updated test transaction' };

      await testUpdate(table.name, table.id, recordId, updateData);

      // Test DELETE
      await testDelete(table.name, table.id, recordId);

      // Add a small delay between tests
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    // Test notifications UPDATE (special case)
    await testNotificationsUpdate();

    setIsLoading(false);
  };

  // Test notifications UPDATE specifically
  const testNotificationsUpdate = async () => {
    try {
      addTestResult({
        operation: 'UPDATE',
        table: 'notifications',
        status: 'pending',
        message: 'Testing notifications UPDATE...'
      });

      // First try to read notifications
      const { data: notificationsData, error: readError } = await window.ezsite.apis.tablePage(38282, {
        PageNo: 1,
        PageSize: 1,
        OrderByField: 'id',
        IsAsc: false,
        Filters: []
      });

      if (readError) {
        addTestResult({
          operation: 'UPDATE',
          table: 'notifications',
          status: 'error',
          message: `Cannot read notifications: ${readError}`
        });
        return;
      }

      if (!notificationsData?.List || notificationsData.List.length === 0) {
        // Create a test notification first
        const { error: createError } = await window.ezsite.apis.tableCreate(38282, {
          user_id: 1,
          title: 'Test Notification',
          message: 'Test notification for UPDATE verification',
          type: 'create',
          related_table: 'test',
          related_id: 1,
          actor_id: 1,
          actor_name: 'Test User',
          is_read: false
        });

        if (createError) {
          addTestResult({
            operation: 'UPDATE',
            table: 'notifications',
            status: 'error',
            message: `Cannot create test notification: ${createError}`
          });
          return;
        }

        // Re-read to get the created notification
        const { data: newData, error: reReadError } = await window.ezsite.apis.tablePage(38282, {
          PageNo: 1,
          PageSize: 1,
          OrderByField: 'id',
          IsAsc: false,
          Filters: []
        });

        if (reReadError || !newData?.List?.[0]) {
          addTestResult({
            operation: 'UPDATE',
            table: 'notifications',
            status: 'error',
            message: 'Cannot find created notification'
          });
          return;
        }

        notificationsData.List = newData.List;
      }

      const notification = notificationsData.List[0];
      const { error: updateError } = await window.ezsite.apis.tableUpdate(38282, {
        id: notification.id,
        is_read: true,
        title: 'Updated Test Notification'
      });

      if (updateError) {
        addTestResult({
          operation: 'UPDATE',
          table: 'notifications',
          status: 'error',
          message: `Notifications UPDATE failed: ${updateError}`
        });
      } else {
        addTestResult({
          operation: 'UPDATE',
          table: 'notifications',
          status: 'success',
          message: 'Notifications UPDATE successful'
        });
      }
    } catch (error) {
      addTestResult({
        operation: 'UPDATE',
        table: 'notifications',
        status: 'error',
        message: `Notifications UPDATE exception: ${error}`
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'pending':
        return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      default:
        return <Database className="h-4 w-4 text-gray-400" />;
    }
  };

  const getOperationIcon = (operation: string) => {
    switch (operation) {
      case 'CREATE':
        return <Plus className="h-3 w-3" />;
      case 'READ':
        return <Eye className="h-3 w-3" />;
      case 'UPDATE':
        return <Edit className="h-3 w-3" />;
      case 'DELETE':
        return <Trash2 className="h-3 w-3" />;
      default:
        return <Database className="h-3 w-3" />;
    }
  };

  const clearResults = () => {
    setTestResults([]);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Database CRUD Operations Test
          </CardTitle>
          <CardDescription>
            Test CREATE, READ, UPDATE, DELETE operations for products, sales_transactions, employees, and notifications tables
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Button
              onClick={runComprehensiveTest}
              disabled={isLoading}
              className="flex items-center gap-2">

              {isLoading ?
              <RefreshCw className="h-4 w-4 animate-spin" /> :

              <Database className="h-4 w-4" />
              }
              Run CRUD Tests
            </Button>
            <Button
              variant="outline"
              onClick={clearResults}
              disabled={isLoading}>

              Clear Results
            </Button>
          </div>
          
          {testResults.length > 0 &&
          <div className="space-y-2 max-h-96 overflow-y-auto">
              <h3 className="font-semibold text-sm">Test Results:</h3>
              {testResults.map((result, index) =>
            <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(result.status)}
                    <Badge variant="outline" className="text-xs">
                      {getOperationIcon(result.operation)}
                      {result.operation}
                    </Badge>
                    <code className="text-xs bg-white px-1 rounded">{result.table}</code>
                    <span className="text-gray-600">{result.message}</span>
                  </div>
                  <span className="text-xs text-gray-400">
                    {new Date(result.timestamp).toLocaleTimeString()}
                  </span>
                </div>
            )}
            </div>
          }

          {testResults.length === 0 && !isLoading &&
          <div className="text-center py-8 text-gray-500">
              <Database className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No test results yet. Click "Run CRUD Tests" to start testing database operations.</p>
            </div>
          }
        </CardContent>
      </Card>
    </div>);

};

export default DatabaseCrudTest;