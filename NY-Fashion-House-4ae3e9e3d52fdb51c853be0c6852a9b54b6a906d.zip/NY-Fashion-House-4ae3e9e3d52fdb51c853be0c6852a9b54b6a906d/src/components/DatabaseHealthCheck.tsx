
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, CheckCircle, RefreshCw, Database, Wifi, WifiOff } from 'lucide-react';
import { productService } from '@/services/productService';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';

interface HealthCheckResult {
  isHealthy: boolean;
  connectionStatus: any;
  errorCount: number;
  lastError?: any;
  recommendations: string[];
}

const DatabaseHealthCheck: React.FC = () => {
  const [healthCheck, setHealthCheck] = useState<HealthCheckResult | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const performHealthCheck = async () => {
    setIsChecking(true);
    try {
      const result = await productService.performHealthCheck();
      setHealthCheck(result);
      setLastChecked(new Date());
    } catch (error) {
      enhancedErrorLoggingService.logErrorWithDetails(error as Error, {
        title: 'Health Check Error',
        action: 'Perform database health check',
        operation: 'performHealthCheck',
        severity: 'medium',
        category: 'database',
        service: 'DatabaseHealthCheck'
      });
    } finally {
      setIsChecking(false);
    }
  };

  const restoreConnection = async () => {
    setIsChecking(true);
    try {
      await productService.restoreConnection();
      await performHealthCheck(); // Re-check after restoration
    } catch (error) {
      enhancedErrorLoggingService.logErrorWithDetails(error as Error, {
        title: 'Connection Restoration Error',
        action: 'Restore database connection',
        operation: 'restoreConnection',
        severity: 'high',
        category: 'database',
        service: 'DatabaseHealthCheck'
      });
    } finally {
      setIsChecking(false);
    }
  };

  useEffect(() => {
    performHealthCheck();

    // Auto-check every 30 seconds
    const interval = setInterval(performHealthCheck, 30000);
    return () => clearInterval(interval);
  }, []);

  if (!healthCheck) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
          <span className="ml-2">Checking database health...</span>
        </CardContent>
      </Card>);

  }

  return (
    <Card className={`${healthCheck.isHealthy ? 'border-green-200' : 'border-red-200'}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="w-5 h-5" />
          Database Health Status
          <Badge variant={healthCheck.isHealthy ? 'default' : 'destructive'}>
            {healthCheck.isHealthy ? 'Healthy' : 'Issues Detected'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Connection Status */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2">
            {healthCheck.connectionStatus.isConnected ?
            <Wifi className="w-4 h-4 text-green-600" /> :

            <WifiOff className="w-4 h-4 text-red-600" />
            }
            <span className="font-medium">Connection</span>
          </div>
          <Badge variant={healthCheck.connectionStatus.isConnected ? 'default' : 'destructive'}>
            {healthCheck.connectionStatus.isConnected ? 'Connected' : 'Disconnected'}
          </Badge>
        </div>

        {/* Error Count */}
        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-600" />
            <span className="font-medium">Recent Errors</span>
          </div>
          <Badge variant={healthCheck.errorCount === 0 ? 'default' : 'secondary'}>
            {healthCheck.errorCount}
          </Badge>
        </div>

        {/* Last Error */}
        {healthCheck.lastError &&
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <h4 className="font-medium text-red-800 mb-2">Latest Error</h4>
            <p className="text-sm text-red-700 mb-2">{healthCheck.lastError.message}</p>
            <p className="text-xs text-red-600">
              Correlation ID: {healthCheck.lastError.correlationId}
            </p>
          </div>
        }

        {/* Recommendations */}
        {healthCheck.recommendations.length > 0 &&
        <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h4 className="font-medium text-yellow-800 mb-2">Recommendations</h4>
            <ul className="text-sm text-yellow-700 space-y-1">
              {healthCheck.recommendations.map((rec, index) =>
            <li key={index} className="flex items-start gap-2">
                  <span className="text-yellow-600">•</span>
                  <span>{rec}</span>
                </li>
            )}
            </ul>
          </div>
        }

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            onClick={performHealthCheck}
            disabled={isChecking}
            variant="outline"
            size="sm">

            {isChecking ?
            <RefreshCw className="w-4 h-4 animate-spin mr-2" /> :

            <RefreshCw className="w-4 h-4 mr-2" />
            }
            Recheck
          </Button>
          
          {!healthCheck.connectionStatus.isConnected &&
          <Button
            onClick={restoreConnection}
            disabled={isChecking}
            size="sm">

              {isChecking ?
            <RefreshCw className="w-4 h-4 animate-spin mr-2" /> :

            <CheckCircle className="w-4 h-4 mr-2" />
            }
              Restore Connection
            </Button>
          }
        </div>

        {/* Status Footer */}
        <div className="text-xs text-gray-500 pt-2 border-t">
          {lastChecked &&
          <p>Last checked: {lastChecked.toLocaleTimeString()}</p>
          }
          <p>Failure count: {healthCheck.connectionStatus.failureCount}</p>
        </div>
      </CardContent>
    </Card>);

};

export default DatabaseHealthCheck;