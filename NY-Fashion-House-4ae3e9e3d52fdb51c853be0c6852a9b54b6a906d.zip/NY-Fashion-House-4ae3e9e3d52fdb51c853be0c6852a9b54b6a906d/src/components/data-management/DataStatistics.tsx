
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { RefreshCw, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Database, Users, Package, FileText, DollarSign } from 'lucide-react';
import { toast } from 'sonner';

interface DataStatisticsProps {}

interface EntityStats {
  type: string;
  label: string;
  icon: React.ReactNode;
  count: number;
  healthScore: number;
  trend: 'up' | 'down' | 'stable';
  issues: string[];
}

const DataStatistics: React.FC<DataStatisticsProps> = () => {
  const [stats, setStats] = useState<EntityStats[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  // Load statistics
  const loadStatistics = async () => {
    try {
      setIsLoading(true);

      // In a real implementation, you would fetch from your API
      // const { data: healthMetrics, error } = await window.ezsite.apis.tablePage('data_health_metrics', {
      //   PageNo: 1,
      //   PageSize: 100,
      //   OrderByField: 'entity_type',
      //   IsAsc: true,
      //   Filters: []
      // });

      // Mock data for demonstration
      const mockStats: EntityStats[] = [
      {
        type: 'customers',
        label: 'Customers',
        icon: <Users className="h-5 w-5" />,
        count: 1247,
        healthScore: 95,
        trend: 'up',
        issues: ['3 duplicate records', '12 missing email addresses']
      },
      {
        type: 'products',
        label: 'Products',
        icon: <Package className="h-5 w-5" />,
        count: 892,
        healthScore: 78,
        trend: 'stable',
        issues: ['45 low stock items', '8 missing categories', '23 invalid prices']
      },
      {
        type: 'employees',
        label: 'Employees',
        icon: <Users className="h-5 w-5" />,
        count: 156,
        healthScore: 92,
        trend: 'up',
        issues: ['2 incomplete profiles', '5 missing hire dates']
      },
      {
        type: 'invoices',
        label: 'Invoices',
        icon: <FileText className="h-5 w-5" />,
        count: 3421,
        healthScore: 88,
        trend: 'up',
        issues: ['67 overdue invoices', '12 duplicate invoice numbers']
      },
      {
        type: 'sales',
        label: 'Sales',
        icon: <DollarSign className="h-5 w-5" />,
        count: 5643,
        healthScore: 85,
        trend: 'down',
        issues: ['134 unreconciled transactions', '28 missing customer data']
      },
      {
        type: 'suppliers',
        label: 'Suppliers',
        icon: <Database className="h-5 w-5" />,
        count: 89,
        healthScore: 90,
        trend: 'stable',
        issues: ['4 inactive suppliers', '7 missing contact info']
      }];


      setStats(mockStats);
      setLastUpdated(new Date());

      // Update health metrics in database
      for (const stat of mockStats) {
        const healthData = {
          entity_type: stat.type,
          total_records: stat.count,
          duplicate_records: Math.floor(Math.random() * 10),
          incomplete_records: Math.floor(Math.random() * 20),
          orphaned_records: Math.floor(Math.random() * 5),
          last_updated: new Date().toISOString(),
          health_score: stat.healthScore
        };

        // Insert health metrics
        const { error } = await window.ezsite.apis.tableCreate('data_health_metrics', healthData);
        if (error) {
          console.warn('Failed to update health metrics for', stat.type, error);
        }
      }

    } catch (error) {
      console.error('Error loading statistics:', error);
      toast.error('Failed to load data statistics');
    } finally {
      setIsLoading(false);
    }
  };

  // Load statistics on component mount
  useEffect(() => {
    loadStatistics();
  }, []);

  // Get health score color
  const getHealthScoreColor = (score: number): string => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  // Get health score variant
  const getHealthScoreVariant = (score: number): "default" | "secondary" | "destructive" | "outline" => {
    if (score >= 90) return 'default';
    if (score >= 70) return 'secondary';
    return 'destructive';
  };

  // Calculate overall health score
  const overallHealthScore = stats.length > 0 ?
  Math.round(stats.reduce((sum, stat) => sum + stat.healthScore, 0) / stats.length) :
  0;

  return (
    <div className="space-y-6">
      {/* Overall Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Records</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.reduce((sum, stat) => sum + stat.count, 0).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              Across all entities
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Health Score</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getHealthScoreColor(overallHealthScore)}`}>
              {overallHealthScore}%
            </div>
            <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
              <div
                className="bg-blue-600 h-1.5 rounded-full transition-all duration-500"
                style={{ width: `${overallHealthScore}%` }} />

            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Data Issues</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {stats.reduce((sum, stat) => sum + stat.issues.length, 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              Issues detected
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Last Updated</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {lastUpdated.toLocaleTimeString()}
            </div>
            <p className="text-xs text-muted-foreground">
              {lastUpdated.toLocaleDateString()}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Entity Statistics */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Entity Health Overview</CardTitle>
            <CardDescription>
              Data quality and health metrics for all entities
            </CardDescription>
          </div>
          <Button
            onClick={loadStatistics}
            disabled={isLoading}
            variant="outline"
            size="sm">

            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {stats.map((stat) =>
            <Card key={stat.type} className="relative overflow-hidden">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <div className="flex items-center gap-2">
                    {stat.icon}
                    <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
                  </div>
                  <div className="flex items-center gap-1">
                    {stat.trend === 'up' && <TrendingUp className="h-3 w-3 text-green-500" />}
                    {stat.trend === 'down' && <TrendingDown className="h-3 w-3 text-red-500" />}
                    <Badge variant={getHealthScoreVariant(stat.healthScore)}>
                      {stat.healthScore}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold">{stat.count.toLocaleString()}</span>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>Health Score</span>
                        <span className={getHealthScoreColor(stat.healthScore)}>
                          {stat.healthScore}%
                        </span>
                      </div>
                      <Progress value={stat.healthScore} className="h-1.5" />
                    </div>
                    
                    {stat.issues.length > 0 &&
                  <div className="space-y-1">
                        <span className="text-xs font-medium text-orange-600">Issues:</span>
                        <div className="space-y-0.5">
                          {stat.issues.slice(0, 2).map((issue, index) =>
                      <div key={index} className="text-xs text-gray-600 flex items-center gap-1">
                              <AlertTriangle className="h-3 w-3 text-orange-500" />
                              {issue}
                            </div>
                      )}
                          {stat.issues.length > 2 &&
                      <div className="text-xs text-gray-500">
                              +{stat.issues.length - 2} more issues
                            </div>
                      }
                        </div>
                      </div>
                  }
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default DataStatistics;