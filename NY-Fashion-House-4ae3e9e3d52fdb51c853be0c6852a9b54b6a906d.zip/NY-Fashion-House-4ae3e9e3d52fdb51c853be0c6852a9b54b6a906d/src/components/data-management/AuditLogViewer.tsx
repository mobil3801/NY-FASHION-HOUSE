import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Search, Eye, RefreshCw, Download, User, Database, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { AuditService } from '@/services/auditService';

const AuditLogViewer: React.FC = () => {
  const [logs, setLogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAction, setFilterAction] = useState('');
  const [selectedLog, setSelectedLog] = useState<any>(null);

  // Load audit logs
  const loadAuditLogs = async () => {
    try {
      setIsLoading(true);
      const { logs: auditLogs, totalCount } = await AuditService.getAuditLogs(currentPage, pageSize);

      // Filter logs based on search term and action filter
      let filteredLogs = auditLogs;

      if (searchTerm) {
        filteredLogs = filteredLogs.filter((log) =>
        log.user_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.details?.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }

      if (filterAction) {
        filteredLogs = filteredLogs.filter((log) =>
        log.action?.toLowerCase().includes(filterAction.toLowerCase())
        );
      }

      setLogs(filteredLogs);
      setTotalPages(Math.ceil(totalCount / pageSize));
    } catch (error) {
      console.error('Error loading audit logs:', error);
      toast.error('Failed to load audit logs');

      // Generate mock data for demonstration
      const mockLogs = generateMockAuditLogs();
      setLogs(mockLogs);
      setTotalPages(Math.ceil(mockLogs.length / pageSize));
    } finally {
      setIsLoading(false);
    }
  };

  // Generate mock audit logs for demonstration
  const generateMockAuditLogs = () => {
    const actions = ['CREATE_USER', 'UPDATE_USER', 'DELETE_USER', 'CREATE_ROLE', 'UPDATE_ROLE', 'DELETE_ROLE', 'LOGIN', 'LOGOUT'];
    const users = ['admin@company.com', 'manager@company.com', 'user@company.com'];

    const logs = [];
    for (let i = 0; i < 50; i++) {
      const action = actions[Math.floor(Math.random() * actions.length)];
      const user = users[Math.floor(Math.random() * users.length)];

      logs.push({
        id: i + 1,
        user_id: Math.floor(Math.random() * 100) + 1,
        user_name: user.split('@')[0],
        action: action,
        details: `${action.toLowerCase().replace('_', ' ')} operation performed`,
        timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
        ip_address: `192.168.1.${Math.floor(Math.random() * 255)}`
      });
    }

    return logs.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  };

  // Load logs when dependencies change
  useEffect(() => {
    loadAuditLogs();
  }, [currentPage, pageSize]);

  // Apply filters when search term or filter action changes
  useEffect(() => {
    loadAuditLogs();
  }, [searchTerm, filterAction]);

  // Get action badge variant
  const getActionVariant = (action: string): "default" | "secondary" | "destructive" | "outline" => {
    if (action.includes('CREATE')) return 'default';
    if (action.includes('UPDATE')) return 'outline';
    if (action.includes('DELETE')) return 'destructive';
    return 'secondary';
  };

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch {
      return 'Invalid Date';
    }
  };

  // Export audit logs
  const exportAuditLogs = () => {
    try {
      if (logs.length === 0) {
        toast.warning('No audit logs to export');
        return;
      }

      const csvContent = [
      'Timestamp,User,Action,Details,IP Address',
      ...logs.map((log) => [
      formatTimestamp(log.timestamp),
      log.user_name || 'System',
      log.action,
      (log.details || '').replace(/"/g, '""'),
      log.ip_address || 'N/A'].
      map((field) => `"${field}"`).join(','))].
      join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `audit_logs_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success(`Exported ${logs.length} audit log entries`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export audit logs');
    }
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Audit Trail
              </CardTitle>
              <CardDescription>
                Complete log of all system activities and user actions
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button onClick={exportAuditLogs} variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button onClick={loadAuditLogs} variant="outline" size="sm" disabled={isLoading}>
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by user..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8" />

            </div>

            <Select value={filterAction || 'ALL'} onValueChange={(value) => setFilterAction(value === 'ALL' ? '' : value)}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Actions</SelectItem>
                <SelectItem value="CREATE">Create</SelectItem>
                <SelectItem value="UPDATE">Update</SelectItem>
                <SelectItem value="DELETE">Delete</SelectItem>
                <SelectItem value="LOGIN">Login</SelectItem>
                <SelectItem value="LOGOUT">Logout</SelectItem>
              </SelectContent>
            </Select>

            <Select value={pageSize.toString()} onValueChange={(value) => setPageSize(parseInt(value))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="25">25 per page</SelectItem>
                <SelectItem value="50">50 per page</SelectItem>
                <SelectItem value="100">100 per page</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Audit Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Recent Activity
            <Badge variant="secondary">{logs.length} entries</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[180px]">Timestamp</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead>IP Address</TableHead>
                  <TableHead className="w-[100px]">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ?
                <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2" />
                      Loading audit logs...
                    </TableCell>
                  </TableRow> :
                logs.length === 0 ?
                <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                      No audit logs found
                    </TableCell>
                  </TableRow> :

                logs.slice((currentPage - 1) * pageSize, currentPage * pageSize).map((log) =>
                <TableRow key={log.id}>
                      <TableCell className="font-mono text-xs">
                        {formatTimestamp(log.timestamp)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <User className="h-3 w-3 text-gray-400" />
                          <span className="text-sm">{log.user_name || 'System'}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getActionVariant(log.action)} className="font-mono">
                          {log.action}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-gray-600">{log.details}</span>
                      </TableCell>
                      <TableCell>
                        <span className="font-mono text-xs text-gray-500">{log.ip_address || 'N/A'}</span>
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedLog(log)}>

                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle className="flex items-center gap-2">
                                Audit Log Details
                              </DialogTitle>
                              <DialogDescription>
                                {formatTimestamp(log.timestamp)}
                              </DialogDescription>
                            </DialogHeader>
                            {selectedLog &&
                        <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm font-medium">User</label>
                                    <div className="text-sm text-gray-600">
                                      {selectedLog.user_name || 'System'}
                                    </div>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium">Action</label>
                                    <div className="text-sm text-gray-600">
                                      <Badge variant={getActionVariant(selectedLog.action)}>
                                        {selectedLog.action}
                                      </Badge>
                                    </div>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium">IP Address</label>
                                    <div className="text-sm text-gray-600 font-mono">
                                      {selectedLog.ip_address || 'N/A'}
                                    </div>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium">User ID</label>
                                    <div className="text-sm text-gray-600">
                                      {selectedLog.user_id}
                                    </div>
                                  </div>
                                </div>
                                
                                <div>
                                  <label className="text-sm font-medium">Details</label>
                                  <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded-md">
                                    {selectedLog.details || 'No additional details'}
                                  </div>
                                </div>
                              </div>
                        }
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                )
                }
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 &&
          <div className="flex items-center justify-between mt-6">
              <p className="text-sm text-gray-600">
                Showing {(currentPage - 1) * pageSize + 1} to {Math.min(currentPage * pageSize, logs.length)} of {logs.length} results
              </p>
              <div className="flex gap-2">
                <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage <= 1}>

                  Previous
                </Button>
                <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage >= totalPages}>

                  Next
                </Button>
              </div>
            </div>
          }
        </CardContent>
      </Card>
    </div>);

};

export default AuditLogViewer;