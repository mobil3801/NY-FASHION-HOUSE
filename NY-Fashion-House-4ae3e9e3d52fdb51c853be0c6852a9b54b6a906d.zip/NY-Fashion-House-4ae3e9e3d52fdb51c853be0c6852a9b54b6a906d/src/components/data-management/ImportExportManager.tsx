
import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Download, Upload, FileText, AlertTriangle, CheckCircle, X, ChevronDown } from 'lucide-react';
import { toast } from 'sonner';
import { requestSizeManager, formatFileSize } from '@/utils/requestSizeManager';

interface ImportExportManagerProps {
  entityType: string;
  onImportComplete?: () => void;
}

interface ImportResult {
  success: number;
  failed: number;
  errors: string[];
}

const ImportExportManager: React.FC<ImportExportManagerProps> = ({
  entityType,
  onImportComplete
}) => {
  const [importDialog, setImportDialog] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle file selection
  const handleFileSelect = async (file: File) => {
    if (!file) return;

    // Validate file type
    const validTypes = ['.csv', '.xlsx', '.xls', '.json'];
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();

    if (!validTypes.includes(fileExtension)) {
      toast.error('Invalid file type. Please use CSV, Excel, or JSON files.');
      return;
    }

    // Check file size limits
    const maxFileSize = 50; // 50MB limit
    if (file.size > maxFileSize * 1024 * 1024) {
      toast.error(`File too large. Maximum size is ${maxFileSize}MB. Current: ${formatFileSize(file.size)}`);
      return;
    }

    // Warn for large files
    if (file.size > 10 * 1024 * 1024) {
      toast.info(`Processing large file: ${formatFileSize(file.size)}. This may take a while.`);
    }

    await processImport(file);
  };

  // Process import
  const processImport = async (file: File) => {
    try {
      setIsImporting(true);
      setImportProgress(0);
      setImportResult(null);

      // Read file content
      const fileContent = await readFileContent(file);
      let data: any[] = [];

      // Parse based on file type
      const fileExtension = file.name.split('.').pop()?.toLowerCase();

      if (fileExtension === 'csv') {
        data = parseCSV(fileContent);
      } else if (fileExtension === 'json') {
        data = JSON.parse(fileContent);
      } else if (fileExtension === 'xlsx' || fileExtension === 'xls') {
        // For Excel files, you would need a library like SheetJS
        toast.error('Excel import is not implemented yet');
        return;
      }

      // Validate data structure
      const validationResult = validateImportData(data, entityType);
      if (!validationResult.isValid) {
        toast.error(`Invalid data structure: ${validationResult.errors.join(', ')}`);
        return;
      }

      // Import data in optimized batches using request size manager
      const batchSize = Math.min(50, Math.ceil(1000 / Math.max(1, Object.keys(data[0] || {}).length))); // Adjust batch size based on record complexity
      let successCount = 0;
      let failedCount = 0;
      const errors: string[] = [];

      await requestSizeManager.processBulkOperation(
        data,
        async (batch) => {
          try {
            const batchResults = await importBatch(batch, entityType);
            successCount += batchResults.success;
            failedCount += batchResults.failed;
            errors.push(...batchResults.errors);
            return batchResults;
          } catch (error) {
            console.error('Batch import error:', error);
            failedCount += batch.length;
            errors.push(`Batch failed: ${error}`);
            return { success: 0, failed: batch.length, errors: [String(error)] };
          }
        },
        {
          chunkSize: batchSize,
          onProgress: (progress) => {
            setImportProgress(progress);
          },
          delay: 50 // Reduced delay for better performance
        }
      );

      // Log import operation
      const importData = {
        operation_type: 'import',
        entity_type: entityType,
        entity_ids: '', // Not applicable for imports
        operation_details: JSON.stringify({
          action: 'import',
          fileName: file.name,
          totalRecords: data.length,
          successCount,
          failedCount,
          timestamp: new Date().toISOString()
        }),
        user_id: 0,
        user_email: '',
        timestamp: new Date().toISOString(),
        status: failedCount === 0 ? 'completed' : 'completed_with_errors',
        error_message: errors.length > 0 ? errors.slice(0, 3).join('; ') : ''
      };

      const { error: logError } = await window.ezsite.apis.tableCreate(
        'data_operations',
        importData
      );

      if (logError) {
        console.warn('Failed to log import operation:', logError);
      }

      setImportResult({ success: successCount, failed: failedCount, errors });

      if (successCount > 0) {
        toast.success(`Successfully imported ${successCount} records`);
        onImportComplete?.();
      }

      if (failedCount > 0) {
        toast.warning(`${failedCount} records failed to import`);
      }

    } catch (error) {
      console.error('Import error:', error);
      toast.error('Import failed: ' + (error as Error).message);
      setImportResult({ success: 0, failed: 0, errors: [(error as Error).message] });
    } finally {
      setIsImporting(false);
    }
  };

  // Mock import batch function
  const importBatch = async (batch: any[], entityType: string): Promise<ImportResult> => {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, Math.random() * 500 + 200));

    // Mock results - in reality you'd call your API
    const success = batch.length - Math.floor(Math.random() * 3);
    const failed = batch.length - success;
    const errors = failed > 0 ? [`${failed} records had validation errors`] : [];

    return { success, failed, errors };
  };

  // Read file content
  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  };

  // Parse CSV content
  const parseCSV = (content: string): any[] => {
    const lines = content.split('\n').filter((line) => line.trim());
    if (lines.length < 2) return [];

    const headers = lines[0].split(',').map((h) => h.trim().replace(/"/g, ''));
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map((v) => v.trim().replace(/"/g, ''));
      const record: any = {};

      headers.forEach((header, index) => {
        record[header] = values[index] || '';
      });

      data.push(record);
    }

    return data;
  };

  // Validate import data
  const validateImportData = (data: any[], entityType: string): {isValid: boolean;errors: string[];} => {
    const errors: string[] = [];

    if (!Array.isArray(data)) {
      errors.push('Data must be an array');
      return { isValid: false, errors };
    }

    if (data.length === 0) {
      errors.push('No data to import');
      return { isValid: false, errors };
    }

    // Entity-specific validation
    const requiredFields: Record<string, string[]> = {
      customers: ['name', 'email'],
      products: ['name', 'price'],
      employees: ['name', 'email', 'position'],
      suppliers: ['name', 'contact_person'],
      invoices: ['customer_name', 'total_amount'],
      sales: ['total_amount', 'sale_date']
    };

    const required = requiredFields[entityType] || [];

    // Check first few records for required fields
    const sampleSize = Math.min(5, data.length);
    for (let i = 0; i < sampleSize; i++) {
      const record = data[i];
      for (const field of required) {
        if (!record.hasOwnProperty(field) || !record[field]) {
          errors.push(`Missing required field "${field}" in record ${i + 1}`);
        }
      }
    }

    return { isValid: errors.length === 0, errors };
  };

  // Handle drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  // Export templates
  const exportTemplate = () => {
    const templates: Record<string, any[]> = {
      customers: [
      { name: 'John Doe', email: 'john@example.com', phone: '555-1234', company: 'ACME Corp' }],

      products: [
      { name: 'Sample Product', sku: 'SKU-001', price: 99.99, category: 'Electronics', stock_quantity: 100 }],

      employees: [
      { name: 'Jane Smith', email: 'jane@company.com', position: 'Manager', department: 'Sales' }],

      suppliers: [
      { name: 'Supplier Inc', contact_person: 'Bob Johnson', email: 'bob@supplier.com', phone: '555-5678' }],

      invoices: [
      { invoice_number: 'INV-001', customer_name: 'Customer Name', total_amount: 1000, due_date: '2024-01-31' }],

      sales: [
      { sale_number: 'SALE-001', customer_name: 'Customer Name', total_amount: 500, sale_date: '2024-01-15', payment_method: 'Credit Card' }]

    };

    const template = templates[entityType] || [{ example: 'No template available' }];

    // Create CSV
    const headers = Object.keys(template[0]);
    const csvContent = [
    headers.join(','),
    ...template.map((row) =>
    headers.map((header) => row[header] || '').join(',')
    )].
    join('\n');

    // Download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${entityType}_template.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast.success(`Downloaded ${entityType} import template`);
  };

  return (
    <div className="flex items-center gap-2">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Import/Export
            <ChevronDown className="h-4 w-4 ml-2" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setImportDialog(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Import Data
          </DropdownMenuItem>
          <DropdownMenuItem onClick={exportTemplate}>
            <Download className="h-4 w-4 mr-2" />
            Download Template
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Import Dialog */}
      <Dialog open={importDialog} onOpenChange={setImportDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Import {entityType.charAt(0).toUpperCase() + entityType.slice(1)}</DialogTitle>
            <DialogDescription>
              Upload a CSV, Excel, or JSON file to import data. Make sure your data matches the expected format.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {!isImporting && !importResult &&
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragOver ?
              'border-blue-500 bg-blue-50' :
              'border-gray-300 hover:border-gray-400'}`
              }
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}>

                <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <div className="space-y-2">
                  <p className="text-lg font-medium">Drop your file here</p>
                  <p className="text-sm text-gray-600">or click to browse</p>
                  <p className="text-xs text-gray-500">
                    Supports CSV, Excel (.xlsx, .xls), and JSON files
                  </p>
                </div>
                <Button
                className="mt-4"
                onClick={() => fileInputRef.current?.click()}>

                  Choose File
                </Button>
                <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls,.json"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileSelect(file);
                }}
                className="hidden" />

              </div>
            }

            {isImporting &&
            <div className="space-y-4">
                <div className="text-center">
                  <div className="text-lg font-medium mb-2">Importing data...</div>
                  <div className="text-sm text-gray-600 mb-4">
                    Please wait while we process your file.
                  </div>
                  <Progress value={importProgress} className="h-2" />
                  <div className="text-xs text-gray-500 mt-2">
                    {Math.round(importProgress)}% complete
                  </div>
                </div>
              </div>
            }

            {importResult &&
            <div className="space-y-4">
                <div className="text-center">
                  <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-4" />
                  <div className="text-lg font-medium mb-2">Import Complete</div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="text-center pb-2">
                      <CardTitle className="text-2xl text-green-600">
                        {importResult.success}
                      </CardTitle>
                      <CardDescription>Successful</CardDescription>
                    </CardHeader>
                  </Card>
                  
                  <Card>
                    <CardHeader className="text-center pb-2">
                      <CardTitle className={`text-2xl ${
                    importResult.failed > 0 ? 'text-red-600' : 'text-gray-400'}`
                    }>
                        {importResult.failed}
                      </CardTitle>
                      <CardDescription>Failed</CardDescription>
                    </CardHeader>
                  </Card>
                </div>

                {importResult.errors.length > 0 &&
              <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      <div className="space-y-1">
                        <div className="font-medium">Import Errors:</div>
                        {importResult.errors.slice(0, 5).map((error, index) =>
                    <div key={index} className="text-sm">• {error}</div>
                    )}
                        {importResult.errors.length > 5 &&
                    <div className="text-sm">• And {importResult.errors.length - 5} more errors...</div>
                    }
                      </div>
                    </AlertDescription>
                  </Alert>
              }

                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => {
                  setImportDialog(false);
                  setImportResult(null);
                }}>
                    Close
                  </Button>
                  <Button onClick={() => {
                  setImportResult(null);
                  fileInputRef.current!.value = '';
                }}>
                    Import Another File
                  </Button>
                </div>
              </div>
            }
          </div>
        </DialogContent>
      </Dialog>
    </div>);

};

export default ImportExportManager;