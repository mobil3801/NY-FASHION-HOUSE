
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, CheckCircle, RefreshCw, Zap, Database, Users, Package, FileText } from 'lucide-react';
import { toast } from 'sonner';

interface ValidationIssue {
  id: string;
  type: 'duplicate' | 'incomplete' | 'invalid' | 'orphaned';
  entity: string;
  description: string;
  recordId: string;
  severity: 'high' | 'medium' | 'low';
  autoFixable: boolean;
}

interface CleanupTask {
  id: string;
  name: string;
  description: string;
  estimatedTime: string;
  affectedRecords: number;
  risk: 'low' | 'medium' | 'high';
}

const DataValidationTools: React.FC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [validationIssues, setValidationIssues] = useState<ValidationIssue[]>([]);
  const [cleanupTasks, setCleanupTasks] = useState<CleanupTask[]>([]);
  const [fixingIssues, setFixingIssues] = useState<Set<string>>(new Set());

  // Start validation scan
  const startValidationScan = async () => {
    try {
      setIsScanning(true);
      setScanProgress(0);
      setValidationIssues([]);

      const entities = ['customers', 'products', 'employees', 'suppliers', 'invoices', 'sales'];
      const totalSteps = entities.length;

      for (let i = 0; i < entities.length; i++) {
        const entity = entities[i];

        // Simulate scanning each entity
        await new Promise((resolve) => setTimeout(resolve, 800));

        // Generate mock validation issues
        const entityIssues = await scanEntityForIssues(entity);
        setValidationIssues((prev) => [...prev, ...entityIssues]);

        setScanProgress((i + 1) / totalSteps * 100);
      }

      // Generate cleanup tasks
      const tasks = generateCleanupTasks();
      setCleanupTasks(tasks);

      toast.success(`Validation scan complete. Found ${validationIssues.length} issues.`);

    } catch (error) {
      console.error('Validation scan error:', error);
      toast.error('Validation scan failed');
    } finally {
      setIsScanning(false);
    }
  };

  // Mock function to scan entity for issues
  const scanEntityForIssues = async (entity: string): Promise<ValidationIssue[]> => {
    const issues: ValidationIssue[] = [];
    const issueTypes = ['duplicate', 'incomplete', 'invalid', 'orphaned'] as const;

    // Generate random issues for demo
    const numIssues = Math.floor(Math.random() * 8) + 1;

    for (let i = 0; i < numIssues; i++) {
      const type = issueTypes[Math.floor(Math.random() * issueTypes.length)];

      issues.push({
        id: `${entity}-${type}-${i}`,
        type,
        entity,
        description: getIssueDescription(entity, type),
        recordId: `${entity.toUpperCase()}-${Math.floor(Math.random() * 1000)}`,
        severity: ['high', 'medium', 'low'][Math.floor(Math.random() * 3)] as any,
        autoFixable: type === 'duplicate' || type === 'incomplete'
      });
    }

    return issues;
  };

  // Get issue description
  const getIssueDescription = (entity: string, type: string): string => {
    const descriptions = {
      duplicate: {
        customers: 'Duplicate customer with same email address',
        products: 'Duplicate product with same SKU',
        employees: 'Duplicate employee with same email',
        suppliers: 'Duplicate supplier with same name',
        invoices: 'Duplicate invoice number',
        sales: 'Duplicate sale transaction'
      },
      incomplete: {
        customers: 'Missing required contact information',
        products: 'Missing product description or price',
        employees: 'Missing hire date or department',
        suppliers: 'Missing contact details',
        invoices: 'Missing customer or amount information',
        sales: 'Missing payment method or date'
      },
      invalid: {
        customers: 'Invalid email format',
        products: 'Invalid price value (negative or zero)',
        employees: 'Invalid hire date (future date)',
        suppliers: 'Invalid phone number format',
        invoices: 'Invalid due date (in the past)',
        sales: 'Invalid sale amount'
      },
      orphaned: {
        customers: 'Customer with no associated sales',
        products: 'Product not in any category',
        employees: 'Employee with invalid department',
        suppliers: 'Supplier with no products',
        invoices: 'Invoice with non-existent customer',
        sales: 'Sale with invalid product reference'
      }
    };

    return descriptions[type as keyof typeof descriptions]?.[entity as keyof typeof descriptions.duplicate] || 'Data integrity issue detected';
  };

  // Generate cleanup tasks
  const generateCleanupTasks = (): CleanupTask[] => {
    return [
    {
      id: 'remove-duplicates',
      name: 'Remove Duplicate Records',
      description: 'Identify and merge duplicate customer, product, and supplier records',
      estimatedTime: '15-30 minutes',
      affectedRecords: 45,
      risk: 'medium'
    },
    {
      id: 'fix-incomplete',
      name: 'Fix Incomplete Records',
      description: 'Fill in missing required fields where possible',
      estimatedTime: '5-10 minutes',
      affectedRecords: 23,
      risk: 'low'
    },
    {
      id: 'validate-references',
      name: 'Validate Data References',
      description: 'Check and fix broken foreign key references',
      estimatedTime: '20-40 minutes',
      affectedRecords: 18,
      risk: 'high'
    },
    {
      id: 'normalize-formats',
      name: 'Normalize Data Formats',
      description: 'Standardize phone numbers, addresses, and other formatted fields',
      estimatedTime: '10-15 minutes',
      affectedRecords: 156,
      risk: 'low'
    },
    {
      id: 'remove-orphaned',
      name: 'Remove Orphaned Records',
      description: 'Delete records that no longer have valid parent references',
      estimatedTime: '5-10 minutes',
      affectedRecords: 12,
      risk: 'medium'
    }];

  };

  // Auto-fix issues
  const autoFixIssues = async (issueIds: string[]) => {
    try {
      const newFixingIssues = new Set([...fixingIssues, ...issueIds]);
      setFixingIssues(newFixingIssues);

      // Simulate fixing issues
      for (const issueId of issueIds) {
        await new Promise((resolve) => setTimeout(resolve, 1000));

        // Log the fix operation
        const issue = validationIssues.find((i) => i.id === issueId);
        if (issue) {
          const fixData = {
            operation_type: 'data_cleanup',
            entity_type: issue.entity,
            entity_ids: issue.recordId,
            operation_details: JSON.stringify({
              action: 'auto_fix',
              issueType: issue.type,
              description: issue.description,
              timestamp: new Date().toISOString()
            }),
            user_id: 0,
            user_email: '',
            timestamp: new Date().toISOString(),
            status: 'completed',
            error_message: ''
          };

          const { error } = await window.ezsite.apis.tableCreate('data_operations', fixData);
          if (error) {
            console.warn('Failed to log fix operation:', error);
          }
        }
      }

      // Remove fixed issues
      setValidationIssues((prev) => prev.filter((issue) => !issueIds.includes(issue.id)));

      // Remove from fixing set
      const updatedFixingIssues = new Set(fixingIssues);
      issueIds.forEach((id) => updatedFixingIssues.delete(id));
      setFixingIssues(updatedFixingIssues);

      toast.success(`Fixed ${issueIds.length} issues automatically`);

    } catch (error) {
      console.error('Auto-fix error:', error);
      toast.error('Failed to auto-fix some issues');

      // Remove from fixing set on error
      const updatedFixingIssues = new Set(fixingIssues);
      issueIds.forEach((id) => updatedFixingIssues.delete(id));
      setFixingIssues(updatedFixingIssues);
    }
  };

  // Run cleanup task
  const runCleanupTask = async (task: CleanupTask) => {
    try {
      toast.info(`Starting cleanup task: ${task.name}`);

      // Log cleanup operation
      const cleanupData = {
        operation_type: 'data_cleanup',
        entity_type: 'multiple',
        entity_ids: '',
        operation_details: JSON.stringify({
          action: 'cleanup_task',
          taskId: task.id,
          taskName: task.name,
          affectedRecords: task.affectedRecords,
          timestamp: new Date().toISOString()
        }),
        user_id: 0,
        user_email: '',
        timestamp: new Date().toISOString(),
        status: 'completed',
        error_message: ''
      };

      const { error } = await window.ezsite.apis.tableCreate('data_operations', cleanupData);
      if (error) {
        console.warn('Failed to log cleanup operation:', error);
      }

      // Simulate cleanup
      await new Promise((resolve) => setTimeout(resolve, 2000));

      toast.success(`Cleanup task "${task.name}" completed successfully`);

    } catch (error) {
      console.error('Cleanup task error:', error);
      toast.error(`Cleanup task "${task.name}" failed`);
    }
  };

  const getIssueIcon = (type: string) => {
    switch (type) {
      case 'duplicate':return '👥';
      case 'incomplete':return '⚠️';
      case 'invalid':return '❌';
      case 'orphaned':return '🔗';
      default:return '⚡';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':return 'destructive';
      case 'medium':return 'secondary';
      case 'low':return 'outline';
      default:return 'outline';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'high':return 'text-red-600';
      case 'medium':return 'text-yellow-600';
      case 'low':return 'text-green-600';
      default:return 'text-gray-600';
    }
  };

  const autoFixableIssues = validationIssues.filter((issue) => issue.autoFixable);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Data Validation & Cleanup Tools
            </CardTitle>
            <CardDescription>
              Scan for data quality issues and perform automated cleanup tasks
            </CardDescription>
          </div>
          <Button
            onClick={startValidationScan}
            disabled={isScanning}
            variant="outline">

            {isScanning ?
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> :

            <Zap className="h-4 w-4 mr-2" />
            }
            {isScanning ? 'Scanning...' : 'Start Validation Scan'}
          </Button>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="issues" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="issues" className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Data Issues
              {validationIssues.length > 0 &&
              <Badge variant="destructive" className="ml-1">
                  {validationIssues.length}
                </Badge>
              }
            </TabsTrigger>
            <TabsTrigger value="cleanup" className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Cleanup Tasks
              {cleanupTasks.length > 0 &&
              <Badge variant="secondary" className="ml-1">
                  {cleanupTasks.length}
                </Badge>
              }
            </TabsTrigger>
          </TabsList>

          <TabsContent value="issues" className="space-y-4">
            {isScanning &&
            <Card>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Scanning data for issues...</div>
                        <div className="text-sm text-gray-600">
                          This may take a few minutes depending on your data size.
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold">{Math.round(scanProgress)}%</div>
                      </div>
                    </div>
                    <Progress value={scanProgress} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            }

            {!isScanning && validationIssues.length === 0 &&
            <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <CheckCircle className="h-12 w-12 mx-auto text-green-500 mb-4" />
                    <div className="text-lg font-medium mb-2">No Issues Found</div>
                    <div className="text-gray-600">
                      Your data appears to be clean, or you haven't run a scan yet.
                    </div>
                  </div>
                </CardContent>
              </Card>
            }

            {validationIssues.length > 0 &&
            <div className="space-y-4">
                {autoFixableIssues.length > 0 &&
              <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription className="flex items-center justify-between">
                      <span>
                        {autoFixableIssues.length} issues can be fixed automatically
                      </span>
                      <Button
                    size="sm"
                    onClick={() => autoFixIssues(autoFixableIssues.map((i) => i.id))}
                    disabled={fixingIssues.size > 0}>

                        {fixingIssues.size > 0 ?
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> :

                    <Zap className="h-4 w-4 mr-2" />
                    }
                        Auto-Fix All
                      </Button>
                    </AlertDescription>
                  </Alert>
              }

                <div className="space-y-2">
                  {validationIssues.map((issue) =>
                <Card key={issue.id} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <span className="text-lg">{getIssueIcon(issue.type)}</span>
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-medium capitalize">{issue.entity}</span>
                              <Badge variant={getSeverityColor(issue.severity) as any}>
                                {issue.severity}
                              </Badge>
                              <span className="text-sm text-gray-500">#{issue.recordId}</span>
                            </div>
                            <div className="text-sm text-gray-700">{issue.description}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {issue.autoFixable &&
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => autoFixIssues([issue.id])}
                        disabled={fixingIssues.has(issue.id)}>

                              {fixingIssues.has(issue.id) ?
                        <RefreshCw className="h-4 w-4 animate-spin" /> :

                        'Auto-Fix'
                        }
                            </Button>
                      }
                        </div>
                      </div>
                    </Card>
                )}
                </div>
              </div>
            }
          </TabsContent>

          <TabsContent value="cleanup" className="space-y-4">
            {cleanupTasks.length === 0 ?
            <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-8">
                    <Database className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <div className="text-lg font-medium mb-2">No Cleanup Tasks</div>
                    <div className="text-gray-600">
                      Run a validation scan to generate cleanup recommendations.
                    </div>
                  </div>
                </CardContent>
              </Card> :

            <div className="space-y-4">
                {cleanupTasks.map((task) =>
              <Card key={task.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-base">{task.name}</CardTitle>
                          <CardDescription>{task.description}</CardDescription>
                        </div>
                        <Button onClick={() => runCleanupTask(task)} size="sm">
                          Run Task
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <div className="text-gray-600">Estimated Time</div>
                          <div className="font-medium">{task.estimatedTime}</div>
                        </div>
                        <div>
                          <div className="text-gray-600">Affected Records</div>
                          <div className="font-medium">{task.affectedRecords}</div>
                        </div>
                        <div>
                          <div className="text-gray-600">Risk Level</div>
                          <div className={`font-medium ${getRiskColor(task.risk)}`}>
                            {task.risk.toUpperCase()}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
              )}
              </div>
            }
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>);

};

export default DataValidationTools;