
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ChevronDown, Trash2, Archive, Download, Upload, Copy, Edit, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { requestSizeManager } from '@/utils/requestSizeManager';

interface BulkOperationsProps {
  entityType: string;
  selectedItems: any[];
  onAction: (action: string, items: any[]) => Promise<void>;
  isLoading: boolean;
}

const BulkOperations: React.FC<BulkOperationsProps> = ({
  entityType,
  selectedItems,
  onAction,
  isLoading
}) => {
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    action: string;
    title: string;
    description: string;
    variant: 'default' | 'destructive';
  }>({
    open: false,
    action: '',
    title: '',
    description: '',
    variant: 'default'
  });

  const handleAction = (action: string) => {
    let title = '';
    let description = '';
    let variant: 'default' | 'destructive' = 'default';

    switch (action) {
      case 'delete':
        title = 'Delete Selected Items';
        description = `Are you sure you want to delete ${selectedItems.length} selected ${entityType}? This action cannot be undone.`;
        variant = 'destructive';
        break;
      case 'archive':
        title = 'Archive Selected Items';
        description = `Are you sure you want to archive ${selectedItems.length} selected ${entityType}? Archived items can be restored later.`;
        break;
      case 'activate':
        title = 'Activate Selected Items';
        description = `Are you sure you want to activate ${selectedItems.length} selected ${entityType}?`;
        break;
      case 'deactivate':
        title = 'Deactivate Selected Items';
        description = `Are you sure you want to deactivate ${selectedItems.length} selected ${entityType}?`;
        break;
      case 'duplicate':
        title = 'Duplicate Selected Items';
        description = `Are you sure you want to create duplicates of ${selectedItems.length} selected ${entityType}?`;
        break;
      case 'export':
        // Direct export without confirmation
        handleExport();
        return;
      default:
        return;
    }

    setConfirmDialog({
      open: true,
      action,
      title,
      description,
      variant
    });
  };

  const confirmAction = async () => {
    try {
      setConfirmDialog((prev) => ({ ...prev, open: false }));

      // Log the operation attempt
      const operationData = {
        operation_type: confirmDialog.action,
        entity_type: entityType,
        entity_ids: selectedItems.map((item) => item.id || item.ID).join(','),
        operation_details: JSON.stringify({
          action: confirmDialog.action,
          itemCount: selectedItems.length,
          timestamp: new Date().toISOString()
        }),
        user_id: 0, // Will be filled by backend
        user_email: '', // Will be filled by backend
        timestamp: new Date().toISOString(),
        status: 'initiated',
        error_message: ''
      };

      const { error: logError } = await window.ezsite.apis.tableCreate(
        'data_operations',
        operationData
      );

      if (logError) {
        console.warn('Failed to log operation:', logError);
      }

      // Process large operations in chunks to avoid request size limits
      if (selectedItems.length > 100) {
        toast.info(`Processing ${selectedItems.length} items in chunks...`);

        await requestSizeManager.processBulkOperation(
          selectedItems,
          async (chunk) => {
            await onAction(confirmDialog.action, chunk);
            return chunk;
          },
          {
            chunkSize: 50,
            onProgress: (progress, current, total) => {
              toast.info(`Processing chunk ${current}/${total} (${Math.round(progress)}%)`, {
                id: 'bulk-progress'
              });
            }
          }
        );

        toast.dismiss('bulk-progress');
      } else {
        await onAction(confirmDialog.action, selectedItems);
      }

      toast.success(`${confirmDialog.action.charAt(0).toUpperCase() + confirmDialog.action.slice(1)} operation completed successfully`);
    } catch (error) {
      console.error('Bulk operation failed:', error);
      toast.error(`Failed to ${confirmDialog.action} selected items: ${(error as Error).message}`);
    }
  };

  const handleExport = () => {
    try {
      // Create CSV content
      if (selectedItems.length === 0) {
        toast.warning('No items selected for export');
        return;
      }

      const headers = Object.keys(selectedItems[0]);
      const csvContent = [
      headers.join(','),
      ...selectedItems.map((item) =>
      headers.map((header) => {
        const value = item[header];
        // Escape commas and quotes in CSV
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value || '';
      }).join(',')
      )].
      join('\n');

      // Download file
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `${entityType}_export_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success(`Exported ${selectedItems.length} ${entityType} records`);

      // Log export operation
      const exportData = {
        operation_type: 'export',
        entity_type: entityType,
        entity_ids: selectedItems.map((item) => item.id || item.ID).join(','),
        operation_details: JSON.stringify({
          action: 'export',
          format: 'csv',
          itemCount: selectedItems.length,
          timestamp: new Date().toISOString()
        }),
        user_id: 0,
        user_email: '',
        timestamp: new Date().toISOString(),
        status: 'completed',
        error_message: ''
      };

      window.ezsite.apis.tableCreate('data_operations', exportData).
      catch((error) => console.warn('Failed to log export:', error));

    } catch (error) {
      console.error('Export failed:', error);
      toast.error('Failed to export data');
    }
  };

  const operations = [
  {
    group: 'Actions',
    items: [
    { key: 'activate', label: 'Activate', icon: <CheckCircle className="h-4 w-4" />, color: 'green' },
    { key: 'deactivate', label: 'Deactivate', icon: <XCircle className="h-4 w-4" />, color: 'gray' },
    { key: 'duplicate', label: 'Duplicate', icon: <Copy className="h-4 w-4" />, color: 'blue' }]

  },
  {
    group: 'Data Operations',
    items: [
    { key: 'export', label: 'Export to CSV', icon: <Download className="h-4 w-4" />, color: 'blue' },
    { key: 'archive', label: 'Archive', icon: <Archive className="h-4 w-4" />, color: 'yellow' }]

  },
  {
    group: 'Destructive Actions',
    items: [
    { key: 'delete', label: 'Delete', icon: <Trash2 className="h-4 w-4" />, color: 'red' }]

  }];


  if (selectedItems.length === 0) {
    return (
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <span>Select items to perform bulk operations</span>
      </div>);

  }

  return (
    <div className="flex items-center gap-2">
      <Badge variant="secondary" className="text-xs">
        {selectedItems.length} selected
      </Badge>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" disabled={isLoading}>
            {isLoading ?
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> :

            <Edit className="h-4 w-4 mr-2" />
            }
            Bulk Actions
            <ChevronDown className="h-4 w-4 ml-2" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {operations.map((group, groupIndex) =>
          <div key={group.group}>
              {groupIndex > 0 && <DropdownMenuSeparator />}
              <div className="px-2 py-1.5 text-xs font-medium text-gray-500">
                {group.group}
              </div>
              {group.items.map((item) =>
            <DropdownMenuItem
              key={item.key}
              onClick={() => handleAction(item.key)}
              className={`flex items-center gap-2 cursor-pointer ${
              item.color === 'red' ? 'text-red-600 focus:text-red-600' : ''}`
              }>

                  <span className={
              item.color === 'red' ? 'text-red-600' :
              item.color === 'green' ? 'text-green-600' :
              item.color === 'yellow' ? 'text-yellow-600' :
              item.color === 'blue' ? 'text-blue-600' :
              'text-gray-600'
              }>
                    {item.icon}
                  </span>
                  {item.label}
                </DropdownMenuItem>
            )}
            </div>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Confirmation Dialog */}
      <AlertDialog open={confirmDialog.open} onOpenChange={(open) =>
      setConfirmDialog((prev) => ({ ...prev, open }))
      }>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{confirmDialog.title}</AlertDialogTitle>
            <AlertDialogDescription>
              {confirmDialog.description}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmAction}
              variant={confirmDialog.variant}>

              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>);

};

export default BulkOperations;