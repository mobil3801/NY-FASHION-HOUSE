
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { Search, Filter, SortAsc, SortDesc, Eye, Edit, Trash2, RefreshCw, MoreHorizontal } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

import { currencyFormat, formatUSD } from '@/utils/currencyUtils';
import { formatUSADate, formatUSADateTime } from '@/utils/dateUtils';

interface UnifiedDataTableProps {
  entityType: string;
  onSelectionChange: (items: any[]) => void;
  selectedItems: any[];
}

const UnifiedDataTable: React.FC<UnifiedDataTableProps> = ({
  entityType,
  onSelectionChange,
  selectedItems
}) => {
  const [data, setData] = useState<any[]>([]);
  const [filteredData, setFilteredData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [sortField, setSortField] = useState('id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterField, setFilterField] = useState('');
  const [filterValue, setFilterValue] = useState('');

  // Entity-specific configurations
  const entityConfigs = {
    customers: {
      tableName: 'customers',
      columns: [
      { key: 'id', label: 'ID', type: 'number', sortable: true },
      { key: 'name', label: 'Name', type: 'text', sortable: true, searchable: true },
      { key: 'email', label: 'Email', type: 'email', sortable: true, searchable: true },
      { key: 'phone', label: 'Phone', type: 'text', sortable: false },
      { key: 'company', label: 'Company', type: 'text', sortable: true, searchable: true },
      { key: 'created_at', label: 'Created', type: 'date', sortable: true },
      { key: 'status', label: 'Status', type: 'badge', sortable: true }]

    },
    products: {
      tableName: 'products',
      columns: [
      { key: 'id', label: 'ID', type: 'number', sortable: true },
      { key: 'name', label: 'Product Name', type: 'text', sortable: true, searchable: true },
      { key: 'sku', label: 'SKU', type: 'text', sortable: true, searchable: true },
      { key: 'category', label: 'Category', type: 'text', sortable: true },
      { key: 'price', label: 'Price', type: 'currency', sortable: true },
      { key: 'stock_quantity', label: 'Stock', type: 'number', sortable: true },
      { key: 'status', label: 'Status', type: 'badge', sortable: true }]

    },
    employees: {
      tableName: 'employees',
      columns: [
      { key: 'id', label: 'ID', type: 'number', sortable: true },
      { key: 'name', label: 'Name', type: 'text', sortable: true, searchable: true },
      { key: 'email', label: 'Email', type: 'email', sortable: true, searchable: true },
      { key: 'position', label: 'Position', type: 'text', sortable: true },
      { key: 'department', label: 'Department', type: 'text', sortable: true },
      { key: 'hire_date', label: 'Hire Date', type: 'date', sortable: true },
      { key: 'status', label: 'Status', type: 'badge', sortable: true }]

    },
    suppliers: {
      tableName: 'suppliers',
      columns: [
      { key: 'id', label: 'ID', type: 'number', sortable: true },
      { key: 'name', label: 'Supplier Name', type: 'text', sortable: true, searchable: true },
      { key: 'contact_person', label: 'Contact', type: 'text', sortable: true, searchable: true },
      { key: 'email', label: 'Email', type: 'email', sortable: true },
      { key: 'phone', label: 'Phone', type: 'text', sortable: false },
      { key: 'created_at', label: 'Created', type: 'date', sortable: true },
      { key: 'status', label: 'Status', type: 'badge', sortable: true }]

    },
    invoices: {
      tableName: 'invoices',
      columns: [
      { key: 'id', label: 'ID', type: 'number', sortable: true },
      { key: 'invoice_number', label: 'Invoice #', type: 'text', sortable: true, searchable: true },
      { key: 'customer_name', label: 'Customer', type: 'text', sortable: true, searchable: true },
      { key: 'total_amount', label: 'Amount', type: 'currency', sortable: true },
      { key: 'due_date', label: 'Due Date', type: 'date', sortable: true },
      { key: 'status', label: 'Status', type: 'badge', sortable: true }]

    },
    sales: {
      tableName: 'sales',
      columns: [
      { key: 'id', label: 'ID', type: 'number', sortable: true },
      { key: 'sale_number', label: 'Sale #', type: 'text', sortable: true, searchable: true },
      { key: 'customer_name', label: 'Customer', type: 'text', sortable: true, searchable: true },
      { key: 'total_amount', label: 'Amount', type: 'currency', sortable: true },
      { key: 'sale_date', label: 'Date', type: 'date', sortable: true },
      { key: 'payment_method', label: 'Payment', type: 'text', sortable: true },
      { key: 'status', label: 'Status', type: 'badge', sortable: true }]

    },
    accounting: {
      tableName: 'accounting_transactions',
      columns: [
      { key: 'id', label: 'ID', type: 'number', sortable: true },
      { key: 'transaction_number', label: 'Transaction #', type: 'text', sortable: true, searchable: true },
      { key: 'account_name', label: 'Account', type: 'text', sortable: true, searchable: true },
      { key: 'amount', label: 'Amount', type: 'currency', sortable: true },
      { key: 'transaction_date', label: 'Date', type: 'date', sortable: true },
      { key: 'type', label: 'Type', type: 'badge', sortable: true }]

    }
  };

  const currentConfig = entityConfigs[entityType as keyof typeof entityConfigs];

  // Load data
  const loadData = async () => {
    if (!currentConfig) return;

    try {
      setIsLoading(true);

      const filters = [];
      if (searchTerm && currentConfig.columns.some((col) => col.searchable)) {
        const searchableColumns = currentConfig.columns.filter((col) => col.searchable);
        // For demo purposes, we'll search in the first searchable column
        if (searchableColumns.length > 0) {
          filters.push({
            name: searchableColumns[0].key,
            op: 'StringContains',
            value: searchTerm
          });
        }
      }

      if (filterField && filterValue) {
        filters.push({
          name: filterField,
          op: 'StringContains',
          value: filterValue
        });
      }

      const queryParams = {
        PageNo: currentPage,
        PageSize: pageSize,
        OrderByField: sortField,
        IsAsc: sortDirection === 'asc',
        Filters: filters
      };

      // Since we don't have actual table IDs, we'll create mock data
      // In a real implementation, you would call:
      // const { data: response, error } = await window.ezsite.apis.tablePage(currentConfig.tableName, queryParams);

      // Mock data for demonstration
      const mockData = generateMockData(entityType, currentPage, pageSize);
      setData(mockData.items);
      setFilteredData(mockData.items);
      setTotalPages(Math.ceil(mockData.total / pageSize));

    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setIsLoading(false);
    }
  };

  // Generate mock data for demonstration
  const generateMockData = (type: string, page: number, size: number) => {
    const total = 100; // Mock total
    const items = [];

    for (let i = 0; i < size; i++) {
      const id = (page - 1) * size + i + 1;
      let item: any = { id };

      switch (type) {
        case 'customers':
          item = {
            ...item,
            name: `Customer ${id}`,
            email: `customer${id}@example.com`,
            phone: `(555) 000-${id.toString().padStart(4, '0')}`,
            company: `Company ${id}`,
            created_at: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString(),
            status: ['active', 'inactive', 'pending'][Math.floor(Math.random() * 3)]
          };
          break;
        case 'products':
          item = {
            ...item,
            name: `Product ${id}`,
            sku: `SKU-${id.toString().padStart(6, '0')}`,
            category: ['Electronics', 'Clothing', 'Books', 'Home'][Math.floor(Math.random() * 4)],
            price: Math.random() * 1000 + 10,
            stock_quantity: Math.floor(Math.random() * 100),
            status: ['active', 'discontinued', 'out_of_stock'][Math.floor(Math.random() * 3)]
          };
          break;
        case 'employees':
          item = {
            ...item,
            name: `Employee ${id}`,
            email: `employee${id}@company.com`,
            position: ['Manager', 'Developer', 'Designer', 'Analyst'][Math.floor(Math.random() * 4)],
            department: ['IT', 'Sales', 'HR', 'Marketing'][Math.floor(Math.random() * 4)],
            hire_date: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString(),
            status: ['active', 'inactive', 'on_leave'][Math.floor(Math.random() * 3)]
          };
          break;
      }
      items.push(item);
    }

    return { items, total };
  };

  // Load data when component mounts or dependencies change
  useEffect(() => {
    loadData();
  }, [entityType, currentPage, pageSize, sortField, sortDirection, searchTerm, filterField, filterValue]);

  // Handle selection
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      onSelectionChange([...selectedItems, ...filteredData]);
    } else {
      const dataIds = filteredData.map((item) => item.id);
      onSelectionChange(selectedItems.filter((item) => !dataIds.includes(item.id)));
    }
  };

  const handleSelectItem = (item: any, checked: boolean) => {
    if (checked) {
      onSelectionChange([...selectedItems, item]);
    } else {
      onSelectionChange(selectedItems.filter((selected) => selected.id !== item.id));
    }
  };

  // Render cell value based on type
  const renderCellValue = (value: any, type: string) => {
    if (value === null || value === undefined) return '-';

    switch (type) {
      case 'currency':
        return formatUSD(value);
      case 'date':
        return formatUSADate(new Date(value));
      case 'datetime':
        return formatUSADateTime(new Date(value));
      case 'badge':
        return (
          <Badge
            variant={
            value === 'active' ? 'default' :
            value === 'inactive' || value === 'discontinued' ? 'secondary' :
            value === 'pending' || value === 'on_leave' ? 'outline' :
            'destructive'
            }>

            {value.replace('_', ' ').toUpperCase()}
          </Badge>);

      case 'email':
        return <a href={`mailto:${value}`} className="text-blue-600 hover:underline">{value}</a>;
      default:
        return value.toString();
    }
  };

  const isAllSelected = filteredData.length > 0 &&
  filteredData.every((item) => selectedItems.some((selected) => selected.id === item.id));
  const isIndeterminate = filteredData.some((item) => selectedItems.some((selected) => selected.id === item.id)) && !isAllSelected;

  if (!currentConfig) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-gray-500">Entity type "{entityType}" is not supported yet.</p>
        </CardContent>
      </Card>);

  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2">
            {currentConfig.columns.length} Columns
            <Badge variant="outline">{filteredData.length} Records</Badge>
          </CardTitle>
          
          <div className="flex flex-col lg:flex-row gap-2">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 w-full lg:w-64" />

            </div>
            
            {/* Filter */}
            <div className="flex gap-2">
              <Select value={filterField} onValueChange={setFilterField}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Filter by..." />
                </SelectTrigger>
                <SelectContent>
                  {currentConfig.columns.map((column) =>
                  <SelectItem key={column.key} value={column.key}>
                      {column.label}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
              
              {filterField &&
              <Input
                placeholder="Filter value..."
                value={filterValue}
                onChange={(e) => setFilterValue(e.target.value)}
                className="w-32" />

              }
            </div>
            
            {/* Page Size */}
            <Select value={pageSize.toString()} onValueChange={(value) => setPageSize(parseInt(value))}>
              <SelectTrigger className="w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10</SelectItem>
                <SelectItem value="25">25</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
              </SelectContent>
            </Select>
            
            <Button onClick={loadData} disabled={isLoading} variant="outline" size="sm">
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">
                  <Checkbox
                    checked={isAllSelected}
                    indeterminate={isIndeterminate}
                    onCheckedChange={handleSelectAll} />

                </TableHead>
                {currentConfig.columns.map((column) =>
                <TableHead
                  key={column.key}
                  className={column.sortable ? 'cursor-pointer hover:bg-gray-50' : ''}
                  onClick={() => {
                    if (column.sortable) {
                      if (sortField === column.key) {
                        setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                      } else {
                        setSortField(column.key);
                        setSortDirection('asc');
                      }
                    }
                  }}>

                    <div className="flex items-center gap-1">
                      {column.label}
                      {column.sortable && sortField === column.key && (
                    sortDirection === 'asc' ? <SortAsc className="h-3 w-3" /> : <SortDesc className="h-3 w-3" />)
                    }
                    </div>
                  </TableHead>
                )}
                <TableHead className="w-12">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ?
              <TableRow>
                  <TableCell colSpan={currentConfig.columns.length + 2} className="text-center py-8">
                    <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2" />
                    Loading data...
                  </TableCell>
                </TableRow> :
              filteredData.length === 0 ?
              <TableRow>
                  <TableCell colSpan={currentConfig.columns.length + 2} className="text-center py-8 text-gray-500">
                    No data found
                  </TableCell>
                </TableRow> :

              filteredData.map((item) =>
              <TableRow key={item.id}>
                    <TableCell>
                      <Checkbox
                    checked={selectedItems.some((selected) => selected.id === item.id)}
                    onCheckedChange={(checked) => handleSelectItem(item, checked as boolean)} />

                    </TableCell>
                    {currentConfig.columns.map((column) =>
                <TableCell key={column.key}>
                        {renderCellValue(item[column.key], column.type)}
                      </TableCell>
                )}
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem>
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
              )
              }
            </TableBody>
          </Table>
        </div>
        
        {/* Pagination */}
        {totalPages > 1 &&
        <div className="flex items-center justify-between mt-4">
            <p className="text-sm text-gray-600">
              Showing {(currentPage - 1) * pageSize + 1} to {Math.min(currentPage * pageSize, filteredData.length * totalPages)} results
            </p>
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    if (currentPage > 1) setCurrentPage(currentPage - 1);
                  }}
                  className={currentPage <= 1 ? 'pointer-events-none opacity-50' : ''} />

                </PaginationItem>
                
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const pageNum = i + 1;
                return (
                  <PaginationItem key={pageNum}>
                      <PaginationLink
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        setCurrentPage(pageNum);
                      }}
                      isActive={currentPage === pageNum}>

                        {pageNum}
                      </PaginationLink>
                    </PaginationItem>);

              })}
                
                {totalPages > 5 && <PaginationEllipsis />}
                
                <PaginationItem>
                  <PaginationNext
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
                  }}
                  className={currentPage >= totalPages ? 'pointer-events-none opacity-50' : ''} />

                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        }
      </CardContent>
    </Card>);

};

export default UnifiedDataTable;