import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, ShoppingCart, DollarSign, TrendingUp } from 'lucide-react';
import { enhancedErrorLoggingService } from '@/services/enhancedErrorLoggingService';

const StatsCards: React.FC = () => {
  const [stats, setStats] = useState({
    totalCustomers: 0,
    totalOrders: 0,
    totalRevenue: 0,
    growthRate: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setIsLoading(true);
      // Basic stats fetching - using customers table as example
      const { data: customersData, error: customersError } = await window.ezsite.apis.tablePage(38563, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'id',
        IsAsc: true,
        Filters: []
      });

      if (!customersError && customersData) {
        setStats((prev) => ({
          ...prev,
          totalCustomers: customersData.VirtualCount || 0
        }));
      }

    } catch (error) {
      console.error('Error fetching stats:', error);
      enhancedErrorLoggingService.logError(error as Error, {
        title: 'Dashboard Stats Error',
        action: 'Fetch dashboard statistics',
        operation: 'fetchStats',
        severity: 'medium',
        category: 'server',
        service: 'dashboardService'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const statsCards = [
  {
    title: 'Total Customers',
    value: stats.totalCustomers,
    icon: Users,
    description: 'Active customers'
  },
  {
    title: 'Total Orders',
    value: stats.totalOrders,
    icon: ShoppingCart,
    description: 'Orders this month'
  },
  {
    title: 'Revenue',
    value: `$${stats.totalRevenue.toLocaleString()}`,
    icon: DollarSign,
    description: 'Total revenue'
  },
  {
    title: 'Growth',
    value: `${stats.growthRate}%`,
    icon: TrendingUp,
    description: 'Vs last month'
  }];


  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {statsCards.map((stat, index) => {
        const IconComponent = stat.icon;
        return (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <IconComponent className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? '...' : stat.value}
              </div>
              <p className="text-xs text-muted-foreground">
                {stat.description}
              </p>
            </CardContent>
          </Card>);

      })}
    </div>);

};

export default StatsCards;