import React from 'react';
import { AlertTriangle, RefreshCw, Home, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';

interface ErrorDisplayProps {
  error?: Error | string;
  title?: string;
  description?: string;
  showDetails?: boolean;
  onRetry?: () => void;
  onBack?: () => void;
  variant?: 'card' | 'inline' | 'page';
  className?: string;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({
  error,
  title = 'Something went wrong',
  description = 'An unexpected error occurred. Please try again.',
  showDetails = process.env.NODE_ENV === 'development',
  onRetry,
  onBack,
  variant = 'card',
  className = ''
}) => {
  const navigate = useNavigate();

  const errorMessage = error instanceof Error ? error.message : String(error);
  const errorStack = error instanceof Error ? error.stack : undefined;

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  const handleHome = () => {
    navigate('/');
  };

  const handleRefresh = () => {
    if (onRetry) {
      onRetry();
    } else {
      window.location.reload();
    }
  };

  if (variant === 'inline') {
    return (
      <Alert className={`border-red-200 bg-red-50 ${className}`}>
        <AlertTriangle className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-800">
          {description}
          {showDetails && error &&
          <details className="mt-2">
              <summary className="cursor-pointer text-sm font-medium">Technical Details</summary>
              <pre className="mt-1 text-xs overflow-x-auto whitespace-pre-wrap">
                {errorMessage}
              </pre>
            </details>
          }
        </AlertDescription>
      </Alert>);

  }

  if (variant === 'page') {
    return (
      <div className={`min-h-screen flex items-center justify-center bg-gray-50 p-4 ${className}`}>
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <CardTitle className="text-red-600 text-xl">{title}</CardTitle>
            <CardDescription className="text-base">{description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {showDetails && error &&
            <div className="text-xs text-gray-600 p-3 bg-gray-100 rounded-md">
                <p className="font-medium mb-2">Error Details:</p>
                <p className="break-words">{errorMessage}</p>
                {errorStack &&
              <details className="mt-2">
                    <summary className="cursor-pointer">Stack Trace</summary>
                    <pre className="mt-1 text-xs overflow-x-auto whitespace-pre-wrap">
                      {errorStack}
                    </pre>
                  </details>
              }
              </div>
            }
            <div className="flex gap-2">
              <Button onClick={handleRefresh} className="flex-1">
                <RefreshCw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
              <Button variant="outline" onClick={handleBack} className="flex-1">
                <ChevronLeft className="w-4 h-4 mr-2" />
                Go Back
              </Button>
            </div>
            <Button variant="ghost" onClick={handleHome} className="w-full">
              <Home className="w-4 h-4 mr-2" />
              Home Page
            </Button>
          </CardContent>
        </Card>
      </div>);

  }

  // Default card variant
  return (
    <Card className={`border-red-200 bg-red-50 ${className}`}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          <CardTitle className="text-red-600 text-lg">{title}</CardTitle>
        </div>
        <CardDescription className="text-red-800">{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {showDetails && error &&
        <details className="text-sm text-gray-600">
            <summary className="cursor-pointer font-medium">Error Details</summary>
            <div className="mt-2 p-2 bg-gray-100 rounded text-xs">
              <p className="break-words">{errorMessage}</p>
              {errorStack &&
            <pre className="mt-1 overflow-x-auto whitespace-pre-wrap">
                  {errorStack}
                </pre>
            }
            </div>
          </details>
        }
        <div className="flex gap-2">
          {onRetry &&
          <Button onClick={onRetry} size="sm" className="flex-1">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          }
          <Button variant="outline" onClick={handleBack} size="sm" className="flex-1">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>
      </CardContent>
    </Card>);

};

export default ErrorDisplay;