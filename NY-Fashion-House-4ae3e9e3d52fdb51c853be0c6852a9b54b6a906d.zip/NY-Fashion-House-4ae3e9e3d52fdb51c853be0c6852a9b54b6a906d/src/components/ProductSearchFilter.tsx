
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, X, Filter } from 'lucide-react';
import { ProductSearchParams, ProductCategory } from '@/types/product';
import { productService } from '@/services/productService';
import { supplierService } from '@/services/supplierService';
import { Supplier } from '@/types/supplier';

interface ProductSearchFilterProps {
  filters: ProductSearchParams;
  onFiltersChange: (filters: ProductSearchParams) => void;
  suppliers: Supplier[];
}

const ProductSearchFilter: React.FC<ProductSearchFilterProps> = ({
  filters,
  onFiltersChange,
  suppliers
}) => {
  const categories = productService.getCategories();
  const sizes = productService.getSizes();
  const colors = productService.getColors();

  const updateFilter = (key: keyof ProductSearchParams, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const clearFilter = (key: keyof ProductSearchParams) => {
    const newFilters = { ...filters };
    delete newFilters[key];
    onFiltersChange(newFilters);
  };

  const clearAllFilters = () => {
    onFiltersChange({});
  };

  const getActiveFiltersCount = () => {
    return Object.keys(filters).length - (filters.sortBy ? 1 : 0) - (filters.sortOrder ? 1 : 0);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Filter className="w-4 h-4" />
          Search & Filter
          {getActiveFiltersCount() > 0 &&
          <Badge variant="secondary">{getActiveFiltersCount()}</Badge>
          }
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search products by name, SKU, or description..."
            value={filters.query || ''}
            onChange={(e) => updateFilter('query', e.target.value || undefined)}
            className="pl-10" />

        </div>

        {/* Filters Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Category Filter */}
          <div>
            <label className="text-sm font-medium mb-1 block">Category</label>
            <Select
              value={filters.category || 'all-categories'}
              onValueChange={(value) => updateFilter('category', value === 'all-categories' ? undefined : value)}>

              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-categories">All Categories</SelectItem>
                {categories.map((category) =>
                <SelectItem key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Size Filter */}
          <div>
            <label className="text-sm font-medium mb-1 block">Size</label>
            <Select
              value={filters.size || 'all-sizes'}
              onValueChange={(value) => updateFilter('size', value === 'all-sizes' ? undefined : value)}>

              <SelectTrigger>
                <SelectValue placeholder="All Sizes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-sizes">All Sizes</SelectItem>
                {sizes.map((size) =>
                <SelectItem key={size} value={size}>{size}</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Color Filter */}
          <div>
            <label className="text-sm font-medium mb-1 block">Color</label>
            <Select
              value={filters.color || 'all-colors'}
              onValueChange={(value) => updateFilter('color', value === 'all-colors' ? undefined : value)}>

              <SelectTrigger>
                <SelectValue placeholder="All Colors" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-colors">All Colors</SelectItem>
                {colors.map((color) =>
                <SelectItem key={color} value={color}>{color}</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* Supplier Filter */}
          <div>
            <label className="text-sm font-medium mb-1 block">Supplier</label>
            <Select
              value={filters.supplier || 'all-suppliers'}
              onValueChange={(value) => updateFilter('supplier', value === 'all-suppliers' ? undefined : value)}>

              <SelectTrigger>
                <SelectValue placeholder="All Suppliers" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-suppliers">All Suppliers</SelectItem>
                {suppliers.map((supplier) =>
                <SelectItem key={supplier.id} value={supplier.id}>
                    {supplier.name}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Stock Status Filters */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant={filters.inStock ? "default" : "outline"}
            size="sm"
            onClick={() => updateFilter('inStock', !filters.inStock ? true : undefined)}>

            In Stock Only
          </Button>
          <Button
            variant={filters.lowStock ? "default" : "outline"}
            size="sm"
            onClick={() => updateFilter('lowStock', !filters.lowStock ? true : undefined)}>

            Low Stock
          </Button>
        </div>

        {/* Sort Options */}
        <div className="flex gap-2">
          <div className="flex-1">
            <label className="text-sm font-medium mb-1 block">Sort By</label>
            <Select
              value={filters.sortBy || ''}
              onValueChange={(value) => updateFilter('sortBy', value || undefined)}>

              <SelectTrigger>
                <SelectValue placeholder="Default" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default-sort">Default</SelectItem>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="price">Price</SelectItem>
                <SelectItem value="stock">Stock Level</SelectItem>
                <SelectItem value="category">Category</SelectItem>
                <SelectItem value="createdAt">Created Date</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex-1">
            <label className="text-sm font-medium mb-1 block">Order</label>
            <Select
              value={filters.sortOrder || ''}
              onValueChange={(value) => updateFilter('sortOrder', value || undefined)}>

              <SelectTrigger>
                <SelectValue placeholder="Ascending" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="asc">Ascending</SelectItem>
                <SelectItem value="desc">Descending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Active Filters */}
        {getActiveFiltersCount() > 0 &&
        <div className="flex flex-wrap gap-2 items-center">
            <span className="text-sm font-medium">Active Filters:</span>
            {filters.query &&
          <Badge variant="secondary" className="gap-1">
                Search: {filters.query}
                <X className="w-3 h-3 cursor-pointer" onClick={() => clearFilter('query')} />
              </Badge>
          }
            {filters.category &&
          <Badge variant="secondary" className="gap-1">
                Category: {filters.category}
                <X className="w-3 h-3 cursor-pointer" onClick={() => clearFilter('category')} />
              </Badge>
          }
            {filters.size &&
          <Badge variant="secondary" className="gap-1">
                Size: {filters.size}
                <X className="w-3 h-3 cursor-pointer" onClick={() => clearFilter('size')} />
              </Badge>
          }
            {filters.color &&
          <Badge variant="secondary" className="gap-1">
                Color: {filters.color}
                <X className="w-3 h-3 cursor-pointer" onClick={() => clearFilter('color')} />
              </Badge>
          }
            {filters.supplier &&
          <Badge variant="secondary" className="gap-1">
                Supplier: {suppliers.find((s) => s.id === filters.supplier)?.name}
                <X className="w-3 h-3 cursor-pointer" onClick={() => clearFilter('supplier')} />
              </Badge>
          }
            <Button variant="outline" size="sm" onClick={clearAllFilters}>
              Clear All
            </Button>
          </div>
        }
      </CardContent>
    </Card>);

};

export default ProductSearchFilter;