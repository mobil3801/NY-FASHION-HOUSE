import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Customer, Purchase } from "@/types/customer";
import { getCustomerPurchases } from "@/services/customerService";
import { CalendarDays, Mail, Phone, MapPin, DollarSign, ShoppingBag } from "lucide-react";

interface CustomerDetailsProps {
  customer: Customer;
}

const CustomerDetails = ({ customer }: CustomerDetailsProps) => {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadPurchases = async () => {
      try {
        const data = await getCustomerPurchases(customer.id);
        setPurchases(data);
      } catch (error) {
        console.error('Failed to load purchases:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadPurchases();
  }, [customer.id]);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusColor = (status: Purchase['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Customer Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span>Customer Information</span>
              <Badge variant={customer.status === 'active' ? 'default' : 'secondary'}>
                {customer.status}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">{customer.email}</span>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">{customer.phone}</span>
            </div>
            <div className="flex items-start gap-3">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
              <span className="text-sm">{customer.address}</span>
            </div>
            <div className="flex items-center gap-3">
              <CalendarDays className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Customer since {formatDate(customer.createdAt)}</span>
            </div>
            {customer.notes &&
            <div className="pt-2">
                <p className="text-sm font-medium">Notes:</p>
                <p className="text-sm text-muted-foreground">{customer.notes}</p>
              </div>
            }
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Purchase Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Total Orders</span>
              </div>
              <span className="font-semibold">{customer.totalPurchases}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Total Spent</span>
              </div>
              <span className="font-semibold">${customer.totalSpent.toLocaleString()}</span>
            </div>
            {customer.lastPurchase &&
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Last Purchase</span>
                </div>
                <span className="font-semibold">{formatDate(customer.lastPurchase)}</span>
              </div>
            }
            <div className="flex items-center justify-between">
              <span className="text-sm">Average Order Value</span>
              <span className="font-semibold">
                ${customer.totalPurchases > 0 ? (customer.totalSpent / customer.totalPurchases).toFixed(2) : '0.00'}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Purchase History */}
      <Card>
        <CardHeader>
          <CardTitle>Purchase History</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ?
          <div className="text-center py-8">Loading purchase history...</div> :
          purchases.length === 0 ?
          <div className="text-center py-8 text-muted-foreground">
              No purchase history available
            </div> :

          <ScrollArea className="h-[300px]">
              <div className="space-y-4">
                {purchases.map((purchase, index) =>
              <div key={purchase.id}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium">{purchase.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatDate(purchase.date)}
                        </p>
                      </div>
                      <div className="text-right space-y-1">
                        <p className="font-semibold">${purchase.amount.toFixed(2)}</p>
                        <Badge className={getStatusColor(purchase.status)}>
                          {purchase.status}
                        </Badge>
                      </div>
                    </div>
                    {index < purchases.length - 1 && <Separator className="mt-4" />}
                  </div>
              )}
              </div>
            </ScrollArea>
          }
        </CardContent>
      </Card>
    </div>);

};

export default CustomerDetails;