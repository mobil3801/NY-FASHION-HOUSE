import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { AuditLog } from '@/types/audit';
import { AlertTriangle, Shield, Clock, User, Globe, Monitor } from 'lucide-react';

interface AuditLogDetailProps {
  log: AuditLog | null;
  open: boolean;
  onClose: () => void;
}

const AuditLogDetail: React.FC<AuditLogDetailProps> = ({ log, open, onClose }) => {
  if (!log) return null;

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'CRITICAL':
        return <Badge variant="destructive">Critical</Badge>;
      case 'HIGH':
        return <Badge variant="destructive" className="bg-orange-500">High</Badge>;
      case 'MEDIUM':
        return <Badge variant="outline" className="border-yellow-500 text-yellow-600">Medium</Badge>;
      case 'LOW':
        return <Badge variant="secondary">Low</Badge>;
      default:
        return <Badge variant="secondary">{severity}</Badge>;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {log.is_security_event ?
            <AlertTriangle className="h-5 w-5 text-red-500" /> :

            <Shield className="h-5 w-5 text-gray-500" />
            }
            Audit Log Details - {log.action}
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh]">
          <div className="space-y-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Basic Information</h3>
                <div className="flex gap-2">
                  {getSeverityBadge(log.severity)}
                  {log.is_security_event &&
                  <Badge variant="destructive" className="animate-pulse">
                      Security Event
                    </Badge>
                  }
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-gray-400" />
                    <span className="font-medium">Timestamp</span>
                  </div>
                  <p className="text-sm text-gray-600 ml-6">
                    {format(new Date(log.timestamp), 'PPpp')}
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-gray-400" />
                    <span className="font-medium">User</span>
                  </div>
                  <p className="text-sm text-gray-600 ml-6">
                    {log.user_name} ({log.user_email})
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="font-medium">Action</span>
                  <p className="text-sm text-gray-600">
                    <Badge variant="secondary">{log.action}</Badge>
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="font-medium">Table</span>
                  <p className="text-sm text-gray-600">
                    <code className="bg-gray-100 px-2 py-1 rounded">{log.table_name}</code>
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Technical Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Technical Details</h3>
              
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 text-gray-400" />
                    <span className="font-medium">IP Address</span>
                  </div>
                  <p className="text-sm text-gray-600 ml-6">{log.ip_address}</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4 text-gray-400" />
                    <span className="font-medium">User Agent</span>
                  </div>
                  <p className="text-sm text-gray-600 ml-6 break-all">{log.user_agent}</p>
                </div>

                <div className="space-y-2">
                  <span className="font-medium">Session ID</span>
                  <p className="text-sm text-gray-600">
                    <code className="bg-gray-100 px-2 py-1 rounded">{log.session_id}</code>
                  </p>
                </div>

                <div className="space-y-2">
                  <span className="font-medium">Record ID</span>
                  <p className="text-sm text-gray-600">{log.record_id || 'N/A'}</p>
                </div>
              </div>
            </div>

            {/* Event Description */}
            {log.event_description &&
            <>
                <Separator />
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Event Description</h3>
                  <p className="text-sm text-gray-600">{log.event_description}</p>
                </div>
              </>
            }

            {/* Data Changes */}
            {(log.old_values || log.new_values) &&
            <>
                <Separator />
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Data Changes</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {log.old_values &&
                  <div className="space-y-2">
                        <span className="font-medium text-red-600">Old Values</span>
                        <pre className="text-sm bg-red-50 border border-red-200 p-3 rounded overflow-auto">
                          {log.old_values}
                        </pre>
                      </div>
                  }

                    {log.new_values &&
                  <div className="space-y-2">
                        <span className="font-medium text-green-600">New Values</span>
                        <pre className="text-sm bg-green-50 border border-green-200 p-3 rounded overflow-auto">
                          {log.new_values}
                        </pre>
                      </div>
                  }
                  </div>
                </div>
              </>
            }

            {/* Metadata */}
            {log.metadata &&
            <>
                <Separator />
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Metadata</h3>
                  <pre className="text-sm bg-gray-50 border p-3 rounded overflow-auto">
                    {log.metadata}
                  </pre>
                </div>
              </>
            }
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>);

};

export default AuditLogDetail;