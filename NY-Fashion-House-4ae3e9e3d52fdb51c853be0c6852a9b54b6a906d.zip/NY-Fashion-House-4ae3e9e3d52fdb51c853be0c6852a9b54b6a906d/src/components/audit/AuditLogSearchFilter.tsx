import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, X, Filter } from 'lucide-react';
import { AuditLogFilters } from '@/types/audit';

interface AuditLogSearchFilterProps {
  filters: AuditLogFilters;
  onFiltersChange: (filters: AuditLogFilters) => void;
  onSearch: () => void;
  onClear: () => void;
}

const AuditLogSearchFilter: React.FC<AuditLogSearchFilterProps> = ({
  filters,
  onFiltersChange,
  onSearch,
  onClear
}) => {
  const handleFilterChange = (key: keyof AuditLogFilters, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Filter className="h-5 w-5" />
          Search Filters
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="space-y-2">
            <Label htmlFor="user-search">User Name</Label>
            <Input
              id="user-search"
              placeholder="Search by user..."
              value={filters.user_name || ''}
              onChange={(e) => handleFilterChange('user_name', e.target.value)} />

          </div>

          <div className="space-y-2">
            <Label htmlFor="action-filter">Action</Label>
            <Select value={filters.action || 'ALL'} onValueChange={(value) => handleFilterChange('action', value === 'ALL' ? '' : value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Actions</SelectItem>
                <SelectItem value="CREATE">Create</SelectItem>
                <SelectItem value="UPDATE">Update</SelectItem>
                <SelectItem value="DELETE">Delete</SelectItem>
                <SelectItem value="LOGIN">Login</SelectItem>
                <SelectItem value="LOGOUT">Logout</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="table-filter">Table</Label>
            <Select value={filters.table_name || 'ALL'} onValueChange={(value) => handleFilterChange('table_name', value === 'ALL' ? '' : value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select table" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Tables</SelectItem>
                <SelectItem value="easysite_auth_users">Users</SelectItem>
                <SelectItem value="sales_transactions">Sales</SelectItem>
                <SelectItem value="products">Products</SelectItem>
                <SelectItem value="customers">Customers</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="security-filter">Security Events</Label>
            <Select
              value={filters.is_security_event === undefined ? 'ALL' : filters.is_security_event.toString()}
              onValueChange={(value) => handleFilterChange('is_security_event', value === 'ALL' ? undefined : value === 'true')}>

              <SelectTrigger>
                <SelectValue placeholder="All events" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Events</SelectItem>
                <SelectItem value="true">Security Events Only</SelectItem>
                <SelectItem value="false">Regular Events Only</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="start-date">Start Date</Label>
            <Input
              id="start-date"
              type="datetime-local"
              value={filters.start_date || ''}
              onChange={(e) => handleFilterChange('start_date', e.target.value)} />

          </div>

          <div className="space-y-2">
            <Label htmlFor="end-date">End Date</Label>
            <Input
              id="end-date"
              type="datetime-local"
              value={filters.end_date || ''}
              onChange={(e) => handleFilterChange('end_date', e.target.value)} />

          </div>
        </div>

        <div className="flex gap-2">
          <Button onClick={onSearch} className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Search
          </Button>
          <Button variant="outline" onClick={onClear} className="flex items-center gap-2">
            <X className="h-4 w-4" />
            Clear Filters
          </Button>
        </div>
      </CardContent>
    </Card>);

};

export default AuditLogSearchFilter;