import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, FileText, Table, CheckCircle2 } from 'lucide-react';
import { AuditLog, AuditLogFilters } from '@/types/audit';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface AuditLogExportProps {
  logs: AuditLog[];
  filters: AuditLogFilters;
}

const AuditLogExport: React.FC<AuditLogExportProps> = ({ logs, filters }) => {
  const [isExporting, setIsExporting] = useState(false);

  const exportToCSV = async () => {
    setIsExporting(true);
    try {
      const headers = [
      'ID',
      'Timestamp',
      'User Name',
      'User Email',
      'Action',
      'Table Name',
      'Record ID',
      'IP Address',
      'Severity',
      'Security Event',
      'Event Description'];


      const csvContent = [
      headers.join(','),
      ...logs.map((log) => [
      log.id,
      format(new Date(log.timestamp), 'yyyy-MM-dd HH:mm:ss'),
      `"${log.user_name}"`,
      `"${log.user_email}"`,
      log.action,
      log.table_name,
      log.record_id,
      log.ip_address,
      log.severity,
      log.is_security_event ? 'Yes' : 'No',
      `"${log.event_description || ''}"`].
      join(','))].
      join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `audit_logs_${format(new Date(), 'yyyy-MM-dd_HH-mm-ss')}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Audit logs exported successfully');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export audit logs');
    } finally {
      setIsExporting(false);
    }
  };

  const exportToJSON = async () => {
    setIsExporting(true);
    try {
      const exportData = {
        export_timestamp: new Date().toISOString(),
        filters_applied: filters,
        total_records: logs.length,
        logs: logs
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: 'application/json;charset=utf-8;'
      });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `audit_logs_${format(new Date(), 'yyyy-MM-dd_HH-mm-ss')}.json`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Audit logs exported successfully');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export audit logs');
    } finally {
      setIsExporting(false);
    }
  };

  const getFiltersSummary = () => {
    const appliedFilters = [];
    if (filters.user_name) appliedFilters.push(`User: ${filters.user_name}`);
    if (filters.action) appliedFilters.push(`Action: ${filters.action}`);
    if (filters.table_name) appliedFilters.push(`Table: ${filters.table_name}`);
    if (filters.start_date) appliedFilters.push(`From: ${format(new Date(filters.start_date), 'PPp')}`);
    if (filters.end_date) appliedFilters.push(`To: ${format(new Date(filters.end_date), 'PPp')}`);
    if (filters.is_security_event !== undefined) {
      appliedFilters.push(`Security: ${filters.is_security_event ? 'Yes' : 'No'}`);
    }
    return appliedFilters;
  };

  return (
    <div className="space-y-6">
      {/* Export Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {logs.length}
              </div>
              <p className="text-gray-600">Total Records</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600 mb-2">
                {logs.filter((log) => log.is_security_event).length}
              </div>
              <p className="text-gray-600">Security Events</p>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">
                {logs.filter((log) => log.severity === 'HIGH' || log.severity === 'CRITICAL').length}
              </div>
              <p className="text-gray-600">Critical/High</p>
            </div>
          </div>

          {/* Applied Filters */}
          {getFiltersSummary().length > 0 &&
          <div className="mt-6">
              <h4 className="font-medium mb-2">Applied Filters:</h4>
              <div className="flex flex-wrap gap-2">
                {getFiltersSummary().map((filter, index) =>
              <Badge key={index} variant="outline">{filter}</Badge>
              )}
              </div>
            </div>
          }
        </CardContent>
      </Card>

      {/* Export Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* CSV Export */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Table className="h-5 w-5" />
              CSV Export
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Export audit logs as a CSV file for use in spreadsheet applications.
            </p>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Compatible with Excel, Google Sheets</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Includes all essential fields</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Formatted timestamps</span>
              </div>
            </div>

            <Button
              onClick={exportToCSV}
              disabled={isExporting || logs.length === 0}
              className="w-full">

              <FileText className="h-4 w-4 mr-2" />
              {isExporting ? 'Exporting...' : 'Export as CSV'}
            </Button>
          </CardContent>
        </Card>

        {/* JSON Export */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              JSON Export
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-gray-600">
              Export audit logs as a JSON file with complete metadata.
            </p>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Complete data preservation</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Includes metadata and filters</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Machine-readable format</span>
              </div>
            </div>

            <Button
              onClick={exportToJSON}
              disabled={isExporting || logs.length === 0}
              className="w-full"
              variant="outline">

              <Download className="h-4 w-4 mr-2" />
              {isExporting ? 'Exporting...' : 'Export as JSON'}
            </Button>
          </CardContent>
        </Card>
      </div>

      {logs.length === 0 &&
      <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500">No audit logs available for export. Please adjust your filters and search again.</p>
          </CardContent>
        </Card>
      }
    </div>);

};

export default AuditLogExport;