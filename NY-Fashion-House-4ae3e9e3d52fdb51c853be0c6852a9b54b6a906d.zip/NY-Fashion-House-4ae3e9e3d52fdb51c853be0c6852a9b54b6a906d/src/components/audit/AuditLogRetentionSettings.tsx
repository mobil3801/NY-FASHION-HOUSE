import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Settings, Save, AlertCircle, Database, Archive } from 'lucide-react';
import { toast } from 'sonner';

interface RetentionSettings {
  retentionPeriod: number;
  retentionUnit: 'days' | 'months' | 'years';
  autoArchive: boolean;
  archiveAfter: number;
  archiveUnit: 'days' | 'months';
  compressionEnabled: boolean;
  securityEventRetention: number;
  criticalEventRetention: number;
}

const AuditLogRetentionSettings: React.FC = () => {
  const [settings, setSettings] = useState<RetentionSettings>({
    retentionPeriod: 365,
    retentionUnit: 'days',
    autoArchive: true,
    archiveAfter: 90,
    archiveUnit: 'days',
    compressionEnabled: true,
    securityEventRetention: 2555, // 7 years in days
    criticalEventRetention: 1825 // 5 years in days
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // In a real implementation, this would save to the backend
      await new Promise((resolve) => setTimeout(resolve, 1000));

      toast.success('Retention settings saved successfully');
    } catch (error) {
      toast.error('Failed to save retention settings');
    } finally {
      setIsSaving(false);
    }
  };

  const calculateStorageImpact = () => {
    const baseStoragePerDay = 50; // MB per day estimated
    const retentionDays = settings.retentionUnit === 'days' ? settings.retentionPeriod :
    settings.retentionUnit === 'months' ? settings.retentionPeriod * 30 :
    settings.retentionPeriod * 365;

    const totalStorage = baseStoragePerDay * retentionDays;
    const compressionSavings = settings.compressionEnabled ? totalStorage * 0.6 : 0;

    return {
      estimatedStorage: totalStorage - compressionSavings,
      compressionSavings
    };
  };

  const storageImpact = calculateStorageImpact();

  return (
    <div className="space-y-6">
      {/* General Retention Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            General Retention Policy
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Standard Retention Period</Label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    value={settings.retentionPeriod}
                    onChange={(e) => setSettings({ ...settings, retentionPeriod: parseInt(e.target.value) || 0 })}
                    min="1"
                    className="flex-1" />

                  <Select
                    value={settings.retentionUnit}
                    onValueChange={(value: 'days' | 'months' | 'years') =>
                    setSettings({ ...settings, retentionUnit: value })
                    }>

                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="days">Days</SelectItem>
                      <SelectItem value="months">Months</SelectItem>
                      <SelectItem value="years">Years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-sm text-gray-600">
                  How long to keep regular audit logs before deletion.
                </p>
              </div>

              <Separator />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Auto-Archive</Label>
                    <p className="text-sm text-gray-600">
                      Automatically archive old logs to reduce storage
                    </p>
                  </div>
                  <Switch
                    checked={settings.autoArchive}
                    onCheckedChange={(checked) => setSettings({ ...settings, autoArchive: checked })} />

                </div>

                {settings.autoArchive &&
                <div className="space-y-2">
                    <Label>Archive After</Label>
                    <div className="flex gap-2">
                      <Input
                      type="number"
                      value={settings.archiveAfter}
                      onChange={(e) => setSettings({ ...settings, archiveAfter: parseInt(e.target.value) || 0 })}
                      min="1"
                      className="flex-1" />

                      <Select
                      value={settings.archiveUnit}
                      onValueChange={(value: 'days' | 'months') =>
                      setSettings({ ...settings, archiveUnit: value })
                      }>

                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="days">Days</SelectItem>
                          <SelectItem value="months">Months</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                }

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Compression</Label>
                    <p className="text-sm text-gray-600">
                      Enable compression to save storage space
                    </p>
                  </div>
                  <Switch
                    checked={settings.compressionEnabled}
                    onCheckedChange={(checked) => setSettings({ ...settings, compressionEnabled: checked })} />

                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Security Event Retention</Label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    value={settings.securityEventRetention}
                    onChange={(e) => setSettings({ ...settings, securityEventRetention: parseInt(e.target.value) || 0 })}
                    min="1" />

                  <span className="flex items-center px-3 text-sm text-gray-600">days</span>
                </div>
                <p className="text-sm text-gray-600">
                  Security events are kept longer for compliance.
                </p>
              </div>

              <div className="space-y-2">
                <Label>Critical Event Retention</Label>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    value={settings.criticalEventRetention}
                    onChange={(e) => setSettings({ ...settings, criticalEventRetention: parseInt(e.target.value) || 0 })}
                    min="1" />

                  <span className="flex items-center px-3 text-sm text-gray-600">days</span>
                </div>
                <p className="text-sm text-gray-600">
                  Critical events require extended retention.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Storage Impact */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Storage Impact Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 mb-1">
                {Math.round(storageImpact.estimatedStorage)}
              </div>
              <div className="text-sm text-gray-600">MB Estimated Storage</div>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600 mb-1">
                {Math.round(storageImpact.compressionSavings)}
              </div>
              <div className="text-sm text-gray-600">MB Compression Savings</div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600 mb-1">
                {settings.compressionEnabled ? '60%' : '0%'}
              </div>
              <div className="text-sm text-gray-600">Space Reduction</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Compliance Notice */}
      <Card className="border-amber-200 bg-amber-50">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5" />
            <div className="space-y-2">
              <h4 className="font-medium text-amber-800">Compliance Notice</h4>
              <p className="text-sm text-amber-700">
                Ensure your retention policy complies with applicable regulations (GDPR, SOX, HIPAA, etc.). 
                Security and critical events may have specific retention requirements in your jurisdiction.
              </p>
              <div className="flex items-center gap-2 text-sm text-amber-700">
                <Archive className="h-4 w-4" />
                <span>Consider legal consultation for retention policy changes</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ?
          <>Saving...</> :

          <>
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </>
          }
        </Button>
      </div>
    </div>);

};

export default AuditLogRetentionSettings;