import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, Activity, Shield, TrendingUp, Database, Users } from 'lucide-react';
import { toast } from 'sonner';

interface AuditStats {
  totalLogs: number;
  securityEvents: number;
  criticalEvents: number;
  todayLogs: number;
  activeUsers: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

const RealTimeAuditDashboard: React.FC = () => {
  const [stats, setStats] = useState<AuditStats>({
    totalLogs: 0,
    securityEvents: 0,
    criticalEvents: 0,
    todayLogs: 0,
    activeUsers: 0,
    riskLevel: 'LOW'
  });
  const [loading, setLoading] = useState(true);

  const fetchDashboardStats = async () => {
    try {
      setLoading(true);

      // Fetch today's logs
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { data: todayData, error: todayError } = await window.ezsite.apis.tablePage(37723, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'timestamp',
        IsAsc: false,
        Filters: [
        { name: 'timestamp', op: 'GreaterThanOrEqual', value: today.toISOString() }]

      });

      if (todayError) throw new Error(todayError);

      // Fetch security events
      const { data: securityData, error: securityError } = await window.ezsite.apis.tablePage(37723, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'timestamp',
        IsAsc: false,
        Filters: [
        { name: 'is_security_event', op: 'Equal', value: true }]

      });

      if (securityError) throw new Error(securityError);

      // Fetch critical events
      const { data: criticalData, error: criticalError } = await window.ezsite.apis.tablePage(37723, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'timestamp',
        IsAsc: false,
        Filters: [
        { name: 'severity', op: 'Equal', value: 'CRITICAL' }]

      });

      if (criticalError) throw new Error(criticalError);

      // Calculate stats
      const todayLogs = todayData?.VirtualCount || 0;
      const securityEvents = securityData?.VirtualCount || 0;
      const criticalEvents = criticalData?.VirtualCount || 0;

      // Simple risk calculation
      let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
      if (criticalEvents > 5) riskLevel = 'CRITICAL';else
      if (securityEvents > 10) riskLevel = 'HIGH';else
      if (securityEvents > 3) riskLevel = 'MEDIUM';

      setStats({
        totalLogs: todayLogs,
        securityEvents,
        criticalEvents,
        todayLogs,
        activeUsers: Math.floor(Math.random() * 50) + 10, // Mock data
        riskLevel
      });

    } catch (error) {
      console.error('Dashboard stats error:', error);
      toast.error('Failed to load dashboard statistics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardStats();
    // Refresh every 30 seconds
    const interval = setInterval(fetchDashboardStats, 30000);
    return () => clearInterval(interval);
  }, []);

  const getRiskBadge = (level: string) => {
    switch (level) {
      case 'CRITICAL':
        return <Badge variant="destructive" className="animate-pulse">Critical Risk</Badge>;
      case 'HIGH':
        return <Badge variant="destructive" className="bg-orange-500">High Risk</Badge>;
      case 'MEDIUM':
        return <Badge variant="outline" className="border-yellow-500 text-yellow-600">Medium Risk</Badge>;
      case 'LOW':
        return <Badge variant="secondary" className="bg-green-100 text-green-800">Low Risk</Badge>;
      default:
        return <Badge variant="secondary">{level}</Badge>;
    }
  };

  const getRiskPercentage = (level: string) => {
    switch (level) {
      case 'CRITICAL':return 90;
      case 'HIGH':return 70;
      case 'MEDIUM':return 45;
      case 'LOW':return 20;
      default:return 0;
    }
  };

  return (
    <div className="space-y-6">
      {/* Risk Level Alert */}
      <Card className={stats.riskLevel === 'CRITICAL' || stats.riskLevel === 'HIGH' ? 'border-red-500' : ''}>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Security Risk Level
            </span>
            {getRiskBadge(stats.riskLevel)}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Progress
              value={getRiskPercentage(stats.riskLevel)}
              className={`h-3 ${stats.riskLevel === 'CRITICAL' ? 'bg-red-100' : stats.riskLevel === 'HIGH' ? 'bg-orange-100' : 'bg-green-100'}`} />

            <p className="text-sm text-gray-600">
              {stats.riskLevel === 'CRITICAL' && 'Immediate attention required. Critical security events detected.'}
              {stats.riskLevel === 'HIGH' && 'High security activity detected. Monitor closely.'}
              {stats.riskLevel === 'MEDIUM' && 'Moderate security activity. Continue monitoring.'}
              {stats.riskLevel === 'LOW' && 'System operating normally. Low security risk.'}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Activity</CardTitle>
            <Activity className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.todayLogs.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">audit entries today</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Security Events</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.securityEvents}</div>
            <p className="text-xs text-muted-foreground">requiring attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Events</CardTitle>
            <Database className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.criticalEvents}</div>
            <p className="text-xs text-muted-foreground">high priority items</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Users className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.activeUsers}</div>
            <p className="text-xs text-muted-foreground">in current session</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            System Health Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600 mb-1">98.5%</div>
                <div className="text-sm text-gray-600">System Uptime</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600 mb-1">2.3s</div>
                <div className="text-sm text-gray-600">Avg Response</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600 mb-1">99.1%</div>
                <div className="text-sm text-gray-600">Success Rate</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default RealTimeAuditDashboard;