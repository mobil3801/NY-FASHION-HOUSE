import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Eye, AlertTriangle, Shield, Clock } from 'lucide-react';
import { AuditLog } from '@/types/audit';
import { format } from 'date-fns';
import LoadingSpinner from '@/components/LoadingSpinner';

interface AuditLogTableProps {
  logs: AuditLog[];
  onViewDetails: (log: AuditLog) => void;
  loading?: boolean;
}

const AuditLogTable: React.FC<AuditLogTableProps> = ({
  logs,
  onViewDetails,
  loading = false
}) => {
  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'CRITICAL':
        return <Badge variant="destructive">Critical</Badge>;
      case 'HIGH':
        return <Badge variant="destructive" className="bg-orange-500">High</Badge>;
      case 'MEDIUM':
        return <Badge variant="outline" className="border-yellow-500 text-yellow-600">Medium</Badge>;
      case 'LOW':
        return <Badge variant="secondary">Low</Badge>;
      default:
        return <Badge variant="secondary">{severity}</Badge>;
    }
  };

  const getActionBadge = (action: string) => {
    const actionColors = {
      CREATE: 'bg-green-100 text-green-800',
      UPDATE: 'bg-blue-100 text-blue-800',
      DELETE: 'bg-red-100 text-red-800',
      LOGIN: 'bg-purple-100 text-purple-800',
      LOGOUT: 'bg-gray-100 text-gray-800'
    };

    return (
      <Badge
        variant="secondary"
        className={actionColors[action as keyof typeof actionColors] || 'bg-gray-100 text-gray-800'}>

        {action}
      </Badge>);

  };

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <LoadingSpinner />
      </div>);

  }

  if (logs.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No audit logs found matching your criteria.</p>
      </div>);

  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[150px]">Timestamp</TableHead>
            <TableHead>User</TableHead>
            <TableHead>Action</TableHead>
            <TableHead>Table</TableHead>
            <TableHead>Severity</TableHead>
            <TableHead>Security</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {logs.map((log) =>
          <TableRow key={log.id}>
              <TableCell className="font-medium">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">
                    {format(new Date(log.timestamp), 'MMM dd, HH:mm')}
                  </span>
                </div>
              </TableCell>
              <TableCell>
                <div>
                  <div className="font-medium">{log.user_name}</div>
                  <div className="text-sm text-gray-500">{log.user_email}</div>
                </div>
              </TableCell>
              <TableCell>
                {getActionBadge(log.action)}
              </TableCell>
              <TableCell>
                <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                  {log.table_name}
                </code>
              </TableCell>
              <TableCell>
                {getSeverityBadge(log.severity)}
              </TableCell>
              <TableCell>
                {log.is_security_event ?
              <div className="flex items-center gap-1 text-red-600">
                    <AlertTriangle className="h-4 w-4" />
                    <span className="text-sm">Security</span>
                  </div> :

              <div className="flex items-center gap-1 text-gray-500">
                    <Shield className="h-4 w-4" />
                    <span className="text-sm">Regular</span>
                  </div>
              }
              </TableCell>
              <TableCell className="text-right">
                <Button
                variant="ghost"
                size="sm"
                onClick={() => onViewDetails(log)}>

                  <Eye className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>);

};

export default AuditLogTable;