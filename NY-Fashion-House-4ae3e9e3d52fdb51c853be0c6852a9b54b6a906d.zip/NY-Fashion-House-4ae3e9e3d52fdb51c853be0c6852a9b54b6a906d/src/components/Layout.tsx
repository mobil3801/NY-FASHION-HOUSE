
import React from 'react';
import { Outlet } from 'react-router-dom';
import DashboardHeader from '@/components/DashboardHeader';

const Layout: React.FC = () => {
  return (
    <div className="min-h-screen transition-colors duration-300" style={{ backgroundColor: 'var(--theme-background)' }}>
      <DashboardHeader />
      
      <main className="min-h-[calc(100vh-64px)]">
        <div className="p-4 sm:p-6">
          <Outlet />
        </div>
      </main>
    </div>);

};

export default Layout;