
import React, { useState, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import LoadingSpinner from '@/components/LoadingSpinner';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, Edit, Trash2, Search, Building, Phone, Mail, MapPin, X } from 'lucide-react';
import { toast } from 'sonner';
import { useIsMobile } from '@/hooks/use-mobile';

interface SupplierFormData {
  serial?: string;
  name: string;
  contact_person: string;
  email: string;
  phone: string;
  address: string;
  payment_terms: string;
  status: 'active' | 'inactive';
}

interface Supplier extends SupplierFormData {
  id: number;
  created_at: string;
  updated_at: string;
}

const SupplierManagement: React.FC = () => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState<SupplierFormData>({
    name: '',
    contact_person: '',
    email: '',
    phone: '',
    address: '',
    payment_terms: 'Net 30',
    status: 'active'
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [maxSerial, setMaxSerial] = useState(0);

  const isMobile = useIsMobile();
  const queryClient = useQueryClient();

  useEffect(() => {
    loadSuppliers();
  }, []);

  const loadSuppliers = async () => {
    try {
      setLoading(true);
      const { data, error } = await window.ezsite.apis.tablePage(38564, {
        "PageNo": 1,
        "PageSize": 1000,
        "OrderByField": "id",
        "IsAsc": false,
        "Filters": []
      });

      if (error) throw error;

      setSuppliers(data.List || []);

      // Calculate the maximum serial number for auto-increment
      const serialNumbers = data.List?.
      map((s: any) => parseInt(s.name?.match(/^\d+/)?.[0] || '0')).
      filter((n: number) => !isNaN(n)) || [];
      setMaxSerial(serialNumbers.length > 0 ? Math.max(...serialNumbers) : 0);
    } catch (error) {
      console.error('Error loading suppliers:', error);
      toast.error('Failed to load suppliers');
    } finally {
      setLoading(false);
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    // Only validate format if values are provided, no required field validation
    if (formData.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (formData.phone.trim() && !/^\+1\s\(\d{3}\)\s\d{3}-\d{4}$/.test(formData.phone)) {
      errors.phone = 'Phone must be in format: +1 (###) ###-####';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const formatPhoneNumber = (value: string): string => {
    // Remove all non-digit characters
    const digits = value.replace(/\D/g, '');

    // If the number starts with 1, remove it (US country code)
    const cleanDigits = digits.startsWith('1') ? digits.slice(1) : digits;

    // Apply format +1 (###) ###-####
    if (cleanDigits.length >= 10) {
      const area = cleanDigits.slice(0, 3);
      const middle = cleanDigits.slice(3, 6);
      const last = cleanDigits.slice(6, 10);
      return `+1 (${area}) ${middle}-${last}`;
    } else if (cleanDigits.length >= 6) {
      const area = cleanDigits.slice(0, 3);
      const middle = cleanDigits.slice(3, 6);
      const last = cleanDigits.slice(6);
      return `+1 (${area}) ${middle}-${last}`;
    } else if (cleanDigits.length >= 3) {
      const area = cleanDigits.slice(0, 3);
      const middle = cleanDigits.slice(3);
      return `+1 (${area}) ${middle}`;
    } else if (cleanDigits.length > 0) {
      return `+1 (${cleanDigits}`;
    }

    return '+1 (';
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneNumber(e.target.value);
    setFormData((prev) => ({ ...prev, phone: formatted }));
  };

  const resetForm = () => {
    const nextSerial = (maxSerial + 1).toString().padStart(4, '0');
    setFormData({
      name: '',
      contact_person: '',
      email: '',
      phone: '',
      address: '',
      payment_terms: 'Net 30',
      status: 'active'
    });
    setFormErrors({});
    setEditingSupplier(null);
  };

  const openAddForm = () => {
    resetForm();
    setIsFormOpen(true);
  };

  const openEditForm = (supplier: Supplier) => {
    setFormData({
      name: supplier.name,
      contact_person: supplier.contact_person,
      email: supplier.email,
      phone: supplier.phone,
      address: supplier.address,
      payment_terms: supplier.payment_terms,
      status: supplier.status
    });
    setEditingSupplier(supplier);
    setFormErrors({});
    setIsFormOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Still validate format but don't prevent submission
    validateForm();

    setSubmitting(true);

    try {
      const submitData = { ...formData };

      // Auto-generate serial number for new suppliers
      if (!editingSupplier) {
        const nextSerial = (maxSerial + 1).toString().padStart(4, '0');
        submitData.name = `${nextSerial} - ${submitData.name}`;
      }

      if (editingSupplier) {
        // Update existing supplier
        const { error } = await window.ezsite.apis.tableUpdate(38564, {
          id: editingSupplier.id,
          ...submitData
        });

        if (error) throw error;
        toast.success('Supplier updated successfully');
      } else {
        // Create new supplier
        const { error } = await window.ezsite.apis.tableCreate(38564, submitData);

        if (error) throw error;
        toast.success('Supplier added successfully');
        setMaxSerial((prev) => prev + 1);
      }

      setIsFormOpen(false);
      resetForm();
      await loadSuppliers();

      // Invalidate suppliers query to update any dropdown in ProductForm
      queryClient.invalidateQueries({ queryKey: ['suppliers'] });
    } catch (error) {
      console.error('Error saving supplier:', error);
      toast.error(`Failed to ${editingSupplier ? 'update' : 'add'} supplier: ${error}`);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (supplier: Supplier) => {
    if (!confirm(`Are you sure you want to delete "${supplier.name}"?`)) {
      return;
    }

    try {
      const { error } = await window.ezsite.apis.tableDelete(38564, { id: supplier.id });

      if (error) throw error;

      toast.success('Supplier deleted successfully');
      await loadSuppliers();

      // Invalidate suppliers query to update any dropdown in ProductForm
      queryClient.invalidateQueries({ queryKey: ['suppliers'] });
    } catch (error) {
      console.error('Error deleting supplier:', error);
      toast.error(`Failed to delete supplier: ${error}`);
    }
  };

  const filteredSuppliers = suppliers.filter((supplier) =>
  supplier.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
  supplier.contact_person?.toLowerCase().includes(searchQuery.toLowerCase()) ||
  supplier.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
  supplier.phone?.includes(searchQuery)
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>);

  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Supplier Management
            </CardTitle>
            <Button onClick={openAddForm} className="w-full sm:w-auto">
              <Plus className="h-4 w-4 mr-2" />
              Add Supplier
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search suppliers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10" />

          </div>

          {/* Suppliers Table */}
          <div className="border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Supplier</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Address</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSuppliers.map((supplier) =>
                  <TableRow key={supplier.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{supplier.name}</p>
                          <p className="text-sm text-gray-600">{supplier.contact_person}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-1 text-sm">
                            <Phone className="w-3 h-3" />
                            {supplier.phone}
                          </div>
                          <div className="flex items-center gap-1 text-sm">
                            <Mail className="w-3 h-3" />
                            {supplier.email}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-start gap-1 text-sm">
                          <MapPin className="w-3 h-3 mt-1 flex-shrink-0" />
                          <span className="line-clamp-2">{supplier.address}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={supplier.status === 'active' ? 'default' : 'secondary'}>
                          {supplier.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openEditForm(supplier)}>

                            <Edit className="w-3 h-3" />
                            {!isMobile && <span className="ml-1">Edit</span>}
                          </Button>
                          <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(supplier)}>

                            <Trash2 className="w-3 h-3" />
                            {!isMobile && <span className="ml-1">Delete</span>}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>

          {filteredSuppliers.length === 0 &&
          <div className="text-center py-8">
              <Building className="w-12 h-12 mx-auto text-gray-400 mb-3" />
              <p className="text-gray-600 font-medium">No suppliers found</p>
              <p className="text-sm text-gray-500">
                {searchQuery ? 'Try adjusting your search criteria' : 'Add suppliers to manage your supply chain'}
              </p>
            </div>
          }
        </CardContent>
      </Card>

      {/* Add/Edit Supplier Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingSupplier ? 'Edit Supplier' : 'Add New Supplier'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Serial Number Display for New Suppliers */}
            {!editingSupplier &&
            <div>
                <Label>Serial Number</Label>
                <div className="p-2 bg-gray-50 rounded border text-sm font-mono">
                  {(maxSerial + 1).toString().padStart(4, '0')} (Auto-generated)
                </div>
              </div>
            }

            {/* Supplier Name */}
            <div>
              <Label htmlFor="name">Supplier Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                className={formErrors.name ? 'border-red-500' : ''} />

              {formErrors.name &&
              <p className="text-sm text-red-500 mt-1">{formErrors.name}</p>
              }
            </div>

            {/* Contact Person */}
            <div>
              <Label htmlFor="contact_person">Contact Person</Label>
              <Input
                id="contact_person"
                value={formData.contact_person}
                onChange={(e) => setFormData((prev) => ({ ...prev, contact_person: e.target.value }))}
                className={formErrors.contact_person ? 'border-red-500' : ''} />

              {formErrors.contact_person &&
              <p className="text-sm text-red-500 mt-1">{formErrors.contact_person}</p>
              }
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Email */}
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                  className={formErrors.email ? 'border-red-500' : ''} />

                {formErrors.email &&
                <p className="text-sm text-red-500 mt-1">{formErrors.email}</p>
                }
              </div>

              {/* Phone */}
              <div>
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={handlePhoneChange}
                  placeholder="+1 (###) ###-####"
                  className={formErrors.phone ? 'border-red-500' : ''} />

                {formErrors.phone &&
                <p className="text-sm text-red-500 mt-1">{formErrors.phone}</p>
                }
              </div>
            </div>

            {/* Address */}
            <div>
              <Label htmlFor="address">Address</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData((prev) => ({ ...prev, address: e.target.value }))}
                className={formErrors.address ? 'border-red-500' : ''}
                rows={3} />

              {formErrors.address &&
              <p className="text-sm text-red-500 mt-1">{formErrors.address}</p>
              }
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Payment Terms */}
              <div>
                <Label htmlFor="payment_terms">Payment Terms</Label>
                <Select value={formData.payment_terms} onValueChange={(value) =>
                setFormData((prev) => ({ ...prev, payment_terms: value }))
                }>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Net 15">Net 15</SelectItem>
                    <SelectItem value="Net 30">Net 30</SelectItem>
                    <SelectItem value="Net 45">Net 45</SelectItem>
                    <SelectItem value="Net 60">Net 60</SelectItem>
                    <SelectItem value="Cash on Delivery">Cash on Delivery</SelectItem>
                    <SelectItem value="Advance Payment">Advance Payment</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Status */}
              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value: 'active' | 'inactive') =>
                setFormData((prev) => ({ ...prev, status: value }))
                }>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsFormOpen(false)}
                className="w-full sm:w-auto">

                Cancel
              </Button>
              <Button
                type="submit"
                disabled={submitting}
                className="w-full sm:w-auto">

                {submitting ?
                <LoadingSpinner className="w-4 h-4 mr-2" /> :
                null}
                {editingSupplier ? 'Update' : 'Add'} Supplier
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>);

};

export default SupplierManagement;