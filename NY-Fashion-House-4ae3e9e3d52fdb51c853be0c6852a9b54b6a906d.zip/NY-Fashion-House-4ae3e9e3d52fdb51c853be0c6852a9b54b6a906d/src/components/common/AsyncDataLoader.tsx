import React from 'react';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorDisplay from '@/components/ErrorDisplay';
import { useAsyncOperation } from '@/hooks/use-async-operation';

interface AsyncDataLoaderProps<T> {
  loadData: () => Promise<T>;
  onDataLoaded?: (data: T) => void;
  children: (data: T) => React.ReactNode;
  loadingText?: string;
  errorTitle?: string;
  retryEnabled?: boolean;
  className?: string;
}

function AsyncDataLoader<T>({
  loadData,
  onDataLoaded,
  children,
  loadingText = 'Loading...',
  errorTitle = 'Failed to load data',
  retryEnabled = true,
  className = ''
}: AsyncDataLoaderProps<T>) {
  const { data, loading, error, execute, reset } = useAsyncOperation<T>({
    onSuccess: onDataLoaded
  });

  React.useEffect(() => {
    execute(loadData);
  }, []);

  const handleRetry = () => {
    reset();
    execute(loadData);
  };

  if (loading) {
    return (
      <div className={`flex justify-center items-center py-8 ${className}`}>
        <LoadingSpinner text={loadingText} />
      </div>);

  }

  if (error) {
    return (
      <div className={className}>
        <ErrorDisplay
          error={error}
          title={errorTitle}
          onRetry={retryEnabled ? handleRetry : undefined}
          variant="card" />

      </div>);

  }

  if (!data) {
    return (
      <div className={`flex justify-center items-center py-8 text-gray-500 ${className}`}>
        No data available
      </div>);

  }

  return <>{children(data)}</>;
}

export default AsyncDataLoader;