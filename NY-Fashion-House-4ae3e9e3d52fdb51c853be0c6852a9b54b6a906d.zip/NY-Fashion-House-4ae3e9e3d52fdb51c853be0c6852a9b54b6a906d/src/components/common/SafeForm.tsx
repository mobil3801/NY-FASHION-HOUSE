import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorDisplay from '@/components/ErrorDisplay';
import { useAsyncOperation } from '@/hooks/use-async-operation';
import { AlertTriangle, CheckCircle } from 'lucide-react';
import ErrorBoundary from '@/components/ErrorBoundary';

interface SafeFormProps {
  onSubmit: (formData: FormData) => Promise<any>;
  onSuccess?: (result: any) => void;
  onError?: (error: Error) => void;
  children: React.ReactNode;
  submitButtonText?: string;
  successMessage?: string;
  className?: string;
  resetOnSuccess?: boolean;
}

const SafeForm: React.FC<SafeFormProps> = ({
  onSubmit,
  onSuccess,
  onError,
  children,
  submitButtonText = 'Submit',
  successMessage = 'Form submitted successfully',
  className = '',
  resetOnSuccess = false
}) => {
  const [formRef, setFormRef] = useState<HTMLFormElement | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  const { loading, error, execute, reset } = useAsyncOperation({
    showToast: true,
    showSuccessToast: true,
    successMessage,
    onSuccess: (result) => {
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);

      if (resetOnSuccess && formRef) {
        formRef.reset();
      }

      if (onSuccess) {
        onSuccess(result);
      }
    },
    onError
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    execute(() => onSubmit(formData));
  };

  const handleReset = () => {
    reset();
    setShowSuccess(false);
    if (formRef) {
      formRef.reset();
    }
  };

  return (
    <ErrorBoundary level="component" showDetails={false}>
      <div className={className}>
        {showSuccess &&
        <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-md flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span className="text-green-800 text-sm">{successMessage}</span>
          </div>
        }

        {error &&
        <div className="mb-4">
            <ErrorDisplay
            error={error}
            title="Form Submission Failed"
            variant="inline"
            onRetry={() => {
              if (formRef) {
                const formData = new FormData(formRef);
                execute(() => onSubmit(formData));
              }
            }} />

          </div>
        }

        <form
          ref={setFormRef}
          onSubmit={handleSubmit}
          className="space-y-4">

          {children}
          
          <div className="flex gap-2 pt-4">
            <Button
              type="submit"
              disabled={loading}
              className="flex-1">

              {loading ?
              <>
                  <LoadingSpinner size="sm" />
                  <span className="ml-2">Processing...</span>
                </> :

              submitButtonText
              }
            </Button>
            
            {(error || showSuccess) &&
            <Button
              type="button"
              variant="outline"
              onClick={handleReset}
              disabled={loading}>

                Reset
              </Button>
            }
          </div>
        </form>
      </div>
    </ErrorBoundary>);

};

export default SafeForm;