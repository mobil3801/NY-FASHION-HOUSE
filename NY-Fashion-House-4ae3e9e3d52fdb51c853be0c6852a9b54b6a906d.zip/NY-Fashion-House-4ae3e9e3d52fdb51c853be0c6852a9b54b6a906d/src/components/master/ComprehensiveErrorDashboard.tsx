import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { Progress } from '../ui/progress';
import { Switch } from '../ui/switch';
import { Label } from '../ui/label';
import {
  AlertTriangle,
  Activity,
  TrendingUp,
  Settings,
  RefreshCw,
  Download,
  Eye,
  Search,
  Filter,
  BarChart3,
  PieChart,
  Clock,
  Bug,
  CheckCircle,
  XCircle,
  Info } from
'lucide-react';
import { MasterErrorManager } from '../../services/masterErrorManager';
import { DevToolsIntegration } from '../../utils/devToolsIntegration';
import { ErrorPatternDetector, ErrorPattern, ErrorStatistics } from '../../utils/errorPatternDetector';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart as RechartsPieChart, Cell } from 'recharts';

interface ComprehensiveErrorDashboardProps {
  className?: string;
}

export function ComprehensiveErrorDashboard({ className }: ComprehensiveErrorDashboardProps) {
  const [errorManager] = useState(() => new MasterErrorManager());
  const [devTools] = useState(() => new DevToolsIntegration());
  const [patternDetector] = useState(() => new ErrorPatternDetector());

  const [statistics, setStatistics] = useState<ErrorStatistics>({
    totalErrors: 0,
    errorsByLevel: {},
    errorsByCategory: {},
    topPatterns: [],
    recentTrends: []
  });

  const [patterns, setPatterns] = useState<ErrorPattern[]>([]);
  const [insights, setInsights] = useState<string[]>([]);
  const [devToolsErrors, setDevToolsErrors] = useState<any[]>([]);
  const [realTimeMode, setRealTimeMode] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedPattern, setSelectedPattern] = useState<ErrorPattern | null>(null);

  // Color palette for charts
  const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6', '#ec4899'];

  useEffect(() => {
    loadData();

    if (autoRefresh) {
      const interval = setInterval(loadData, 30000); // Refresh every 30 seconds
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  useEffect(() => {
    if (realTimeMode) {
      // Set up real-time error monitoring
      const handleRealTimeError = (event: CustomEvent) => {
        loadData();
      };

      window.addEventListener('error-captured' as any, handleRealTimeError);
      return () => window.removeEventListener('error-captured' as any, handleRealTimeError);
    }
  }, [realTimeMode]);

  const loadData = async () => {
    try {
      setIsRefreshing(true);

      // Load statistics and patterns
      const stats = errorManager.getErrorStatistics();
      const patternsList = errorManager.getErrorPatterns();
      const devErrors = devTools.getDevToolsErrors();
      const generatedInsights = patternDetector.generateInsights();

      setStatistics(stats);
      setPatterns(patternsList);
      setDevToolsErrors(devErrors);
      setInsights(generatedInsights);
    } catch (error) {
      console.error('Failed to load error dashboard data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleExportData = () => {
    const exportData = {
      statistics,
      patterns,
      insights,
      devToolsErrors,
      timestamp: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `error-report-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleClearDevToolsErrors = () => {
    devTools.clearDevToolsErrors();
    setDevToolsErrors([]);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':return 'text-red-600 bg-red-50 border-red-200';
      case 'high':return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'medium':return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low':return 'text-green-600 bg-green-50 border-green-200';
      default:return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':return <XCircle className="h-4 w-4" />;
      case 'high':return <AlertTriangle className="h-4 w-4" />;
      case 'medium':return <Info className="h-4 w-4" />;
      case 'low':return <CheckCircle className="h-4 w-4" />;
      default:return <Bug className="h-4 w-4" />;
    }
  };

  // Prepare chart data
  const levelChartData = Object.entries(statistics.errorsByLevel).map(([level, count]) => ({
    level,
    count,
    fill: COLORS[Object.keys(statistics.errorsByLevel).indexOf(level) % COLORS.length]
  }));

  const categoryChartData = Object.entries(statistics.errorsByCategory).map(([category, count]) => ({
    category,
    count,
    fill: COLORS[Object.keys(statistics.errorsByCategory).indexOf(category) % COLORS.length]
  }));

  const trendChartData = statistics.recentTrends.map((trend) => ({
    time: new Date(trend.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    errors: trend.count
  }));

  return (
    <div className={`p-6 space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Error Monitoring Dashboard</h1>
          <p className="text-gray-600">Comprehensive error tracking and analysis</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="real-time"
              checked={realTimeMode}
              onCheckedChange={setRealTimeMode} />

            <Label htmlFor="real-time">Real-time</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch
              id="auto-refresh"
              checked={autoRefresh}
              onCheckedChange={setAutoRefresh} />

            <Label htmlFor="auto-refresh">Auto-refresh</Label>
          </div>
          
          <Button variant="outline" onClick={loadData} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          
          <Button variant="outline" onClick={handleExportData}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Insights Alert */}
      {insights.length > 0 &&
      <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Automated Insights</AlertTitle>
          <AlertDescription>
            <ul className="mt-2 space-y-1">
              {insights.map((insight, index) =>
            <li key={index} className="text-sm">{insight}</li>
            )}
            </ul>
          </AlertDescription>
        </Alert>
      }

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Errors</CardTitle>
            <Bug className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{statistics.totalErrors}</div>
            <p className="text-xs text-muted-foreground">
              {statistics.recentTrends.length > 0 ?
              `${statistics.recentTrends[statistics.recentTrends.length - 1]?.count || 0} in last hour` :
              'No recent data'
              }
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Patterns</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patterns.length}</div>
            <p className="text-xs text-muted-foreground">
              {patterns.filter((p) => p.severity === 'critical').length} critical
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">DevTools Errors</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{devToolsErrors.length}</div>
            <p className="text-xs text-muted-foreground">Development mode</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {statistics.totalErrors < 50 ? 'Good' :
              statistics.totalErrors < 100 ? 'Fair' : 'Poor'}
            </div>
            <Progress
              value={Math.max(0, 100 - statistics.totalErrors / 10)}
              className="mt-2" />

          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="patterns">Error Patterns</TabsTrigger>
          <TabsTrigger value="trends">Trends & Analytics</TabsTrigger>
          <TabsTrigger value="devtools">DevTools</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Errors by Level */}
            <Card>
              <CardHeader>
                <CardTitle>Errors by Level</CardTitle>
                <CardDescription>Distribution of errors by severity level</CardDescription>
              </CardHeader>
              <CardContent>
                {levelChartData.length > 0 ?
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={levelChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="level" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer> :

                <div className="flex items-center justify-center h-[300px] text-gray-500">
                    No data available
                  </div>
                }
              </CardContent>
            </Card>

            {/* Errors by Category */}
            <Card>
              <CardHeader>
                <CardTitle>Errors by Category</CardTitle>
                <CardDescription>Categorization of error types</CardDescription>
              </CardHeader>
              <CardContent>
                {categoryChartData.length > 0 ?
                <ResponsiveContainer width="100%" height={300}>
                    <RechartsPieChart>
                      <RechartsPieChart
                      data={categoryChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={5}>

                        {categoryChartData.map((entry, index) =>
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                      )}
                      </RechartsPieChart>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer> :

                <div className="flex items-center justify-center h-[300px] text-gray-500">
                    No data available
                  </div>
                }
              </CardContent>
            </Card>
          </div>

          {/* Recent Error Trends */}
          <Card>
            <CardHeader>
              <CardTitle>Error Trends (Last 24 Hours)</CardTitle>
              <CardDescription>Hourly error occurrence patterns</CardDescription>
            </CardHeader>
            <CardContent>
              {trendChartData.length > 0 ?
              <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={trendChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line
                    type="monotone"
                    dataKey="errors"
                    stroke="#ef4444"
                    strokeWidth={2}
                    dot={{ fill: '#ef4444', strokeWidth: 2, r: 4 }} />

                  </LineChart>
                </ResponsiveContainer> :

              <div className="flex items-center justify-center h-[300px] text-gray-500">
                  No trend data available
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Error Patterns Analysis</CardTitle>
              <CardDescription>Detected error patterns and their frequencies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {patterns.length > 0 ?
                patterns.map((pattern) =>
                <div
                  key={pattern.id}
                  className={`border rounded-lg p-4 cursor-pointer hover:bg-gray-50 ${
                  selectedPattern?.id === pattern.id ? 'ring-2 ring-blue-500' : ''}`
                  }
                  onClick={() => setSelectedPattern(pattern)}>

                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {getSeverityIcon(pattern.severity)}
                          <Badge variant={
                      pattern.severity === 'critical' ? 'destructive' :
                      pattern.severity === 'high' ? 'destructive' :
                      'secondary'
                      }>
                            {pattern.severity}
                          </Badge>
                          <Badge variant="outline">{pattern.category}</Badge>
                        </div>
                        <div className="flex items-center space-x-2 text-sm text-gray-600">
                          <span>{pattern.frequency} occurrences</span>
                          <Clock className="h-3 w-3" />
                          <span>{new Date(pattern.lastSeen).toLocaleDateString()}</span>
                        </div>
                      </div>
                      
                      <h4 className="font-semibold mb-1">{pattern.description}</h4>
                      <p className="text-sm text-gray-600 mb-2">{pattern.suggestedFix}</p>
                      
                      <div className="text-xs text-gray-500 font-mono bg-gray-100 p-2 rounded">
                        Pattern: {pattern.pattern.source}
                      </div>
                    </div>
                ) :

                <div className="text-center py-8 text-gray-500">
                    No error patterns detected yet
                  </div>
                }
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Error Patterns</CardTitle>
                <CardDescription>Most frequent error patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {statistics.topPatterns.slice(0, 5).map((pattern, index) =>
                  <div key={pattern.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <span className="font-bold text-gray-400">#{index + 1}</span>
                        {getSeverityIcon(pattern.severity)}
                        <span className="font-medium truncate">{pattern.description.substring(0, 50)}...</span>
                      </div>
                      <Badge variant="outline">{pattern.frequency}</Badge>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Performance Impact</CardTitle>
                <CardDescription>Error impact on system performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Error Processing Overhead</span>
                    <Badge variant="secondary">Minimal</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Pattern Detection Efficiency</span>
                    <Badge variant="secondary">Optimized</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Storage Usage</span>
                    <Badge variant="secondary">Under Control</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="devtools" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Development Tools Integration</CardTitle>
                <CardDescription>Errors captured during development</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={handleClearDevToolsErrors}>
                Clear All
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {devToolsErrors.length > 0 ?
                devToolsErrors.map((error, index) =>
                <div key={error.id || index} className="border rounded-lg p-3 bg-gray-50">
                      <div className="flex items-center justify-between mb-2">
                        <Badge variant={error.level === 'error' ? 'destructive' : 'secondary'}>
                          {error.level}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {new Date(error.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm font-medium mb-1">{error.message}</p>
                      {error.stack &&
                  <details className="text-xs">
                          <summary className="cursor-pointer text-gray-600">Stack trace</summary>
                          <pre className="mt-1 bg-white p-2 rounded border overflow-x-auto">
                            {error.stack}
                          </pre>
                        </details>
                  }
                    </div>
                ) :

                <div className="text-center py-8 text-gray-500">
                    No development errors captured
                  </div>
                }
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

}