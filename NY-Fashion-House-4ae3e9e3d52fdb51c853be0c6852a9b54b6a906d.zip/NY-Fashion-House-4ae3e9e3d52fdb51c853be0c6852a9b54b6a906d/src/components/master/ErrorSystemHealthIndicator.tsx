import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Alert, AlertDescription } from '../ui/alert';
import {
  Shield,
  AlertTriangle,
  CheckCircle,
  Activity,
  Zap,
  TrendingUp,
  Clock,
  BarChart3 } from
'lucide-react';
import { MasterErrorManager } from '../../services/masterErrorManager';

interface SystemHealthProps {
  className?: string;
  refreshInterval?: number;
}

interface HealthMetrics {
  totalErrors: number;
  criticalErrors: number;
  errorRate: number;
  systemHealth: 'excellent' | 'good' | 'fair' | 'poor' | 'critical';
  memoryUsage?: number;
  responseTime: number;
  uptime: number;
  errorTrends: {timestamp: number;count: number;}[];
}

export function ErrorSystemHealthIndicator({
  className,
  refreshInterval = 30000
}: SystemHealthProps) {
  const [errorManager] = useState(() => new MasterErrorManager());
  const [healthMetrics, setHealthMetrics] = useState<HealthMetrics>({
    totalErrors: 0,
    criticalErrors: 0,
    errorRate: 0,
    systemHealth: 'excellent',
    responseTime: 0,
    uptime: 0,
    errorTrends: []
  });
  const [isLoading, setIsLoading] = useState(true);

  const calculateHealth = (metrics: Partial<HealthMetrics>): HealthMetrics['systemHealth'] => {
    const { totalErrors = 0, criticalErrors = 0, errorRate = 0 } = metrics;

    if (criticalErrors > 0 || errorRate > 10) return 'critical';
    if (totalErrors > 100 || errorRate > 5) return 'poor';
    if (totalErrors > 50 || errorRate > 2) return 'fair';
    if (totalErrors > 10 || errorRate > 0.5) return 'good';
    return 'excellent';
  };

  const getHealthColor = (health: HealthMetrics['systemHealth']) => {
    switch (health) {
      case 'excellent':return 'text-green-600';
      case 'good':return 'text-blue-600';
      case 'fair':return 'text-yellow-600';
      case 'poor':return 'text-orange-600';
      case 'critical':return 'text-red-600';
    }
  };

  const getHealthIcon = (health: HealthMetrics['systemHealth']) => {
    switch (health) {
      case 'excellent':return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'good':return <CheckCircle className="h-5 w-5 text-blue-600" />;
      case 'fair':return <AlertTriangle className="h-5 w-5 text-yellow-600" />;
      case 'poor':return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      case 'critical':return <AlertTriangle className="h-5 w-5 text-red-600" />;
    }
  };

  const getHealthPercentage = (health: HealthMetrics['systemHealth']) => {
    switch (health) {
      case 'excellent':return 100;
      case 'good':return 80;
      case 'fair':return 60;
      case 'poor':return 40;
      case 'critical':return 20;
    }
  };

  useEffect(() => {
    const loadHealthMetrics = async () => {
      try {
        setIsLoading(true);

        // Get error statistics
        const stats = errorManager.getErrorStatistics();
        const patterns = errorManager.getErrorPatterns();

        // Calculate metrics
        const criticalPatterns = patterns.filter((p) => p.severity === 'critical');
        const recentErrors = stats.recentTrends.
        filter((t) => t.timestamp > Date.now() - 24 * 60 * 60 * 1000).
        reduce((sum, t) => sum + t.count, 0);

        const errorRate = recentErrors / 24; // Errors per hour
        const responseTime = performance.now(); // Simplified
        const uptime = Date.now() - (window as any).appStartTime || 0;

        const metrics: HealthMetrics = {
          totalErrors: stats.totalErrors,
          criticalErrors: criticalPatterns.length,
          errorRate,
          systemHealth: calculateHealth({
            totalErrors: stats.totalErrors,
            criticalErrors: criticalPatterns.length,
            errorRate
          }),
          memoryUsage: (performance as any).memory?.usedJSHeapSize,
          responseTime,
          uptime,
          errorTrends: stats.recentTrends
        };

        setHealthMetrics(metrics);
      } catch (error) {
        console.error('Failed to load health metrics:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadHealthMetrics();

    const interval = setInterval(loadHealthMetrics, refreshInterval);
    return () => clearInterval(interval);
  }, [errorManager, refreshInterval]);

  const formatUptime = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor(ms % (1000 * 60 * 60) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="h-5 w-5 mr-2 animate-pulse" />
            System Health
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
            <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Shield className="h-5 w-5 mr-2" />
            System Health
          </div>
          <Badge variant={
          healthMetrics.systemHealth === 'excellent' || healthMetrics.systemHealth === 'good' ?
          'default' :
          healthMetrics.systemHealth === 'critical' ?
          'destructive' :
          'secondary'
          }>
            {healthMetrics.systemHealth.toUpperCase()}
          </Badge>
        </CardTitle>
        <CardDescription>
          Real-time error management system status
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Health Score */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Overall Health</span>
            <div className="flex items-center space-x-2">
              {getHealthIcon(healthMetrics.systemHealth)}
              <span className={`text-sm font-medium ${getHealthColor(healthMetrics.systemHealth)}`}>
                {getHealthPercentage(healthMetrics.systemHealth)}%
              </span>
            </div>
          </div>
          <Progress value={getHealthPercentage(healthMetrics.systemHealth)} className="h-2" />
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <div className="flex items-center text-sm">
              <BarChart3 className="h-3 w-3 mr-1 text-blue-500" />
              Total Errors
            </div>
            <div className="text-lg font-semibold">{healthMetrics.totalErrors}</div>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center text-sm">
              <AlertTriangle className="h-3 w-3 mr-1 text-red-500" />
              Critical Issues
            </div>
            <div className="text-lg font-semibold text-red-600">
              {healthMetrics.criticalErrors}
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center text-sm">
              <TrendingUp className="h-3 w-3 mr-1 text-orange-500" />
              Error Rate
            </div>
            <div className="text-lg font-semibold">
              {healthMetrics.errorRate.toFixed(1)}/hr
            </div>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center text-sm">
              <Clock className="h-3 w-3 mr-1 text-green-500" />
              Uptime
            </div>
            <div className="text-lg font-semibold">
              {formatUptime(healthMetrics.uptime)}
            </div>
          </div>
        </div>

        {/* Performance Metrics */}
        {healthMetrics.memoryUsage &&
        <div className="pt-2 border-t">
            <div className="flex items-center justify-between text-sm">
              <span>Memory Usage</span>
              <span>{Math.round(healthMetrics.memoryUsage / 1024 / 1024)}MB</span>
            </div>
          </div>
        }

        {/* Alerts */}
        {healthMetrics.systemHealth === 'critical' &&
        <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Critical system issues detected. Immediate attention required.
            </AlertDescription>
          </Alert>
        }

        {healthMetrics.systemHealth === 'poor' &&
        <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              System performance degraded. Review error patterns.
            </AlertDescription>
          </Alert>
        }
      </CardContent>
    </Card>);

}