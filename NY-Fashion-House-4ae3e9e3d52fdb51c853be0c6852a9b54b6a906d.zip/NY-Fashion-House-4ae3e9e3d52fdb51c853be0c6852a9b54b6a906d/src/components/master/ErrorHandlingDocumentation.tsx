import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '../ui/collapsible';
import {
  BookOpen,
  Code,
  AlertCircle,
  CheckCircle,
  ChevronDown,
  ChevronRight,
  Copy,
  ExternalLink,
  Lightbulb,
  Shield,
  Zap,
  Settings,
  Bug,
  FileText } from
'lucide-react';

interface DocumentationSection {
  id: string;
  title: string;
  description: string;
  content: React.ReactNode;
  category: 'getting-started' | 'implementation' | 'best-practices' | 'troubleshooting' | 'api' | 'advanced';
}

export function ErrorHandlingDocumentation() {
  const [selectedSection, setSelectedSection] = useState<string>('overview');
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['overview']));

  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId);
    } else {
      newExpanded.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };

  const copyCodeToClipboard = (code: string) => {
    navigator.clipboard.writeText(code);
  };

  const CodeBlock = ({ code, language = 'typescript', title }: {code: string;language?: string;title?: string;}) =>
  <div className="relative">
      {title && <div className="text-sm font-medium mb-2 flex items-center">
        <Code className="h-4 w-4 mr-1" />
        {title}
      </div>}
      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm relative">
        <Button
        variant="ghost"
        size="sm"
        className="absolute top-2 right-2 text-gray-400 hover:text-white"
        onClick={() => copyCodeToClipboard(code)}>

          <Copy className="h-3 w-3" />
        </Button>
        <code>{code}</code>
      </pre>
    </div>;


  const documentationSections: DocumentationSection[] = [
  {
    id: 'overview',
    title: 'System Overview',
    description: 'Understanding the comprehensive error handling system',
    category: 'getting-started',
    content:
    <div className="space-y-6">
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertTitle>Production-Ready Error Handling</AlertTitle>
            <AlertDescription>
              This system provides comprehensive error boundaries, centralized logging, 
              performance optimization, and automated pattern detection for React applications.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bug className="h-5 w-5 mr-2" />
                  Error Boundaries
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Hierarchical error boundaries (App → Page → Component)</li>
                  <li>• Automatic retry mechanisms</li>
                  <li>• Custom fallback components</li>
                  <li>• Context-aware error handling</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="h-5 w-5 mr-2" />
                  Performance Optimized
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li>• Error debouncing and throttling</li>
                  <li>• Batch processing of error logs</li>
                  <li>• Memory usage optimization</li>
                  <li>• Minimal runtime overhead</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-900 mb-2">Architecture Components</h4>
            <div className="text-sm text-blue-800 space-y-1">
              <div>📋 <strong>MasterErrorBoundary:</strong> Top-level error boundary with recovery strategies</div>
              <div>🔧 <strong>MasterErrorManager:</strong> Centralized error collection and processing</div>
              <div>⚡ <strong>PerformanceOptimizer:</strong> Error throttling and batching</div>
              <div>🔍 <strong>ErrorPatternDetector:</strong> Automated error pattern analysis</div>
              <div>🛠️ <strong>DevToolsIntegration:</strong> Development debugging support</div>
            </div>
          </div>
        </div>

  },
  {
    id: 'quick-start',
    title: 'Quick Start Guide',
    description: 'Get up and running in minutes',
    category: 'getting-started',
    content:
    <div className="space-y-6">
          <Alert>
            <Lightbulb className="h-4 w-4" />
            <AlertTitle>Step-by-Step Setup</AlertTitle>
            <AlertDescription>
              Follow these steps to integrate the error handling system into your application.
            </AlertDescription>
          </Alert>

          <div className="space-y-6">
            <div>
              <h4 className="font-semibold mb-3 flex items-center">
                <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-2">1</span>
                Wrap Your App
              </h4>
              <CodeBlock
            title="App.tsx"
            code={`import { MasterErrorBoundary } from './components/master/MasterErrorBoundary';

function App() {
  return (
    <MasterErrorBoundary 
      level="app" 
      context="main-application"
      enableAutoRecovery={true}
      maxRetries={3}
    >
      <YourAppContent />
    </MasterErrorBoundary>
  );
}`} />

            </div>

            <div>
              <h4 className="font-semibold mb-3 flex items-center">
                <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-2">2</span>
                Wrap Critical Components
              </h4>
              <CodeBlock
            title="CriticalComponent.tsx"
            code={`import { withMasterErrorBoundary } from './components/master/MasterErrorBoundary';

const CriticalComponent = () => {
  // Your component logic
  return <div>Critical functionality</div>;
};

export default withMasterErrorBoundary(CriticalComponent, {
  level: 'component',
  context: 'critical-feature',
  enableAutoRecovery: true
});`} />

            </div>

            <div>
              <h4 className="font-semibold mb-3 flex items-center">
                <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm mr-2">3</span>
                Manual Error Reporting
              </h4>
              <CodeBlock
            title="Manual Error Reporting"
            code={`import { MasterErrorManager } from './services/masterErrorManager';

const errorManager = new MasterErrorManager();

try {
  // Your code that might throw
  riskyOperation();
} catch (error) {
  errorManager.reportError(error, 'api-call');
}`} />

            </div>
          </div>
        </div>

  },
  {
    id: 'implementation',
    title: 'Implementation Guide',
    description: 'Detailed implementation examples',
    category: 'implementation',
    content:
    <div className="space-y-6">
          <Tabs defaultValue="basic" className="w-full">
            <TabsList>
              <TabsTrigger value="basic">Basic Usage</TabsTrigger>
              <TabsTrigger value="advanced">Advanced Features</TabsTrigger>
              <TabsTrigger value="custom">Custom Fallbacks</TabsTrigger>
            </TabsList>

            <TabsContent value="basic">
              <div className="space-y-4">
                <h4 className="font-semibold">Basic Error Boundary Usage</h4>
                <CodeBlock
              code={`// Simple component wrapper
<MasterErrorBoundary level="component" context="user-profile">
  <UserProfile userId={userId} />
</MasterErrorBoundary>

// Page-level wrapper
<MasterErrorBoundary level="page" context="dashboard-page">
  <Dashboard />
</MasterErrorBoundary>`} />

              </div>
            </TabsContent>

            <TabsContent value="advanced">
              <div className="space-y-4">
                <h4 className="font-semibold">Advanced Configuration</h4>
                <CodeBlock
              code={`// Advanced error boundary with custom settings
<MasterErrorBoundary 
  level="section" 
  context="payment-flow"
  enableAutoRecovery={true}
  maxRetries={2}
  fallbackComponent={CustomPaymentFallback}
>
  <PaymentSection />
</MasterErrorBoundary>

// With custom error handling
const CustomPaymentFallback = ({ error, retry }) => (
  <div className="payment-error">
    <h3>Payment System Temporarily Unavailable</h3>
    <p>We're experiencing technical difficulties.</p>
    <Button onClick={retry}>Try Again</Button>
    <Button onClick={() => contactSupport(error)}>Contact Support</Button>
  </div>
);`} />

              </div>
            </TabsContent>

            <TabsContent value="custom">
              <div className="space-y-4">
                <h4 className="font-semibold">Custom Fallback Components</h4>
                <CodeBlock
              code={`// Create custom fallback for specific use cases
const DatabaseErrorFallback = ({ error, retry }) => {
  const [isRetrying, setIsRetrying] = useState(false);
  
  const handleRetry = async () => {
    setIsRetrying(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    retry();
    setIsRetrying(false);
  };
  
  return (
    <Card className="m-4">
      <CardHeader>
        <CardTitle>Database Connection Error</CardTitle>
        <CardDescription>
          Unable to connect to the database. This is usually temporary.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error.message}</AlertDescription>
          </Alert>
          <Button onClick={handleRetry} disabled={isRetrying}>
            {isRetrying ? 'Retrying...' : 'Retry Connection'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};`} />

              </div>
            </TabsContent>
          </Tabs>
        </div>

  },
  {
    id: 'best-practices',
    title: 'Best Practices',
    description: 'Recommended patterns and practices',
    category: 'best-practices',
    content:
    <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-green-700">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Do's
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>✅ Use hierarchical error boundaries (App → Page → Component)</div>
                <div>✅ Provide meaningful context in error boundaries</div>
                <div>✅ Implement custom fallback components for critical features</div>
                <div>✅ Enable auto-recovery for transient errors</div>
                <div>✅ Log errors with comprehensive metadata</div>
                <div>✅ Test error scenarios in development</div>
                <div>✅ Monitor error patterns in production</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-red-700">
                  <AlertCircle className="h-5 w-5 mr-2" />
                  Don'ts
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>❌ Don't ignore errors or fail silently</div>
                <div>❌ Don't use generic error messages</div>
                <div>❌ Don't overuse error boundaries (performance cost)</div>
                <div>❌ Don't expose sensitive information in error messages</div>
                <div>❌ Don't forget to cleanup resources in error handlers</div>
                <div>❌ Don't rely solely on error boundaries for validation</div>
                <div>❌ Don't log duplicate errors without deduplication</div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Error Boundary Placement Strategy</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h5 className="font-semibold mb-2">Application Level</h5>
                  <p className="text-sm">Catch unhandled errors and provide app-wide fallback. Handle critical failures that affect the entire application.</p>
                  <CodeBlock
                code={`<MasterErrorBoundary level="app" context="main-app">
  <Router>
    <Routes>
      {/* Your routes */}
    </Routes>
  </Router>
</MasterErrorBoundary>`} />

                </div>

                <div className="bg-green-50 p-4 rounded-lg">
                  <h5 className="font-semibold mb-2">Page Level</h5>
                  <p className="text-sm">Isolate errors to specific pages/routes. Allow other parts of the application to continue functioning.</p>
                  <CodeBlock
                code={`<Route path="/dashboard" element={
  <MasterErrorBoundary level="page" context="dashboard">
    <Dashboard />
  </MasterErrorBoundary>
} />`} />

                </div>

                <div className="bg-yellow-50 p-4 rounded-lg">
                  <h5 className="font-semibold mb-2">Component Level</h5>
                  <p className="text-sm">Wrap critical or error-prone components. Provide specific fallbacks for individual features.</p>
                  <CodeBlock
                code={`<MasterErrorBoundary level="component" context="payment-form">
  <PaymentForm />
</MasterErrorBoundary>`} />

                </div>
              </div>
            </CardContent>
          </Card>
        </div>

  },
  {
    id: 'troubleshooting',
    title: 'Troubleshooting Guide',
    description: 'Common issues and solutions',
    category: 'troubleshooting',
    content:
    <div className="space-y-6">
          <Alert>
            <Bug className="h-4 w-4" />
            <AlertTitle>Common Issues & Solutions</AlertTitle>
            <AlertDescription>
              Quick solutions to the most frequently encountered problems.
            </AlertDescription>
          </Alert>

          {[
      {
        issue: "Error boundaries not catching errors",
        symptoms: ["Errors still crash the app", "Error boundary fallback not showing"],
        solutions: [
        "Ensure error boundaries are placed correctly in the component tree",
        "Verify that errors are thrown during render, not in event handlers",
        "Use try-catch blocks for async operations and event handlers",
        "Check that the error boundary component extends React.Component"]

      },
      {
        issue: "Performance issues with error logging",
        symptoms: ["App feels slow", "High memory usage", "Network congestion"],
        solutions: [
        "Enable error debouncing in PerformanceOptimizer",
        "Increase batch size for error processing",
        "Implement sampling for non-critical errors",
        "Clear old error patterns periodically"]

      },
      {
        issue: "DevTools integration not working",
        symptoms: ["No errors in DevTools console", "Missing error details"],
        solutions: [
        "Check that NODE_ENV is set to 'development'",
        "Verify DevToolsIntegration is initialized",
        "Clear browser cache and session storage",
        "Check browser console for integration errors"]

      },
      {
        issue: "Auto-recovery not working",
        symptoms: ["Errors not retrying automatically", "Infinite retry loops"],
        solutions: [
        "Verify enableAutoRecovery is set to true",
        "Check maxRetries setting (default is 3)",
        "Ensure error recovery strategies are properly configured",
        "Review error types that support auto-recovery"]

      }].
      map((troubleshoot, index) =>
      <Collapsible key={index}>
              <CollapsibleTrigger className="flex items-center justify-between w-full p-4 bg-gray-50 rounded-lg hover:bg-gray-100">
                <div className="flex items-center space-x-3">
                  <AlertCircle className="h-5 w-5 text-red-500" />
                  <span className="font-semibold">{troubleshoot.issue}</span>
                </div>
                <ChevronDown className="h-4 w-4" />
              </CollapsibleTrigger>
              <CollapsibleContent className="p-4 border-l-4 border-gray-200 ml-4 mt-2">
                <div className="space-y-3">
                  <div>
                    <h6 className="font-medium text-orange-700 mb-2">Symptoms:</h6>
                    <ul className="text-sm space-y-1">
                      {troubleshoot.symptoms.map((symptom, idx) =>
                <li key={idx} className="flex items-center">
                          <span className="w-2 h-2 bg-orange-400 rounded-full mr-2"></span>
                          {symptom}
                        </li>
                )}
                    </ul>
                  </div>
                  <div>
                    <h6 className="font-medium text-green-700 mb-2">Solutions:</h6>
                    <ul className="text-sm space-y-1">
                      {troubleshoot.solutions.map((solution, idx) =>
                <li key={idx} className="flex items-center">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                          {solution}
                        </li>
                )}
                    </ul>
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
      )}
        </div>

  },
  {
    id: 'api-reference',
    title: 'API Reference',
    description: 'Complete API documentation',
    category: 'api',
    content:
    <div className="space-y-6">
          <Tabs defaultValue="error-boundary" className="w-full">
            <TabsList>
              <TabsTrigger value="error-boundary">Error Boundary</TabsTrigger>
              <TabsTrigger value="error-manager">Error Manager</TabsTrigger>
              <TabsTrigger value="pattern-detector">Pattern Detector</TabsTrigger>
            </TabsList>

            <TabsContent value="error-boundary" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>MasterErrorBoundary Props</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="border border-gray-300 p-2 text-left">Prop</th>
                          <th className="border border-gray-300 p-2 text-left">Type</th>
                          <th className="border border-gray-300 p-2 text-left">Default</th>
                          <th className="border border-gray-300 p-2 text-left">Description</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="border border-gray-300 p-2 font-mono">level</td>
                          <td className="border border-gray-300 p-2">'app' | 'page' | 'section' | 'component'</td>
                          <td className="border border-gray-300 p-2">required</td>
                          <td className="border border-gray-300 p-2">Error boundary hierarchy level</td>
                        </tr>
                        <tr>
                          <td className="border border-gray-300 p-2 font-mono">context</td>
                          <td className="border border-gray-300 p-2">string</td>
                          <td className="border border-gray-300 p-2">'unknown'</td>
                          <td className="border border-gray-300 p-2">Contextual information for error tracking</td>
                        </tr>
                        <tr>
                          <td className="border border-gray-300 p-2 font-mono">enableAutoRecovery</td>
                          <td className="border border-gray-300 p-2">boolean</td>
                          <td className="border border-gray-300 p-2">false</td>
                          <td className="border border-gray-300 p-2">Enable automatic retry mechanisms</td>
                        </tr>
                        <tr>
                          <td className="border border-gray-300 p-2 font-mono">maxRetries</td>
                          <td className="border border-gray-300 p-2">number</td>
                          <td className="border border-gray-300 p-2">3</td>
                          <td className="border border-gray-300 p-2">Maximum number of retry attempts</td>
                        </tr>
                        <tr>
                          <td className="border border-gray-300 p-2 font-mono">fallbackComponent</td>
                          <td className="border border-gray-300 p-2">React.ComponentType</td>
                          <td className="border border-gray-300 p-2">undefined</td>
                          <td className="border border-gray-300 p-2">Custom fallback component</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="error-manager" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>MasterErrorManager Methods</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h5 className="font-semibold mb-2">reportError(error: Error, context?: string)</h5>
                    <p className="text-sm text-gray-600 mb-2">Manually report an error to the system.</p>
                    <CodeBlock
                  code={`const errorManager = new MasterErrorManager();
errorManager.reportError(new Error('Custom error'), 'user-action');`} />

                  </div>

                  <div>
                    <h5 className="font-semibold mb-2">getErrorStatistics(): ErrorStatistics</h5>
                    <p className="text-sm text-gray-600 mb-2">Get current error statistics for monitoring.</p>
                    <CodeBlock
                  code={`const stats = errorManager.getErrorStatistics();
console.log('Total errors:', stats.totalErrors);`} />

                  </div>

                  <div>
                    <h5 className="font-semibold mb-2">getErrorPatterns(): ErrorPattern[]</h5>
                    <p className="text-sm text-gray-600 mb-2">Retrieve detected error patterns.</p>
                    <CodeBlock
                  code={`const patterns = errorManager.getErrorPatterns();
patterns.forEach(pattern => {
  console.log(pattern.description, pattern.frequency);
});`} />

                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pattern-detector" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>ErrorPatternDetector API</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h5 className="font-semibold mb-2">generateInsights(): string[]</h5>
                    <p className="text-sm text-gray-600 mb-2">Generate automated insights from error patterns.</p>
                    <CodeBlock
                  code={`const detector = new ErrorPatternDetector();
const insights = detector.generateInsights();
insights.forEach(insight => console.log(insight));`} />

                  </div>

                  <div>
                    <h5 className="font-semibold mb-2">getPattern(id: string): ErrorPattern | undefined</h5>
                    <p className="text-sm text-gray-600 mb-2">Get specific error pattern by ID.</p>
                    <CodeBlock
                  code={`const pattern = detector.getPattern('network_timeout');
if (pattern) {
  console.log('Suggested fix:', pattern.suggestedFix);
}`} />

                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

  }];


  const filteredSections = documentationSections;
  const currentSection = filteredSections.find((section) => section.id === selectedSection) || filteredSections[0];

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <div className="flex items-center space-x-3 mb-2">
          <BookOpen className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold">Error Handling System Documentation</h1>
        </div>
        <p className="text-gray-600">Comprehensive guide to implementing and using the error handling system</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-1">
          <Card className="sticky top-4">
            <CardHeader>
              <CardTitle className="text-lg">Documentation</CardTitle>
            </CardHeader>
            <CardContent>
              <nav className="space-y-1">
                {filteredSections.map((section) =>
                <button
                  key={section.id}
                  onClick={() => setSelectedSection(section.id)}
                  className={`w-full text-left p-2 rounded-md text-sm transition-colors ${
                  selectedSection === section.id ?
                  'bg-blue-100 text-blue-700 font-medium' :
                  'text-gray-600 hover:bg-gray-50'}`
                  }>

                    <div className="flex items-center justify-between">
                      <span>{section.title}</span>
                      <Badge variant="outline" className="text-xs">
                        {section.category.replace('-', ' ')}
                      </Badge>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">{section.description}</div>
                  </button>
                )}
              </nav>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center">
                    {currentSection.category === 'getting-started' && <Lightbulb className="h-5 w-5 mr-2 text-green-600" />}
                    {currentSection.category === 'implementation' && <Code className="h-5 w-5 mr-2 text-blue-600" />}
                    {currentSection.category === 'best-practices' && <CheckCircle className="h-5 w-5 mr-2 text-green-600" />}
                    {currentSection.category === 'troubleshooting' && <Bug className="h-5 w-5 mr-2 text-red-600" />}
                    {currentSection.category === 'api' && <FileText className="h-5 w-5 mr-2 text-purple-600" />}
                    {currentSection.category === 'advanced' && <Settings className="h-5 w-5 mr-2 text-orange-600" />}
                    {currentSection.title}
                  </CardTitle>
                  <CardDescription>{currentSection.description}</CardDescription>
                </div>
                <Badge variant="outline">{currentSection.category.replace('-', ' ')}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                {currentSection.content}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>);

}