import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { AlertCircle, RefreshCw, Bug, FileText, Clock } from 'lucide-react';
import { MasterErrorManager } from '../../services/masterErrorManager';
import { ErrorRecoveryStrategies } from '../../utils/errorRecoveryStrategies';

interface Props {
  children: ReactNode;
  fallbackComponent?: React.ComponentType<{error: Error;retry: () => void;}>;
  level: 'app' | 'page' | 'section' | 'component';
  context?: string;
  enableAutoRecovery?: boolean;
  maxRetries?: number;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  retryCount: number;
  lastErrorTime: number;
  errorId: string;
  recoveryStrategy?: string;
}

export class MasterErrorBoundary extends Component<Props, State> {
  private errorManager: MasterErrorManager;
  private recoveryStrategies: ErrorRecoveryStrategies;

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      retryCount: 0,
      lastErrorTime: 0,
      errorId: '',
      recoveryStrategy: undefined
    };

    this.errorManager = new MasterErrorManager();
    this.recoveryStrategies = new ErrorRecoveryStrategies();
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return {
      hasError: true,
      error,
      errorId: `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      lastErrorTime: Date.now()
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({ errorInfo });

    // Log error with comprehensive metadata
    this.errorManager.logError({
      error,
      errorInfo,
      level: this.props.level,
      context: this.props.context || 'unknown',
      errorId: this.state.errorId,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      url: window.location.href,
      retryCount: this.state.retryCount,
      componentStack: errorInfo.componentStack,
      errorBoundary: 'MasterErrorBoundary'
    });

    // Attempt automatic recovery if enabled
    if (this.props.enableAutoRecovery && this.state.retryCount < (this.props.maxRetries || 3)) {
      const strategy = this.recoveryStrategies.selectStrategy(error, this.props.level);
      this.setState({ recoveryStrategy: strategy });

      if (strategy === 'auto-retry') {
        setTimeout(() => this.handleRetry(), 2000);
      }
    }
  }

  handleRetry = () => {
    this.setState((prevState) => ({
      hasError: false,
      error: null,
      errorInfo: null,
      retryCount: prevState.retryCount + 1,
      recoveryStrategy: undefined
    }));
  };

  handleReportIssue = () => {
    const errorReport = {
      errorId: this.state.errorId,
      error: this.state.error?.message,
      stack: this.state.error?.stack,
      componentStack: this.state.errorInfo?.componentStack,
      level: this.props.level,
      context: this.props.context,
      timestamp: this.state.lastErrorTime,
      retryCount: this.state.retryCount
    };

    // Open issue reporting interface
    this.errorManager.openIssueReporter(errorReport);
  };

  handleViewDetails = () => {
    // Open detailed error view
    this.errorManager.openErrorDetails(this.state.errorId);
  };

  getErrorSeverity = (): 'low' | 'medium' | 'high' | 'critical' => {
    if (this.props.level === 'app') return 'critical';
    if (this.props.level === 'page') return 'high';
    if (this.state.retryCount > 2) return 'high';
    return 'medium';
  };

  render() {
    if (this.state.hasError && this.state.error) {
      // Use custom fallback if provided
      if (this.props.fallbackComponent) {
        const FallbackComponent = this.props.fallbackComponent;
        return <FallbackComponent error={this.state.error} retry={this.handleRetry} />;
      }

      const severity = this.getErrorSeverity();
      const canRetry = this.state.retryCount < (this.props.maxRetries || 3);

      return (
        <div className="flex items-center justify-center min-h-[400px] p-4">
          <Card className="w-full max-w-2xl">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <AlertCircle className="h-6 w-6 text-red-500" />
                  <CardTitle className="text-red-700">
                    {this.props.level === 'app' ? 'Application Error' :
                    this.props.level === 'page' ? 'Page Error' : 'Component Error'}
                  </CardTitle>
                </div>
                <Badge variant={severity === 'critical' ? 'destructive' :
                severity === 'high' ? 'destructive' : 'secondary'}>
                  {severity.toUpperCase()}
                </Badge>
              </div>
              <CardDescription>
                An error occurred in {this.props.context || 'the application'}. 
                {this.state.recoveryStrategy === 'auto-retry' && ' Attempting automatic recovery...'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gray-50 p-3 rounded-md">
                <p className="text-sm font-medium text-gray-700">Error Details:</p>
                <p className="text-sm text-gray-600 mt-1">{this.state.error.message}</p>
                <div className="flex items-center mt-2 text-xs text-gray-500">
                  <Clock className="h-3 w-3 mr-1" />
                  Error ID: {this.state.errorId}
                </div>
              </div>

              {this.state.retryCount > 0 &&
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3">
                  <p className="text-sm text-yellow-800">
                    Retry attempt {this.state.retryCount} of {this.props.maxRetries || 3}
                  </p>
                </div>
              }

              <div className="flex flex-wrap gap-2">
                {canRetry &&
                <Button onClick={this.handleRetry} className="flex items-center">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Try Again
                  </Button>
                }
                
                <Button variant="outline" onClick={this.handleViewDetails}>
                  <FileText className="h-4 w-4 mr-2" />
                  View Details
                </Button>
                
                <Button variant="outline" onClick={this.handleReportIssue}>
                  <Bug className="h-4 w-4 mr-2" />
                  Report Issue
                </Button>
              </div>

              {process.env.NODE_ENV === 'development' && this.state.errorInfo &&
              <details className="mt-4">
                  <summary className="cursor-pointer text-sm font-medium text-gray-700">
                    Development Details (Not shown in production)
                  </summary>
                  <pre className="mt-2 text-xs bg-gray-100 p-2 rounded overflow-auto max-h-40">
                    {this.state.error.stack}
                    {'\n\nComponent Stack:'}
                    {this.state.errorInfo.componentStack}
                  </pre>
                </details>
              }
            </CardContent>
          </Card>
        </div>);

    }

    return this.props.children;
  }
}

// HOC for easy wrapping of components
export function withMasterErrorBoundary<P extends object>(
Component: React.ComponentType<P>,
options: Omit<Props, 'children'> = { level: 'component' })
{
  return function WrappedComponent(props: P) {
    return (
      <MasterErrorBoundary {...options}>
        <Component {...props} />
      </MasterErrorBoundary>);

  };
}