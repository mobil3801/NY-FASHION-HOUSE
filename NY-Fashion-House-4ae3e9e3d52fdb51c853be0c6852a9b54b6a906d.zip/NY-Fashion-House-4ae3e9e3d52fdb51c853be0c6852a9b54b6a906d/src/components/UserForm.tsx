
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Loader2, AlertCircle } from 'lucide-react';
import { User, UserFormData } from '@/types/user';
import { validators, validateUSAStandards } from '@/utils/formatValidation';
import { toast } from 'sonner';

interface UserFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: User | null;
  roles: any[];
  onSubmit: (data: UserFormData) => Promise<void>;
  loading: boolean;
}

const UserForm: React.FC<UserFormProps> = ({
  open,
  onOpenChange,
  user,
  roles,
  onSubmit,
  loading
}) => {
  const [formData, setFormData] = useState<UserFormData>({
    name: '',
    email: '',
    phoneNumber: '',
    roleId: undefined,
    isActivated: true,
    password: ''
  });

  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name,
        email: user.email,
        phoneNumber: user.phone_number || '',
        roleId: user.role_id || undefined,
        isActivated: user.is_activated,
        password: '' // Don't pre-fill password
      });
    } else {
      setFormData({
        name: '',
        email: '',
        phoneNumber: '',
        roleId: undefined,
        isActivated: true,
        password: ''
      });
    }
  }, [user]);

  const validateUserForm = (): boolean => {
    const errors: Record<string, string> = {};

    // Name validation
    const nameResult = validators.required(formData.name);
    if (!nameResult.isValid) {
      errors.name = nameResult.message || 'Name is required';
    } else if (formData.name.trim().length < 2) {
      errors.name = 'Name must be at least 2 characters';
    }

    // Email validation
    const emailResult = validators.email(formData.email);
    if (!emailResult.isValid) {
      errors.email = emailResult.message || 'Invalid email format';
    }

    // Phone validation
    if (formData.phoneNumber && formData.phoneNumber.trim()) {
      const phoneResult = validateUSAStandards.phoneNumber(formData.phoneNumber);
      if (!phoneResult.isValid) {
        errors.phoneNumber = phoneResult.message || 'Invalid phone number format';
      }
    }

    // Password validation (for new users only)
    if (!user && formData.password) {
      const passwordResult = validators.password(formData.password);
      if (!passwordResult.isValid) {
        errors.password = passwordResult.message || 'Password does not meet requirements';
      }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateUserForm()) {
      toast.error('Please correct the errors in the form');
      return;
    }

    try {
      await onSubmit(formData);
    } catch (error) {
      // Error handling is done in the parent component
      console.error('Form submission error:', error);
    }
  };

  const handleInputChange = (field: keyof UserFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));

    // Clear validation error when user starts typing
    if (validationErrors[field]) {
      setValidationErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{user ? 'Edit User' : 'Create New User'}</DialogTitle>
          <DialogDescription>
            {user ?
            'Update user information and settings.' :
            'Create a new user account with the required information.'
            }
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange('name', e.target.value)}
              placeholder="Enter full name"
              required
              disabled={loading}
              className={validationErrors.name ? 'border-red-500' : ''} />

            {validationErrors.name &&
            <p className="text-sm text-red-600">{validationErrors.name}</p>
            }
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="Enter email address"
              required
              disabled={loading || !!user} // Don't allow email changes for existing users
              className={validationErrors.email ? 'border-red-500' : ''} />

            {validationErrors.email &&
            <p className="text-sm text-red-600">{validationErrors.email}</p>
            }
          </div>

          <div className="space-y-2">
            <Label htmlFor="phoneNumber">Phone Number</Label>
            <Input
              id="phoneNumber"
              value={formData.phoneNumber}
              onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
              placeholder="(555) 123-4567"
              disabled={loading}
              className={validationErrors.phoneNumber ? 'border-red-500' : ''} />

            {validationErrors.phoneNumber &&
            <p className="text-sm text-red-600">{validationErrors.phoneNumber}</p>
            }
          </div>

          {!user &&
          <div className="space-y-2">
              <Label htmlFor="password">Password *</Label>
              <Input
              id="password"
              type="password"
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              placeholder="Enter password (min. 8 characters)"
              required
              disabled={loading}
              minLength={8}
              className={validationErrors.password ? 'border-red-500' : ''} />

              {validationErrors.password &&
            <p className="text-sm text-red-600">{validationErrors.password}</p>
            }
              <p className="text-xs text-gray-500">
                Password must contain at least 8 characters with uppercase, lowercase, and numbers
              </p>
            </div>
          }

          <div className="space-y-2">
            <Label>Role</Label>
            <Select
              value={formData.roleId ? formData.roleId.toString() : ''}
              onValueChange={(value) => handleInputChange('roleId', value ? parseInt(value) : undefined)}
              disabled={loading}>

              <SelectTrigger>
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">No Role</SelectItem>
                {roles.map((role) =>
                <SelectItem key={role.id} value={role.id.toString()}>
                    {role.name}
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="isActivated"
              checked={formData.isActivated}
              onCheckedChange={(checked) => handleInputChange('isActivated', checked)}
              disabled={loading} />

            <Label htmlFor="isActivated">Account Active</Label>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}>

              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {user ? 'Update User' : 'Create User'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>);

};

export default UserForm;