import React from 'react';
import { format } from 'date-fns';
import { Users, UserCheck, Search, Filter, X, ArrowRight, CheckCircle, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Role, UserRoleAssignment } from '@/types/role';

interface RoleAssignmentProps {
  isOpen: boolean;
  onClose: () => void;
  roles: Role[];
  selectedRole?: Role;
  onAssignUsers: (userIds: number[], roleId: number) => Promise<void>;
}

export const RoleAssignment: React.FC<RoleAssignmentProps> = ({
  isOpen,
  onClose,
  roles,
  selectedRole,
  onAssignUsers
}) => {
  const [users, setUsers] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [selectedUsers, setSelectedUsers] = React.useState<number[]>([]);
  const [targetRoleId, setTargetRoleId] = React.useState<number>(selectedRole?.id || 0);
  const [searchTerm, setSearchTerm] = React.useState('');
  const [filterRole, setFilterRole] = React.useState<string>('all');
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState('');

  // Fetch users when dialog opens
  React.useEffect(() => {
    if (isOpen) {
      fetchUsers();
      setTargetRoleId(selectedRole?.id || 0);
      setSelectedUsers([]);
      setSearchTerm('');
      setFilterRole('all');
      setError('');
    }
  }, [isOpen, selectedRole]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const { data, error } = await window.ezsite.apis.tablePage(37706, {
        PageNo: 1,
        PageSize: 1000,
        OrderByField: 'name',
        IsAsc: true,
        Filters: []
      });

      if (error) throw new Error(error);
      setUsers(data.List);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      setError(error.message || 'Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = React.useMemo(() => {
    return users.filter((user) => {
      const matchesSearch = !searchTerm ||
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesRole = filterRole === 'all' ||
      filterRole === 'none' && !user.role_id ||
      filterRole !== 'none' && user.role_id?.toString() === filterRole;

      return matchesSearch && matchesRole;
    });
  }, [users, searchTerm, filterRole]);

  const handleUserSelect = (userId: number, checked: boolean) => {
    setSelectedUsers((prev) =>
    checked ?
    [...prev, userId] :
    prev.filter((id) => id !== userId)
    );
  };

  const handleSelectAll = (checked: boolean) => {
    setSelectedUsers(checked ? filteredUsers.map((user) => user.id) : []);
  };

  const handleSubmit = async () => {
    if (selectedUsers.length === 0) {
      setError('Please select at least one user to assign');
      return;
    }

    if (!targetRoleId) {
      setError('Please select a target role');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      await onAssignUsers(selectedUsers, targetRoleId);
      onClose();
    } catch (error: any) {
      setError(error.message || 'Failed to assign users to role');
    } finally {
      setSubmitting(false);
    }
  };

  const getRoleName = (roleId: number | null) => {
    if (!roleId) return 'No Role';
    const role = roles.find((r) => r.id === roleId);
    return role?.name || 'Unknown Role';
  };

  const getRoleBadgeVariant = (roleId: number | null) => {
    if (!roleId) return 'secondary' as const;
    const role = roles.find((r) => r.id === roleId);
    if (role?.code === 'Administrator') return 'destructive' as const;
    return 'default' as const;
  };

  const allFiltered = filteredUsers.length > 0 && selectedUsers.length === filteredUsers.length;
  const someFiltered = selectedUsers.length > 0 && selectedUsers.length < filteredUsers.length;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCheck className="h-5 w-5" />
            Assign Users to Role
          </DialogTitle>
          <DialogDescription>
            {selectedRole ?
            `Assign users to the "${selectedRole.name}" role` :
            'Select users and assign them to a role'
            }
          </DialogDescription>
        </DialogHeader>

        {error &&
        <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        }

        <div className="flex-1 space-y-4 overflow-hidden">
          {/* Target Role Selection */}
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="targetRole">Assign to Role *</Label>
                  <Select
                    value={targetRoleId.toString()}
                    onValueChange={(value) => setTargetRoleId(parseInt(value))}>

                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select target role" />
                    </SelectTrigger>
                    <SelectContent>
                      {roles.map((role) =>
                      <SelectItem key={role.id} value={role.id.toString()}>
                          <div className="flex items-center gap-2">
                            <span>{role.name}</span>
                            {(role.code === 'Administrator' || role.code === 'GeneralUser') &&
                          <Badge variant="secondary" className="text-xs">System</Badge>
                          }
                          </div>
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <div className="text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      <span>{selectedUsers.length} users selected</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Search and Filter */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="search">Search Users</Label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="search"
                  placeholder="Search by name or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10" />

              </div>
            </div>

            <div>
              <Label htmlFor="filterRole">Filter by Current Role</Label>
              <Select value={filterRole} onValueChange={setFilterRole}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users</SelectItem>
                  <SelectItem value="none">No Role Assigned</SelectItem>
                  {roles.map((role) =>
                  <SelectItem key={role.id} value={role.id.toString()}>
                      {role.name}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Users Table */}
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">
                  Users ({filteredUsers.length})
                </CardTitle>
                {filteredUsers.length > 0 &&
                <Checkbox
                  checked={allFiltered}
                  ref={(el) => {
                    if (el) el.indeterminate = someFiltered;
                  }}
                  onCheckedChange={handleSelectAll} />

                }
              </div>
            </CardHeader>
            
            <CardContent className="flex-1 overflow-auto p-0">
              {loading ?
              <div className="p-6 text-center">
                  <div className="animate-spin h-8 w-8 border-b-2 border-gray-900 mx-auto mb-4"></div>
                  <p>Loading users...</p>
                </div> :
              filteredUsers.length === 0 ?
              <div className="p-6 text-center text-gray-500">
                  <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No users found matching your criteria</p>
                </div> :

              <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12"></TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Current Role</TableHead>
                      <TableHead className="text-center">Change</TableHead>
                      <TableHead>Joined</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user) =>
                  <TableRow key={user.id}>
                        <TableCell>
                          <Checkbox
                        checked={selectedUsers.includes(user.id)}
                        onCheckedChange={(checked) => handleUserSelect(user.id, !!checked)} />

                        </TableCell>
                        
                        <TableCell>
                          <div>
                            <div className="font-medium">{user.name}</div>
                            <div className="text-sm text-gray-600">{user.email}</div>
                          </div>
                        </TableCell>
                        
                        <TableCell>
                          <Badge variant={getRoleBadgeVariant(user.role_id)}>
                            {getRoleName(user.role_id)}
                          </Badge>
                        </TableCell>
                        
                        <TableCell className="text-center">
                          {selectedUsers.includes(user.id) && targetRoleId && user.role_id !== targetRoleId &&
                      <div className="flex items-center justify-center gap-1 text-sm">
                              <ArrowRight className="h-3 w-3 text-blue-600" />
                              <Badge variant="outline" className="text-xs">
                                {getRoleName(targetRoleId)}
                              </Badge>
                            </div>
                      }
                          {user.role_id === targetRoleId &&
                      <CheckCircle className="h-4 w-4 text-green-600 mx-auto" />
                      }
                        </TableCell>
                        
                        <TableCell className="text-sm text-gray-600">
                          {format(new Date(user.create_time), 'MMM dd, yyyy')}
                        </TableCell>
                      </TableRow>
                  )}
                  </TableBody>
                </Table>
              }
            </CardContent>
          </Card>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={submitting}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={submitting || selectedUsers.length === 0 || !targetRoleId}>

            {submitting ? 'Assigning...' : `Assign ${selectedUsers.length} Users`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>);

};

export default RoleAssignment;