import React from 'react';
import { useForm } from 'react-hook-form';
import { Save, X, Shield, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Role, Permission, RoleFormData } from '@/types/role';
import PermissionMatrix from './PermissionMatrix';
import { validators } from '@/utils/formatValidation';

interface RoleFormProps {
  role?: Role;
  permissions: Permission[];
  rolePermissions: number[];
  onSubmit: (data: RoleFormData) => Promise<void>;
  onCancel: () => void;
  loading: boolean;
}

export const RoleForm: React.FC<RoleFormProps> = ({
  role,
  permissions,
  rolePermissions,
  onSubmit,
  onCancel,
  loading
}) => {
  const [selectedPermissions, setSelectedPermissions] = React.useState<number[]>(rolePermissions);
  const [submitError, setSubmitError] = React.useState<string>('');

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    watch,
    setValue,
    trigger
  } = useForm<{name: string;remark: string;}>({
    mode: 'onBlur',
    defaultValues: {
      name: role?.name || '',
      remark: role?.remark || ''
    }
  });

  const watchedName = watch('name');
  const isProtectedRole = role && (role.code === 'Administrator' || role.code === 'GeneralUser');
  const isEditing = !!role;

  const onFormSubmit = async (formData: {name: string;remark: string;}) => {
    try {
      setSubmitError('');

      // Validation
      if (!formData.name.trim()) {
        setSubmitError('Role name is required');
        return;
      }

      if (formData.name.trim().length < 2) {
        setSubmitError('Role name must be at least 2 characters long');
        return;
      }

      if (selectedPermissions.length === 0) {
        setSubmitError('At least one permission must be granted to the role');
        return;
      }

      const roleData: RoleFormData = {
        name: formData.name.trim(),
        remark: formData.remark.trim(),
        permissions: selectedPermissions
      };

      await onSubmit(roleData);
    } catch (error: any) {
      setSubmitError(error.message || 'An error occurred while saving the role');
    }
  };

  const generatePreviewCode = (name: string) => {
    if (!name) return '';
    return name.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '') + '_' + Date.now().toString().slice(-6);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="h-6 w-6" />
          <h2 className="text-2xl font-bold">
            {isEditing ? 'Edit Role' : 'Create New Role'}
          </h2>
          {isEditing &&
          <Badge variant={isProtectedRole ? 'destructive' : 'secondary'}>
              {isProtectedRole ? 'System Role' : 'Custom Role'}
            </Badge>
          }
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onCancel} disabled={isSubmitting}>
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>
          <Button
            form="role-form"
            type="submit"
            disabled={isSubmitting || loading}>

            <Save className="h-4 w-4 mr-2" />
            {isSubmitting ? 'Saving...' : 'Save Role'}
          </Button>
        </div>
      </div>

      {/* Protected Role Warning */}
      {isProtectedRole &&
      <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            This is a system default role. The name and code cannot be modified, but you can update permissions and remarks.
          </AlertDescription>
        </Alert>
      }

      {/* Form Error */}
      {submitError &&
      <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{submitError}</AlertDescription>
        </Alert>
      }

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Basic Information */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent>
              <form id="role-form" onSubmit={handleSubmit(onFormSubmit)} className="space-y-4">
                <div>
                  <Label htmlFor="name">Role Name *</Label>
                  <Input
                    id="name"
                    {...register('name', {
                      required: 'Role name is required',
                      minLength: { value: 2, message: 'Role name must be at least 2 characters' },
                      maxLength: { value: 50, message: 'Role name must be less than 50 characters' },
                      validate: {
                        noSpecialChars: (value) => {
                          const regex = /^[a-zA-Z0-9\s-_]+$/;
                          return regex.test(value) || 'Role name can only contain letters, numbers, spaces, hyphens, and underscores';
                        },
                        notEmpty: (value) => {
                          return value.trim().length > 0 || 'Role name cannot be empty or just spaces';
                        }
                      }
                    })}
                    placeholder="e.g., Sales Manager"
                    disabled={isProtectedRole}
                    className={`mt-1 ${errors.name ? 'border-red-500' : ''}`} />


                  {errors.name &&
                  <p className="text-sm text-red-600 mt-1">{errors.name.message}</p>
                  }
                </div>

                {/* Code Preview */}
                {!isEditing && watchedName &&
                <div>
                    <Label className="text-sm text-gray-600">Generated Code (Preview)</Label>
                    <div className="mt-1 p-2 bg-gray-100 rounded text-sm font-mono">
                      {generatePreviewCode(watchedName)}
                    </div>
                  </div>
                }

                {/* Existing Code for Edit */}
                {isEditing && role &&
                <div>
                    <Label className="text-sm text-gray-600">Role Code</Label>
                    <div className="mt-1 p-2 bg-gray-100 rounded text-sm font-mono">
                      {role.code}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Role codes cannot be changed after creation
                    </p>
                  </div>
                }

                <div>
                  <Label htmlFor="remark">Description</Label>
                  <Textarea
                    id="remark"
                    {...register('remark', {
                      maxLength: { value: 500, message: 'Description must be less than 500 characters' },
                      validate: {
                        noOnlySpaces: (value) => {
                          return !value || value.trim().length === 0 || value.trim().length > 0 || 'Description cannot be only spaces';
                        }
                      }
                    })}
                    placeholder="Optional description of the role's purpose and responsibilities..."
                    rows={3}
                    className={`mt-1 resize-none ${errors.remark ? 'border-red-500' : ''}`} />


                  {errors.remark &&
                  <p className="text-sm text-red-600 mt-1">{errors.remark.message}</p>
                  }
                </div>

                {/* Permission Summary */}
                <div className="pt-4 border-t">
                  <Label className="text-sm font-medium">Permission Summary</Label>
                  <div className="mt-2 flex items-center gap-2">
                    <Badge variant="secondary">
                      {selectedPermissions.length} of {permissions.length} permissions
                    </Badge>
                    <span className="text-sm text-gray-600">
                      {Math.round(selectedPermissions.length / permissions.length * 100)}% coverage
                    </span>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Permissions */}
        <div className="lg:col-span-2">
          <PermissionMatrix
            permissions={permissions}
            selectedPermissions={selectedPermissions}
            onPermissionChange={setSelectedPermissions} />

        </div>
      </div>
    </div>);

};

export default RoleForm;