import React from 'react';
import { Check, X, ChevronDown, ChevronRight, Shield, Lock, Unlock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Permission, PermissionMatrix as PermissionMatrixType } from '@/types/role';

interface PermissionMatrixProps {
  permissions: Permission[];
  selectedPermissions: number[];
  onPermissionChange: (permissionIds: number[]) => void;
  readonly?: boolean;
}

export const PermissionMatrix: React.FC<PermissionMatrixProps> = ({
  permissions,
  selectedPermissions,
  onPermissionChange,
  readonly = false
}) => {
  const [expandedCategories, setExpandedCategories] = React.useState<string[]>([]);

  // Group permissions by category
  const groupedPermissions = React.useMemo(() => {
    const groups: {[key: string]: Permission[];} = {};

    permissions.forEach((permission) => {
      if (!groups[permission.category]) {
        groups[permission.category] = [];
      }
      groups[permission.category].push(permission);
    });

    // Sort permissions within each category
    Object.keys(groups).forEach((category) => {
      groups[category].sort((a, b) => a.sort_order - b.sort_order);
    });

    return groups;
  }, [permissions]);

  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) =>
    prev.includes(category) ?
    prev.filter((c) => c !== category) :
    [...prev, category]
    );
  };

  const toggleCategoryPermissions = (category: string, grant: boolean) => {
    if (readonly) return;

    const categoryPermissions = groupedPermissions[category];
    const categoryPermissionIds = categoryPermissions.map((p) => p.id);

    let newSelectedPermissions: number[];

    if (grant) {
      // Add all category permissions
      newSelectedPermissions = [...new Set([...selectedPermissions, ...categoryPermissionIds])];
    } else {
      // Remove all category permissions
      newSelectedPermissions = selectedPermissions.filter((id) => !categoryPermissionIds.includes(id));
    }

    onPermissionChange(newSelectedPermissions);
  };

  const togglePermission = (permissionId: number) => {
    if (readonly) return;

    const newSelectedPermissions = selectedPermissions.includes(permissionId) ?
    selectedPermissions.filter((id) => id !== permissionId) :
    [...selectedPermissions, permissionId];

    onPermissionChange(newSelectedPermissions);
  };

  const toggleAllPermissions = (grant: boolean) => {
    if (readonly) return;

    const allPermissionIds = permissions.map((p) => p.id);
    onPermissionChange(grant ? allPermissionIds : []);
  };

  const getCategoryStats = (category: string) => {
    const categoryPermissions = groupedPermissions[category];
    const grantedCount = categoryPermissions.filter((p) => selectedPermissions.includes(p.id)).length;
    const totalCount = categoryPermissions.length;

    return { grantedCount, totalCount };
  };

  const allGranted = selectedPermissions.length === permissions.length;
  const someGranted = selectedPermissions.length > 0;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            <CardTitle>Permission Matrix</CardTitle>
            <Badge variant="secondary" className="ml-2">
              {selectedPermissions.length} / {permissions.length} granted
            </Badge>
          </div>
          
          {!readonly &&
          <div className="flex gap-2">
              <Button
              variant="outline"
              size="sm"
              onClick={() => toggleAllPermissions(false)}
              disabled={!someGranted}>

                <X className="h-4 w-4 mr-1" />
                Deny All
              </Button>
              <Button
              variant="outline"
              size="sm"
              onClick={() => toggleAllPermissions(true)}
              disabled={allGranted}>

                <Check className="h-4 w-4 mr-1" />
                Grant All
              </Button>
            </div>
          }
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {Object.entries(groupedPermissions).map(([category, categoryPermissions]) => {
          const isExpanded = expandedCategories.includes(category);
          const { grantedCount, totalCount } = getCategoryStats(category);
          const allCategoryGranted = grantedCount === totalCount;
          const someCategoryGranted = grantedCount > 0;

          return (
            <Card key={category} className="border">
              <CardHeader className="pb-3">
                <Collapsible>
                  <div className="flex items-center justify-between">
                    <CollapsibleTrigger
                      onClick={() => toggleCategory(category)}
                      className="flex items-center gap-2 hover:bg-gray-50 p-2 rounded -m-2">

                      {isExpanded ?
                      <ChevronDown className="h-4 w-4" /> :

                      <ChevronRight className="h-4 w-4" />
                      }
                      <span className="font-semibold">{category}</span>
                      <Badge variant={someCategoryGranted ? "default" : "secondary"} className="ml-2">
                        {grantedCount}/{totalCount}
                      </Badge>
                    </CollapsibleTrigger>
                    
                    {!readonly &&
                    <div className="flex gap-1">
                        <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleCategoryPermissions(category, false)}
                        disabled={!someCategoryGranted}
                        className="h-8 px-2">

                          <X className="h-3 w-3" />
                        </Button>
                        <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleCategoryPermissions(category, true)}
                        disabled={allCategoryGranted}
                        className="h-8 px-2">

                          <Check className="h-3 w-3" />
                        </Button>
                      </div>
                    }
                  </div>
                  
                  <CollapsibleContent>
                    {isExpanded &&
                    <div className="mt-4 space-y-3">
                        {categoryPermissions.map((permission) => {
                        const isGranted = selectedPermissions.includes(permission.id);

                        return (
                          <div key={permission.id} className="flex items-start gap-3 p-3 rounded-lg border bg-gray-50/50">
                              {readonly ?
                            <div className="flex items-center mt-1">
                                  {isGranted ?
                              <Unlock className="h-4 w-4 text-green-600" /> :

                              <Lock className="h-4 w-4 text-gray-400" />
                              }
                                </div> :

                            <Checkbox
                              checked={isGranted}
                              onCheckedChange={() => togglePermission(permission.id)}
                              className="mt-1" />

                            }
                              
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-medium text-sm">{permission.name}</span>
                                  <Badge variant="outline" className="text-xs">
                                    {permission.code}
                                  </Badge>
                                  {isGranted &&
                                <Badge variant="default" className="text-xs">
                                      Granted
                                    </Badge>
                                }
                                </div>
                                {permission.description &&
                              <p className="text-sm text-gray-600">{permission.description}</p>
                              }
                              </div>
                            </div>);

                      })}
                      </div>
                    }
                  </CollapsibleContent>
                </Collapsible>
              </CardHeader>
            </Card>);

        })}

        {Object.keys(groupedPermissions).length === 0 &&
        <div className="text-center py-8 text-gray-500">
            <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No permissions available</p>
          </div>
        }
      </CardContent>
    </Card>);

};

export default PermissionMatrix;