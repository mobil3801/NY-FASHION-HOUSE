import React from 'react';
import { Search, Filter, Calendar, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { RoleSearchFilters } from '@/types/role';

interface RoleSearchFilterProps {
  filters: RoleSearchFilters;
  onFiltersChange: (filters: RoleSearchFilters) => void;
  onReset: () => void;
}

export const RoleSearchFilter: React.FC<RoleSearchFilterProps> = ({
  filters,
  onFiltersChange,
  onReset
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const handleFilterChange = (key: keyof RoleSearchFilters, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value
    });
  };

  const handleReset = () => {
    onReset();
    setIsOpen(false);
  };

  return (
    <Card className="mb-6">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            <CardTitle className="text-lg">Search & Filter Roles</CardTitle>
          </div>
          <Collapsible open={isOpen} onOpenChange={setIsOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                {isOpen ? 'Hide Filters' : 'Advanced Filters'}
              </Button>
            </CollapsibleTrigger>
          </Collapsible>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Quick Search */}
        <div className="flex gap-4">
          <div className="flex-1">
            <Label htmlFor="search">Search Roles</Label>
            <Input
              id="search"
              placeholder="Search by name, code, or description..."
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              className="mt-1" />

          </div>
          
          <div className="w-48">
            <Label htmlFor="sortBy">Sort By</Label>
            <Select value={filters.sortBy} onValueChange={(value) => handleFilterChange('sortBy', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="code">Code</SelectItem>
                <SelectItem value="create_time">Created Date</SelectItem>
                <SelectItem value="userCount">User Count</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="w-32">
            <Label htmlFor="sortOrder">Order</Label>
            <Select value={filters.sortOrder} onValueChange={(value) => handleFilterChange('sortOrder', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="asc">Ascending</SelectItem>
                <SelectItem value="desc">Descending</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Advanced Filters */}
        <Collapsible open={isOpen} onOpenChange={setIsOpen}>
          <CollapsibleContent className="space-y-4 pt-4 border-t">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* User Count Range */}
              <div>
                <Label htmlFor="userCountMin" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Min Users
                </Label>
                <Input
                  id="userCountMin"
                  type="number"
                  placeholder="0"
                  value={filters.userCountMin || ''}
                  onChange={(e) => handleFilterChange('userCountMin', parseInt(e.target.value) || undefined)}
                  className="mt-1" />

              </div>

              <div>
                <Label htmlFor="userCountMax">Max Users</Label>
                <Input
                  id="userCountMax"
                  type="number"
                  placeholder="No limit"
                  value={filters.userCountMax || ''}
                  onChange={(e) => handleFilterChange('userCountMax', parseInt(e.target.value) || undefined)}
                  className="mt-1" />

              </div>

              {/* Date Range */}
              <div>
                <Label htmlFor="dateFrom" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Created From
                </Label>
                <Input
                  id="dateFrom"
                  type="date"
                  value={filters.dateFrom || ''}
                  onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                  className="mt-1" />

              </div>

              <div>
                <Label htmlFor="dateTo">Created To</Label>
                <Input
                  id="dateTo"
                  type="date"
                  value={filters.dateTo || ''}
                  onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                  className="mt-1" />

              </div>
            </div>

            {/* Filter Actions */}
            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={handleReset}>
                Reset Filters
              </Button>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </CardContent>
    </Card>);

};

export default RoleSearchFilter;