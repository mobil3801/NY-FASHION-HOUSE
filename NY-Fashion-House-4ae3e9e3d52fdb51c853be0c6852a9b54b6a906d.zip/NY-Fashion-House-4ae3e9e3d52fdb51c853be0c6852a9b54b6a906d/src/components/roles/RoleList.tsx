import React from 'react';
import { format } from 'date-fns';
import {
  Edit,
  Trash2,
  Users,
  Shield,
  MoreHorizontal,
  AlertTriangle,
  Eye,
  UserCheck,
  Calendar,
  Hash } from
'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

interface Role {
  id: number;
  name: string;
  code: string;
  remark?: string;
  create_time: string;
  userCount?: number;
}

interface RoleListProps {
  roles: Role[];
  loading: boolean;
  onEdit: (role: Role) => void;
  onDelete: (role: Role) => void;
  onViewUsers: (role: Role) => void;
  onAssignUsers: (role: Role) => void;
}

export const RoleList: React.FC<RoleListProps> = ({
  roles,
  loading,
  onEdit,
  onDelete,
  onViewUsers,
  onAssignUsers
}) => {
  const [deleteRole, setDeleteRole] = React.useState<Role | null>(null);

  const isProtectedRole = (role: Role) => {
    return role.code === 'Administrator' || role.code === 'GeneralUser';
  };

  const handleDelete = async () => {
    if (deleteRole) {
      await onDelete(deleteRole);
      setDeleteRole(null);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'MMM dd, yyyy');
    } catch {
      return 'Invalid Date';
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Roles
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) =>
            <div key={i} className="animate-pulse">
                <div className="h-16 bg-gray-200 rounded"></div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Roles ({roles.length})
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {roles.length === 0 ?
          <div className="text-center py-8 text-gray-500">
              <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">No roles found</p>
              <p className="text-sm">Create your first role to get started</p>
            </div> :

          <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[200px]">Role</TableHead>
                    <TableHead className="w-[150px]">Code</TableHead>
                    <TableHead className="w-[100px] text-center">Users</TableHead>
                    <TableHead className="w-[120px]">Created</TableHead>
                    <TableHead className="min-w-[200px]">Description</TableHead>
                    <TableHead className="w-[80px] text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roles.map((role) =>
                <TableRow key={role.id} className="group">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div>
                            <div className="font-semibold">{role.name}</div>
                            {isProtectedRole(role) &&
                        <Badge variant="destructive" className="text-xs mt-1">
                                System Default
                              </Badge>
                        }
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell>
                        <Badge variant="outline" className="font-mono text-xs">
                          <Hash className="h-3 w-3 mr-1" />
                          {role.code}
                        </Badge>
                      </TableCell>
                      
                      <TableCell className="text-center">
                        <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onViewUsers(role)}
                      className="flex items-center gap-1 mx-auto">

                          <Users className="h-4 w-4" />
                          {role.userCount || 0}
                        </Button>
                      </TableCell>
                      
                      <TableCell className="text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {formatDate(role.create_time)}
                        </div>
                      </TableCell>
                      
                      <TableCell className="max-w-xs">
                        <p className="text-sm text-gray-600 truncate" title={role.remark}>
                          {role.remark ||
                      <span className="italic text-gray-400">No description</span>
                      }
                        </p>
                      </TableCell>
                      
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48">
                            <DropdownMenuItem onClick={() => onViewUsers(role)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Users ({role.userCount || 0})
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onAssignUsers(role)}>
                              <UserCheck className="h-4 w-4 mr-2" />
                              Assign Users
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => onEdit(role)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Role
                            </DropdownMenuItem>
                            {!isProtectedRole(role) &&
                        <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                            onClick={() => setDeleteRole(role)}
                            className="text-red-600 focus:text-red-600">

                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete Role
                                </DropdownMenuItem>
                              </>
                        }
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                )}
                </TableBody>
              </Table>
            </div>
          }
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteRole} onOpenChange={() => setDeleteRole(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              Delete Role
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <p>
                Are you sure you want to delete the role <strong>"{deleteRole?.name}"</strong>?
              </p>
              <p className="text-sm text-red-600">
                This action cannot be undone. All users assigned to this role will need to be reassigned to another role.
              </p>
              {deleteRole?.userCount && deleteRole.userCount > 0 &&
              <div className="p-3 bg-red-50 rounded border border-red-200">
                  <p className="text-sm text-red-800 font-medium">
                    Warning: This role is currently assigned to {deleteRole.userCount} user(s).
                  </p>
                  <p className="text-sm text-red-700">
                    Please reassign these users to other roles before deletion.
                  </p>
                </div>
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
              disabled={deleteRole?.userCount && deleteRole.userCount > 0}>

              Delete Role
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>);

};

export default RoleList;