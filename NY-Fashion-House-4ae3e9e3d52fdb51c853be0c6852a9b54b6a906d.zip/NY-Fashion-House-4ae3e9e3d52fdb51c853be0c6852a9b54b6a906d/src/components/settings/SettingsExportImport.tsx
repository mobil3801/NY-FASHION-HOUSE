
import React, { useState } from 'react';
import { SettingsService } from '@/services/settingsService';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Download, Upload, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';

const SettingsExportImport: React.FC = () => {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const exportData = await SettingsService.exportSettings();

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: 'application/json'
      });

      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `system-settings-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success('Settings exported successfully');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export settings');
    } finally {
      setIsExporting(false);
    }
  };

  const handleImport = async () => {
    if (!importFile) return;

    setIsImporting(true);
    try {
      const fileContent = await importFile.text();
      const importData = JSON.parse(fileContent);

      // Validate import data structure
      if (!importData.settings || !Array.isArray(importData.settings)) {
        throw new Error('Invalid settings file format');
      }

      await SettingsService.importSettings(importData);

      toast.success(`Successfully imported ${importData.settings.length} settings`);
      setImportFile(null);

      // Refresh the page to show updated settings
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error) {
      console.error('Import error:', error);
      toast.error('Failed to import settings: ' + (error as Error).message);
    } finally {
      setIsImporting(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/json') {
      setImportFile(file);
    } else {
      toast.error('Please select a valid JSON file');
      setImportFile(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <span>Export & Import Settings</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Importing settings will overwrite existing values. Make sure to export your current settings first as a backup.
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <Label className="text-base font-medium">Export Settings</Label>
            <p className="text-sm text-muted-foreground">
              Download all current system settings as a JSON file.
            </p>
            <Button
              onClick={handleExport}
              disabled={isExporting}
              className="w-full">

              <Download className="h-4 w-4 mr-2" />
              {isExporting ? 'Exporting...' : 'Export Settings'}
            </Button>
          </div>

          <div className="space-y-3">
            <Label className="text-base font-medium">Import Settings</Label>
            <p className="text-sm text-muted-foreground">
              Upload a settings JSON file to restore configuration.
            </p>
            <div className="space-y-2">
              <Input
                type="file"
                accept=".json"
                onChange={handleFileChange}
                className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/80" />

              <Button
                onClick={handleImport}
                disabled={!importFile || isImporting}
                variant="outline"
                className="w-full">

                <Upload className="h-4 w-4 mr-2" />
                {isImporting ? 'Importing...' : 'Import Settings'}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>);

};

export default SettingsExportImport;