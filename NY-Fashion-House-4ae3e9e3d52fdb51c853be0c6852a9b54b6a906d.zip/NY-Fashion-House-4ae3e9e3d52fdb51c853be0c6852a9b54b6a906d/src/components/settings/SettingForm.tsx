
import React, { useState } from 'react';
import { SystemSetting } from '@/types/settings';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Save, RotateCcw } from 'lucide-react';

interface SettingFormProps {
  setting: SystemSetting;
  onSave: (setting: SystemSetting) => Promise<void>;
  options?: Record<string, string[]>;
}

const SettingForm: React.FC<SettingFormProps> = ({
  setting,
  onSave,
  options = {}
}) => {
  const [value, setValue] = useState(setting.setting_value);
  const [isLoading, setIsLoading] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const handleValueChange = (newValue: string) => {
    setValue(newValue);
    setHasChanges(newValue !== setting.setting_value);
  };

  const handleSave = async () => {
    if (!hasChanges) return;

    setIsLoading(true);
    try {
      await onSave({
        ...setting,
        setting_value: value
      });
      setHasChanges(false);
    } catch (error) {
      console.error('Error saving setting:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setValue(setting.setting_value);
    setHasChanges(false);
  };

  const renderInput = () => {
    const settingOptions = options[setting.setting_key] || getDefaultOptions(setting.setting_key);

    switch (setting.data_type) {
      case 'boolean':
        return (
          <div className="flex items-center space-x-2">
            <Switch
              id={setting.setting_key}
              checked={value === 'true'}
              onCheckedChange={(checked) => handleValueChange(checked ? 'true' : 'false')} />

            <Label htmlFor={setting.setting_key}>
              {value === 'true' ? 'Enabled' : 'Disabled'}
            </Label>
          </div>);


      case 'number':
        return (
          <Input
            type="number"
            value={value}
            onChange={(e) => handleValueChange(e.target.value)}
            placeholder="Enter number" />);



      case 'select':
        return (
          <Select value={value} onValueChange={handleValueChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select an option" />
            </SelectTrigger>
            <SelectContent>
              {settingOptions.map((option) =>
              <SelectItem key={option} value={option}>
                  {option}
                </SelectItem>
              )}
            </SelectContent>
          </Select>);


      case 'json':
        return (
          <Textarea
            value={value}
            onChange={(e) => handleValueChange(e.target.value)}
            placeholder="Enter JSON configuration"
            rows={6}
            className="font-mono text-sm" />);



      default:
        return (
          <Input
            type="text"
            value={value}
            onChange={(e) => handleValueChange(e.target.value)}
            placeholder="Enter value" />);


    }
  };

  return (
    <Card className={`transition-colors ${hasChanges ? 'border-blue-300 bg-blue-50/20' : ''}`}>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">{setting.setting_key.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase())}</CardTitle>
        <p className="text-sm text-muted-foreground">{setting.description}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor={setting.setting_key}>Value</Label>
          {renderInput()}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-xs text-muted-foreground">
              Type: {setting.data_type}
            </span>
            {hasChanges &&
            <span className="text-xs text-blue-600 font-medium">
                Unsaved changes
              </span>
            }
          </div>
          
          <div className="flex space-x-2">
            {hasChanges &&
            <Button
              variant="outline"
              size="sm"
              onClick={handleReset}
              disabled={isLoading}>

                <RotateCcw className="h-4 w-4 mr-1" />
                Reset
              </Button>
            }
            <Button
              size="sm"
              onClick={handleSave}
              disabled={!hasChanges || isLoading}>

              <Save className="h-4 w-4 mr-1" />
              {isLoading ? 'Saving...' : 'Save'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>);

};

const getDefaultOptions = (settingKey: string): string[] => {
  const optionsMap: Record<string, string[]> = {
    currency: ['USD', 'EUR', 'GBP', 'CAD', 'AUD', 'JPY'],
    date_format: ['MM/dd/yyyy', 'dd/MM/yyyy', 'yyyy-MM-dd', 'dd MMM yyyy'],
    timezone: [
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'America/Phoenix',
    'Pacific/Honolulu'],

    backup_frequency: ['hourly', 'daily', 'weekly', 'monthly']
  };

  return optionsMap[settingKey] || [];
};

export default SettingForm;