
import React from 'react';
import { SystemSetting, SettingsCategory } from '@/types/settings';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import SettingForm from './SettingForm';

interface SettingsCategoryProps {
  category: SettingsCategory;
  settings: SystemSetting[];
  onSettingSave: (setting: SystemSetting) => Promise<void>;
}

const SettingsCategoryComponent: React.FC<SettingsCategoryProps> = ({
  category,
  settings,
  onSettingSave
}) => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <span className="text-2xl">{category.icon}</span>
              <div>
                <CardTitle className="text-xl">{category.name}</CardTitle>
                <p className="text-muted-foreground text-sm">{category.description}</p>
              </div>
            </div>
            <Badge variant="secondary">{settings.length} settings</Badge>
          </div>
        </CardHeader>
      </Card>

      <div className="grid gap-4">
        {settings.map((setting) =>
        <SettingForm
          key={setting.id || setting.setting_key}
          setting={setting}
          onSave={onSettingSave} />

        )}
      </div>
    </div>);

};

export default SettingsCategoryComponent;