import React from 'react';
import { cn } from '@/lib/utils';

interface ThreeDotsMenuProps {
  isOpen: boolean;
  onClick: () => void;
  className?: string;
}

const ThreeDotsMenu: React.FC<ThreeDotsMenuProps> = ({ isOpen, onClick, className }) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        // Hide on large screens (desktop), show on mobile/tablet
        'lg:hidden',
        'relative p-2 rounded-full bg-white hover:bg-gray-50 shadow-md border border-gray-200',
        'transition-all duration-300 ease-in-out transform hover:scale-110 active:scale-95',
        'focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2',
        className
      )}
      aria-label="Toggle navigation menu">



      {/* Hamburger-style animation for three dots */}
      <div className="flex flex-col items-center justify-center w-6 h-6 space-y-1">
        <div
          className={cn(
            'w-4 h-0.5 bg-gray-600 rounded-full transition-all duration-300',
            isOpen ? 'transform rotate-45 translate-y-1.5 bg-blue-500' : ''
          )} />



        <div
          className={cn(
            'w-4 h-0.5 bg-gray-600 rounded-full transition-all duration-300',
            isOpen ? 'opacity-0 scale-0' : ''
          )} />



        <div
          className={cn(
            'w-4 h-0.5 bg-gray-600 rounded-full transition-all duration-300',
            isOpen ? 'transform -rotate-45 -translate-y-1.5 bg-blue-500' : ''
          )} />


      </div>

      {/* Ripple effect */}
      <div
        className={cn(
          'absolute inset-0 rounded-full bg-blue-500/20 scale-0 transition-transform duration-200',
          isOpen ? 'scale-100' : ''
        )} />


    </button>);

};

export default ThreeDotsMenu;