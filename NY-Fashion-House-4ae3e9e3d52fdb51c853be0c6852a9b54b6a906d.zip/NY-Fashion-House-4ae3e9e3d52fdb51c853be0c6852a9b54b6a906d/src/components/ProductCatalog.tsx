
import React, { useState } from 'react';
import { formatUSD } from '@/utils/currencyUtils';
import { Product } from '@/types/product';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow } from
'@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger } from
'@/components/ui/alert-dialog';
import { Eye, Edit, Package, AlertTriangle, Trash2 } from 'lucide-react';
import ProductThumbnail from '@/components/ProductThumbnail';
import { enhancedProductService } from '@/services/enhancedProductService';
import { useToast } from '@/hooks/use-toast';

interface ProductCatalogProps {
  products: Product[];
  onViewProduct?: (product: Product) => void;
  onEditProduct?: (product: Product) => void;
  onDeleteProduct?: () => void;
  loading?: boolean;
}

const ProductCatalog: React.FC<ProductCatalogProps> = ({
  products,
  onViewProduct,
  onEditProduct,
  onDeleteProduct,
  loading = false
}) => {
  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);
  const { toast } = useToast();

  const handleDeleteProduct = async (product: Product) => {
    try {
      setDeletingProductId(product.id);
      await enhancedProductService.deleteProduct(product.id);

      toast({
        title: "Product deleted",
        description: `${product.name} has been successfully deleted.`,
        variant: "default"
      });

      // Refresh the product list
      if (onDeleteProduct) {
        onDeleteProduct();
      }
    } catch (error) {
      toast({
        title: "Error deleting product",
        description: error instanceof Error ? error.message : "Failed to delete product. Please try again.",
        variant: "destructive"
      });
    } finally {
      setDeletingProductId(null);
    }
  };
  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          <span className="ml-3">Loading products...</span>
        </CardContent>
      </Card>);

  }

  if (products.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-8">
          <Package className="h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
          <p className="text-gray-500 text-center">
            No products match your current filters. Try adjusting your search criteria.
          </p>
        </CardContent>
      </Card>);

  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-16">Image</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Unit Price</TableHead>
                <TableHead>Total Value</TableHead>
                <TableHead>Status</TableHead>
                {(onViewProduct || onEditProduct || onDeleteProduct) &&
                <TableHead>Actions</TableHead>
                }
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) =>
              <TableRow key={product.id}>
                  <TableCell className="w-16">
                    <ProductThumbnail
                    imageIds={product.imageIds}
                    altText={product.name}
                    size="md"
                    className="mx-auto" />

                  </TableCell>
                  <TableCell>
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900 truncate">{product.name}</p>
                      {product.description &&
                    <p className="text-sm text-gray-500 truncate max-w-xs">
                          {product.description}
                        </p>
                    }
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="max-w-32">
                      <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono break-all">
                        {product.sku.substring(0, 16)}...
                      </code>
                      <div className="text-xs text-gray-500 mt-1" title={product.sku}>
                        128-char SKU
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {product.category.split('-').map((word) =>
                    word.charAt(0).toUpperCase() + word.slice(1)
                    ).join(' ')}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span className={`font-medium ${
                    product.stockLevel === 0 ? 'text-red-600' :
                    product.stockLevel <= product.minStockLevel ? 'text-yellow-600' :
                    'text-gray-900'}`
                    }>
                        {product.stockLevel}
                      </span>
                      {product.stockLevel <= product.minStockLevel &&
                    <AlertTriangle className="w-4 h-4 text-yellow-500" />
                    }
                    </div>
                  </TableCell>
                  <TableCell>
                    {formatUSD(product.sellingPrice)}
                  </TableCell>
                  <TableCell>
                    <span className="font-medium">
                      {formatUSD(product.sellingPrice * product.stockLevel)}
                    </span>
                  </TableCell>
                  <TableCell>
                    {product.stockLevel === 0 ?
                  <Badge variant="destructive">Out of Stock</Badge> :
                  product.stockLevel <= product.minStockLevel ?
                  <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                        Low Stock
                      </Badge> :

                  <Badge variant="default" className="bg-green-100 text-green-800">
                        In Stock
                      </Badge>
                  }
                  </TableCell>
                  {(onViewProduct || onEditProduct || onDeleteProduct) &&
                <TableCell>
                      <div className="flex items-center space-x-2">
                        {onViewProduct &&
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onViewProduct(product)}>

                            <Eye className="w-4 h-4" />
                          </Button>
                    }
                        {onEditProduct &&
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEditProduct(product)}>

                            <Edit className="w-4 h-4" />
                          </Button>
                    }
                        {onDeleteProduct &&
                    <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                          variant="ghost"
                          size="sm"
                          disabled={deletingProductId === product.id}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50">

                              {deletingProductId === product.id ?
                          <div className="w-4 h-4 animate-spin rounded-full border-2 border-red-600 border-t-transparent" /> :

                          <Trash2 className="w-4 h-4" />
                          }
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Product</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete "{product.name}"? This action cannot be undone.
                                The product will be marked as inactive and removed from your inventory.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                            onClick={() => handleDeleteProduct(product)}
                            className="bg-red-600 hover:bg-red-700 focus:ring-red-600">

                                Delete Product
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                    }
                      </div>
                    </TableCell>
                }
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Summary row */}
      <Card>
        <CardContent className="py-4">
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">
              Showing {products.length} products
            </span>
            <span className="font-medium">
              Total Inventory Value: {formatUSD(
                products.reduce((sum, p) => sum + p.sellingPrice * p.stockLevel, 0)
              )}
            </span>
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default ProductCatalog;