
import React, { useState, useEffect } from 'react';
import { Attendance } from '@/types/employee';
import { employeeService } from '@/services/employeeService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import {
  Calendar,
  Clock,
  Plus,
  CheckCircle,
  XCircle,
  AlertCircle,
  TrendingUp } from
'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isSameMonth } from 'date-fns';
import { toast } from 'sonner';

interface AttendanceTrackerProps {
  employeeId: string;
  employeeName: string;
  onAttendanceUpdate: () => void;
}

const AttendanceTracker: React.FC<AttendanceTrackerProps> = ({
  employeeId,
  employeeName,
  onAttendanceUpdate
}) => {
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [newAttendance, setNewAttendance] = useState({
    date: format(new Date(), 'yyyy-MM-dd'),
    clockIn: '09:00',
    clockOut: '17:00',
    breakDuration: 60,
    status: 'present' as const,
    notes: ''
  });

  useEffect(() => {
    loadAttendance();
  }, [employeeId, currentDate]);

  const loadAttendance = async () => {
    setLoading(true);
    try {
      const startDate = format(startOfMonth(currentDate), 'yyyy-MM-dd');
      const endDate = format(endOfMonth(currentDate), 'yyyy-MM-dd');
      const data = await employeeService.getAttendanceByEmployee(employeeId, startDate, endDate);
      setAttendance(data);
    } catch (error) {
      console.error('Failed to load attendance:', error);
      toast.error('Failed to load attendance data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddAttendance = async () => {
    if (!newAttendance.date || !newAttendance.clockIn) {
      toast.error('Date and clock in time are required');
      return;
    }

    setLoading(true);
    try {
      const clockInTime = new Date(`${newAttendance.date}T${newAttendance.clockIn}`);
      const clockOutTime = newAttendance.clockOut ?
      new Date(`${newAttendance.date}T${newAttendance.clockOut}`) :
      undefined;

      let totalHours = 0;
      if (clockOutTime) {
        const diffMs = clockOutTime.getTime() - clockInTime.getTime();
        const diffHours = diffMs / (1000 * 60 * 60);
        totalHours = Math.max(0, diffHours - newAttendance.breakDuration / 60);
      }

      await employeeService.createAttendance({
        employeeId,
        date: newAttendance.date,
        clockIn: `${newAttendance.date}T${newAttendance.clockIn}:00.000Z`,
        clockOut: newAttendance.clockOut ? `${newAttendance.date}T${newAttendance.clockOut}:00.000Z` : undefined,
        breakDuration: newAttendance.breakDuration,
        totalHours,
        status: newAttendance.status,
        notes: newAttendance.notes
      });

      toast.success('Attendance record added successfully');
      setIsDialogOpen(false);
      setNewAttendance({
        date: format(new Date(), 'yyyy-MM-dd'),
        clockIn: '09:00',
        clockOut: '17:00',
        breakDuration: 60,
        status: 'present',
        notes: ''
      });
      loadAttendance();
      onAttendanceUpdate();
    } catch (error) {
      console.error('Failed to add attendance:', error);
      toast.error('Failed to add attendance record');
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'present':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'absent':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'late':
        return <AlertCircle className="h-4 w-4 text-orange-500" />;
      case 'half-day':
        return <Clock className="h-4 w-4 text-blue-500" />;
      case 'overtime':
        return <TrendingUp className="h-4 w-4 text-purple-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-green-100 text-green-800';
      case 'absent':
        return 'bg-red-100 text-red-800';
      case 'late':
        return 'bg-orange-100 text-orange-800';
      case 'half-day':
        return 'bg-blue-100 text-blue-800';
      case 'overtime':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAttendanceForDate = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return attendance.find((att) => att.date === dateStr);
  };

  const monthDays = eachDayOfInterval({
    start: startOfMonth(currentDate),
    end: endOfMonth(currentDate)
  });

  const stats = {
    totalDays: monthDays.length,
    presentDays: attendance.filter((att) => att.status === 'present').length,
    absentDays: attendance.filter((att) => att.status === 'absent').length,
    lateDays: attendance.filter((att) => att.status === 'late').length,
    totalHours: attendance.reduce((sum, att) => sum + att.totalHours, 0)
  };

  const attendanceRate = stats.totalDays > 0 ?
  ((stats.presentDays + stats.lateDays) / stats.totalDays * 100).toFixed(1) :
  '0.0';

  return (
    <div className="space-y-6">
      {/* Header and Stats */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Attendance Tracking</h2>
          <p className="text-gray-600">
            {employeeName} - {format(currentDate, 'MMMM yyyy')}
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1))}>

              Previous
            </Button>
            <span className="font-medium">{format(currentDate, 'MMMM yyyy')}</span>
            <Button
              variant="outline"
              onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1))}>

              Next
            </Button>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Record
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add Attendance Record</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newAttendance.date}
                    onChange={(e) => setNewAttendance({ ...newAttendance, date: e.target.value })} />

                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="clockIn">Clock In</Label>
                    <Input
                      id="clockIn"
                      type="time"
                      value={newAttendance.clockIn}
                      onChange={(e) => setNewAttendance({ ...newAttendance, clockIn: e.target.value })} />

                  </div>

                  <div>
                    <Label htmlFor="clockOut">Clock Out</Label>
                    <Input
                      id="clockOut"
                      type="time"
                      value={newAttendance.clockOut}
                      onChange={(e) => setNewAttendance({ ...newAttendance, clockOut: e.target.value })} />

                  </div>
                </div>

                <div>
                  <Label htmlFor="breakDuration">Break Duration (minutes)</Label>
                  <Input
                    id="breakDuration"
                    type="number"
                    value={newAttendance.breakDuration}
                    onChange={(e) => setNewAttendance({ ...newAttendance, breakDuration: parseInt(e.target.value) || 0 })} />

                </div>

                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={newAttendance.status}
                    onValueChange={(value: any) => setNewAttendance({ ...newAttendance, status: value })}>

                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="present">Present</SelectItem>
                      <SelectItem value="absent">Absent</SelectItem>
                      <SelectItem value="late">Late</SelectItem>
                      <SelectItem value="half-day">Half Day</SelectItem>
                      <SelectItem value="overtime">Overtime</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={newAttendance.notes}
                    onChange={(e) => setNewAttendance({ ...newAttendance, notes: e.target.value })}
                    placeholder="Any additional notes..." />

                </div>

                <div className="flex gap-2 mt-6">
                  <Button
                    onClick={handleAddAttendance}
                    disabled={loading}
                    className="flex-1">

                    {loading ? 'Adding...' : 'Add Record'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                    className="flex-1">

                    Cancel
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Attendance Rate</p>
              <p className="text-2xl font-bold text-green-600">{attendanceRate}%</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Present Days</p>
              <p className="text-2xl font-bold text-green-600">{stats.presentDays}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Absent Days</p>
              <p className="text-2xl font-bold text-red-600">{stats.absentDays}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Late Days</p>
              <p className="text-2xl font-bold text-orange-600">{stats.lateDays}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">Total Hours</p>
              <p className="text-2xl font-bold text-blue-600">{stats.totalHours.toFixed(1)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Calendar View */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Monthly Calendar
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2 mb-4">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) =>
            <div key={day} className="p-2 text-center font-medium text-gray-500 text-sm">
                {day}
              </div>
            )}
          </div>
          
          <div className="grid grid-cols-7 gap-2">
            {monthDays.map((date) => {
              const attendanceRecord = getAttendanceForDate(date);
              const isCurrentMonth = isSameMonth(date, currentDate);

              return (
                <div
                  key={date.toISOString()}
                  className={`
                    p-3 border rounded-lg min-h-16 
                    ${isCurrentMonth ? 'bg-white' : 'bg-gray-50 text-gray-400'}
                    ${isToday(date) ? 'ring-2 ring-blue-500' : ''}
                  `}>

                  <div className="text-sm font-medium mb-1">
                    {format(date, 'd')}
                  </div>
                  {attendanceRecord &&
                  <div className="flex items-center justify-center">
                      <Badge className={`text-xs ${getStatusColor(attendanceRecord.status)}`}>
                        <span className="flex items-center gap-1">
                          {getStatusIcon(attendanceRecord.status)}
                          {attendanceRecord.status}
                        </span>
                      </Badge>
                    </div>
                  }
                </div>);

            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Records */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Attendance Records</CardTitle>
        </CardHeader>
        <CardContent>
          {attendance.length === 0 ?
          <div className="text-center py-8">
              <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No attendance records</h3>
              <p className="text-gray-600 mb-4">Start by adding the first attendance record.</p>
              <Button onClick={() => setIsDialogOpen(true)} className="flex items-center gap-2 mx-auto">
                <Plus className="h-4 w-4" />
                Add First Record
              </Button>
            </div> :

          <div className="space-y-3">
              {attendance.slice(0, 10).map((record) =>
            <div key={record.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(record.status)}
                    <div>
                      <p className="font-medium">{format(new Date(record.date), 'EEEE, MMMM d, yyyy')}</p>
                      <p className="text-sm text-gray-600">
                        {format(new Date(record.clockIn), 'HH:mm')} - {' '}
                        {record.clockOut ? format(new Date(record.clockOut), 'HH:mm') : 'Not clocked out'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className={getStatusColor(record.status)}>
                      {record.status}
                    </Badge>
                    <p className="text-sm text-gray-600 mt-1">
                      {record.totalHours.toFixed(1)}h
                    </p>
                  </div>
                </div>
            )}
            </div>
          }
        </CardContent>
      </Card>
    </div>);

};

export default AttendanceTracker;