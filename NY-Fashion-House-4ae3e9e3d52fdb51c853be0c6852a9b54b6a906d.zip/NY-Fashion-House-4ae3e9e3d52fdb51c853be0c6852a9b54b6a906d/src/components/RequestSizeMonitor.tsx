import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, RefreshCw, Activity } from 'lucide-react';
import { formatFileSize, requestSizeManager } from '@/utils/requestSizeManager';

interface RequestMetric {
  timestamp: Date;
  size: number;
  type: 'api' | 'upload' | 'bulk';
  status: 'success' | 'failed' | 'too-large';
  endpoint?: string;
}

interface RequestSizeMonitorProps {
  className?: string;
}

const RequestSizeMonitor: React.FC<RequestSizeMonitorProps> = ({ className = '' }) => {
  const [metrics, setMetrics] = useState<RequestMetric[]>([]);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [currentConfig, setCurrentConfig] = useState({
    maxSize: 50 * 1024 * 1024, // 50MB
    chunkSize: 5 * 1024 * 1024, // 5MB
    timeout: 300000 // 5 minutes
  });

  useEffect(() => {
    // Initialize request size manager
    requestSizeManager.configure(currentConfig);
  }, [currentConfig]);

  const addMetric = (metric: RequestMetric) => {
    setMetrics(prev => [...prev.slice(-99), metric]); // Keep last 100 metrics
  };

  const getMetricsSummary = () => {
    const last24Hours = metrics.filter(m => 
      Date.now() - m.timestamp.getTime() < 24 * 60 * 60 * 1000
    );

    const successful = last24Hours.filter(m => m.status === 'success').length;
    const failed = last24Hours.filter(m => m.status === 'failed').length;
    const tooLarge = last24Hours.filter(m => m.status === 'too-large').length;
    const totalSize = last24Hours.reduce((sum, m) => sum + m.size, 0);

    return {
      total: last24Hours.length,
      successful,
      failed,
      tooLarge,
      averageSize: last24Hours.length > 0 ? totalSize / last24Hours.length : 0,
      maxSize: Math.max(...last24Hours.map(m => m.size), 0)
    };
  };

  const updateConfig = (newConfig: Partial<typeof currentConfig>) => {
    setCurrentConfig(prev => ({ ...prev, ...newConfig }));
  };

  const clearMetrics = () => {
    setMetrics([]);
  };

  const summary = getMetricsSummary();
  const utilizationPercentage = (summary.maxSize / currentConfig.maxSize) * 100;

  return (
    <div className={`space-y-4 ${className}`}>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Request Size Monitor</CardTitle>
          <Activity className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div>
              <div className="text-2xl font-bold text-green-600">{summary.successful}</div>
              <div className="text-xs text-muted-foreground">Successful</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-red-600">{summary.failed}</div>
              <div className="text-xs text-muted-foreground">Failed</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-yellow-600">{summary.tooLarge}</div>
              <div className="text-xs text-muted-foreground">Too Large</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{summary.total}</div>
              <div className="text-xs text-muted-foreground">Total (24h)</div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Size Utilization</span>
              <span>{Math.round(utilizationPercentage)}%</span>
            </div>
            <Progress value={utilizationPercentage} className="h-2" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Avg: {formatFileSize(summary.averageSize)}</span>
              <span>Max: {formatFileSize(summary.maxSize)}</span>
              <span>Limit: {formatFileSize(currentConfig.maxSize)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Configuration</CardTitle>
          <CardDescription>
            Adjust request size limits and chunking behavior
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium">Max Request Size (MB)</label>
            <input
              type="number"
              value={currentConfig.maxSize / (1024 * 1024)}
              onChange={(e) => updateConfig({ 
                maxSize: parseInt(e.target.value) * 1024 * 1024 
              })}
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
              min="1"
              max="100"
            />
          </div>
          
          <div>
            <label className="text-sm font-medium">Chunk Size (MB)</label>
            <input
              type="number"
              value={currentConfig.chunkSize / (1024 * 1024)}
              onChange={(e) => updateConfig({ 
                chunkSize: parseInt(e.target.value) * 1024 * 1024 
              })}
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
              min="1"
              max="20"
            />
          </div>

          <div>
            <label className="text-sm font-medium">Timeout (seconds)</label>
            <input
              type="number"
              value={currentConfig.timeout / 1000}
              onChange={(e) => updateConfig({ 
                timeout: parseInt(e.target.value) * 1000 
              })}
              className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
              min="30"
              max="600"
            />
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsMonitoring(!isMonitoring)}
            >
              {isMonitoring ? 'Stop' : 'Start'} Monitoring
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={clearMetrics}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Clear Metrics
            </Button>
          </div>
        </CardContent>
      </Card>

      {summary.tooLarge > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {summary.tooLarge} requests were rejected due to size limits in the last 24 hours. 
            Consider enabling chunking or reducing payload sizes.
          </AlertDescription>
        </Alert>
      )}

      {metrics.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {metrics.slice(-10).reverse().map((metric, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    {metric.status === 'success' ? (
                      <CheckCircle className="h-3 w-3 text-green-500" />
                    ) : (
                      <AlertTriangle className="h-3 w-3 text-red-500" />
                    )}
                    <Badge variant="outline" className="text-xs">
                      {metric.type}
                    </Badge>
                    <span>{formatFileSize(metric.size)}</span>
                  </div>
                  <div className="text-muted-foreground">
                    {metric.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default RequestSizeMonitor;