import React, { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface ImageWithFallbackProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  fallbackSrc?: string;
  alt: string;
}

const ImageWithFallback: React.FC<ImageWithFallbackProps> = ({
  src,
  fallbackSrc,
  alt,
  className,
  ...props
}) => {
  const [imgSrc, setImgSrc] = useState(src);
  const [isError, setIsError] = useState(false);

  // Create a data URL for a simple placeholder
  const createPlaceholderSVG = () => {
    const svg = `
      <svg width="100" height="100" xmlns="http://www.w3.org/2000/svg">
        <rect width="100%" height="100%" fill="#f3f4f6"/>
        <text x="50%" y="50%" text-anchor="middle" dy="0.3em" font-family="Arial" font-size="12" fill="#6b7280">
          No Image
        </text>
      </svg>
    `;
    return `data:image/svg+xml;base64,${btoa(svg)}`;
  };

  const defaultFallback = fallbackSrc || createPlaceholderSVG();

  useEffect(() => {
    setImgSrc(src);
    setIsError(false);
  }, [src]);

  const handleError = () => {
    if (!isError && defaultFallback && imgSrc !== defaultFallback) {
      setImgSrc(defaultFallback);
      setIsError(true);
    } else if (isError) {
      // If even the fallback fails, use the SVG placeholder
      setImgSrc(createPlaceholderSVG());
    }
  };

  return (
    <img
      {...props}
      src={imgSrc}
      alt={alt}
      className={cn(className)}
      onError={handleError}
      loading="lazy" />);


};

export default ImageWithFallback;