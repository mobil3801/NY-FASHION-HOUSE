
import React, { useRef, useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Home,
  Users,
  Package,
  ShoppingCart,
  UserCheck,
  DollarSign,
  Calculator,
  BarChart3,
  Settings,
  Shield,
  Database,
  CheckCircle2,
  Building2,
  Bug,
  TestTube } from
'lucide-react';

const baseNavigation = [
{ name: 'Dashboard', href: '/', icon: Home },
{ name: 'Customers', href: '/customers', icon: Users },
{ name: 'Products', href: '/products', icon: Package },
{ name: 'Point of Sale', href: '/pos', icon: ShoppingCart },
{ name: 'Invoice & Sale Record', href: '/transaction-management', icon: DollarSign },
{ name: 'Supplier List', href: '/suppliers', icon: Building2 },
{ name: 'Employees', href: '/employees', icon: UserCheck },
{ name: 'Salary Management', href: '/salary', icon: DollarSign },
{ name: 'Accounting', href: '/accounting', icon: Calculator },
{ name: 'Reports', href: '/reports', icon: BarChart3 },
{ name: 'Backup Management', href: '/backup-management', icon: Shield },
{ name: 'Data Management', href: '/data-management', icon: Database },
{ name: 'Settings', href: '/system-settings', icon: Settings }];

const devOnlyNavigation = [
{ name: 'QA Testing', href: '/qa-dashboard', icon: TestTube },
{ name: 'Performance Testing', href: '/performance-testing', icon: TestTube },
{ name: 'Error Dashboard', href: '/error-dashboard', icon: Bug },
{ name: 'Error Testing', href: '/error-testing', icon: Bug }];


// Show QA and Performance testing items only in development/testing environments
const navigation = import.meta.env.PROD ?
baseNavigation :
[...baseNavigation.slice(0, 8), ...devOnlyNavigation, ...baseNavigation.slice(8)];


interface HorizontalNavigationProps {
  className?: string;
}

const HorizontalNavigation: React.FC<HorizontalNavigationProps> = ({ className }) => {
  const location = useLocation();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, scrollLeft: 0 });

  // Check scroll position and update button states
  const updateScrollButtons = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 1);
    }
  };

  // Scroll to left
  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: -200,
        behavior: 'smooth'
      });
    }
  };

  // Scroll to right
  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: 200,
        behavior: 'smooth'
      });
    }
  };

  // Handle drag start
  const handleMouseDown = (e: React.MouseEvent) => {
    if (scrollContainerRef.current) {
      setIsDragging(true);
      setDragStart({
        x: e.pageX - scrollContainerRef.current.offsetLeft,
        scrollLeft: scrollContainerRef.current.scrollLeft
      });
      scrollContainerRef.current.style.cursor = 'grabbing';
    }
  };

  // Handle drag move
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !scrollContainerRef.current) return;
    e.preventDefault();
    const x = e.pageX - scrollContainerRef.current.offsetLeft;
    const walk = (x - dragStart.x) * 2; // Multiply by 2 for faster scrolling
    scrollContainerRef.current.scrollLeft = dragStart.scrollLeft - walk;
  };

  // Handle drag end
  const handleMouseUp = () => {
    setIsDragging(false);
    if (scrollContainerRef.current) {
      scrollContainerRef.current.style.cursor = 'grab';
    }
  };

  // Handle drag leave
  const handleMouseLeave = () => {
    setIsDragging(false);
    if (scrollContainerRef.current) {
      scrollContainerRef.current.style.cursor = 'grab';
    }
  };

  // Touch events for mobile drag support
  const handleTouchStart = (e: React.TouchEvent) => {
    if (scrollContainerRef.current) {
      setIsDragging(true);
      setDragStart({
        x: e.touches[0].pageX - scrollContainerRef.current.offsetLeft,
        scrollLeft: scrollContainerRef.current.scrollLeft
      });
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || !scrollContainerRef.current) return;
    const x = e.touches[0].pageX - scrollContainerRef.current.offsetLeft;
    const walk = (x - dragStart.x) * 2;
    scrollContainerRef.current.scrollLeft = dragStart.scrollLeft - walk;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // Update scroll buttons on mount and scroll
  useEffect(() => {
    updateScrollButtons();
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', updateScrollButtons);
      return () => container.removeEventListener('scroll', updateScrollButtons);
    }
  }, []);

  // Update scroll buttons on resize
  useEffect(() => {
    const handleResize = () => updateScrollButtons();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className={cn("relative hidden lg:block", className)}>
      {/* Left scroll button */}
      <Button
        variant="ghost"
        size="sm"
        className={cn(
          "absolute left-0 top-1/2 -translate-y-1/2 z-10 h-8 w-8 rounded-full",
          "shadow-lg transition-all duration-200",
          !canScrollLeft && "opacity-50 cursor-not-allowed"
        )}
        style={{
          backgroundColor: 'var(--theme-card)',
          border: '1px solid var(--theme-border)',
          color: 'var(--theme-text)'
        }}
        onClick={scrollLeft}
        disabled={!canScrollLeft}>

        <ChevronLeft className="h-4 w-4" />
      </Button>

      {/* Right scroll button */}
      <Button
        variant="ghost"
        size="sm"
        className={cn(
          "absolute right-0 top-1/2 -translate-y-1/2 z-10 h-8 w-8 rounded-full",
          "shadow-lg transition-all duration-200",
          !canScrollRight && "opacity-50 cursor-not-allowed"
        )}
        style={{
          backgroundColor: 'var(--theme-card)',
          border: '1px solid var(--theme-border)',
          color: 'var(--theme-text)'
        }}
        onClick={scrollRight}
        disabled={!canScrollRight}>

        <ChevronRight className="h-4 w-4" />
      </Button>

      {/* Scrollable navigation container */}
      <div className="px-10">
        <div
          ref={scrollContainerRef}
          className={cn(
            "flex items-center space-x-1 overflow-x-auto scrollbar-hide",
            "scroll-smooth py-2 cursor-grab select-none",
            isDragging && "cursor-grabbing"
          )}
          style={{
            scrollbarWidth: 'none',
            msOverflowStyle: 'none'
          }}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseLeave}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}>

          {navigation.map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <Link
                key={item.name}
                to={item.href}
                className={cn(
                  "flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium",
                  "transition-all duration-200 whitespace-nowrap flex-shrink-0",
                  "hover:scale-105 hover:shadow-sm pointer-events-auto",
                  isActive ?
                  "shadow-md" :
                  "transition-colors duration-300"
                )}
                style={{
                  backgroundColor: isActive ? 'var(--theme-primary)' : 'transparent',
                  color: isActive ? 'var(--theme-background)' : 'var(--theme-text)'
                }}
                onMouseDown={(e) => e.stopPropagation()}> {/* Prevent drag when clicking links */}
                <item.icon
                  className={cn(
                    "h-4 w-4 flex-shrink-0",
                    isActive ? "" : "opacity-70"
                  )}
                  style={{
                    color: isActive ? 'var(--theme-background)' : 'var(--theme-text)'
                  }} />

                <span>{item.name}</span>
              </Link>);

          })}
        </div>
      </div>

      <style jsx>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>);

};

export default HorizontalNavigation;