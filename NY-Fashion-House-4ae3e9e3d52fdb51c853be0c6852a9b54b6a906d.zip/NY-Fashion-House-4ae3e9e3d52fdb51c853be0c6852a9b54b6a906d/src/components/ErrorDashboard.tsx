// Error Dashboard - Comprehensive error monitoring and management interface
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  AlertTriangle,
  Bug,
  Download,
  Eye,
  Filter,
  RefreshCw,
  Trash2,
  TrendingUp,
  CheckCircle,
  XCircle,
  AlertCircle,
  Info } from
'lucide-react';
import {
  comprehensiveErrorTrackingService,
  ComprehensiveErrorReport,
  ErrorStatistics } from
'@/services/comprehensiveErrorTrackingService';

interface ErrorDashboardProps {
  className?: string;
}

const ErrorDashboard: React.FC<ErrorDashboardProps> = ({ className }) => {
  const [errorReports, setErrorReports] = useState<ComprehensiveErrorReport[]>([]);
  const [statistics, setStatistics] = useState<ErrorStatistics | null>(null);
  const [selectedError, setSelectedError] = useState<ComprehensiveErrorReport | null>(null);
  const [filter, setFilter] = useState<'all' | 'unresolved' | 'critical' | 'recent'>('all');
  const [isLoading, setIsLoading] = useState(true);

  const refreshData = () => {
    setIsLoading(true);
    const reports = comprehensiveErrorTrackingService.getErrorReports();
    const stats = comprehensiveErrorTrackingService.getStatistics();

    setErrorReports(reports);
    setStatistics(stats);
    setIsLoading(false);
  };

  useEffect(() => {
    refreshData();

    // Refresh every 30 seconds
    const interval = setInterval(refreshData, 30000);
    return () => clearInterval(interval);
  }, []);

  const filteredErrors = errorReports.filter((error) => {
    switch (filter) {
      case 'unresolved':
        return !error.resolved;
      case 'critical':
        return error.severity === 'critical';
      case 'recent':
        return Date.now() - new Date(error.timestamp).getTime() < 60 * 60 * 1000; // Last hour
      default:
        return true;
    }
  });

  const handleResolveError = (errorId: string) => {
    comprehensiveErrorTrackingService.resolveError(errorId);
    refreshData();
  };

  const handleRetryError = async (errorId: string) => {
    await comprehensiveErrorTrackingService.retryOperation(errorId);
    refreshData();
  };

  const handleClearAll = () => {
    comprehensiveErrorTrackingService.clearAllErrors();
    refreshData();
  };

  const handleExport = () => {
    const data = comprehensiveErrorTrackingService.exportErrorReports();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `error-reports-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'high':
        return <AlertCircle className="w-4 h-4 text-orange-500" />;
      case 'medium':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default:
        return <Info className="w-4 h-4 text-blue-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  if (isLoading) {
    return (
      <div className={`flex items-center justify-center p-8 ${className}`}>
        <RefreshCw className="w-6 h-6 animate-spin mr-2" />
        Loading error reports...
      </div>);

  }

  return (
    <div className={`p-6 space-y-6 ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Error Dashboard</h1>
          <p className="text-sm text-gray-600">Monitor and manage application errors</p>
        </div>
        
        <div className="flex gap-2">
          <Button onClick={refreshData} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={handleExport} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={handleClearAll} variant="destructive" size="sm">
            <Trash2 className="w-4 h-4 mr-2" />
            Clear All
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      {statistics &&
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Errors</p>
                  <p className="text-2xl font-bold">{statistics.totalErrors}</p>
                </div>
                <Bug className="w-8 h-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Recent Errors</p>
                  <p className="text-2xl font-bold text-orange-600">{statistics.recentErrors}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Critical Errors</p>
                  <p className="text-2xl font-bold text-red-600">{statistics.errorsBySeverity.critical || 0}</p>
                </div>
                <XCircle className="w-8 h-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Resolved</p>
                  <p className="text-2xl font-bold text-green-600">{statistics.resolvedErrors}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>
      }

      <Tabs defaultValue="errors" className="w-full">
        <TabsList>
          <TabsTrigger value="errors">Error Reports</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="top-errors">Top Errors</TabsTrigger>
        </TabsList>

        <TabsContent value="errors" className="space-y-4">
          {/* Filter Controls */}
          <div className="flex gap-2">
            <Button
              onClick={() => setFilter('all')}
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm">

              All
            </Button>
            <Button
              onClick={() => setFilter('unresolved')}
              variant={filter === 'unresolved' ? 'default' : 'outline'}
              size="sm">

              Unresolved
            </Button>
            <Button
              onClick={() => setFilter('critical')}
              variant={filter === 'critical' ? 'default' : 'outline'}
              size="sm">

              Critical
            </Button>
            <Button
              onClick={() => setFilter('recent')}
              variant={filter === 'recent' ? 'default' : 'outline'}
              size="sm">

              Recent
            </Button>
          </div>

          {/* Error List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5" />
                Error Reports ({filteredErrors.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {filteredErrors.length === 0 ?
              <div className="text-center py-8 text-gray-500">
                  <CheckCircle className="w-12 h-12 mx-auto mb-4 text-green-500" />
                  <p className="text-lg font-medium">No errors found</p>
                  <p className="text-sm">Your application is running smoothly!</p>
                </div> :

              <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {filteredErrors.map((error) =>
                  <div
                    key={error.id}
                    className="p-3 border rounded-lg hover:bg-gray-50 transition-colors">

                        <div className="flex items-start justify-between">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2">
                              {getSeverityIcon(error.severity)}
                              <Badge className={getSeverityColor(error.severity)}>
                                {error.severity}
                              </Badge>
                              <Badge variant="outline">{error.category}</Badge>
                              {error.resolved &&
                          <Badge className="bg-green-100 text-green-800">
                                  Resolved
                                </Badge>
                          }
                            </div>
                            
                            <h4 className="font-medium text-sm mb-1">
                              {error.displayTitle}
                            </h4>
                            
                            <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                              {error.message}
                            </p>
                            
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              <span>
                                {new Date(error.timestamp).toLocaleString()}
                              </span>
                              {error.context.component &&
                          <span>Component: {error.context.component}</span>
                          }
                              {error.retryCount > 0 &&
                          <span>Retries: {error.retryCount}</span>
                          }
                            </div>
                          </div>
                          
                          <div className="flex gap-1 ml-4">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedError(error)}>

                                  <Eye className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle className="flex items-center gap-2">
                                    {getSeverityIcon(error.severity)}
                                    {error.displayTitle}
                                  </DialogTitle>
                                </DialogHeader>
                                <ErrorDetailView error={error} />
                              </DialogContent>
                            </Dialog>

                            {error.isRecoverable && !error.resolved &&
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRetryError(error.id)}>

                                <RefreshCw className="w-4 h-4" />
                              </Button>
                        }

                            {!error.resolved &&
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleResolveError(error.id)}>

                                <CheckCircle className="w-4 h-4" />
                              </Button>
                        }
                          </div>
                        </div>
                      </div>
                  )}
                  </div>
                </ScrollArea>
              }
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          {statistics &&
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Errors by Category</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(statistics.errorsByCategory).map(([category, count]) =>
                  <div key={category} className="flex justify-between items-center">
                        <span className="capitalize">{category}</span>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                  )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Errors by Severity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(statistics.errorsBySeverity).map(([severity, count]) =>
                  <div key={severity} className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          {getSeverityIcon(severity)}
                          <span className="capitalize">{severity}</span>
                        </div>
                        <Badge className={getSeverityColor(severity)}>{count}</Badge>
                      </div>
                  )}
                  </div>
                </CardContent>
              </Card>
            </div>
          }
        </TabsContent>

        <TabsContent value="top-errors" className="space-y-4">
          {statistics &&
          <Card>
              <CardHeader>
                <CardTitle>Most Frequent Errors</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {statistics.topErrors.map((error, index) =>
                <div key={index} className="p-3 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-sm">{error.message}</h4>
                        <Badge variant="destructive">{error.count}x</Badge>
                      </div>
                      <p className="text-xs text-gray-500">
                        Last occurred: {new Date(error.lastOccurred).toLocaleString()}
                      </p>
                    </div>
                )}
                </div>
              </CardContent>
            </Card>
          }
        </TabsContent>
      </Tabs>
    </div>);

};

// Error Detail View Component
const ErrorDetailView: React.FC<{error: ComprehensiveErrorReport;}> = ({ error }) => {
  return (
    <div className="space-y-6">
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          {error.userFriendlyMessage}
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-medium mb-2">Error Information</h4>
          <div className="space-y-2 text-sm">
            <div><strong>ID:</strong> {error.id}</div>
            <div><strong>Timestamp:</strong> {new Date(error.timestamp).toLocaleString()}</div>
            <div><strong>Severity:</strong> <Badge className={getSeverityColor(error.severity)}>{error.severity}</Badge></div>
            <div><strong>Category:</strong> {error.category}</div>
            <div><strong>Recoverable:</strong> {error.isRecoverable ? 'Yes' : 'No'}</div>
            <div><strong>Retry Count:</strong> {error.retryCount}</div>
          </div>
        </div>

        <div>
          <h4 className="font-medium mb-2">Context</h4>
          <div className="space-y-2 text-sm">
            {error.context.component && <div><strong>Component:</strong> {error.context.component}</div>}
            {error.context.action && <div><strong>Action:</strong> {error.context.action}</div>}
            {error.context.route && <div><strong>Route:</strong> {error.context.route}</div>}
            {error.errorLocation && <div><strong>Location:</strong> {error.errorLocation}</div>}
          </div>
        </div>
      </div>

      <div>
        <h4 className="font-medium mb-2">Root Cause Analysis</h4>
        <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-lg">
          {error.rootCause}
        </p>
      </div>

      {error.recommendations.length > 0 &&
      <div>
          <h4 className="font-medium mb-2">Recommendations</h4>
          <ul className="text-sm space-y-1">
            {error.recommendations.map((rec, index) =>
          <li key={index} className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                {rec}
              </li>
          )}
          </ul>
        </div>
      }

      {error.componentTrace && error.componentTrace.length > 0 &&
      <div>
          <h4 className="font-medium mb-2">Component Trace</h4>
          <p className="text-sm font-mono bg-gray-50 p-3 rounded-lg">
            {error.componentTrace.join(' → ')}
          </p>
        </div>
      }

      {error.stack &&
      <div>
          <h4 className="font-medium mb-2">Stack Trace</h4>
          <pre className="text-xs bg-gray-50 p-3 rounded-lg overflow-x-auto whitespace-pre-wrap">
            {error.stack}
          </pre>
        </div>
      }
    </div>);

};

export default ErrorDashboard;