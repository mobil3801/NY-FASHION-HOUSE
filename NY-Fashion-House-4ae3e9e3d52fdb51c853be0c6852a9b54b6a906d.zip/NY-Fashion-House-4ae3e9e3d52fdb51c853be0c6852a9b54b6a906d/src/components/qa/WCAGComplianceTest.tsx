
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, AlertTriangle, XCircle, Play, Eye, Globe } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface WCAGViolation {
  id: string;
  impact: 'critical' | 'serious' | 'moderate' | 'minor';
  description: string;
  help: string;
  helpUrl: string;
  nodes: Array<{
    html: string;
    target: string[];
  }>;
}

interface WCAGTestResult {
  url: string;
  level: string;
  violations: WCAGViolation[];
  passes: number;
  incomplete: number;
  timestamp: string;
}

interface WCAGComplianceTestProps {
  onTestComplete: () => void;
}

const WCAGComplianceTest: React.FC<WCAGComplianceTestProps> = ({ onTestComplete }) => {
  const [testUrl, setTestUrl] = useState('');
  const [wcagLevel, setWcagLevel] = useState('AA');
  const [testing, setTesting] = useState(false);
  const [testResults, setTestResults] = useState<WCAGTestResult | null>(null);
  const [progress, setProgress] = useState(0);

  const runWCAGTest = async () => {
    if (!testUrl) {
      toast({
        title: "Error",
        description: "Please enter a URL to test",
        variant: "destructive"
      });
      return;
    }

    setTesting(true);
    setProgress(0);
    setTestResults(null);

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 500);

      // Simulate WCAG testing with mock data
      await new Promise((resolve) => setTimeout(resolve, 5000));
      clearInterval(progressInterval);
      setProgress(100);

      // Generate mock WCAG test results
      const mockResults: WCAGTestResult = {
        url: testUrl,
        level: wcagLevel,
        violations: [
        {
          id: 'color-contrast',
          impact: 'serious',
          description: 'Elements must have sufficient color contrast',
          help: 'Ensure sufficient contrast between foreground and background colors',
          helpUrl: 'https://dequeuniversity.com/rules/axe/4.4/color-contrast',
          nodes: [
          {
            html: '<button class="btn-primary">Submit</button>',
            target: ['.btn-primary']
          }]

        },
        {
          id: 'heading-order',
          impact: 'moderate',
          description: 'Heading levels should only increase by one',
          help: 'Ensure headings are in a logical order',
          helpUrl: 'https://dequeuniversity.com/rules/axe/4.4/heading-order',
          nodes: [
          {
            html: '<h3>Section Title</h3>',
            target: ['h3']
          }]

        },
        {
          id: 'alt-text',
          impact: 'critical',
          description: 'Images must have alternative text',
          help: 'Ensure images have alt text for screen readers',
          helpUrl: 'https://dequeuniversity.com/rules/axe/4.4/image-alt',
          nodes: [
          {
            html: '<img src="logo.png">',
            target: ['img']
          }]

        }],

        passes: 24,
        incomplete: 2,
        timestamp: new Date().toISOString()
      };

      setTestResults(mockResults);

      // Save results to database
      await saveWCAGResults(mockResults);

      toast({
        title: "WCAG Test Completed",
        description: `Found ${mockResults.violations.length} accessibility violations`
      });

    } catch (error) {
      console.error('Error running WCAG test:', error);
      toast({
        title: "Error",
        description: "Failed to run WCAG test",
        variant: "destructive"
      });
    } finally {
      setTesting(false);
      setProgress(0);
    }
  };

  const saveWCAGResults = async (results: WCAGTestResult) => {
    try {
      // Create a new QA report for WCAG test
      const reportData = {
        report_name: `WCAG ${results.level} Compliance Test`,
        report_type: 'WCAG Accessibility',
        execution_date: results.timestamp,
        total_tests: results.violations.length + results.passes + results.incomplete,
        passed_tests: results.passes,
        failed_tests: results.violations.length,
        pass_rate: results.passes / (results.violations.length + results.passes + results.incomplete) * 100,
        status: 'Completed',
        created_by: 'WCAG Test Runner'
      };

      const { error: reportError } = await window.ezsite.apis.tableCreate(38559, reportData);
      if (reportError) throw reportError;

      // Save WCAG specific results
      const wcagData = {
        report_id: 0, // Will be updated with actual report ID in production
        test_url: results.url,
        wcag_level: results.level,
        total_violations: results.violations.length,
        critical_violations: results.violations.filter((v) => v.impact === 'critical').length,
        moderate_violations: results.violations.filter((v) => v.impact === 'serious' || v.impact === 'moderate').length,
        minor_violations: results.violations.filter((v) => v.impact === 'minor').length,
        compliance_score: results.passes / (results.violations.length + results.passes + results.incomplete) * 100,
        test_date: results.timestamp
      };

      const { error: wcagError } = await window.ezsite.apis.tableCreate(38561, wcagData);
      if (wcagError) throw wcagError;

      onTestComplete();

    } catch (error) {
      console.error('Error saving WCAG results:', error);
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'critical':return 'destructive';
      case 'serious':return 'destructive';
      case 'moderate':return 'default';
      case 'minor':return 'secondary';
      default:return 'default';
    }
  };

  const getImpactIcon = (impact: string) => {
    switch (impact) {
      case 'critical':return <XCircle className="h-4 w-4" />;
      case 'serious':return <AlertTriangle className="h-4 w-4" />;
      case 'moderate':return <AlertTriangle className="h-4 w-4" />;
      case 'minor':return <Eye className="h-4 w-4" />;
      default:return <Eye className="h-4 w-4" />;
    }
  };

  const calculateComplianceScore = () => {
    if (!testResults) return 0;
    const total = testResults.violations.length + testResults.passes + testResults.incomplete;
    return total > 0 ? testResults.passes / total * 100 : 0;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            WCAG Compliance Testing
          </CardTitle>
          <CardDescription>
            Test web pages for accessibility compliance against WCAG guidelines
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="text-sm font-medium">Test URL</label>
              <Input
                placeholder="https://example.com"
                value={testUrl}
                onChange={(e) => setTestUrl(e.target.value)}
                disabled={testing} />

            </div>
            <div>
              <label className="text-sm font-medium">WCAG Level</label>
              <Select value={wcagLevel} onValueChange={setWcagLevel} disabled={testing}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">Level A</SelectItem>
                  <SelectItem value="AA">Level AA</SelectItem>
                  <SelectItem value="AAA">Level AAA</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={runWCAGTest} disabled={testing || !testUrl}>
              <Play className="mr-2 h-4 w-4" />
              {testing ? 'Running Test...' : 'Run WCAG Test'}
            </Button>
          </div>

          {testing &&
          <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Testing accessibility compliance...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} />
            </div>
          }
        </CardContent>
      </Card>

      {testResults &&
      <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Compliance Score</p>
                    <p className="text-2xl font-bold text-green-600">
                      {calculateComplianceScore().toFixed(1)}%
                    </p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Violations</p>
                    <p className="text-2xl font-bold text-red-600">
                      {testResults.violations.length}
                    </p>
                  </div>
                  <XCircle className="h-8 w-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Passed</p>
                    <p className="text-2xl font-bold text-green-600">
                      {testResults.passes}
                    </p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Incomplete</p>
                    <p className="text-2xl font-bold text-yellow-600">
                      {testResults.incomplete}
                    </p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Test Results</CardTitle>
              <CardDescription>
                WCAG {testResults.level} compliance results for {testResults.url}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="violations">
                <TabsList>
                  <TabsTrigger value="violations">
                    Violations ({testResults.violations.length})
                  </TabsTrigger>
                  <TabsTrigger value="summary">Summary</TabsTrigger>
                </TabsList>

                <TabsContent value="violations" className="space-y-4">
                  {testResults.violations.map((violation, index) =>
                <Alert key={index}>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-2">
                          {getImpactIcon(violation.impact)}
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{violation.description}</p>
                              <Badge variant={getImpactColor(violation.impact)}>
                                {violation.impact}
                              </Badge>
                            </div>
                            <AlertDescription>
                              {violation.help}
                            </AlertDescription>
                            <div className="space-y-1">
                              <p className="text-sm font-medium">Affected Elements:</p>
                              {violation.nodes.map((node, nodeIndex) =>
                          <div key={nodeIndex} className="ml-4 p-2 bg-muted rounded text-sm">
                                  <code>{node.html}</code>
                                  <div className="text-xs text-muted-foreground mt-1">
                                    Target: {node.target.join(', ')}
                                  </div>
                                </div>
                          )}
                            </div>
                            <Button variant="link" size="sm" className="h-auto p-0">
                              <a href={violation.helpUrl} target="_blank" rel="noopener noreferrer">
                                Learn more about fixing this issue
                              </a>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Alert>
                )}
                </TabsContent>

                <TabsContent value="summary">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium">Test Details</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>URL Tested:</span>
                            <span className="font-mono">{testResults.url}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>WCAG Level:</span>
                            <span>{testResults.level}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Test Date:</span>
                            <span>{new Date(testResults.timestamp).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium">Violation Breakdown</h4>
                        <div className="space-y-2 text-sm">
                          {['critical', 'serious', 'moderate', 'minor'].map((impact) => {
                          const count = testResults.violations.filter((v) => v.impact === impact).length;
                          return count > 0 ?
                          <div key={impact} className="flex justify-between">
                                <span className="capitalize">{impact}:</span>
                                <Badge variant={getImpactColor(impact)} className="text-xs">
                                  {count}
                                </Badge>
                              </div> :
                          null;
                        })}
                        </div>
                      </div>
                    </div>

                    <Alert>
                      <CheckCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Recommendation:</strong> Focus on fixing Critical and Serious violations first, 
                        as these have the most significant impact on users with disabilities. 
                        Review the specific guidance provided for each violation type.
                      </AlertDescription>
                    </Alert>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      }
    </div>);

};

export default WCAGComplianceTest;