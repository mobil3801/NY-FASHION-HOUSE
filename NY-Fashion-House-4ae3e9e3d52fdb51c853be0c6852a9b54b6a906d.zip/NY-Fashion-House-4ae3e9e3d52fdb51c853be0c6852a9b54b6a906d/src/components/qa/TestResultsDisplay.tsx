
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { CheckCircle, XCircle, AlertTriangle, Clock, Eye, BarChart3 } from 'lucide-react';
import { qaTestingService, TestResult, TestExecution } from '@/services/qaTestingService';

interface TestResultsDisplayProps {
  executionId?: number;
  showRecentResults?: boolean;
  maxResults?: number;
}

const TestResultsDisplay: React.FC<TestResultsDisplayProps> = ({
  executionId,
  showRecentResults = false,
  maxResults = 50
}) => {
  const [results, setResults] = useState<TestResult[]>([]);
  const [executions, setExecutions] = useState<TestExecution[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedResult, setSelectedResult] = useState<TestResult | null>(null);

  useEffect(() => {
    if (executionId) {
      fetchTestResults(executionId);
    } else if (showRecentResults) {
      fetchRecentExecutions();
    }
  }, [executionId, showRecentResults]);

  const fetchTestResults = async (execId: number) => {
    try {
      setLoading(true);
      const testResults = await qaTestingService.getTestResults(execId);
      setResults(testResults);
    } catch (error) {
      console.error('Error fetching test results:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentExecutions = async () => {
    try {
      setLoading(true);
      const recentExecutions = await qaTestingService.getRecentExecutions(10);
      setExecutions(recentExecutions);
    } catch (error) {
      console.error('Error fetching recent executions:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'skipped':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      default:
        return <Clock className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'skipped':
        return 'bg-yellow-100 text-yellow-800';
      case 'running':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatExecutionTime = (time: number) => {
    if (time < 1000) return `${time}ms`;
    return `${(time / 1000).toFixed(2)}s`;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Test Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            Loading results...
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5" />
          {executionId ? 'Test Results' : 'Recent Test Executions'}
        </CardTitle>
        <CardDescription>
          {executionId ?
          `Results for execution ID: ${executionId}` :
          'Overview of recent test executions'
          }
        </CardDescription>
      </CardHeader>
      <CardContent>
        {executionId ?
        // Show detailed test results for a specific execution
        <>
            {results.length === 0 ?
          <div className="text-center py-8 text-gray-500">
                No test results found for this execution
              </div> :

          <div className="space-y-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Status</TableHead>
                      <TableHead>Test Case</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Result</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {results.map((result) =>
                <TableRow key={result.id}>
                        <TableCell>
                          <Badge className={getStatusColor(result.status)}>
                            {getStatusIcon(result.status)}
                            <span className="ml-1 capitalize">{result.status}</span>
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">Test Case #{result.test_case_id}</div>
                            <div className="text-sm text-gray-500">
                              {new Date(result.started_at).toLocaleString()}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{formatExecutionTime(result.execution_time)}</TableCell>
                        <TableCell>
                          <div className="max-w-xs truncate" title={result.actual_result}>
                            {result.actual_result}
                          </div>
                          {result.error_message &&
                    <div className="text-sm text-red-600 max-w-xs truncate" title={result.error_message}>
                              {result.error_message}
                            </div>
                    }
                        </TableCell>
                        <TableCell>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Test Result Details</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <strong>Status:</strong>
                                  <Badge className={`ml-2 ${getStatusColor(result.status)}`}>
                                    {result.status}
                                  </Badge>
                                </div>
                                <div>
                                  <strong>Execution Time:</strong> {formatExecutionTime(result.execution_time)}
                                </div>
                                <div>
                                  <strong>Started:</strong> {new Date(result.started_at).toLocaleString()}
                                </div>
                                <div>
                                  <strong>Completed:</strong> {new Date(result.completed_at).toLocaleString()}
                                </div>
                                <div>
                                  <strong>Actual Result:</strong>
                                  <pre className="mt-2 p-3 bg-gray-100 rounded text-sm overflow-x-auto">
                                    {result.actual_result}
                                  </pre>
                                </div>
                                {result.error_message &&
                          <div>
                                    <strong>Error Message:</strong>
                                    <pre className="mt-2 p-3 bg-red-50 rounded text-sm text-red-700 overflow-x-auto">
                                      {result.error_message}
                                    </pre>
                                  </div>
                          }
                                {result.details &&
                          <div>
                                    <strong>Details:</strong>
                                    <pre className="mt-2 p-3 bg-gray-100 rounded text-sm overflow-x-auto">
                                      {JSON.stringify(JSON.parse(result.details), null, 2)}
                                    </pre>
                                  </div>
                          }
                              </div>
                            </DialogContent>
                          </Dialog>
                        </TableCell>
                      </TableRow>
                )}
                  </TableBody>
                </Table>
              </div>
          }
          </> :

        // Show recent executions overview
        <>
            {executions.length === 0 ?
          <div className="text-center py-8 text-gray-500">
                No recent test executions found
              </div> :

          <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead>Execution Name</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Results</TableHead>
                    <TableHead>Started</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {executions.map((execution) =>
              <TableRow key={execution.id}>
                      <TableCell>
                        <Badge className={getStatusColor(execution.status)}>
                          <span className="capitalize">{execution.status}</span>
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{execution.execution_name}</div>
                      </TableCell>
                      <TableCell>{execution.progress_percentage}%</TableCell>
                      <TableCell>
                        <div className="text-sm space-y-1">
                          <div className="text-green-600">✓ {execution.passed_tests} passed</div>
                          <div className="text-red-600">✗ {execution.failed_tests} failed</div>
                          <div className="text-yellow-600">⊝ {execution.skipped_tests} skipped</div>
                        </div>
                      </TableCell>
                      <TableCell>{new Date(execution.started_at).toLocaleString()}</TableCell>
                      <TableCell>
                        <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchTestResults(execution.id)}>

                          View Results
                        </Button>
                      </TableCell>
                    </TableRow>
              )}
                </TableBody>
              </Table>
          }
          </>
        }
      </CardContent>
    </Card>);

};

export default TestResultsDisplay;