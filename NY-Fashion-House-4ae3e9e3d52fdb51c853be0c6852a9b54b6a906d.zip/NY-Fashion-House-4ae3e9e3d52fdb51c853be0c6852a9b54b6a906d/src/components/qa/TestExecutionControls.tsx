
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Square, RotateCcw, Plus } from 'lucide-react';
import { qaTestingService, TestSuite } from '@/services/qaTestingService';
import { testRegistryService } from '@/services/testRegistryService';
import { useToast } from '@/hooks/use-toast';

interface TestExecutionControlsProps {
  onExecutionStart?: (executionId: number) => void;
  onExecutionStop?: () => void;
}

const TestExecutionControls: React.FC<TestExecutionControlsProps> = ({
  onExecutionStart,
  onExecutionStop
}) => {
  const [testSuites, setTestSuites] = useState<TestSuite[]>([]);
  const [selectedSuite, setSelectedSuite] = useState<string>('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadTestSuites();
  }, []);

  const loadTestSuites = async () => {
    try {
      setLoading(true);
      const suites = await qaTestingService.getTestSuites();
      setTestSuites(suites);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load test suites',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStartExecution = async () => {
    if (!selectedSuite) {
      toast({
        title: 'Error',
        description: 'Please select a test suite',
        variant: 'destructive'
      });
      return;
    }

    try {
      setIsExecuting(true);
      const executionName = `Execution_${Date.now()}`;
      const response = await qaTestingService.startTestExecution(
        parseInt(selectedSuite),
        executionName
      );

      if (response.error) {
        throw new Error(response.error);
      }

      toast({
        title: 'Execution Started',
        description: `Test execution "${executionName}" has been started`
      });

      if (onExecutionStart) {
        onExecutionStart(response.data || 1);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to start test execution',
        variant: 'destructive'
      });
      setIsExecuting(false);
    }
  };

  const handleStopExecution = () => {
    setIsExecuting(false);
    if (onExecutionStop) {
      onExecutionStop();
    }
    toast({
      title: 'Execution Stopped',
      description: 'Test execution has been stopped'
    });
  };

  const createQuickSuite = async (templateName: string) => {
    try {
      await testRegistryService.createSuiteFromTemplate(templateName);
      await loadTestSuites();
      toast({
        title: 'Suite Created',
        description: `${templateName} suite has been created`
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create test suite',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Test Execution Controls</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-4">
            Loading test suites...
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Play className="w-5 h-5" />
          Test Execution Controls
        </CardTitle>
        <CardDescription>
          Select a test suite and start execution
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-4">
          <div className="flex-1">
            <Select value={selectedSuite} onValueChange={setSelectedSuite}>
              <SelectTrigger>
                <SelectValue placeholder="Select a test suite" />
              </SelectTrigger>
              <SelectContent>
                {testSuites.map((suite) =>
                <SelectItem key={suite.id} value={suite.id.toString()}>
                    <div className="flex items-center gap-2">
                      <span>{suite.name}</span>
                      <Badge variant="outline" className="ml-2">
                        {suite.test_type}
                      </Badge>
                    </div>
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            {!isExecuting ?
            <Button
              onClick={handleStartExecution}
              disabled={!selectedSuite}
              className="flex items-center gap-2">

                <Play className="w-4 h-4" />
                Start
              </Button> :

            <Button
              onClick={handleStopExecution}
              variant="destructive"
              className="flex items-center gap-2">

                <Square className="w-4 h-4" />
                Stop
              </Button>
            }
            <Button
              onClick={loadTestSuites}
              variant="outline"
              className="flex items-center gap-2">

              <RotateCcw className="w-4 h-4" />
              Refresh
            </Button>
          </div>
        </div>

        {testSuites.length === 0 &&
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            <h3 className="text-lg font-semibold mb-2">No Test Suites Found</h3>
            <p className="text-gray-600 mb-4">
              Create your first test suite to get started with QA testing
            </p>
            <div className="flex justify-center gap-2">
              <Button
              onClick={() => createQuickSuite('Frontend Unit Tests')}
              variant="outline"
              size="sm"
              className="flex items-center gap-2">

                <Plus className="w-4 h-4" />
                Unit Tests
              </Button>
              <Button
              onClick={() => createQuickSuite('API Integration Tests')}
              variant="outline"
              size="sm"
              className="flex items-center gap-2">

                <Plus className="w-4 h-4" />
                Integration Tests
              </Button>
              <Button
              onClick={() => createQuickSuite('Performance Tests')}
              variant="outline"
              size="sm"
              className="flex items-center gap-2">

                <Plus className="w-4 h-4" />
                Performance Tests
              </Button>
            </div>
          </div>
        }
      </CardContent>
    </Card>);

};

export default TestExecutionControls;