
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, CheckCircle, Clock, User, Filter, Plus } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface QAIssue {
  id: number;
  report_id: number;
  issue_title: string;
  issue_description: string;
  priority: string;
  category: string;
  severity: string;
  component: string;
  test_case_id: number;
  recommended_fix: string;
  status: string;
  assigned_to: string;
  resolution_notes: string;
}

interface IssueClassificationSystemProps {
  issues: QAIssue[];
  onIssuesUpdate: () => void;
}

const IssueClassificationSystem: React.FC<IssueClassificationSystemProps> = ({
  issues,
  onIssuesUpdate
}) => {
  const [selectedIssue, setSelectedIssue] = useState<QAIssue | null>(null);
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [showCreateIssue, setShowCreateIssue] = useState(false);
  const [newIssue, setNewIssue] = useState({
    issue_title: '',
    issue_description: '',
    priority: 'Medium',
    category: 'Functional',
    severity: 'Medium',
    component: '',
    recommended_fix: ''
  });

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical':return 'destructive';
      case 'High':return 'destructive';
      case 'Medium':return 'default';
      case 'Low':return 'secondary';
      default:return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Open':return 'destructive';
      case 'In Progress':return 'default';
      case 'Resolved':return 'secondary';
      case 'Closed':return 'secondary';
      default:return 'default';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Open':return <AlertCircle className="h-4 w-4" />;
      case 'In Progress':return <Clock className="h-4 w-4" />;
      case 'Resolved':return <CheckCircle className="h-4 w-4" />;
      case 'Closed':return <CheckCircle className="h-4 w-4" />;
      default:return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getRecommendedFix = (issue: QAIssue): string => {
    const fixes: Record<string, Record<string, string>> = {
      Functional: {
        Critical: 'Immediate code review and hotfix deployment required. Rollback if necessary.',
        High: 'Priority fix in next sprint. Add automated test coverage.',
        Medium: 'Include in current sprint planning. Document root cause.',
        Low: 'Add to backlog. Consider during next major release.'
      },
      Performance: {
        Critical: 'Optimize immediately. Consider caching, database indexing, or infrastructure scaling.',
        High: 'Profile and optimize within 1-2 sprints. Monitor performance metrics.',
        Medium: 'Performance tuning in next release. Set up monitoring alerts.',
        Low: 'Minor optimization opportunity. Consider during refactoring.'
      },
      Accessibility: {
        Critical: 'Fix immediately for WCAG compliance. Legal compliance risk.',
        High: 'Priority accessibility fix. Update style guide and components.',
        Medium: 'Improve accessibility in next sprint. Add accessibility testing.',
        Low: 'Minor accessibility enhancement. Include in design system updates.'
      },
      Security: {
        Critical: 'URGENT: Security vulnerability. Patch immediately and review similar code.',
        High: 'Security risk identified. Fix in current sprint and conduct security audit.',
        Medium: 'Security improvement needed. Update security policies and training.',
        Low: 'Minor security enhancement. Include in security review cycle.'
      }
    };

    return fixes[issue.category]?.[issue.priority] ||
    issue.recommended_fix ||
    'Review issue details and determine appropriate fix strategy.';
  };

  const filteredIssues = issues.filter((issue) => {
    const priorityMatch = filterPriority === 'all' || issue.priority === filterPriority;
    const statusMatch = filterStatus === 'all' || issue.status === filterStatus;
    const categoryMatch = filterCategory === 'all' || issue.category === filterCategory;
    return priorityMatch && statusMatch && categoryMatch;
  });

  const groupedIssues = {
    Critical: filteredIssues.filter((issue) => issue.priority === 'Critical'),
    High: filteredIssues.filter((issue) => issue.priority === 'High'),
    Medium: filteredIssues.filter((issue) => issue.priority === 'Medium'),
    Low: filteredIssues.filter((issue) => issue.priority === 'Low')
  };

  const updateIssueStatus = async (issueId: number, newStatus: string) => {
    try {
      const issue = issues.find((i) => i.id === issueId);
      if (!issue) return;

      const { error } = await window.ezsite.apis.tableUpdate(38560, {
        ID: issueId,
        status: newStatus,
        resolution_notes: newStatus === 'Resolved' ? 'Issue resolved via QA dashboard' : issue.resolution_notes
      });

      if (error) throw error;

      toast({
        title: "Issue Updated",
        description: `Issue status changed to ${newStatus}`
      });

      onIssuesUpdate();
    } catch (error) {
      console.error('Error updating issue:', error);
      toast({
        title: "Error",
        description: "Failed to update issue status",
        variant: "destructive"
      });
    }
  };

  const createNewIssue = async () => {
    try {
      const issueData = {
        report_id: 0, // Will be linked to current report
        issue_title: newIssue.issue_title,
        issue_description: newIssue.issue_description,
        priority: newIssue.priority,
        category: newIssue.category,
        severity: newIssue.severity,
        component: newIssue.component,
        test_case_id: 0,
        recommended_fix: newIssue.recommended_fix || getRecommendedFix(newIssue as any),
        status: 'Open',
        assigned_to: '',
        resolution_notes: ''
      };

      const { error } = await window.ezsite.apis.tableCreate(38560, issueData);
      if (error) throw error;

      toast({
        title: "Issue Created",
        description: "New QA issue has been created successfully"
      });

      setShowCreateIssue(false);
      setNewIssue({
        issue_title: '',
        issue_description: '',
        priority: 'Medium',
        category: 'Functional',
        severity: 'Medium',
        component: '',
        recommended_fix: ''
      });

      onIssuesUpdate();
    } catch (error) {
      console.error('Error creating issue:', error);
      toast({
        title: "Error",
        description: "Failed to create new issue",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Issue Classification System</CardTitle>
              <CardDescription>
                Manage and prioritize QA issues with automated workflow recommendations
              </CardDescription>
            </div>
            <Dialog open={showCreateIssue} onOpenChange={setShowCreateIssue}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Issue
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New QA Issue</DialogTitle>
                  <DialogDescription>
                    Add a new issue to the QA tracking system
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Issue Title</label>
                    <Input
                      value={newIssue.issue_title}
                      onChange={(e) => setNewIssue({ ...newIssue, issue_title: e.target.value })}
                      placeholder="Brief description of the issue" />

                  </div>
                  <div>
                    <label className="text-sm font-medium">Description</label>
                    <Textarea
                      value={newIssue.issue_description}
                      onChange={(e) => setNewIssue({ ...newIssue, issue_description: e.target.value })}
                      placeholder="Detailed description of the issue"
                      rows={3} />

                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="text-sm font-medium">Priority</label>
                      <Select
                        value={newIssue.priority}
                        onValueChange={(value) => setNewIssue({ ...newIssue, priority: value })}>

                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Critical">Critical</SelectItem>
                          <SelectItem value="High">High</SelectItem>
                          <SelectItem value="Medium">Medium</SelectItem>
                          <SelectItem value="Low">Low</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Category</label>
                      <Select
                        value={newIssue.category}
                        onValueChange={(value) => setNewIssue({ ...newIssue, category: value })}>

                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Functional">Functional</SelectItem>
                          <SelectItem value="Performance">Performance</SelectItem>
                          <SelectItem value="Accessibility">Accessibility</SelectItem>
                          <SelectItem value="Security">Security</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Severity</label>
                      <Select
                        value={newIssue.severity}
                        onValueChange={(value) => setNewIssue({ ...newIssue, severity: value })}>

                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="High">High</SelectItem>
                          <SelectItem value="Medium">Medium</SelectItem>
                          <SelectItem value="Low">Low</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Component</label>
                    <Input
                      value={newIssue.component}
                      onChange={(e) => setNewIssue({ ...newIssue, component: e.target.value })}
                      placeholder="Affected component or module" />

                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setShowCreateIssue(false)}>
                      Cancel
                    </Button>
                    <Button onClick={createNewIssue} disabled={!newIssue.issue_title}>
                      Create Issue
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <span className="text-sm font-medium">Filters:</span>
            </div>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="Open">Open</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Resolved">Resolved</SelectItem>
                <SelectItem value="Closed">Closed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="Functional">Functional</SelectItem>
                <SelectItem value="Performance">Performance</SelectItem>
                <SelectItem value="Accessibility">Accessibility</SelectItem>
                <SelectItem value="Security">Security</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Tabs defaultValue="priority" className="space-y-4">
            <TabsList>
              <TabsTrigger value="priority">By Priority</TabsTrigger>
              <TabsTrigger value="status">By Status</TabsTrigger>
              <TabsTrigger value="category">By Category</TabsTrigger>
            </TabsList>

            <TabsContent value="priority" className="space-y-4">
              {Object.entries(groupedIssues).map(([priority, priorityIssues]) =>
              priorityIssues.length > 0 &&
              <Card key={priority}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Badge variant={getPriorityColor(priority)}>{priority}</Badge>
                        <span className="text-sm font-normal">
                          ({priorityIssues.length} issues)
                        </span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {priorityIssues.map((issue) =>
                    <div
                      key={issue.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 cursor-pointer"
                      onClick={() => setSelectedIssue(issue)}>

                            <div className="space-y-1">
                              <h4 className="font-medium">{issue.issue_title}</h4>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span>{issue.category}</span>
                                <span>{issue.component}</span>
                                <div className="flex items-center gap-1">
                                  {getStatusIcon(issue.status)}
                                  {issue.status}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Select
                          value={issue.status}
                          onValueChange={(value) => updateIssueStatus(issue.id, value)}>

                                <SelectTrigger className="w-32">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Open">Open</SelectItem>
                                  <SelectItem value="In Progress">In Progress</SelectItem>
                                  <SelectItem value="Resolved">Resolved</SelectItem>
                                  <SelectItem value="Closed">Closed</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                    )}
                      </div>
                    </CardContent>
                  </Card>

              )}
            </TabsContent>

            <TabsContent value="status">
              <div className="text-center py-8 text-muted-foreground">
                Status-based view will be implemented here
              </div>
            </TabsContent>

            <TabsContent value="category">
              <div className="text-center py-8 text-muted-foreground">
                Category-based view will be implemented here
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {selectedIssue &&
      <Dialog open={!!selectedIssue} onOpenChange={() => setSelectedIssue(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {selectedIssue.issue_title}
                <Badge variant={getPriorityColor(selectedIssue.priority)}>
                  {selectedIssue.priority}
                </Badge>
              </DialogTitle>
              <DialogDescription>
                Issue ID: {selectedIssue.id} • Category: {selectedIssue.category}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Description</h4>
                <p className="text-sm text-muted-foreground">{selectedIssue.issue_description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium mb-2">Issue Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Priority:</span>
                      <Badge variant={getPriorityColor(selectedIssue.priority)}>
                        {selectedIssue.priority}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Status:</span>
                      <Badge variant={getStatusColor(selectedIssue.status)}>
                        {selectedIssue.status}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span>Category:</span>
                      <span>{selectedIssue.category}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Severity:</span>
                      <span>{selectedIssue.severity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Component:</span>
                      <span>{selectedIssue.component}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Assignment</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Assigned to:</span>
                      <span>{selectedIssue.assigned_to || 'Unassigned'}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Recommended Fix</h4>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm">{getRecommendedFix(selectedIssue)}</p>
                </div>
              </div>

              {selectedIssue.resolution_notes &&
            <div>
                  <h4 className="font-medium mb-2">Resolution Notes</h4>
                  <p className="text-sm text-muted-foreground">{selectedIssue.resolution_notes}</p>
                </div>
            }
            </div>
          </DialogContent>
        </Dialog>
      }
    </div>);

};

export default IssueClassificationSystem;