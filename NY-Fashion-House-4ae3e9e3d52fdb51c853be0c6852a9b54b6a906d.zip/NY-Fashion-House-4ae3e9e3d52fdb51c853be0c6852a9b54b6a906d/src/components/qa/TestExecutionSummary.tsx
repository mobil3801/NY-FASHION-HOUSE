
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Calendar, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react';

interface QAReport {
  id: number;
  report_name: string;
  report_type: string;
  execution_date: string;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  pass_rate: number;
  status: string;
  created_by: string;
}

interface TestExecutionSummaryProps {
  reports: QAReport[];
}

const TestExecutionSummary: React.FC<TestExecutionSummaryProps> = ({ reports }) => {
  const getRecentReports = () => {
    return reports.
    sort((a, b) => new Date(b.execution_date).getTime() - new Date(a.execution_date).getTime()).
    slice(0, 5);
  };

  const getTestTypeStats = () => {
    const typeStats = reports.reduce((acc, report) => {
      if (!acc[report.report_type]) {
        acc[report.report_type] = {
          total: 0,
          passed: 0,
          failed: 0,
          count: 0
        };
      }
      acc[report.report_type].total += report.total_tests;
      acc[report.report_type].passed += report.passed_tests;
      acc[report.report_type].failed += report.failed_tests;
      acc[report.report_type].count += 1;
      return acc;
    }, {} as Record<string, any>);

    return Object.entries(typeStats).map(([type, stats]) => ({
      type,
      ...stats,
      passRate: stats.total > 0 ? stats.passed / stats.total * 100 : 0
    }));
  };

  const getTotalStats = () => {
    return reports.reduce(
      (acc, report) => {
        acc.totalTests += report.total_tests;
        acc.totalPassed += report.passed_tests;
        acc.totalFailed += report.failed_tests;
        return acc;
      },
      { totalTests: 0, totalPassed: 0, totalFailed: 0 }
    );
  };

  const stats = getTotalStats();
  const overallPassRate = stats.totalTests > 0 ? stats.totalPassed / stats.totalTests * 100 : 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Test Execution Summary
          </CardTitle>
          <CardDescription>
            Overall test execution statistics and recent results
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-muted-foreground">Total Tests Executed</h4>
              <p className="text-2xl font-bold">{stats.totalTests.toLocaleString()}</p>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-muted-foreground">Overall Pass Rate</h4>
              <p className="text-2xl font-bold text-green-600">{overallPassRate.toFixed(1)}%</p>
              <Progress value={overallPassRate} className="h-2" />
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-muted-foreground">Test Reports</h4>
              <p className="text-2xl font-bold">{reports.length}</p>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="font-medium text-green-800">Passed Tests</span>
              </div>
              <span className="text-2xl font-bold text-green-600">{stats.totalPassed.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                <span className="font-medium text-red-800">Failed Tests</span>
              </div>
              <span className="text-2xl font-bold text-red-600">{stats.totalFailed.toLocaleString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Test Type Breakdown</CardTitle>
            <CardDescription>Performance by test category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {getTestTypeStats().map((stat) =>
              <div key={stat.type} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{stat.type}</span>
                    <Badge variant="outline">{stat.count} reports</Badge>
                  </div>
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>{stat.total} tests</span>
                    <span>{stat.passRate.toFixed(1)}% pass rate</span>
                  </div>
                  <Progress value={stat.passRate} className="h-2" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Test Reports</CardTitle>
            <CardDescription>Latest test execution results</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {getRecentReports().map((report) =>
              <div key={report.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="space-y-1">
                    <p className="font-medium text-sm">{report.report_name}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {new Date(report.execution_date).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="text-right space-y-1">
                    <Badge
                    variant={report.status === 'Completed' ? 'default' : 'secondary'}
                    className="text-xs">

                      {report.status}
                    </Badge>
                    <p className="text-xs font-medium">
                      {report.pass_rate.toFixed(1)}% pass rate
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

};

export default TestExecutionSummary;