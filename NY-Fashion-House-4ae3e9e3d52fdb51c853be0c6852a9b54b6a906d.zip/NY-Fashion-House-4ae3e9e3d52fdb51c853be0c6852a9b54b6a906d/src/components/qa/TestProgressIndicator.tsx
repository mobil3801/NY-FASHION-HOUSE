
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Clock, AlertTriangle, RefreshCw } from 'lucide-react';
import { qaTestingService, TestExecution } from '@/services/qaTestingService';

interface TestProgressIndicatorProps {
  executionId?: number;
  isActive?: boolean;
}

const TestProgressIndicator: React.FC<TestProgressIndicatorProps> = ({
  executionId,
  isActive = false
}) => {
  const [execution, setExecution] = useState<TestExecution | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (executionId && isActive) {
      const interval = setInterval(() => {
        fetchExecutionStatus();
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [executionId, isActive]);

  const fetchExecutionStatus = async () => {
    if (!executionId) return;

    try {
      const executions = await qaTestingService.getRecentExecutions(100);
      const currentExecution = executions.find((e) => e.id === executionId);
      if (currentExecution) {
        setExecution(currentExecution);
      }
    } catch (error) {
      console.error('Error fetching execution status:', error);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return <Clock className="w-4 h-4 animate-spin" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'cancelled':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'cancelled':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (!execution && !isActive) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5" />
            Test Progress
          </CardTitle>
          <CardDescription>
            No active test execution
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            Start a test execution to see progress here
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <RefreshCw className="w-5 h-5" />
          Test Progress
          {execution &&
          <Badge className={getStatusColor(execution.status)}>
              {getStatusIcon(execution.status)}
              <span className="ml-1 capitalize">{execution.status}</span>
            </Badge>
          }
        </CardTitle>
        <CardDescription>
          {execution ? execution.execution_name : 'Real-time execution progress'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {execution ?
        <>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Overall Progress</span>
                <span>{execution.progress_percentage}%</span>
              </div>
              <Progress value={execution.progress_percentage} className="h-2" />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-gray-700">{execution.total_tests}</div>
                <div className="text-xs text-gray-500">Total Tests</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{execution.passed_tests}</div>
                <div className="text-xs text-green-600">Passed</div>
              </div>
              <div className="text-center p-3 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600">{execution.failed_tests}</div>
                <div className="text-xs text-red-600">Failed</div>
              </div>
              <div className="text-center p-3 bg-yellow-50 rounded-lg">
                <div className="text-2xl font-bold text-yellow-600">{execution.skipped_tests}</div>
                <div className="text-xs text-yellow-600">Skipped</div>
              </div>
            </div>

            {execution.status === 'running' &&
          <div className="flex items-center justify-center text-sm text-blue-600">
                <Clock className="w-4 h-4 animate-spin mr-2" />
                Execution in progress...
              </div>
          }

            {execution.status === 'completed' &&
          <div className="text-center p-4 bg-green-50 rounded-lg">
                <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <div className="text-green-800 font-semibold">Execution Completed</div>
                <div className="text-sm text-green-600">
                  {execution.passed_tests} of {execution.total_tests} tests passed
                </div>
              </div>
          }

            <div className="text-xs text-gray-500 space-y-1">
              <div>Started: {new Date(execution.started_at).toLocaleString()}</div>
              {execution.completed_at &&
            <div>Completed: {new Date(execution.completed_at).toLocaleString()}</div>
            }
            </div>
          </> :

        <div className="text-center py-4">
            <RefreshCw className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-2" />
            <div>Loading execution data...</div>
          </div>
        }
      </CardContent>
    </Card>);

};

export default TestProgressIndicator;