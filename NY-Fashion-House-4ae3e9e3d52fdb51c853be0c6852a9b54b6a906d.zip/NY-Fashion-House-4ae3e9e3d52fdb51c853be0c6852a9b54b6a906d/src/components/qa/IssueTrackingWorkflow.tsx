
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Workflow,
  Clock,
  Users,
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Target,
  Zap,
  GitBranch } from
'lucide-react';
import { issueTrackingWorkflowService } from '@/services/issueTrackingWorkflowService';
import { toast } from '@/hooks/use-toast';

interface QAIssue {
  id: number;
  report_id: number;
  issue_title: string;
  issue_description: string;
  priority: string;
  category: string;
  severity: string;
  component: string;
  status: string;
  recommended_fix: string;
  assigned_to: string;
}

interface IssueTrackingWorkflowProps {
  issues: QAIssue[];
  onWorkflowUpdate?: () => void;
}

const IssueTrackingWorkflow: React.FC<IssueTrackingWorkflowProps> = ({
  issues,
  onWorkflowUpdate
}) => {
  const [workflowRecommendations, setWorkflowRecommendations] = useState<any[]>([]);
  const [selectedIssue, setSelectedIssue] = useState<QAIssue | null>(null);
  const [resolutionPlan, setResolutionPlan] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    generateWorkflowRecommendations();
  }, [issues]);

  const generateWorkflowRecommendations = async () => {
    setLoading(true);
    try {
      const recommendations = issueTrackingWorkflowService.generateWorkflowRecommendations(issues);
      const processedWorkflows = await issueTrackingWorkflowService.processIssueWorkflows(issues);

      setWorkflowRecommendations(processedWorkflows);
    } catch (error) {
      console.error('Error generating workflow recommendations:', error);
      toast({
        title: "Error",
        description: "Failed to generate workflow recommendations",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const generateResolutionPlan = async (issue: QAIssue) => {
    const plan = issueTrackingWorkflowService.generateResolutionPlan(issue);
    setResolutionPlan(plan);
    setSelectedIssue(issue);
  };

  const getRiskLevelColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'Critical':return 'destructive';
      case 'High':return 'destructive';
      case 'Medium':return 'default';
      case 'Low':return 'secondary';
      default:return 'default';
    }
  };

  const getPhaseIcon = (phase: string) => {
    switch (phase) {
      case 'Investigation':return <Target className="h-4 w-4" />;
      case 'Solution Design':return <GitBranch className="h-4 w-4" />;
      case 'Implementation':return <Zap className="h-4 w-4" />;
      case 'Testing':return <CheckCircle className="h-4 w-4" />;
      case 'Deployment':return <ArrowRight className="h-4 w-4" />;
      default:return <Clock className="h-4 w-4" />;
    }
  };

  const getAutomationOpportunities = () => {
    const opportunities = workflowRecommendations.flatMap((rec) =>
    rec.automatedActions.filter((action: any) =>
    ['assign', 'create_ticket', 'notify'].includes(action.type)
    )
    );

    return opportunities.length;
  };

  const getWorkflowEfficiencyScore = () => {
    if (workflowRecommendations.length === 0) return 0;

    const totalRecommendations = workflowRecommendations.reduce(
      (sum, rec) => sum + rec.recommendations.recommendedActions.length, 0
    );
    const automatedActions = workflowRecommendations.reduce(
      (sum, rec) => sum + rec.automatedActions.length, 0
    );

    return totalRecommendations > 0 ? automatedActions / totalRecommendations * 100 : 0;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>);

  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Workflow className="h-5 w-5" />
            Automated Issue Tracking & Workflow Recommendations
          </CardTitle>
          <CardDescription>
            AI-powered workflow automation and resolution recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="text-2xl font-bold text-blue-600">{workflowRecommendations.length}</h3>
              <p className="text-sm text-blue-800">Active Workflows</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <h3 className="text-2xl font-bold text-green-600">{getAutomationOpportunities()}</h3>
              <p className="text-sm text-green-800">Automation Opportunities</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <h3 className="text-2xl font-bold text-purple-600">{getWorkflowEfficiencyScore().toFixed(1)}%</h3>
              <p className="text-sm text-purple-800">Workflow Efficiency</p>
            </div>
          </div>

          <div className="space-y-4">
            {workflowRecommendations.map((workflow, index) =>
            <Card key={index} className="border-l-4 border-l-blue-500">
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between mb-4">
                    <div className="space-y-2">
                      <h4 className="font-medium text-lg">{workflow.issue.issue_title}</h4>
                      <div className="flex items-center gap-2">
                        <Badge variant={getRiskLevelColor(workflow.recommendations.riskLevel)}>
                          {workflow.recommendations.riskLevel} Risk
                        </Badge>
                        <Badge variant="outline">
                          Priority: {workflow.recommendations.priority}
                        </Badge>
                        <Badge variant="secondary">
                          {workflow.recommendations.estimatedEffort}
                        </Badge>
                      </div>
                    </div>
                    <Button
                    variant="outline"
                    size="sm"
                    onClick={() => generateResolutionPlan(workflow.issue)}>

                      <GitBranch className="mr-2 h-4 w-4" />
                      Resolution Plan
                    </Button>
                  </div>

                  <Tabs defaultValue="recommendations" className="w-full">
                    <TabsList>
                      <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
                      <TabsTrigger value="workflows">Workflows</TabsTrigger>
                      <TabsTrigger value="automation">Automation</TabsTrigger>
                    </TabsList>

                    <TabsContent value="recommendations" className="space-y-3">
                      <div>
                        <h5 className="font-medium mb-2">Recommended Actions</h5>
                        <ul className="space-y-1">
                          {workflow.recommendations.recommendedActions.slice(0, 3).map((action: string, actionIndex: number) =>
                        <li key={actionIndex} className="flex items-center gap-2 text-sm">
                              <ArrowRight className="h-3 w-3 text-blue-500" />
                              {action}
                            </li>
                        )}
                        </ul>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <div>
                          <h5 className="font-medium mb-2">Required Skills</h5>
                          <div className="flex flex-wrap gap-1">
                            {workflow.recommendations.requiredSkills.map((skill: string, skillIndex: number) =>
                          <Badge key={skillIndex} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                          )}
                          </div>
                        </div>
                        <div>
                          <h5 className="font-medium mb-2">Dependencies</h5>
                          <div className="flex flex-wrap gap-1">
                            {workflow.recommendations.dependencies.map((dep: string, depIndex: number) =>
                          <Badge key={depIndex} variant="secondary" className="text-xs">
                                {dep}
                              </Badge>
                          )}
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="workflows" className="space-y-3">
                      {workflow.workflows.map((wf: any, wfIndex: number) =>
                    <div key={wfIndex} className="p-3 bg-gray-50 rounded-lg">
                          <h5 className="font-medium">{wf.workflowType}</h5>
                          <div className="mt-2 space-y-1">
                            {wf.actions.map((action: any, actionIndex: number) =>
                        <div key={actionIndex} className="flex items-center gap-2 text-sm">
                                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                <span className="capitalize">{action.actionType.replace('_', ' ')}</span>
                                {action.parameters.assignee &&
                          <Badge variant="outline" className="text-xs">
                                    {action.parameters.assignee}
                                  </Badge>
                          }
                              </div>
                        )}
                          </div>
                        </div>
                    )}
                    </TabsContent>

                    <TabsContent value="automation" className="space-y-3">
                      {workflow.automatedActions.length > 0 ?
                    workflow.automatedActions.map((action: any, actionIndex: number) =>
                    <Alert key={actionIndex}>
                            <Zap className="h-4 w-4" />
                            <AlertDescription>
                              <strong>Automated {action.type}:</strong> {action.workflow}
                              <div className="text-xs text-muted-foreground mt-1">
                                Scheduled: {new Date(action.scheduled).toLocaleString()}
                              </div>
                            </AlertDescription>
                          </Alert>
                    ) :

                    <div className="text-center py-4 text-muted-foreground">
                          No automated actions available for this issue
                        </div>
                    }
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Resolution Plan Dialog */}
      <Dialog open={!!resolutionPlan} onOpenChange={() => {setResolutionPlan(null);setSelectedIssue(null);}}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GitBranch className="h-5 w-5" />
              Resolution Plan: {selectedIssue?.issue_title}
            </DialogTitle>
            <DialogDescription>
              Comprehensive plan for issue resolution with estimated timelines
            </DialogDescription>
          </DialogHeader>
          
          {resolutionPlan &&
          <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="font-semibold text-blue-600">{resolutionPlan.totalEstimatedTime}</div>
                  <div className="text-sm text-blue-800">Total Time</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="font-semibold text-green-600">{resolutionPlan.phases.length}</div>
                  <div className="text-sm text-green-800">Phases</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="font-semibold text-orange-600">{resolutionPlan.requiredResources.length}</div>
                  <div className="text-sm text-orange-800">Resources</div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Resolution Phases</h4>
                <div className="space-y-4">
                  {resolutionPlan.phases.map((phase: any, index: number) =>
                <div key={index} className="flex gap-4 p-4 border rounded-lg">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        {getPhaseIcon(phase.phase)}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="font-medium">{phase.phase}</h5>
                          <Badge variant="outline">{phase.duration}</Badge>
                        </div>
                        <ul className="space-y-1">
                          {phase.activities.map((activity: string, actIndex: number) =>
                      <li key={actIndex} className="text-sm flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div>
                              {activity}
                            </li>
                      )}
                        </ul>
                      </div>
                    </div>
                )}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">Risk Mitigation</h4>
                  <ul className="space-y-2">
                    {resolutionPlan.riskMitigation.map((risk: string, index: number) =>
                  <li key={index} className="flex items-start gap-2 text-sm">
                        <AlertTriangle className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                        {risk}
                      </li>
                  )}
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-3">Success Criteria</h4>
                  <ul className="space-y-2">
                    {resolutionPlan.successCriteria.map((criteria: string, index: number) =>
                  <li key={index} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                        {criteria}
                      </li>
                  )}
                  </ul>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Required Resources</h4>
                <div className="flex flex-wrap gap-2">
                  {resolutionPlan.requiredResources.map((resource: string, index: number) =>
                <Badge key={index} variant="outline" className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {resource}
                    </Badge>
                )}
                </div>
              </div>
            </div>
          }
        </DialogContent>
      </Dialog>
    </div>);

};

export default IssueTrackingWorkflow;