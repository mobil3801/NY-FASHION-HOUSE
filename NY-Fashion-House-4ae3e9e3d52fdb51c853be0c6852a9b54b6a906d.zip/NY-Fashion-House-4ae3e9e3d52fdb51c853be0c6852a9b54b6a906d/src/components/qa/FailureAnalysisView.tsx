
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertCircle, TrendingDown, PieChart, BarChart3, Target } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart as RechartsePieChart, Pie, Cell } from 'recharts';

interface QAReport {
  id: number;
  report_name: string;
  report_type: string;
  execution_date: string;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  pass_rate: number;
  status: string;
}

interface QAIssue {
  id: number;
  report_id: number;
  issue_title: string;
  issue_description: string;
  priority: string;
  category: string;
  severity: string;
  component: string;
  status: string;
}

interface FailureAnalysisViewProps {
  issues: QAIssue[];
  reports: QAReport[];
}

const FailureAnalysisView: React.FC<FailureAnalysisViewProps> = ({ issues, reports }) => {
  const [selectedTimeRange, setSelectedTimeRange] = useState('30');
  const [analysisData, setAnalysisData] = useState<any>({});

  useEffect(() => {
    generateAnalysisData();
  }, [issues, reports, selectedTimeRange]);

  const generateAnalysisData = () => {
    const daysBack = parseInt(selectedTimeRange);
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);

    const recentReports = reports.filter((report) =>
    new Date(report.execution_date) >= cutoffDate
    );

    const recentIssues = issues.filter((issue) => {
      const relatedReport = reports.find((r) => r.id === issue.report_id);
      return relatedReport && new Date(relatedReport.execution_date) >= cutoffDate;
    });

    // Failure trend over time
    const failureTrend = recentReports.
    sort((a, b) => new Date(a.execution_date).getTime() - new Date(b.execution_date).getTime()).
    map((report) => ({
      date: new Date(report.execution_date).toLocaleDateString(),
      failureRate: report.total_tests > 0 ? report.failed_tests / report.total_tests * 100 : 0,
      failedTests: report.failed_tests,
      totalTests: report.total_tests
    }));

    // Top failure categories
    const categoryBreakdown = recentIssues.reduce((acc, issue) => {
      acc[issue.category] = (acc[issue.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topCategories = Object.entries(categoryBreakdown).
    map(([category, count]) => ({ category, count })).
    sort((a, b) => b.count - a.count);

    // Component failure analysis
    const componentBreakdown = recentIssues.reduce((acc, issue) => {
      const component = issue.component || 'Unknown';
      acc[component] = (acc[component] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topFailingComponents = Object.entries(componentBreakdown).
    map(([component, count]) => ({ component, count })).
    sort((a, b) => b.count - a.count).
    slice(0, 10);

    // Priority distribution
    const priorityDistribution = recentIssues.reduce((acc, issue) => {
      acc[issue.priority] = (acc[issue.priority] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const priorityData = Object.entries(priorityDistribution).map(([priority, count]) => ({
      name: priority,
      value: count,
      color: priority === 'Critical' ? '#ef4444' :
      priority === 'High' ? '#f97316' :
      priority === 'Medium' ? '#eab308' : '#22c55e'
    }));

    // Root cause analysis
    const rootCauses = generateRootCauseAnalysis(recentIssues);

    setAnalysisData({
      failureTrend,
      topCategories,
      topFailingComponents,
      priorityData,
      rootCauses,
      totalIssues: recentIssues.length,
      criticalIssues: recentIssues.filter((i) => i.priority === 'Critical').length,
      avgFailureRate: failureTrend.length > 0 ?
      failureTrend.reduce((sum, data) => sum + data.failureRate, 0) / failureTrend.length : 0
    });
  };

  const generateRootCauseAnalysis = (issues: QAIssue[]) => {
    // Simplified root cause categorization based on patterns
    const rootCausePatterns = {
      'Code Quality': issues.filter((i) =>
      i.category === 'Functional' && (
      i.issue_title.toLowerCase().includes('null') ||
      i.issue_title.toLowerCase().includes('undefined') ||
      i.issue_title.toLowerCase().includes('error'))

      ).length,
      'Design Issues': issues.filter((i) =>
      i.category === 'Accessibility' ||
      i.issue_title.toLowerCase().includes('ui') ||
      i.issue_title.toLowerCase().includes('layout')
      ).length,
      'Performance': issues.filter((i) =>
      i.category === 'Performance' ||
      i.issue_title.toLowerCase().includes('slow') ||
      i.issue_title.toLowerCase().includes('timeout')
      ).length,
      'Integration': issues.filter((i) =>
      i.issue_title.toLowerCase().includes('api') ||
      i.issue_title.toLowerCase().includes('service') ||
      i.issue_title.toLowerCase().includes('connection')
      ).length,
      'Security': issues.filter((i) =>
      i.category === 'Security' ||
      i.issue_title.toLowerCase().includes('auth') ||
      i.issue_title.toLowerCase().includes('permission')
      ).length,
      'Environment': issues.filter((i) =>
      i.issue_title.toLowerCase().includes('config') ||
      i.issue_title.toLowerCase().includes('deploy') ||
      i.issue_title.toLowerCase().includes('environment')
      ).length
    };

    return Object.entries(rootCausePatterns).
    map(([cause, count]) => ({ cause, count })).
    sort((a, b) => b.count - a.count).
    filter((item) => item.count > 0);
  };

  const getImpactRecommendations = () => {
    const { criticalIssues, totalIssues, avgFailureRate } = analysisData;
    const recommendations = [];

    if (criticalIssues > 0) {
      recommendations.push({
        type: 'Critical',
        message: `${criticalIssues} critical issues require immediate attention`,
        action: 'Review and fix critical issues within 24 hours'
      });
    }

    if (avgFailureRate > 20) {
      recommendations.push({
        type: 'High',
        message: `High average failure rate: ${avgFailureRate.toFixed(1)}%`,
        action: 'Investigate top failing components and implement fixes'
      });
    }

    if (totalIssues > 50) {
      recommendations.push({
        type: 'Medium',
        message: `Large number of issues (${totalIssues}) in selected timeframe`,
        action: 'Consider process improvements and preventive measures'
      });
    }

    return recommendations;
  };

  if (!analysisData.failureTrend) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>);

  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5" />
                Failure Analysis & Root Cause Investigation
              </CardTitle>
              <CardDescription>
                Comprehensive analysis of test failures and quality issues
              </CardDescription>
            </div>
            <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <h3 className="text-2xl font-bold text-red-600">{analysisData.totalIssues}</h3>
              <p className="text-sm text-red-800">Total Issues</p>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <h3 className="text-2xl font-bold text-orange-600">{analysisData.criticalIssues}</h3>
              <p className="text-sm text-orange-800">Critical Issues</p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="text-2xl font-bold text-blue-600">{analysisData.avgFailureRate.toFixed(1)}%</h3>
              <p className="text-sm text-blue-800">Avg Failure Rate</p>
            </div>
          </div>

          <Tabs defaultValue="trends" className="space-y-4">
            <TabsList>
              <TabsTrigger value="trends">Trends</TabsTrigger>
              <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
              <TabsTrigger value="components">Components</TabsTrigger>
              <TabsTrigger value="root-causes">Root Causes</TabsTrigger>
              <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
            </TabsList>

            <TabsContent value="trends" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingDown className="h-4 w-4" />
                    Failure Rate Trend
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={analysisData.failureTrend}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip
                        formatter={(value, name) => [
                        name === 'failureRate' ? `${value}%` : value,
                        name === 'failureRate' ? 'Failure Rate' : 'Failed Tests']
                        } />

                      <Line
                        type="monotone"
                        dataKey="failureRate"
                        stroke="#ef4444"
                        strokeWidth={2}
                        name="failureRate" />

                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="breakdown" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Issue Categories</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {analysisData.topCategories.map((item: any, index: number) =>
                      <div key={index} className="flex items-center justify-between">
                          <span className="text-sm">{item.category}</span>
                          <div className="flex items-center gap-2">
                            <div className="w-20 bg-gray-200 rounded-full h-2">
                              <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{
                                width: `${item.count / Math.max(...analysisData.topCategories.map((c: any) => c.count)) * 100}%`
                              }} />

                            </div>
                            <span className="text-sm font-medium">{item.count}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Priority Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={200}>
                      <RechartsePieChart>
                        <Pie
                          data={analysisData.priorityData}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, value }) => `${name}: ${value}`}>

                          {analysisData.priorityData.map((entry: any, index: number) =>
                          <Cell key={`cell-${index}`} fill={entry.color} />
                          )}
                        </Pie>
                        <Tooltip />
                      </RechartsePieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="components" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-4 w-4" />
                    Top Failing Components
                  </CardTitle>
                  <CardDescription>
                    Components with the highest number of issues
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysisData.topFailingComponents.map((component: any, index: number) =>
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <h4 className="font-medium">{component.component}</h4>
                          <p className="text-sm text-muted-foreground">
                            {component.count} issues found
                          </p>
                        </div>
                        <Badge variant="destructive">{component.count}</Badge>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="root-causes" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-4 w-4" />
                    Root Cause Analysis
                  </CardTitle>
                  <CardDescription>
                    Identified patterns and potential root causes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analysisData.rootCauses.map((cause: any, index: number) =>
                    <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{cause.cause}</h4>
                          <Badge variant="outline">{cause.count} issues</Badge>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                          <div
                          className="bg-red-600 h-2 rounded-full"
                          style={{
                            width: `${cause.count / Math.max(...analysisData.rootCauses.map((c: any) => c.count)) * 100}%`
                          }} />

                        </div>
                        <p className="text-sm text-muted-foreground">
                          {getRootCauseRecommendation(cause.cause)}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="recommendations" className="space-y-4">
              <div className="space-y-4">
                {getImpactRecommendations().map((rec, index) =>
                <Card key={index}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>{rec.type} Priority</span>
                        <Badge variant={rec.type === 'Critical' ? 'destructive' : rec.type === 'High' ? 'default' : 'secondary'}>
                          {rec.type}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm mb-3">{rec.message}</p>
                      <div className="p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm font-medium text-blue-800">Recommended Action:</p>
                        <p className="text-sm text-blue-700">{rec.action}</p>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Card>
                  <CardHeader>
                    <CardTitle>Process Improvement Suggestions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm">
                      <li>• Implement automated testing for top failing components</li>
                      <li>• Add pre-commit hooks to catch common issues early</li>
                      <li>• Increase code review coverage for critical components</li>
                      <li>• Consider pair programming for complex features</li>
                      <li>• Implement better error handling and logging</li>
                      <li>• Add performance monitoring to catch issues early</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>);

};

const getRootCauseRecommendation = (cause: string): string => {
  const recommendations: Record<string, string> = {
    'Code Quality': 'Implement stricter code reviews, add static analysis tools, and improve unit test coverage.',
    'Design Issues': 'Establish design system guidelines, conduct UI/UX reviews, and implement accessibility testing.',
    'Performance': 'Add performance monitoring, implement caching strategies, and optimize database queries.',
    'Integration': 'Implement API contract testing, add service health checks, and improve error handling.',
    'Security': 'Conduct security audits, implement security scanning, and provide security training.',
    'Environment': 'Standardize deployment processes, implement infrastructure as code, and improve configuration management.'
  };

  return recommendations[cause] || 'Investigate further to identify specific improvement opportunities.';
};

export default FailureAnalysisView;