
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Download, FileText, Table, Code, Calendar } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface QAReport {
  id: number;
  report_name: string;
  report_type: string;
  execution_date: string;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  pass_rate: number;
  status: string;
  created_by: string;
}

interface QAIssue {
  id: number;
  report_id: number;
  issue_title: string;
  issue_description: string;
  priority: string;
  category: string;
  severity: string;
  component: string;
  status: string;
  recommended_fix: string;
  assigned_to: string;
  resolution_notes: string;
}

interface ReportExportManagerProps {
  reports: QAReport[];
  issues: QAIssue[];
}

const ReportExportManager: React.FC<ReportExportManagerProps> = ({ reports, issues }) => {
  const [exportFormat, setExportFormat] = useState('pdf');
  const [exportScope, setExportScope] = useState('all');
  const [includeIssues, setIncludeIssues] = useState(true);
  const [includeCharts, setIncludeCharts] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);

  const handleExport = async () => {
    setIsExporting(true);

    try {
      const exportData = prepareExportData();

      switch (exportFormat) {
        case 'pdf':
          await exportToPDF(exportData);
          break;
        case 'csv':
          await exportToCSV(exportData);
          break;
        case 'json':
          await exportToJSON(exportData);
          break;
        default:
          throw new Error('Unsupported export format');
      }

      toast({
        title: "Export Completed",
        description: `QA report exported successfully as ${exportFormat.toUpperCase()}`
      });

      setShowExportDialog(false);
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: "Export Failed",
        description: "Failed to export QA report. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const prepareExportData = () => {
    let exportReports = reports;

    if (exportScope === 'recent') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      exportReports = reports.filter((report) =>
      new Date(report.execution_date) >= thirtyDaysAgo
      );
    }

    const relatedIssues = includeIssues ?
    issues.filter((issue) =>
    exportReports.some((report) => report.id === issue.report_id)
    ) : [];

    return {
      reports: exportReports,
      issues: relatedIssues,
      summary: generateSummaryStats(exportReports, relatedIssues),
      metadata: {
        exportDate: new Date().toISOString(),
        exportFormat,
        exportScope,
        includeIssues,
        includeCharts
      }
    };
  };

  const generateSummaryStats = (reports: QAReport[], issues: QAIssue[]) => {
    const totalTests = reports.reduce((sum, report) => sum + report.total_tests, 0);
    const totalPassed = reports.reduce((sum, report) => sum + report.passed_tests, 0);
    const totalFailed = reports.reduce((sum, report) => sum + report.failed_tests, 0);
    const avgPassRate = reports.length > 0 ?
    reports.reduce((sum, report) => sum + report.pass_rate, 0) / reports.length : 0;

    const issuesByPriority = issues.reduce((acc, issue) => {
      acc[issue.priority] = (acc[issue.priority] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const issuesByCategory = issues.reduce((acc, issue) => {
      acc[issue.category] = (acc[issue.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalReports: reports.length,
      totalTests,
      totalPassed,
      totalFailed,
      avgPassRate,
      totalIssues: issues.length,
      criticalIssues: issues.filter((i) => i.priority === 'Critical').length,
      openIssues: issues.filter((i) => i.status === 'Open').length,
      issuesByPriority,
      issuesByCategory
    };
  };

  const exportToPDF = async (data: any) => {
    // Create a comprehensive PDF report
    const reportContent = generatePDFContent(data);

    // In a real implementation, you would use a library like jsPDF
    // For now, we'll create a downloadable HTML version
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>QA Report - ${new Date().toLocaleDateString()}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
            .section { margin-bottom: 30px; }
            .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
            .stat-card { border: 1px solid #ddd; padding: 15px; border-radius: 5px; text-align: center; }
            .stat-value { font-size: 24px; font-weight: bold; color: #333; }
            .stat-label { font-size: 12px; color: #666; margin-top: 5px; }
            table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f5f5f5; }
            .priority-critical { color: #dc3545; font-weight: bold; }
            .priority-high { color: #fd7e14; font-weight: bold; }
            .priority-medium { color: #ffc107; font-weight: bold; }
            .priority-low { color: #28a745; font-weight: bold; }
          </style>
        </head>
        <body>
          ${reportContent}
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `qa-report-${new Date().toISOString().split('T')[0]}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const generatePDFContent = (data: any) => {
    const { reports, issues, summary, metadata } = data;

    return `
      <div class="header">
        <h1>Quality Assurance Report</h1>
        <p>Generated on ${new Date(metadata.exportDate).toLocaleDateString()}</p>
        <p>Report Period: ${exportScope === 'all' ? 'All Time' : 'Last 30 Days'}</p>
      </div>

      <div class="section">
        <h2>Executive Summary</h2>
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-value">${summary.totalReports}</div>
            <div class="stat-label">Total Reports</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${summary.totalTests.toLocaleString()}</div>
            <div class="stat-label">Total Tests</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${summary.avgPassRate.toFixed(1)}%</div>
            <div class="stat-label">Average Pass Rate</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${summary.totalIssues}</div>
            <div class="stat-label">Total Issues</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${summary.criticalIssues}</div>
            <div class="stat-label">Critical Issues</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">${summary.openIssues}</div>
            <div class="stat-label">Open Issues</div>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>Test Execution Reports</h2>
        <table>
          <thead>
            <tr>
              <th>Report Name</th>
              <th>Type</th>
              <th>Date</th>
              <th>Total Tests</th>
              <th>Passed</th>
              <th>Failed</th>
              <th>Pass Rate</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${reports.map((report: QAReport) => `
              <tr>
                <td>${report.report_name}</td>
                <td>${report.report_type}</td>
                <td>${new Date(report.execution_date).toLocaleDateString()}</td>
                <td>${report.total_tests}</td>
                <td>${report.passed_tests}</td>
                <td>${report.failed_tests}</td>
                <td>${report.pass_rate.toFixed(1)}%</td>
                <td>${report.status}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      ${includeIssues && issues.length > 0 ? `
        <div class="section">
          <h2>Issues Summary</h2>
          <h3>Priority Breakdown</h3>
          <ul>
            ${Object.entries(summary.issuesByPriority).map(([priority, count]: [string, any]) => `
              <li class="priority-${priority.toLowerCase()}">${priority}: ${count} issues</li>
            `).join('')}
          </ul>
          
          <h3>Category Breakdown</h3>
          <ul>
            ${Object.entries(summary.issuesByCategory).map(([category, count]: [string, any]) => `
              <li>${category}: ${count} issues</li>
            `).join('')}
          </ul>

          <h3>Detailed Issues</h3>
          <table>
            <thead>
              <tr>
                <th>Title</th>
                <th>Priority</th>
                <th>Category</th>
                <th>Component</th>
                <th>Status</th>
                <th>Recommended Fix</th>
              </tr>
            </thead>
            <tbody>
              ${issues.slice(0, 50).map((issue: QAIssue) => `
                <tr>
                  <td>${issue.issue_title}</td>
                  <td class="priority-${issue.priority.toLowerCase()}">${issue.priority}</td>
                  <td>${issue.category}</td>
                  <td>${issue.component}</td>
                  <td>${issue.status}</td>
                  <td>${issue.recommended_fix.substring(0, 100)}${issue.recommended_fix.length > 100 ? '...' : ''}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          ${issues.length > 50 ? `<p><em>Showing first 50 issues out of ${issues.length} total</em></p>` : ''}
        </div>
      ` : ''}

      <div class="section">
        <h2>Recommendations</h2>
        <ul>
          <li>Focus on resolving ${summary.criticalIssues} critical issues immediately</li>
          <li>Improve test coverage in areas with high failure rates</li>
          <li>Implement automated testing for frequently failing components</li>
          <li>Consider refactoring components with persistent issues</li>
          <li>Establish regular QA review cycles for continuous improvement</li>
        </ul>
      </div>
    `;
  };

  const exportToCSV = async (data: any) => {
    const { reports, issues } = data;

    // Generate CSV for reports
    const reportsCSV = [
    ['Report Name', 'Type', 'Execution Date', 'Total Tests', 'Passed', 'Failed', 'Pass Rate', 'Status', 'Created By'],
    ...reports.map((report: QAReport) => [
    report.report_name,
    report.report_type,
    report.execution_date,
    report.total_tests,
    report.passed_tests,
    report.failed_tests,
    report.pass_rate,
    report.status,
    report.created_by]
    )].
    map((row) => row.join(',')).join('\n');

    downloadCSV(reportsCSV, 'qa-reports');

    if (includeIssues && issues.length > 0) {
      // Generate CSV for issues
      const issuesCSV = [
      ['ID', 'Issue Title', 'Description', 'Priority', 'Category', 'Severity', 'Component', 'Status', 'Recommended Fix'],
      ...issues.map((issue: QAIssue) => [
      issue.id,
      issue.issue_title,
      issue.issue_description.replace(/,/g, ';'), // Replace commas to avoid CSV issues
      issue.priority,
      issue.category,
      issue.severity,
      issue.component,
      issue.status,
      issue.recommended_fix.replace(/,/g, ';')]
      )].
      map((row) => row.join(',')).join('\n');

      downloadCSV(issuesCSV, 'qa-issues');
    }
  };

  const downloadCSV = (csvContent: string, filename: string) => {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const exportToJSON = async (data: any) => {
    const jsonContent = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `qa-report-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Export Report
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Export QA Report</DialogTitle>
          <DialogDescription>
            Configure export settings and download comprehensive QA reports
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Export Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Export Format</label>
                <Select value={exportFormat} onValueChange={setExportFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pdf">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        PDF Report
                      </div>
                    </SelectItem>
                    <SelectItem value="csv">
                      <div className="flex items-center gap-2">
                        <Table className="h-4 w-4" />
                        CSV Data
                      </div>
                    </SelectItem>
                    <SelectItem value="json">
                      <div className="flex items-center gap-2">
                        <Code className="h-4 w-4" />
                        JSON Data
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium">Report Scope</label>
                <Select value={exportScope} onValueChange={setExportScope}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Reports</SelectItem>
                    <SelectItem value="recent">Last 30 Days</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">Include Sections</label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="include-issues"
                      checked={includeIssues}
                      onCheckedChange={setIncludeIssues} />

                    <label htmlFor="include-issues" className="text-sm">
                      Include Issues Details
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="include-charts"
                      checked={includeCharts}
                      onCheckedChange={setIncludeCharts} />

                    <label htmlFor="include-charts" className="text-sm">
                      Include Charts and Visualizations
                    </label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Export Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Format:</span>
                  <Badge variant="outline">{exportFormat.toUpperCase()}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Reports:</span>
                  <span>{exportScope === 'all' ? reports.length : reports.filter((r) => {
                      const thirtyDaysAgo = new Date();
                      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
                      return new Date(r.execution_date) >= thirtyDaysAgo;
                    }).length}</span>
                </div>
                <div className="flex justify-between">
                  <span>Issues:</span>
                  <span>{includeIssues ? issues.length : 'Not included'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Charts:</span>
                  <span>{includeCharts ? 'Included' : 'Not included'}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => setShowExportDialog(false)}
              disabled={isExporting}>

              Cancel
            </Button>
            <Button
              onClick={handleExport}
              disabled={isExporting}>

              {isExporting ?
              <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  Exporting...
                </> :

              <>
                  <Download className="mr-2 h-4 w-4" />
                  Export Report
                </>
              }
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>);

};

export default ReportExportManager;