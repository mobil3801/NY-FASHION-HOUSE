
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertCircle, CheckCircle, Download, Filter, Calendar, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { toast } from '@/hooks/use-toast';
import TestExecutionSummary from './TestExecutionSummary';
import FailureAnalysisView from './FailureAnalysisView';
import WCAGComplianceTest from './WCAGComplianceTest';
import IssueClassificationSystem from './IssueClassificationSystem';
import IssueTrackingWorkflow from './IssueTrackingWorkflow';
import ReportExportManager from './ReportExportManager';

interface QAReport {
  id: number;
  report_name: string;
  report_type: string;
  execution_date: string;
  total_tests: number;
  passed_tests: number;
  failed_tests: number;
  pass_rate: number;
  status: string;
  created_by: string;
}

interface QAIssue {
  id: number;
  report_id: number;
  issue_title: string;
  issue_description: string;
  priority: string;
  category: string;
  severity: string;
  component: string;
  status: string;
  recommended_fix: string;
}

const QAReportingDashboard: React.FC = () => {
  const [reports, setReports] = useState<QAReport[]>([]);
  const [issues, setIssues] = useState<QAIssue[]>([]);
  const [selectedReport, setSelectedReport] = useState<QAReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadReports();
    loadIssues();
  }, []);

  const loadReports = async () => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(38559, {
        PageNo: 1,
        PageSize: 50,
        OrderByField: 'execution_date',
        IsAsc: false,
        Filters: []
      });

      if (error) throw error;
      setReports(data?.List || []);
    } catch (error) {
      console.error('Error loading reports:', error);
      toast({
        title: "Error",
        description: "Failed to load QA reports",
        variant: "destructive"
      });
    }
  };

  const loadIssues = async () => {
    try {
      const { data, error } = await window.ezsite.apis.tablePage(38560, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: 'id',
        IsAsc: false,
        Filters: []
      });

      if (error) throw error;
      setIssues(data?.List || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading issues:', error);
      toast({
        title: "Error",
        description: "Failed to load QA issues",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical':return 'destructive';
      case 'High':return 'destructive';
      case 'Medium':return 'default';
      case 'Low':return 'secondary';
      default:return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':return 'text-green-600';
      case 'In Progress':return 'text-blue-600';
      case 'Failed':return 'text-red-600';
      default:return 'text-gray-600';
    }
  };

  const generateTrendData = () => {
    return reports.slice(-7).map((report) => ({
      date: new Date(report.execution_date).toLocaleDateString(),
      passRate: report.pass_rate,
      totalTests: report.total_tests
    }));
  };

  const generateIssueDistribution = () => {
    const distribution = issues.reduce((acc, issue) => {
      acc[issue.priority] = (acc[issue.priority] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(distribution).map(([priority, count]) => ({
      name: priority,
      value: count,
      color: priority === 'Critical' ? '#ef4444' :
      priority === 'High' ? '#f97316' :
      priority === 'Medium' ? '#eab308' : '#22c55e'
    }));
  };

  const totalIssues = issues.length;
  const criticalIssues = issues.filter((i) => i.priority === 'Critical').length;
  const openIssues = issues.filter((i) => i.status === 'Open').length;
  const avgPassRate = reports.length > 0 ?
  reports.reduce((sum, r) => sum + r.pass_rate, 0) / reports.length : 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>);

  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">QA Reporting Dashboard</h1>
          <p className="text-muted-foreground">
            Comprehensive quality assurance reporting and analysis
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setActiveTab('wcag')}>
            <CheckCircle className="mr-2 h-4 w-4" />
            Run WCAG Test
          </Button>
          <ReportExportManager reports={reports} issues={issues} />
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reports</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reports.length}</div>
            <p className="text-xs text-muted-foreground">
              +2 from last week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Pass Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgPassRate.toFixed(1)}%</div>
            <Progress value={avgPassRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Issues</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalIssues}</div>
            <p className="text-xs text-muted-foreground">
              {criticalIssues} critical, {openIssues} open
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resolution Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {totalIssues > 0 ? ((totalIssues - openIssues) / totalIssues * 100).toFixed(1) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              {totalIssues - openIssues} resolved issues
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="reports">Test Reports</TabsTrigger>
          <TabsTrigger value="issues">Issues</TabsTrigger>
          <TabsTrigger value="workflow">Workflow Automation</TabsTrigger>
          <TabsTrigger value="wcag">WCAG Compliance</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Pass Rate Trend</CardTitle>
                <CardDescription>Test pass rates over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={generateTrendData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="passRate" stroke="#8884d8" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Issue Distribution</CardTitle>
                <CardDescription>Issues by priority level</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={generateIssueDistribution()}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}>

                      {generateIssueDistribution().map((entry, index) =>
                      <Cell key={`cell-${index}`} fill={entry.color} />
                      )}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <TestExecutionSummary reports={reports} />
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Test Reports</CardTitle>
              <CardDescription>All QA test execution reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reports.map((report) =>
                <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-1">
                      <h4 className="font-medium">{report.report_name}</h4>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <span>{report.report_type}</span>
                        <span>{new Date(report.execution_date).toLocaleDateString()}</span>
                        <span className={getStatusColor(report.status)}>{report.status}</span>
                      </div>
                      <div className="flex items-center space-x-4 text-sm">
                        <span className="text-green-600">{report.passed_tests} passed</span>
                        <span className="text-red-600">{report.failed_tests} failed</span>
                        <span className="font-medium">{report.pass_rate.toFixed(1)}% pass rate</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Progress value={report.pass_rate} className="w-20" />
                      <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedReport(report)}>

                        Details
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="issues">
          <IssueClassificationSystem issues={issues} onIssuesUpdate={loadIssues} />
        </TabsContent>

        <TabsContent value="workflow">
          <IssueTrackingWorkflow issues={issues} onWorkflowUpdate={loadIssues} />
        </TabsContent>

        <TabsContent value="wcag">
          <WCAGComplianceTest onTestComplete={() => loadReports()} />
        </TabsContent>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription>Performance test results and trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                Performance metrics will be displayed here when performance tests are run.
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <FailureAnalysisView issues={issues} reports={reports} />
        </TabsContent>
      </Tabs>

      {selectedReport &&
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[80vh] overflow-y-auto">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>{selectedReport.report_name}</CardTitle>
                  <CardDescription>{selectedReport.report_type} Report</CardDescription>
                </div>
                <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedReport(null)}>

                  ✕
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Execution Date</h4>
                  <p className="text-sm text-muted-foreground">
                    {new Date(selectedReport.execution_date).toLocaleString()}
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Created By</h4>
                  <p className="text-sm text-muted-foreground">{selectedReport.created_by}</p>
                </div>
                <div>
                  <h4 className="font-medium">Total Tests</h4>
                  <p className="text-sm text-muted-foreground">{selectedReport.total_tests}</p>
                </div>
                <div>
                  <h4 className="font-medium">Pass Rate</h4>
                  <p className="text-sm text-muted-foreground">{selectedReport.pass_rate.toFixed(1)}%</p>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Test Results</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-green-600">Passed</span>
                    <span className="font-medium">{selectedReport.passed_tests}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-red-600">Failed</span>
                    <span className="font-medium">{selectedReport.failed_tests}</span>
                  </div>
                  <Progress value={selectedReport.pass_rate} className="mt-2" />
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Related Issues</h4>
                <div className="space-y-2">
                  {issues.
                filter((issue) => issue.report_id === selectedReport.id).
                map((issue) =>
                <div key={issue.id} className="flex items-center justify-between p-2 bg-muted rounded">
                        <span className="text-sm">{issue.issue_title}</span>
                        <Badge variant={getPriorityColor(issue.priority)}>
                          {issue.priority}
                        </Badge>
                      </div>
                )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      }
    </div>);

};

export default QAReportingDashboard;