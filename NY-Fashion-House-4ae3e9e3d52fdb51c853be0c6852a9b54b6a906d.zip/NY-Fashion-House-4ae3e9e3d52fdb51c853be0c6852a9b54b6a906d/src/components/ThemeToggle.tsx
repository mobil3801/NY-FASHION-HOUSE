import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/components/theme-provider';

const ThemeToggle: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleTheme}
      className="w-9 h-9 p-0 transition-all duration-300"
      style={{
        border: '1px solid var(--theme-border)',
        color: 'var(--theme-text)'
      }}
      title={`Switch to ${theme === 'light' ? 'dark' : 'light'} theme`}>

      {theme === 'light' ?
      <Moon className="h-4 w-4 transition-transform duration-300" /> :
      <Sun className="h-4 w-4 transition-transform duration-300" />
      }
    </Button>);

};

export default ThemeToggle;