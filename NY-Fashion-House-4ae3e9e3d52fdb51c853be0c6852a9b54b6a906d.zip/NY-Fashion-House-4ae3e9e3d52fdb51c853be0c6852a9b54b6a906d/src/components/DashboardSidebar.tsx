import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  Home,
  Users,
  Package,
  ShoppingCart,
  UserCheck,
  DollarSign,
  Building2,
  Settings,
  Calculator,
  BarChart3,
  X } from
'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';

const navigation = [
{
  name: 'Dashboard',
  href: '/',
  icon: Home
},
{
  name: 'Customers',
  href: '/customers',
  icon: Users
},
{
  name: 'Products',
  href: '/products',
  icon: Package
},
{
  name: 'Point of Sale',
  href: '/pos',
  icon: ShoppingCart
},
{
  name: 'Employees',
  href: '/employees',
  icon: UserCheck
},
{
  name: 'Salary Management',
  href: '/salary',
  icon: DollarSign
},
{
  name: 'Accounting',
  href: '/accounting',
  icon: Calculator
},
{
  name: 'Reports',
  href: '/reports',
  icon: BarChart3
}];


interface DashboardSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const DashboardSidebar: React.FC<DashboardSidebarProps> = ({ isOpen, onClose }) => {
  const location = useLocation();

  const SidebarContent = () =>
  <div className="flex h-full flex-col">
      <div className="flex h-16 items-center px-6 border-b md:border-b-0">
        <Building2 className="h-8 w-8 text-blue-600" />
        <span className="ml-2 text-xl font-bold text-gray-900">Manhas Fashion</span>
      </div>
      
      <nav className="flex-1 space-y-1 px-4 py-4">
        {navigation.map((item) => {
        const isActive = location.pathname === item.href;
        return (
          <Link
            key={item.name}
            to={item.href}
            onClick={onClose}
            className={cn(
              'group flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors duration-200',
              isActive ?
              'bg-blue-50 text-blue-700 border-r-2 border-blue-700' :
              'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            )}>

              <item.icon
              className={cn(
                'mr-3 h-5 w-5 flex-shrink-0',
                isActive ? 'text-blue-700' : 'text-gray-400 group-hover:text-gray-500'
              )} />

              <span className="truncate">{item.name}</span>
            </Link>);

      })}
      </nav>
      
      <div className="px-4 py-4 border-t">
        <div className="flex items-center px-3 py-2 text-sm text-gray-500 rounded-md hover:bg-gray-50 cursor-pointer transition-colors">
          <Settings className="mr-3 h-5 w-5" />
          Settings
        </div>
      </div>
    </div>;


  return (
    <>
      {/* Mobile Sidebar */}
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent side="left" className="p-0 w-64">
          <SidebarContent />
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      <div className="hidden md:flex h-[calc(100vh-64px)] w-64 flex-col bg-white shadow-sm border-r fixed left-0 top-16 z-40">
        <SidebarContent />
      </div>
    </>);

};

export default DashboardSidebar;