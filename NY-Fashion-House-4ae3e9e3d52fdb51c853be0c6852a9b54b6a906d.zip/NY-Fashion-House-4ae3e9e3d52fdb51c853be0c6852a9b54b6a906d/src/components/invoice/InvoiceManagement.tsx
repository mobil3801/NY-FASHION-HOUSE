import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import CustomPagination from '@/components/ui/custom-pagination';
import {
  Eye,
  MoreHorizontal,
  Mail,
  Printer,
  Edit,
  Trash2,
  DollarSign,
  AlertCircle,
  Calendar,
  Plus,
  FileText,
  RefreshCw,
  Download,
  Filter } from
'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { Invoice, InvoiceFilters } from '@/types/invoice';
import { invoiceService } from '@/services/invoiceService';
import { useUserRoles } from '@/hooks/use-user-roles';
import InvoiceSearchFilter from '@/components/InvoiceSearchFilter';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorDisplay from '@/components/ErrorDisplay';

const statusColors = {
  draft: 'bg-gray-100 text-gray-800 border-gray-200',
  sent: 'bg-blue-100 text-blue-800 border-blue-200',
  viewed: 'bg-purple-100 text-purple-800 border-purple-200',
  paid: 'bg-green-100 text-green-800 border-green-200',
  overdue: 'bg-red-100 text-red-800 border-red-200',
  cancelled: 'bg-gray-100 text-gray-800 border-gray-200'
};

const ITEMS_PER_PAGE = 10;

const InvoiceManagement: React.FC = () => {
  // Get user roles and permissions
  const {
    userRoles,
    isAdmin,
    isSales,
    canDeleteInvoices,
    canManageInvoices,
    canViewInvoices,
    loading: rolesLoading,
    error: rolesError
  } = useUserRoles();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedInvoices, setSelectedInvoices] = useState<Set<string>>(new Set());
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState<Invoice | null>(null);
  const [bulkDeleteDialogOpen, setBulkDeleteDialogOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);

  // Filters state
  const [filters, setFilters] = useState<InvoiceFilters>({});



  useEffect(() => {
    if (!rolesLoading && !rolesError) {
      if (canViewInvoices) {
        loadInvoices();
      } else {
        setError('Access denied. Insufficient permissions to view invoices.');
        setLoading(false);
      }
    }
  }, [canViewInvoices, filters, rolesLoading, rolesError]);

  const loadInvoices = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await invoiceService.getAllInvoices(filters);
      setInvoices(data);
    } catch (error) {
      console.error('Error loading invoices:', error);
      setError('Failed to load invoices. Please try again.');
      toast.error('Failed to load invoices');
    } finally {
      setLoading(false);
    }
  };

  // Filter and search logic
  const filteredInvoices = useMemo(() => {
    let result = [...invoices];

    // Apply search query
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      result = result.filter((invoice) =>
      invoice.invoiceNumber.toLowerCase().includes(query) ||
      invoice.customerName.toLowerCase().includes(query) ||
      invoice.customerPhone && invoice.customerPhone.toLowerCase().includes(query)
      );
    }

    // Apply amount filters
    if (filters.amountMin !== undefined) {
      result = result.filter((invoice) => invoice.totalAmount >= filters.amountMin!);
    }
    if (filters.amountMax !== undefined) {
      result = result.filter((invoice) => invoice.totalAmount <= filters.amountMax!);
    }

    return result;
  }, [invoices, filters]);

  // Pagination
  const totalPages = Math.ceil(filteredInvoices.length / ITEMS_PER_PAGE);
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const formatCurrency = (amount: number) => `$${amount.toFixed(2)}`;

  const getStatusIcon = (status: Invoice['status']) => {
    switch (status) {
      case 'overdue':
        return <AlertCircle className="h-3 w-3 mr-1" />;
      case 'paid':
        return <DollarSign className="h-3 w-3 mr-1" />;
      default:
        return null;
    }
  };

  const handleSelectInvoice = (invoiceId: string) => {
    const newSelection = new Set(selectedInvoices);
    if (newSelection.has(invoiceId)) {
      newSelection.delete(invoiceId);
    } else {
      newSelection.add(invoiceId);
    }
    setSelectedInvoices(newSelection);
  };

  const handleSelectAll = () => {
    if (selectedInvoices.size === paginatedInvoices.length) {
      setSelectedInvoices(new Set());
    } else {
      setSelectedInvoices(new Set(paginatedInvoices.map((inv) => inv.id)));
    }
  };

  const handleDeleteInvoice = async (invoice: Invoice) => {
    if (!canDeleteInvoices) {
      toast.error('Access denied. Only administrators can delete invoices.');
      return;
    }

    setInvoiceToDelete(invoice);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!invoiceToDelete || !canDeleteInvoices) return;

    try {
      const success = await invoiceService.deleteInvoice(invoiceToDelete.id);
      if (success) {
        toast.success('Invoice deleted successfully');
        setInvoices((prev) => prev.filter((inv) => inv.id !== invoiceToDelete.id));
        setSelectedInvoices((prev) => {
          const newSet = new Set(prev);
          newSet.delete(invoiceToDelete.id);
          return newSet;
        });
      } else {
        toast.error('Failed to delete invoice');
      }
    } catch (error) {
      console.error('Error deleting invoice:', error);
      toast.error('Failed to delete invoice');
    } finally {
      setDeleteDialogOpen(false);
      setInvoiceToDelete(null);
    }
  };

  const handleBulkDelete = () => {
    if (!canDeleteInvoices || selectedInvoices.size === 0) {
      toast.error('Access denied or no invoices selected.');
      return;
    }
    setBulkDeleteDialogOpen(true);
  };

  const confirmBulkDelete = async () => {
    if (!canDeleteInvoices) return;

    try {
      const deletePromises = Array.from(selectedInvoices).map((id) =>
      invoiceService.deleteInvoice(id)
      );

      const results = await Promise.all(deletePromises);
      const successCount = results.filter(Boolean).length;

      toast.success(`${successCount} invoice(s) deleted successfully`);

      // Refresh the list
      await loadInvoices();
      setSelectedInvoices(new Set());
    } catch (error) {
      console.error('Error bulk deleting invoices:', error);
      toast.error('Failed to delete some invoices');
    } finally {
      setBulkDeleteDialogOpen(false);
    }
  };

  const handleViewInvoice = (invoice: Invoice) => {
    // TODO: Navigate to invoice detail view
    toast.info(`Viewing invoice ${invoice.invoiceNumber}`);
  };

  const handleEditInvoice = (invoice: Invoice) => {
    if (!canManageInvoices) {
      toast.error('Access denied. Insufficient permissions to edit invoices.');
      return;
    }
    // TODO: Navigate to invoice edit form
    toast.info(`Editing invoice ${invoice.invoiceNumber}`);
  };

  const handlePrintInvoice = (invoice: Invoice) => {
    // TODO: Implement print functionality
    toast.info(`Printing invoice ${invoice.invoiceNumber}`);
  };

  const handleEmailInvoice = (invoice: Invoice) => {
    // TODO: Implement email functionality
    toast.info(`Sending email for invoice ${invoice.invoiceNumber}`);
  };

  const handleRecordPayment = (invoice: Invoice) => {
    if (!canManageInvoices) {
      toast.error('Access denied. Insufficient permissions to record payments.');
      return;
    }
    // TODO: Open payment recording dialog
    toast.info(`Recording payment for invoice ${invoice.invoiceNumber}`);
  };

  const hasActiveFilters = Object.values(filters).some((value) =>
  value !== undefined && value !== '' && value !== null
  );

  if (rolesLoading) {
    return (
      <div className="p-6">
        <LoadingSpinner message="Checking permissions..." />
      </div>);

  }

  if (rolesError) {
    return (
      <div className="p-6">
        <ErrorDisplay
          message={`Authentication error: ${rolesError}`}
          onRetry={() => window.location.reload()} />

      </div>);

  }

  if (!canViewInvoices) {
    return (
      <div className="p-6">
        <ErrorDisplay
          message="Access denied. You don't have sufficient permissions to view invoices."
          onRetry={() => window.location.reload()} />

      </div>);

  }

  if (loading) {
    return (
      <div className="p-6">
        <LoadingSpinner message="Loading invoices..." />
      </div>);

  }

  if (error) {
    return (
      <div className="p-6">
        <ErrorDisplay message={error} onRetry={loadInvoices} />
      </div>);

  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Invoice Management</h1>
          <p className="text-muted-foreground">
            Manage your invoices, track payments, and handle billing operations
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="w-full sm:w-auto">

            <Filter className="h-4 w-4 mr-2" />
            {showFilters ? 'Hide Filters' : 'Show Filters'}
          </Button>
          <Button
            variant="outline"
            onClick={loadInvoices}
            className="w-full sm:w-auto">

            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          {canManageInvoices &&
          <Button className="w-full sm:w-auto">
              <Plus className="h-4 w-4 mr-2" />
              New Invoice
            </Button>
          }
        </div>
      </div>

      {/* Filters */}
      {showFilters &&
      <InvoiceSearchFilter
        filters={filters}
        onFiltersChange={setFilters}
        onClearFilters={() => {
          setFilters({});
          setCurrentPage(1);
        }}
        hasActiveFilters={hasActiveFilters} />

      }

      {/* Bulk Actions */}
      {selectedInvoices.size > 0 &&
      <Card>
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">
                {selectedInvoices.size} invoice(s) selected
              </span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export Selected
                </Button>
                {canDeleteInvoices &&
              <Button
                variant="destructive"
                size="sm"
                onClick={handleBulkDelete}>

                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete Selected
                  </Button>
              }
              </div>
            </div>
          </CardContent>
        </Card>
      }

      {/* Invoice Table */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Invoices ({filteredInvoices.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredInvoices.length === 0 ?
          <div className="text-center py-8">
              <div className="mx-auto h-12 w-12 text-gray-400 mb-4">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No invoices found</h3>
              <p className="text-gray-500">
                {hasActiveFilters ?
              'No invoices match your current filters. Try adjusting your search criteria.' :
              'Create your first invoice to get started.'
              }
              </p>
            </div> :

          <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]">
                      <Checkbox
                      checked={paginatedInvoices.length > 0 && selectedInvoices.size === paginatedInvoices.length}
                      onCheckedChange={handleSelectAll}
                      aria-label="Select all invoices" />

                    </TableHead>
                    <TableHead>Invoice #</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Issue Date</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Paid</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[50px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedInvoices.map((invoice) =>
                <TableRow key={invoice.id} className="hover:bg-gray-50">
                      <TableCell>
                        <Checkbox
                      checked={selectedInvoices.has(invoice.id)}
                      onCheckedChange={() => handleSelectInvoice(invoice.id)}
                      aria-label={`Select invoice ${invoice.invoiceNumber}`} />

                      </TableCell>
                      <TableCell className="font-medium">
                        <button
                      onClick={() => handleViewInvoice(invoice)}
                      className="text-blue-600 hover:text-blue-800 hover:underline">

                          {invoice.invoiceNumber}
                        </button>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{invoice.customerName}</div>
                          {invoice.customerPhone &&
                      <div className="text-sm text-gray-500">{invoice.customerPhone}</div>
                      }
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm text-gray-600">
                          <Calendar className="h-3 w-3 mr-1" />
                          {format(invoice.issueDate, 'MMM dd, yyyy')}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className={`flex items-center text-sm ${
                    invoice.status === 'overdue' ? 'text-red-600' : 'text-gray-600'}`
                    }>
                          <Calendar className="h-3 w-3 mr-1" />
                          {format(invoice.dueDate, 'MMM dd, yyyy')}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">
                        {formatCurrency(invoice.totalAmount)}
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium text-green-600">
                            {formatCurrency(invoice.paidAmount)}
                          </div>
                          {invoice.remainingAmount > 0 &&
                      <div className="text-xs text-gray-500">
                              {formatCurrency(invoice.remainingAmount)} due
                            </div>
                      }
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                      variant="secondary"
                      className={`${statusColors[invoice.status]} flex items-center w-fit`}>

                          {getStatusIcon(invoice.status)}
                          {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewInvoice(invoice)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            {canManageInvoices &&
                        <DropdownMenuItem onClick={() => handleEditInvoice(invoice)}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                        }
                            <DropdownMenuItem onClick={() => handlePrintInvoice(invoice)}>
                              <Printer className="h-4 w-4 mr-2" />
                              Print
                            </DropdownMenuItem>
                            {invoice.customerEmail &&
                        <DropdownMenuItem onClick={() => handleEmailInvoice(invoice)}>
                                <Mail className="h-4 w-4 mr-2" />
                                Send Email
                              </DropdownMenuItem>
                        }
                            {invoice.remainingAmount > 0 && canManageInvoices &&
                        <DropdownMenuItem onClick={() => handleRecordPayment(invoice)}>
                                <DollarSign className="h-4 w-4 mr-2" />
                                Record Payment
                              </DropdownMenuItem>
                        }
                            {canDeleteInvoices &&
                        <DropdownMenuItem
                          onClick={() => handleDeleteInvoice(invoice)}
                          className="text-red-600">

                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                        }
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                )}
                </TableBody>
              </Table>
            </div>
          }
        </CardContent>
      </Card>

      {/* Pagination */}
      {totalPages > 1 &&
      <CustomPagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage} />

      }

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Invoice</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete invoice {invoiceToDelete?.invoiceNumber}? 
              This action cannot be undone and will permanently remove the invoice and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700">

              Delete Invoice
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Delete Confirmation Dialog */}
      <AlertDialog open={bulkDeleteDialogOpen} onOpenChange={setBulkDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Multiple Invoices</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedInvoices.size} selected invoice(s)? 
              This action cannot be undone and will permanently remove all selected invoices and their associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmBulkDelete}
              className="bg-red-600 hover:bg-red-700">

              Delete {selectedInvoices.size} Invoices
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>);

};

export default InvoiceManagement;