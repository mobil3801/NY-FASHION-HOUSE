import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  FileText,
  DollarSign,
  AlertCircle,
  CheckCircle,
  Clock,
  TrendingUp,
  Eye,
  RefreshCw } from
'lucide-react';
import { InvoiceStats } from '@/types/invoice';
import { invoiceService } from '@/services/invoiceService';
import { toast } from 'sonner';

interface InvoiceStatsDashboardProps {
  onViewAll?: () => void;
}

const InvoiceStatsDashboard: React.FC<InvoiceStatsDashboardProps> = ({ onViewAll }) => {
  const [stats, setStats] = useState<InvoiceStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await invoiceService.getInvoiceStats();
      setStats(data);
    } catch (error) {
      console.error('Error loading invoice stats:', error);
      setError('Failed to load invoice statistics');
      toast.error('Failed to load invoice statistics');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => `$${amount.toFixed(2)}`;

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
          </div>
        </CardContent>
      </Card>);

  }

  if (error || !stats) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center py-8">
            <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Failed to load statistics</h3>
            <p className="text-gray-500 mb-4">{error || 'An unexpected error occurred.'}</p>
            <Button onClick={loadStats} variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry
            </Button>
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Invoice Overview</h2>
          <p className="text-muted-foreground">Track your invoice performance and outstanding payments</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={loadStats} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          {onViewAll &&
          <Button onClick={onViewAll} variant="outline" size="sm">
              <Eye className="h-4 w-4 mr-2" />
              View All
            </Button>
          }
        </div>
      </div>

      {/* Main Statistics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Invoices */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Invoices</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalInvoices}</div>
            <p className="text-xs text-muted-foreground">
              All invoices created
            </p>
          </CardContent>
        </Card>

        {/* Total Revenue */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.totalAmount)}</div>
            <p className="text-xs text-muted-foreground">
              Total invoiced amount
            </p>
          </CardContent>
        </Card>

        {/* Paid Amount */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Payments Received</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(stats.paidAmount)}</div>
            <p className="text-xs text-muted-foreground">
              {stats.totalAmount > 0 ?
              `${(stats.paidAmount / stats.totalAmount * 100).toFixed(1)}% of total` :
              'No invoices yet'
              }
            </p>
          </CardContent>
        </Card>

        {/* Outstanding Amount */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding</CardTitle>
            <DollarSign className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{formatCurrency(stats.pendingAmount)}</div>
            <p className="text-xs text-muted-foreground">
              Amount pending payment
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Status Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Invoice Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Invoice Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Paid
                </Badge>
              </div>
              <span className="font-medium">{stats.paidCount}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-red-100 text-red-800 border-red-200">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Overdue
                </Badge>
              </div>
              <span className="font-medium">{stats.overdueCount}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-blue-100 text-blue-800 border-blue-200">
                  <Clock className="h-3 w-3 mr-1" />
                  Pending
                </Badge>
              </div>
              <span className="font-medium">{stats.pendingCount}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="bg-gray-100 text-gray-800 border-gray-200">
                  <FileText className="h-3 w-3 mr-1" />
                  Draft
                </Badge>
              </div>
              <span className="font-medium">{stats.draftCount}</span>
            </div>
          </CardContent>
        </Card>

        {/* Financial Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Financial Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Total Invoiced</span>
                <span className="font-medium">{formatCurrency(stats.totalAmount)}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-green-600">Payments Received</span>
                <span className="font-medium text-green-600">{formatCurrency(stats.paidAmount)}</span>
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-orange-600">Outstanding</span>
                <span className="font-medium text-orange-600">{formatCurrency(stats.pendingAmount)}</span>
              </div>
              
              {stats.overdueAmount > 0 &&
              <div className="flex justify-between text-sm">
                  <span className="text-red-600">Overdue</span>
                  <span className="font-medium text-red-600">{formatCurrency(stats.overdueAmount)}</span>
                </div>
              }
            </div>

            <div className="pt-4 border-t">
              <div className="flex justify-between">
                <span className="font-medium">Collection Rate</span>
                <span className="font-bold">
                  {stats.totalAmount > 0 ?
                  `${(stats.paidAmount / stats.totalAmount * 100).toFixed(1)}%` :
                  'N/A'
                  }
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Items */}
      {stats.overdueAmount > 0 &&
      <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <div className="flex-1">
                <h3 className="font-semibold text-red-900">Overdue Invoices Require Attention</h3>
                <p className="text-sm text-red-700">
                  You have {formatCurrency(stats.overdueAmount)} in overdue payments across {stats.overdueCount} invoice(s).
                </p>
              </div>
              {onViewAll &&
            <Button
              onClick={onViewAll}
              size="sm"
              className="bg-red-600 hover:bg-red-700">

                  Review Overdue
                </Button>
            }
            </div>
          </CardContent>
        </Card>
      }
    </div>);

};

export default InvoiceStatsDashboard;