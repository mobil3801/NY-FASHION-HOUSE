// Comprehensive Error Monitoring Dashboard - Production-ready monitoring and analytics
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Brain,
  Clock,
  Download,
  Filter,
  Gauge,
  LineChart,
  RefreshCcw,
  Search,
  Settings,
  Shield,
  TrendingDown,
  TrendingUp,
  Users,
  Zap } from
'lucide-react';
import { toast } from 'sonner';
import {
  centralizedErrorManager,
  getErrorPatterns,
  getPerformanceMetrics } from
'@/services/centralizedErrorManager';
import {
  automatedErrorAnalyzer,
  getLatestAnalysisReport,
  getErrorClusters,
  getErrorPredictions } from
'@/services/automatedErrorAnalyzer';
import {
  comprehensiveErrorTrackingService,
  ComprehensiveErrorReport } from
'@/services/comprehensiveErrorTrackingService';

interface DashboardMetrics {
  totalErrors: number;
  recentErrors: number;
  errorRate: number;
  healthScore: number;
  criticalIssues: number;
  resolvedIssues: number;
  averageResolutionTime: number;
  userSatisfaction: number;
}

interface TimeSeriesData {
  timestamp: string;
  errorCount: number;
  severity: string;
  category: string;
}

interface ErrorTrend {
  period: string;
  errorCount: number;
  trend: 'up' | 'down' | 'stable';
  changePercentage: number;
}

const ComprehensiveErrorMonitoringDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalErrors: 0,
    recentErrors: 0,
    errorRate: 0,
    healthScore: 100,
    criticalIssues: 0,
    resolvedIssues: 0,
    averageResolutionTime: 0,
    userSatisfaction: 85
  });
  const [errorReports, setErrorReports] = useState<ComprehensiveErrorReport[]>([]);
  const [timeSeriesData, setTimeSeriesData] = useState<TimeSeriesData[]>([]);
  const [trends, setTrends] = useState<ErrorTrend[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(30000); // 30 seconds

  useEffect(() => {
    loadDashboardData();

    let interval: NodeJS.Timeout;
    if (autoRefresh) {
      interval = setInterval(loadDashboardData, refreshInterval);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh, refreshInterval]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      // Load all error data
      const reports = comprehensiveErrorTrackingService.getErrorReports();
      const statistics = comprehensiveErrorTrackingService.getStatistics();
      const performanceMetrics = getPerformanceMetrics();
      const analysisReport = getLatestAnalysisReport();
      const clusters = getErrorClusters();
      const patterns = getErrorPatterns();

      // Update metrics
      setMetrics({
        totalErrors: statistics.totalErrors,
        recentErrors: statistics.recentErrors,
        errorRate: performanceMetrics.errorRate || 0,
        healthScore: analysisReport.summary.overallHealthScore || 100,
        criticalIssues: clusters.filter((c) => c.severity === 'critical').length,
        resolvedIssues: patterns.filter((p) => p.isResolved).length,
        averageResolutionTime: statistics.averageResolutionTime,
        userSatisfaction: 85 // This would come from user feedback in a real system
      });

      // Update error reports
      setErrorReports(reports.slice(0, 100)); // Show latest 100 errors

      // Generate time series data
      setTimeSeriesData(generateTimeSeriesData(reports));

      // Generate trend data
      setTrends(generateTrendData(reports));

      setLastUpdate(new Date());
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
      toast.error('Failed to load monitoring data');
    } finally {
      setIsLoading(false);
    }
  };

  const generateTimeSeriesData = (reports: ComprehensiveErrorReport[]): TimeSeriesData[] => {
    const dataMap = new Map<string, {count: number;severity: string;category: string;}>();

    reports.slice(0, 50).forEach((report) => {
      const hour = new Date(report.timestamp).toISOString().slice(0, 13) + ':00:00.000Z';
      const existing = dataMap.get(hour) || { count: 0, severity: 'low', category: 'unknown' };

      dataMap.set(hour, {
        count: existing.count + 1,
        severity: report.severity === 'critical' ? 'critical' : existing.severity,
        category: report.category
      });
    });

    return Array.from(dataMap.entries()).
    map(([timestamp, data]) => ({
      timestamp,
      errorCount: data.count,
      severity: data.severity,
      category: data.category
    })).
    sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  };

  const generateTrendData = (reports: ComprehensiveErrorReport[]): ErrorTrend[] => {
    const now = new Date();
    const periods = [
    { label: '1H', hours: 1 },
    { label: '6H', hours: 6 },
    { label: '24H', hours: 24 },
    { label: '7D', hours: 168 }];


    return periods.map((period) => {
      const cutoffTime = new Date(now.getTime() - period.hours * 60 * 60 * 1000);
      const periodErrors = reports.filter((r) => new Date(r.timestamp) > cutoffTime);

      const previousCutoffTime = new Date(cutoffTime.getTime() - period.hours * 60 * 60 * 1000);
      const previousPeriodErrors = reports.filter((r) => {
        const errorTime = new Date(r.timestamp);
        return errorTime > previousCutoffTime && errorTime <= cutoffTime;
      });

      const currentCount = periodErrors.length;
      const previousCount = previousPeriodErrors.length;
      const changePercentage = previousCount > 0 ? (currentCount - previousCount) / previousCount * 100 : 0;

      let trend: 'up' | 'down' | 'stable' = 'stable';
      if (Math.abs(changePercentage) > 10) {
        trend = changePercentage > 0 ? 'up' : 'down';
      }

      return {
        period: period.label,
        errorCount: currentCount,
        trend,
        changePercentage: Math.abs(changePercentage)
      };
    });
  };

  const exportDiagnosticReport = async () => {
    try {
      const diagnosticData = centralizedErrorManager.exportDiagnosticData();
      const analysisData = automatedErrorAnalyzer.exportAnalysisData();

      const completeReport = {
        timestamp: new Date().toISOString(),
        diagnosticData: JSON.parse(diagnosticData),
        analysisData: JSON.parse(analysisData),
        dashboardMetrics: metrics,
        trends,
        timeSeriesData
      };

      const blob = new Blob([JSON.stringify(completeReport, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `error-monitoring-report-${new Date().toISOString().slice(0, 19)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success('Diagnostic Report Exported', {
        description: 'Complete monitoring report has been downloaded.',
        duration: 5000
      });
    } catch (error) {
      console.error('Failed to export diagnostic report:', error);
      toast.error('Failed to export diagnostic report');
    }
  };

  const renderOverview = () =>
  <div className="space-y-6">
      {/* System Health Summary */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Gauge className="h-6 w-6 text-blue-500" />
              <CardTitle>System Health Overview</CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Button
              onClick={loadDashboardData}
              disabled={isLoading}
              size="sm"
              variant="outline">

                <RefreshCcw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Badge variant={autoRefresh ? 'default' : 'secondary'}>
                {autoRefresh ? 'Auto-Refresh On' : 'Manual Mode'}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <MetricCard
            title="Health Score"
            value={`${metrics.healthScore}%`}
            trend={metrics.healthScore >= 80 ? 'stable' : 'down'}
            icon={<Shield className="h-5 w-5" />}
            color={metrics.healthScore >= 80 ? 'green' : metrics.healthScore >= 50 ? 'yellow' : 'red'} />

            <MetricCard
            title="Error Rate"
            value={`${metrics.errorRate.toFixed(1)}/min`}
            trend={metrics.errorRate < 5 ? 'stable' : 'up'}
            icon={<Activity className="h-5 w-5" />}
            color={metrics.errorRate < 5 ? 'green' : metrics.errorRate < 10 ? 'yellow' : 'red'} />

            <MetricCard
            title="Critical Issues"
            value={metrics.criticalIssues.toString()}
            trend={metrics.criticalIssues === 0 ? 'stable' : 'up'}
            icon={<AlertTriangle className="h-5 w-5" />}
            color={metrics.criticalIssues === 0 ? 'green' : 'red'} />

            <MetricCard
            title="Recent Errors"
            value={metrics.recentErrors.toString()}
            trend="stable"
            icon={<BarChart3 className="h-5 w-5" />}
            color="blue" />

          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Overall System Health</span>
                <span>{metrics.healthScore}%</span>
              </div>
              <Progress
              value={metrics.healthScore}
              className={`h-3 ${
              metrics.healthScore >= 80 ? '' :
              metrics.healthScore >= 50 ? 'bg-yellow-200' : 'bg-red-200'}`
              } />

            </div>

            <div className="text-xs text-muted-foreground">
              Last updated: {lastUpdate.toLocaleString()}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Error Trends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <LineChart className="h-5 w-5" />
            <span>Error Trends</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {trends.map((trend) =>
          <div key={trend.period} className="text-center">
                <div className="text-2xl font-bold">{trend.errorCount}</div>
                <div className="text-sm text-muted-foreground mb-2">{trend.period}</div>
                <div className="flex items-center justify-center space-x-1">
                  {trend.trend === 'up' && <TrendingUp className="h-4 w-4 text-red-500" />}
                  {trend.trend === 'down' && <TrendingDown className="h-4 w-4 text-green-500" />}
                  <span className={`text-xs ${
              trend.trend === 'up' ? 'text-red-500' :
              trend.trend === 'down' ? 'text-green-500' :
              'text-muted-foreground'}`
              }>
                    {trend.changePercentage.toFixed(1)}%
                  </span>
                </div>
              </div>
          )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button onClick={exportDiagnosticReport} variant="outline" className="h-20 flex-col">
              <Download className="h-5 w-5 mb-2" />
              Export Report
            </Button>
            <Button onClick={() => setActiveTab('analysis')} variant="outline" className="h-20 flex-col">
              <Brain className="h-5 w-5 mb-2" />
              Analysis
            </Button>
            <Button onClick={() => setActiveTab('alerts')} variant="outline" className="h-20 flex-col">
              <AlertTriangle className="h-5 w-5 mb-2" />
              Alerts
            </Button>
            <Button onClick={() => setActiveTab('settings')} variant="outline" className="h-20 flex-col">
              <Settings className="h-5 w-5 mb-2" />
              Settings
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>;


  const renderRealTimeMonitoring = () =>
  <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5" />
            <span>Real-Time Error Stream</span>
          </CardTitle>
          <CardDescription>Live feed of incoming errors</CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            <div className="space-y-2">
              {errorReports.slice(0, 20).map((report) =>
            <ErrorReportItem key={report.id} report={report} />
            )}
              {errorReports.length === 0 &&
            <div className="text-center py-8 text-muted-foreground">
                  No errors detected. System running smoothly!
                </div>
            }
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>;


  const renderAnalysis = () => {
    const analysisReport = getLatestAnalysisReport();
    const clusters = getErrorClusters();
    const predictions = getErrorPredictions();

    return (
      <div className="space-y-6">
        {/* Analysis Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5" />
              <span>Automated Analysis Results</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{analysisReport.summary.totalErrors}</div>
                <div className="text-sm text-muted-foreground">Total Errors</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{analysisReport.summary.resolvedPatterns}</div>
                <div className="text-sm text-muted-foreground">Resolved Patterns</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{analysisReport.summary.newPatterns}</div>
                <div className="text-sm text-muted-foreground">New Patterns</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{analysisReport.summary.criticalIssues}</div>
                <div className="text-sm text-muted-foreground">Critical Issues</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Error Clusters */}
        <Card>
          <CardHeader>
            <CardTitle>Error Clusters</CardTitle>
            <CardDescription>Grouped error patterns and their analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {clusters.slice(0, 5).map((cluster) =>
              <div key={cluster.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold">{cluster.name}</h4>
                    <div className="flex space-x-2">
                      <Badge variant={
                    cluster.severity === 'critical' ? 'destructive' :
                    cluster.severity === 'high' ? 'secondary' : 'default'
                    }>
                        {cluster.severity}
                      </Badge>
                      <Badge variant="outline">{cluster.frequency} occurrences</Badge>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground mb-2">
                    Affected Components: {cluster.affectedComponents.join(', ')}
                  </div>
                  <div className="text-sm">
                    <strong>Recommendations:</strong>
                    <ul className="list-disc list-inside mt-1">
                      {cluster.recommendedActions.slice(0, 2).map((action, index) =>
                    <li key={index}>{action}</li>
                    )}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Predictions */}
        <Card>
          <CardHeader>
            <CardTitle>Error Predictions</CardTitle>
            <CardDescription>AI-powered predictions of future error occurrences</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {predictions.slice(0, 3).map((prediction) =>
              <div key={prediction.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold">{prediction.errorType}</h4>
                    <div className="flex space-x-2">
                      <Badge variant={
                    prediction.riskLevel === 'critical' ? 'destructive' :
                    prediction.riskLevel === 'high' ? 'secondary' : 'default'
                    }>
                        {prediction.riskLevel} risk
                      </Badge>
                    </div>
                  </div>
                  <div className="text-sm text-muted-foreground mb-2">
                    Probability: {(prediction.probability * 100).toFixed(1)}% in {prediction.timeWindow}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Confidence: {(prediction.confidence * 100).toFixed(1)}%
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>);

  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Error Monitoring Dashboard</h1>
        <p className="text-muted-foreground">
          Comprehensive real-time monitoring and analysis of application errors
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="monitoring">Real-Time</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          {renderOverview()}
        </TabsContent>

        <TabsContent value="monitoring" className="mt-6">
          {renderRealTimeMonitoring()}
        </TabsContent>

        <TabsContent value="analysis" className="mt-6">
          {renderAnalysis()}
        </TabsContent>
      </Tabs>
    </div>);

};

// Metric Card Component
interface MetricCardProps {
  title: string;
  value: string;
  trend: 'up' | 'down' | 'stable';
  icon: React.ReactNode;
  color: 'green' | 'yellow' | 'red' | 'blue';
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, trend, icon, color }) => {
  const colorClasses = {
    green: 'text-green-600 bg-green-50 dark:bg-green-950',
    yellow: 'text-yellow-600 bg-yellow-50 dark:bg-yellow-950',
    red: 'text-red-600 bg-red-50 dark:bg-red-950',
    blue: 'text-blue-600 bg-blue-50 dark:bg-blue-950'
  };

  return (
    <div className={`p-4 rounded-lg ${colorClasses[color]}`}>
      <div className="flex items-center justify-between mb-2">
        {icon}
        {trend === 'up' && <TrendingUp className="h-4 w-4" />}
        {trend === 'down' && <TrendingDown className="h-4 w-4" />}
      </div>
      <div className="text-2xl font-bold mb-1">{value}</div>
      <div className="text-sm opacity-80">{title}</div>
    </div>);

};

// Error Report Item Component
interface ErrorReportItemProps {
  report: ComprehensiveErrorReport;
}

const ErrorReportItem: React.FC<ErrorReportItemProps> = ({ report }) => {
  const timeAgo = new Date(Date.now() - new Date(report.timestamp).getTime()).toISOString().slice(11, 19);

  return (
    <div className="flex items-center space-x-3 p-3 border rounded-lg">
      <div className="flex-shrink-0">
        <AlertTriangle className={`h-4 w-4 ${
        report.severity === 'critical' ? 'text-red-500' :
        report.severity === 'high' ? 'text-orange-500' :
        report.severity === 'medium' ? 'text-yellow-500' : 'text-blue-500'}`
        } />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium truncate">{report.message}</div>
        <div className="text-xs text-muted-foreground">
          {report.context.component || 'Unknown'} • {report.category}
        </div>
      </div>
      <div className="flex-shrink-0 text-xs text-muted-foreground">
        {timeAgo}
      </div>
    </div>);

};

export default ComprehensiveErrorMonitoringDashboard;