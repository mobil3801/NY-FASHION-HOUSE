
import React from 'react';
import { Package } from 'lucide-react';

interface ProductThumbnailProps {
  imageIds?: number[];
  altText?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const ProductThumbnail: React.FC<ProductThumbnailProps> = ({
  imageIds = [],
  altText = 'Product image',
  size = 'md',
  className = ''
}) => {
  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-24 h-24',
    lg: 'w-32 h-32'
  };

  const [imageUrl, setImageUrl] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const loadImage = async () => {
      if (imageIds && imageIds.length > 0) {
        try {
          const { data, error } = await window.ezsite.apis.getUploadUrl(imageIds[0]);
          if (!error && data) {
            setImageUrl(data);
          }
        } catch (err) {
          console.warn('Failed to load product image:', err);
        }
      }
      setLoading(false);
    };

    loadImage();
  }, [imageIds]);

  if (loading) {
    return (
      <div className={`${sizeClasses[size]} ${className} bg-gray-100 animate-pulse rounded-md flex items-center justify-center`}>
        <Package className="h-6 w-6 text-gray-400" />
      </div>);

  }

  if (imageUrl) {
    return (
      <img
        src={imageUrl}
        alt={altText}
        className={`${sizeClasses[size]} ${className} object-cover rounded-md`}
        loading="lazy" />);


  }

  return (
    <div className={`${sizeClasses[size]} ${className} bg-gray-100 rounded-md flex items-center justify-center`}>
      <Package className="h-6 w-6 text-gray-400" />
    </div>);

};

export default ProductThumbnail;