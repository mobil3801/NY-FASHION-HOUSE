import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { FileText, Printer, Download, Eye } from 'lucide-react';
import { Employee } from '@/types/employee';
import { SalarySlip, PayPeriod } from '@/types/salary';
import { employeeService } from '@/services/employeeService';
import { salaryService } from '@/services/salaryService';
import { toast } from 'sonner';

interface SalarySlipGeneratorProps {
  onSlipGenerated?: (slip: SalarySlip) => void;
}

const SalarySlipGenerator: React.FC<SalarySlipGeneratorProps> = ({ onSlipGenerated }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payPeriods, setPayPeriods] = useState<PayPeriod[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('');
  const [generatedSlip, setGeneratedSlip] = useState<SalarySlip | null>(null);
  const [loading, setLoading] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [employeesData, payPeriodsData] = await Promise.all([
      employeeService.getAllEmployees(),
      salaryService.getAllPayPeriods()]
      );
      setEmployees(employeesData.filter((emp) => emp.employmentStatus === 'active'));
      setPayPeriods(payPeriodsData);
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load data');
    }
  };

  const handleGenerateSlip = async () => {
    if (!selectedEmployee || !selectedPeriod) {
      toast.error('Please select both employee and pay period');
      return;
    }

    setLoading(true);
    try {
      const slip = await salaryService.generateSalarySlip(selectedEmployee, selectedPeriod, 'current-user');
      setGeneratedSlip(slip);
      onSlipGenerated?.(slip);
      toast.success('Salary slip generated successfully');
    } catch (error) {
      console.error('Failed to generate salary slip:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to generate salary slip');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    if (printRef.current) {
      const printContent = printRef.current;
      const printWindow = window.open('', '_blank');

      if (printWindow) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Salary Slip - ${generatedSlip?.employee.firstName} ${generatedSlip?.employee.lastName}</title>
              <style>
                body { 
                  font-family: Arial, sans-serif; 
                  margin: 0; 
                  padding: 20px; 
                  color: #333;
                }
                .salary-slip { 
                  max-width: 800px; 
                  margin: 0 auto; 
                  background: white;
                }
                .header { 
                  text-align: center; 
                  border-bottom: 2px solid #333; 
                  padding-bottom: 20px; 
                  margin-bottom: 30px;
                }
                .company-name { 
                  font-size: 24px; 
                  font-weight: bold; 
                  margin-bottom: 5px;
                }
                .slip-title { 
                  font-size: 18px; 
                  color: #666;
                }
                .employee-info { 
                  display: grid; 
                  grid-template-columns: 1fr 1fr; 
                  gap: 20px; 
                  margin-bottom: 30px;
                }
                .info-group h4 { 
                  margin: 0 0 10px 0; 
                  color: #333; 
                  font-size: 14px; 
                  text-transform: uppercase;
                }
                .info-group p { 
                  margin: 5px 0; 
                  font-size: 14px;
                }
                .salary-details { 
                  margin-bottom: 30px;
                }
                .section-title { 
                  font-size: 16px; 
                  font-weight: bold; 
                  margin-bottom: 15px; 
                  padding-bottom: 5px; 
                  border-bottom: 1px solid #ddd;
                }
                .detail-row { 
                  display: flex; 
                  justify-content: space-between; 
                  padding: 8px 0; 
                  border-bottom: 1px solid #eee;
                }
                .detail-row:last-child { 
                  border-bottom: none;
                }
                .total-row { 
                  font-weight: bold; 
                  font-size: 16px; 
                  background: #f5f5f5; 
                  padding: 12px; 
                  margin: 10px 0;
                }
                .net-salary { 
                  background: #e8f5e8; 
                  border: 2px solid #4CAF50; 
                  padding: 15px; 
                  text-align: center; 
                  font-size: 20px; 
                  font-weight: bold; 
                  color: #2E7D32;
                }
                .footer { 
                  margin-top: 40px; 
                  padding-top: 20px; 
                  border-top: 1px solid #ddd; 
                  font-size: 12px; 
                  color: #666;
                }
                @media print {
                  body { margin: 0; }
                  .no-print { display: none; }
                }
              </style>
            </head>
            <body>
              ${printContent.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-BD');
  };

  return (
    <div className="space-y-6">
      {/* Generator Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Generate Salary Slip
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Employee</label>
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose an employee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((employee) =>
                  <SelectItem key={employee.id} value={employee.id}>
                      {employee.firstName} {employee.lastName} - {employee.position}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Select Pay Period</label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose pay period" />
                </SelectTrigger>
                <SelectContent>
                  {payPeriods.map((period) =>
                  <SelectItem key={period.id} value={period.payPeriod}>
                      {period.payPeriod} ({period.bengaliMonth} {period.bengaliYear})
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-4">
            <Button
              onClick={handleGenerateSlip}
              disabled={!selectedEmployee || !selectedPeriod || loading}>

              {loading ?
              'Generating...' :

              <>
                  <Eye className="h-4 w-4 mr-2" />
                  Generate Slip
                </>
              }
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Generated Salary Slip */}
      {generatedSlip &&
      <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Salary Slip Preview</CardTitle>
            <div className="flex items-center space-x-2">
              <Button variant="outline" onClick={handlePrint}>
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div ref={printRef} className="salary-slip">
              {/* Header */}
              <div className="header text-center border-b-2 pb-6 mb-8">
                <h1 className="company-name text-2xl font-bold mb-2">Your Company Name</h1>
                <p className="slip-title text-lg text-gray-600">SALARY SLIP</p>
                <p className="text-sm text-gray-500 mt-2">
                  Pay Period: {generatedSlip.salaryCalculation.payPeriod} 
                  ({generatedSlip.salaryCalculation.bengaliMonth} {generatedSlip.salaryCalculation.bengaliYear})
                </p>
              </div>

              {/* Employee Information */}
              <div className="employee-info grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div className="info-group">
                  <h4 className="text-sm font-semibold text-gray-700 uppercase mb-3">Employee Details</h4>
                  <p><strong>Name:</strong> {generatedSlip.employee.firstName} {generatedSlip.employee.lastName}</p>
                  <p><strong>Employee ID:</strong> {generatedSlip.employee.employeeCode}</p>
                  <p><strong>Position:</strong> {generatedSlip.employee.position}</p>
                  <p><strong>Department:</strong> {generatedSlip.employee.department}</p>
                </div>
                <div className="info-group">
                  <h4 className="text-sm font-semibold text-gray-700 uppercase mb-3">Payment Details</h4>
                  <p><strong>Generated Date:</strong> {formatDate(generatedSlip.generatedAt)}</p>
                  <p><strong>Status:</strong> 
                    <Badge variant="outline" className="ml-2">
                      {generatedSlip.salaryCalculation.status}
                    </Badge>
                  </p>
                  {generatedSlip.paymentRecord &&
                <>
                      <p><strong>Payment Method:</strong> {generatedSlip.paymentRecord.paymentMethod}</p>
                      <p><strong>Payment Date:</strong> {formatDate(generatedSlip.paymentRecord.paymentDate)}</p>
                    </>
                }
                </div>
              </div>

              {/* Salary Breakdown */}
              <div className="salary-details space-y-6">
                {/* Earnings */}
                <div>
                  <h3 className="section-title">Earnings</h3>
                  <div className="space-y-2">
                    <div className="detail-row">
                      <span>Basic Salary</span>
                      <span>{formatCurrency(generatedSlip.salaryCalculation.baseSalary)}</span>
                    </div>
                    
                    {generatedSlip.salaryCalculation.allowances.map((allowance) =>
                  <div key={allowance.id} className="detail-row">
                        <span>
                          {allowance.name}
                          {allowance.type === 'percentage' &&
                      <span className="text-xs text-gray-500 ml-1">
                              ({allowance.baseAmount}%)
                            </span>
                      }
                        </span>
                        <span>{formatCurrency(allowance.calculatedAmount)}</span>
                      </div>
                  )}

                    {generatedSlip.salaryCalculation.overtime.overtimeHours > 0 &&
                  <div className="detail-row">
                        <span>
                          Overtime ({generatedSlip.salaryCalculation.overtime.overtimeHours.toFixed(2)} hrs @ {formatCurrency(generatedSlip.salaryCalculation.overtime.overtimeRate)}/hr)
                        </span>
                        <span>{formatCurrency(generatedSlip.salaryCalculation.overtime.overtimeAmount)}</span>
                      </div>
                  }
                  </div>
                  
                  <div className="total-row flex justify-between">
                    <span>Gross Salary</span>
                    <span>{formatCurrency(generatedSlip.salaryCalculation.grossSalary)}</span>
                  </div>
                </div>

                {/* Deductions */}
                {generatedSlip.salaryCalculation.deductions.length > 0 &&
              <div>
                    <h3 className="section-title">Deductions</h3>
                    <div className="space-y-2">
                      {generatedSlip.salaryCalculation.deductions.map((deduction) =>
                  <div key={deduction.id} className="detail-row">
                          <span>
                            {deduction.name}
                            {deduction.type === 'percentage' &&
                      <span className="text-xs text-gray-500 ml-1">
                                ({deduction.baseAmount}%)
                              </span>
                      }
                            {deduction.taxDetails &&
                      <span className="text-xs text-gray-500 ml-1">
                                ({deduction.taxDetails.taxRate}% tax)
                              </span>
                      }
                          </span>
                          <span>-{formatCurrency(deduction.calculatedAmount)}</span>
                        </div>
                  )}
                    </div>
                    
                    <div className="total-row flex justify-between">
                      <span>Total Deductions</span>
                      <span>-{formatCurrency(
                      generatedSlip.salaryCalculation.deductions.reduce((sum, d) => sum + d.calculatedAmount, 0)
                    )}</span>
                    </div>
                  </div>
              }

                {/* Net Salary */}
                <div className="net-salary">
                  <div className="flex justify-between items-center">
                    <span>Net Salary</span>
                    <span>{formatCurrency(generatedSlip.salaryCalculation.netSalary)}</span>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="footer text-center">
                <p className="text-sm text-gray-600">
                  This is a computer generated salary slip. No signature is required.
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  Generated on {formatDate(generatedSlip.generatedAt)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      }
    </div>);

};

export default SalarySlipGenerator;