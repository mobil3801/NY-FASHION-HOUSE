import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { errorLoggingService } from '@/services/errorLoggingService';
import ErrorDisplay from '@/components/ErrorDisplay';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  showDetails?: boolean;
  level?: 'page' | 'component';
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorId: string | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    errorId: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null, errorId: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log error with detailed information
    const errorId = errorLoggingService.logError(error, {
      componentStack: errorInfo.componentStack,
      severity: 'high',
      context: {
        type: 'react-error-boundary',
        props: this.props,
        errorInfo
      }
    });

    this.setState({
      error,
      errorInfo,
      errorId
    });

    // Call optional error handler
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
  }

  private handleRetry = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      errorId: null
    });
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      const variant = this.props.level === 'component' ? 'card' : 'page';

      return (
        <ErrorDisplay
          error={this.state.error || 'An error occurred in this component'}
          title="Something went wrong"
          description={
          this.state.errorId ?
          `An unexpected error occurred (Error ID: ${this.state.errorId}). Please try again or contact support.` :
          "An unexpected error occurred. Please try again."
          }
          showDetails={this.props.showDetails}
          onRetry={this.handleRetry}
          variant={variant} />);


    }

    return this.props.children;
  }
}

export default ErrorBoundary;