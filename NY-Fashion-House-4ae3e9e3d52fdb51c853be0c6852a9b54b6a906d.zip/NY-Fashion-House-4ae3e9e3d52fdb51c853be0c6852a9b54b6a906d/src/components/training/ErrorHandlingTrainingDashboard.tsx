// Interactive Error Handling Training Dashboard
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Book,
  Code2,
  PlayCircle,
  CheckCircle2,
  AlertTriangle,
  Target,
  TrendingUp,
  Users,
  FileText,
  Settings,
  Zap,
  Shield,
  Brain,
  Lightbulb,
  Award,
  Clock } from
'lucide-react';
import { toast } from 'sonner';
import { centralizedErrorManager, logError } from '@/services/centralizedErrorManager';
import { getLatestAnalysisReport, getErrorClusters } from '@/services/automatedErrorAnalyzer';
import UniversalErrorBoundary from '@/components/universal/UniversalErrorBoundary';

interface TrainingModule {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: string;
  topics: string[];
  completed: boolean;
  score?: number;
}

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
}

interface InteractiveDemo {
  id: string;
  title: string;
  description: string;
  component: React.ComponentType;
  expectedBehavior: string;
}

const ErrorHandlingTrainingDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [completedModules, setCompletedModules] = useState<Set<string>>(new Set());
  const [currentQuiz, setCurrentQuiz] = useState<QuizQuestion | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [demoResults, setDemoResults] = useState<Record<string, boolean>>({});
  const [trainingProgress, setTrainingProgress] = useState(0);

  const trainingModules: TrainingModule[] = [
  {
    id: 'basics',
    title: 'Error Handling Basics',
    description: 'Learn fundamental concepts of error handling in React applications',
    difficulty: 'beginner',
    duration: '30 minutes',
    topics: ['Error Boundaries', 'Try-Catch', 'Error Context', 'User Experience'],
    completed: false
  },
  {
    id: 'boundaries',
    title: 'Universal Error Boundaries',
    description: 'Master the implementation and usage of comprehensive error boundaries',
    difficulty: 'intermediate',
    duration: '45 minutes',
    topics: ['Multi-level Boundaries', 'Fallback Components', 'Recovery Mechanisms', 'Auto-retry'],
    completed: false
  },
  {
    id: 'centralized',
    title: 'Centralized Error Management',
    description: 'Understand centralized error logging and management systems',
    difficulty: 'intermediate',
    duration: '60 minutes',
    topics: ['Error Manager', 'Batching', 'Throttling', 'Performance Optimization'],
    completed: false
  },
  {
    id: 'analytics',
    title: 'Error Analytics & Patterns',
    description: 'Learn advanced error analysis and pattern detection techniques',
    difficulty: 'advanced',
    duration: '90 minutes',
    topics: ['Pattern Detection', 'Predictive Analytics', 'ML Clustering', 'Automated Analysis'],
    completed: false
  },
  {
    id: 'production',
    title: 'Production Best Practices',
    description: 'Production-ready error handling strategies and monitoring',
    difficulty: 'advanced',
    duration: '75 minutes',
    topics: ['Monitoring', 'Alerting', 'Performance', 'Security', 'Debugging'],
    completed: false
  }];


  const quizQuestions: QuizQuestion[] = [
  {
    id: 'q1',
    question: 'Which React error boundary method is called when an error is caught?',
    options: ['componentDidThrow', 'componentDidCatch', 'componentCaughtError', 'onError'],
    correctAnswer: 1,
    explanation: 'componentDidCatch is the lifecycle method called when a component catches an error.',
    category: 'basics'
  },
  {
    id: 'q2',
    question: 'What is the primary benefit of error batching in the centralized error manager?',
    options: ['Reduces memory usage', 'Improves performance', 'Better error messages', 'Automatic recovery'],
    correctAnswer: 1,
    explanation: 'Error batching improves performance by processing multiple errors together, reducing the overhead of individual error processing.',
    category: 'centralized'
  },
  {
    id: 'q3',
    question: 'Which error boundary level should be used for critical application-wide errors?',
    options: ['widget', 'component', 'route', 'root'],
    correctAnswer: 3,
    explanation: 'Root level error boundaries should be used for critical application-wide errors that might crash the entire application.',
    category: 'boundaries'
  },
  {
    id: 'q4',
    question: 'What does error clustering help achieve in the automated analyzer?',
    options: ['Faster processing', 'Pattern recognition', 'Memory optimization', 'User notifications'],
    correctAnswer: 1,
    explanation: 'Error clustering groups similar errors together to identify patterns and trends, enabling better analysis and prediction.',
    category: 'analytics'
  }];


  useEffect(() => {
    // Calculate training progress
    const completed = Array.from(completedModules).length;
    const progress = completed / trainingModules.length * 100;
    setTrainingProgress(progress);
  }, [completedModules, trainingModules.length]);

  const markModuleComplete = (moduleId: string) => {
    setCompletedModules((prev) => new Set([...prev, moduleId]));
    toast.success('Module Completed!', {
      description: `You've successfully completed the ${trainingModules.find((m) => m.id === moduleId)?.title} module.`,
      duration: 4000
    });
  };

  const startQuiz = () => {
    const randomQuestion = quizQuestions[Math.floor(Math.random() * quizQuestions.length)];
    setCurrentQuiz(randomQuestion);
  };

  const answerQuiz = (answerIndex: number) => {
    if (!currentQuiz) return;

    const isCorrect = answerIndex === currentQuiz.correctAnswer;
    if (isCorrect) {
      setQuizScore((prev) => prev + 1);
      toast.success('Correct!', { description: currentQuiz.explanation });
    } else {
      toast.error('Incorrect', {
        description: `${currentQuiz.explanation} The correct answer was: ${currentQuiz.options[currentQuiz.correctAnswer]}`
      });
    }

    setCurrentQuiz(null);
  };

  const triggerDemoError = async (demoId: string, errorType: string) => {
    try {
      // Simulate different types of errors for training
      switch (errorType) {
        case 'network':
          throw new Error('Failed to fetch data from server');
        case 'validation':
          throw new Error('Invalid input data provided');
        case 'critical':
          throw new Error('Critical system error occurred');
        default:
          throw new Error('Unknown error occurred');
      }
    } catch (error) {
      await logError(error, {
        component: 'ErrorHandlingTraining',
        action: `Demo-${errorType}`,
        severity: errorType === 'critical' ? 'critical' : 'medium',
        category: errorType === 'network' ? 'network' : 'client',
        additionalData: { demoId, trainingMode: true }
      });

      setDemoResults((prev) => ({ ...prev, [demoId]: true }));
      toast.success('Demo Error Logged', {
        description: `Successfully demonstrated ${errorType} error handling.`
      });
    }
  };

  const renderOverview = () =>
  <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center space-x-2">
            <Brain className="h-6 w-6 text-blue-500" />
            <CardTitle>Error Handling Training Center</CardTitle>
          </div>
          <CardDescription>
            Master comprehensive error handling with interactive lessons, quizzes, and hands-on demos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{Array.from(completedModules).length}</div>
              <div className="text-sm text-muted-foreground">Modules Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{quizScore}</div>
              <div className="text-sm text-muted-foreground">Quiz Score</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{Math.round(trainingProgress)}%</div>
              <div className="text-sm text-muted-foreground">Overall Progress</div>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Training Progress</span>
              <span>{Math.round(trainingProgress)}%</span>
            </div>
            <Progress value={trainingProgress} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5" />
              <span>Learning Objectives</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Implement comprehensive error boundaries</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Set up centralized error management</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Analyze error patterns and trends</span>
              </li>
              <li className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span>Optimize error handling performance</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>System Health</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <SystemHealthWidget />
          </CardContent>
        </Card>
      </div>
    </div>;


  const renderModules = () =>
  <div className="space-y-4">
      {trainingModules.map((module) =>
    <Card key={module.id} className={`transition-all ${completedModules.has(module.id) ? 'border-green-200 bg-green-50 dark:bg-green-950' : ''}`}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {completedModules.has(module.id) ?
            <CheckCircle2 className="h-6 w-6 text-green-500" /> :

            <Book className="h-6 w-6 text-blue-500" />
            }
                <div>
                  <CardTitle className="text-lg">{module.title}</CardTitle>
                  <CardDescription>{module.description}</CardDescription>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={
            module.difficulty === 'beginner' ? 'default' :
            module.difficulty === 'intermediate' ? 'secondary' : 'destructive'
            }>
                  {module.difficulty}
                </Badge>
                <Badge variant="outline">
                  <Clock className="h-3 w-3 mr-1" />
                  {module.duration}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2 mb-4">
              {module.topics.map((topic) =>
          <Badge key={topic} variant="outline" className="text-xs">
                  {topic}
                </Badge>
          )}
            </div>
            
            <div className="flex justify-between items-center">
              <div className="text-sm text-muted-foreground">
                {completedModules.has(module.id) ? 'Completed' : 'Not Started'}
              </div>
              <Button
            onClick={() => markModuleComplete(module.id)}
            disabled={completedModules.has(module.id)}
            size="sm">

                {completedModules.has(module.id) ? 'Completed' : 'Start Module'}
              </Button>
            </div>
          </CardContent>
        </Card>
    )}
    </div>;


  const renderQuiz = () =>
  <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-6 w-6 text-purple-500" />
            <span>Interactive Quiz</span>
          </CardTitle>
          <CardDescription>
            Test your knowledge with interactive quizzes
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-lg font-semibold">Current Score: {quizScore}</div>
              <div className="text-sm text-muted-foreground">Questions Answered Correctly</div>
            </div>
            <Button onClick={startQuiz} disabled={!!currentQuiz}>
              <PlayCircle className="h-4 w-4 mr-2" />
              {currentQuiz ? 'Quiz Active' : 'Start Quiz'}
            </Button>
          </div>

          {currentQuiz &&
        <Card>
              <CardHeader>
                <CardTitle className="text-lg">{currentQuiz.question}</CardTitle>
                <Badge variant="outline">{currentQuiz.category}</Badge>
              </CardHeader>
              <CardContent>
                <div className="grid gap-2">
                  {currentQuiz.options.map((option, index) =>
              <Button
                key={index}
                variant="outline"
                className="justify-start text-left h-auto p-3"
                onClick={() => answerQuiz(index)}>

                      <span className="font-mono mr-2">{String.fromCharCode(65 + index)})</span>
                      {option}
                    </Button>
              )}
                </div>
              </CardContent>
            </Card>
        }

          {!currentQuiz &&
        <Alert>
              <Lightbulb className="h-4 w-4" />
              <AlertTitle>Ready to Test Your Knowledge?</AlertTitle>
              <AlertDescription>
                Click "Start Quiz" to begin a random question from our training modules.
              </AlertDescription>
            </Alert>
        }
        </CardContent>
      </Card>
    </div>;


  const renderDemos = () =>
  <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Code2 className="h-6 w-6 text-orange-500" />
            <span>Interactive Demonstrations</span>
          </CardTitle>
          <CardDescription>
            Experience error handling in action with controlled demonstrations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {[
          { id: 'network', type: 'network', title: 'Network Error Demo', description: 'Simulate network connectivity issues' },
          { id: 'validation', type: 'validation', title: 'Validation Error Demo', description: 'Demonstrate form validation errors' },
          { id: 'critical', type: 'critical', title: 'Critical Error Demo', description: 'Show critical system error handling' }].
          map((demo) =>
          <Card key={demo.id}>
                <CardHeader>
                  <CardTitle className="text-lg">{demo.title}</CardTitle>
                  <CardDescription>{demo.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {demoResults[demo.id] &&
                  <Badge variant="default">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Completed
                        </Badge>
                  }
                    </div>
                    <Button
                  onClick={() => triggerDemoError(demo.id, demo.type)}
                  variant="outline">

                      <PlayCircle className="h-4 w-4 mr-2" />
                      Run Demo
                    </Button>
                  </div>
                </CardContent>
              </Card>
          )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Live Error Boundary Demo</CardTitle>
          <CardDescription>See error boundaries in action</CardDescription>
        </CardHeader>
        <CardContent>
          <UniversalErrorBoundary
          level="component"
          componentName="TrainingDemo"
          enableRetry={true}>

            <ErrorBoundaryDemoComponent />
          </UniversalErrorBoundary>
        </CardContent>
      </Card>
    </div>;


  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Error Handling Training Center</h1>
        <p className="text-muted-foreground">
          Comprehensive training program for mastering production-ready error handling
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="modules">Modules</TabsTrigger>
          <TabsTrigger value="quiz">Quiz</TabsTrigger>
          <TabsTrigger value="demos">Demos</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          {renderOverview()}
        </TabsContent>

        <TabsContent value="modules" className="mt-6">
          {renderModules()}
        </TabsContent>

        <TabsContent value="quiz" className="mt-6">
          {renderQuiz()}
        </TabsContent>

        <TabsContent value="demos" className="mt-6">
          {renderDemos()}
        </TabsContent>
      </Tabs>
    </div>);

};

// System Health Widget Component
const SystemHealthWidget: React.FC = () => {
  const [healthData, setHealthData] = useState({
    healthScore: 85,
    errorRate: 2,
    criticalIssues: 0,
    status: 'healthy' as 'healthy' | 'degraded' | 'critical'
  });

  useEffect(() => {
    // In a real implementation, this would fetch actual health data
    const updateHealthData = () => {
      try {
        const report = getLatestAnalysisReport();
        const clusters = getErrorClusters();

        setHealthData({
          healthScore: report.summary.overallHealthScore || 85,
          errorRate: report.summary.recentErrors || 2,
          criticalIssues: clusters.filter((c) => c.severity === 'critical').length,
          status: report.summary.overallHealthScore > 80 ? 'healthy' :
          report.summary.overallHealthScore > 50 ? 'degraded' : 'critical'
        });
      } catch (error) {
        console.warn('Failed to fetch health data:', error);
      }
    };

    updateHealthData();
    const interval = setInterval(updateHealthData, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">Health Score</span>
        <Badge variant={healthData.status === 'healthy' ? 'default' : 'destructive'}>
          {healthData.healthScore}%
        </Badge>
      </div>
      <Progress value={healthData.healthScore} className="h-2" />
      
      <div className="grid grid-cols-2 gap-4 pt-2 text-sm">
        <div>
          <div className="text-muted-foreground">Error Rate</div>
          <div className="font-medium">{healthData.errorRate}/min</div>
        </div>
        <div>
          <div className="text-muted-foreground">Critical Issues</div>
          <div className="font-medium">{healthData.criticalIssues}</div>
        </div>
      </div>
    </div>);

};

// Demo Component for Error Boundary Testing
const ErrorBoundaryDemoComponent: React.FC = () => {
  const [shouldError, setShouldError] = useState(false);

  if (shouldError) {
    throw new Error('Demo error triggered for training purposes');
  }

  return (
    <div className="p-4 border rounded-lg">
      <h4 className="font-medium mb-2">Error Boundary Test Component</h4>
      <p className="text-sm text-muted-foreground mb-4">
        Click the button below to trigger an error and see the error boundary in action.
      </p>
      <Button
        onClick={() => setShouldError(true)}
        variant="destructive"
        size="sm">

        <AlertTriangle className="h-4 w-4 mr-2" />
        Trigger Error
      </Button>
    </div>);

};

export default ErrorHandlingTrainingDashboard;