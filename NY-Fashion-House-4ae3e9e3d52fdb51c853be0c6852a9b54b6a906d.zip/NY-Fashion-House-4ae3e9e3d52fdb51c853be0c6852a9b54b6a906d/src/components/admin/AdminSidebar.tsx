
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Users,
  Shield,
  Settings,
  FileText,
  HardDrive,
  Database,
  Activity,
  X,
  Cog } from
'lucide-react';
import { Button } from '@/components/ui/button';

const navigation = [
{ name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
{ name: 'Users', href: '/admin/users', icon: Users },
{ name: 'Roles', href: '/admin/roles', icon: Shield },
{ name: 'System Settings', href: '/admin/settings', icon: Settings },
{ name: 'Audit Logs', href: '/admin/audit', icon: FileText },
{ name: 'Backups', href: '/admin/backups', icon: HardDrive },
{ name: 'Data Management', href: '/admin/data', icon: Database },
{ name: 'Settings', href: '/admin/settings', icon: Settings }];


interface AdminSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const AdminSidebar: React.FC<AdminSidebarProps> = ({ isOpen, onClose }) => {
  const location = useLocation();

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen &&
      <div
        className="fixed inset-0 bg-black/50 z-40 lg:hidden"
        onClick={onClose} />

      }

      {/* Sidebar */}
      <div className={cn(
        "fixed top-0 left-0 h-full w-64 bg-white border-r border-gray-200 z-50 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:z-auto",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-red-50 to-pink-50">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-gray-900">Admin Panel</h2>
              <p className="text-xs text-gray-500">System Control</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="lg:hidden h-8 w-8 rounded-full hover:bg-gray-100">

            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4">
          <div className="space-y-1 px-3">
            {navigation.map((item, index) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => window.innerWidth < 1024 && onClose()}
                  className={cn(
                    "group flex items-center rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200",
                    "hover:bg-gradient-to-r hover:from-red-50 hover:to-pink-50",
                    isActive ?
                    "bg-gradient-to-r from-red-500 to-pink-500 text-white shadow-md" :
                    "text-gray-700 hover:text-gray-900"
                  )}
                  style={{
                    animationDelay: `${index * 50}ms`
                  }}>

                  <item.icon
                    className={cn(
                      "mr-3 h-5 w-5 flex-shrink-0 transition-colors",
                      isActive ? "text-white" : "text-gray-500 group-hover:text-gray-700"
                    )} />

                  <span className="truncate">{item.name}</span>
                  {isActive &&
                  <div className="ml-auto w-2 h-2 bg-white rounded-full animate-pulse" />
                  }
                </Link>);

            })}
          </div>
        </nav>

        {/* System Status */}
        <div className="p-4 border-t bg-gray-50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-gray-500">System Status</span>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1" />
              <span className="text-xs text-green-600">Online</span>
            </div>
          </div>
          <div className="text-xs text-gray-400">
            <div>CPU: 45%</div>
            <div>Memory: 62%</div>
            <div className="flex items-center mt-1">
              <Activity className="h-3 w-3 mr-1" />
              <span>All systems operational</span>
            </div>
          </div>
        </div>
      </div>
    </>);

};

export default AdminSidebar;