
import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import AdminHeader from './AdminHeader';
import AdminSidebar from './AdminSidebar';

const AdminLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const closeSidebar = () => {
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen transition-colors duration-300" style={{ backgroundColor: 'var(--theme-background)' }}>
      <AdminSidebar isOpen={sidebarOpen} onClose={closeSidebar} />
      
      <div className="lg:pl-64">
        <AdminHeader onMenuToggle={toggleSidebar} />
        
        <main className="min-h-[calc(100vh-73px)]">
          <div className="p-4 sm:p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>);

};

export default AdminLayout;