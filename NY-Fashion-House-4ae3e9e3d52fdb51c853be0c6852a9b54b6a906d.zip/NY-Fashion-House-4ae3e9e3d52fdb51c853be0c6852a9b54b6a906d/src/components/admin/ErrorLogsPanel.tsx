import React, { useState, useEffect } from 'react';
import { AlertTriangle, RefreshCw, Download, Trash2, CheckCircle, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { errorLoggingService, ErrorLog, ErrorDetails } from '@/services/errorLoggingService';

const ErrorLogsPanel: React.FC = () => {
  const [errors, setErrors] = useState<ErrorLog[]>([]);
  const [filteredErrors, setFilteredErrors] = useState<ErrorLog[]>([]);
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [selectedRoute, setSelectedRoute] = useState<string>('all');

  useEffect(() => {
    loadErrors();
  }, []);

  useEffect(() => {
    filterErrors();
  }, [errors, selectedSeverity, selectedRoute]);

  const loadErrors = () => {
    const recentErrors = errorLoggingService.getRecentErrors(100);
    setErrors(recentErrors);
  };

  const filterErrors = () => {
    let filtered = [...errors];

    if (selectedSeverity !== 'all') {
      filtered = filtered.filter((error) =>
      error.errorDetails.severity === selectedSeverity
      );
    }

    if (selectedRoute !== 'all') {
      filtered = filtered.filter((error) =>
      error.errorDetails.route === selectedRoute
      );
    }

    setFilteredErrors(filtered);
  };

  const handleMarkResolved = (errorId: string) => {
    errorLoggingService.markErrorAsResolved(errorId);
    loadErrors();
  };

  const handleClearErrors = () => {
    errorLoggingService.clearErrors();
    loadErrors();
  };

  const handleExportErrors = () => {
    const exportData = errorLoggingService.exportErrors();
    const blob = new Blob([exportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `error-logs-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getSeverityColor = (severity: ErrorDetails['severity']) => {
    switch (severity) {
      case 'low':return 'bg-blue-100 text-blue-800';
      case 'medium':return 'bg-yellow-100 text-yellow-800';
      case 'high':return 'bg-orange-100 text-orange-800';
      case 'critical':return 'bg-red-100 text-red-800';
    }
  };

  const getUniqueRoutes = () => {
    const routes = [...new Set(errors.map((error) => error.errorDetails.route).filter(Boolean))];
    return routes;
  };

  const ErrorDetailsDialog: React.FC<{error: ErrorLog;}> = ({ error }) =>
  <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Eye className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Error Details</DialogTitle>
          <DialogDescription>ID: {error.id}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold">Severity</h4>
              <Badge className={getSeverityColor(error.errorDetails.severity)}>
                {error.errorDetails.severity}
              </Badge>
            </div>
            <div>
              <h4 className="font-semibold">Route</h4>
              <code className="text-sm">{error.errorDetails.route}</code>
            </div>
            <div>
              <h4 className="font-semibold">Timestamp</h4>
              <p className="text-sm">{new Date(error.errorDetails.timestamp).toLocaleString()}</p>
            </div>
            <div>
              <h4 className="font-semibold">Session ID</h4>
              <code className="text-xs">{error.errorDetails.sessionId}</code>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-2">Error Message</h4>
            <div className="p-3 bg-red-50 border rounded-md">
              <p className="text-red-800">{error.errorDetails.message}</p>
            </div>
          </div>

          {error.errorDetails.stack &&
        <div>
              <h4 className="font-semibold mb-2">Stack Trace</h4>
              <pre className="text-xs bg-gray-100 p-3 rounded-md overflow-x-auto">
                {error.errorDetails.stack}
              </pre>
            </div>
        }

          {error.errorDetails.componentStack &&
        <div>
              <h4 className="font-semibold mb-2">Component Stack</h4>
              <pre className="text-xs bg-gray-100 p-3 rounded-md overflow-x-auto">
                {error.errorDetails.componentStack}
              </pre>
            </div>
        }

          {error.errorDetails.context &&
        <div>
              <h4 className="font-semibold mb-2">Context</h4>
              <pre className="text-xs bg-gray-100 p-3 rounded-md overflow-x-auto">
                {JSON.stringify(error.errorDetails.context, null, 2)}
              </pre>
            </div>
        }

          <div>
            <h4 className="font-semibold mb-2">User Agent</h4>
            <p className="text-xs text-gray-600">{error.errorDetails.userAgent}</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>;


  const errorStats = {
    total: errors.length,
    critical: errors.filter((e) => e.errorDetails.severity === 'critical').length,
    high: errors.filter((e) => e.errorDetails.severity === 'high').length,
    resolved: errors.filter((e) => e.resolved).length
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Error Logs
              </CardTitle>
              <CardDescription>
                Monitor and manage application errors
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={loadErrors}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button variant="outline" size="sm" onClick={handleExportErrors}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="destructive" size="sm" onClick={handleClearErrors}>
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{errorStats.total}</div>
            <div className="text-sm text-gray-600">Total Errors</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-600">{errorStats.critical}</div>
            <div className="text-sm text-gray-600">Critical</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-600">{errorStats.high}</div>
            <div className="text-sm text-gray-600">High Severity</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">{errorStats.resolved}</div>
            <div className="text-sm text-gray-600">Resolved</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div>
              <label className="text-sm font-medium">Severity</label>
              <Select value={selectedSeverity} onValueChange={setSelectedSeverity}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Route</label>
              <Select value={selectedRoute} onValueChange={setSelectedRoute}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Routes</SelectItem>
                  {getUniqueRoutes().map((route) =>
                  <SelectItem key={route} value={route || ''}>{route || 'Unknown'}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Error List */}
      <Card>
        <CardContent className="p-0">
          <div className="divide-y">
            {filteredErrors.length === 0 ?
            <div className="p-8 text-center text-gray-500">
                No errors found matching the current filters.
              </div> :

            filteredErrors.map((error) =>
            <div key={error.id} className="p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getSeverityColor(error.errorDetails.severity)}>
                          {error.errorDetails.severity}
                        </Badge>
                        <code className="text-sm text-gray-600">{error.errorDetails.route}</code>
                        {error.resolved &&
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Resolved
                          </Badge>
                    }
                      </div>
                      <p className="text-sm font-medium text-gray-900 mb-1">
                        {error.errorDetails.message}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(error.errorDetails.timestamp).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <ErrorDetailsDialog error={error} />
                      {!error.resolved &&
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleMarkResolved(error.id)}>

                          <CheckCircle className="w-4 h-4" />
                        </Button>
                  }
                    </div>
                  </div>
                </div>
            )
            }
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default ErrorLogsPanel;