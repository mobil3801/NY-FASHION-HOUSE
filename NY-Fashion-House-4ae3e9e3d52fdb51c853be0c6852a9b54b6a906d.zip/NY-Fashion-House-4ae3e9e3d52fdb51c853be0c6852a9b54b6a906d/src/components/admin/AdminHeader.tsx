
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger } from
'@/components/ui/dropdown-menu';
import {
  Menu,
  Settings,
  User,
  LogOut,
  Shield,
  Bell,
  Search } from
'lucide-react';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface AdminHeaderProps {
  onMenuToggle: () => void;
}

interface UserInfo {
  ID: number;
  Name: string;
  Email: string;
  CreateTime: string;
  Roles: string;
}

const AdminHeader: React.FC<AdminHeaderProps> = ({ onMenuToggle }) => {
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const { data, error } = await window.ezsite.apis.getUserInfo();
        if (error) throw new Error(error);
        setUserInfo(data);
      } catch (error) {
        console.error('Error fetching user info:', error);
      }
    };

    fetchUserInfo();
  }, []);

  const handleLogout = async () => {
    try {
      const { error } = await window.ezsite.apis.logout();
      if (error) throw new Error(error);

      toast.success('Logged out successfully');
      navigate('/');
    } catch (error) {
      console.error('Error logging out:', error);
      toast.error('Error logging out');
    }
  };

  const getInitials = (name: string) => {
    return name.
    split(' ').
    map((n) => n[0]).
    join('').
    toUpperCase().
    slice(0, 2);
  };

  return (
    <header className="shadow-sm transition-colors duration-300" style={{
      backgroundColor: 'var(--theme-card)',
      borderBottom: '1px solid var(--theme-border)'
    }}>
      <div className="flex items-center justify-between px-4 py-3">
        {/* Left section */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onMenuToggle}
            className="lg:hidden">

            <Menu className="h-5 w-5" style={{ color: 'var(--theme-text)' }} />
          </Button>
          
          <div className="hidden sm:flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{
              background: 'linear-gradient(135deg, var(--theme-primary), var(--theme-secondary))'
            }}>
              <Shield className="h-4 w-4" style={{ color: 'var(--theme-background)' }} />
            </div>
            <div>
              <h1 className="text-lg font-bold" style={{ color: 'var(--theme-text)' }}>Admin Panel</h1>
              <p className="text-xs" style={{ color: 'var(--theme-muted-foreground)' }}>System Administration</p>
            </div>
          </div>
        </div>

        {/* Center section - Search */}
        <div className="hidden md:flex flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4" style={{ color: 'var(--theme-muted-foreground)' }} />
            <Input
              placeholder="Search admin panel..."
              className="pl-10 transition-colors duration-300"
              style={{
                backgroundColor: 'var(--theme-muted)',
                border: 'none',
                color: 'var(--theme-text)'
              }} />

          </div>
        </div>

        {/* Right section */}
        <div className="flex items-center space-x-3">
          {/* Notifications */}
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="h-5 w-5" style={{ color: 'var(--theme-text)' }} />
            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full text-xs text-white flex items-center justify-center" style={{
              backgroundColor: 'var(--theme-primary)'
            }}>
              3
            </span>
          </Button>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-2 transition-colors duration-300">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="text-white" style={{
                    background: 'linear-gradient(135deg, var(--theme-primary), var(--theme-secondary))'
                  }}>
                    {userInfo ? getInitials(userInfo.Name) : 'A'}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-medium" style={{ color: 'var(--theme-text)' }}>
                    {userInfo?.Name || 'Admin'}
                  </div>
                  <div className="text-xs" style={{ color: 'var(--theme-muted-foreground)' }}>Administrator</div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56" style={{
              backgroundColor: 'var(--theme-card)',
              border: '1px solid var(--theme-border)'
            }}>
              <DropdownMenuLabel>
                <div>
                  <div className="font-medium" style={{ color: 'var(--theme-text)' }}>{userInfo?.Name || 'Admin'}</div>
                  <div className="text-sm" style={{ color: 'var(--theme-muted-foreground)' }}>{userInfo?.Email}</div>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator style={{ borderColor: 'var(--theme-border)' }} />
              <DropdownMenuItem style={{ color: 'var(--theme-text)' }}>
                <User className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem style={{ color: 'var(--theme-text)' }}>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator style={{ borderColor: 'var(--theme-border)' }} />
              <DropdownMenuItem onClick={handleLogout} style={{ color: 'var(--theme-primary)' }}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>);

};

export default AdminHeader;