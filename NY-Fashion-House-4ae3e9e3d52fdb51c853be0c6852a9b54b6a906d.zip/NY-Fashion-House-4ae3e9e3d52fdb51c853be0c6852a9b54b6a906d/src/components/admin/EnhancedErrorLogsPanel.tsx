import React, { useState, useEffect } from 'react';
import { AlertTriangle, RefreshCw, Download, Trash2, Eye, Code, MapPin, Layers, Bug } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { enhancedDevToolsErrorService, EnhancedErrorReport } from '@/services/enhancedDevToolsErrorService';

const EnhancedErrorLogsPanel: React.FC = () => {
  const [errorReports, setErrorReports] = useState<EnhancedErrorReport[]>([]);
  const [filteredReports, setFilteredReports] = useState<EnhancedErrorReport[]>([]);
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showOnlyDevToolsEnhanced, setShowOnlyDevToolsEnhanced] = useState<boolean>(false);

  useEffect(() => {
    loadErrorReports();
  }, []);

  useEffect(() => {
    filterReports();
  }, [errorReports, selectedSeverity, selectedCategory, showOnlyDevToolsEnhanced]);

  const loadErrorReports = () => {
    const reports = enhancedDevToolsErrorService.getErrorReports();
    const persistedReports = enhancedDevToolsErrorService.getPersistedReports();
    const allReports = [...reports, ...persistedReports].slice(0, 100);
    setErrorReports(allReports);
  };

  const filterReports = () => {
    let filtered = [...errorReports];

    if (selectedSeverity !== 'all') {
      filtered = filtered.filter((report) => report.severity === selectedSeverity);
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((report) => report.category === selectedCategory);
    }

    if (showOnlyDevToolsEnhanced) {
      filtered = filtered.filter((report) =>
      report.devToolsDetails.parsedStack.length > 0 ||
      report.stackAnalysis.userCodeFrames.length > 0
      );
    }

    setFilteredReports(filtered);
  };

  const handleClearReports = () => {
    enhancedDevToolsErrorService.clearErrorReports();
    loadErrorReports();
  };

  const handleExportReports = () => {
    const exportData = enhancedDevToolsErrorService.exportErrorReports();
    const blob = new Blob([exportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `enhanced-error-reports-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getSeverityColor = (severity: EnhancedErrorReport['severity']) => {
    switch (severity) {
      case 'low':return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'medium':return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'high':return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'critical':return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
    }
  };

  const getUniqueCategories = () => {
    return [...new Set(errorReports.map((report) => report.category))];
  };

  const ErrorDetailsDialog: React.FC<{report: EnhancedErrorReport;}> = ({ report }) =>
  <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
          <Eye className="w-4 h-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Bug className="w-5 h-5" />
            Enhanced Error Details
          </DialogTitle>
          <DialogDescription>
            ID: {report.id} • {new Date(report.timestamp).toLocaleString()}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
              <TabsTrigger value="stack">Stack Trace</TabsTrigger>
              <TabsTrigger value="components">Components</TabsTrigger>
              <TabsTrigger value="context">Context</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Error Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Badge className={getSeverityColor(report.severity)}>
                        {report.severity}
                      </Badge>
                      <Badge variant="outline">{report.category}</Badge>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Message</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">{report.message}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Location</h4>
                      <code className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                        {report.errorLocation}
                      </code>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Analysis</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Root Cause</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">{report.rootCause}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Recoverable</h4>
                      <Badge variant={report.isRecoverable ? 'default' : 'destructive'}>
                        {report.isRecoverable ? 'Yes' : 'No'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    {report.recommendations.map((rec, index) =>
                  <li key={index} className="text-gray-700 dark:text-gray-300">{rec}</li>
                  )}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="location" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Error Location Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Primary Location</h4>
                    <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-md">
                      <code className="text-sm">{report.errorLocation}</code>
                    </div>
                  </div>

                  {report.devToolsDetails.sourceContext && report.devToolsDetails.sourceContext.length > 0 &&
                <div>
                      <h4 className="font-semibold mb-2">Source Context</h4>
                      {report.devToolsDetails.sourceContext.map((context, index) =>
                  <div key={index} className="mb-4">
                          <h5 className="text-sm font-medium mb-1">
                            {context.fileName.split('/').pop()}
                          </h5>
                          <div className="bg-gray-900 text-gray-100 p-3 rounded-md text-xs font-mono overflow-x-auto">
                            {context.contextLines.map((line, lineIndex) => {
                        const isErrorLine = line.startsWith(`${context.lineNumber}:`);
                        return (
                          <div key={lineIndex} className={isErrorLine ? 'bg-red-900 bg-opacity-50' : ''}>
                                  {isErrorLine ? '>>> ' : '    '}{line}
                                </div>);

                      })}
                          </div>
                        </div>
                  )}
                    </div>
                }
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stack" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <Code className="w-4 h-4" />
                    Enhanced Stack Trace
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    <AccordionItem value="user-code">
                      <AccordionTrigger>
                        User Code Frames ({report.stackAnalysis.userCodeFrames.length})
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {report.stackAnalysis.userCodeFrames.map((frame, index) =>
                        <div key={index} className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-md">
                              <div className="font-mono text-sm">
                                {frame.originalFrame.functionName &&
                            <div className="font-semibold text-blue-700 dark:text-blue-300">
                                    {frame.originalFrame.functionName}()
                                  </div>
                            }
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                  {frame.relativeFilePath}:{frame.originalFrame.lineNumber}:{frame.originalFrame.columnNumber}
                                </div>
                                {frame.componentName &&
                            <Badge variant="outline" className="mt-1">
                                    Component: {frame.componentName}
                                  </Badge>
                            }
                              </div>
                            </div>
                        )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="library-code">
                      <AccordionTrigger>
                        Library Code Frames ({report.stackAnalysis.libraryFrames.length})
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {report.stackAnalysis.libraryFrames.slice(0, 5).map((frame, index) =>
                        <div key={index} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
                              <div className="font-mono text-sm">
                                {frame.originalFrame.functionName &&
                            <div className="font-semibold">{frame.originalFrame.functionName}()</div>
                            }
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                  {frame.fileName.split('/').pop()}:{frame.originalFrame.lineNumber}
                                </div>
                              </div>
                            </div>
                        )}
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="raw-stack">
                      <AccordionTrigger>Raw Stack Trace</AccordionTrigger>
                      <AccordionContent>
                        <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded-md overflow-x-auto whitespace-pre-wrap">
                          {report.devToolsDetails.stack}
                        </pre>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="components" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="w-4 h-4" />
                    React Component Context
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {report.componentContext.length > 0 ?
                <div className="space-y-3">
                      <div>
                        <h4 className="font-semibold mb-2">Component Chain</h4>
                        <div className="flex flex-wrap gap-2">
                          {report.componentContext.map((component, index) =>
                      <div key={index} className="flex items-center">
                              <Badge variant="secondary">{component}</Badge>
                              {index < report.componentContext.length - 1 &&
                        <span className="mx-2 text-gray-400">→</span>
                        }
                            </div>
                      )}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2">Component Stack Details</h4>
                        <div className="space-y-2">
                          {report.stackAnalysis.reactComponentChain.map((frame, index) =>
                      <div key={index} className="p-3 bg-green-50 dark:bg-green-900/20 rounded-md">
                              <div className="font-semibold text-green-700 dark:text-green-300">
                                {frame.componentName}
                              </div>
                              <div className="text-xs text-gray-600 dark:text-gray-400">
                                {frame.relativeFilePath}:{frame.originalFrame.lineNumber}
                              </div>
                            </div>
                      )}
                        </div>
                      </div>

                      {report.devToolsDetails.componentStack &&
                  <div>
                          <h4 className="font-semibold mb-2">Raw Component Stack</h4>
                          <pre className="text-xs bg-gray-900 text-gray-100 p-3 rounded-md overflow-x-auto whitespace-pre-wrap">
                            {report.devToolsDetails.componentStack}
                          </pre>
                        </div>
                  }
                    </div> :

                <p className="text-gray-500 dark:text-gray-400">No React component information available</p>
                }
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="context" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Environment</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div>
                      <strong>URL:</strong> {report.context.url}
                    </div>
                    <div>
                      <strong>User Agent:</strong>
                      <div className="text-xs text-gray-600 dark:text-gray-400 mt-1 break-all">
                        {report.context.userAgent}
                      </div>
                    </div>
                    <div>
                      <strong>Session:</strong> {report.context.sessionId}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">DevTools Info</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div>
                      <strong>Enhanced Mode:</strong>{' '}
                      <Badge variant={report.devToolsDetails.devToolsInfo ? 'default' : 'secondary'}>
                        {report.devToolsDetails.devToolsInfo ? 'Enabled' : 'Fallback'}
                      </Badge>
                    </div>
                    {report.devToolsDetails.devToolsInfo &&
                  <>
                        <div>
                          <strong>Console Timestamp:</strong> {new Date(report.devToolsDetails.devToolsInfo.consoleTimestamp).toLocaleString()}
                        </div>
                        {report.devToolsDetails.devToolsInfo.scriptId &&
                    <div>
                            <strong>Script ID:</strong> {report.devToolsDetails.devToolsInfo.scriptId}
                          </div>
                    }
                      </>
                  }
                  </CardContent>
                </Card>
              </div>

              {report.context.additionalData &&
            <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Additional Data</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-3 rounded-md overflow-x-auto whitespace-pre-wrap">
                      {JSON.stringify(report.context.additionalData, null, 2)}
                    </pre>
                  </CardContent>
                </Card>
            }
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>;


  const statistics = enhancedDevToolsErrorService.getErrorStatistics();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Bug className="w-5 h-5" />
                Enhanced Error Logs
              </CardTitle>
              <CardDescription>
                DevTools-enhanced error monitoring with detailed stack traces and component context
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={loadErrorReports}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button variant="outline" size="sm" onClick={handleExportReports}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="destructive" size="sm" onClick={handleClearReports}>
                <Trash2 className="w-4 h-4 mr-2" />
                Clear All
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Enhanced Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{statistics.total}</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">Total Errors</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-600">{statistics.bySeverity.critical}</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">Critical</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-600">{statistics.bySeverity.high}</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">High Severity</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">
              {filteredReports.filter((r) => r.devToolsDetails.parsedStack.length > 0).length}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">DevTools Enhanced</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">{statistics.recentErrors}</div>
            <div className="text-sm text-gray-600 dark:text-gray-400">Recent (1h)</div>
          </CardContent>
        </Card>
      </div>

      {/* Enhanced Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="space-y-1">
              <label className="text-sm font-medium">Severity</label>
              <Select value={selectedSeverity} onValueChange={setSelectedSeverity}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium">Category</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  {getUniqueCategories().map((category) =>
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1 flex flex-col">
              <label className="text-sm font-medium">Filter</label>
              <Button
                variant={showOnlyDevToolsEnhanced ? "default" : "outline"}
                size="sm"
                onClick={() => setShowOnlyDevToolsEnhanced(!showOnlyDevToolsEnhanced)}>

                DevTools Enhanced Only
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Error Reports List */}
      <Card>
        <CardContent className="p-0">
          <div className="divide-y">
            {filteredReports.length === 0 ?
            <div className="p-8 text-center text-gray-500 dark:text-gray-400">
                No error reports found matching the current filters.
              </div> :

            filteredReports.map((report) =>
            <div key={report.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <Badge className={getSeverityColor(report.severity)}>
                          {report.severity}
                        </Badge>
                        <Badge variant="outline">{report.category}</Badge>
                        <code className="text-xs bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                          {report.errorLocation}
                        </code>
                        {report.componentContext.length > 0 &&
                    <Badge variant="secondary" className="text-xs">
                            <Layers className="w-3 h-3 mr-1" />
                            {report.componentContext[0]}
                          </Badge>
                    }
                        {report.devToolsDetails.parsedStack.length > 0 &&
                    <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                            DevTools Enhanced
                          </Badge>
                    }
                      </div>
                      
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-1 truncate">
                        {report.message}
                      </p>
                      
                      <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400">
                        <span>{new Date(report.timestamp).toLocaleString()}</span>
                        {report.stackAnalysis.userCodeFrames.length > 0 &&
                    <span>
                            {report.stackAnalysis.userCodeFrames.length} user code frame{report.stackAnalysis.userCodeFrames.length !== 1 ? 's' : ''}
                          </span>
                    }
                        {report.componentContext.length > 0 &&
                    <span>{report.componentContext.length} component{report.componentContext.length !== 1 ? 's' : ''}</span>
                    }
                      </div>
                    </div>
                    
                    <div className="flex-shrink-0">
                      <ErrorDetailsDialog report={report} />
                    </div>
                  </div>
                </div>
            )
            }
          </div>
        </CardContent>
      </Card>
    </div>);

};

export default EnhancedErrorLogsPanel;