
import React from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Printer, Download, X } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from '@/hooks/use-toast';

interface Transaction {
  id: number;
  product_id?: number;
  product_name?: string;
  quantity_sold?: number;
  unit_price?: number;
  total_amount: number;
  sale_date?: string;
  employee_id?: number;
  employee_name?: string;
  notes?: string;
}

interface Invoice {
  id: number;
  invoice_number: string;
  customer_id: string;
  customer_name: string;
  customer_phone: string;
  issue_date: string;
  due_date: string;
  subtotal: number;
  discount_amount: number;
  tax_amount: number;
  total_amount: number;
  status: string;
  paid_amount: number;
  remaining_amount: number;
  created_at: string;
  updated_at: string;
}

interface InvoiceReprintDialogProps {
  open: boolean;
  onClose: () => void;
  transaction?: Transaction | null;
  invoice?: Invoice | null;
}

const InvoiceReprintDialog: React.FC<InvoiceReprintDialogProps> = ({
  open,
  onClose,
  transaction,
  invoice
}) => {
  const data = invoice || transaction;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const handlePrint = () => {
    const printContent = document.getElementById('invoice-print-content');
    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Invoice Print</title>
              <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .invoice-header { text-align: center; margin-bottom: 30px; }
                .company-logo { max-width: 150px; margin-bottom: 20px; }
                .invoice-details { margin-bottom: 30px; }
                .invoice-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                .invoice-table th, .invoice-table td { border: 1px solid #ddd; padding: 12px; text-align: left; }
                .invoice-table th { background-color: #f5f5f5; }
                .total-section { margin-top: 20px; text-align: right; }
                .total-amount { font-size: 18px; font-weight: bold; }
                @media print {
                  body { margin: 0; }
                  .no-print { display: none !important; }
                }
              </style>
            </head>
            <body>
              ${printContent.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
        printWindow.close();
      }
    }
    toast({ title: "Invoice sent to printer" });
    onClose();
  };

  const handleDownloadPDF = () => {
    // In a real implementation, you would generate a PDF here
    toast({ title: "PDF download feature coming soon" });
  };

  if (!data) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Invoice Preview
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
          <DialogDescription>
            Review and print the invoice for this {invoice ? 'invoice' : 'transaction'}
          </DialogDescription>
        </DialogHeader>

        <div id="invoice-print-content" className="space-y-6">
          {/* Company Header */}
          <div className="invoice-header text-center border-b pb-6">
            <img
              src="https://cdn.ezsite.ai/AutoDev/19016/95c2a8a3-4455-4cc1-91c1-442a3cf63926.jpeg"
              alt="Company Logo"
              className="company-logo mx-auto h-16 w-auto mb-4" />

            <h1 className="text-2xl font-bold">NY FASHION HOUSE</h1>
            <p className="text-muted-foreground">Fashion & Style Solutions</p>
          </div>

          {/* Invoice Details */}
          <div className="invoice-details grid grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-3">Invoice Information</h3>
              <div className="space-y-2">
                <p><strong>Invoice #:</strong> {invoice?.invoice_number || `TXN-${data.id}`}</p>
                <p><strong>Date:</strong> {
                  invoice?.issue_date ?
                  format(new Date(invoice.issue_date), 'MMM dd, yyyy') :
                  transaction?.sale_date ?
                  format(new Date(transaction.sale_date), 'MMM dd, yyyy') :
                  'N/A'
                  }</p>
                {invoice?.due_date &&
                <p><strong>Due Date:</strong> {format(new Date(invoice.due_date), 'MMM dd, yyyy')}</p>
                }
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-3">Customer Information</h3>
              <div className="space-y-2">
                <p><strong>Name:</strong> {invoice?.customer_name || 'Walk-in Customer'}</p>
                {invoice?.customer_phone &&
                <p><strong>Phone:</strong> {invoice.customer_phone}</p>
                }
                {transaction?.employee_name &&
                <p><strong>Served by:</strong> {transaction.employee_name}</p>
                }
              </div>
            </div>
          </div>

          {/* Items Table */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Items</h3>
            <table className="invoice-table w-full">
              <thead>
                <tr>
                  <th>Item Description</th>
                  <th>Quantity</th>
                  <th>Unit Price</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{transaction?.product_name || 'Invoice Item'}</td>
                  <td>{transaction?.quantity_sold || 1}</td>
                  <td>{formatCurrency(transaction?.unit_price || data.total_amount)}</td>
                  <td>{formatCurrency(data.total_amount)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="total-section">
            <div className="space-y-2 text-right">
              {invoice &&
              <>
                  <div className="flex justify-end">
                    <span className="w-32">Subtotal:</span>
                    <span className="w-24">{formatCurrency(invoice.subtotal)}</span>
                  </div>
                  {invoice.discount_amount > 0 &&
                <div className="flex justify-end">
                      <span className="w-32">Discount:</span>
                      <span className="w-24">-{formatCurrency(invoice.discount_amount)}</span>
                    </div>
                }
                  {invoice.tax_amount > 0 &&
                <div className="flex justify-end">
                      <span className="w-32">Tax:</span>
                      <span className="w-24">{formatCurrency(invoice.tax_amount)}</span>
                    </div>
                }
                </>
              }
              <Separator />
              <div className="flex justify-end total-amount">
                <span className="w-32">Total:</span>
                <span className="w-24">{formatCurrency(data.total_amount)}</span>
              </div>
              {invoice &&
              <>
                  <div className="flex justify-end">
                    <span className="w-32">Paid:</span>
                    <span className="w-24 text-green-600">{formatCurrency(invoice.paid_amount)}</span>
                  </div>
                  <div className="flex justify-end">
                    <span className="w-32">Remaining:</span>
                    <span className="w-24 text-red-600">{formatCurrency(invoice.remaining_amount)}</span>
                  </div>
                </>
              }
            </div>
          </div>

          {/* Notes */}
          {(transaction?.notes || invoice) &&
          <div>
              <h3 className="text-lg font-semibold mb-3">Notes</h3>
              <p className="text-sm text-muted-foreground">
                {transaction?.notes || 'Thank you for your business!'}
              </p>
            </div>
          }

          {/* Footer */}
          <div className="text-center text-sm text-muted-foreground border-t pt-4">
            <p>Thank you for choosing NY Fashion House!</p>
            <p>For questions about this invoice, please contact us.</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 mt-6 border-t pt-4 no-print">
          <Button variant="outline" onClick={handleDownloadPDF} className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download PDF
          </Button>
          <Button onClick={handlePrint} className="flex items-center gap-2">
            <Printer className="h-4 w-4" />
            Print Invoice
          </Button>
        </div>
      </DialogContent>
    </Dialog>);

};

export default InvoiceReprintDialog;