
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, RotateCcw, X } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface Transaction {
  id: number;
  product_id?: number;
  product_name?: string;
  quantity_sold?: number;
  unit_price?: number;
  total_amount: number;
  sale_date?: string;
  employee_id?: number;
  employee_name?: string;
  notes?: string;
}

interface ReturnAdjustmentDialogProps {
  open: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  onSuccess: () => void;
}

const ReturnAdjustmentDialog: React.FC<ReturnAdjustmentDialogProps> = ({
  open,
  onClose,
  transaction,
  onSuccess
}) => {
  const [returnQuantity, setReturnQuantity] = useState<number>(1);
  const [returnReason, setReturnReason] = useState<string>('');
  const [customReason, setCustomReason] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const calculateRefundAmount = () => {
    if (!transaction || !transaction.unit_price) return 0;
    return returnQuantity * transaction.unit_price;
  };

  const handleReturn = async () => {
    if (!transaction) return;

    if (returnQuantity <= 0 || transaction.quantity_sold && returnQuantity > transaction.quantity_sold) {
      toast({
        title: "Invalid quantity",
        description: "Please enter a valid return quantity",
        variant: "destructive"
      });
      return;
    }

    if (!returnReason) {
      toast({
        title: "Reason required",
        description: "Please select a reason for the return",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Create return adjustment transaction
      const returnData = {
        original_transaction_id: transaction.id,
        product_id: transaction.product_id || 0,
        product_name: transaction.product_name || '',
        quantity_returned: returnQuantity,
        unit_price: transaction.unit_price || 0,
        total_refund: calculateRefundAmount(),
        return_reason: returnReason === 'other' ? customReason : returnReason,
        return_date: new Date().toISOString(),
        processed_by: 'current_employee', // In real app, get from auth context
        status: 'completed',
        notes: `Return processed for transaction #${transaction.id}`
      };

      // In a real implementation, you would save this to a returns table
      const { error } = await window.ezsite.apis.tableCreate(38156, { // sales_transactions table
        ...returnData,
        total_amount: -calculateRefundAmount(), // Negative amount for return
        sale_date: new Date().toISOString(),
        employee_name: 'Return Processing',
        notes: returnData.notes
      });

      if (error) throw new Error(error);

      // Create adjustment invoice
      const adjustmentInvoice = {
        invoice_number: `ADJ-${Date.now()}`,
        customer_name: 'Return Customer',
        customer_phone: '',
        issue_date: new Date().toISOString(),
        due_date: new Date().toISOString(),
        subtotal: -calculateRefundAmount(),
        discount_amount: 0,
        tax_amount: 0,
        total_amount: -calculateRefundAmount(),
        status: 'paid',
        paid_amount: -calculateRefundAmount(),
        remaining_amount: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const { error: invoiceError } = await window.ezsite.apis.tableCreate(38565, adjustmentInvoice); // invoices table

      if (invoiceError) {
        console.warn('Failed to create adjustment invoice:', invoiceError);
      }

      toast({
        title: "Return processed successfully",
        description: `Refund of ${formatCurrency(calculateRefundAmount())} has been processed`
      });

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Return processing failed:', error);
      toast({
        title: "Return processing failed",
        description: "Please try again or contact support",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const resetForm = () => {
    setReturnQuantity(1);
    setReturnReason('');
    setCustomReason('');
  };

  React.useEffect(() => {
    if (open && transaction) {
      resetForm();
      setReturnQuantity(transaction.quantity_sold || 1);
    }
  }, [open, transaction]);

  if (!transaction) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RotateCcw className="h-5 w-5" />
            Process Return/Adjustment
          </DialogTitle>
          <DialogDescription>
            Create a return adjustment for this transaction and generate a refund.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Original Transaction Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Original Transaction</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Transaction ID</Label>
                  <p className="text-sm text-muted-foreground">{transaction.id}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Date</Label>
                  <p className="text-sm text-muted-foreground">
                    {transaction.sale_date ?
                    format(new Date(transaction.sale_date), 'MMM dd, yyyy HH:mm') :
                    'N/A'
                    }
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium">Product</Label>
                  <p className="text-sm text-muted-foreground">{transaction.product_name || 'N/A'}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Employee</Label>
                  <p className="text-sm text-muted-foreground">{transaction.employee_name || 'N/A'}</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium">Original Quantity</Label>
                  <p className="text-sm text-muted-foreground">{transaction.quantity_sold || 0}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Unit Price</Label>
                  <p className="text-sm text-muted-foreground">
                    {formatCurrency(transaction.unit_price || 0)}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Original Total</Label>
                  <p className="text-sm text-muted-foreground font-medium">
                    {formatCurrency(transaction.total_amount)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Return Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Return Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="returnQuantity">Return Quantity</Label>
                  <Input
                    id="returnQuantity"
                    type="number"
                    min="1"
                    max={transaction.quantity_sold || 1}
                    value={returnQuantity}
                    onChange={(e) => setReturnQuantity(parseInt(e.target.value) || 1)} />

                  <p className="text-xs text-muted-foreground">
                    Maximum: {transaction.quantity_sold || 1} units
                  </p>
                </div>
                <div className="space-y-2">
                  <Label>Calculated Refund</Label>
                  <div className="p-3 border rounded-md bg-green-50">
                    <p className="text-lg font-semibold text-green-700">
                      {formatCurrency(calculateRefundAmount())}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="returnReason">Return Reason</Label>
                <Select value={returnReason} onValueChange={setReturnReason}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a reason for return" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="defective">Defective Product</SelectItem>
                    <SelectItem value="wrong_item">Wrong Item Received</SelectItem>
                    <SelectItem value="not_as_described">Not as Described</SelectItem>
                    <SelectItem value="customer_changed_mind">Customer Changed Mind</SelectItem>
                    <SelectItem value="size_issue">Size Issue</SelectItem>
                    <SelectItem value="damaged_in_transit">Damaged in Transit</SelectItem>
                    <SelectItem value="other">Other (specify below)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {returnReason === 'other' &&
              <div className="space-y-2">
                  <Label htmlFor="customReason">Custom Reason</Label>
                  <Textarea
                  id="customReason"
                  placeholder="Please specify the reason for return..."
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  rows={3} />

                </div>
              }
            </CardContent>
          </Card>

          {/* Warning */}
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              This action will create a negative transaction record and generate a refund invoice. 
              Make sure all details are correct before proceeding.
            </AlertDescription>
          </Alert>

          {/* Summary */}
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="pt-6">
              <div className="flex justify-between items-center">
                <span className="font-medium">Total Refund Amount:</span>
                <Badge variant="outline" className="text-lg px-3 py-1">
                  {formatCurrency(calculateRefundAmount())}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-6 border-t">
          <Button variant="outline" onClick={onClose} disabled={isProcessing}>
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleReturn} disabled={isProcessing || !returnReason}>
            {isProcessing ?
            <>Processing...</> :

            <>
                <RotateCcw className="h-4 w-4 mr-2" />
                Process Return
              </>
            }
          </Button>
        </div>
      </DialogContent>
    </Dialog>);

};

export default ReturnAdjustmentDialog;