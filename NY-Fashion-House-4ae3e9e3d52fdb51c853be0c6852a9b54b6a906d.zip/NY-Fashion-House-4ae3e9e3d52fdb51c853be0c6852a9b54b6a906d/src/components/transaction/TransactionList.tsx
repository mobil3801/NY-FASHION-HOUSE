import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Printer, RotateCcw, Calendar, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface Transaction {
  id: number;
  product_id?: number;
  product_name?: string;
  quantity_sold?: number;
  unit_price?: number;
  total_amount: number;
  sale_date?: string;
  employee_id?: number;
  employee_name?: string;
  notes?: string;
  // Invoice fields
  invoice_number?: string;
  customer_id?: string;
  customer_name?: string;
  customer_phone?: string;
  issue_date?: string;
  due_date?: string;
  status?: string;
  paid_amount?: number;
  remaining_amount?: number;
}

interface TransactionListProps {
  transactions: Transaction[];
  onPrint: (transaction: Transaction) => void;
  onReturn: (transaction: Transaction) => void;
  onDelete?: (transaction: Transaction) => void;
  isInvoiceView?: boolean;
}

const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  onPrint,
  onReturn,
  onDelete,
  isInvoiceView = false
}) => {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<Transaction | null>(null);

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'sent':
        return 'bg-blue-100 text-blue-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'MMM dd, yyyy');
    } catch {
      return 'Invalid Date';
    }
  };

  const formatDateTime = (dateString?: string) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'MMM dd, yyyy HH:mm');
    } catch {
      return 'Invalid Date';
    }
  };

  const handleDeleteClick = (transaction: Transaction) => {
    if (!onDelete) return;
    setTransactionToDelete(transaction);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!transactionToDelete || !onDelete) return;

    try {
      // Call the delete function passed from parent
      await onDelete(transactionToDelete);
      toast({
        title: "Success",
        description: `${isInvoiceView ? 'Invoice' : 'Transaction'} deleted successfully`
      });
    } catch (error) {
      console.error('Error deleting transaction:', error);
      toast({
        title: "Error",
        description: `Failed to delete ${isInvoiceView ? 'invoice' : 'transaction'}. Please try again.`,
        variant: "destructive"
      });
    } finally {
      setDeleteDialogOpen(false);
      setTransactionToDelete(null);
    }
  };

  const cancelDelete = () => {
    setDeleteDialogOpen(false);
    setTransactionToDelete(null);
  };

  if (transactions.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-16">
          <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No {isInvoiceView ? 'invoices' : 'transactions'} found</h3>
          <p className="text-muted-foreground text-center">
            Try adjusting your search criteria or date range to find what you're looking for.
          </p>
        </CardContent>
      </Card>);

  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>
            {isInvoiceView ? 'Invoice Records' : 'Sales Transactions'}
          </CardTitle>
          <CardDescription>
            {isInvoiceView ?
            `${transactions.length} invoices found` :
            `${transactions.length} transactions found`
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  {isInvoiceView ?
                  <>
                      <TableHead>Invoice #</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Issue Date</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Paid</TableHead>
                      <TableHead>Remaining</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </> :
                  <>
                      <TableHead>Date</TableHead>
                      <TableHead>Product</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Unit Price</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Employee</TableHead>
                      <TableHead>Notes</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </>
                  }
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) =>
                <TableRow key={transaction.id} className="hover:bg-muted/50">
                    {isInvoiceView ?
                  <>
                        <TableCell className="font-medium">
                          {transaction.invoice_number || `TXN-${transaction.id}`}
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{transaction.customer_name || 'Walk-in Customer'}</div>
                            {transaction.customer_phone &&
                        <div className="text-sm text-muted-foreground">
                                {transaction.customer_phone}
                              </div>
                        }
                          </div>
                        </TableCell>
                        <TableCell>{formatDate(transaction.issue_date)}</TableCell>
                        <TableCell>{formatDate(transaction.due_date)}</TableCell>
                        <TableCell className="font-medium">
                          {formatCurrency(transaction.total_amount)}
                        </TableCell>
                        <TableCell className="text-green-600">
                          {formatCurrency(transaction.paid_amount || 0)}
                        </TableCell>
                        <TableCell className="text-red-600">
                          {formatCurrency(transaction.remaining_amount || 0)}
                        </TableCell>
                        <TableCell>
                          <Badge
                        variant="secondary"
                        className={cn("capitalize", getStatusColor(transaction.status))}>
                            {transaction.status || 'Unknown'}
                          </Badge>
                        </TableCell>
                      </> :
                  <>
                        <TableCell>{formatDateTime(transaction.sale_date)}</TableCell>
                        <TableCell className="font-medium">
                          {transaction.product_name || 'N/A'}
                        </TableCell>
                        <TableCell>{transaction.quantity_sold || 0}</TableCell>
                        <TableCell>{formatCurrency(transaction.unit_price || 0)}</TableCell>
                        <TableCell className="font-medium">
                          {formatCurrency(transaction.total_amount)}
                        </TableCell>
                        <TableCell>{transaction.employee_name || 'N/A'}</TableCell>
                        <TableCell className="max-w-xs truncate">
                          {transaction.notes || 'No notes'}
                        </TableCell>
                      </>
                  }
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onPrint(transaction)}
                        className="flex items-center gap-1">
                          <Printer className="h-3 w-3" />
                          Print
                        </Button>
                        {!isInvoiceView &&
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onReturn(transaction)}
                        className="flex items-center gap-1">
                            <RotateCcw className="h-3 w-3" />
                            Return
                          </Button>
                      }
                        {onDelete &&
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteClick(transaction)}
                        className="flex items-center gap-1 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700">
                            <Trash2 className="h-3 w-3" />
                            Delete
                          </Button>
                      }
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {isInvoiceView ? 'Invoice' : 'Transaction'}</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {isInvoiceView ? 'invoice' : 'transaction'} {transactionToDelete?.invoice_number || `#${transactionToDelete?.id}`}?
              This action cannot be undone and will permanently remove the {isInvoiceView ? 'invoice' : 'transaction'} and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelDelete}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700">
              Delete {isInvoiceView ? 'Invoice' : 'Transaction'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>);

};

export default TransactionList;