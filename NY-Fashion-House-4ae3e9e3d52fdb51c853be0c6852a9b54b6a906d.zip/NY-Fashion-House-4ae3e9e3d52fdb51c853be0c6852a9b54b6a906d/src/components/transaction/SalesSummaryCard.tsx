
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SalesSummaryCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  trend: number;
  isCount?: boolean;
}

const SalesSummaryCard: React.FC<SalesSummaryCardProps> = ({
  title,
  value,
  icon,
  trend,
  isCount = false
}) => {
  const formatValue = (val: number) => {
    if (isCount) {
      return val.toLocaleString();
    }
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(val);
  };

  const getTrendIcon = () => {
    if (trend > 0) return <TrendingUp className="h-3 w-3" />;
    if (trend < 0) return <TrendingDown className="h-3 w-3" />;
    return <Minus className="h-3 w-3" />;
  };

  const getTrendColor = () => {
    if (trend > 0) return 'text-green-600 bg-green-50';
    if (trend < 0) return 'text-red-600 bg-red-50';
    return 'text-gray-600 bg-gray-50';
  };

  return (
    <Card className="relative overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">
              {title}
            </p>
            <p className="text-2xl font-bold">
              {formatValue(value)}
            </p>
            <div className="flex items-center space-x-1">
              <Badge
                variant="secondary"
                className={cn("flex items-center gap-1 text-xs", getTrendColor())}>

                {getTrendIcon()}
                {Math.abs(trend)}%
              </Badge>
              <span className="text-xs text-muted-foreground">
                vs last period
              </span>
            </div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>);

};

export default SalesSummaryCard;