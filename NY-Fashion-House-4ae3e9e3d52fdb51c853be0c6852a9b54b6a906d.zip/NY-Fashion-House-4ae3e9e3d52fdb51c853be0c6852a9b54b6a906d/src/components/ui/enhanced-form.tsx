import React, { ReactNode } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Save, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import FormErrorDisplay from './form-error-display';
import ValidationSummary from './validation-summary';

interface EnhancedFormProps {
  title?: string;
  description?: string;
  onSubmit: (e: React.FormEvent) => void | Promise<void>;
  onCancel?: () => void;
  submitText?: string;
  cancelText?: string;
  isLoading?: boolean;
  isSubmitting?: boolean;
  isValid?: boolean;
  error?: string | Error | null;
  errors?: Record<string, string>;
  touched?: Record<string, boolean>;
  children: ReactNode;
  className?: string;
  showValidationSummary?: boolean;
  disabled?: boolean;
  variant?: 'card' | 'plain';
}

const EnhancedForm: React.FC<EnhancedFormProps> = ({
  title,
  description,
  onSubmit,
  onCancel,
  submitText = "Submit",
  cancelText = "Cancel",
  isLoading = false,
  isSubmitting = false,
  isValid = true,
  error,
  errors = {},
  touched = {},
  children,
  className,
  showValidationSummary = false,
  disabled = false,
  variant = 'card'
}) => {
  const hasErrors = Object.keys(errors).length > 0;
  const isProcessing = isLoading || isSubmitting;

  const FormContent = () => (
    <div className="space-y-6">
      {/* Error Display */}
      {error && (
        <FormErrorDisplay
          error={error}
          variant="inline"
        />
      )}

      {/* Validation Summary */}
      {showValidationSummary && (
        <ValidationSummary
          errors={errors}
          touched={touched}
          showSuccessWhenValid={true}
        />
      )}

      {/* Form Fields */}
      <form onSubmit={onSubmit} className="space-y-4">
        {children}

        {/* Form Actions */}
        <div className="flex flex-col-reverse sm:flex-row gap-3 justify-end pt-4 border-t">
          {onCancel && (
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={isProcessing || disabled}
              className="h-11"
            >
              <X className="h-4 w-4 mr-2" />
              {cancelText}
            </Button>
          )}
          
          <Button
            type="submit"
            disabled={isProcessing || disabled || (!isValid && hasErrors)}
            className="h-11"
          >
            {isProcessing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                {submitText}
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );

  if (variant === 'plain') {
    return (
      <div className={className}>
        <FormContent />
      </div>
    );
  }

  return (
    <Card className={className}>
      {(title || description) && (
        <CardHeader>
          {title && <CardTitle>{title}</CardTitle>}
          {description && <CardDescription>{description}</CardDescription>}
        </CardHeader>
      )}
      <CardContent>
        <FormContent />
      </CardContent>
    </Card>
  );
};

export { EnhancedForm };
export default EnhancedForm;
