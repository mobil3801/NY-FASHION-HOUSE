import React from 'react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

interface AvatarWithFallbackProps {
  src?: string;
  alt?: string;
  fallback?: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const AvatarWithFallback = ({ 
  src, 
  alt = "User Avatar", 
  fallback = "U", 
  className,
  size = 'md' 
}: AvatarWithFallbackProps) => {
  const sizeClasses = {
    sm: 'h-5 w-5 sm:h-6 sm:w-6',
    md: 'h-8 w-8 sm:h-10 sm:w-10',
    lg: 'h-12 w-12 sm:h-16 sm:w-16'
  };

  // Generate fallback initials from alt text or use provided fallback
  const getInitials = (text: string) => {
    return text
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const initials = fallback === "U" && alt !== "User Avatar" ? getInitials(alt) : fallback;

  return (
    <Avatar className={cn(sizeClasses[size], className)}>
      {src && (
        <AvatarImage 
          src={src} 
          alt={alt}
          onError={(e) => {
            // Hide broken image and let fallback show
            e.currentTarget.style.display = 'none';
          }}
        />
      )}
      <AvatarFallback
        className="text-xs font-medium"
        style={{
          backgroundColor: 'var(--theme-primary)',
          color: 'var(--theme-background)'
        }}
      >
        {initials}
      </AvatarFallback>
    </Avatar>
  );
};

export default AvatarWithFallback;