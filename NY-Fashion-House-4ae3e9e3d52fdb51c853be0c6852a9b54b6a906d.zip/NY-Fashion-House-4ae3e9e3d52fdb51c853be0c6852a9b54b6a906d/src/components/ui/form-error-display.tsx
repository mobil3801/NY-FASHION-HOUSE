import React from 'react';
import { AlertTriangle, X, RefreshCw } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface FormErrorDisplayProps {
  error?: string | Error | null;
  errors?: Record<string, string>;
  touched?: Record<string, boolean>;
  title?: string;
  showRetry?: boolean;
  onRetry?: () => void;
  onDismiss?: () => void;
  className?: string;
  variant?: 'inline' | 'card' | 'alert';
}

const FormErrorDisplay: React.FC<FormErrorDisplayProps> = ({
  error,
  errors = {},
  touched = {},
  title = "Form Error",
  showRetry = false,
  onRetry,
  onDismiss,
  className,
  variant = 'alert'
}) => {
  const errorMessage = typeof error === 'string' ? error : error?.message;
  const touchedErrors = Object.entries(errors).filter(([key]) => touched[key]);
  const hasFieldErrors = touchedErrors.length > 0;
  const hasGeneralError = !!errorMessage;
  const hasAnyError = hasFieldErrors || hasGeneralError;

  if (!hasAnyError) return null;

  const ErrorContent = () => (
    <div className="space-y-3">
      {hasGeneralError && (
        <div className="flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm text-red-800 font-medium">{errorMessage}</p>
          </div>
          {onDismiss && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onDismiss}
              className="h-auto p-1 text-red-600 hover:text-red-800"
            >
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
      )}

      {hasFieldErrors && (
        <div>
          <h4 className="text-sm font-medium text-red-800 mb-2">
            Field Errors ({touchedErrors.length})
          </h4>
          <ul className="space-y-1">
            {touchedErrors.map(([field, fieldError]) => (
              <li key={field} className="text-sm text-red-700 flex items-start gap-1">
                <span className="inline-block w-1 h-1 bg-red-600 rounded-full mt-2 flex-shrink-0" />
                <span>
                  <strong className="capitalize">
                    {field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}:
                  </strong>{' '}
                  {fieldError}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {showRetry && onRetry && (
        <div className="flex justify-end pt-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onRetry}
            className="text-red-600 border-red-300 hover:bg-red-50"
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Retry
          </Button>
        </div>
      )}
    </div>
  );

  if (variant === 'card') {
    return (
      <Card className={cn("border-red-500 bg-red-50", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="text-red-800 text-lg flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <ErrorContent />
        </CardContent>
      </Card>
    );
  }

  if (variant === 'inline') {
    return (
      <div className={cn("p-3 bg-red-50 border border-red-200 rounded-md", className)}>
        <ErrorContent />
      </div>
    );
  }

  return (
    <Alert variant="destructive" className={className}>
      <AlertDescription>
        <ErrorContent />
      </AlertDescription>
    </Alert>
  );
};

export { FormErrorDisplay };
export default FormErrorDisplay;
