import React, { forwardRef } from 'react';
import { Textarea, TextareaProps } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

interface FormTextareaProps extends TextareaProps {
  label?: string;
  error?: string;
  touched?: boolean;
  required?: boolean;
  helperText?: string;
  containerClassName?: string;
  maxLength?: number;
  showCharCount?: boolean;
}

const FormTextarea = forwardRef<HTMLTextAreaElement, FormTextareaProps>(
  ({ 
    label, 
    error, 
    touched, 
    required, 
    helperText, 
    containerClassName,
    className,
    id,
    maxLength,
    showCharCount,
    value,
    ...props 
  }, ref) => {
    const hasError = touched && error;
    const inputId = id || label?.toLowerCase().replace(/\s+/g, '-');
    const currentLength = value?.toString().length || 0;

    return (
      <div className={cn("space-y-2", containerClassName)}>
        {label && (
          <Label 
            htmlFor={inputId} 
            className={cn(
              "text-sm font-medium",
              hasError && "text-red-600"
            )}
          >
            {label}
            {required && <span className="text-red-500 ml-1">*</span>}
          </Label>
        )}
        
        <Textarea
          ref={ref}
          id={inputId}
          className={cn(
            "resize-none",
            hasError && "border-red-500 focus:border-red-500 focus:ring-red-500",
            className
          )}
          maxLength={maxLength}
          value={value}
          {...props}
        />
        
        <div className="flex justify-between items-start">
          <div className="flex-1">
            {hasError && (
              <p className="text-sm text-red-600">
                {error}
              </p>
            )}
            
            {helperText && !hasError && (
              <p className="text-sm text-gray-500">
                {helperText}
              </p>
            )}
          </div>
          
          {showCharCount && maxLength && (
            <p className={cn(
              "text-xs ml-2 flex-shrink-0",
              currentLength > maxLength * 0.9 ? "text-orange-600" : "text-gray-400",
              currentLength >= maxLength && "text-red-600"
            )}>
              {currentLength}/{maxLength}
            </p>
          )}
        </div>
      </div>
    );
  }
);

FormTextarea.displayName = "FormTextarea";

export { FormTextarea };
export default FormTextarea;
