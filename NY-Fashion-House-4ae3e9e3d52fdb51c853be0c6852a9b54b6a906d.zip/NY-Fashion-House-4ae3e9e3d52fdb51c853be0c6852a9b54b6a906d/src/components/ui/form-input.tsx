import React, { forwardRef } from 'react';
import { Input, InputProps } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

interface FormInputProps extends InputProps {
  label?: string;
  error?: string;
  touched?: boolean;
  required?: boolean;
  helperText?: string;
  containerClassName?: string;
}

const FormInput = forwardRef<HTMLInputElement, FormInputProps>(
  ({ 
    label, 
    error, 
    touched, 
    required, 
    helperText, 
    containerClassName,
    className,
    id,
    ...props 
  }, ref) => {
    const hasError = touched && error;
    const inputId = id || label?.toLowerCase().replace(/\s+/g, '-');

    return (
      <div className={cn("space-y-2", containerClassName)}>
        {label && (
          <Label 
            htmlFor={inputId} 
            className={cn(
              "text-sm font-medium",
              hasError && "text-red-600"
            )}
          >
            {label}
            {required && <span className="text-red-500 ml-1">*</span>}
          </Label>
        )}
        
        <Input
          ref={ref}
          id={inputId}
          className={cn(
            "h-11",
            hasError && "border-red-500 focus:border-red-500 focus:ring-red-500",
            className
          )}
          {...props}
        />
        
        {hasError && (
          <p className="text-sm text-red-600 mt-1">
            {error}
          </p>
        )}
        
        {helperText && !hasError && (
          <p className="text-sm text-gray-500 mt-1">
            {helperText}
          </p>
        )}
      </div>
    );
  }
);

FormInput.displayName = "FormInput";

export { FormInput };
export default FormInput;
