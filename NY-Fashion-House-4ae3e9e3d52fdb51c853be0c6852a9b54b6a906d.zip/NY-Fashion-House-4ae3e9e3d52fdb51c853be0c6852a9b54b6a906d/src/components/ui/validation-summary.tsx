import React from 'react';
import { AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface ValidationSummaryProps {
  errors: Record<string, string>;
  touched: Record<string, boolean>;
  className?: string;
  showSuccessWhenValid?: boolean;
  title?: string;
}

const ValidationSummary: React.FC<ValidationSummaryProps> = ({
  errors,
  touched,
  className,
  showSuccessWhenValid = false,
  title = "Form Validation"
}) => {
  const touchedErrors = Object.entries(errors).filter(([key]) => touched[key]);
  const hasErrors = touchedErrors.length > 0;
  const touchedFields = Object.keys(touched).length;
  const isValid = touchedFields > 0 && !hasErrors;

  if (!touchedFields) return null;

  if (isValid && showSuccessWhenValid) {
    return (
      <Alert className={cn("border-green-500 bg-green-50", className)}>
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800">
          All fields are valid
        </AlertDescription>
      </Alert>
    );
  }

  if (!hasErrors) return null;

  return (
    <Card className={cn("border-red-500 bg-red-50", className)}>
      <CardContent className="pt-4">
        <div className="flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
          <div className="flex-1">
            <h4 className="text-sm font-medium text-red-800 mb-2">
              {title} ({touchedErrors.length} error{touchedErrors.length !== 1 ? 's' : ''})
            </h4>
            <ul className="text-sm text-red-700 space-y-1">
              {touchedErrors.map(([field, error]) => (
                <li key={field} className="flex items-start gap-1">
                  <span className="inline-block w-1 h-1 bg-red-600 rounded-full mt-2 flex-shrink-0" />
                  <span>
                    <strong className="capitalize">
                      {field.replace(/([A-Z])/g, ' $1').toLowerCase()}:
                    </strong>{' '}
                    {error}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export { ValidationSummary };
export default ValidationSummary;
