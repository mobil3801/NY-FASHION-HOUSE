// Finalized Error Boundary with Complete Coverage and Stream Error Handling
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw, Bug, FileText, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { finalizedErrorManagementSystem } from '@/services/finalizedErrorManagementSystem';

interface Props {
  children: ReactNode;
  level?: 'app' | 'page' | 'component' | 'widget';
  componentName?: string;
  fallbackType?: 'minimal' | 'detailed' | 'full';
  enableRetry?: boolean;
  enableReporting?: boolean;
  maxRetries?: number;
  showErrorDetails?: boolean;
  enableAutoRecovery?: boolean;
  recoveryDelay?: number;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
  retryCount: number;
  isRecovering: boolean;
  errorId: string;
  streamErrorDetected: boolean;
  patternAnalysisResults?: any;
}

class FinalizedErrorBoundary extends Component<Props, State> {
  private retryTimeout?: NodeJS.Timeout;
  private recoveryTimeout?: NodeJS.Timeout;

  constructor(props: Props) {
    super(props);

    this.state = {
      hasError: false,
      retryCount: 0,
      isRecovering: false,
      errorId: this.generateErrorId(),
      streamErrorDetected: false
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    // Detect stream errors specifically
    const streamErrorDetected = error.message?.includes('stream') ||
    error.message?.includes('copy') ||
    error.message?.includes('Error while copying content');

    return {
      hasError: true,
      error,
      streamErrorDetected,
      errorId: Math.random().toString(36).substr(2, 9)
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[FINALIZED ERROR BOUNDARY] Error caught:', {
      error: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      level: this.props.level,
      componentName: this.props.componentName
    });

    // Enhanced error metadata
    const metadata = {
      level: this.props.level || 'component',
      componentName: this.props.componentName || 'Unknown',
      severity: this.state.streamErrorDetected ? 'high' : 'medium',
      category: this.state.streamErrorDetected ? 'stream_operations' : 'component_error',
      errorInfo,
      userAgent: navigator.userAgent,
      url: window.location.href,
      timestamp: new Date().toISOString(),
      retryCount: this.state.retryCount
    };

    // Send to finalized error management system
    finalizedErrorManagementSystem.handleError(error, metadata);

    this.setState({
      error,
      errorInfo,
      patternAnalysisResults: finalizedErrorManagementSystem.getErrorPatterns()
    });

    // Auto-recovery for stream errors
    if (this.state.streamErrorDetected && this.props.enableAutoRecovery !== false) {
      this.initiateStreamErrorRecovery();
    }

    // Trigger automatic retry for certain error types
    if (this.props.enableRetry !== false && this.shouldAutoRetry(error)) {
      this.scheduleRetry();
    }
  }

  private generateErrorId(): string {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private shouldAutoRetry(error: Error): boolean {
    const maxRetries = this.props.maxRetries || 3;
    if (this.state.retryCount >= maxRetries) return false;

    // Auto-retry for network errors, temporary failures, and stream errors
    return error.message.includes('network') ||
    error.message.includes('timeout') ||
    error.message.includes('stream') ||
    error.message.includes('temporary') ||
    error.name === 'ChunkLoadError';
  }

  private scheduleRetry(): void {
    if (this.retryTimeout) clearTimeout(this.retryTimeout);

    const delay = Math.min(1000 * Math.pow(2, this.state.retryCount), 10000); // Exponential backoff, max 10s

    this.retryTimeout = setTimeout(() => {
      this.handleRetry();
    }, delay);
  }

  private initiateStreamErrorRecovery(): void {
    this.setState({ isRecovering: true });

    console.log('[STREAM ERROR RECOVERY] Attempting recovery for stream error...');

    this.recoveryTimeout = setTimeout(() => {
      this.setState({
        isRecovering: false,
        hasError: false,
        error: undefined,
        errorInfo: undefined,
        retryCount: 0
      });

      console.log('[STREAM ERROR RECOVERY] Recovery completed');
    }, this.props.recoveryDelay || 3000);
  }

  private handleRetry = (): void => {
    this.setState((prevState) => ({
      hasError: false,
      error: undefined,
      errorInfo: undefined,
      retryCount: prevState.retryCount + 1,
      isRecovering: false
    }));
  };

  private handleReload = (): void => {
    window.location.reload();
  };

  private handleReportError = (): void => {
    if (!this.state.error) return;

    const report = {
      errorId: this.state.errorId,
      error: {
        message: this.state.error.message,
        stack: this.state.error.stack,
        name: this.state.error.name
      },
      errorInfo: this.state.errorInfo,
      level: this.props.level,
      componentName: this.props.componentName,
      streamError: this.state.streamErrorDetected,
      systemHealth: finalizedErrorManagementSystem.getSystemHealth(),
      timestamp: new Date().toISOString()
    };

    console.log('[ERROR REPORT]', report);

    // Could integrate with external reporting service here
    navigator.clipboard?.writeText(JSON.stringify(report, null, 2));
    alert('Error report copied to clipboard');
  };

  componentWillUnmount() {
    if (this.retryTimeout) clearTimeout(this.retryTimeout);
    if (this.recoveryTimeout) clearTimeout(this.recoveryTimeout);
  }

  renderMinimalFallback() {
    return (
      <div className="flex items-center justify-center p-4 bg-red-50 border border-red-200 rounded-lg">
        <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
        <span className="text-red-700 text-sm">Something went wrong</span>
        {this.props.enableRetry !== false &&
        <Button
          variant="outline"
          size="sm"
          onClick={this.handleRetry}
          disabled={this.state.isRecovering}
          className="ml-2">

            {this.state.isRecovering ?
          <RefreshCw className="w-4 h-4 animate-spin" /> :

          'Retry'
          }
          </Button>
        }
      </div>);

  }

  renderDetailedFallback() {
    const { error, streamErrorDetected } = this.state;

    return (
      <Card className="max-w-2xl mx-auto m-4">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-6 h-6 text-red-500" />
              <div>
                <CardTitle className="text-lg">
                  {streamErrorDetected ? 'Stream Operation Error' : 'Application Error'}
                </CardTitle>
                <CardDescription>
                  Error in {this.props.componentName || 'component'} at {this.props.level || 'unknown'} level
                </CardDescription>
              </div>
            </div>
            <Badge variant={streamErrorDetected ? 'destructive' : 'secondary'}>
              {streamErrorDetected ? 'Stream Error' : 'Component Error'}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {streamErrorDetected &&
          <Alert className="border-orange-200 bg-orange-50">
              <Zap className="w-4 h-4 text-orange-500" />
              <AlertDescription className="text-orange-700">
                A stream operation failed. The system is attempting automatic recovery.
              </AlertDescription>
            </Alert>
          }

          {error && this.props.showErrorDetails &&
          <div className="bg-gray-50 p-3 rounded-md">
              <p className="text-sm font-medium text-gray-700 mb-1">Error Details:</p>
              <p className="text-sm text-gray-600 break-words">{error.message}</p>
            </div>
          }

          <div className="flex flex-wrap gap-2">
            {this.props.enableRetry !== false &&
            <Button
              onClick={this.handleRetry}
              disabled={this.state.isRecovering}
              size="sm"
              variant="default">

                {this.state.isRecovering ?
              <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Recovering...
                  </> :

              <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Retry ({this.state.retryCount}/{this.props.maxRetries || 3})
                  </>
              }
              </Button>
            }

            <Button onClick={this.handleReload} variant="outline" size="sm">
              Reload Page
            </Button>

            {this.props.enableReporting !== false &&
            <Button onClick={this.handleReportError} variant="outline" size="sm">
                <Bug className="w-4 h-4 mr-2" />
                Report Issue
              </Button>
            }
          </div>

          {this.state.patternAnalysisResults &&
          <div className="text-xs text-gray-500">
              Error ID: {this.state.errorId} | Patterns detected: {this.state.patternAnalysisResults.length}
            </div>
          }
        </CardContent>
      </Card>);

  }

  renderFullFallback() {
    const { error, errorInfo, streamErrorDetected } = this.state;
    const systemHealth = finalizedErrorManagementSystem.getSystemHealth();

    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-4xl w-full">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <AlertCircle className="w-8 h-8 text-red-500" />
                <div>
                  <CardTitle className="text-xl">
                    Critical Error - Application Recovery Required
                  </CardTitle>
                  <CardDescription className="text-base">
                    A serious error occurred that requires immediate attention
                  </CardDescription>
                </div>
              </div>
              <Badge variant="destructive" className="text-sm px-3 py-1">
                Level: {this.props.level?.toUpperCase() || 'UNKNOWN'}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {streamErrorDetected &&
            <Alert className="border-red-200 bg-red-50">
                <Zap className="w-5 h-5 text-red-500" />
                <AlertDescription className="text-red-700 text-base">
                  <strong>Stream Error Detected:</strong> This error is related to data stream operations. 
                  The error management system has been notified and recovery procedures are active.
                </AlertDescription>
              </Alert>
            }

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <h3 className="font-medium text-gray-900">Error Information</h3>
                <div className="bg-white p-4 rounded-lg border space-y-2">
                  <div>
                    <span className="text-sm font-medium text-gray-600">Type:</span>
                    <span className="ml-2 text-sm">{error?.name || 'Unknown'}</span>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Component:</span>
                    <span className="ml-2 text-sm">{this.props.componentName || 'Unknown'}</span>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Error ID:</span>
                    <span className="ml-2 text-sm font-mono">{this.state.errorId}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-medium text-gray-900">System Health</h3>
                <div className="bg-white p-4 rounded-lg border space-y-2">
                  <div>
                    <span className="text-sm font-medium text-gray-600">Total Errors:</span>
                    <span className="ml-2 text-sm">{systemHealth.totalErrors}</span>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Stream Errors:</span>
                    <span className="ml-2 text-sm">{systemHealth.streamErrors}</span>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Status:</span>
                    <Badge variant={systemHealth.performanceOptimized ? 'default' : 'destructive'} className="ml-2">
                      {systemHealth.performanceOptimized ? 'Optimized' : 'Degraded'}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>

            {error && this.props.showErrorDetails &&
            <div className="space-y-3">
                <h3 className="font-medium text-gray-900">Technical Details</h3>
                <div className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm font-mono overflow-auto max-h-40">
                  <div className="mb-2">
                    <strong>Message:</strong> {error.message}
                  </div>
                  {error.stack &&
                <div>
                      <strong>Stack Trace:</strong>
                      <pre className="whitespace-pre-wrap mt-1 text-xs">{error.stack}</pre>
                    </div>
                }
                </div>
              </div>
            }

            <div className="flex flex-wrap gap-3 pt-4 border-t">
              {this.props.enableRetry !== false &&
              <Button
                onClick={this.handleRetry}
                disabled={this.state.isRecovering}
                size="default"
                className="min-w-[120px]">

                  {this.state.isRecovering ?
                <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Recovering...
                    </> :

                <>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Retry Application
                    </>
                }
                </Button>
              }

              <Button onClick={this.handleReload} variant="outline" size="default">
                <RefreshCw className="w-4 h-4 mr-2" />
                Reload Page
              </Button>

              {this.props.enableReporting !== false &&
              <Button onClick={this.handleReportError} variant="outline" size="default">
                  <FileText className="w-4 h-4 mr-2" />
                  Copy Error Report
                </Button>
              }
            </div>
          </CardContent>
        </Card>
      </div>);

  }

  render() {
    if (this.state.hasError) {
      const fallbackType = this.props.fallbackType || 'detailed';

      switch (fallbackType) {
        case 'minimal':
          return this.renderMinimalFallback();
        case 'full':
          return this.renderFullFallback();
        case 'detailed':
        default:
          return this.renderDetailedFallback();
      }
    }

    return this.props.children;
  }
}

export default FinalizedErrorBoundary;