import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Calculator, Clock, Plus, Minus, DollarSign, FileText } from 'lucide-react';
import { Employee } from '@/types/employee';
import { SalaryCalculation, PayPeriod } from '@/types/salary';
import { employeeService } from '@/services/employeeService';
import { salaryService } from '@/services/salaryService';
import { toast } from 'sonner';

interface SalaryCalculatorProps {
  onCalculationComplete?: (calculation: SalaryCalculation) => void;
}

const SalaryCalculator: React.FC<SalaryCalculatorProps> = ({ onCalculationComplete }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payPeriods, setPayPeriods] = useState<PayPeriod[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('');
  const [calculation, setCalculation] = useState<SalaryCalculation | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [employeesData, payPeriodsData] = await Promise.all([
      employeeService.getAllEmployees(),
      salaryService.getAllPayPeriods()]
      );
      setEmployees(employeesData.filter((emp) => emp.employmentStatus === 'active'));
      setPayPeriods(payPeriodsData);
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleCalculate = async () => {
    if (!selectedEmployee || !selectedPeriod) {
      toast.error('Please select both employee and pay period');
      return;
    }

    setIsCalculating(true);
    try {
      const calculationResult = await salaryService.calculateSalary(selectedEmployee, selectedPeriod);
      setCalculation(calculationResult);
      toast.success('Salary calculated successfully');
    } catch (error) {
      console.error('Failed to calculate salary:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to calculate salary');
    } finally {
      setIsCalculating(false);
    }
  };

  const handleSaveCalculation = async () => {
    if (!calculation) return;

    try {
      await salaryService.saveSalaryCalculation(calculation);
      toast.success('Salary calculation saved successfully');
      onCalculationComplete?.(calculation);
      setCalculation(null);
      setSelectedEmployee('');
      setSelectedPeriod('');
    } catch (error) {
      console.error('Failed to save calculation:', error);
      toast.error('Failed to save calculation');
    }
  };

  const selectedEmployeeData = employees.find((emp) => emp.id === selectedEmployee);
  const selectedPeriodData = payPeriods.find((period) => period.payPeriod === selectedPeriod);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-10 bg-gray-200 rounded"></div>
            <div className="h-10 bg-gray-200 rounded"></div>
            <div className="h-10 bg-gray-200 rounded w-1/3"></div>
          </div>
        </CardContent>
      </Card>);

  }

  return (
    <div className="space-y-6">
      {/* Calculation Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Salary Calculator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Employee</label>
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose an employee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((employee) =>
                  <SelectItem key={employee.id} value={employee.id}>
                      {employee.firstName} {employee.lastName} - {employee.position}
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Select Pay Period</label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose pay period" />
                </SelectTrigger>
                <SelectContent>
                  {payPeriods.map((period) =>
                  <SelectItem key={period.id} value={period.payPeriod}>
                      {period.payPeriod} ({period.bengaliMonth} {period.bengaliYear})
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedEmployeeData && selectedPeriodData &&
          <div className="p-4 bg-gray-50 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Employee:</span>
                  <p className="font-medium">{selectedEmployeeData.firstName} {selectedEmployeeData.lastName}</p>
                </div>
                <div>
                  <span className="text-gray-600">Department:</span>
                  <p className="font-medium">{selectedEmployeeData.department}</p>
                </div>
                <div>
                  <span className="text-gray-600">Position:</span>
                  <p className="font-medium">{selectedEmployeeData.position}</p>
                </div>
              </div>
            </div>
          }

          <div className="flex items-center justify-end">
            <Button
              onClick={handleCalculate}
              disabled={!selectedEmployee || !selectedPeriod || isCalculating}>

              {isCalculating ?
              <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Calculating...
                </> :

              <>
                  <Calculator className="h-4 w-4 mr-2" />
                  Calculate Salary
                </>
              }
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Calculation Results */}
      {calculation &&
      <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Calculation Results
            </CardTitle>
            <p className="text-sm text-gray-600">
              Pay Period: {calculation.payPeriod} ({calculation.bengaliMonth} {calculation.bengaliYear})
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Basic Salary */}
            <div>
              <h4 className="font-semibold text-lg mb-3">Basic Salary</h4>
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">
                  {formatCurrency(calculation.baseSalary)}
                </div>
              </div>
            </div>

            {/* Allowances */}
            <div>
              <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                <Plus className="h-4 w-4 text-green-600" />
                Allowances
              </h4>
              <div className="space-y-2">
                {calculation.allowances.map((allowance) =>
              <div key={allowance.id} className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <div>
                      <span className="font-medium">{allowance.name}</span>
                      <Badge variant="outline" className="ml-2">
                        {allowance.type === 'percentage' ? `${allowance.baseAmount}%` : 'Fixed'}
                      </Badge>
                    </div>
                    <span className="text-green-600 font-semibold">
                      +{formatCurrency(allowance.calculatedAmount)}
                    </span>
                  </div>
              )}
                {calculation.allowances.length === 0 &&
              <p className="text-gray-500 italic">No allowances</p>
              }
              </div>
            </div>

            {/* Overtime */}
            {calculation.overtime.overtimeHours > 0 &&
          <div>
                <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <Clock className="h-4 w-4 text-orange-600" />
                  Overtime
                </h4>
                <div className="p-4 bg-orange-50 rounded-lg">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Regular Hours:</span>
                      <p className="font-medium">{calculation.overtime.regularHours.toFixed(2)} hrs</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Overtime Hours:</span>
                      <p className="font-medium">{calculation.overtime.overtimeHours.toFixed(2)} hrs</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Overtime Rate:</span>
                      <p className="font-medium">{formatCurrency(calculation.overtime.overtimeRate)}/hr</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Overtime Amount:</span>
                      <p className="font-medium text-orange-600">
                        +{formatCurrency(calculation.overtime.overtimeAmount)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
          }

            {/* Gross Salary */}
            <div>
              <Separator />
              <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <span className="font-semibold text-lg">Gross Salary</span>
                <span className="text-2xl font-bold">
                  {formatCurrency(calculation.grossSalary)}
                </span>
              </div>
            </div>

            {/* Deductions */}
            <div>
              <h4 className="font-semibold text-lg mb-3 flex items-center gap-2">
                <Minus className="h-4 w-4 text-red-600" />
                Deductions
              </h4>
              <div className="space-y-2">
                {calculation.deductions.map((deduction) =>
              <div key={deduction.id} className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <div>
                      <span className="font-medium">{deduction.name}</span>
                      <Badge variant="outline" className="ml-2">
                        {deduction.type === 'percentage' ? `${deduction.baseAmount}%` :
                    deduction.type === 'tax' ? 'Tax' : 'Fixed'}
                      </Badge>
                      {deduction.taxDetails &&
                  <p className="text-xs text-gray-600 mt-1">
                          Tax Rate: {deduction.taxDetails.taxRate}% on {formatCurrency(deduction.taxDetails.taxableIncome)}
                        </p>
                  }
                    </div>
                    <span className="text-red-600 font-semibold">
                      -{formatCurrency(deduction.calculatedAmount)}
                    </span>
                  </div>
              )}
                {calculation.deductions.length === 0 &&
              <p className="text-gray-500 italic">No deductions</p>
              }
              </div>
            </div>

            {/* Net Salary */}
            <div>
              <Separator />
              <div className="p-6 bg-gradient-to-r from-blue-500 to-green-500 text-white rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-bold">Net Salary</h3>
                    <p className="opacity-90">Amount to be paid</p>
                  </div>
                  <div className="text-3xl font-bold">
                    {formatCurrency(calculation.netSalary)}
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end space-x-4 pt-4">
              <Button variant="outline" onClick={() => setCalculation(null)}>
                Clear
              </Button>
              <Button onClick={handleSaveCalculation}>
                <DollarSign className="h-4 w-4 mr-2" />
                Save Calculation
              </Button>
            </div>
          </CardContent>
        </Card>
      }
    </div>);

};

export default SalaryCalculator;